function EesQuizSchCandRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("edu_org_id").value  = document.getElementById("edu_org_id"+"_r"+inRecNum).value; 
    //document.getElementById("quiz_sch_id").value  = document.getElementById("quiz_sch_id"+"_r"+inRecNum).value; 
    document.getElementById("hna_cand_org_id").value  = document.getElementById("hna_cand_org_id"+"_r"+inRecNum).value; 
    document.getElementById("hna_cand_user_id").value  = document.getElementById("hna_cand_user_id"+"_r"+inRecNum).value; 
    //document.getElementById("user_ctg").value  = document.getElementById("user_ctg"+"_r"+inRecNum).value; 
    document.getElementById("name_initials").value  = document.getElementById("name_initials"+"_r"+inRecNum).value; 
    document.getElementById("first_name").value  = document.getElementById("first_name"+"_r"+inRecNum).value; 
    document.getElementById("middle_name").value  = document.getElementById("middle_name"+"_r"+inRecNum).value; 
    document.getElementById("last_name").value  = document.getElementById("last_name"+"_r"+inRecNum).value; 
    document.getElementById("email_id").value  = document.getElementById("email_id"+"_r"+inRecNum).value; 
    //document.getElementById("is_user_exist").value  = document.getElementById("is_user_exist"+"_r"+inRecNum).value; 
    //document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    //document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    //document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    //document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
    //document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value; 
    //document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    //document.getElementById("city_name").value  = document.getElementById("city_name"+"_r"+inRecNum).value; 
    //document.getElementById("state_name").value  = document.getElementById("state_name"+"_r"+inRecNum).value; 
    //document.getElementById("country_name").value  = document.getElementById("country_name"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_1").value  = document.getElementById("contact_num_1"+"_r"+inRecNum).value; 
    document.getElementById("university_board_name").value  = document.getElementById("university_board_name"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_by").value  = document.getElementById("rec_cre_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_by").value  = document.getElementById("rec_upd_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 
    //document.getElementById("hna_user_id").value  = document.getElementById("hna_user_id"+"_r"+inRecNum).value; 
    //document.getElementById("hna_org_id").value  = document.getElementById("hna_org_id"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("edu_org_id").value  = '';
    //document.getElementById("quiz_sch_id").value  = '';
    document.getElementById("hna_cand_org_id").value  = '';
    document.getElementById("hna_cand_user_id").value  = '';
    //document.getElementById("user_ctg").value  = '';
    document.getElementById("name_initials").value  = '';
    document.getElementById("first_name").value  = '';
    document.getElementById("middle_name").value  = '';
    document.getElementById("last_name").value  = '';
    document.getElementById("email_id").value  = '';
    //document.getElementById("is_user_exist").value  = '';
    //document.getElementById("address_1").value  = '';
    //document.getElementById("address_2").value  = '';
    //document.getElementById("city").value  = '';
    //document.getElementById("zip").value  = '';
    //document.getElementById("state").value  = '';
    //document.getElementById("country").value  = '';
    //document.getElementById("city_name").value  = '';
    //document.getElementById("state_name").value  = '';
    //document.getElementById("country_name").value  = '';
    document.getElementById("contact_num_1").value  = '';
    document.getElementById("university_board_name").value  = '';
    document.getElementById("status").value  = '';
    //document.getElementById("rec_cre_by").value  = '';
    //document.getElementById("rec_cre_date").value  = '';
    //document.getElementById("rec_cre_time").value  = '';
    //document.getElementById("rec_upd_by").value  = '';
    //document.getElementById("rec_upd_date").value  = '';
    //document.getElementById("rec_upd_time").value  = '';
    //document.getElementById("hna_user_id").value  = '';
    //document.getElementById("hna_org_id").value  = '';
  }
}
