function ClassIdDisable()
{
 var lSessionType = document.getElementById("session_type").value;
 if(lSessionType == 'X')
 {
  document.getElementById("class_id").disabled =  true;
  document.getElementById("class_id_exam").disabled =  false;
 }
 else
 {
  document.getElementById("class_id").disabled =  false;
  document.getElementById("class_id_exam").disabled =  true;
 }
}
