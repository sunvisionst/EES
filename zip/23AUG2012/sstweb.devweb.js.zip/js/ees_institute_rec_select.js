function EesInstituteRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("institute_id").value  = document.getElementById("institute_id"+"_r"+inRecNum).value; 
    document.getElementById("institute_name").value  = document.getElementById("institute_name"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    document.getElementById("website").value  = document.getElementById("website"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_1").value  = document.getElementById("contact_num_1"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_2").value  = document.getElementById("contact_num_2"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_3").value  = document.getElementById("contact_num_3"+"_r"+inRecNum).value; 
    document.getElementById("fax_1").value  = document.getElementById("fax_1"+"_r"+inRecNum).value; 
    document.getElementById("fax_2").value  = document.getElementById("fax_2"+"_r"+inRecNum).value; 
    document.getElementById("email_id_1").value  = document.getElementById("email_id_1"+"_r"+inRecNum).value; 
    document.getElementById("email_id_2").value  = document.getElementById("email_id_2"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value  = '';
    document.getElementById("institute_id").value  = '';
    document.getElementById("institute_name").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("zip").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("website").value  = '';
    document.getElementById("contact_num_1").value  = '';
    document.getElementById("contact_num_2").value  = '';
    document.getElementById("contact_num_3").value  = '';
    document.getElementById("fax_1").value  = '';
    document.getElementById("fax_2").value  = '';
    document.getElementById("email_id_1").value  = '';
    document.getElementById("email_id_2").value  = '';
  }
}
