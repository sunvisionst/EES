function getAssistantName()
{
  document.getElementById("assistant_name").value =   document.getElementById("assistant_id").value;
  document.getElementById("faculty_name").value =   document.getElementById("faculty_id").value;

}
