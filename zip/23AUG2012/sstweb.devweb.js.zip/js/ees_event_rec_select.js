function EesEventRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value           = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("event_id").value         = document.getElementById("event_id"+"_r"+inRecNum).value;
    document.getElementById("event_type").value       = document.getElementById("event_type"+"_r"+inRecNum).value;
    document.getElementById("event_desc").value       = document.getElementById("event_desc"+"_r"+inRecNum).value;
    document.getElementById("event_start_date").value = document.getElementById("event_start_date"+"_r"+inRecNum).value;
    document.getElementById("event_close_date").value = document.getElementById("event_close_date"+"_r"+inRecNum).value;

    document.getElementById("ptl_publish_ind").value = document.getElementById("ptl_publish_ind"+"_r"+inRecNum).value;
    document.getElementById("ptl_publish_start_date").value = document.getElementById("ptl_publish_start_date"+"_r"+inRecNum).value;
    document.getElementById("ptl_publish_close_date").value = document.getElementById("ptl_publish_close_date"+"_r"+inRecNum).value;

    //-------------------------------------------------------------------------
    var lPtlUserIdGlobal = document.getElementById("ptl_user_id_global");
    if ( lPtlUserIdGlobal && lPtlUserIdGlobal.value.length > 0 )
    {
      if ( lPtlUserIdGlobal.value == document.getElementById("ptl_user_id"+"_r"+inRecNum).value )
        document.getElementById("oth_ptl_user_ind").value = 'N';
      else
        document.getElementById("oth_ptl_user_ind").value = 'Y';
      document.getElementById("ptl_user_id").value = document.getElementById("ptl_user_id"+"_r"+inRecNum).value;
    }
    //-------------------------------------------------------------------------

    get_event_matter( 'event_matter', document.getElementById("org_id").value, document.getElementById("event_id").value, 'N' );
    //get_event_matter( 'event_matter_td', document.getElementById("org_id").value, document.getElementById("event_id").value, 'Y' );

    //-------------------------------------------------------------------------
    var lSstGuruIndObj = document.getElementById("sst_guru_ind");
    var lSstGuruTypeObj = document.getElementById("sst_guru_type");
    var lActionBarTrObj = document.getElementById("action_bar_tr");
    var lStatusObj = document.getElementById("status"+"_r"+inRecNum);
    //-------------------------------------------------------------------------
    if ( ( lActionBarTrObj && !lSstGuruIndObj && lStatusObj )
      || ( lActionBarTrObj && ( lSstGuruIndObj && lSstGuruTypeObj && lSstGuruTypeObj.value.search(/199/i) == -1 ) && lStatusObj ) )
    {
      if ( ( lStatusObj.value == 'A' ) )
        lActionBarTrObj.style.display = 'none';
      else
      if ( ( lStatusObj.value == 'S' ) )
        lActionBarTrObj.style.display = 'none';
      else
        lActionBarTrObj.style.display = '';
    }
    else
    if ( lActionBarTrObj && ( lSstGuruIndObj && lSstGuruTypeObj && lSstGuruTypeObj.value.search(/199/i) > -1 ) && lStatusObj )
    {
      if ( lPtlUserIdGlobal.value == document.getElementById("ptl_user_id"+"_r"+inRecNum).value )
        lActionBarTrObj.style.display = '';
      else
        lActionBarTrObj.style.display = 'none';
    }
    //-------------------------------------------------------------------------
    //-------------------------------------------------------------------------
    var lEventApproveLinkTr = document.getElementById("event_approve_link_tr");
    if ( lEventApproveLinkTr )
    {
      if ( ( lStatusObj && lStatusObj.value == 'S' ) )
        lEventApproveLinkTr.style.display = '';
      else
        lEventApproveLinkTr.style.display = 'none';
    }
    //-------------------------------------------------------------------------
    var lEventSendLinkTr = document.getElementById("event_send_link_tr");
    if ( lEventSendLinkTr )
    {
      if ( ( lStatusObj && ( lStatusObj.value == 'O' || lStatusObj.value == 'R' ) ) )
        lEventSendLinkTr.style.display = '';
      else
        lEventSendLinkTr.style.display = 'none';
    }
    //-------------------------------------------------------------------------
    //document.getElementById("action_container_td").innerHTML      = '';
    //-------------------------------------------------------------------------
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    
    //document.getElementById("org_id").value          = '';
    document.getElementById("event_id").value         = '';
    document.getElementById("event_type").value       = '';
    document.getElementById("event_desc").value       = '';
    document.getElementById("event_start_date").value = '';
    document.getElementById("event_close_date").value = '';

    document.getElementById("ptl_publish_ind").value  = '';
    document.getElementById("ptl_publish_start_date").value = '';
    document.getElementById("ptl_publish_close_date").value = '';

    //-------------------------------------------------------------------------
    var lPtlUserIdGlobal = document.getElementById("ptl_user_id_global");
    if ( lPtlUserIdGlobal && lPtlUserIdGlobal.value.length > 0 )
    {
      document.getElementById("oth_ptl_user_ind").value = 'N';
      document.getElementById("ptl_user_id").value = lPtlUserIdGlobal.value;
    }
    //-------------------------------------------------------------------------

    document.getElementById("event_matter").value     = '';

    if ( document.getElementById("event_approve_link_tr") ) document.getElementById("event_approve_link_tr").style.display = 'none';
    if ( document.getElementById("event_send_link_tr") ) document.getElementById("event_send_link_tr").style.display = 'none';
    if ( document.getElementById("action_bar_tr") ) document.getElementById("action_bar_tr").style.display = '';
    //document.getElementById("action_container_td").innerHTML = '';
  }
}
