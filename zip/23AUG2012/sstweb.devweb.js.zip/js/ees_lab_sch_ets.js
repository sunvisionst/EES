function FacultyDisabled()
{
 var lClassId = document.getElementById("class_id");
 if(lClassId =='ETS')
 {
  document.getElementById("faculty_id").disabled = true;
  document.getElementById("faculty_name").disabled = true;
 }
 else
 {
  document.getElementById("faculty_id").disabled = false;
  document.getElementById("faculty_name").disabled = false;
 }
 
}
