function EesTnpCompanyRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("company_id").value  = document.getElementById("company_id"+"_r"+inRecNum).value; 
    document.getElementById("company_name").value  = document.getElementById("company_name"+"_r"+inRecNum).value; 
    document.getElementById("compnay_ctg").value  = document.getElementById("compnay_ctg"+"_r"+inRecNum).value; 
    document.getElementById("compnay_type").value  = document.getElementById("compnay_type"+"_r"+inRecNum).value; 
    document.getElementById("tnp_flag").value  = document.getElementById("tnp_flag"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    document.getElementById("company_url").value  = document.getElementById("company_url"+"_r"+inRecNum).value; 
    document.getElementById("working_domain").value  = document.getElementById("working_domain"+"_r"+inRecNum).value; 
    document.getElementById("specialization").value  = document.getElementById("specialization"+"_r"+inRecNum).value; 
    document.getElementById("contact_person").value  = document.getElementById("contact_person"+"_r"+inRecNum).value; 
    document.getElementById("contact_person_desgnation").value  = document.getElementById("contact_person_desgnation"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_1").value  = document.getElementById("contact_num_1"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_2").value  = document.getElementById("contact_num_2"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_3").value  = document.getElementById("contact_num_3"+"_r"+inRecNum).value; 
    document.getElementById("fax_1").value  = document.getElementById("fax_1"+"_r"+inRecNum).value; 
    document.getElementById("fax_2").value  = document.getElementById("fax_2"+"_r"+inRecNum).value; 
    document.getElementById("email_id_1").value  = document.getElementById("email_id_1"+"_r"+inRecNum).value; 
    document.getElementById("email_id_2").value  = document.getElementById("email_id_2"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("company_id").value  = '';
    document.getElementById("company_name").value  = '';
    document.getElementById("compnay_ctg").value  = '';
    document.getElementById("compnay_type").value  = '';
    document.getElementById("tnp_flag").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("zip").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("company_url").value  = '';
    document.getElementById("working_domain").value  = '';
    document.getElementById("specialization").value  = '';
    document.getElementById("contact_person").value  = '';
    document.getElementById("contact_person_desgnation").value  = '';
    document.getElementById("contact_num_1").value  = '';
    document.getElementById("contact_num_2").value  = '';
    document.getElementById("contact_num_3").value  = '';
    document.getElementById("fax_1").value  = '';
    document.getElementById("fax_2").value  = '';
    document.getElementById("email_id_1").value  = '';
    document.getElementById("email_id_2").value  = '';
  }
}
