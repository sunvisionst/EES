function EsmSupplierPoRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("po_num_query").value  = document.getElementById("po_num"+"_r"+inRecNum).value; 
    document.getElementById("po_num").value  = document.getElementById("po_num"+"_r"+inRecNum).value; 
    document.getElementById("supplier_id").value  = document.getElementById("supplier_id"+"_r"+inRecNum).value; 
    document.getElementById("po_date").value  = document.getElementById("po_date"+"_r"+inRecNum).value; 
    document.getElementById("order_type").value  = document.getElementById("order_type"+"_r"+inRecNum).value; 
    document.getElementById("buyer_ref_num").value  = document.getElementById("buyer_ref_num"+"_r"+inRecNum).value; 
    document.getElementById("buyer_ref_date").value  = document.getElementById("buyer_ref_date"+"_r"+inRecNum).value; 
    document.getElementById("po_status").value  = document.getElementById("po_status"+"_r"+inRecNum).value; 
    if ( document.getElementById("po_status"+"_r"+inRecNum).value == 'A' )
    {
      //lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      //lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit7"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit8"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    }
    else
    if ( document.getElementById("po_status"+"_r"+inRecNum).value == 'O' )
    {
      //lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      //lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit7"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit8"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    }
    document.getElementById("po_status_date").value  = document.getElementById("po_status_date"+"_r"+inRecNum).value; 
    document.getElementById("pay_mode").value  = document.getElementById("pay_mode"+"_r"+inRecNum).value; 
    document.getElementById("pay_term").value  = document.getElementById("pay_term"+"_r"+inRecNum).value; 
    document.getElementById("enq_num").value  = document.getElementById("enq_num"+"_r"+inRecNum).value; 
    document.getElementById("enq_version").value  = document.getElementById("enq_version"+"_r"+inRecNum).value; 
    document.getElementById("enq_date").value  = document.getElementById("enq_date"+"_r"+inRecNum).value; 
    document.getElementById("spl_instruction").value  = document.getElementById("spl_instruction"+"_r"+inRecNum).value; 
    document.getElementById("destination_id").value  = document.getElementById("destination_id"+"_r"+inRecNum).value; 
    document.getElementById("delivery_date").value  = document.getElementById("delivery_date"+"_r"+inRecNum).value; 
    document.getElementById("delivery_address_type").value  = document.getElementById("delivery_address_type"+"_r"+inRecNum).value; 
    document.getElementById("delivery_address").value  = document.getElementById("delivery_address"+"_r"+inRecNum).value; 
    //document.getElementById("discount_percent").value  = document.getElementById("discount_percent"+"_r"+inRecNum).value; 
    //document.getElementById("discount_fix").value  = document.getElementById("discount_fix"+"_r"+inRecNum).value; 
    document.getElementById("discount_date").value  = document.getElementById("discount_date"+"_r"+inRecNum).value; 
    document.getElementById("transport_mode").value  = document.getElementById("transport_mode"+"_r"+inRecNum).value; 
    document.getElementById("cancel_flag").value  = document.getElementById("cancel_flag"+"_r"+inRecNum).value; 
    document.getElementById("cancel_date").value  = document.getElementById("cancel_date"+"_r"+inRecNum).value; 
    document.getElementById("cancel_remark").value  = document.getElementById("cancel_remark"+"_r"+inRecNum).value; 
    document.getElementById("reject_flag").value  = document.getElementById("reject_flag"+"_r"+inRecNum).value; 
    document.getElementById("reject_date").value  = document.getElementById("reject_date"+"_r"+inRecNum).value; 
    document.getElementById("reject_remark").value  = document.getElementById("reject_remark"+"_r"+inRecNum).value; 
    //document.getElementById("pr_ord_item_req_num").value  = document.getElementById("pr_ord_item_req_num"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("po_num_query").value  = '';
    document.getElementById("po_num").value  = '';
    document.getElementById("supplier_id").value  = '';
    document.getElementById("po_date").value  = '';
    document.getElementById("order_type").value  = '';
    document.getElementById("buyer_ref_num").value  = '';
    document.getElementById("buyer_ref_date").value  = '';
    document.getElementById("po_status").value  = '';
    {
      //lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      //lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      /*
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit7"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit8"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      */
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit7"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit8"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    }
    document.getElementById("po_status_date").value  = '';
    document.getElementById("pay_mode").value  = '';
    document.getElementById("pay_term").value  = '';
    document.getElementById("enq_num").value  = '';
    document.getElementById("enq_version").value  = '';
    document.getElementById("enq_date").value  = '';
    document.getElementById("spl_instruction").value  = '';
    document.getElementById("destination_id").value  = '';
    document.getElementById("delivery_date").value  = '';
    document.getElementById("delivery_address_type").value  = '';
    document.getElementById("delivery_address").value  = '';
    //document.getElementById("discount_percent").value  = '';
    //document.getElementById("discount_fix").value  = '';
    document.getElementById("discount_date").value  = '';
    document.getElementById("transport_mode").value  = '';
    document.getElementById("cancel_flag").value  = '';
    document.getElementById("cancel_date").value  = '';
    document.getElementById("cancel_remark").value  = '';
    document.getElementById("reject_flag").value  = '';
    document.getElementById("reject_date").value  = '';
    document.getElementById("reject_remark").value  = '';
    //document.getElementById("pr_ord_item_req_num").value  = '';
  }
}
