function EesAdmListRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //alert("aaaa-> "+ document.getElementById("dob"+"_r"+inRecNum).value); 
    var lDobArr   =  document.getElementById("dob"+"_r"+inRecNum).value.split('-'); 
    //alert('lDobArr[0]'+lDobArr[0]);
    //alert('lDobArr[1]'+lDobArr[1]);
    //alert('lDobArr[2]'+lDobArr[2]);
    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("adm_req_id").value  = document.getElementById("adm_req_id"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("student_f_name").value  = document.getElementById("student_f_name"+"_r"+inRecNum).value; 
    document.getElementById("student_m_name").value  = document.getElementById("student_m_name"+"_r"+inRecNum).value; 
    document.getElementById("student_l_name").value  = document.getElementById("student_l_name"+"_r"+inRecNum).value; 
    document.getElementById("student_ctg").value  = document.getElementById("student_ctg"+"_r"+inRecNum).value; 
    document.getElementById("gender_flag").value  = document.getElementById("gender_flag"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("unv_rn_1").value  = document.getElementById("unv_rn_1"+"_r"+inRecNum).value; 
    document.getElementById("gen_rank_1").value  = document.getElementById("gen_rank_1"+"_r"+inRecNum).value; 
    document.getElementById("ctg_rank_1").value  = document.getElementById("ctg_rank_1"+"_r"+inRecNum).value; 
    document.getElementById("cheque_num").value  = document.getElementById("cheque_num"+"_r"+inRecNum).value; 
    document.getElementById("cheque_date").value  = document.getElementById("cheque_date"+"_r"+inRecNum).value; 
    //document.getElementById("bank_code").value  = document.getElementById("bank_code"+"_r"+inRecNum).value; 
    document.getElementById("bank_name").value  = document.getElementById("bank_name"+"_r"+inRecNum).value; 
    document.getElementById("father_name").value  = document.getElementById("father_name"+"_r"+inRecNum).value; 
    document.getElementById("cheque_amt").value  = document.getElementById("cheque_amt"+"_r"+inRecNum).value; 
    document.getElementById("adv_adm_fee").value  = document.getElementById("cheque_amt"+"_r"+inRecNum).value; 

    /*document.getElementById("application_form_num").value  = document.getElementById("application_form_num"+"_r"+inRecNum).value; 
    document.getElementById("applicant_id").value  = document.getElementById("applicant_id"+"_r"+inRecNum).value; 
    document.getElementById("student_photo_file").value  = document.getElementById("student_photo_file"+"_r"+inRecNum).value; 
    document.getElementById("mother_photo_file").value  = document.getElementById("mother_photo_file"+"_r"+inRecNum).value; 
    document.getElementById("father_photo_file").value  = document.getElementById("father_photo_file"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 

    */
    //document.getElementById("dob").value  = document.getElementById("dob"+"_r"+inRecNum).value; 
    document.getElementById("dob_day").value  = lDobArr[0]; 
    document.getElementById("dob_month").value  = 1;//lDobArr[1]; 
    document.getElementById("dob_year").value  = lDobArr[2]; 
    /*
    document.getElementById("age_on_date").value  = document.getElementById("age_on_date"+"_r"+inRecNum).value; 
    document.getElementById("age_year").value  = document.getElementById("age_year"+"_r"+inRecNum).value; 
    document.getElementById("age_month").value  = document.getElementById("age_month"+"_r"+inRecNum).value; 
    document.getElementById("age_day").value  = document.getElementById("age_day"+"_r"+inRecNum).value; 
    document.getElementById("s_nationality").value  = document.getElementById("s_nationality"+"_r"+inRecNum).value; 
    document.getElementById("religion").value  = document.getElementById("religion"+"_r"+inRecNum).value; 
    */
    /*
    document.getElementById("p_address_1").value  = document.getElementById("p_address_1"+"_r"+inRecNum).value; 
    document.getElementById("p_address_2").value  = document.getElementById("p_address_2"+"_r"+inRecNum).value; 
    document.getElementById("p_country").value  = document.getElementById("p_country"+"_r"+inRecNum).value; 
    document.getElementById("p_state").value  = document.getElementById("p_state"+"_r"+inRecNum).value; 
    document.getElementById("p_city").value  = document.getElementById("p_city"+"_r"+inRecNum).value; 
    document.getElementById("p_district").value  = document.getElementById("p_district"+"_r"+inRecNum).value; 
    document.getElementById("p_zip").value  = document.getElementById("p_zip"+"_r"+inRecNum).value; 
    document.getElementById("m_address_1").value  = document.getElementById("m_address_1"+"_r"+inRecNum).value; 
    document.getElementById("m_address_2").value  = document.getElementById("m_address_2"+"_r"+inRecNum).value; 
    document.getElementById("m_country").value  = document.getElementById("m_country"+"_r"+inRecNum).value; 
    document.getElementById("m_state").value  = document.getElementById("m_state"+"_r"+inRecNum).value; 
    document.getElementById("m_city").value  = document.getElementById("m_city"+"_r"+inRecNum).value; 
    document.getElementById("m_district").value  = document.getElementById("m_district"+"_r"+inRecNum).value; 
    document.getElementById("m_zip").value  = document.getElementById("m_zip"+"_r"+inRecNum).value; 
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value; 
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value; 
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value; 
    document.getElementById("prev_org_name").value  = document.getElementById("prev_org_name"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_id").value  = document.getElementById("prev_class_id"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_num").value  = document.getElementById("prev_class_num"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_std").value  = document.getElementById("prev_class_std"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_section").value  = document.getElementById("prev_class_section"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_id").value  = document.getElementById("prev_course_id"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_term").value  = document.getElementById("prev_course_term"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_stream").value  = document.getElementById("prev_course_stream"+"_r"+inRecNum).value; 
    document.getElementById("reason_for_leaving").value  = document.getElementById("reason_for_leaving"+"_r"+inRecNum).value; 
    */
    /*
    document.getElementById("father_age").value  = document.getElementById("father_age"+"_r"+inRecNum).value; 
    document.getElementById("f_nationality").value  = document.getElementById("f_nationality"+"_r"+inRecNum).value; 
    document.getElementById("father_occ_type").value  = document.getElementById("father_occ_type"+"_r"+inRecNum).value; 
    document.getElementById("father_employer").value  = document.getElementById("father_employer"+"_r"+inRecNum).value; 
    document.getElementById("father_designation").value  = document.getElementById("father_designation"+"_r"+inRecNum).value; 
    document.getElementById("father_annual_income").value  = document.getElementById("father_annual_income"+"_r"+inRecNum).value; 
    document.getElementById("f_off_address_1").value  = document.getElementById("f_off_address_1"+"_r"+inRecNum).value; 
    document.getElementById("f_phone_list").value  = document.getElementById("f_phone_list"+"_r"+inRecNum).value; 
    document.getElementById("mother_name").value  = document.getElementById("mother_name"+"_r"+inRecNum).value; 
    document.getElementById("mother_age").value  = document.getElementById("mother_age"+"_r"+inRecNum).value; 
    document.getElementById("m_nationality").value  = document.getElementById("m_nationality"+"_r"+inRecNum).value; 
    document.getElementById("mother_occ_type").value  = document.getElementById("mother_occ_type"+"_r"+inRecNum).value; 
    document.getElementById("mother_employer").value  = document.getElementById("mother_employer"+"_r"+inRecNum).value; 
    document.getElementById("mother_designation").value  = document.getElementById("mother_designation"+"_r"+inRecNum).value; 
    document.getElementById("mother_annual_income").value  = document.getElementById("mother_annual_income"+"_r"+inRecNum).value; 
    document.getElementById("m_off_address_1").value  = document.getElementById("m_off_address_1"+"_r"+inRecNum).value; 
    document.getElementById("m_phone_list").value  = document.getElementById("m_phone_list"+"_r"+inRecNum).value; 
    document.getElementById("divorced_flag").value  = document.getElementById("divorced_flag"+"_r"+inRecNum).value; 
    document.getElementById("child_with").value  = document.getElementById("child_with"+"_r"+inRecNum).value;
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    */ 
    /*
    document.getElementById("adm_req_sts").value  = document.getElementById("adm_req_sts"+"_r"+inRecNum).value; 
    document.getElementById("adm_req_sts_date").value  = document.getElementById("adm_req_sts_date"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("scholor_num").value  = document.getElementById("scholor_num"+"_r"+inRecNum).value; 
    document.getElementById("form_recv_date").value  = document.getElementById("form_recv_date"+"_r"+inRecNum).value; 
    document.getElementById("form_recv_time").value  = document.getElementById("form_recv_time"+"_r"+inRecNum).value; 
    document.getElementById("prospectus_sale_date").value  = document.getElementById("prospectus_sale_date"+"_r"+inRecNum).value; 
    document.getElementById("prospectus_sale_time").value  = document.getElementById("prospectus_sale_time"+"_r"+inRecNum).value; 
    document.getElementById("prospectus_sold_by").value  = document.getElementById("prospectus_sold_by"+"_r"+inRecNum).value; 
    document.getElementById("application_form_fee").value  = document.getElementById("application_form_fee"+"_r"+inRecNum).value; 
    document.getElementById("adm_academic_session").value  = document.getElementById("adm_academic_session"+"_r"+inRecNum).value; 
    document.getElementById("entrance_exam_date").value  = document.getElementById("entrance_exam_date"+"_r"+inRecNum).value; 
    document.getElementById("entrance_exam_time_start").value  = document.getElementById("entrance_exam_time_start"+"_r"+inRecNum).value; 
    document.getElementById("entrance_exam_time_end").value  = document.getElementById("entrance_exam_time_end"+"_r"+inRecNum).value; 
    document.getElementById("exam_present_status").value  = document.getElementById("exam_present_status"+"_r"+inRecNum).value; 
    document.getElementById("building_id").value  = document.getElementById("building_id"+"_r"+inRecNum).value; 
    document.getElementById("floor_num").value  = document.getElementById("floor_num"+"_r"+inRecNum).value; 
    
    document.getElementById("room_num").value  = document.getElementById("room_num"+"_r"+inRecNum).value; 
    
    document.getElementById("max_mark").value  = document.getElementById("max_mark"+"_r"+inRecNum).value; 
    document.getElementById("obtained_mark").value  = document.getElementById("obtained_mark"+"_r"+inRecNum).value; 
    document.getElementById("grade").value  = document.getElementById("grade"+"_r"+inRecNum).value; 
    document.getElementById("fee_sch_date").value  = document.getElementById("fee_sch_date"+"_r"+inRecNum).value; 
    document.getElementById("fee_deposit_date").value  = document.getElementById("fee_deposit_date"+"_r"+inRecNum).value; 
    document.getElementById("online_flag").value  = document.getElementById("online_flag"+"_r"+inRecNum).value; 
    document.getElementById("admission_mode").value  = document.getElementById("admission_mode"+"_r"+inRecNum).value; 
    document.getElementById("course_stream_1").value  = document.getElementById("course_stream_1"+"_r"+inRecNum).value; 
    document.getElementById("course_stream_2").value  = document.getElementById("course_stream_2"+"_r"+inRecNum).value; 
    document.getElementById("course_stream_3").value  = document.getElementById("course_stream_3"+"_r"+inRecNum).value; 
    document.getElementById("course_stream_4").value  = document.getElementById("course_stream_4"+"_r"+inRecNum).value; 
    document.getElementById("unv_1").value  = document.getElementById("unv_1"+"_r"+inRecNum).value; 
    */
    /*
    document.getElementById("stt_rank_1").value  = document.getElementById("stt_rank_1"+"_r"+inRecNum).value; 
    document.getElementById("yoa_1").value  = document.getElementById("yoa_1"+"_r"+inRecNum).value; 
    document.getElementById("unv_2").value  = document.getElementById("unv_2"+"_r"+inRecNum).value; 
    document.getElementById("unv_rn_2").value  = document.getElementById("unv_rn_2"+"_r"+inRecNum).value; 
    document.getElementById("gen_rank_2").value  = document.getElementById("gen_rank_2"+"_r"+inRecNum).value; 
    document.getElementById("ctg_rank_2").value  = document.getElementById("ctg_rank_2"+"_r"+inRecNum).value; 
    document.getElementById("stt_rank_2").value  = document.getElementById("stt_rank_2"+"_r"+inRecNum).value; 
    document.getElementById("yoa_2").value  = document.getElementById("yoa_2"+"_r"+inRecNum).value; 
    document.getElementById("prev_mark_percent").value  = document.getElementById("prev_mark_percent"+"_r"+inRecNum).value; 
    document.getElementById("domecile_ind").value  = document.getElementById("domecile_ind"+"_r"+inRecNum).value; 
    document.getElementById("org_transport_req_ind").value  = document.getElementById("org_transport_req_ind"+"_r"+inRecNum).value; 
    document.getElementById("org_hostel_req_ind").value  = document.getElementById("org_hostel_req_ind"+"_r"+inRecNum).value; 
    */
    /*
    document.getElementById("lg_0_name").value  = document.getElementById("lg_0_name"+"_r"+inRecNum).value; 
    document.getElementById("lg_0_rel_type").value  = document.getElementById("lg_0_rel_type"+"_r"+inRecNum).value; 
    document.getElementById("lg_0_address").value  = document.getElementById("lg_0_address"+"_r"+inRecNum).value; 
    document.getElementById("lg_0_phone").value  = document.getElementById("lg_0_phone"+"_r"+inRecNum).value; 
    document.getElementById("lg_1_name").value  = document.getElementById("lg_1_name"+"_r"+inRecNum).value; 
    document.getElementById("lg_1_rel_type").value  = document.getElementById("lg_1_rel_type"+"_r"+inRecNum).value; 
    document.getElementById("lg_1_address").value  = document.getElementById("lg_1_address"+"_r"+inRecNum).value; 
    document.getElementById("lg_1_phone").value  = document.getElementById("lg_1_phone"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_1").value  = document.getElementById("st_cap_attr_1"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_2").value  = document.getElementById("st_cap_attr_2"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_3").value  = document.getElementById("st_cap_attr_3"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_4").value  = document.getElementById("st_cap_attr_4"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_5").value  = document.getElementById("st_cap_attr_5"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_6").value  = document.getElementById("st_cap_attr_6"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_7").value  = document.getElementById("st_cap_attr_7"+"_r"+inRecNum).value; 
    document.getElementById("st_cap_attr_8").value  = document.getElementById("st_cap_attr_8"+"_r"+inRecNum).value; 
    document.getElementById("allergy").value  = document.getElementById("allergy"+"_r"+inRecNum).value; 
    document.getElementById("physical_disability").value  = document.getElementById("physical_disability"+"_r"+inRecNum).value; 
    document.getElementById("health_problem").value  = document.getElementById("health_problem"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_1").value  = document.getElementById("health_problem_1"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_2").value  = document.getElementById("health_problem_2"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_3").value  = document.getElementById("health_problem_3"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_4").value  = document.getElementById("health_problem_4"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_5").value  = document.getElementById("health_problem_5"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_6").value  = document.getElementById("health_problem_6"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_7").value  = document.getElementById("health_problem_7"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_8").value  = document.getElementById("health_problem_8"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_9").value  = document.getElementById("health_problem_9"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_10").value  = document.getElementById("health_problem_10"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_11").value  = document.getElementById("health_problem_11"+"_r"+inRecNum).value; 
    document.getElementById("health_problem_12").value  = document.getElementById("health_problem_12"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_1").value  = document.getElementById("enclosure_1"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_2").value  = document.getElementById("enclosure_2"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_3").value  = document.getElementById("enclosure_3"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_4").value  = document.getElementById("enclosure_4"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_5").value  = document.getElementById("enclosure_5"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_6").value  = document.getElementById("enclosure_6"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_7").value  = document.getElementById("enclosure_7"+"_r"+inRecNum).value; 
    document.getElementById("enclosure_8").value  = document.getElementById("enclosure_8"+"_r"+inRecNum).value; 
    document.getElementById("seat_num").value  = document.getElementById("seat_num"+"_r"+inRecNum).value; 
    document.getElementById("reason_for_join").value  = document.getElementById("reason_for_join"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
    document.getElementById("place_of_birth").value  = document.getElementById("place_of_birth"+"_r"+inRecNum).value; 
    */
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("adm_req_id").value  = '';
    /*
    document.getElementById("application_form_num").value  = '';
    document.getElementById("applicant_id").value  = '';
    document.getElementById("student_photo_file").value  = '';
    document.getElementById("mother_photo_file").value  = '';
    document.getElementById("father_photo_file").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("class_section").value  = '';
    */
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("student_f_name").value  = '';
    document.getElementById("student_m_name").value  = '';
    document.getElementById("student_l_name").value  = '';
    document.getElementById("dob_day").value  = '';
    document.getElementById("dob_month").value  = '';
    document.getElementById("dob_year").value  = '';
    /*
    document.getElementById("age_on_date").value  = '';
    document.getElementById("age_year").value  = '';
    document.getElementById("age_month").value  = '';
    document.getElementById("age_day").value  = '';
    document.getElementById("s_nationality").value  = '';
    document.getElementById("religion").value  = '';
    */
    document.getElementById("student_ctg").value  = '';
    document.getElementById("gender_flag").value  = '';
    /*
    document.getElementById("p_address_1").value  = '';
    document.getElementById("p_address_2").value  = '';
    document.getElementById("p_country").value  = '';
    document.getElementById("p_state").value  = '';
    document.getElementById("p_city").value  = '';
    document.getElementById("p_district").value  = '';
    document.getElementById("p_zip").value  = '';
    document.getElementById("m_address_1").value  = '';
    document.getElementById("m_address_2").value  = '';
    document.getElementById("m_country").value  = '';
    document.getElementById("m_state").value  = '';
    document.getElementById("m_city").value  = '';
    document.getElementById("m_district").value  = '';
    document.getElementById("m_zip").value  = '';
    document.getElementById("phone_list").value  = '';
    document.getElementById("email_list").value  = '';
    document.getElementById("fax_list").value  = '';
    document.getElementById("prev_org_name").value  = '';
    document.getElementById("prev_class_id").value  = '';
    document.getElementById("prev_class_num").value  = '';
    document.getElementById("prev_class_std").value  = '';
    document.getElementById("prev_class_section").value  = '';
    document.getElementById("prev_course_id").value  = '';
    document.getElementById("prev_course_term").value  = '';
    document.getElementById("prev_course_stream").value  = '';
    document.getElementById("reason_for_leaving").value  = '';
    */
    document.getElementById("father_name").value  = '';
    /*
    document.getElementById("father_age").value  = '';
    document.getElementById("f_nationality").value  = '';
    document.getElementById("father_occ_type").value  = '';
    document.getElementById("father_employer").value  = '';
    document.getElementById("father_designation").value  = '';
    document.getElementById("father_annual_income").value  = '';
    document.getElementById("f_off_address_1").value  = '';
    document.getElementById("f_phone_list").value  = '';
    document.getElementById("mother_name").value  = '';
    document.getElementById("mother_age").value  = '';
    document.getElementById("m_nationality").value  = '';
    document.getElementById("mother_occ_type").value  = '';
    document.getElementById("mother_employer").value  = '';
    document.getElementById("mother_designation").value  = '';
    document.getElementById("mother_annual_income").value  = '';
    document.getElementById("m_off_address_1").value  = '';
    document.getElementById("m_phone_list").value  = '';
    document.getElementById("divorced_flag").value  = '';
    document.getElementById("child_with").value  = '';
    document.getElementById("roll_num").value  = '';
    */
    document.getElementById("academic_session").value  = '';
    /*
    document.getElementById("adm_req_sts").value  = '';
    document.getElementById("adm_req_sts_date").value  = '';
    document.getElementById("student_id").value  = '';
    document.getElementById("scholor_num").value  = '';
    document.getElementById("form_recv_date").value  = '';
    document.getElementById("form_recv_time").value  = '';
    document.getElementById("prospectus_sale_date").value  = '';
    document.getElementById("prospectus_sale_time").value  = '';
    document.getElementById("prospectus_sold_by").value  = '';
    document.getElementById("application_form_fee").value  = '';
    document.getElementById("adm_academic_session").value  = '';
    document.getElementById("entrance_exam_date").value  = '';
    document.getElementById("entrance_exam_time_start").value  = '';
    document.getElementById("entrance_exam_time_end").value  = '';
    document.getElementById("exam_present_status").value  = '';
    document.getElementById("building_id").value  = '';
    document.getElementById("floor_num").value  = '';
    document.getElementById("room_num").value  = '';
    document.getElementById("max_mark").value  = '';
    document.getElementById("obtained_mark").value  = '';
    document.getElementById("grade").value  = '';
    document.getElementById("fee_sch_date").value  = '';
    document.getElementById("fee_deposit_date").value  = '';
    document.getElementById("online_flag").value  = '';
    document.getElementById("admission_mode").value  = '';
    document.getElementById("course_stream_1").value  = '';
    document.getElementById("course_stream_2").value  = '';
    document.getElementById("course_stream_3").value  = '';
    document.getElementById("course_stream_4").value  = '';
    document.getElementById("unv_1").value  = '';
    */
    document.getElementById("unv_rn_1").value  = '';
    document.getElementById("gen_rank_1").value  = '';
    document.getElementById("ctg_rank_1").value  = '';
    /*
    document.getElementById("stt_rank_1").value  = '';
    document.getElementById("yoa_1").value  = '';
    document.getElementById("unv_2").value  = '';
    document.getElementById("unv_rn_2").value  = '';
    document.getElementById("gen_rank_2").value  = '';
    document.getElementById("ctg_rank_2").value  = '';
    document.getElementById("stt_rank_2").value  = '';
    document.getElementById("yoa_2").value  = '';
    document.getElementById("prev_mark_percent").value  = '';
    document.getElementById("domecile_ind").value  = '';
    document.getElementById("org_transport_req_ind").value  = '';
    document.getElementById("org_hostel_req_ind").value  = '';
    */
    document.getElementById("cheque_num").value  = '';
    document.getElementById("cheque_date").value  = '';
    //document.getElementById("bank_code").value  = '';
    document.getElementById("bank_name").value  = '';
    document.getElementById("cheque_amt").value  = '';
    /*
    document.getElementById("lg_0_name").value  = '';
    document.getElementById("lg_0_rel_type").value  = '';
    document.getElementById("lg_0_address").value  = '';
    document.getElementById("lg_0_phone").value  = '';
    document.getElementById("lg_1_name").value  = '';
    document.getElementById("lg_1_rel_type").value  = '';
    document.getElementById("lg_1_address").value  = '';
    document.getElementById("lg_1_phone").value  = '';
    document.getElementById("st_cap_attr_1").value  = '';
    document.getElementById("st_cap_attr_2").value  = '';
    document.getElementById("st_cap_attr_3").value  = '';
    document.getElementById("st_cap_attr_4").value  = '';
    document.getElementById("st_cap_attr_5").value  = '';
    document.getElementById("st_cap_attr_6").value  = '';
    document.getElementById("st_cap_attr_7").value  = '';
    document.getElementById("st_cap_attr_8").value  = '';
    document.getElementById("allergy").value  = '';
    document.getElementById("physical_disability").value  = '';
    document.getElementById("health_problem").value  = '';
    document.getElementById("health_problem_1").value  = '';
    document.getElementById("health_problem_2").value  = '';
    document.getElementById("health_problem_3").value  = '';
    document.getElementById("health_problem_4").value  = '';
    document.getElementById("health_problem_5").value  = '';
    document.getElementById("health_problem_6").value  = '';
    document.getElementById("health_problem_7").value  = '';
    document.getElementById("health_problem_8").value  = '';
    document.getElementById("health_problem_9").value  = '';
    document.getElementById("health_problem_10").value  = '';
    document.getElementById("health_problem_11").value  = '';
    document.getElementById("health_problem_12").value  = '';
    document.getElementById("enclosure_1").value  = '';
    document.getElementById("enclosure_2").value  = '';
    document.getElementById("enclosure_3").value  = '';
    document.getElementById("enclosure_4").value  = '';
    document.getElementById("enclosure_5").value  = '';
    document.getElementById("enclosure_6").value  = '';
    document.getElementById("enclosure_7").value  = '';
    document.getElementById("enclosure_8").value  = '';
    document.getElementById("seat_num").value  = '';
    document.getElementById("reason_for_join").value  = '';
    document.getElementById("remark").value  = '';
    document.getElementById("place_of_birth").value  = '';
    */
    document.getElementById("adv_adm_fee").value  = '';
  }
}
