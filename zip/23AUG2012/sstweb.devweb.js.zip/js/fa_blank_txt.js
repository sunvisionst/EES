function FaBlankTxt()
{
document.getElementById("lag_id").value = "";
document.getElementById("lag_name").value = "";
}
