function EesFeeCycleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("cycle_id").value           = document.getElementById("cycle_id"+"_r"+inRecNum).value; 
    document.getElementById("cycle_start_date").value   = document.getElementById("cycle_start_date"+"_r"+inRecNum).value; 
    document.getElementById("cycle_end_date").value     = document.getElementById("cycle_end_date"+"_r"+inRecNum).value; 
    document.getElementById("cycle_prep_date").value    = document.getElementById("cycle_prep_date"+"_r"+inRecNum).value; 
    document.getElementById("cycle_print_date").value   = document.getElementById("cycle_print_date"+"_r"+inRecNum).value; 
    document.getElementById("cycle_due_date").value     = document.getElementById("cycle_due_date"+"_r"+inRecNum).value; 
    document.getElementById("planned_cycle_ind").value  = document.getElementById("planned_cycle_ind"+"_r"+inRecNum).value; 
    document.getElementById("status").value             = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("purpose").value            = document.getElementById("purpose"+"_r"+inRecNum).value; 
    document.getElementById("cycle_run_sts").value      = document.getElementById("cycle_run_sts"+"_r"+inRecNum).value; 
    document.getElementById("cycle_apr_sts").value      = document.getElementById("cycle_apr_sts"+"_r"+inRecNum).value; 

    //----------------------------------------------------------------------------------------------------
    /*
    {
      var lFeeHeadSize = document.getElementById("fee_head_size").value;
      var lStatus      = document.getElementById("status"+"_r"+inRecNum);
      var lApplicableFeeHeadObj = document.getElementById("applicable_fee_head"+"_r"+inRecNum);
      //alert(lApplicableFeeHeadObj.value);
      var lApplicableFeeHead = (document.getElementById("applicable_fee_head"+"_r"+inRecNum).value).split(',');
      var lStartIndex = 1;
      for ( lRecNum = lStartIndex; lRecNum <= lFeeHeadSize; lRecNum++ )
      {
        var lFeeHead = document.getElementById("fee_head"+"_r"+lRecNum).value;
        //alert(lFeeHead);
        for ( lRecNum1 = 0; lRecNum1 < lApplicableFeeHead.length; lRecNum1++ )
        {
          var lCheckBoxObj       = document.getElementById("ees_fee_cycle_item_select_checkbox"+lRecNum); 
          if ( lFeeHead == lApplicableFeeHead[lRecNum1] )
          {
            lCheckBoxObj.checked     = true;
            document.getElementById("ees_fee_cycle_item"+"_"+"select"+"_r"+lRecNum).value = 'Y';
            lStartIndex = lRecNum;
            break;
          }
        }
      }
      if ( lStatus && lStatus.value == 'O' )
      {
        lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      }
      else
      if ( lStatus && lStatus.value == 'A' )
      {
        lSubmitObj = document.getElementById("submit_cycle_approve"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      }
      else
      if ( lStatus && lStatus.value == 'P' )
      {
        if ( lApplicableFeeHeadObj.value.indexOf("UDF") != -1 )
          jAlert( "FEE HEAD NOT YET LINKED WITH FEE PAYMENT CYCLE "+document.getElementById("cycle_id").value, "Sunvision Alert Says" );
      }
    }
    */
    //----------------------------------------------------------------------------------------------------

    //----------------------------------------------------------------------------------------------------
    document.getElementById("cycle_id").readOnly          = true;
    document.getElementById("cycle_start_date").readOnly  = true;
    document.getElementById("cycle_end_date").readOnly    = true;
    document.getElementById("cycle_prep_date").readOnly   = true;
    document.getElementById("cycle_print_date").readOnly  = true;
    document.getElementById("cycle_due_date").readOnly    = true;
    //----------------------------------------------------------------------------------------------------
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("cycle_id").value           = '';
    document.getElementById("cycle_start_date").value   = '';
    document.getElementById("cycle_end_date").value     = '';
    document.getElementById("cycle_prep_date").value    = '';
    document.getElementById("cycle_print_date").value   = '';
    document.getElementById("cycle_due_date").value     = '';
    if ( document.getElementById("menu_option") && document.getElementById("menu_option").value == 'eesFeeCycleOther' )
      document.getElementById("planned_cycle_ind").value  = 'N';
    else
    if ( document.getElementById("menu_option") && document.getElementById("menu_option").value == 'eesFeeCyclePlanned' )
      document.getElementById("planned_cycle_ind").value  = 'Y';
    else
      document.getElementById("planned_cycle_ind").value  = '';
    document.getElementById("status").value             = '';
    document.getElementById("purpose").value            = '';
    document.getElementById("cycle_run_sts").value      = '';
    document.getElementById("cycle_apr_sts").value      = '';

    //----------------------------------------------------------------------------------------------------
    document.getElementById("cycle_id").readOnly          = true;
    document.getElementById("cycle_start_date").readOnly  = true;
    document.getElementById("cycle_end_date").readOnly    = true;
    document.getElementById("cycle_prep_date").readOnly   = true;
    document.getElementById("cycle_print_date").readOnly  = true;
    document.getElementById("cycle_due_date").readOnly    = true;
    //----------------------------------------------------------------------------------------------------
  }
}
