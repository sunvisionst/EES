function setchkNoRadioSelect()
{
  var truefalse = false
  var lRecNum   = 0;

  for(lRecNum=0; lRecNum < 2; lRecNum++)
  {
    if ( document.form1.select_radio_query[lRecNum].checked )
    {
      truefalse = true;
    }
  }
   if(!truefalse)
    {
     alert("Please Select RadioButton to continue ")
     window.event.returnValue=false;
    }
}

