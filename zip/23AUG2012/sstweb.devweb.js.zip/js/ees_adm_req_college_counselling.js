function  showApplicationFormNo()
{
  //alert(document.getElementById('select_radio_for_college_councelling').value );
  //if ( document.form.select_radio_for_cc_6.checked )
  if ( document.getElementById('select_radio_for_cc_6').checked )
  {
    document.getElementById("prospectus_account_tr").style.display= '';
    document.getElementById("application_form_tr").style.display= 'none';
  }
  else
  //if ( document.form.select_radio_for_cc_5.checked )
  if ( document.getElementById('select_radio_for_cc_5').checked )
  {
    document.getElementById("application_form_tr").style.display= 'none';
    document.getElementById("prospectus_account_tr").style.display= 'none';
  }
  else
  //if ( document.form.select_radio_for_cc_7.checked )
  if ( document.getElementById('select_radio_for_cc_7').checked )
  {
    document.getElementById("application_form_tr").style.display= '';
    document.getElementById("prospectus_account_tr").style.display= 'none';
  }
  else
  {
    ;//document.getElementById("application_form_tr").style.display= 'none';
    //document.getElementById("prospectus_account_tr").style.display= 'none';
  }
}



function  showApproveCourse()
{
  //if ( document.form.select_radio_for_cc_2.checked )
  if ( document.getElementById('select_radio_for_cc_2').checked )
  {
    document.getElementById("approved_course_tr").style.display= '';
  }
  else
  {
    document.getElementById("approved_course_tr").style.display= 'none';
  }

}
