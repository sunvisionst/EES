function EesExamQuestionRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("exam_id").value  = document.getElementById("exam_id"+"_r"+inRecNum).value; 
    document.getElementById("paper_id").value  = document.getElementById("paper_id"+"_r"+inRecNum).value; 
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value; 
    document.getElementById("question_num").value  = document.getElementById("question_num"+"_r"+inRecNum).value; 
    document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value; 
    document.getElementById("question_text").value  = document.getElementById("question_text"+"_r"+inRecNum).value; 
    document.getElementById("mandatory_flag").value  = document.getElementById("mandatory_flag"+"_r"+inRecNum).value; 
    document.getElementById("exam_term").value  = document.getElementById("exam_term"+"_r"+inRecNum).value; 
    document.getElementById("exam_type").value  = document.getElementById("exam_type"+"_r"+inRecNum).value; 
    document.getElementById("prepared_by").value  = document.getElementById("prepared_by"+"_r"+inRecNum).value; 
    document.getElementById("max_mark").value  = document.getElementById("max_mark"+"_r"+inRecNum).value; 
    document.getElementById("exam_date").value  = document.getElementById("exam_date"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("exam_id").value  = '';
    //document.getElementById("paper_id").value  = '';
    document.getElementById("seq_num").value  = '';
    document.getElementById("question_num").value  = '';
    //document.getElementById("subject_code").value  = '';
    document.getElementById("question_text").value  = '';
    document.getElementById("mandatory_flag").value  = '';
    //document.getElementById("exam_term").value  = '';
    //document.getElementById("exam_type").value  = '';
    document.getElementById("prepared_by").value  = '';
    document.getElementById("max_mark").value  = '';
    document.getElementById("exam_date").value  = '';
  }
}
