//function eesCalcSalary(inRecNum, inTotalDeduction, inPf, inIt, inAdv, inLoan)
function eesCalcDeduction( inRecNum, inHeadObj )
{

  var lTotalDeductionObj = document.getElementById("total_deduction"+"_r"+inRecNum);

  //alert(inHeadObj.value+' '+document.getElementById(inHeadObj.name+'_dummy').value);

  document.getElementById("total_deduction"+"_r"+inRecNum).value
   = parseInt(document.getElementById("total_deduction"+"_r"+inRecNum).value) 
     + ( parseInt(inHeadObj.value) - document.getElementById(inHeadObj.name+'_dummy').value);

  document.getElementById("total_deduction"+"_r"+inRecNum+"_td").innerText
   = document.getElementById("total_deduction"+"_r"+inRecNum).value;

  document.getElementById("total_salary"+"_r"+inRecNum+"_td").innerText
   = document.getElementById("total_earning"+"_r"+inRecNum+"_td").innerText
   - document.getElementById("total_deduction"+"_r"+inRecNum+"_td").innerText;

  document.getElementById(inHeadObj.name+'_dummy').value = inHeadObj.value;
}
