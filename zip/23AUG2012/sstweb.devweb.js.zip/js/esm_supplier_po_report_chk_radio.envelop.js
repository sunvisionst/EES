function chk_radio(evt)
{
  var lmnth_dt_follow_up   = "";
  var lact_close_follow_up = "";
  var lTrueFalse = true;
 
  lmnth_dt_follow_up = document.getElementById('mnth_dt_radio');
  lact_close_follow_up = document.getElementById('act_close_radio');
   

  if( lmnth_dt_follow_up != null && lmnth_dt_follow_up.value.length > 0 )
    lTrueFalse = true;
  else
    lTrueFalse = false;


  if( lact_close_follow_up != null && lact_close_follow_up.value.length > 0 )
    lTrueFalse = true;
  else
    lTrueFalse = false;


  if( !lTrueFalse ) 
  {                
    var lBrowserName = getBrowserName();
    alert('Please Select Active Or Close !!');
    if ( lBrowserName == 'Microsoft Internet Explorer' )
    {
      window.event.returnValue=false;
    }
    else 
    if ( lBrowserName == 'Netscape' )
    {
      evt.preventDefault();
      evt.stopPropagation();
    }
  }
}

