
function getCourseSemesterSection()
{
  var lSubmitObj;
  var lClassId = document.getElementById("class_id").value; 
  if( lClassId == "ETS")
  {
    document.getElementById("course_id").value           = '';
    document.getElementById("course_id_dummy").value     = '';
    document.getElementById("course_term").value           = '';
 //   document.getElementById("class_num_dummy").value     = '';
    document.getElementById("course_term_dummy").value     = '';
    document.getElementById("class_section").value       = '';
    document.getElementById("class_section_dummy").value = '';
    document.getElementById("subject_code").value        = lClassId;
    lSubmitObj = document.getElementById("subject_code"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj.value = 'ETS';
    lSubmitObj = document.getElementById("faculty_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj.value = '';
    lSubmitObj = document.getElementById("faculty_name"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj.value = '';
  }
  else
  {
    var lClassIdArray = lClassId.split('/');
    document.getElementById("course_id").value           = lClassIdArray[0];
 //   document.getElementById("course_id_dummy").value     = lClassIdArray[0];
    document.getElementById("course_term").value           = lClassIdArray[2];
    document.getElementById("class_num").value              = lClassIdArray[1];
  //  document.getElementById("course_term_dummy").value     = lClassIdArray[2];
    document.getElementById("class_section").value       = lClassIdArray[3];
 //   document.getElementById("class_section_dummy").value = lClassIdArray[3];
    document.getElementById("subject_code").value        = '';
    lSubmitObj = document.getElementById("subject_code"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("faculty_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("faculty_name"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
  }

}
