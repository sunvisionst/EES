function EsmGeneralLicenseRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("license_code").value  = document.getElementById("license_code"+"_r"+inRecNum).value; 
    //document.getElementById("license_type").value  = document.getElementById("license_type"+"_r"+inRecNum).value; 
    document.getElementById("license_num").value  = document.getElementById("license_num"+"_r"+inRecNum).value; 
    document.getElementById("license_eff_date").value  = document.getElementById("license_eff_date"+"_r"+inRecNum).value; 
    document.getElementById("license_expiry_date").value  = document.getElementById("license_expiry_date"+"_r"+inRecNum).value; 
    //document.getElementById("license_rate").value  = document.getElementById("license_rate"+"_r"+inRecNum).value; 
    //document.getElementById("usd_rate").value  = document.getElementById("usd_rate"+"_r"+inRecNum).value; 
    //document.getElementById("eu_rate").value  = document.getElementById("eu_rate"+"_r"+inRecNum).value; 
    //document.getElementById("license_status").value  = document.getElementById("license_status"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("license_code").value  = '';
    //document.getElementById("license_type").value  = '';
    document.getElementById("license_num").value  = '';
    document.getElementById("license_eff_date").value  = '';
    document.getElementById("license_expiry_date").value  = '';
    //document.getElementById("license_rate").value  = '';
    //document.getElementById("usd_rate").value  = '';
    //document.getElementById("eu_rate").value  = '';
    //document.getElementById("license_status").value  = '';
  }
}
