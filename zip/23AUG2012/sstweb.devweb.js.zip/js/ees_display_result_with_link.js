function EesDisplayResultWithLink( inRecOnPage, lRecNum)
{
  alert("pppppppppppp"+lRecNum);
  alert("paaaaaaaaaaaap"+inRecOnPage);

  var lSelectRObj = document.getElementById("select_r"+lRecNum);
  lSelectRObj.value = 'Y';
  //window.event.returnValue = false;
}

