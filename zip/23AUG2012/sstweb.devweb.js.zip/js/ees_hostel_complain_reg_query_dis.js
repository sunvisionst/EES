function  eesHostelQueryDis()
{
 document.getElementById("singlefset").style.display = '';
}
