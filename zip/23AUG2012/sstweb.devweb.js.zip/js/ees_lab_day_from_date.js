function EesLabDayFromDate()
{
   alert('Prabodh');
 // var lSubmitObj;
   // lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("__field_name__").value      = document.getElementById("__field_name__"+"_r"+inRecNum).value;
    // add other fields like above
  //  alert('value ---'+document.getElementById("sch_date").value);   //   = document.getElementById("week_day"+"_r"+inRecNum).value;
}
