function EsmSiOrderItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("si_ord_num").value  = document.getElementById("si_ord_num"+"_r"+inRecNum).value; 
    document.getElementById("item_code").value  = document.getElementById("item_code"+"_r"+inRecNum).value; 
    document.getElementById("make_id").value  = document.getElementById("make_id"+"_r"+inRecNum).value; 
    document.getElementById("req_qty").value  = document.getElementById("req_qty"+"_r"+inRecNum).value; 
    document.getElementById("issued_qty").value  = document.getElementById("issued_qty"+"_r"+inRecNum).value; 
    document.getElementById("si_order_status").value  = document.getElementById("si_order_status"+"_r"+inRecNum).value; 
    document.getElementById("si_order_status_date").value  = document.getElementById("si_order_status_date"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("si_ord_num").value  = '';
    document.getElementById("item_code").value  = '';
    document.getElementById("make_id").value  = '';
    document.getElementById("req_qty").value  = '';
    document.getElementById("issued_qty").value  = '';
    document.getElementById("si_order_status").value  = '';
    document.getElementById("si_order_status_date").value  = '';
  }
}
