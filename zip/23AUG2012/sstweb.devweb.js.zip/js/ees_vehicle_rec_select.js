function EesVehicleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //add other fields like above
    //document.getElementById("org_id").value              = document.getElementById("org_id"+"_r"+inRecNum).value;
    //document.getElementById("contract_id").value         = document.getElementById("contract_id"+"_r"+inRecNum).value;
    document.getElementById("vehicle_id").value            = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
    document.getElementById("vehicle_num").value           = document.getElementById("vehicle_num"+"_r"+inRecNum).value;
    document.getElementById("dop").value                   = document.getElementById("dop"+"_r"+inRecNum).value;
    document.getElementById("doc").value                   = document.getElementById("doc"+"_r"+inRecNum).value;
    document.getElementById("chessis_num").value           = document.getElementById("chessis_num"+"_r"+inRecNum).value;
    document.getElementById("make_id").value               = document.getElementById("make_id"+"_r"+inRecNum).value;
    document.getElementById("capacity").value              = document.getElementById("capacity"+"_r"+inRecNum).value;
    document.getElementById("vehicle_type").value          = document.getElementById("vehicle_type"+"_r"+inRecNum).value;
    document.getElementById("owner_type").value            = document.getElementById("owner_type"+"_r"+inRecNum).value;
    document.getElementById("agreement_amt").value         = document.getElementById("agreement_amt"+"_r"+inRecNum).value;
    document.getElementById("agr_start_date").value        = document.getElementById("agr_start_date"+"_r"+inRecNum).value;
    document.getElementById("agr_end_date").value          = document.getElementById("agr_end_date"+"_r"+inRecNum).value;
    document.getElementById("rt_num").value                = document.getElementById("rt_num"+"_r"+inRecNum).value;
    document.getElementById("rt_start_date").value         = document.getElementById("rt_start_date"+"_r"+inRecNum).value;
    document.getElementById("rt_end_date").value           = document.getElementById("rt_end_date"+"_r"+inRecNum).value;
    document.getElementById("insurance_num").value         = document.getElementById("insurance_num"+"_r"+inRecNum).value;
    document.getElementById("insurance_start_date").value  = document.getElementById("insurance_start_date"+"_r"+inRecNum).value;
    document.getElementById("insurance_end_date").value    = document.getElementById("insurance_end_date"+"_r"+inRecNum).value;
    document.getElementById("with_driver_ind").value       = document.getElementById("with_driver_ind"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //add other fields like above
    //document.getElementById("org_id").value          = '';
    //document.getElementById("vendor_id").value       = '';
    //document.getElementById("contract_id").value     = '';
    document.getElementById("vehicle_id").value      = '';
    document.getElementById("vehicle_num").value     = '';
    document.getElementById("dop").value             = '';
    document.getElementById("doc").value             = '';
    document.getElementById("chessis_num").value     = '';
    document.getElementById("make_id").value         = '';
    document.getElementById("capacity").value        = '';
    document.getElementById("vehicle_type").value    = '';
    document.getElementById("owner_type").value      = '';
    document.getElementById("with_driver_ind").value = '';
    document.getElementById("agreement_amt").value   = '';
    document.getElementById("agr_start_date").value  = '';
    document.getElementById("agr_end_date").value    = '';
    document.getElementById("rt_num").value          = '';
    document.getElementById("rt_start_date").value   = '';
    document.getElementById("rt_end_date").value     = '';
    document.getElementById("insurance_num").value   = '';
    document.getElementById("insurance_start_date").value  = '';
    document.getElementById("insurance_end_date").value    = '';
  }
}
