function EesFeePopOnStudentRecSelect( inSelectFlag, inRecNum, inYearQrtFlag )
{
  if ( inSelectFlag == 'Y' )
  {
    document.getElementById("submit1").disabled = false;
    document.getElementById("submit2").disabled = false;

    document.getElementById("student_id").value = document.getElementById("student_id"+"_r"+inRecNum).value;
    var lStudentCtgObj = document.getElementById('student_ctg'+"_r"+inRecNum);
    for ( var lRecNum = 1; lRecNum <= lEesFeeHeadTabObjJSArr.length; lRecNum++ )
    {
      var lDefaultAmt = 0.00;
      var lFeeHead    = '';
      var lClassStd   = '';
      if ( lEesFeeHeadTabObjJSArr[lRecNum-1].fee_flag == inYearQrtFlag )
      {
        document.getElementById("fee_head").value = lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head;
        lFeeHead  = lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head;
        lClassStd = document.getElementById("class_std"+"_r"+inRecNum).value;

        if ( inYearQrtFlag == 'Y' )
          lDefaultAmt = lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt;
        else
        if ( inYearQrtFlag == 'Q' )
          lDefaultAmt = getQrtFeeAmt( lClassStd, lFeeHead );

        document.getElementById("default_amt").value  = lDefaultAmt;
        document.getElementById("late_fee_amt").value = calcLateFeeAmt( lFeeHead, lStudentCtgObj, lDefaultAmt );
        document.getElementById("paid_amt").value     = lDefaultAmt - calcConcession( lFeeHead, lStudentCtgObj, lDefaultAmt );

        //if ( inYearQrtFlag == 'Y' )
        //{
        //  document.getElementById("year_qrt_num").value = document.getElementById('today_date').value.substring(7,12);
        //}
      }
    }
  }
  else
  {
    document.getElementById("submit1").disabled   = true;
    document.getElementById("submit2").disabled   = true;

    document.getElementById("student_id").value   = '';;
    document.getElementById("fee_head").value     = '';
    document.getElementById("default_amt").value  = '';
    document.getElementById("paid_amt").value     = '';
    document.getElementById("late_fee_amt").value = '';
    document.getElementById("year_qrt_num").value = '';
  }
}

function getQrtFeeAmt( inClassStd, inFeeHead )
{
  for ( var lRecNum = 1; lRecNum <= lEesFeeHeadClassTabObjJSArr.length; lRecNum++ )
  {
    if( lEesFeeHeadClassTabObjJSArr[lRecNum-1].fee_head == inFeeHead
     && lEesFeeHeadClassTabObjJSArr[lRecNum-1].class_std == inClassStd )
    {
      return lEesFeeHeadClassTabObjJSArr[lRecNum-1].default_amt;
    }
  }
}
