function lESM_PARAM_CONFIG_LIST_ValuesRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("parameter_name").value = document.getElementById("parameter_name"+"_r"+inRecNum).value;
    document.getElementById("parameter_value").value          = document.getElementById("parameter_value"+"_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    document.getElementById("parameter_name").value = '';
    document.getElementById("parameter_value").value          = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
