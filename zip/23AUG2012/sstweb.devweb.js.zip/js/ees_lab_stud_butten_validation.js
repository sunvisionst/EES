function EesStudButtenVld()
{
  if(document.getElementById("course_id").value  == '' && document.getElementById("class_num").value  == '' && document.getElementById("class_section").value  == '' ) 
  {
    alert("Select Course,Semester And Section To Continue ");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  == '' && document.getElementById("class_num").value  == '' && document.getElementById("class_section").value  != '')
  {
    alert("Select Course and Semester To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  == '' && document.getElementById("class_num").value  != '' && document.getElementById("class_section").value  == '')
  {
    alert("Select Course and Section  To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  != '' && document.getElementById("class_num").value  == '' && document.getElementById("class_section").value  == '')
  {
    alert("Select Semester and Section To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  != '' && document.getElementById("class_num").value  != '' && document.getElementById("class_section").value  == '')
  {
    alert("Select Section To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  != '' && document.getElementById("class_num").value  == '' && document.getElementById("class_section").value  != '')
  {
    alert("Select Semester To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("course_id").value  == '' && document.getElementById("class_num").value  != '' && document.getElementById("class_section").value  != '')
  {
    alert("Select Course To Continue");

    window.event.returnValue = false;
  }


}
