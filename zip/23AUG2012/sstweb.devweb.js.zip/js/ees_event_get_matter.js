function get_event_matter( inDestFieldId, inOrgId, inEventId, inTextareaInd )
{
  for ( ;; )
  {
    gAlertShowInd = true;
    //var lEventId   = document.getElementById('event_id').value;
    var lWhereText = '';
    //lWhereText += ' org_id= \\''+inOrgId+'\\'  ';
    //lWhereText += ' and event_id= \\''+lEventId+'\\'  ';
    //alert('inDestFieldId,inOrgId,inEventId,inTextareaInd'+inDestFieldId+' '+inOrgId+' '+inEventId+' '+inTextareaInd);
    invokeRefreshField
    ( lWhereText
    , 'ees_event'
    , 'get_event_matter'
    , 'EVENT_MATTER'
    , inDestFieldId
    , 'option'
    //, 'HTML&others=oth&param_org_id='+inOrgId+'&param_event_id='+inEventId+'&param_textarea_ind='+inTextareaInd
    , 'TAHE&others=oth&param_org_id='+inOrgId+'&param_event_id='+inEventId+'&param_textarea_ind='+inTextareaInd
    );
    break;
  }
  return gResultText;
}
