function BlankCr()
{   
  document.getElementById("cr_ag_id").value        = '';
  document.getElementById("cr_lag_id").value       = '';
  document.getElementById("cr_account_num").value  = '';
}
function BlankDr()
{  
  if (  document.getElementById("dr_account_num") != null ) 
  {
    document.getElementById("dr_lag_id").disabled       = false;
    document.getElementById("dr_ag_id").disabled  = false;
  }
    document.getElementById("dr_ag_id").value        = '';
    document.getElementById("dr_lag_id").value       = '';
    document.getElementById("dr_account_num").value  = '';
}
function MakeDisableCr()
{
  if (document.getElementById("cr_account_num") != null && document.getElementById("cr_account_num").value.length > 0)
  {
    document.getElementById("cr_ag_id").disabled     = true;
    document.getElementById("cr_lag_id").disabled    = true;
    //alert('true');
  }
  else
  {
    document.getElementById("cr_ag_id").disabled       = false;
    document.getElementById("cr_lag_id").disabled      = false;
   // alert('false');
  }
}
function MakeDisableDr()
{
  if ( document.getElementById("dr_account_num") != null)
  {
    document.getElementById("dr_ag_id").disabled       = true;
    document.getElementById("dr_lag_id").disabled  = true;
  }
  else
  {
     document.getElementById("dr_ag_id").disabled   = false;
     document.getElementById("dr_lag_id").disabled  = false;
  }
}
function DisableRevert()
{
   document.getElementById("cr_ag_id").disabled       = false;
   document.getElementById("cr_lag_id").disabled  = false;
   document.getElementById("dr_ag_id").disabled       = false;
   document.getElementById("dr_lag_id").disabled  = false;
}
