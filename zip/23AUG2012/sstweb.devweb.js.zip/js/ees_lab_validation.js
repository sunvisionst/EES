function EesLabValidation( i, TotalRecord, lName, lStudentId, lBarcodeNo)
{
    var j;
    j = i;
    if( j = 0)
    {
       var lNameArr      = new Array();
       var lStudentIdArr = new Array();
       var lBarcodeNoArr = new Array();
    }    
    lNameArr[i]      = lName;
    lStudentIdArr[i] = lStudentId;
    lStudentIdArr[i] = lBarcodeNo;

//  var lRoomNum      = document.getElementById("room_num").value;
//  var lExamDate     = document.getElementById("exam_date").value;
//  var lExamId       = document.getElementById("exam_id").value;
//  var lClassNum     = document.getElementById("class_num").value;
//  var lClassSection = document.getElementById("class_section").value;
//  var lSubjectCode  = document.getElementById("subject_code").value;
//  var selected_row = 0 ;
 // alert("At the Number"+inRecNum);
// for( var i = 1; i <= TotalRow ; i++ )
// {
//   if( document.form.select_radio[i-1].checked)
//   {
 //    selected_row = i ;
 //    break;
 //  }
// }
 
  alert("Selected Row :-  "+lNameArr[0]);
/*
  //---------------------------------------------------------
  // Code for change Date format from 31-Oct-2006 to 20061031
  //--------------------------------------------------------- 
  var lExamDateArray = lExamDate.split('-');
  if(lExamDateArray[1]== 'Jan')
    lExamDateArray[1] = '01';
  if(lExamDateArray[1]== 'Feb')
    lExamDateArray[1] = '02';
  if(lExamDateArray[1]== 'Mar')
    lExamDateArray[1] = '03';
  if(lExamDateArray[1]== 'Apr')
    lExamDateArray[1] = '04';
  if(lExamDateArray[1]== 'May')
    lExamDateArray[1] = '05';
  if(lExamDateArray[1]== 'Jun')
    lExamDateArray[1] = '06';
  if(lExamDateArray[1]== 'Jul')
    lExamDateArray[1] = '07';
  if(lExamDateArray[1]== 'Aug')
    lExamDateArray[1] = '08';
  if(lExamDateArray[1]== 'Sep')
    lExamDateArray[1] = '09';
  if(lExamDateArray[1]== 'Oct')
    lExamDateArray[1] = '10';
  if(lExamDateArray[1]== 'Nov')
    lExamDateArray[1] = '11';
  if(lExamDateArray[1]== 'Dec')
    lExamDateArray[1] = '12';
  lExamDate = lExamDateArray[2]+lExamDateArray[1]+lExamDateArray[0];
 // alert("At the Date"+lExamDate);
  //-------------------------------------------------------------
  // End Code for change Date format from 31-Oct-2006 to 20061031
  //-------------------------------------------------------------
*/
}
