function EesAcademicSessionRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("academic_session").value      = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("org_id").value                = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("start_date").value            = document.getElementById("start_date"+"_r"+inRecNum).value; 
    document.getElementById("end_date").value              = document.getElementById("end_date"+"_r"+inRecNum).value;
    document.getElementById("academic_session_sts").value  = document.getElementById("academic_session_sts"+"_r"+inRecNum).value;
    if ( document.getElementById("org_ctg").value == 'I' )
    {
      document.getElementById("semester_start_date").value   = document.getElementById("semester_start_date"+"_r"+inRecNum).value; 
      document.getElementById("semester_end_date").value     = document.getElementById("semester_end_date"+"_r"+inRecNum).value;
    }
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value             = '';
    document.getElementById("academic_session").value          = '';
    document.getElementById("org_id").value                    = '';
    document.getElementById("start_date").value                = '';
    document.getElementById("end_date").value                  = '';
    document.getElementById("academic_session_sts").value      = '';
    if ( document.getElementById("org_ctg").value == 'I' )
    {
      document.getElementById("semester_start_date").value       = '';
      document.getElementById("semester_end_date").value         = '';
    }
  }
}
