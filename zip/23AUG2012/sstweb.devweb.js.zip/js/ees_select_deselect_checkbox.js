function selectAll(inArrSize)
{
  if(document.getElementById("selectAllCheckbox").checked)
  {
    for(lRecNum  = 1;lRecNum<= inArrSize;lRecNum++)
    { 
      document.getElementById("select_checkbox"+lRecNum).checked = true;
      document.getElementById("select_r"+lRecNum).value = 'Y';
    }
  }
  else
  {
    for(lRecNum  = 1;lRecNum<= inArrSize;lRecNum++)
    { 
      document.getElementById("select_checkbox"+lRecNum).checked = false;
      document.getElementById("select_r"+lRecNum).value = 'N';
    }
  }
}
