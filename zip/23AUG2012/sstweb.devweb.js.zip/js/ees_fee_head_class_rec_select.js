function EesFeeHeadClassRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    if ( document.getElementById('org_ctg').value == 'I' )
    {
      var lCourseIdListNoStreamObj = document.getElementById('course_id_list_no_stream_str');
      var lCourseIdObj = document.getElementById("course_id");
      lCourseIdObj.value  = document.getElementById("course_id"+"_r"+inRecNum).value;
      if ( lCourseIdListNoStreamObj && ( lCourseIdListNoStreamObj.value.indexOf(lCourseIdObj.value) != -1 ) )
        document.getElementById("course_stream_value_div").style.display='none';
      else
      {
        document.getElementById("course_stream_value_div").style.display='';
        {
          gSelectedValue = document.getElementById("course_stream"+"_r"+inRecNum).value;
          var lOrgId = document.getElementById('org_id').value;
          var lCourseId = document.getElementById('course_id').value;
          var lWhereText ='';
          lWhereText += ' org_id =\''+lOrgId+'\'';
          lWhereText += ' and course_id=\''+lCourseId+'\'' ;
          invokeRefreshField( lWhereText, 'ees_fee_head_class', 'get_course_stream'
                            , 'COURSE_STREAM,DESCRIPTION'
                            , 'course_stream'
                            , 'option', 'SELECT' );
        }
      }
      
      document.getElementById("course_term").value      = document.getElementById("course_term"+"_r"+inRecNum).value;
    }

    var lClassNumObj = document.getElementById("class_num");
    lClassNumObj.value = document.getElementById("class_num"+"_r"+inRecNum).value;
    if ( document.getElementById('org_ctg').value == 'S' )
    {
      var lClassNumListStreamObj = document.getElementById('class_num_list_stream_str');
      if ( lClassNumListStreamObj && ( lClassNumListStreamObj.value.indexOf(lClassNumObj.value) != -1 ) )
        document.getElementById("course_stream").value      = document.getElementById("course_stream"+"_r"+inRecNum).value;
      else
        document.getElementById("course_stream").value      = '';

      var lCourseStreamObj = document.getElementById("course_stream"+"_r"+inRecNum);
      if ( lCourseStreamObj != null && lCourseStreamObj.value == 'NA' )
      {
        document.getElementById("course_stream_value_div").style.display='none';
      }
      else
      {
        document.getElementById("course_stream_value_div").style.display='';
      }
    }

    document.getElementById("course_stream").value    = document.getElementById("course_stream"+"_r"+inRecNum).value;
    document.getElementById("default_amt").value      = document.getElementById("default_amt"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;


    if ( document.getElementById('org_ctg').value == 'I' )
    {
      document.getElementById("course_id").value        = '';
      document.getElementById("course_term").value      = '1';
    }
    document.getElementById("course_stream_value_div").style.display='none';
    document.getElementById("course_stream").value    = '';
    document.getElementById("class_num").value        = '1';
    document.getElementById("default_amt").value      = '';
  }
}
