function FaGlAccountEnableDisable()
{
  if(document.getElementById("account_num").value == '')
  { 
  //alert("Account value Null"); 
    document.getElementById("ag_id").disabled = true;
    document.getElementById("lag_id").disabled = true;
    document.getElementById("head_type").disabled = true;
    document.getElementById("sl_ind").disabled = true;
    document.getElementById("sl_type").disabled = true;
    document.getElementById("bal_close_cm").disabled = true;
    document.getElementById("bal_open_cm").disabled = true;
  //alert("Disabling successfull"); 
  }
  else
//  if(document.getElementById("account_num").value != '') 
  {
  //alert("Account value not Null"); 
    document.getElementById("ag_id").disabled = false;
    document.getElementById("lag_id").disabled = true;
    document.getElementById("head_type").disabled = true;
    document.getElementById("sl_ind").disabled = true;
    document.getElementById("sl_type").disabled = false;
    document.getElementById("bal_close_cm").disabled = false;
    document.getElementById("bal_open_cm").disabled = false;
 
  }
 
  if(document.getElementById("ag_id").value != '')
  {
  //alert("Ag_id value not Null"); 
    document.getElementById("lag_id").disabled = false;
    document.getElementById("head_type").disabled = false;
    document.getElementById("sl_ind").disabled = false;

  }

}
