function EesSubjectAllocationRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value             = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("employee_id").value        = document.getElementById("employee_id"+"_r"+inRecNum).value;
    document.getElementById("class_id").value           = document.getElementById("class_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value          = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_section").value      = document.getElementById("class_section"+"_r"+inRecNum).value;
    document.getElementById("subject_code").value       = document.getElementById("subject_code"+"_r"+inRecNum).value;
    document.getElementById("course_id").value          = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value        = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("class_std").value          = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("load_point").value         = document.getElementById("load_point"+"_r"+inRecNum).value;
    document.getElementById("planned_lect_num").value   = document.getElementById("planned_lect_num"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value             = '';
    document.getElementById("employee_id").value        = '';
    document.getElementById("class_id").value           = '';
    document.getElementById("class_num").value          = '';
    document.getElementById("class_section").value      = '';
    document.getElementById("subject_code").value       = '';
    document.getElementById("course_id").value          = '';
    document.getElementById("course_term").value        = '';
    document.getElementById("class_std").value          = '';
    document.getElementById("load_point").value         = '';
    document.getElementById("planned_lect_num").value   = '';
  }
}
