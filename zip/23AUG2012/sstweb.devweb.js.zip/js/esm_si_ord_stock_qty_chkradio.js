function chkRadio(event)
{
  var lRadio1 = document.getElementById("radio_select_1").checked;
  var lRadio2 = document.getElementById("radio_select_2").checked;
  var lRadio3 = document.getElementById("radio_select_3").checked;
  if(lRadio1 == false && lRadio2 == false && lRadio3 == false)
  {
    alert("Please Select RadioButton to continue ")
    var lBrowserName = getBrowserName();
    if ( lBrowserName == 'Microsoft Internet Explorer' )
      window.event.returnValue=false;
    else
    if ( lBrowserName == 'Netscape' )
    {
       event.preventDefault();
       event.stopPropagation();
    }
  }
}

