function EesStudentFeeRecSelect( inSelectFlag, inRecNum)
{
  if ( inSelectFlag == 'Y' )
  {
    //document.getElementById("submit1").disabled = false;
    //document.getElementById("submit2").disabled = false;

    document.getElementById("student_id").value = document.getElementById("student_id"+"_r"+inRecNum).value;
    //document.getElementById("fee_head").value = document.getElementById("fee_head"+"_r"+inRecNum).value;
    //document.getElementById("year_qrt_num").value = document.getElementById("year_qrt_num"+"_r"+inRecNum).value;
    //document.getElementById("fee_flag").value = document.getElementById("fee_flag"+"_r"+inRecNum).value;
    //document.getElementById("dop").value = document.getElementById("dop"+"_r"+inRecNum).value;
    //document.getElementById("default_amt").value = document.getElementById("default_amt"+"_r"+inRecNum).value;
    //document.getElementById("late_fee_amt").value = document.getElementById("late_fee_amt"+"_r"+inRecNum).value;
    //document.getElementById("paid_amt").value = document.getElementById("paid_amt"+"_r"+inRecNum).value;
  }
  else
  {
    //document.getElementById("submit1").disabled = true;
    //document.getElementById("submit2").disabled = true;

    document.getElementById("student_id").value = "";
    document.getElementById("fee_head").value = "";
    //document.getElementById("year_qrt_num").value = "";
    //document.getElementById("fee_flag").value = "";
    //document.getElementById("dop").value = "";
    document.getElementById("default_amt").value = "";
    document.getElementById("late_fee_amt").value = "";
    document.getElementById("paid_amt").value = "";
  }
}
