function eesCalcSalary(inRecNum, inTotalEarning, inTotalDeduction, inDimObj, inPdObj)
{

  //alert('inTotalSalary '+ inTotalEarning + ' '+ inDimObj.value + ' '+ inPdObj.value);
  //alert('inTotalDeduction '+ inTotalDeduction + ' '+ inDimObj.value + ' '+ inPdObj.value);

  if ( inPdObj.value > inDimObj.value )
  {
    alert('Number of days present cannot be more than Total no. of days in a month!!');
    document.getElementById("income_amt"+"_r"+inRecNum).value = "";
    document.getElementById("deduction_amt"+"_r"+inRecNum).value = "";
    document.getElementById("actual_salary"+"_r"+inRecNum).value = "";
  }
  else
  {
    var lTotalEarning = (inTotalEarning/inDimObj.value)*inPdObj.value;
    document.getElementById("income_amt"+"_r"+inRecNum).value = lTotalEarning;
    var lTotalDeduction = (inTotalDeduction/inDimObj.value)*inPdObj.value;
    document.getElementById("deduction_amt"+"_r"+inRecNum).value = lTotalDeduction;

    if ( lTotalEarning > lTotalDeduction )
      document.getElementById("actual_salary"+"_r"+inRecNum).value = lTotalEarning - lTotalDeduction;
    else
      document.getElementById("actual_salary"+"_r"+inRecNum).value = 0.00;


    document.getElementById("select_checkbox"+inRecNum).checked = true ;
    document.getElementById("select_r"+inRecNum).value = 'Y'  ;
    
   }
}
