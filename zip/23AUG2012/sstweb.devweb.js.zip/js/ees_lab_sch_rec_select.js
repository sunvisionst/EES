function EesLabSchRecSelect( inSelectFlag, inRecNum)
{
 // alert('ttttt'+inSelectFlag);
 // alert('ttttt'+inRecNum);
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value         = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("lab_id").value         = document.getElementById("lab_id"+"_r"+inRecNum).value;
    document.getElementById("faculty_name").value   = document.getElementById("faculty_name"+"_r"+inRecNum).value;
    document.getElementById("assistant_name").value = document.getElementById("assistant_name"+"_r"+inRecNum).value;
    //document.getElementById("assistant_id").value   = document.getElementById("assistant_id"+"_r"+inRecNum).value;
    document.getElementById("week_day").value       = document.getElementById("week_day"+"_r"+inRecNum).value;
    document.getElementById("sch_date").value       = document.getElementById("sch_date"+"_r"+inRecNum).value;
    //document.getElementById("course_id").value      = document.getElementById("course_id"+"_r"+inRecNum).value;
    //document.getElementById("class_num").value      = document.getElementById("class_num"+"_r"+inRecNum).value;
    //document.getElementById("course_term").value      = document.getElementById("course_term"+"_r"+inRecNum).value;

    document.getElementById("session_id").value     = document.getElementById("session_id"+"_r"+inRecNum).value;
    document.getElementById("sch_time_from").value  = document.getElementById("sch_time_from"+"_r"+inRecNum).value;
    document.getElementById("session_type").value   = document.getElementById("session_type"+"_r"+inRecNum).value;
    if((document.getElementById("session_type").value) == 'X')
    {
     document.getElementById("roll_num_start").value  = document.getElementById("roll_num_start"+"_r"+inRecNum).value;
     document.getElementById("roll_num_end").value  = document.getElementById("roll_num_end"+"_r"+inRecNum).value;
    }
    document.getElementById("sch_time_to").value    = document.getElementById("sch_time_to"+"_r"+inRecNum).value;
    //document.getElementById("subject_code").value   = document.getElementById("subject_code"+"_r"+inRecNum).value;
    //document.getElementById("faculty_id").value     = document.getElementById("faculty_id"+"_r"+inRecNum).value;
    document.getElementById("class_id").value       = document.getElementById("class_id"+"_r"+inRecNum).value;
    //document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value      = '';
    // add other fields like above
    //document.getElementById("org_id").value               = '';
    //document.getElementById("lab_id").value               = '';
    document.getElementById("week_day").value             = '';
    //document.getElementById("week_day"+"_dummy").value    = '';
    //document.getElementById("assistant_id").value         = '';
    document.getElementById("sch_date").value             = '';
    document.getElementById("session_id").value           = '';
    if((document.getElementById("session_type").value) == 'X')
    {
     document.getElementById("roll_num_start").value  = '';
     document.getElementById("roll_num_end").value  = '';
    }
    document.getElementById("session_type").value         = '';
    //document.getElementById("sch_time_from").value        = '';
    //document.getElementById("sch_time_to").value          = '';
    //document.getElementById("course_id").value            = '';
    //document.getElementById("class_num").value            = '';
    //document.getElementById("course_term").value            = '';
    //document.getElementById("class_num"+"_dummy").value   = '';
    //document.getElementById("subject_code").value         = '';
    //document.getElementById("faculty_id").value           = '';
    document.getElementById("faculty_name").value         = '';
    document.getElementById("assistant_name").value       = '';
    document.getElementById("class_id").value             = '';
    //document.getElementById("class_section").value        = '';
    //document.getElementById("class_section"+"_dummy").value  = '';
    //document.getElementById("course_id"+"_dummy").value   = '';
    //document.getElementById("course_term"+"_dummy").value   = '';

  }
}
function EesLabSchRecSelectWithTO( inSelectFlag, inRecNum)
{
 setTimeout("EesLabSchRecSelect( \""+inSelectFlag+"\", \""+inRecNum+"\" );" , 50);
 
}
