
function enableButtonByRadio( inRecOnPage, inLocRefRecStr , lRecOnPageRecStr )
{
    var lFlag = false;
    var lFlagBox = false;
    var lBreakNum = "";
    for(var i=1; i<= inRecOnPage; i++)
    {
       var lSelect = document.getElementById("select_r"+i);
       if ( lSelect.value == 'Y' )
         lFlag = true;
    }

    if ( lFlag )
    {
      alert("Please Deselect radio before");
      var lCount = 0;
      for(var i=1; i<= inRecOnPage; i++)
      {
        var lSubmit       = document.getElementById("submit_r"+i);
        var lNumber = inLocRefRecStr.charAt(i-1);
        for(var j=1; j<= lNumber; j++)
        {
          var inRecNum = lRecOnPageRecStr.charAt(lCount);
          lCount = lCount + 1;
          for(var k=1; k<= inRecNum; k++)
          {
            var lSelectChkBox = document.getElementById("select_checkbox"+i+j+k);

            if (lSelectChkBox.checked )
            {
              lSelectChkBox.checked = false;
              var lSelectR = document.getElementById("select_r"+i+j+k);
              lSelectR.value   = 'N';
            }
          }
        }
      }
    }
    else
    { 
      var lCount = 0;
      for(var i=1; i<= inRecOnPage; i++)
      {
        var lSubmit       = document.getElementById("submit_r"+i);
        var lNumber = inLocRefRecStr.charAt(i-1);
        for(var j=1; j<= lNumber; j++)
        {
          var inRecNum = lRecOnPageRecStr.charAt(lCount);
          lCount = lCount + 1;
          for(var k=1; k<= inRecNum; k++)
          {
            var lSelectChkBox = "";
            lSelectChkBox     = document.getElementById("select_r"+i+j+k);

            if (lSelectChkBox.value == 'Y')
            {
              lFlagBox = true;
              lBreakNum = i+''+j;
              break;
            }  
            else
            {
              lFlagBox = false;
            //break;
            }
          if ( lFlagBox )
            break;
        }
        if ( lFlagBox )
          break;
        }
        if ( lFlagBox )
          break;
      }

      if ( lFlagBox )
      {
        var lSelectChkBox = "";
        for ( var i = 0;i < inRecOnPage+1;i++ )
        {
          var lSelectRadio       = document.getElementById("select_radio"+i);
          lSelectRadio.disabled = true;
        } 

        var lCount = 0;
        for ( var i = 1;i <= inRecOnPage;i++ )
        {
          var lNumber = inLocRefRecStr.charAt(i-1);

          for(var j=1; j<= lNumber; j++)
          {
            var inRecNum = lRecOnPageRecStr.charAt(lCount);
            lCount = lCount + 1; 
            for(var k=1; k<= inRecNum; k++)
            {
              lSelectChkBox = document.getElementById("select_checkbox"+i+j+k);
              if (lBreakNum != i+''+j)
                lSelectChkBox.disabled = true;
              else
                lSelectChkBox.disabled = false;
            }
          }
        }

        lSubmit.disabled = false;
      }
      else
      {
        var lSelectChkBox = "";
        for ( var i = 0;i < inRecOnPage+1;i++ )
        {
          var lSelectRadio       = document.getElementById("select_radio"+i);
          lSelectRadio.disabled = false;
        }

        var lCount = 0;
        for ( var i = lBreakNum+1;i <= inRecOnPage;i++ )
        {
          var lNumber = inLocRefRecStr.charAt(i-1);

          for(var j=1; j<= lNumber; j++)
          {
            var inRecNum = lRecOnPageRecStr.charAt(lCount);
            lCount = lCount + 1;
            for(var k=1; k<= inRecNum; k++)
            {
              lSelectChkBox = document.getElementById("select_checkbox"+i+j+k);
              lSelectChkBox.disabled = false;
            }
          }
        }
        

        for ( var i = 1;i <= inRecOnPage;i++ )
        {
            var lSubmit      = document.getElementById("submit_r"+i); 
            lSubmit.disabled = true;
        }
      }

    }
}
