
function chkNoValueEnteredByIdDs(inId)
{
  var lId   = inId ;
  var lObj  = document.getElementById(lId);

  if (lObj.value == "")
  {
   alert("Please enter a value to continue.");
   //window.event.returnValue=false;
   
  }
}
