function select_source( inRow , inRecNum , inArrsize )
{
   var lQtyDispatch = document.getElementById("qty_dispatch_r"+inRow);

   var lSelectCheckBox     = document.getElementById("select_checkbox"+inRow+""+inRecNum);          
   var lSelectR            = document.getElementById("select_r"+inRow+""+inRecNum);          
   var lStockQty           = document.getElementById("act_finish_stock_qty_r"+inRow+""+inRecNum);          
   var lStockQtyDummy      = document.getElementById("act_finish_stock_qty_r"+inRow+""+inRecNum+"_dummy");          
   var lSupplierQty        = document.getElementById("supplier_qty_r"+inRow+""+inRecNum);          
   var lSupplierQtyDummy   = document.getElementById("supplier_qty_r"+inRow+""+inRecNum+"_dummy");          
   //var lBalQty             = document.getElementById("bal_qty_r"+inRow+""+inRecNum);          
   //var lBalQtyDummy        = document.getElementById("bal_qty_r"+inRow+""+inRecNum+"_dummy");          
   var lStockBlockQty      = document.getElementById("blk_finish_stock_qty_r"+inRow+""+inRecNum);          
   var lStockBlockQtyDummy = document.getElementById("blk_finish_stock_qty_r"+inRow+""+inRecNum+"_dummy");          

   var lItemBalQty         = document.getElementById("item_bal_qty_r"+inRow);          

   var lQD = parseInt(lQtyDispatch.value);
   var lSQ = parseInt(lStockQty.value);
   var lIBQ = parseInt(lItemBalQty.value);
   var lSBQ = parseInt(lStockBlockQty.value);
 
   //-----------------------------ITEM ORDER COMPLETED STARTS---------------------------

   var cDisableCheckBox = 0;
   var lSupCheckBox = document.getElementById("select_checkbox"+inRow+""+inRecNum);
   if ( lSupCheckBox.value =='Y' )
   {
     for ( var lCntr = 1; lCntr <= inArrsize; lCntr++ )
     {
       var cSelectR     = document.getElementById("select_r"+inRow+""+lCntr);          
       if ( cSelectR.value == 'Y'  )
       {
         var lSupQty      = document.getElementById("supplier_qty_r"+inRow+""+lCntr);
         if ( lSupQty.value != ""  )
          cDisableCheckBox = cDisableCheckBox + parseInt(lSupQty.value); 
       }
     }
     if ( lQD == cDisableCheckBox )
     {
       var cSelectR      = document.getElementById("select_r"+inRow+""+inRecNum);          
       cSelectR.value    = "N"; 
     
       var lSupCheckBox = document.getElementById("select_checkbox"+inRow+""+inRecNum);
       lSupCheckBox.checked = false;
       alert ( " Ordered Item Qty is Completed " );
     }
   }

   //-----------------------------ITEM ORDER COMPLETED ENDS---------------------------

   var lValue = lSelectR.value;
   
   if ( lSQ == 0 )
   {
     alert ("Item are not in stock" );
   }
   else
   if ( lValue == 'Y' )
   { 
     if ( ( lSBQ < lSQ ) || ( lSBQ == 0) )
     {
       if ( (lSQ - lSBQ) >= lIBQ  )
       {
         alert ( "lSQ >= lIBQ" );
         var lSupQty                = lIBQ;
         lSupplierQty.value         = lSupQty;
         lSupplierQtyDummy.value    = lSupQty;
 
         //var lBQty                  = 0; 
         //lBalQty.value              = lBQty;
         //lBalQtyDummy.value         = lBQty;
          lItemBalQty.value          = 0;
 
          var lStkBlkQty             = parseInt(lStockBlockQty.value) + lIBQ;
          lStockBlockQty.value       = lStkBlkQty;
          lStockBlockQtyDummy.value  = lStkBlkQty;;
       }
       else
       if ( (lSQ - lSBQ) < lIBQ  )
       {
          //alert ( "lSQ < lIBQ" );
          var lSupQty                = lSQ - lSBQ;
          lSupplierQty.value         = lSupQty;
          lSupplierQtyDummy.value    = lSupQty;
 
          //var lBQty                  = lIBQ - lSQ; 
          //lBalQty.value              = lBQty;
          //lBalQtyDummy.value         = lBQty;
 
          lItemBalQty.value          = lIBQ - ( lSQ - lSBQ );
 
          var lStkBlkQty             = parseInt(lStockBlockQty.value) + ( lSQ - lSBQ );
          lStockBlockQty.value       = lStkBlkQty;
          lStockBlockQtyDummy.value  = lStkBlkQty;;
       }
     }
     else
     {
       var cSelectR      = document.getElementById("select_r"+inRow+""+inRecNum);          
       cSelectR.value    = "N"; 
     
       var lSupCheckBox = document.getElementById("select_checkbox"+inRow+""+inRecNum);
       lSupCheckBox.checked = false;
        alert (" All Items are blocked in Stock");
     }
   }
   else
   if ( lValue == 'N' )
   {
      var lStBlkQty = 0;
      if ( lStockBlockQty.value != null && lStockBlockQty.value.length > 0  )
        lStBlkQty = parseInt(lStockBlockQty.value);
 
      var lSpQty = 0;
      if ( lSupplierQty.value != null && lSupplierQty.value.length > 0  )
        lSpQty = parseInt(lSupplierQty.value); 
 
      var lStkBlkQty             = lStBlkQty - lSpQty;
 
      lItemBalQty.value = parseInt( lItemBalQty.value ) + lSpQty;
 
      var lSupQty                = 0; 
      lSupplierQty.value         = lSupQty;
      lSupplierQtyDummy.value    = lSupQty;

      //var lBQty                  = 0; 
      //lBalQty.value              = lBQty;
      //lBalQtyDummy.value         = lBQty;

      lStockBlockQty.value       = lStkBlkQty;
      lStockBlockQtyDummy.value  = lStkBlkQty;;
   }
}
