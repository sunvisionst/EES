function selectCountry( inDomesticCountry, inFieldName, inCountryCode )
{
      var lFieldName   = document.getElementById(inFieldName);
      var lCountryCode = document.getElementById(inCountryCode);
      if ( lFieldName.value != 'D' && ( inDomesticCountry == lCountryCode.value ))
      {
        alert("Please Fill fill foreign country ");
        lCountryCode.value = "";
        //lCountryCode.focus();
      }
      else
      if ( lFieldName.value == 'D' && ( inDomesticCountry != lCountryCode.value ))
      {
        alert("Please Fill fill domestic country ");
        lCountryCode.value = "";
      }
}
