
function getId(inDelimiter)
{
   var lSelectedValue = document.form.select_currency.value;
   var lCurrencyValue = lSelectedValue.substring(lSelectedValue.indexOf("#value=")+7);
   document.form.currency_value.value=lCurrencyValue;
}
