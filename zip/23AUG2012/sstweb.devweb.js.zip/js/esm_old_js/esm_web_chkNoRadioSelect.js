
function setenqchkNoRadioSelect()
{
  var truefalse = false
  var lRecNum   = 0;

  for(lRecNum=0; lRecNum < 3; lRecNum++)
  {
    if ( document.form.select_radio[lRecNum].checked )
    {
      truefalse = true;
    }
  }
   if(!truefalse)
    {
     alert("Please Select RadioButton to continue ")
     window.event.returnValue=false;
    }
}
