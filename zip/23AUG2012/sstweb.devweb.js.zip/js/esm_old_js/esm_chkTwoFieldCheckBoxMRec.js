function chkTwoFieldCheckBox(inRecOnPage,inFirstField,inSecondField)
{
  var truefalse = false;
  var lCheckBoxObjId;

  var lFirstField  = inFirstField;
  var lSecondField = inSecondField;

  lFirstField  = lFirstField+"_r";
  lSecondField = lSecondField+"_r";

  window.event.returnValue=true;
  for(var lNumRec=1; lNumRec<=(inRecOnPage); lNumRec++)
  {

    lCheckBoxObjId = document.getElementById("select_checkbox"+lNumRec);
    if ( lCheckBoxObjId.checked )
    {
      lFirstFieldObj  = document.getElementById(lFirstField+lNumRec);
      lSecondFieldObj = document.getElementById(lSecondField+lNumRec);
      if ( (lFirstFieldObj.value == "") || ( lFirstFieldObj.value != "" && parseInt(lFirstFieldObj.value) == 0 ))
      {
        if ( ( lSecondFieldObj.value == "" ) || ( lSecondFieldObj.value != "" && parseInt(lSecondFieldObj.value) == 0 ))
        {
          alert("Please fill "+ inFirstField+" and "+ inSecondField+" > 0 in row "+lNumRec);
          window.event.returnValue=false;
        }
        else
        {
          alert("Please fill "+ inFirstField+" > 0 in row "+lNumRec);
          window.event.returnValue=false;
        }
      }  
      else
      {
        if ( ( lSecondFieldObj.value == "") || ( lSecondFieldObj.value != "" && parseInt(lSecondFieldObj.value) == 0 ))
        {
          alert("Please fill "+ inSecondField+" > 0 in row "+lNumRec);
          window.event.returnValue=false;
        }
      }
    }
  }

}
