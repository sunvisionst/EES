function disablePAcntName(inAL,inPAN )
{
  var lAL   = inAL ;
  var lObjAL  = document.getElementById(lAL);

  var lPAN  = inPAN ;
  var lObjPAN  = document.getElementById(lPAN);

  if (lObjAL.value == 0 )
  {
    lObjPAN.disabled = true;
  }
  else 
  {
   lObjPAN.disabled = false;
  }
}
