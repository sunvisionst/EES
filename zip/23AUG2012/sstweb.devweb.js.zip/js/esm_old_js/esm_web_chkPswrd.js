function webchkPswrd( inFieldName,inFieldNameDup)
{
   var lFound = false;
   var lFieldObj    = document.getElementById(inFieldName);
   var lFieldObjDup = document.getElementById(inFieldNameDup);

   if (  lFieldObj.value != "" && lFieldObjDup.value != "" )
   { 
     if ( lFieldObj.value == lFieldObjDup.value ) 
       lFound = false;
     else
       lFound = true;
   } 
   if(lFound)
   {
       alert("Password and Confirm Password not Matched!");
       window.event.returnValue=false;
       lFieldObjDup.focus();
   }
}
