
function calcTRateByIds(inRecNum, inQty, inRate, inTRate)
{
  var lRecNum = inRecNum ;
  var lQty   = inQty ;
  var lRate   = inRate ;
  var lTRate   = inTRate ;

  var lQtyObj  = document.getElementById(lQty+lRecNum);
  var lRateObj  = document.getElementById(lRate+lRecNum);
  var lTRateObj  = document.getElementById(lTRate+lRecNum);

  lTRateObj.value = (lQtyObj.value)*(lRateObj.value);
}
