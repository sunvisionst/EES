function EsmItemRecSelect( inSelectFlag, inRecNum)
{
  
  if ( inSelectFlag == 'Y' )
  {

    //alert(document.getElementById("item_code_r"+inRecNum).value);
//    document.getElementById("submit1").disabled = true;
 //   document.getElementById("submit2").disabled = false;
 //   document.getElementById("submit3").disabled = false;
    document.getElementById("item_code").value      = document.getElementById("item_code_r"+inRecNum).value;
    document.getElementById("group_0").value        = document.getElementById("group_0_r"+inRecNum).value;
    document.getElementById("group_1").value        = document.getElementById("group_1_r"+inRecNum).value;
    document.getElementById("group_2").value        = document.getElementById("group_2_r"+inRecNum).value;
    document.getElementById("group_3").value        = document.getElementById("group_3_r"+inRecNum).value;
    document.getElementById("group_4").value        = document.getElementById("group_4_r"+inRecNum).value;
     document.getElementById("group_5").value       = document.getElementById("group_5_r"+inRecNum).value;
    document.getElementById("group_6").value        = document.getElementById("group_6_r"+inRecNum).value;
    document.getElementById("size_uom").value       = document.getElementById("size_uom_r"+inRecNum).value;

    document.getElementById("l").value              = document.getElementById("l_r"+inRecNum).value;
    document.getElementById("w").value              = document.getElementById("w_r"+inRecNum).value;
    document.getElementById("h").value              = document.getElementById("h_r"+inRecNum).value;
    document.getElementById("related_item_code").value = document.getElementById("related_item_code_r"+inRecNum).value;
    document.getElementById("accessory_flag").value    = document.getElementById("accessory_flag_r"+inRecNum).value;
    document.getElementById("item_type").value         = document.getElementById("item_type_r"+inRecNum).value;
    document.getElementById("item_desc").value         = document.getElementById("item_desc_r"+inRecNum).value;
    document.getElementById("item_desc_cust").value    = document.getElementById("item_desc_cust_r"+inRecNum).value; 
     document.getElementById("item_part_num").value    = document.getElementById("item_part_num_r"+inRecNum).value;
     document.getElementById("uom_per_qty").value      = document.getElementById("uom_per_qty_r"+inRecNum).value;
    document.getElementById("weight_per_qty").value    = document.getElementById("weight_per_qty_r"+inRecNum).value;

     document.getElementById("chees_pcs").value        = document.getElementById("chees_pcs_r"+inRecNum).value;
      document.getElementById("finish_pcs").value      = document.getElementById("finish_pcs_r"+inRecNum).value;

    document.getElementById("min_stock_qty").value     = document.getElementById("min_stock_qty_r"+inRecNum).value;
    document.getElementById("item_seq_num").value      = document.getElementById("item_seq_num_r"+inRecNum).value;
// accessary flag


  
  }
  else
  {
 //   document.getElementById("submit1").disabled = false;
  //  document.getElementById("submit2").disabled = true;
  //  document.getElementById("submit3").disabled = true;

    document.getElementById("item_code").value           = '';
    document.getElementById("group_0").value             = '';
    document.getElementById("group_1").value             = '';
    document.getElementById("group_2").value             = '';
    document.getElementById("group_3").value             = '';
    document.getElementById("group_4").value             = '';
    document.getElementById("group_5").value             = '';
    document.getElementById("group_6").value             = '';
    document.getElementById("size_uom").value            = '';
    document.getElementById("l").value                   = '';
    document.getElementById("w").value                   = '';
    document.getElementById("h").value                   = ''; 
    document.getElementById("related_item_code").value   = '';
    document.getElementById("accessory_flag").value      = '';
    document.getElementById("item_type").value           = '';
    document.getElementById("item_desc").value           = '';
    document.getElementById("item_desc_cust").value      = '';
    document.getElementById("item_part_num").value       = '';
    document.getElementById("uom_per_qty").value         = '';
    document.getElementById("weight_per_qty").value      = '';
    document.getElementById("chees_pcs").value           = '';
    document.getElementById("finish_pcs").value          = '';
    document.getElementById("min_stock_qty").value       = '';
    document.getElementById("item_seq_num").value        = '';


   }

}
