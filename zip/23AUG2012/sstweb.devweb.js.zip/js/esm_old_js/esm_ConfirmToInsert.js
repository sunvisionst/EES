function confirmToInsert( inConfirm )
{
    window.event.returnValue=false;
    if ( inConfirm == 'Y' )
    {
      if(confirm("Are you sure to create data."))
      {
        if ( inConfirm == 'Y' )
        {
          window.event.returnValue=true;
        }
        else
        {
          window.event.returnValue=false;
        }
      }
    }
    else
    if ( inConfirm == 'N' )
    {
      window.event.returnValue=true;
    }
}

