
function setFieldEnableDisable( )
{
  if(document.form.select_radio[0].checked)
   {
      document.form.oa_num.disabled = false;
      document.form.oa_date.disabled = false;
      document.form.select_invoice_option.value = "SOSI";
   }
   else if(document.form.select_radio[1].checked)
   {
      document.form.oa_num.disabled = false;
      document.form.oa_date.disabled = false;
      document.form.select_invoice_option.value = "SOMI";
   }
   else if(document.form.select_radio[2].checked)
   {
     document.form.oa_num.disabled = true;
     document.form.oa_date.disabled = true;
     document.form.select_invoice_option.value = "MOSI";
   }
   else if(document.form.select_radio[3].checked)
   {
      document.form.oa_num.disabled = false;
      document.form.oa_date.disabled = false;
      document.form.select_invoice_option.value = "N";
   }
}
