
function radioSelectUB()
{
    for(var i=0; i<document.form.length; i++)
    {
       var lType = "radio";
       if(document.form[i].type == lType)
       {
           document.form[i+1].value = "N";
           if(document.form[i].checked)
           {
                document.form[i+1].value = "Y";
           }
           else
           {
              document.form[i+1].value = "N";
           }
       }

    }
}
