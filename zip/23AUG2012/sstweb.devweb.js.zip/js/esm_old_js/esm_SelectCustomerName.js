
function getId(inDelimiter)
{
   var lSelectedValue = document.form.customer_name.value;
   var lCustomerId = lSelectedValue.substring(lSelectedValue.indexOf("#id=")+4);
   document.form.customer_id.value=lCustomerId;
   document.form.customer_id_dummy.value=lCustomerId;
}
