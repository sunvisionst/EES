  function checkReqQtyEqltoQty(inRecNum,inQtySup,inQty,inQtyDispatch)
  {
    var lQty            = inQty ; 
    var lQtySup         = inQtySup ;
    var lQtyDispatch    = inQtyDispatch ;

    var lTRate ;

    var lQtyObj          = document.getElementById(lQty+inRecNum);
    var lQtySupObj       = document.getElementById(lQtySup+inRecNum);
    var lQtyDispatchObj  = document.getElementById(lQtyDispatch+inRecNum);
      
    lTRate = parseInt(lQtySupObj.value ) + parseInt(lQtyDispatchObj.value );  
    if ( lTRate > lQtyObj.value )
    {
      alert ( "Req Quantity <= Item Total Qty -  Qty Supplied" );
      lQtyDispatchObj.focus();  
      window.event.returnValue = false;
    }

  }


