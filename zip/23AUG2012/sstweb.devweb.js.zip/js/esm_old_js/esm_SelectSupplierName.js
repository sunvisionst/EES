
function getId(inDelimiter)
{
   var lSelectedValue = document.form.supplier_name.value;
   var lSupplierId = lSelectedValue.substring(lSelectedValue.indexOf("#id=")+4);
   document.form.supplier_id.value=lSupplierId;
   document.form.supplier_id_dummy.value=lSupplierId;
}
