
function conf()
{
    window.event.returnValue=false;
    if(confirm("Do you want to continue."))
    {
      document.form.action_submit.value = "esm_import_balance_order_enq_create_submit"
      window.event.returnValue=true;
    }
    else 
    {
      window.event.returnValue=false;
      document.form.action_submit.value = ""
    }
}
