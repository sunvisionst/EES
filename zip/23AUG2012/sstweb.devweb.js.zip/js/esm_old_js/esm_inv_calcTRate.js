
function calcTRate(inRecNum )
{
  var index = 4+8*(parseInt(inRecNum)-1);

  var qty  = document.form[parseInt(index)].value;
  var rate = document.form[parseInt(index)+1].value;
  document.form[parseInt(index)+2].value = qty*rate;
}
