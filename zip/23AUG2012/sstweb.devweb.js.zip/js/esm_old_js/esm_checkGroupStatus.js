function checkGroupStatus( )
{
   var lGroupId;
   var truefalse = true;

   for (var lRecNum = 0 ; lRecNum <= 6; lRecNum++)
   {
      lGroupId = document.getElementById("group_"+lRecNum);
      if (lGroupId.value == "")
      {
          truefalse = false;
          break;
      } 
   }//end for

   if(!truefalse)
   {
       alert("Please Insert Value in the Group "+lRecNum+" .");
       window.event.returnValue=false;
   }

}

