
function chkSameAccountIdOnDrCrSideDr(inObjDr,inObjCr)
{
  var lObjDr = document.getElementById(inObjDr); 
  var lObjCr = document.getElementById(inObjCr);
  
  if ( lObjCr.value != "" && lObjDr.value != "" )
  {
    if ( lObjDr.value == lObjCr.value  )
    {
      alert(" Debit & Credit Account Id can not same ");
      lObjDr.value = "";   
      lObjDr.focus();   
    } 
  }
}

function chkSameAccountIdOnDrCrSideCr(inObjDr,inObjCr)
{
  var lObjDr = document.getElementById(inObjDr); 
  var lObjCr = document.getElementById(inObjCr);
  
  if ( lObjDr.value != "" && lObjCr.value != "" )
  {
    if ( lObjDr.value == lObjCr.value  )
    {
      alert(" Debit & Credit Account Id can not same ");
      lObjCr.value = "";   
      lObjCr.focus();   
    } 
  }
}

