function chkItemSourceForPrchse ( inRecNum, inTFName,inRecTypeName )
{
   var lCheckBoxObjId;
   var lTFName;
   var truefalse = true;
   var lRecTypeName = inRecTypeName;

   for (var lRecNum = 1 ; lRecNum <= inRecNum; lRecNum++)    
   {
      lCheckBoxObjId = document.getElementById("select_checkbox"+lRecNum);
      lTFName = document.getElementById(inTFName+lRecNum);
     
      if (lRecTypeName == "Purchase")
      { 
        if ( lCheckBoxObjId.checked && lTFName.value =="P" )
        {
          truefalse = false;
          break;
        }
      }
      else
      if (lRecTypeName == "Production") 
      {
        if (lCheckBoxObjId != null ) 
        {
          if ( lCheckBoxObjId.checked && lTFName.value !="P" )
          {
            truefalse = false;
            break;
          }
        }
      } 
   }//end for

   if(!truefalse)
   {
       alert("You are Selected the Item at Record No.  "+lRecNum+"  Which are not for "+lRecTypeName+".");
       window.event.returnValue=false;
   }

}
      
    


