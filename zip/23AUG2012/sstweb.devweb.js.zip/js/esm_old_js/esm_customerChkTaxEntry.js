
function chkTaxEntry()
{

  var lTxFormType = "tax_form_type";
  var lTxFormNum  = "tax_form_num";
  var lTxFormDate = "tax_form_date";

  var lTxFormTypeObj  = document.getElementById(lTxFormType);
  var lTxFormNumObj   = document.getElementById(lTxFormNum);
  var lTxFormDateObj  = document.getElementById(lTxFormDate);
 
  if ( lTxFormTypeObj.value == "" && lTxFormNumObj.value == "" && lTxFormDateObj.value == "" )
    ;
  else
  {
     
    if ( lTxFormTypeObj.value != "" && lTxFormNumObj.value == ""  && lTxFormDateObj.value == "" )
      ;
    else
    if ( lTxFormTypeObj.value != "" && lTxFormNumObj.value == ""  )
    {
      alert("Please Fill "+lTxFormNum+" to continue"); 
      lTxFormNumObj.focus();
      window.event.returnValue=false;
    }
    else
    if ( lTxFormTypeObj.value == "" )
    {
      alert("Please Fill "+lTxFormType+" to continue " ); 
      lTxFormTypeObj.focus();
      window.event.returnValue=false;
    }
    
  }
}
