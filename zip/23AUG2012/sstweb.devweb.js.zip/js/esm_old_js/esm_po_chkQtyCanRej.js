  function chklQtyCanRej( inRecNum,inQty,inQtyCanRej,inMenuOption )
  {
   /*
    var lQty            = inQty ; 
    var lQtyCanRej         = inQtyCanRej ;

    var lQtyObj          = document.getElementById(lQty+inRecNum);
    var lQtyCanRejObj       = document.getElementById(lQtyCanRej+inRecNum);
      
    if ( lQtyObj.value < lQtyCanRejObj.value )
    {
      {
        if ( inMenuOption == "reject" ) 
          alert ( "Quantity Rejected must be <= Total Quantity" );
        else
        if ( inMenuOption == "cancel" ) 
          alert ( "Quantity Cancel must be <= Total Quantity" );
      }
      lQtyCanRejObj.focus();  
      window.event.returnValue = false;
    }
   */

   for (var lRecNum = 1 ; lRecNum <= inRecNum; lRecNum++)
   {
      var lQty            = inQty ;
      var lQtyCanRej      = inQtyCanRej ;

      var lQtyObj         = document.getElementById(lQty+lRecNum);
      var lQtyCanRejObj   = document.getElementById(lQtyCanRej+lRecNum);

/*
      if ( lQtyCanRejObj.value == 0 )
      {
         alert("Please enter value greater than 0 .");
         lQtyCanRejObj.focus();
         window.event.returnValue=false;
         break;
      }
*/

      if ( lQtyObj.value < lQtyCanRejObj.value )
      {
        {
          if ( inMenuOption == "reject" )
            alert ( "Quantity Rejected must be <= Total Quantity" );
          else
          if ( inMenuOption == "cancel" )
            alert ( "Quantity Cancel must be <= Total Quantity" );
          else
          if ( inMenuOption == "revertCancel" )
            alert ( "Quantity Reverted must be <= Total Quantity" );
        }
        lQtyCanRejObj.focus();

  	   window.event.returnValue=false;
         break;
      }
   }


  }


