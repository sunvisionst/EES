
function esmItemRateSelectCheckBox()
{
  
  alert('selectCheckBox');
  var lCheckBoxObj  = document.getElementById('select_checkbox') ;
  
  if ( lCheckBoxObj.checked )
  {
 
   alert('checked');
   document.getElementById("make_id").disabled = true;
   document.getElementById("source_id").disabled = true;
   document.getElementById("size_factor").disabled = true;
   document.getElementById("production_cost").disabled = true;
   document.getElementById("domestic_sale_cost").disabled = true;
   document.getElementById("export_sale_cost").disabled = true;
   document.getElementById("domestic_buy_rate").disabled = true;
   document.getElementById("import_buy_rate").disabled = true;
   document.getElementById("make_rate").disabled = true;
   document.getElementById("effective_date").disabled = true;
   document.getElementById("expiration_date").disabled = true;

  }
  else
  {
   alert('unchecked');
   document.getElementById("make_id").disabled = false;
   document.getElementById("source_id").disabled = false;
   document.getElementById("size_factor").disabled = false;
   document.getElementById("production_cost").disabled = false;
   document.getElementById("domestic_sale_cost").disabled = false;
   document.getElementById("export_sale_cost").disabled = false;
   document.getElementById("domestic_buy_rate").disabled = false;
   document.getElementById("import_buy_rate").disabled = false;
   document.getElementById("make_rate").disabled = false;
   document.getElementById("effective_date").disabled = false;
   document.getElementById("expiration_date").disabled = false;


  }
}
