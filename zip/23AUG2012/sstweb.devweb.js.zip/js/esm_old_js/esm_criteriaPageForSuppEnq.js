 function criteriaPageSuppEnq ()
 {
   var lEnqNumObj = document.getElementById('enq_num');
   var lEnqVersionObj = document.getElementById('enq_version');
   var lSuppNameObj = document.getElementById('supplier_name');
   if ( lEnqNumObj.value != "" )
   {
   }
   else
   {
     if (lSuppNameObj.value == "")
     {
       alert("Please enter a value in "+lSuppNameObj.name +" to continue.")
       lSuppNameObj.focus();
       window.event.returnValue=false;
     }
   }
 }

