

function  emailValidationForContact( inContactType, inContactNum)
{
     var lContactType = "";
     var lContactNum  = "";
     lContactType = document.getElementById(inContactType);
     lContactNum  = document.getElementById(inContactNum);

     if ( lContactType.value == 'E' )
       emailValidation(lContactNum);
} 
