function EsmCustPoSchItemRecSelect( inSelectFlag, inRecNum)
{
  
  if ( inSelectFlag == 'Y' )
  {
    document.getElementById("submit1").disabled = false;
    document.getElementById("submit2").disabled = false;
    document.getElementById("submit3").disabled = false;
    document.getElementById("submit5").disabled = false;

    document.getElementById("item_code").value = document.getElementById("item_code_r"+inRecNum).value;
    document.getElementById("make_id").value = document.getElementById("make_id_r"+inRecNum).value;  
    document.getElementById("qty").value = document.getElementById("qty_r"+inRecNum).value;
    document.getElementById("rate").value  = document.getElementById("rate_r"+inRecNum).value;
    document.getElementById("delivery_date").value = document.getElementById("delivery_date_r"+inRecNum).value;
  }
  else
  {
    document.getElementById("submit1").disabled = true;
    document.getElementById("submit2").disabled = true;
    document.getElementById("submit3").disabled = true;
    document.getElementById("submit5").disabled = true;

    document.getElementById("item_code").value           = '';
    document.getElementById("make_id").value           = '';
    document.getElementById("qty").value  = '';
    document.getElementById("rate").value         = '';
    document.getElementById("delievery_date").value ='';
  }
}
