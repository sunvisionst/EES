
function getNameId(inDelimiter,inSource,inTarget,inDummyInd)
{

  var lSource         = inSource ;
  var lSourceObj      = document.getElementById(inSource);
  var lTarget         = inTarget ;
  var lTargetObj      = document.getElementById(inTarget);
  var lDummyInd       = inDummyInd; 
  var lSelectedValue  = lSourceObj.value;
  var lTruncatedValue = '';

  if ( lSelectedValue.indexOf("#id=") <= 0 )
    lTruncatedValue = lSelectedValue;
  else
    lTruncatedValue = lSelectedValue.substring(lSelectedValue.indexOf("#id=")+4);

  lTargetObj.value = lTruncatedValue;
 
 // To Populate Dummy field on Page for same field
 if ( lDummyInd == 'Y' )
 { 
   var lDummyObj;
   lDummyObj = document.getElementById(lTargetObj.name+"_dummy");
   lDummyObj.value = lTruncatedValue;
 } 

}
