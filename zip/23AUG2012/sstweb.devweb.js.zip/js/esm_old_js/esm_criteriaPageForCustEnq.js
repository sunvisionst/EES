 function criteriaPageCustEnq ()
 {
   var lEnqNumObj = document.getElementById('enq_num');
   var lEnqVersionObj = document.getElementById('enq_version');
   var lCustNameObj = document.getElementById('customer_name');
   if ( lEnqNumObj.value != "" )
   {
   }
   else
   {
     if (lCustNameObj.value == "")
     {
       alert("Please enter a value in "+lCustNameObj.name +" to continue.")
       lCustNameObj.focus();
       window.event.returnValue=false;
     }
   }
 }

