
function fillQtyInLocation( inRecNum, inLocRefRecStr, inRecOnPageRecStr, inMaxQty, inQty, inActualMoveQty, inMenuOption )
{
    var lFlag         = false;
    var lFlagTmp      = true;
    var lBreakQty     = false;
    var lTotalLocQty    = "0";
    var lActualQty   = document.getElementById("act_move_qty"); 
    {
      var lCount = 0;
      var i = inRecNum;
      var lCountTmp = 0;
      for ( var c = 0;c < inRecNum;c++)
      {
        lCountTmp = parseInt(lCountTmp) + parseInt(inLocRefRecStr.charAt(c));
      } 
      var lNumber = inLocRefRecStr.charAt(i-1);
      lCount = parseInt(lCountTmp) - parseInt(lNumber); 
      for( var j = 1;j <= lNumber;j++ )
      {
        var lRecOnPage = inRecOnPageRecStr.charAt(lCount); 
        lCount = lCount + 1;
        for (var k = 1; k <= lRecOnPage;k++)
        {
          var lActualMoveQty = "";
          lActualMoveQty = document.getElementById(inActualMoveQty+"_r"+i+j+k);
          if ( lActualMoveQty.value != "" )
            lTotalLocQty = parseInt(lTotalLocQty) + parseInt(lActualMoveQty.value);
        }
      }
    }

    if ( parseInt(lTotalLocQty) > parseInt(lActualQty.value) )
    {
      alert("Total Move Qty should be less than Actual Move Qty.");
      window.event.returnValue=false;
    }
    else
    {
      var lCount = 0;
      var i = inRecNum;
      var lCountTmp = 0;
      for ( var c = 0;c < inRecNum;c++)
      {
        lCountTmp = parseInt(lCountTmp) + parseInt(inLocRefRecStr.charAt(c));
      }
      var lNumber = inLocRefRecStr.charAt(i-1);
      lCount = parseInt(lCountTmp) - parseInt(lNumber); 
      for ( var j = 1; j <= lNumber; j++ )
      {
        var lRecOnPage = inRecOnPageRecStr.charAt(lCount);
        lCount = lCount + 1;
        for (var k = lRecOnPage; k >= 1;k--)
        {
          var lActualMoveQty = document.getElementById(inActualMoveQty+"_r"+i+j+k);

          if ( lActualMoveQty.value == "" )
          {
            if ( lBreakQty && lFlagTmp)
            {
              lFlag = true;
              break;
            }
          }
          else
          {

            if ( k == 1)
            {
              if ( lActualMoveQty.value != "" )
              {  
                lFlagTmp = false;
              }
            }
            else 
            {
              lFlagTmp  = true;
              lBreakQty = true;
            }
          }
          if ( lFlag )
            break;
        }
        if ( lFlag )
          break;
      }

      var lQtyFlag = false;
      var lQtyNum  = "";
      if ( lFlag )
      {
        alert("Please fill Move Qty above. ");
        window.event.returnValue=false;
      }
      else
      {
        var lCount = 0;
        var i = inRecNum;
        var lCountTmp = 0;
        for ( var c = 0;c < inRecNum;c++)
        {
          lCountTmp = parseInt(lCountTmp) + parseInt(inLocRefRecStr.charAt(c));
        }
        var lNumber = inLocRefRecStr.charAt(i-1); 
        lCount = parseInt(lCountTmp) - parseInt(lNumber); 
        for (var j = 1; j <= lNumber;j++)
        {
        var lRecOnPage = inRecOnPageRecStr.charAt(lCount); 
        lCount = lCount + 1;
        for (var k = 1; k <= lRecOnPage;k++)
        {
          var lActualMoveQty = document.getElementById(inActualMoveQty+"_r"+i+j+k);
          if ( lActualMoveQty.value != "" )
          {
            var lMaxQty          = document.getElementById(inMaxQty+"_r"+i+j+k);
            var lQty             = document.getElementById(inQty+"_r"+i+j+k);

            if ( inMenuOption == 'StockIn')
            {
              if (  (lMaxQty.value != "" && lQty.value != "" ) &&  (parseInt(lMaxQty.value) == parseInt(lQty.value)) || (  (parseInt(lQty.value) == ( parseInt(lMaxQty.value) - parseInt(lActualMoveQty.value) ) ) && ( parseInt(lMaxQty.value) >= (parseInt(lQty.value)+ parseInt(lActualMoveQty.value))) || ( ( parseInt(lTotalLocQty) - parseInt(lActualMoveQty.value) ) == ( parseInt(lActualQty.value) - parseInt(lActualMoveQty.value ) ) ) ) )     
              {
              }
              else
              {
                lQtyFlag = true;
                lQtyNum  = k;
              }
            }
            else
            if ( inMenuOption == 'StockOut')
            {
              if ( parseInt(lQty.value) >= parseInt(lActualMoveQty.value))
                ;
              else
              {
                lQtyFlag = true;
                lQtyNum  = k;
              }

            }
            if (lQtyFlag)
              break; 
          }
          if (lQtyFlag)
            break; 
        }
          if (lQtyFlag)
            break; 
        }


        if ( lQtyFlag )
        {
          if ( parseInt(lTotalLocQty) < parseInt(lQty.value) )
            lMoveQty = parseInt(lMaxQty.value) - parseInt(lQty.value);
          else 
          if (parseInt(lActualQty.value) - ( parseInt(lTotalLocQty) - parseInt(lActualMoveQty.value) ) >= ( parseInt(lMaxQty.value) - parseInt(lQty.value) ))
            lMoveQty = parseInt(lMaxQty.value) - parseInt(lQty.value);
          else
          {
            lMoveQty = parseInt(lActualQty.value) - (parseInt(lTotalLocQty) - parseInt(lActualMoveQty.value) );
          }




          if ( lMaxQty.value == "" && lQty.value == ""  )
            alert("There is no Space for allocatuion .");
          else
          if ( parseInt(lMaxQty.value) < ( parseInt(lQty.value) + parseInt(lActualMoveQty.value)))
            alert("Allocation is not possible for Move Qty .");
            //alert("Space is not available for Move Qty in row "+lQtyNum+".");
          else  
          if ( inMenuOption == 'StockIn')
            alert("Move Qty should be "+lMoveQty+" in that place.");
            //alert("Move Qty should be "+lMoveQty+" in row "+lQtyNum+".");
          else 
          if ( inMenuOption == 'StockOut')
          { 
            alert("Please fill Actual Move Qty less than or equal to Existing Qty in row "+lQtyNum+". ");
          }

          //lActualMoveQty.focus();
          window.event.returnValue=false; 
        }
    }
  }  
}
