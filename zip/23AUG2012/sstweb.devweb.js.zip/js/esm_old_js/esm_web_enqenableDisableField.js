
function setenqFieldEnableDisable( )
{
  if(document.form.select_radio[0].checked)
   {
      document.form.card_num.disabled = false;
      document.form.credit_card_bank.disabled = false;
      document.form.card_type.disabled = false;
      document.form.card_ctg.disabled = false;
      document.form.card_issue_dt.disabled = false;
      document.form.card_valid.disabled = false;
   }
   else if(document.form.select_radio[1].checked)
   {
      document.form.card_num.disabled = true;
      document.form.credit_card_bank.disabled = true;
      document.form.card_type.disabled = true;
      document.form.card_ctg.disabled = true;
      document.form.card_issue_dt.disabled = true;
      document.form.card_valid.disabled = true;
      document.form.card_num.value = "";
      document.form.credit_card_bank.value = "";
      document.form.card_type.value = "";
      document.form.card_ctg.value ="";
      document.form.card_issue_dt.value = "";
      document.form.card_valid.value = "";
   }
   else if(document.form.select_radio[2].checked)
   {
      document.form.card_num.disabled = true;
      document.form.credit_card_bank.disabled = true;
      document.form.card_type.disabled = true;
      document.form.card_ctg.disabled = true;
      document.form.card_issue_dt.disabled = true;
      document.form.card_valid.disabled = true;
      document.form.card_num.value = "";
      document.form.credit_card_bank.value = "";
      document.form.card_type.value = "";
      document.form.card_ctg.value ="";
      document.form.card_issue_dt.value = "";
      document.form.card_valid.value = "";
   }
    else if(document.form.select_radio[3].checked)
   {
      document.form.card_num.disabled = true;
      document.form.credit_card_bank.disabled = true;
      document.form.card_type.disabled = true;
      document.form.card_ctg.disabled = true;
      document.form.card_issue_dt.disabled = true;
      document.form.card_valid.disabled = true;
      document.form.card_num.value = "";
      document.form.credit_card_bank.value = "";
      document.form.card_type.value = "";
      document.form.card_ctg.value ="";
      document.form.card_issue_dt.value = "";
      document.form.card_valid.value = "";
   }

}
