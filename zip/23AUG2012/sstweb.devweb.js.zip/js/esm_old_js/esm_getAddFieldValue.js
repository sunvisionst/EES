function getAddFieldValue( inFieldName, inTrgFieldName, inRecNum , inFieldValue )
{
  var lFieldName    = "";
  var lTrgFieldName = "";
  if ( inRecNum != ""  && inRecNum == 'S')
  {
     lFieldName    = document.getElementById(inFieldName);
     lTrgFieldName = document.getElementById(inTrgFieldName);

    if ( lFieldName.value ==  'D')
      lTrgFieldName.value = inFieldValue;
    else
      lTrgFieldName.value = "";
  }
  else
  {
     lFieldName    = document.getElementById(inFieldName+"_r"+inRecNum);
     lTrgFieldName = document.getElementById(inTrgFieldName+"_r"+inRecNum);

     if ( lFieldName.value ==  20)
      lTrgFieldName.value = inFieldValue;
    else
      lTrgFieldName.value = "";
  }
 
} 
