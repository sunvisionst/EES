  function chkReqQtyEqlActQty(inOprReqQty,inOprQty,inOprBalQty)
  {
    var lOprActQty    = inOprReqQty ; 
    var lOprReqQty    = inOprQty ;
    var lOprBalQty    = inOprBalQty ;

    var lTRate ;

    var lOprActQtyObj     = document.getElementById(lOprActQty);
    var lOprReqQtyObj     = document.getElementById(lOprReqQty);
    var lOprBalQtyObj     = document.getElementById(lOprBalQty);
      
    lTRate = parseInt(lOprReqQtyObj.value ) + parseInt(lOprBalQtyObj.value );  
    if ( lOprActQtyObj.value < lTRate )
    {
      alert ( "Req Quantity <= Actual Quantity  -  Balance Qty" );
      lOprReqQtyObj.focus();  
      window.event.returnValue = false;
    }
  }

  function chkBalanceQty(inOprReqQty,inOprQty,inOprBalQty)
  {
    var lOprActQty    = inOprReqQty ;
    var lOprReqQty    = inOprQty ;
    var lOprBalQty    = inOprBalQty ;

    var lActRate ;
    var lActRateTemp ;

    var lOprActQtyObj     = document.getElementById(lOprActQty);
    var lOprReqQtyObj     = document.getElementById(lOprReqQty);
    var lOprBalQtyObj     = document.getElementById(lOprBalQty);

    lActRateTemp = parseInt(lOprBalQtyObj.value);
    lActRate = parseInt(parseInt(lOprActQtyObj.value)-( parseInt(lOprReqQtyObj.value ) + parseInt(lOprBalQtyObj.value)));
    if ( lActRate < 0 )
    ;
    else
    {
      lOprBalQtyObj.value = parseInt(lActRate);
    }
  }



