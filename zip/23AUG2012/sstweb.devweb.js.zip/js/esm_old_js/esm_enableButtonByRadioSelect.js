
function enableButtonByRadioSelect( inRecOnPage )
{
    for(var i=1; i<= inRecOnPage; i++)
    {
       //var lType = "radio";
       var lSubmit = document.getElementById("submit_r"+i);
       var lApprove = document.getElementById("approve_r"+i);
       var lSelect = document.getElementById("select_r"+i);
        
       if (lSelect.value == 'Y')
       {
          lSubmit.disabled = false;
          lApprove.disabled = false;
       }  
       else
       {
          lSubmit.disabled = true;
          lApprove.disabled = true;
       }  


    }
}
