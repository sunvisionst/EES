 function criteriaPagePo ( inTFName, inTFNum )
 {
   var lTFName = document.getElementById(inTFName);
   var lTFNum = document.getElementById(inTFNum);
   if ( lTFNum.value == "" )
   {
     if ( lTFName.value == "" )
     {
       alert("Please enter a value in "+lTFName.name +" to continue.");
       lTFName.focus();
       window.event.returnValue=false;
     }
   }
 }
