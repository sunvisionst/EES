function EsmCustPoSchRecSelect( inSelectFlag, inRecNum)
{
  if ( inSelectFlag == 'Y' )
  {
    document.getElementById("submit1").disabled = true;
    document.getElementById("submit2").disabled = false;
    document.getElementById("submit3").disabled = false;
    document.getElementById("submit4").disabled = false;
    document.getElementById("submit5").disabled = false;

    document.getElementById("po_sch_num").value = document.getElementById("po_sch_num_r"+inRecNum).value;
    document.getElementById("po_sch_date").value = document.getElementById("po_sch_date_r"+inRecNum).value;
    document.getElementById("oa_num").value = document.getElementById("oa_num_r"+inRecNum).value;
    document.getElementById("oa_date").value = document.getElementById("oa_date_r"+inRecNum).value;
    document.getElementById("order_type").value  = document.getElementById("order_type_r"+inRecNum).value;
    document.getElementById("customer_id").value = document.getElementById("customer_id_r"+inRecNum).value;
    document.getElementById("customer_name")[document.getElementById("cust_seq_num_r"+inRecNum).value].selected = true; 

    document.getElementById("delivery_address_type").value = document.getElementById("delivery_address_type_r"+inRecNum).value;
    document.getElementById("po_num").value = document.getElementById("po_num_r"+inRecNum).value;
    document.getElementById("po_date").value  = document.getElementById("po_date_r"+inRecNum).value;
    document.getElementById("vendor_id").value  = document.getElementById("vendor_id_r"+inRecNum).value;
    document.getElementById("buyer_name").value  = document.getElementById("buyer_name_r"+inRecNum).value;
    document.getElementById("spl_instruction").value  = document.getElementById("spl_instruction_r"+inRecNum).value;
  }
  else
  {
    document.getElementById("submit1").disabled = false;
    document.getElementById("submit2").disabled = true;
    document.getElementById("submit3").disabled = true;
    document.getElementById("submit4").disabled = true;
    document.getElementById("submit5").disabled = true;

    document.getElementById("po_sch_num").value           = '';
    document.getElementById("po_sch_date").value  = '';
    document.getElementById("oa_num").value     = '';
    document.getElementById("oa_date").value  = '';
    document.getElementById("order_type").value         = '';
    document.getElementById("customer_id").value   = '';
    document.getElementById("delivery_address_type").value ='';
    document.getElementById("po_num").value = '';
    document.getElementById("po_date").value  = '';   
    document.getElementById("vendor_id").value  = '';
    document.getElementById("buyer_name").value  = '';
    document.getElementById("spl_instruction").value  =''; 
  }
}
