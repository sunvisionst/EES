function checkPrNumOrCustId(incustomerId,inprordNum)
{
  var lcustomerId = incustomerId;
  var lprOrdNum   = inprordNum;
  var truefalse = true;

  var lCustomerIdObj = document.getElementById(lcustomerId);
  var lPrOrdNumObj   = document.getElementById(lprOrdNum);

  if ( lCustomerIdObj.value == "" && lPrOrdNumObj.value == "")
  {
    truefalse = false;
  } 

  if(!truefalse)
  {
     alert("Please enter either Production order num  OR  Customer Id");
     window.event.returnValue=false;
  }
}



