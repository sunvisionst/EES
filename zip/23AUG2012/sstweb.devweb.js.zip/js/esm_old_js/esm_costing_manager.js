function costing_discount_global_factor( inArrSize )
{

   alert("costing_discount_global_factor");
   var lGlobalFactor      = document.getElementById("global_factor");
   var lBusTotalCost      = document.getElementById("bus_total_cost");
   var lBTC               = parseInt(lBusTotalCost.value);
   var lStndTotalCost     = document.getElementById("stnd_total_cost");
   var lSTC               = parseInt(lStndTotalCost.value);

   if ( lGlobalFactor.value != "" )
   {

      for ( var lRecNum = 1; lRecNum <= inArrSize; lRecNum++ )
      {
        var lItemFactor        = document.getElementById("item_factor_r"+lRecNum);
        var lTOC               = document.getElementById("total_opr_cost_r"+lRecNum);
        var lTOCvalue          = parseInt(lTOC.value);

        var lItemFactorDiscount = 0;
        if ( lItemFactor.value != "" )
        {
          lItemFactorDiscount = lTOCvalue * (( 100 - parseInt(lItemFactor.value) )/100); 
          //alert("1nd discount"+lItemFactorDiscount)
          lItemFactorDiscount = lItemFactorDiscount * (( 100 - parseInt(lGlobalFactor.value) )/100);
          //alert("2st discount"+lItemFactorDiscount)
        }
        else
        {
          lItemFactorDiscount = lTOCvalue * (( 100 - parseInt(lGlobalFactor.value) )/100); 
        }

        var lBusOprCost   = document.getElementById("bus_opr_cost_r"+lRecNum);
        lBusOprCost.value = lItemFactorDiscount;
      }
      var lTCDiscount;

      var lBusTotalCostDiscount = 0;
      for ( var lRecNum = 1; lRecNum <= inArrSize; lRecNum++ )
      {
        var lBOC   = document.getElementById("bus_opr_cost_r"+lRecNum);
        lBusTotalCostDiscount =  lBusTotalCostDiscount + parseInt(lBOC.value);
      }
      //lTCDiscount         = lSTC * (( 100 - parseInt(lGlobalFactor.value) )/100);
      //lBusTotalCost.value = lTCDiscount;
      lBusTotalCost.value = lBusTotalCostDiscount;
   }
}
function costing_discount_item_factor( inRow, inArrSize )
{
   alert("costing_discount_item_factor");
   var lGlobalFactor      = document.getElementById("global_factor");
   var lItemFactor        = document.getElementById("item_factor_r"+inRow);

   var lTotalOprCost      = document.getElementById("total_opr_cost_r"+inRow);
   var lTotalOprCostDummy = document.getElementById("total_opr_cost_r"+inRow+"_dummy");

   var lBusOprCost        = document.getElementById("bus_opr_cost_r"+inRow);
   var lBusOprCostDummy   = document.getElementById("bus_opr_cost_r"+inRow+"_dummy");


   var lBusTotalCost      = document.getElementById("bus_total_cost");
   var lBTC               = parseInt(lBusTotalCost.value); 
   var lStndTotalCost     = document.getElementById("stnd_total_cost");
   var lSTC               = parseInt(lStndTotalCost.value);

   var lTOC  = parseInt(lTotalOprCost.value);
   var lDiscount;

   lDiscount = lTOC * (( 100 - parseInt(lItemFactor.value) )/100);

   if ( lItemFactor.value != "" )
   {
     var lItemDiscount = 0;
     lItemDiscount = lTOC * (( 100 - parseInt(lItemFactor.value) )/100);
     if ( lGlobalFactor.value != "" )
     {
       lItemDiscount = lItemDiscount * (( 100 - parseInt(lGlobalFactor.value) )/100);
     }
     lBusOprCost.value  = lItemDiscount;  
   }
   else
   {
     if ( lGlobalFactor.value != "" )
     {
       lItemDiscount = lTOC * (( 100 - parseInt(lGlobalFactor.value) )/100);
       lBusOprCost.value  = lItemDiscount;  
     }
   }

   var lBTotalCost = 0;
   for ( var lRecNum = 1; lRecNum <= inArrSize; lRecNum++ ) 
   {
     var lTotalCost = document.getElementById("bus_opr_cost_r"+lRecNum);
     lBTotalCost  = lBTotalCost + parseInt ( lTotalCost.value );
   }
   
     //alert(lBTotalCost);
   if ( lBTotalCost > 0 )
     lBusTotalCost.value = lBTotalCost;
/*
   lDiscount = lTOC * (( 100 - parseInt(lItemFactor.value) )/100);

   alert( lDiscount ); 
   lBusOprCost.value      = lDiscount;  

   var lBTotalCost = 0;
   for ( var lRecNum = 0; lRecNum < inArrSize; lRecNum++ ) 
   {
     var lTotalCost = document.getElementById("bus_opr_cost_r"+lRecNum);
     lBTotalCost  = lBTotalCost + parseInt ( lTotalCost.value );
     alert("BusTotalCost"+lBTotalCost);
   }

   lBusTotalCost.value = lBTotalCost;
*/



/*

   if ( lGlobalFactor.value != "" )
   {
     var lTCDiscount;
    
     lTCDiscount         = lSTC * (( 100 - parseInt(lGlobalFactor.value) )/100); 
     lBusTotalCost.value = lTCDiscount;
    
     alert ( lBusTotalCost.value );

      for ( var lRecNum = 0; lRecNum < inArrSize; lRecNum++ ) 
      {
        var lItemFactorG        = document.getElementById("item_factor_r"+lRecNum);
        var lTOCG               = document.getElementById("total_opr_cost_r"+lRecNum);
        var lTOCGvalue          = parseInt(lTOCG.value);
 
        var lItemFactorDiscount = 0;
        lItemFactorDiscount = lTOCGvalue * (( 100 - parseInt(lGlobalFactor.value) )/100);
       
        var lBusOprCostG   = document.getElementById("bus_opr_cost_r"+lRecNum);
        lBusOprCostG.value = lItemFactorDiscount;
        lItemFactorG.value = parseInt(lGlobalFactor.value);
      }
   }

*/



}
