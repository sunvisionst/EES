function validateClassteacher( inClassTeacher, lRow, lCol, e )
{
  //////////////////////////////////////////////////////////////////////////////////////////

      //////////////////////////////////////////////////////////////////////////////////////////
      checkSemaphore('sst_semaphore');
      //////////////////////////////////////////////////////////////////////////////////////////

      var lEmployeeId  = document.getElementById("employee_id"+"_r"+lRow+"_c"+lCol).value;
      var lClassTeacher = inClassTeacher;
      var lBrowserName = getBrowserName();

      if( lCol == '1')
      {
        if( lEmployeeId == lClassTeacher )
        ;
        else
        var evtmsg = confirm('This Faculty '+lEmployeeId+' is not Class Teacher... Are U Sure to Assign?');
      }


      if( evtmsg == false )
      {
        if ( lBrowserName == 'Microsoft Internet Explorer' )
        {
          document.getElementById("employee_id"+"_r"+lRow+"_c"+lCol).value= '';
          window.event.returnValue=false;
        }
        else
        if ( lBrowserName == 'Netscape' )
        {
          document.getElementById("employee_id"+"_r"+lRow+"_c"+lCol).value= '';
          e.preventDefault();
          e.stopPropagation();
        }
      }

      //////////////////////////////////////////////////////////////////////////////////////////
      releaseSemaphore('sst_semaphore');
      //////////////////////////////////////////////////////////////////////////////////////////

}
