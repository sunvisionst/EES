function EesGranterFieldVld()
{
  var lSubmitObj;
  alert("ok"+document.getElementById("country").value);
 // if( document.getElementById("country").value == '1' )
  {
 //  alert("ok"+document.getElementById("country").value);
       //      document.getElementById("installment_flag").value   = document.getElementById("installment_flag"+"_r"+inRecNum).value;
  
  }
///  if( document.getElementById("country").value == '2' )
  {
 //   alert("Not ok"+document.getElementById("country").value);
       //      document.getElementById("installment_flag").value   = document.getElementById("installment_flag"+"_r"+inRecNum).value;

  }

}





