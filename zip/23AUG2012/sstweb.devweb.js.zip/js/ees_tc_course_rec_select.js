function EesCourseRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_id").readOnly  = true;
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
    //document.getElementById("dept_id").value  = document.getElementById("dept_id"+"_r"+inRecNum).value; 
    //document.getElementById("course_code").value  = document.getElementById("course_code"+"_r"+inRecNum).value; 
    //document.getElementById("short_code").value  = document.getElementById("short_code"+"_r"+inRecNum).value; 
    //document.getElementById("sst_course_id").value  = document.getElementById("sst_course_id"+"_r"+inRecNum).value; 
    document.getElementById("duration_type").value  = document.getElementById("duration_type"+"_r"+inRecNum).value; 
    document.getElementById("course_duration").value  = document.getElementById("course_duration"+"_r"+inRecNum).value; 
    //document.getElementById("class_id_pattern").value  = document.getElementById("class_id_pattern"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
    //document.getElementById("board_university").value  = document.getElementById("board_university"+"_r"+inRecNum).value; 
    //document.getElementById("stream_ind").value  = document.getElementById("stream_ind"+"_r"+inRecNum).value; 
    //document.getElementById("course_strength").value  = document.getElementById("course_strength"+"_r"+inRecNum).value; 
    //document.getElementById("quota_qty").value  = document.getElementById("quota_qty"+"_r"+inRecNum).value; 
    document.getElementById("course_coord").value  = document.getElementById("course_coord"+"_r"+inRecNum).value; 
    //document.getElementById("min_fee_amt").value  = document.getElementById("min_fee_amt"+"_r"+inRecNum).value; 
    //document.getElementById("cc_ptl_user_id").value  = document.getElementById("cc_ptl_user_id"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("description").value  = '';
    document.getElementById("course_id").readOnly  = false;
    //document.getElementById("dept_id").value  = '';
    //document.getElementById("course_code").value  = '';
    //document.getElementById("short_code").value  = '';
    //document.getElementById("sst_course_id").value  = '';
    document.getElementById("duration_type").value  = 'M';
    document.getElementById("course_duration").value  = '1';
    //document.getElementById("class_id_pattern").value  = '';
    document.getElementById("remark").value  = '';
    //document.getElementById("board_university").value  = '';
    //document.getElementById("stream_ind").value  = '';
    //document.getElementById("course_strength").value  = '';
    //document.getElementById("quota_qty").value  = '';
    document.getElementById("course_coord").value  = '';
    //document.getElementById("min_fee_amt").value  = '';
    //document.getElementById("cc_ptl_user_id").value  = '';
  }
}
