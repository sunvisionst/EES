function chkDuplicateBookIssue( inArrSize, inThis )
{
   var lReturnValue = 0;
   var lBookIdNameId;

   if ( inArrSize > 0 )
   for ( var lRecNum = 1; lRecNum <= inArrSize; lRecNum++ )
   {
     lBookIdNameId = inThis.name+'_r'+lRecNum;
     if ( document.getElementById(lBookIdNameId).value == inThis.value )
     {
       alert('This Book is Already issued');
       document.getElementById('book_name').value        = '';
       document.getElementById('author').value           = '';
       document.getElementById('book_ctg_1').value       = '';
       document.getElementById('book_id').value          = '';
       document.getElementById('book_id').focus();
       lReturnValue = -1;
       (submit1).disable=true;
       break;
     }
   }

   return lReturnValue;
} 

