function EesStudentMarkRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value;
   document.getElementById("exam_id").value     = document.getElementById("exam_id"+"_r"+inRecNum).value;
   document.getElementById("subject_code").value= document.getElementById("subject_code"+"_r"+inRecNum).value;
   document.getElementById("class_id").value    = document.getElementById("class_id"+"_r"+inRecNum).value;
   document.getElementById("class_std").value   = document.getElementById("class_std"+"_r"+inRecNum).value;
   document.getElementById("course_id").value   = document.getElementById("course_id"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

   document.getElementById("student_id").value  = '';
   document.getElementById("exam_id").value     = '';
   document.getElementById("subject_code").value= '';
   document.getElementById("class_id").value    = '';
   document.getElementById("class_std").value   = '';
   document.getElementById("course_id").value   = '';
    // add other fields like above
  }
}
