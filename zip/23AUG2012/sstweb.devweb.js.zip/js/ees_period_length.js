function calculateDD( inSubjectdetail, lFieldList, inRow, inCol)
{
  //alert(inSubjectdetail);
  //e.g. inSubjectdetail = "ARTS-1@2$....."
  var lFlag   = 0;
  var lValue  = 0;
  var lFieldListValue = document.getElementById(lFieldList+"_r"+inRow+"_c"+inCol).value; 
  
  var lSubjectAndArr = new Array();
  lSubjectAndArr = inSubjectdetail.split('@');
  
  for ( var lFieldCnt = 0; lFieldCnt < lSubjectAndArr.length; lFieldCnt++)
  {
    var lSubjectAndNoArr = new Array();
    lSubjectAndNoArr = lSubjectAndArr[lFieldCnt].split(',');

    if ( lSubjectAndNoArr[2] == 'Y' )
    if( lSubjectAndNoArr[0] == lFieldListValue )
    {
       if( parseInt(lSubjectAndNoArr[1]) > 1 )
       { 
         lFlag  = 1;
         lValue = parseInt(lSubjectAndNoArr[1]);
       }
       break;
    }
  }

  if( lFlag == 1 && lValue > 1)
  {
    var lCol = inCol;
    for ( var lCnt = 2; lCnt <= lValue; lCnt++)
    {
      lCol =  parseInt(lCol) +  parseInt(1);
      document.getElementById(lFieldList+"_r"+inRow+"_c"+lCol).value = lFieldListValue;
      //////////////////////////////////////////////////////////////////////////////////
      copyDD( 'employee_id'+"_r"+inRow+"_c"+inCol , 'employee_id'+"_r"+inRow+"_c"+lCol);
      //////////////////////////////////////////////////////////////////////////////////
    }
  }
}
