function prepDeliveryAddressSupp( inSupplierId, inDelAddrType, inDelAddr )
{
   var lDeliveryAddress = "";
   var lSupplierIdObj = document.getElementById(inSupplierId);
   var lAddrTypeObj = document.getElementById(inDelAddrType);
   var lAddrTypeValue = lAddrTypeObj.value;
   var lDelAddrObj = document.getElementById(inDelAddr);
   if ( lAddrTypeObj.value == "" )
     lAddrTypeValue = 'N';

     for ( var  lRecNum = 0; lRecNum < lEsmSupplierAddressTabObjJSArr.length; lRecNum++ )
     {
       if ( (lEsmSupplierAddressTabObjJSArr[lRecNum].supplier_id == lSupplierIdObj.value)
         && (lEsmSupplierAddressTabObjJSArr[lRecNum].address_type == lAddrTypeValue)
          )
       {
         lDeliveryAddress = lDeliveryAddress + lEsmSupplierAddressTabObjJSArr[lRecNum].address_field_value;
         if ( lRecNum+1 < lEsmSupplierAddressTabObjJSArr.length )
            lDeliveryAddress = lDeliveryAddress + " , ";
       }
     }
     lDelAddrObj.value = lDeliveryAddress;
}
/*
      String lAddressFldName = "";
      for ( int lNum = 0; lNum < lGnTypeValueAddrFldArr.size(); lNum++ )
      {
         GnTypeValueTabObj lGnTypeValueTabObj = new GnTypeValueTabObj();
         lGnTypeValueTabObj = (GnTypeValueTabObj)lGnTypeValueAddrFldArr.get(lNum);
                                                                                                                             
         if ( lGnTypeValueTabObj.id_type_code.equals(lEsmCustomerAddressTabObj.address_field_name) )
            lAddressFldName = lGnTypeValueTabObj.id_type_value;
      }
                                                                                                                             
      lDeliveryAddress = lDeliveryAddress + lAddressFldName + " - ";
      lDeliveryAddress = lDeliveryAddress + lEsmCustomerAddressTabObj.address_field_value;
      if ( lAddRecNum+1 < lEnqCustomerEnquiryItemAddressSortedArr.size() )
      lDeliveryAddress = lDeliveryAddress + " , ";
    }*/
