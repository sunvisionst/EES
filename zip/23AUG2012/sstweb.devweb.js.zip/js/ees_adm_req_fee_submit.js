function  showApplicationFormOrRollNo()
{
  if ( document.form.select_radio_for_1.checked )
  {
    document.getElementById("application_form_tr").style.display= '';
    document.getElementById("roll_no_text_tr").style.display= 'none';
  }
  else
  if ( document.form.select_radio_for_2.checked )
  {
    document.getElementById("roll_no_text_tr").style.display= '';
    document.getElementById("application_form_tr").style.display= 'none';
  }

}




function checkDefaultRadio()
{
  document.getElementById("select_radio_for_1.checked").checked = true;
  showApplicationFormOrRollNo(); 
}
