function EesLibBookIssueRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("issue_txn_id").value  = document.getElementById("issue_txn_id"+"_r"+inRecNum).value; 
    document.getElementById("book_id").value  = document.getElementById("book_id"+"_r"+inRecNum).value; 
    document.getElementById("issue_date").value  = document.getElementById("issue_date"+"_r"+inRecNum).value; 
    document.getElementById("duration_in_days").value  = document.getElementById("duration_in_days"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("library_card_num").value  = document.getElementById("library_card_num"+"_r"+inRecNum).value; 
    document.getElementById("penalty_amt").value  = document.getElementById("penalty_amt"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("book_ctg_1").value  = document.getElementById("book_ctg_1"+"_r"+inRecNum).value; 
    document.getElementById("book_ctg_2").value  = document.getElementById("book_ctg_2"+"_r"+inRecNum).value; 
    document.getElementById("book_ctg_3").value  = document.getElementById("book_ctg_3"+"_r"+inRecNum).value; 
    document.getElementById("book_type").value   = document.getElementById("book_type"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("issue_txn_id").value  = '';
    document.getElementById("book_id").value  = '';
    document.getElementById("issue_date").value  = '';
    document.getElementById("duration_in_days").value  = '';
    document.getElementById("student_id").value  = '';
    document.getElementById("library_card_num").value  = '';
    document.getElementById("penalty_amt").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("class_section").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("book_ctg_1").value  = '';
    document.getElementById("book_ctg_2").value  = '';
    document.getElementById("book_ctg_3").value  = '';
    document.getElementById("book_type").value  = '';
  }
}
