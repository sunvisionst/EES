function doubleClickInit ( lResetVarFlag, lRecCount, lRecOnPage, inRecOnPage, inRecOffSet )
{

     if ( lResetVarFlag == 'F' )
     {
       if ( lRecCount > 0 )
       {
         lRecOffSet = 0;
         if ( lRecCount <= lRecOnPage )
           lPageRecCount = lRecCount;
         else
           lPageRecCount = lRecOnPage;
       }
     }

     else
     if ( lResetVarFlag == 'L' )
     {
       if ( lRecCount > 0 )
       {
         if ( lRecCount <= lRecOnPage )
         {
           lRecOffSet = 0;
           lPageRecCount = lRecCount;
         }
         else
         if( lRecCount%lRecOnPage > 0)
         {
           lRecOffSet = lRecCount-(lRecCount%lRecOnPage);
           lPageRecCount = lRecCount%lRecOnPage;
         }
         else
         if ( lRecCount%lRecOnPage == 0 )
         {
           lRecOffSet = lRecCount-2*lRecOnPage;
           lPageRecCount = lRecOnPage;
         }
       }
     }

     else
     if ( lResetVarFlag == 'N' )
     {
       if ( lRecCount > 0 )
       {
         if ( lRecCount <= lRecOnPage )
           lPageRecCount = lRecCount;
         else
           lPageRecCount = lRecOnPage;

         if ( lRecOffSet == ( lRecCount - (lRecCount%lRecOnPage)) )
         {
           lRecOffSet = lRecCount - (lRecCount%lRecOnPage);
           lPageRecCount = lRecCount%lRecOnPage;
         }
         else
         if ( (lRecOffSet+lRecOnPage) == ( lRecCount - (lRecCount%lRecOnPage)) )
         {
           lRecOffSet = lRecOffSet + lRecOnPage;
           lPageRecCount = lRecCount%lRecOnPage;
         }
         else
         {
           lRecOffSet = lRecOffSet + lRecOnPage;
         }
       }
     }

     else
     if ( lResetVarFlag == 'P' )
     {
       if ( lRecCount > 0 )
       {
         if ( ( lRecOffSet - lRecOnPage ) < 0 )
           lRecOffSet = 0;
         else
           lRecOffSet = lRecOffSet - lRecOnPage;

         if ( lRecCount <= lRecOnPage )
           lPageRecCount = lRecCount;
         else
           lPageRecCount = lRecOnPage;
       }
     }

     else
     if ( lResetVarFlag == 'X' )
     {
       if ( lRecCount <= inRecOnPage )
       {
         lPageRecCount = lRecCount;
       }
       else
       {
         if ( inRecOnPage < MAX_PAGE_REC_JS )
         {
           lPageRecCount = MAX_PAGE_REC_JS;
         }
         else
         {
           lPageRecCount = inRecOnPage;
         }
       }
       lRecOffSet = inRecOffSet;
     }
     //alert( lRecOffSet +' - '+ lPageRecCount );

}
