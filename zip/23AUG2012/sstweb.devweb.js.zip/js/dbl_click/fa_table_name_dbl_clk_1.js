  function dblClickEsmItem1( inRecOffSet, inRecOnPage, inTableName, inFieldListSrc, inFieldListTrg, inSelectIndicator)
  {

     lRecCount        = lFaAccountGroupTabObjJSArr.length;
     doubleClickInit ( lResetVarFlag, lRecCount, lRecOnPage, inRecOnPage, inRecOffSet );

//alert('11111');
     gTableName = inTableName;
     gFieldListSrc = inFieldListSrc;
     gFieldListTrg = inFieldListTrg;
     gSelectIndicator = inSelectIndicator;

//alert('22222');
     if ( lRefreshFlag )
     {
       lRecOffSet   = 0;
       lRecOnPage   = MAX_PAGE_REC_JS;
       lRecCount    = lFaAccountGroupTabObjJSArr.length;
       lRefreshFlag = false;
     }

     Window = document.open("","","width=300,height=400,status=no,resizable=no,top=200,left=200");
     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<html>");
     Window.document.write("<title>Select Record</title>");
     Window.document.write("<body>");

//alert('33332');
     doubleClickPrepActionBar();

     Window.document.write("<table width='100%' border='1' cellspaceNG='0' cellpadding='0' bgcolor='#e0e0e0'>");
     Window.document.write("<tr>");

//alert('44444');
     // Prepare Source Field Array
     var lFieldSrcArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListSrc, ',', lFieldSrcArr );
     for ( lRecNum = 0; lRecNum < lFieldSrcArr.length; lRecNum++ )
     {
       Window.document.write("<th>");
       Window.document.write(lFieldSrcArr[lRecNum]);
       Window.document.write("</th>");
     }
     Window.document.write("</tr>");


//alert('55555');
     // Prepare Target Field Array
     var lFieldTrgArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListTrg, ',', lFieldTrgArr );

     for( lRecNum = parseInt(lRecOffSet) ; lRecNum < (parseInt(lRecOffSet)+parseInt(lPageRecCount)); lRecNum++ )
     {

        Window.document.write("<tr>");

        doubleClickPrepSelectTag( inSelectIndicator, lRecNum );

        for ( lDisplayFldNum = 0; lDisplayFldNum < lFieldSrcArr.length; lDisplayFldNum++ )
        {
          var lFieldValue = "";
          var lHtmlText   = "";

          lHtmlText = lHtmlText + " <td> ";
          lHtmlText = lHtmlText + " <input ";
          lHtmlText = lHtmlText + " type=\"hidden\" ";
          if ( lFieldSrcArr[lDisplayFldNum] == "ag_id" )
          {
            lFieldValue = lFaAccountGroupTabObjJSArr[lRecNum].ag_id;
            lHtmlText = lHtmlText + " name=\"ag_id"+"_ref_r"+(lRecNum+1)+"\" ";
            lHtmlText = lHtmlText + " id=\"ag_id"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          else 
         if (lFieldSrcArr[lDisplayFldNum] == "ag_name")
          {
            lFieldValue = lFaAccountGroupTabObjJSArr[lRecNum].ag_name;
            lHtmlText = lHtmlText + " name=\"ag_name"+"_ref_r"+(lRecNum+1)+"\" ";
            lHtmlText = lHtmlText + " id=\"ag_name"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          lHtmlText = lHtmlText + " value=\"";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "\">";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "</td>";

          Window.document.write( lHtmlText );
        }
        Window.document.write("</tr>");
     }

     Window.document.write("<tr>");
     Window.document.write("<td>");

//alert('66666');

     var lFieldTrgArrOnClickStr = "";
     var lFieldTrgArrIdx = 0;
     for ( lFieldTrgArrIdx = 0; lFieldTrgArrIdx < lFieldTrgArr.length; lFieldTrgArrIdx++ )
       lFieldTrgArrOnClickStr = lFieldTrgArrOnClickStr + " lFieldTrgArrSubmit["+lFieldTrgArrIdx+"] = '"+lFieldTrgArr[lFieldTrgArrIdx]+"';";
       
       
     Window.document.write( " <input type ='submit' "
                          + " align='center' "
                          + " name='submit' "
                          + " id = 'submit' "
                          + " value='Submit' "
                          + " onClick = \""
                          + "    var lParentRecOffset = "+(lRecOffSet+1)+";"
                          + "    var lNum = 0;"
                          + "    var lSelectObjId;"
                          + "    for ( lNum = "+(lRecOffSet+1)+"; lNum <= "+lRecOffSet+lPageRecCount+"; lNum++ )"
                          + "    {"
                          + "      lSelectObjId = document.getElementById('select_r'+lNum); "
                          + "      var lLoopBreakFlag = false;"
                          //+ "      alert( 'select_r'+lNum+' - '+lSelectObjId.value +' - '+lParentRecOffset+ ' - '+ "+lPageRecCount+");"
                          + "      if ( lSelectObjId.value == 'Y' ) "
                          + "      for ( lParentRecNum = 1; " + " lParentRecNum <= "+inRecOnPage+"; " + " lParentRecNum++) "
                          + "      {"
                          + "        var lFieldTrgArrSubmit = new Array("+lFieldTrgArr.length+");"
                          + "        "+lFieldTrgArrOnClickStr
                          + "        for ( lTargetFldNum = 0; lTargetFldNum < lFieldTrgArrSubmit.length; lTargetFldNum++ ) "
                          + "        { "
                          + "          var lParentFieldName = '';"
                          + "          lParentFieldName = lParentFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "          lParentFieldName = lParentFieldName+'_r';"
                          + "          lParentFieldName = lParentFieldName+lParentRecNum;"
                          //+ "          alert( 'parent field name '+lParentFieldName );"
                          //+ "          alert( self.opener.document.getElementById(lParentFieldName).value );"
                          + "          if ( self.opener.document.getElementById(lParentFieldName).value.length > 0 )"
                          + "            ;"
                          + "          else"
                          + "          {"
                          + "            if ( lFieldTrgArrSubmit[lTargetFldNum] == 'ag_id' )"
                          + "            {"
                          + "              var lPopFieldName = '';"
                          + "              lPopFieldName = lPopFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "              lPopFieldName = lPopFieldName+'_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
                          //+ "              alert( 'pop field name '+lPopFieldName );"
                          //+ "              alert( self.opener.document.getElementById(lParentFieldName).value );"
                          + "            }"
                          + "            self.opener.document.getElementById(lParentFieldName).value = document.getElementById(lPopFieldName).value;"
                          + "            lLoopBreakFlag = true;"
                          + "          }"
                          + "        }"
                          + "        if ( lLoopBreakFlag ) { break; }"
                          + "      }"
                          + "    }"
                          + "  \""
                          + " >");

     Window.document.write("</td>");
     Window.document.write("</tr>");

     Window.document.write("</table>");
     Window.document.write("</body>");
     Window.document.write("</html>");
}


function prepArrOfStrFromDlmtStr( inFieldListTrg, inDelimiter, lFieldTrgArr )
{
//alert('prepArrOfStrFromDlmtStr - start ');
     var lFieldListTrgTemp = '';
     var trueFalse = true;
     var lRecNum = 0;
     while( trueFalse )
     {
        if ( inFieldListTrg.indexOf( inDelimiter ) > 0 )
        {
           lFieldTrgArr[lRecNum] = inFieldListTrg.substring( 0, inFieldListTrg.indexOf( inDelimiter ) );
           lFieldListTrgTemp = inFieldListTrg.substring( inFieldListTrg.indexOf( inDelimiter )+1, inFieldListTrg.length );
           inFieldListTrg = '';
           inFieldListTrg = lFieldListTrgTemp;
           lRecNum++;
        }
        else
        {
           trueFalse = false;
           break;
        }
     }
//alert('prepArrOfStrFromDlmtStr - end ');
}
