  var Window;
  var lRecOffSet       = 0;
  var MAX_PAGE_REC_JS  = 5;
  var lRecOnPage       = MAX_PAGE_REC_JS;
  //var lRecCount        = lEsmItemTabObjJSArr.length;
  var lPageRecCount    = 0;
  var lRefreshFlag     = true;
  var lResetVarFlag    = 'X';
  var gTableName       = "";
  var gFieldListSrc    = "";
  var gFieldListTrg    = "";
  var gSelectIndicator = '';

  function firstPage() { lResetVarFlag = 'F'; }
  function lastPage()  { lResetVarFlag = 'L'; }
  function prevPage()  { lResetVarFlag = 'P'; }
  function nextPage()  { lResetVarFlag = 'N'; }

  function closeWin()
  {
    lRefreshFlag = true;
  }

  function resetGV()
  {
    //Window;
    lRecOffSet       = 0;
    MAX_PAGE_REC_JS  = 5;
    //lRecOnPage       = MAX_PAGE_REC_JS;
    lRecCount        = 0
    lPageRecCount    = 0;
    lRefreshFlag     = true;
    lResetVarFlag    = 'X';
    gTableName       = "";
    gFieldListSrc    = "";
    gFieldListTrg    = "";
    gSelectIndicator = '';
  }

