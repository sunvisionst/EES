  function dblClickEsmItem1( inRecOffSet, inRecOnPage, inColOnPage, inTableName, inFieldListSrc, inFieldListTrg, inSelectIndicator)
  {

     lRecCount        = lEesSubjectAllocationTabObjJSArr.length;
     doubleClickInit ( lResetVarFlag, lRecCount, lRecOnPage, inRecOnPage, inRecOffSet );

     //alert('Prabodh'+inColOnPage);
     gTableName = inTableName;
     gFieldListSrc = inFieldListSrc;
     gFieldListTrg = inFieldListTrg;
     gSelectIndicator = inSelectIndicator;

//     alert('22222 '+inRecOnPage+' '+inColOnPage);
     if ( lRefreshFlag )
     {
       lRecOffSet   = 0;
       lRecOnPage   = MAX_PAGE_REC_JS;
       lRecCount    = lEesSubjectAllocationTabObjJSArr.length;
       lRefreshFlag = false;
     }
     //alert('ArrSize'+lEesSubjectAllocationTabObjJSArr.length);
     Window = document.open("","","width=300,height=400,status=no,resizable=no,scrollbars=yes,top=200,left=200");
     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<html>");
     Window.document.write("<title>Select Record</title>");
     Window.document.write("<body>");

//alert('33332');
   //  doubleClickPrepActionBar();

     Window.document.write("<table width='100%' border='1' cellspaceNG='0' cellpadding='0' bgcolor='#e0e0e0'>");
     Window.document.write("<tr>");

//alert('44444');



     // Prepare Source Field Array
     var lFieldSrcArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListSrc, ',', lFieldSrcArr );
     

     Window.document.write("<th>Select</th>");
     var lThHeader;
     //alert('33332length'+lFieldSrcArr.length);
     for ( lRecNum = 0; lRecNum < lFieldSrcArr.length; lRecNum++ )
     {
       Window.document.write("<th>");
       if(lFieldSrcArr[lRecNum] == "subject_code")
          lThHeader = "Subject Code";
       if(lFieldSrcArr[lRecNum] == "employee_id")
          lThHeader = "Employee Id";
     //  if(lFieldSrcArr[lRecNum] == "class_id")
       //   lThHeader = "Class Id";
    //   if(lFieldSrcArr[lRecNum] == "class_section")
      //    lThHeader = "Class Section";
     //  if(lFieldSrcArr[lRecNum] == "course_id")
       //   lThHeader = "Course Id";
       Window.document.write(lThHeader);
       Window.document.write("</th>");
     }
     Window.document.write("</tr>");






//alert('55555');
     // Prepare Target Field Array
     var lFieldTrgArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListTrg, ',', lFieldTrgArr );

//     for( lRecNum = parseInt(lRecOffSet) ; lRecNum < (parseInt(lRecOffSet)+parseInt(lPageRecCount)); lRecNum++ )
     for( lRecNum = 0; lRecNum < lRecCount; lRecNum++ )
     {

        Window.document.write("<tr>");

        doubleClickPrepSelectTag( inSelectIndicator, lRecNum );

        for ( lDisplayFldNum = 0; lDisplayFldNum < lFieldSrcArr.length; lDisplayFldNum++ )
        {
          var lFieldValue = "";
          var lHtmlText   = "";

          lHtmlText = lHtmlText + " <td> ";
          lHtmlText = lHtmlText + " <input ";
          lHtmlText = lHtmlText + " type=\"hidden\" ";
          if ( lFieldSrcArr[lDisplayFldNum] == "subject_code" )
          {
            lFieldValue = lEesSubjectAllocationTabObjJSArr[lRecNum].subject_code;
            lHtmlText = lHtmlText + " name=\"subject_code"+"_ref_r"+(lRecNum+1)+"\" ";
            lHtmlText = lHtmlText + " id=\"subject_code"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          else 
          if (lFieldSrcArr[lDisplayFldNum] == "employee_id")
          {
             lFieldValue = lEesSubjectAllocationTabObjJSArr[lRecNum].employee_id;
             lHtmlText = lHtmlText + " name=\"employee_id"+"_ref_r"+(lRecNum+1)+"\" ";
             lHtmlText = lHtmlText + " id=\"employee_id"+"_ref_r"+(lRecNum+1)+"\" ";
          }
    //      else
      //    if (lFieldSrcArr[lDisplayFldNum] == "class_id")
          {
        //     lFieldValue = lEesSubjectAllocationTabObjJSArr[lRecNum].class_id;
          //   lHtmlText = lHtmlText + " name=\"class_id"+"_ref_r"+(lRecNum+1)+"\" ";
            // lHtmlText = lHtmlText + " id=\"class_id"+"_ref_r"+(lRecNum+1)+"\" ";
          }
       // else
   //       if (lFieldSrcArr[lDisplayFldNum] == "class_section")
          {
        //     lFieldValue = lEesSubjectAllocationTabObjJSArr[lRecNum].class_section;
      //       lHtmlText = lHtmlText + " name=\"class_section"+"_ref_r"+(lRecNum+1)+"\" ";
    //         lHtmlText = lHtmlText + " id=\"class_section"+"_ref_r"+(lRecNum+1)+"\" ";
          } 

        //  else
//          if (lFieldSrcArr[lDisplayFldNum] == "course_id")
          {
   //           lFieldValue = lEesSubjectAllocationTabObjJSArr[lRecNum].course_id;
   //          lHtmlText = lHtmlText + " name=\"course_id"+"_ref_r"+(lRecNum+1)+"\" ";
     //        lHtmlText = lHtmlText + " id=\"course_id"+"_ref_r"+(lRecNum+1)+"\" ";
          } 

          lHtmlText = lHtmlText + " value=\"";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "\">";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "</td>";

          Window.document.write( lHtmlText );
        }
        Window.document.write("</tr>");
     }

     Window.document.write("<tr>");
     Window.document.write("<td align='center' colspan = '3'>");
     //Window.document.write("<br>");


     var lFieldTrgArrOnClickStr = "";
     var lFieldTrgArrIdx = 0;
     for ( lFieldTrgArrIdx = 0; lFieldTrgArrIdx < lFieldTrgArr.length; lFieldTrgArrIdx++ )
       lFieldTrgArrOnClickStr = lFieldTrgArrOnClickStr 
                              + " lFieldTrgArrSubmit["
                              + lFieldTrgArrIdx+"] = '"
                              + lFieldTrgArr[lFieldTrgArrIdx]+"';";

     lPageRecCount = lRecCount;
     Window.document.write( " <input "
                          + " type  = 'submit' "
                          + " align = 'center' "
                          + " name  = 'submit' "
                          + " id    = 'submit' "
                          + " value = 'Submit' "
                          + " onClick = \""
                          //+ "    var lParentRecOffset = "+(lRecOffSet+1)+";"
                          + "    var lNum = 0;"
                          + "    var lSelectObjId;"
                          //+ "    alert('Before loop '+"+lRecOffSet+"+', '+"+lPageRecCount+");"
                          + "    for ( lNum = "+(lRecOffSet+1)+"; lNum <= "+lRecOffSet+lPageRecCount+"; lNum++ )"
                          + "    {"
                          //+ "      alert('inside loop '+lNum);"
                          + "      lSelectObjId = document.getElementById('select_r'+lNum); "
                          //+ "      alert('inside loop '+lSelectObjId.value);"
                          + "      var lLoopBreakFlag = false;"
                    //      + "      alert( 'select_r'+lNum+' - '+lSelectObjId.value +'  '+ "+lPageRecCount+"+' - '+"+inRecOnPage+");"
                          + "      if ( lSelectObjId.value == 'Y' ) "
                          + "      {"
                      //    + "        alert('lParentRecNum bef lop ');"
                          //+ "      var lParentRecNum = 0;"
                          //+ "      for ( lParentRecNum = 1; lParentRecNum <= "+inRecOnPage+"; lParentRecNum++) "
                          //+ "      for ( lParentRecNum = 1; lParentRecNum <= "+lPageRecCount+"; lParentRecNum++) "
                          //+ "      {"
               //           + "        alert('lParentRecNum '+lParentRecNum);"
                          + "        var lFieldTrgArrSubmit = new Array("+lFieldTrgArr.length+");"
                          + "        "+lFieldTrgArrOnClickStr
                          + "        for ( lTargetFldNum = 0; lTargetFldNum < lFieldTrgArrSubmit.length; lTargetFldNum++ ) "
                          + "        { "
                          + "          var lParentFieldName = '';"
                          + "          lParentFieldName = lParentFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "          lParentFieldName = lParentFieldName+'_r';"
                          + "          lParentFieldName = lParentFieldName+"+inRecOnPage+"+"+inColOnPage+";"
                    //      + "          alert( 'parent field name subject code value '+lParentFieldName );"
                   //       + "          alert( self.opener.document.getElementById(lParentFieldName).value );"
                          + "          if ( self.opener.document.getElementById(lParentFieldName).value.length > 0 )"
                          + "            ;"
                          + "          else"
                          + "          {"
                          + "            if ( lFieldTrgArrSubmit[lTargetFldNum] == 'subject_code' )"
                          + "            {"

                          //+ "                self.opener.document.getElementById('subject_code"
                          //                   +"_r"
                          //                   +inRecOnPage+"+"+inColOnPage
                          //                   +"').value "
                          //                   +" = "
                          //                   +" document.getElementById('subject_code"
                          //                   +"_ref_r"
                          //                   +lNum
                          //                   +"').value;"

                          + "              var lPopFieldName = '';"
                    //      + "              alert( 'pop field name '+lPopFieldName );"
                          + "              lPopFieldName = lPopFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "              lPopFieldName = lPopFieldName+'_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
                 //         + "              alert( 'pop field name '+lPopFieldName );"
              //            + "              alert( self.opener.document.getElementById(lParentFieldName).value );"
                          + "            }"
                          + "            else"
                          + "            if ( lFieldTrgArrSubmit[lTargetFldNum] == 'employee_id' )"
                          + "            {"

                          //+ "                self.opener.document.getElementById('employee_id"
                          //                   +"_r"
                          //                   +inRecOnPage+"+"+inColOnPage
                          //                   +"').value "
                          //                   +" = "
                          //                   +" document.getElementById('employee_id"
                          //                   +"_ref_r"
                          //                   +lNum
                          //                   +"').value;"

                          + "              var lPopFieldName = '';"
              //            + "              alert( 'pop field name '+lPopFieldName );"
                          + "              lPopFieldName = lPopFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "              lPopFieldName = lPopFieldName+'_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
               //           + "              alert( 'pop field name '+lPopFieldName );"
               //           + "              alert( self.opener.document.getElementById(lParentFieldName).value );"
                          + "              window.close();"
                          + "            }"
                          + "            self.opener.document.getElementById(lParentFieldName).value "
                          +              "= document.getElementById(lPopFieldName).value;"
                          + "            lLoopBreakFlag = true;"
                          + "          }"
                          + "        }"
                          + "        if ( lLoopBreakFlag ) { break; }"
                          //+ "      }"
                          + "      }"
                          + "    }"
                          + "  \""
                          + " >");

     Window.document.write("</td>");
     Window.document.write("</tr>");

     Window.document.write("</table>");
     Window.document.write("</body>");
     Window.document.write("</html>");
}


function prepArrOfStrFromDlmtStr( inFieldListTrg, inDelimiter, lFieldTrgArr )
{
//alert('prepArrOfStrFromDlmtStr - start ');
     var lFieldListTrgTemp = '';
     var trueFalse = true;
     var lRecNum = 0;
     while( trueFalse )
     {
        if ( inFieldListTrg.indexOf( inDelimiter ) > 0 )
        {
           lFieldTrgArr[lRecNum] = inFieldListTrg.substring( 0, inFieldListTrg.indexOf( inDelimiter ) );
           lFieldListTrgTemp = inFieldListTrg.substring( inFieldListTrg.indexOf( inDelimiter )+1, inFieldListTrg.length );
           inFieldListTrg = '';
           inFieldListTrg = lFieldListTrgTemp;
           lRecNum++;
        }
        else
        {
           trueFalse = false;
           break;
        }
     }
//alert('prepArrOfStrFromDlmtStr - end ');
}
