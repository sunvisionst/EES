function doubleClickPrepSelectTag( inSelectIndicator, lRecNum )
{
        Window.document.write("<td>");
        //Window.document.write("</br>");
        Window.document.write("<input "
                             +" type='text' "
                             +" name='select_r"+(lRecNum+1)+"' "
                             +" id='select_r"+(lRecNum+1)+"' "
                             +" size='1' "
                             +" value='N' "
                             +">" );

        if ( inSelectIndicator == 'C' )
        {
          Window.document.write( "<input "
                               + " type='checkbox' "
                               + " name='select_checkbox_ref"+lRecNum+"' "
                               + " id='select_checkbox_ref"+lRecNum+"'"
                               + " onClick =\""
                               //+ " var lRecNumJS = "+lRecNum+"; alert(lRecNumJS); "
                               + " var lCheckBoxObjId = select_checkbox_ref"+lRecNum+";" // +" alert(lCheckBoxObjId.name);"
                               + " var lSelectObjId   = select_r"+(lRecNum+1)+";"
                               + " var lCheckBoxChecked = lCheckBoxObjId.checked;" // +" alert( lCheckBoxChecked );"
                               + " var lReturnValue = 0;"
                               + " if ( lCheckBoxChecked )"
                               + "   lReturnValue = 'Y';"
                               + " else"
                               + "   lReturnValue = 'N';"
                               + " lCheckBoxObjId.value = lReturnValue; "
                               + " lSelectObjId.value = lCheckBoxObjId.value; "
                               //+ " select_checkbox_ref"+lRecNum+".value = lReturnValue; "
                               //+ " select_r"+lRecNum+".value = select_checkbox_ref"+lRecNum+".value; "
                               + " javascript:window.opener.toggleColour(this,'steelblue');"
                               + " \">");
        }
        else
        if ( inSelectIndicator == 'R' )
        {
          Window.document.write( " <input "
                               + " type='radio' "
                               + " name='select_radio_ref' "
                               + " id='select_radio_ref"+lRecNum+"' "
                               + " onClick=\""
                               //+ " resetRadio( 'select_radio_ref', "+parseInt(lRecOffSet)+", "+(parseInt(lRecOffSet)+parseInt(lPageRecCount))+");"
                               + " for ( lRedioIdx = "+parseInt(lRecOffSet)+"; lRedioIdx < "+(parseInt(lRecOffSet)+parseInt(lPageRecCount))+"; lRedioIdx++ )"
                               + " { "
                               + "   var lSelectFieldName = 'select_r'+(lRedioIdx+1);"
                               + "   var lSelectFieldObj  = document.getElementById(lSelectFieldName);"
                               + "   lSelectFieldObj.value = 'N';"
                               + " } "
                               + " var lRadioObjId = select_radio_ref"+lRecNum+";" //+ " alert('Radio Value '+lRadioObjId.value); "
                               //+ " alert('radio is clicked '+select_radio_ref["+lRecNum+"].value);"
                               + " var lSelectObjId   = select_r"+(lRecNum+1)+";"
                               + " if ( lRadioObjId.checked )" //+ " if ( select_radio["+(lRecNum-1)+"].checked );"
                               + " {"
                               + "   lSelectObjId.value = 'Y'; " //+ " alert('select_r '+select_r"+(lRecNum+1)+".value);"
                               + " }"
                               + " else"
                               + " {"
                               + "   lSelectObjId.value = 'N'; " //+ " alert(lSelectObjId.value); "
                               + " }"
                               //+ " javascript:window.opener.radioFunctionUB();"
                               + " \">");
        }

        Window.document.write("</td>");
}
