  function dblClickEsmItem1( inRecOffSet, inRecOnPage, inTableName, inFieldListSrc, inFieldListTrg, inSelectIndicator)
  {
   lRecCount        = lFaGlAccountTabObjJSArr.length;
     doubleClickInit ( lResetVarFlag, lRecCount, lRecOnPage, inRecOnPage, inRecOffSet );

     gTableName       = inTableName;
     gFieldListSrc    = inFieldListSrc;
     gFieldListTrg    = inFieldListTrg;
     gSelectIndicator = inSelectIndicator;

     if ( lRefreshFlag )
     {
       lRecOffSet   = 0;
       lRecOnPage   = MAX_PAGE_REC_JS;
       lRecCount    = lFaGlAccountTabObjJSArr.length;;
       lRefreshFlag = false;
     }

   //Window = document.open("","","width=300,height=400,status=no,resizable=no,top=200,left=200");
     Window = document.open("","","width=350,height=400,status=no,resizable=no,scrollbars=yes,top=200,left=200");
     Window.document.bgColor = "lightblue";
     Window.document.write("<html>");
     Window.document.write("<title>Select Record</title>");
     Window.document.write("<body>");

    // doubleClickPrepActionBar();

     Window.document.write("<table width='100%' border='1' cellspaceNG='0' cellpadding='0' bgcolor='#e0e0e0'>");
     Window.document.write("<tr>");

     var lFieldSrcArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListSrc, ',', lFieldSrcArr );

     Window.document.write("<th>Select</th>");
     var lThHeader;

     for ( lRecNum = 0; lRecNum < lFieldSrcArr.length; lRecNum++ )
     {
       Window.document.write("<th>");
       if(lFieldSrcArr[lRecNum] == "account_id")
         lThHeader = "Account Number";
       if(lFieldSrcArr[lRecNum] == "account_name")
         lThHeader = "Account Name";
       if(lFieldSrcArr[lRecNum] == "ag_id")
          lThHeader = "A/C Group ID";
       if(lFieldSrcArr[lRecNum] == "lag_id")
          lThHeader = "Link A/C Group ID";

       Window.document.write(lThHeader);
       Window.document.write("</th>");
     }
     Window.document.write("</tr>");

     // Prepare Target Field Array
     var lFieldTrgArr = new Array();
     prepArrOfStrFromDlmtStr( inFieldListTrg, ',', lFieldTrgArr );

     for( lRecNum = 0; lRecNum < lRecCount; lRecNum++ )
     {
        Window.document.write("<tr>");

        doubleClickPrepSelectTag( inSelectIndicator, lRecNum );

        for ( lDisplayFldNum = 0; lDisplayFldNum < lFieldSrcArr.length; lDisplayFldNum++ )
        {
          var lFieldValue = "";
          var lHtmlText   = "";

          lHtmlText = lHtmlText + " <td> ";
          lHtmlText = lHtmlText + " <input ";
          lHtmlText = lHtmlText + " type=\"hidden\" ";

          if (lFieldSrcArr[lDisplayFldNum] == "account_id")
          {
             lFieldValue = lFaGlAccountTabObjJSArr[lRecNum].account_id;
             lHtmlText = lHtmlText + " name=\"account_num"+"_ref_r"+(lRecNum+1)+"\" ";
             lHtmlText = lHtmlText + " id=\"account_num"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          else
          if (lFieldSrcArr[lDisplayFldNum] == "account_name")
          {
             lFieldValue = lFaGlAccountTabObjJSArr[lRecNum].account_name;
             lHtmlText = lHtmlText + " name=\"account_name"+"_ref_r"+(lRecNum+1)+"\" ";
             lHtmlText = lHtmlText + " id=\"account_name"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          else
          if ( lFieldSrcArr[lDisplayFldNum] == "ag_id" )
          {
          lFieldValue = lFaGlAccountTabObjJSArr[lRecNum].ag_id;
          lHtmlText = lHtmlText + " name=\"ag_id"+"_ref_r"+(lRecNum+1)+"\" ";
          lHtmlText = lHtmlText + " id=\"ag_id"+"_ref_r"+(lRecNum+1)+"\" ";
          }
          else
          if (lFieldSrcArr[lDisplayFldNum] == "lag_id")
          {
             lFieldValue = lFaGlAccountTabObjJSArr[lRecNum].lag_id;
             lHtmlText = lHtmlText + " name=\"lag_id"+"_ref_r"+(lRecNum+1)+"\" ";
             lHtmlText = lHtmlText + " id=\"lag_id"+"_ref_r"+(lRecNum+1)+"\" ";
          }

          lHtmlText = lHtmlText + " value=\"";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "\">";
          lHtmlText = lHtmlText + lFieldValue;
          lHtmlText = lHtmlText + "</td>";

          Window.document.write( lHtmlText );
        }
        Window.document.write("</tr>");
     }


     Window.document.write("<tr>");
     Window.document.write("<td align='center' colspan = '3'>");

     var lFieldTrgArrOnClickStr = "";
     var lFieldTrgArrIdx = 0;
     for ( lFieldTrgArrIdx = 0; lFieldTrgArrIdx < lFieldTrgArr.length; lFieldTrgArrIdx++ )
     lFieldTrgArrOnClickStr = lFieldTrgArrOnClickStr + " lFieldTrgArrSubmit["+lFieldTrgArrIdx+"] = '"+lFieldTrgArr[lFieldTrgArrIdx]+"';";
       
     lPageRecCount = lRecCount;  
     Window.document.write( " <input type ='submit' "
                          + " align='center' "
                          + " name='submit' "
                          + " id = 'submit' "
                          + " value='Submit' "
                          + " onClick = \""
                          + "    var lParentRecOffset = "+(lRecOffSet+1)+";"
                          + "    var lNum = 0;"
                          + "    var lSelectObjId;"
                          + "    for ( lNum = "+(lRecOffSet+1)+"; lNum <= "+lRecOffSet+lPageRecCount+"; lNum++ )"
                          + "    {"
                          + "      lSelectObjId = document.getElementById('select_r'+lNum); "
                          + "      var lLoopBreakFlag = false;"
                          + "      if ( lSelectObjId.value == 'Y' ) "
                          + "      {"
                        //  + "     for ( lParentRecNum = 1; " + " lParentRecNum <= "+inRecOnPage+"; " + " lParentRecNum++) "
                         // + "      {"
                          + "        var lFieldTrgArrSubmit = new Array("+lFieldTrgArr.length+");"
                          + "        "+lFieldTrgArrOnClickStr
                          + "        for ( lTargetFldNum = 0; lTargetFldNum < lFieldTrgArrSubmit.length; lTargetFldNum++ ) "
                          + "        { "
                          + "          var lParentFieldName = '';"
                          + "          lParentFieldName = lParentFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "          if ( self.opener.document.getElementById(lParentFieldName).value.length > 0 )"
                          + "            ;"
                          + "          else"
                          + "          {"
                        //  + "              alert('SHAIL'+lFieldTrgArrSubmit[lTargetFldNum]);"


                          + "            if ( lFieldTrgArrSubmit[lTargetFldNum] == 'ag_id' )"
                          + "            {"
                          + "              var lPopFieldName = '';"
                       //   + "              lPopFieldName = lPopFieldName+lFieldTrgArrSubmit[lTargetFldNum];"
                          + "              lPopFieldName = lPopFieldName+'ag_id_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
                          + "            }"
                          + "            else if ( lFieldTrgArrSubmit[lTargetFldNum] == 'account_num' )"                                               + "            {"
                          + "              var lPopFieldName = '';"
                          + "              lPopFieldName = lPopFieldName+'account_num_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
                          + "            }"
                          + "            else if ( lFieldTrgArrSubmit[lTargetFldNum] == 'lag_id' )"
                          + "            {"
                          + "              var lPopFieldName = '';"
                          + "              lPopFieldName = lPopFieldName+'lag_id_ref_r';"
                          + "              lPopFieldName = lPopFieldName+lNum;"
                          + "              window.close();"
                          + "            }"
                          + "            self.opener.document.getElementById(lParentFieldName).value = document.getElementById(lPopFieldName).value;"
                          + "            lLoopBreakFlag = true;"
                          + "          }"
                          + "        }"
                          + "        if ( lLoopBreakFlag ) { break; }"
                          + "      }"
                          + "    }"
                          + "  \""
                          + " >");

     Window.document.write("</td>");
     Window.document.write("</tr>");
     Window.document.write("</table>");
     Window.document.write("</body>");
     Window.document.write("</html>");
}


function prepArrOfStrFromDlmtStr( inFieldListTrg, inDelimiter, lFieldTrgArr )
{
//alert('prepArrOfStrFromDlmtStr - start ');
     var lFieldListTrgTemp = '';
     var trueFalse = true;
     var lRecNum = 0;
     while( trueFalse )
     {
        if ( inFieldListTrg.indexOf( inDelimiter ) > 0 )
        {
           lFieldTrgArr[lRecNum] = inFieldListTrg.substring( 0, inFieldListTrg.indexOf( inDelimiter ) );
           lFieldListTrgTemp = inFieldListTrg.substring( inFieldListTrg.indexOf( inDelimiter )+1, inFieldListTrg.length );
           inFieldListTrg = '';
           inFieldListTrg = lFieldListTrgTemp;
           lRecNum++;
        }
        else
        {
           trueFalse = false;
           break;
        }
     }
//alert('prepArrOfStrFromDlmtStr - end ');
}
