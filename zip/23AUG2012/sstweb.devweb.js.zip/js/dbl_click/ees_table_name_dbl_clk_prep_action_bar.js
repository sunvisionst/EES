function doubleClickPrepActionBar()
{
     Window.document.write("<table width='100%' border='1' cellspacing='0' cellpadding='0' bgcolor='#e0e0e0'>");
     Window.document.write("<tr>");
     Window.document.write( "<td align='center'>[<a href=\""
                          + "javascript:window.opener.dblClickEsmItem1"
                          + "("
                          + parseInt(0)
                          + "  ," + parseInt(this.lRecOnPage)
                          + ", '" + this.gTableName + "'"
                          + ", '" + this.gFieldListSrc + "'"
                          + ", '" + this.gFieldListTrg + "'"
                          + ", '" + this.gSelectIndicator + "'"
                          + " );"
                          + " javascript:self.close();"
                          + " \"onClick = 'self.opener.firstPage();'><<<<\/a>]</td>");

     Window.document.write( "<td align='center'>[<a href=\""
                          + "javascript:window.opener.dblClickEsmItem1"
                          + "("
                          + "  '" + parseInt(this.lRecOffSet) + "'"
                          + ", '" + parseInt(this.lRecOnPage) + "'"
                          + ", '" + this.gTableName + "'"
                          + ", '" + this.gFieldListSrc + "'"
                          + ", '" + this.gFieldListTrg + "'"
                          + ", '" + this.gSelectIndicator + "'"
                          + ");"
                          + " javascript:self.close();"
                          + "\"onClick = 'self.opener.prevPage();'><<<\/a>]</td>");

     Window.document.write( "<td align='center'>[<a href=\""
                          + "javascript:window.opener.dblClickEsmItem1"
                          + "("
                          + "  '" + parseInt(this.lRecOffSet) + "'"
                          + ", '" + parseInt(this.lRecOnPage) + "'"
                          + ", '" + this.gTableName + "'"
                          + ", '" + this.gFieldListSrc + "'"
                          + ", '" + this.gFieldListTrg + "'"
                          + ", '" + this.gSelectIndicator + "'"
                          + ");"
                          + " javascript:self.close();"
                          + "\"onClick = 'self.opener.nextPage();'>>><\/a>]</td>");

     Window.document.write( "<td align='center'>[<a href=\""
                          + "javascript:window.opener.dblClickEsmItem1"
                          + "("
                          + parseInt(0)
                          + ", " + parseInt(this.lRecOnPage)
                          + ", '" + this.gTableName + "'"
                          + ", '" + this.gFieldListSrc + "'"
                          + ", '" + this.gFieldListTrg + "'"
                          + ", '" + this.gSelectIndicator + "'"
                          + ");"
                          + "javascript:self.close();"
                          + "\"onClick='self.opener.lastPage();'>>>><\/a>]</td>");

     Window.document.write("</tr>");
     Window.document.write("</table>");
     Window.document.write("<br>");
}

