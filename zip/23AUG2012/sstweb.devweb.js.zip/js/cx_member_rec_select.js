function CxMemberRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("member_id").value  = document.getElementById("member_id"+"_r"+inRecNum).value; 
    document.getElementById("member_name").value  = document.getElementById("member_name"+"_r"+inRecNum).value; 
    document.getElementById("link_member_id").value  = document.getElementById("link_member_id"+"_r"+inRecNum).value; 
    document.getElementById("member_type").value  = document.getElementById("member_type"+"_r"+inRecNum).value; 
    document.getElementById("role_type").value  = document.getElementById("role_type"+"_r"+inRecNum).value; 
    //--------------------------------------------------------
    var lRoleType = document.getElementById("role_type"+"_r"+inRecNum);
    if ( lRoleType && lRoleType.value == '2' )
    {
      document.getElementById('lable_member_id').innerHTML = 'Client Id';
      document.getElementById('lable_member_name').innerHTML = 'Client Name';
      document.getElementById('link_member_id_tr').style.display = '';
      document.getElementById('num_client_limit_tr').style.display = 'none';
    }
    else
    //+" if ( lRoleType.value == '1' )
    {
      document.getElementById('lable_member_id').innerHTML = 'Member Id';
      document.getElementById('lable_member_name').innerHTML = 'Member Name';
      document.getElementById('link_member_id_tr').style.display = 'none';
      if ( lRoleType.value == '1' )
        document.getElementById('num_client_limit_tr').style.display = '';
      else
        document.getElementById('num_client_limit_tr').style.display = 'none';
    }
    //--------------------------------------------------------
    document.getElementById("cr_limit").value  = document.getElementById("cr_limit"+"_r"+inRecNum).value; 
    document.getElementById("num_client_limit").value  = document.getElementById("num_client_limit"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_change_cnt").value  = document.getElementById("pswd_change_cnt"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_0").value  = document.getElementById("pswd_0"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_1").value  = document.getElementById("pswd_1"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_2").value  = document.getElementById("pswd_2"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_3").value  = document.getElementById("pswd_3"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_4").value  = document.getElementById("pswd_4"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_5").value  = document.getElementById("pswd_5"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_6").value  = document.getElementById("pswd_6"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_7").value  = document.getElementById("pswd_7"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_8").value  = document.getElementById("pswd_8"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_9").value  = document.getElementById("pswd_9"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_10").value  = document.getElementById("pswd_10"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_11").value  = document.getElementById("pswd_11"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_12").value  = document.getElementById("pswd_12"+"_r"+inRecNum).value; 
    //document.getElementById("pswd_effective_date").value  = document.getElementById("pswd_effective_date"+"_r"+inRecNum).value; 
    //document.getElementById("expiry_period").value  = document.getElementById("expiry_period"+"_r"+inRecNum).value; 
    //document.getElementById("hint").value  = document.getElementById("hint"+"_r"+inRecNum).value; 
    //document.getElementById("hint_ans").value  = document.getElementById("hint_ans"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value; 
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value; 
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value; 
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value; 
    document.getElementById("auth_rep_name").value  = document.getElementById("auth_rep_name"+"_r"+inRecNum).value; 
    document.getElementById("auth_rep_father_name").value  = document.getElementById("auth_rep_father_name"+"_r"+inRecNum).value; 
    document.getElementById("auth_rep_phone_list").value  = document.getElementById("auth_rep_phone_list"+"_r"+inRecNum).value; 
    document.getElementById("pd_bal").value  = document.getElementById("pd_bal"+"_r"+inRecNum).value; 
    document.getElementById("cd_bal").value  = document.getElementById("cd_bal"+"_r"+inRecNum).value; 
    document.getElementById("cd_dr").value  = document.getElementById("cd_dr"+"_r"+inRecNum).value; 
    document.getElementById("cd_cr").value  = document.getElementById("cd_cr"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("member_id").value  = '';
    document.getElementById("member_name").value  = '';
    document.getElementById("link_member_id").value  = '';
    document.getElementById("member_type").value  = '';
    document.getElementById("role_type").value  = '';
    document.getElementById('link_member_id_tr').style.display = 'none';
    document.getElementById("cr_limit").value  = '';
    document.getElementById("num_client_limit").value  = '';
    //document.getElementById("remark").value  = '';
    //document.getElementById("pswd_change_cnt").value  = '';
    //document.getElementById("pswd_0").value  = '';
    //document.getElementById("pswd_1").value  = '';
    //document.getElementById("pswd_2").value  = '';
    //document.getElementById("pswd_3").value  = '';
    //document.getElementById("pswd_4").value  = '';
    //document.getElementById("pswd_5").value  = '';
    //document.getElementById("pswd_6").value  = '';
    //document.getElementById("pswd_7").value  = '';
    //document.getElementById("pswd_8").value  = '';
    //document.getElementById("pswd_9").value  = '';
    //document.getElementById("pswd_10").value  = '';
    //document.getElementById("pswd_11").value  = '';
    //document.getElementById("pswd_12").value  = '';
    //document.getElementById("pswd_effective_date").value  = '';
    //document.getElementById("expiry_period").value  = '';
    //document.getElementById("hint").value  = '';
    //document.getElementById("hint_ans").value  = '';
    document.getElementById("status").value  = '';
    //document.getElementById("rec_cre_date").value  = '';
    //document.getElementById("rec_cre_time").value  = '';
    //document.getElementById("rec_upd_date").value  = '';
    //document.getElementById("rec_upd_time").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("state").value  = '';
    document.getElementById("zip").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("phone_list").value  = '';
    document.getElementById("email_list").value  = '';
    document.getElementById("fax_list").value  = '';
    document.getElementById("auth_rep_name").value  = '';
    document.getElementById("auth_rep_father_name").value  = '';
    document.getElementById("auth_rep_phone_list").value  = '';
    document.getElementById("pd_bal").value  = '';
    document.getElementById("cd_bal").value  = '';
    document.getElementById("cd_dr").value  = '';
    document.getElementById("cd_cr").value  = '';
  }
}
