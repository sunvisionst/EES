
function calcTrgtCurAmt(inRecNum, inItemQty, inUnitRate, inExpCur,inTrgtCur, inTargetField , inDummyInd)
{
   alert("Calculate Trgt Amt");
   var lRecNum         = inRecNum ;
   var lItemQty        = inItemQty ;
   var lUnitRate       = inUnitRate ;
   var lExpCur         = inItemQty ;
   var lTrgtCur        = inTrgtCur ;

   var lTargetField    = inTargetField ;

   var lItemQty         = document.getElementById(lItemQty+lRecNum);
   var lUnitRate        = document.getElementById(lUnitRate+lRecNum);
   var lTargetFieldObj  = document.getElementById(lTargetField+lRecNum);
 
   var lValue;

   lValue = ((lItemQty.value*lUnitRate.value)*lExpCur/lTrgtCur);
    
   lTargetFieldObj.value = lValue ;

   if ( inDummyInd == 'Y' )
   {
     var lDummyObj;
     lDummyObj = document.getElementById(lTargetFieldObj.name+"_dummy");
     lDummyObj.value = lValue;
   }
}
