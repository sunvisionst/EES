<!--Write all Servlet specific JS File Includes here -->

<!-- Write Servlet Specific js include here -->
<script language="javascript" src="../js/ees_lab_eqp_rec_select.js"> </script>

<!-- Write Table Specific js include here -->
<script language="javascript" src="../js/tabobj/EesLabEqpTabObj.js"> </script>

<!-- Write all Generic js include here -->
<script language="javascript" src="../js/gn_confMultiNotNullById.js"> </script>
<script language="javascript" src="../js/gn_radioFunctionUB.js"> </script>
<script language="javascript" src="../js/gn_date_validation.js"> </script>
<script language="javascript" src="../js/gn_date_picker.js"> </script>
<script language="javascript" src="../js/gn_checkBoxFunction.js"> </script>
<script language="javascript" src="../js/gn_changeTableRowColor.js"> </script>
<script language="javascript" src="../js/gn_uniqueSelectionRadioCheckBox.js"> </script>
<script language="javascript" src="../js/gn_getElementIdByWindowEvent.js"> </script>
<script language="javascript" src="../js/gn_toolTip.js"> </script>
<script language="javascript" src="../js/gn_refresh_element_ajax.js"> </script>
<script language="javascript" src="../js/gn_prep_dd_option.js"> </script>
<script language="javascript" src="../js/gn_validate_time_format.js"> </script>
<script language="javascript" src="../js/gn_add_opt_val_all.js"> </script>
<script language="javascript" src="../js/gn_TimePicker.js"> </script>
<script language="javascript" src="../js/gn_chkNoRadioSelect.js"> </script>
<script language="javascript" src="../js/gn_chkNoCheckboxSelect.js"> </script>
<script language="javascript" src="../js/gn_number_function.js"> </script>
