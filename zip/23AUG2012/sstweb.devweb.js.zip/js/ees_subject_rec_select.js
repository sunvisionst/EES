function EesSubjectRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("short_subject_code").value  = document.getElementById("short_subject_code"+"_r"+inRecNum).value;
    document.getElementById("subject_code").value        = document.getElementById("subject_code"+"_r"+inRecNum).value;
    document.getElementById("short_subject_code").disabled  = true ;
    document.getElementById("description").value         = document.getElementById("description"+"_r"+inRecNum).value;
    //document.getElementById("num_of_lecture").value    = document.getElementById("num_of_lecture"+"_r"+inRecNum).value;
    //document.getElementById("per_week_lecture").value  = document.getElementById("per_week_lecture"+"_r"+inRecNum).value;
    //if ( document.getElementById("org_ctg").value == "I" )
    //{
    //  document.getElementById("course_id").value           = document.getElementById("course_id"+"_r"+inRecNum).value;
    //  document.getElementById("course_term").value         = document.getElementById("course_term"+"_r"+inRecNum).value;
    //}
    //if ( document.getElementById("course_stream_query") != null && document.getElementById("course_stream_query").value.length > 0  )
    //  document.getElementById("course_stream").value       = document.getElementById("course_stream"+"_r"+inRecNum).value;
    //alert( document.getElementById("subject_type"+"_r"+inRecNum).value );
    document.getElementById("subject_type").value        = document.getElementById("subject_type"+"_r"+inRecNum).value;
    document.getElementById("subject_ctg").value         = document.getElementById("subject_ctg"+"_r"+inRecNum).value;
    document.getElementById("cont_period_ind").value     = document.getElementById("cont_period_ind"+"_r"+inRecNum).value;
    document.getElementById("per_day_lecture").value     = document.getElementById("per_day_lecture"+"_r"+inRecNum).value;
    //document.getElementById("max_mark").value          = document.getElementById("max_mark"+"_r"+inRecNum).value;
    //document.getElementById("remark").value            = document.getElementById("remark"+"_r"+inRecNum).value;
    if ( document.getElementById("subject_ctg"+"_r"+inRecNum).value == 'T' )
      document.getElementById("lab_type_tr").style.display = 'none';
    else
    if ( document.getElementById("subject_ctg"+"_r"+inRecNum).value == 'P' )
      document.getElementById("lab_type_tr").style.display = '';
    document.getElementById("lab_type").value            = document.getElementById("lab_type"+"_r"+inRecNum).value;
    document.getElementById("elective_flag").value       = document.getElementById("elective_flag"+"_r"+inRecNum).value;
    if ( document.getElementById("elective_flag"+"_r"+inRecNum).value == 'N' )
      document.getElementById("elective_flag_href_tr").style.display = 'none';
    else
      document.getElementById("elective_flag_href_tr").style.display = '';
    document.getElementById("tt_ind").value              = document.getElementById("tt_ind"+"_r"+inRecNum).value;
    document.getElementById("sbmf_ind").value            = document.getElementById("sbmf_ind"+"_r"+inRecNum).value;
    document.getElementById("sbmc_ind").value            = document.getElementById("sbmc_ind"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value             = '' ;
    document.getElementById("short_subject_code").value   = '' ;
    document.getElementById("short_subject_code").disabled= false ;
    document.getElementById("subject_code").value         = '' ;
    document.getElementById("description").value          = '' ;
    //document.getElementById("num_of_lecture").value     = '' ;
    //document.getElementById("per_week_lecture").value   = '' ;
    //if ( document.getElementById("org_ctg").value == "I" )
    //{
    //  document.getElementById("course_id").value            = '' ;
    //  document.getElementById("course_term").value          = '' ;
    //}
    //if ( document.getElementById("course_stream_query") != null && document.getElementById("course_stream_query").value.length > 0  )
    //  document.getElementById("course_stream").value        = '' ;
    document.getElementById("subject_type").value         = '' ;
    document.getElementById("subject_ctg").value          = 'T' ;
    document.getElementById("cont_period_ind").value      = 'N' ;
    document.getElementById("per_day_lecture").value      = '1' ;
    //document.getElementById("max_mark").value           = '' ;
    //document.getElementById("remark").value             = '' ;
    document.getElementById("lab_type_tr").style.display = 'none';
    document.getElementById("lab_type").value             = '' ;
    document.getElementById("elective_flag").value        = 'N' ;
    document.getElementById("elective_flag_href_tr").style.display = 'none';
    document.getElementById("tt_ind").value               = 'Y';
    document.getElementById("sbmf_ind").value             = 'N';
    document.getElementById("sbmc_ind").value             = 'N';
  }
}
