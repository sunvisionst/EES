function setchkNoRadioSelectNew()
{
  var truefalse = false
  var lRecNum   = 0;

  for(lRecNum=0; lRecNum < 10; lRecNum++)
  {
    if ( document.form.select_radio[lRecNum-1].checked )
    {
      truefalse = true;
    }
  }
   if(!truefalse)
    {
     alert("Please Select RadioButton to continue ")
     window.event.returnValue=false;
    }
}

