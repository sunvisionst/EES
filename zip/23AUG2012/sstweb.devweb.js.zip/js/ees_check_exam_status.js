function lCheckStatus(inRecNum)
{
  //nSelectFlag, inRecNum
  //var lExamSchStatus = document.getElementById("exam_sch_status"+"_r"+inRecNum).value;
  var lExamSchStatus = document.getElementById("exam_status"+"_r"+inRecNum).value;
  if( lExamSchStatus == 'O' )
  {
    document.getElementById('submit1').disabled = 0;
    document.getElementById('submit2').disabled = 0;
    document.getElementById('submit3').disabled = 1;
  }
  else 
  if( lExamSchStatus == 'A' )
  {
    document.getElementById('submit1').disabled = 1;
    document.getElementById('submit2').disabled = 1;
    document.getElementById('submit3').disabled = 0;
  }
  else 
  if( lExamSchStatus == 'C' )
  {
    document.getElementById('submit1').disabled = 1;
    document.getElementById('submit2').disabled = 1;
    document.getElementById('submit3').disabled = 1;
  }
  //alert(inRecNum);
  //alert(nSelectFlag);
}
