function EsmItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("item_code").value  = document.getElementById("item_code"+"_r"+inRecNum).value; 
    document.getElementById("group_0").value  = document.getElementById("group_0"+"_r"+inRecNum).value; 
    document.getElementById("group_1").value  = document.getElementById("group_1"+"_r"+inRecNum).value; 
    document.getElementById("group_2").value  = document.getElementById("group_2"+"_r"+inRecNum).value; 
    //document.getElementById("group_3").value  = document.getElementById("group_3"+"_r"+inRecNum).value; 
    //document.getElementById("group_4").value  = document.getElementById("group_4"+"_r"+inRecNum).value; 
    //document.getElementById("group_5").value  = document.getElementById("group_5"+"_r"+inRecNum).value; 
    //document.getElementById("group_6").value  = document.getElementById("group_6"+"_r"+inRecNum).value; 
    //document.getElementById("size_uom").value  = document.getElementById("size_uom"+"_r"+inRecNum).value; 
    //document.getElementById("l").value  = document.getElementById("l"+"_r"+inRecNum).value; 
    //document.getElementById("w").value  = document.getElementById("w"+"_r"+inRecNum).value; 
    //document.getElementById("h").value  = document.getElementById("h"+"_r"+inRecNum).value; 
    //document.getElementById("related_item_code").value  = document.getElementById("related_item_code"+"_r"+inRecNum).value; 
    //document.getElementById("accessory_flag").value  = document.getElementById("accessory_flag"+"_r"+inRecNum).value; 
    //document.getElementById("tax_flag").value  = document.getElementById("tax_flag"+"_r"+inRecNum).value; 
    //document.getElementById("tax_percent").value  = document.getElementById("tax_percent"+"_r"+inRecNum).value; 
    //document.getElementById("item_type").value  = document.getElementById("item_type"+"_r"+inRecNum).value; 
    document.getElementById("item_desc").value  = document.getElementById("item_desc"+"_r"+inRecNum).value; 
    //document.getElementById("item_desc_cust").value  = document.getElementById("item_desc_cust"+"_r"+inRecNum).value; 
    //document.getElementById("item_part_num").value  = document.getElementById("item_part_num"+"_r"+inRecNum).value; 
    //document.getElementById("uom_per_qty").value  = document.getElementById("uom_per_qty"+"_r"+inRecNum).value; 
    //document.getElementById("weight_per_qty").value  = document.getElementById("weight_per_qty"+"_r"+inRecNum).value; 
    //document.getElementById("chees_pcs").value  = document.getElementById("chees_pcs"+"_r"+inRecNum).value; 
    //document.getElementById("finish_pcs").value  = document.getElementById("finish_pcs"+"_r"+inRecNum).value; 
    document.getElementById("min_stock_qty").value  = document.getElementById("min_stock_qty"+"_r"+inRecNum).value; 
    //document.getElementById("item_seq_num").value  = document.getElementById("item_seq_num"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("item_code").value  = '';
    document.getElementById("group_0").value  = '';
    document.getElementById("group_1").value  = '';
    document.getElementById("group_2").value  = '';
    //document.getElementById("group_3").value  = '';
    //document.getElementById("group_4").value  = '';
    //document.getElementById("group_5").value  = '';
    //document.getElementById("group_6").value  = '';
    //document.getElementById("size_uom").value  = '';
    //document.getElementById("l").value  = '';
    //document.getElementById("w").value  = '';
    //document.getElementById("h").value  = '';
    //document.getElementById("related_item_code").value  = '';
    //document.getElementById("accessory_flag").value  = '';
    //document.getElementById("tax_flag").value  = '';
    //document.getElementById("tax_percent").value  = '';
    //document.getElementById("item_type").value  = '';
    document.getElementById("item_desc").value  = '';
    //document.getElementById("item_desc_cust").value  = '';
    //document.getElementById("item_part_num").value  = '';
    //document.getElementById("uom_per_qty").value  = '';
    //document.getElementById("weight_per_qty").value  = '';
    //document.getElementById("chees_pcs").value  = '';
    //document.getElementById("finish_pcs").value  = '';
    document.getElementById("min_stock_qty").value  = '';
    //document.getElementById("item_seq_num").value  = '';
  }
}
