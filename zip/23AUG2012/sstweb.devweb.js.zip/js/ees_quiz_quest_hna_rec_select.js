function EesQuizQuestRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("paper_grp_cd").value  = document.getElementById("paper_grp_cd"+"_r"+inRecNum).value; 
    document.getElementById("question_seq_num").value  = document.getElementById("question_seq_num"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    //document.getElementById("exam_id").value  = document.getElementById("exam_id"+"_r"+inRecNum).value; 
    //document.getElementById("paper_id").value  = document.getElementById("paper_id"+"_r"+inRecNum).value; 
    //document.getElementById("exam_term").value  = document.getElementById("exam_term"+"_r"+inRecNum).value; 
    //document.getElementById("exam_type").value  = document.getElementById("exam_type"+"_r"+inRecNum).value; 
    //document.getElementById("exam_date").value  = document.getElementById("exam_date"+"_r"+inRecNum).value; 
    //document.getElementById("prepared_by").value  = document.getElementById("prepared_by"+"_r"+inRecNum).value; 
    document.getElementById("question_num").value  = document.getElementById("question_num"+"_r"+inRecNum).value; 
    document.getElementById("question_text").value  = document.getElementById("question_text"+"_r"+inRecNum).value; 
    document.getElementById("mandatory_flag").value  = document.getElementById("mandatory_flag"+"_r"+inRecNum).value; 
    document.getElementById("max_mark").value  = document.getElementById("max_mark"+"_r"+inRecNum).value; 
    //document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value; 
    //document.getElementById("topic_id").value  = document.getElementById("topic_id"+"_r"+inRecNum).value; 
    document.getElementById("topic_desc").value  = document.getElementById("topic_desc"+"_r"+inRecNum).value; 
    //document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    //document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    //document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    //document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    //document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    //document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    //document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("js_act_code").value  = document.getElementById("js_act_code"+"_r"+inRecNum).value; 
    document.getElementById("num_opt").value  = document.getElementById("num_opt"+"_r"+inRecNum).value; 
    document.getElementById("num_ans").value  = document.getElementById("num_ans"+"_r"+inRecNum).value; 
    document.getElementById("display_type").value  = document.getElementById("display_type"+"_r"+inRecNum).value; 
    document.getElementById("ans_in_one_line").value  = document.getElementById("ans_in_one_line"+"_r"+inRecNum).value; 
    document.getElementById("question_level").value  = document.getElementById("question_level"+"_r"+inRecNum).value; 
    document.getElementById("quest_dur_sec").value  = document.getElementById("quest_dur_sec"+"_r"+inRecNum).value; 
    document.getElementById("is_img_quest").value  = document.getElementById("is_img_quest"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_1").value  = document.getElementById("opt_text_1"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_2").value  = document.getElementById("opt_text_2"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_3").value  = document.getElementById("opt_text_3"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_4").value  = document.getElementById("opt_text_4"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_5").value  = document.getElementById("opt_text_5"+"_r"+inRecNum).value; 
    document.getElementById("opt_text_6").value  = document.getElementById("opt_text_6"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_1").value  = document.getElementById("is_ans_opt_1"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_2").value  = document.getElementById("is_ans_opt_2"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_3").value  = document.getElementById("is_ans_opt_3"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_4").value  = document.getElementById("is_ans_opt_4"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_5").value  = document.getElementById("is_ans_opt_5"+"_r"+inRecNum).value; 
    document.getElementById("is_ans_opt_6").value  = document.getElementById("is_ans_opt_6"+"_r"+inRecNum).value; 
    document.getElementById("equi_mark_1").value  = parseInt(document.getElementById("equi_mark_1"+"_r"+inRecNum).value); 
    document.getElementById("equi_mark_2").value  = parseInt(document.getElementById("equi_mark_2"+"_r"+inRecNum).value); 
    document.getElementById("equi_mark_3").value  = parseInt(document.getElementById("equi_mark_3"+"_r"+inRecNum).value); 
    document.getElementById("equi_mark_4").value  = parseInt(document.getElementById("equi_mark_4"+"_r"+inRecNum).value); 
    document.getElementById("equi_mark_5").value  = parseInt(document.getElementById("equi_mark_5"+"_r"+inRecNum).value); 
    document.getElementById("equi_mark_6").value  = parseInt(document.getElementById("equi_mark_6"+"_r"+inRecNum).value); 
    document.getElementById("remark_hna").value  = document.getElementById("remark_hna"+"_r"+inRecNum).value; 
    document.getElementById("quest_by").value  = document.getElementById("quest_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_by").value  = document.getElementById("rec_cre_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 

    //----------------------------------------------------
    var lQuestionTextObj = document.getElementById("question_text");
    var lIsImgQuest = document.getElementById("is_img_quest"+"_r"+inRecNum);
    if ( lIsImgQuest && lIsImgQuest.value == 'Y' )
    {
      lQuestionTextObj.readOnly = true;
      document.getElementById('is_img_quest_link_tr').style.display='';
    }
    else
    {
      lQuestionTextObj.readOnly = false;
      document.getElementById('is_img_quest_link_tr').style.display  ='none';
    }
    //----------------------------------------------------
    document.getElementById('quest_ans_link_tr').style.display='';

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit8"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit9"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value                        = '';
    document.getElementById("paper_grp_cd").value                  = '';
    document.getElementById("question_seq_num").value              = '';
    //document.getElementById("academic_session").value              = '';
    //document.getElementById("exam_id").value                       = '';
    //document.getElementById("paper_id").value                      = '';
    //document.getElementById("exam_term").value                     = '';
    //document.getElementById("exam_type").value                     = '';
    //document.getElementById("exam_date").value                     = '';
    //document.getElementById("prepared_by").value                   = '';
    document.getElementById("question_num").value                  = '';
    document.getElementById("question_text").value                 = '';
    document.getElementById("question_text").readOnly              = false;
    document.getElementById("mandatory_flag").value                = '';
    document.getElementById("max_mark").value                      = '1';
    //document.getElementById("subject_code").value                  = '';
    //document.getElementById("topic_id").value                      = '';
    document.getElementById("topic_desc").value                    = 'NA';
    //document.getElementById("class_id").value                      = '';
    //document.getElementById("class_num").value                     = '';
    //document.getElementById("class_std").value                     = '';
    //document.getElementById("class_section").value                 = '';
    //document.getElementById("course_id").value                     = '';
    //document.getElementById("course_term").value                   = '';
    //document.getElementById("course_stream").value                 = '';
    document.getElementById("status").value                        = 'O';
    //document.getElementById("js_act_code").value                   = '';
    document.getElementById("num_opt").value                       = '6';
    document.getElementById("num_ans").value                       = '1';
    document.getElementById("display_type").value                  = 'R';
    document.getElementById("ans_in_one_line").value               = 'Y';
    document.getElementById("question_level").value                = '1';
    document.getElementById("quest_dur_sec").value                 = '5';
    document.getElementById("is_img_quest").value                  = 'N';
    document.getElementById("opt_text_1").value                    = '';
    document.getElementById("opt_text_2").value                    = '';
    document.getElementById("opt_text_3").value                    = '';
    document.getElementById("opt_text_4").value                    = '';
    document.getElementById("opt_text_5").value                    = 'all of the above';
    document.getElementById("opt_text_6").value                    = 'none of the above';
    document.getElementById("is_ans_opt_1").value                  = 'N';
    document.getElementById("is_ans_opt_2").value                  = 'N';
    document.getElementById("is_ans_opt_3").value                  = 'N';
    document.getElementById("is_ans_opt_4").value                  = 'N';
    document.getElementById("is_ans_opt_5").value                  = 'N';
    document.getElementById("is_ans_opt_6").value                  = 'N';
    document.getElementById("equi_mark_1").value                   = '';
    document.getElementById("equi_mark_2").value                   = '';
    document.getElementById("equi_mark_3").value                   = '';
    document.getElementById("equi_mark_4").value                   = '';
    document.getElementById("equi_mark_5").value                   = '';
    document.getElementById("equi_mark_6").value                   = '';
    document.getElementById("remark_hna").value                        = '';
    if ( document.getElementById("quest_by") )
      document.getElementById("quest_by").value                      = document.getElementById("ptl_user_id_global").value;
    else
      document.getElementById("quest_by").value                      = '';
    //document.getElementById("rec_cre_by").value                    = '';
    //document.getElementById("rec_cre_date").value                  = '';
    //document.getElementById("rec_cre_time").value                  = '';
    //document.getElementById("rec_upd_date").value                  = '';
    //document.getElementById("rec_upd_time").value                  = '';
    document.getElementById('is_img_quest_link_tr').style.display  ='none';
    document.getElementById('quest_ans_link_tr').style.display     ='none';
  }
}
