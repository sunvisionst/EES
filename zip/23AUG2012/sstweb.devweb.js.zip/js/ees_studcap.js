document.write('<option value=></option>');
document.write('<option value=OS>OUTSTANDING</option>');
document.write('<option value=E>EXCELLENT</option>');
document.write('<option value=VG>VERY GOOD</option>');
document.write('<option value=G>GOOD</option>');
document.write('<option value=AV>AVERAGE</option>');
document.write('<option value=BA>BELOW AVERAGE</option>');
document.write('<option value=NK>NOT KNOWN</option>');
