function verify_student( inEvt )
{
  var lBrowserName = getBrowserName();
  if ( lBrowserName == 'Microsoft Internet Explorer' )
    window.event.returnValue=false;
  else
  if ( lBrowserName == 'Netscape' )
  {
    inEvt.preventDefault();
    inEvt.stopPropagation();
  }
}

