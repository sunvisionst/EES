function EesMessRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value            = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("mess_id").value           = document.getElementById("mess_id"+"_r"+inRecNum).value;
    document.getElementById("hostel_id").value         = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    document.getElementById("location").value          = document.getElementById("location"+"_r"+inRecNum).value;
    document.getElementById("mess_incharge_1").value   = document.getElementById("mess_incharge_1"+"_r"+inRecNum).value;
    document.getElementById("mess_incharge_2").value   = document.getElementById("mess_incharge_2"+"_r"+inRecNum).value;
    document.getElementById("head_cook").value         = document.getElementById("head_cook"+"_r"+inRecNum).value;
    document.getElementById("mess_staff").value        = document.getElementById("mess_staff"+"_r"+inRecNum).value;
    document.getElementById("breakfast_charge").value  = document.getElementById("breakfast_charge"+"_r"+inRecNum).value;
    document.getElementById("lunch_charge").value      = document.getElementById("lunch_charge"+"_r"+inRecNum).value;
    document.getElementById("dinner_charge").value     = document.getElementById("dinner_charge"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value            = '';
    document.getElementById("mess_id").value           = '';
    document.getElementById("hostel_id").value         = '';
    document.getElementById("location").value          = '';
    document.getElementById("mess_incharge_1").value   = '';
    document.getElementById("mess_incharge_2").value   = '';
    document.getElementById("head_cook").value         = '';
    document.getElementById("mess_staff").value        = '';
    document.getElementById("breakfast_charge").value  = '';
    document.getElementById("lunch_charge").value      = '';
    document.getElementById("dinner_charge").value     = '';
    // add other fields like above
  }
}
