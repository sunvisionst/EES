function EsmInvoiceRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("invoice_num").value  = document.getElementById("invoice_num"+"_r"+inRecNum).value; 
    document.getElementById("invoice_date").value  = document.getElementById("invoice_date"+"_r"+inRecNum).value; 
    document.getElementById("customer_id").value  = document.getElementById("customer_id"+"_r"+inRecNum).value; 
    document.getElementById("invoice_amt").value  = document.getElementById("invoice_amt"+"_r"+inRecNum).value; 
    document.getElementById("invoice_status").value  = document.getElementById("invoice_status"+"_r"+inRecNum).value; 
    document.getElementById("invoice_type").value  = document.getElementById("invoice_type"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("invoice_num").value  = '';
    document.getElementById("invoice_date").value  = '';
    document.getElementById("customer_id").value  = '';
    document.getElementById("invoice_amt").value  = '';
    document.getElementById("invoice_sts").value  = '';
    document.getElementById("invoice_type").value  = '';
  }
}
