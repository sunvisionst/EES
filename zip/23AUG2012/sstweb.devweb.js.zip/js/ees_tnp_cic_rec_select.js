function EesTnpCicRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("followup_id").value         = document.getElementById("followup_id"+"_r"+inRecNum).value; 
    document.getElementById("for_class_num").value       = document.getElementById("for_class_num"+"_r"+inRecNum).value; 
    document.getElementById("for_course_id").value       = document.getElementById("for_course_id"+"_r"+inRecNum).value; 
    document.getElementById("for_course_term").value     = document.getElementById("for_course_term"+"_r"+inRecNum).value; 
    document.getElementById("for_course_stream").value   = document.getElementById("for_course_stream"+"_r"+inRecNum).value; 
    document.getElementById("seq_num").value             = document.getElementById("seq_num"+"_r"+inRecNum).value; 
    document.getElementById("link_followup_id").value    = document.getElementById("link_followup_id"+"_r"+inRecNum).value; 
    document.getElementById("org_id").value              = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("company_id").value          = document.getElementById("company_id"+"_r"+inRecNum).value +"/" 
                                                         + document.getElementById("followup_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value           = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value           = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value           = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value         = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value       = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("marks_in_percent").value    = document.getElementById("marks_in_percent"+"_r"+inRecNum).value; 
    document.getElementById("year_gap_ind").value        = document.getElementById("year_gap_ind"+"_r"+inRecNum).value; 
    document.getElementById("num_backlog").value         = document.getElementById("num_backlog"+"_r"+inRecNum).value; 
    document.getElementById("individual_term_ind").value = document.getElementById("individual_term_ind"+"_r"+inRecNum).value; 


    var lCourseTerm =   document.getElementById("course_term"+"_r"+inRecNum).value;

    if(lCourseTerm =='ALL')
    {
       document.getElementById("select_radio_1").checked = true;
       showForClassField1();
    }
    else
    {
       document.getElementById("select_radio_2").checked = true;
       showForClassField1();
    }
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("followup_id").value          = '';
    document.getElementById("for_class_num").value        = '';
    document.getElementById("for_course_id").value        = '';
    document.getElementById("for_course_term").value      = '';
    document.getElementById("for_course_stream").value    = '';
    document.getElementById("seq_num").value              = '';
    document.getElementById("link_followup_id").value     = '';
    document.getElementById("org_id").value               = '';
    document.getElementById("company_id").value           = '';
    document.getElementById("class_num").value            = '';
    document.getElementById("class_std").value            = '';
    document.getElementById("course_id").value            = '';
    document.getElementById("course_term").value          = '';
    document.getElementById("course_stream").value        = '';
    document.getElementById("marks_in_percent").value     = '';
    document.getElementById("year_gap_ind").value         = '';
    document.getElementById("backlog_ind").value          = '';
  }
}

function checkDefaultRadio()
{
  document.getElementById("select_radio_1").checked = true;
  showForClassField1();
}

