function EesVehicleDriverRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value          = document.getElementById("org_id"+"_r"+inRecNum).value;
    //document.getElementById("vehicle_id").value      = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
    document.getElementById("driver_id").value       = document.getElementById("driver_id"+"_r"+inRecNum).value;
    document.getElementById("name").value            = document.getElementById("name"+"_r"+inRecNum).value;
    document.getElementById("driver_ctg").value      = document.getElementById("driver_ctg"+"_r"+inRecNum).value;
    document.getElementById("age").value             = document.getElementById("age"+"_r"+inRecNum).value;
    document.getElementById("address_1").value       = document.getElementById("address_1"+"_r"+inRecNum).value; 
    //document.getElementById("address_2").value       = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("contact_num_1").value   = document.getElementById("contact_num_1"+"_r"+inRecNum).value;
    //document.getElementById("contact_num_2").value   = document.getElementById("contact_num_2"+"_r"+inRecNum).value;
    document.getElementById("date_vh_start").value   = document.getElementById("date_vh_start"+"_r"+inRecNum).value;
    document.getElementById("dl_num").value          = document.getElementById("dl_num"+"_r"+inRecNum).value;
    document.getElementById("dl_start_date").value   = document.getElementById("dl_start_date"+"_r"+inRecNum).value;
    document.getElementById("dl_end_date").value   = document.getElementById("dl_end_date"+"_r"+inRecNum).value;


   // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value         = '';
    //document.getElementById("vehicle_id").value     = '';
    document.getElementById("driver_id").value      = '';
    document.getElementById("name").value           = '';
    document.getElementById("driver_ctg").value     = '';
    document.getElementById("age").value            = '';
    document.getElementById("address_1").value      = '';
    //document.getElementById("address_2").value      = '';
    document.getElementById("contact_num_1").value  = '';
    //document.getElementById("contact_num_2").value  = '';
    document.getElementById("date_vh_start").value  = '';                     
    document.getElementById("dl_num").value         = '';
    document.getElementById("dl_start_date").value  = '';
    document.getElementById("dl_end_date").value    = '';

    // add other fields like above
  }
}
