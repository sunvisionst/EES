function EesExamRecSelect( inSelectFlag, inRecNum)
{
    alert('lExamSchStatus=>');
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("exam_id").value          = document.getElementById("exam_id"+"_r"+inRecNum).value;
    document.getElementById("exam_type").value        = document.getElementById("exam_type"+"_r"+inRecNum).value;  
    document.getElementById("year").value             = document.getElementById("year"+"_r"+inRecNum).value;  
    document.getElementById("month").value            = document.getElementById("month"+"_r"+inRecNum).value; 
    document.getElementById("exam_start_date").value  = document.getElementById("exam_start_date"+"_r"+inRecNum).value;
    document.getElementById("exam_end_date").value    = document.getElementById("exam_end_date"+"_r"+inRecNum).value;
    //document.getElementById("exam_sch_status").value  = document.getElementById("exam_sch_status"+"_r"+inRecNum).value;
    document.getElementById("exam_status").value  = document.getElementById("exam_status"+"_r"+inRecNum).value;
    //var lExamSchStatus = document.getElementById("exam_sch_status").value;
    var lExamSchStatus = document.getElementById("exam_status").value;
    alert('lExamSchStatus=>'+lExamSchStatus);
    if ( lExamSchStatus != null && lExamSchStatus.length > 0 && lExamSchStatus == 'O' )
    {
      lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    }
    else
    if ( lExamSchStatus != null && lExamSchStatus.length > 0 && lExamSchStatus == 'A' )
    {
      lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    }
    else
    if ( lExamSchStatus != null && lExamSchStatus.length > 0 && lExamSchStatus == 'C' )
    {
      lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    }
  
  }
  else
  {
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value      = '';
    document.getElementById("exam_id").value         = '';
    document.getElementById("exam_type").value       = '';
    document.getElementById("year").value            = '';
    document.getElementById("month").value           = '';
    document.getElementById("exam_start_date").value = '';
    document.getElementById("exam_end_date").value   = '';   
    document.getElementById("exam_status").value = '';
    //document.getElementById("exam_sch_status").value = '';

  }
}
