function EesTtAfReqRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    //lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("tab_rowid").value     = document.getElementById("tab_rowid"+"_r"+inRecNum).value; 
    //document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("year").value          = document.getElementById("year"+"_r"+inRecNum).value; 
    //document.getElementById("month").value         = document.getElementById("month"+"_r"+inRecNum).value; 
    document.getElementById("day").value           = document.getElementById("day"+"_r"+inRecNum).value; 
    document.getElementById("period_num").value    = document.getElementById("period_num"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value      = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("timetable_id").value  = document.getElementById("timetable_id"+"_r"+inRecNum).value; 
    document.getElementById("req_id").value        = document.getElementById("req_id"+"_r"+inRecNum).value; 
    document.getElementById("req_date").value      = document.getElementById("req_date"+"_r"+inRecNum).value; 
    //document.getElementById("requested_by").value  = document.getElementById("requested_by"+"_r"+inRecNum).value; 
    document.getElementById("requested_to").value  = document.getElementById("requested_to"+"_r"+inRecNum).value; 
    document.getElementById("status").value        = document.getElementById("status"+"_r"+inRecNum).value; 

    if ( document.getElementById('status').value == 'N' )
      document.getElementById('submit_send').disabled=false;
    else
      document.getElementById('submit_send').disabled=true;
  }
  else
  {
    //lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("tab_rowid").value     = '';
    //document.getElementById("org_id").value        = '';
    //document.getElementById("year").value          = '';
    //document.getElementById("month").value         = '';
    document.getElementById("day").value           = '';
    document.getElementById("period_num").value    = '';
    document.getElementById("class_id").value      = '';
    document.getElementById("timetable_id").value  = '';
    document.getElementById("req_id").value        = '';
    document.getElementById("req_date").value      = '';
    //document.getElementById("requested_by").value  = '';
    document.getElementById("requested_to").value  = '';
    document.getElementById("status").value        = '';
  }
}
