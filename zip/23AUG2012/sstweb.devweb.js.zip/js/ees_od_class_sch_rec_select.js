function EesOdClassSchRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value; 
    document.getElementById("topic_ctg").value  = document.getElementById("topic_ctg"+"_r"+inRecNum).value; 
    document.getElementById("topic_title").value  = document.getElementById("topic_title"+"_r"+inRecNum).value; 
    document.getElementById("topic_detail").value  = document.getElementById("topic_detail"+"_r"+inRecNum).value; 
    document.getElementById("topic_class_dtl").value  = document.getElementById("topic_class_dtl"+"_r"+inRecNum).value; 
    document.getElementById("topic_subject_dtl").value  = document.getElementById("topic_subject_dtl"+"_r"+inRecNum).value; 
    document.getElementById("sch_date").value  = document.getElementById("sch_date"+"_r"+inRecNum).value; 
    document.getElementById("sch_time").value  = document.getElementById("sch_time"+"_r"+inRecNum).value; 
    document.getElementById("delivery_mode").value  = document.getElementById("delivery_mode"+"_r"+inRecNum).value; 
    document.getElementById("class_venue").value  = document.getElementById("class_venue"+"_r"+inRecNum).value; 
    //document.getElementById("topic_id").value  = document.getElementById("topic_id"+"_r"+inRecNum).value; 
    //document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value; 
    //document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    //document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    //document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    //document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    //document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    //document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    //document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    //document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
    //document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value; 
    //document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    //document.getElementById("continent").value  = document.getElementById("continent"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_by").value  = document.getElementById("rec_cre_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_by").value  = document.getElementById("rec_upd_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 
    //document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("apr_by").value  = document.getElementById("apr_by"+"_r"+inRecNum).value; 
    //document.getElementById("apr_date").value  = document.getElementById("apr_date"+"_r"+inRecNum).value; 
    //document.getElementById("apr_time").value  = document.getElementById("apr_time"+"_r"+inRecNum).value; 
    //document.getElementById("rej_by").value  = document.getElementById("rej_by"+"_r"+inRecNum).value; 
    //document.getElementById("rej_remark").value  = document.getElementById("rej_remark"+"_r"+inRecNum).value; 
    //document.getElementById("rej_date").value  = document.getElementById("rej_date"+"_r"+inRecNum).value; 
    //document.getElementById("rej_time").value  = document.getElementById("rej_time"+"_r"+inRecNum).value; 
    var lStatusObj = document.getElementById("status"+"_r"+inRecNum);
    if ( lStatusObj && lStatusObj.value == 'A' )
    {
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    }
    else
    if ( lStatusObj && lStatusObj.value == 'O' )
    {
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    }
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("seq_num").value  = '';
    document.getElementById("topic_ctg").value  = '';
    document.getElementById("topic_title").value  = '';
    document.getElementById("topic_detail").value  = '';
    document.getElementById("topic_class_dtl").value  = '';
    document.getElementById("topic_subject_dtl").value  = '';
    document.getElementById("sch_date").value  = '';
    document.getElementById("sch_time").value  = '';
    document.getElementById("delivery_mode").value  = '';
    document.getElementById("class_venue").value  = '';
    //document.getElementById("topic_id").value  = '';
    //document.getElementById("subject_code").value  = '';
    //document.getElementById("class_num").value  = '';
    //document.getElementById("class_std").value  = '';
    //document.getElementById("class_section").value  = '';
    //document.getElementById("course_id").value  = '';
    //document.getElementById("course_term").value  = '';
    //document.getElementById("course_stream").value  = '';
    //document.getElementById("city").value  = '';
    //document.getElementById("zip").value  = '';
    //document.getElementById("state").value  = '';
    //document.getElementById("country").value  = '';
    //document.getElementById("continent").value  = '';
    //document.getElementById("rec_cre_by").value  = '';
    //document.getElementById("rec_cre_date").value  = '';
    //document.getElementById("rec_cre_time").value  = '';
    //document.getElementById("rec_upd_by").value  = '';
    //document.getElementById("rec_upd_date").value  = '';
    //document.getElementById("rec_upd_time").value  = '';
    //document.getElementById("status").value  = '';
    //document.getElementById("apr_by").value  = '';
    //document.getElementById("apr_date").value  = '';
    //document.getElementById("apr_time").value  = '';
    //document.getElementById("rej_by").value  = '';
    //document.getElementById("rej_remark").value  = '';
    //document.getElementById("rej_date").value  = '';
    //document.getElementById("rej_time").value  = '';
  }
}
