function EesMessDietRegRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("entry_date").value  = document.getElementById("entry_date"+"_r"+inRecNum).value; 
    document.getElementById("diet_type").value  = document.getElementById("diet_type"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("mess_id").value  = document.getElementById("mess_id"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value  = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("entry_time").value  = document.getElementById("entry_time"+"_r"+inRecNum).value; 
    document.getElementById("emp_flag").value  = document.getElementById("emp_flag"+"_r"+inRecNum).value; 
    document.getElementById("diet_qty").value  = document.getElementById("diet_qty"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("roll_num").value  = '';
    document.getElementById("student_id").value  = '';
    document.getElementById("entry_date").value  = '';
    document.getElementById("diet_type").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("mess_id").value  = '';
    document.getElementById("hostel_id").value  = '';
    document.getElementById("entry_time").value  = '';
    document.getElementById("emp_flag").value  = '';
    document.getElementById("diet_qty").value  = '';
  }
}
