function EesTrainingOrganizerRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value        = document.getElementById("org_id_r"+inRecNum).value;
    document.getElementById("tnp_flag").value      = document.getElementById("tnp_flag_r"+inRecNum).value;
    document.getElementById("ref_recorg_id").value = document.getElementById("ref_recorg_id_r"+inRecNum).value;
    document.getElementById("seq_num").value       = document.getElementById("seq_num_r"+inRecNum).value;
    document.getElementById("organizer_name").value= document.getElementById("organizer_name_r"+inRecNum).value;
    document.getElementById("main_organizer_ind").value= document.getElementById("main_organizer_ind_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value      = '';
    document.getElementById("org_id").value        = '';
    document.getElementById("tnp_flag").value      = '';
    document.getElementById("ref_recorg_id").value = '';
    document.getElementById("seq_num").value       = ''
    document.getElementById("organizer_name").value= '';
    document.getElementById("main_organizer_ind").value= '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
