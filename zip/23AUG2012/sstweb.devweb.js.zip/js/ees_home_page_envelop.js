<script type="text/javascript" language="javascript" src="../js/gn_loginEnvVar.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_confMultiNotNullById.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_radioFunctionUB.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_date_validation.js"> </script>
<!--script type="text/javascript" language="javascript" src="../js/gn_date_picker.js"> </script-->
<script type="text/javascript" language="javascript" src="../js/gn_checkBoxFunction.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_changeTableRowColor.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_uniqueSelectionRadioCheckBox.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_getElementIdByWindowEvent.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_toolTip.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_refresh_element_ajax.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_confirm.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_change_css_runtime.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_dyn_load_webfile.js"> </script>

<!-- NOW MENU JS FILE IS OBSO -->
<!--script type="text/javascript" language="javascript" src="../js/gn_menu.js"> </script-->

<script type="text/javascript" language="javascript" src="../js/gn_prep_dd_option.js"> </script>

<script type="text/javascript" language="javascript" src="../js/gn_validate_time_format.js"> </script>
<script type="text/javascript" language="javascript" src="../js/gn_TimePicker.js"> </script>

<!-- NOW BALLOON FILES MAY BE OBSO -->
<!--
<script type="text/javascript" language="javascript" src="../jquery/balloon/balloon.config.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/balloon/balloon.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/balloon/balloon_box.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/balloon/balloon_yahoo-dom-event.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/balloon/balloon_init.js"> </script>
-->

<!-- PORTAL SPECIFIC JS -->
<script type="text/javascript" language="javascript" src="../js/sst_home_page_next_prev_action.js"> </script>

<!-- ROUNDED DIV -->
<!--script type="text/javascript" language="javascript" src="../js/sst_rounded_corner_div.js"></script-->

<!-- JQUERY CORE FILES -->
<!--
<script type="text/javascript" language="javascript" src="../jquery/jquery-1.3.2.js"></script>
<script type="text/javascript" language="javascript" src="../jquery/jquery-1.4.2.js"></script>
<script type="text/javascript" language="javascript" src="../jquery/jquery-1.5.1.min.js"></script>
-->
<script type="text/javascript" language="javascript" src="../jquery/jquery-1.5.2.min.js"></script>

<!-- JQUERY UI IMPLEMENTATION -->
<!--
<script type="text/javascript" language="javascript" src="../jquery/jqueryui.1.8.1/js/jquery-ui-1.8.1.custom.min.js"></script>
<script type="text/javascript" language="javascript" src="../jquery/jqueryui.1.8.12/js/jquery-ui-1.8.12.custom.min.js"></script>
-->
<script type="text/javascript" language="javascript" src="../jquery/jqueryui.1.8.12_orange/js/jquery-ui-1.8.12.custom.min.js"></script>

<!-- JQUERY TIMEPICKER FILES -->
<!--script type="text/javascript" language="javascript" src="../jquery/jquery.timepicker.js"></script-->
<!--script type="text/javascript" language="javascript" src="../jquery/jquery.jtimepicker.js"></script-->

<!-- JQUERY PLUGIN-VALIDATE FORM FIELDS -->
<script type="text/javascript" language="javascript" src="../public_html/jquery_plugin/jquery.validate.js"> </script>

<!-- JQUERY FLUID - KEYBOARD NAVIGATION IMPLEMENTATION -->
<!--script type="text/javascript" src="../jquery/jquery_fluid/lib/jquery/core/js/jquery.js"></script-->
<!--
<script type="text/javascript" src="../jquery/jquery_fluid/lib/jquery/ui/js/jquery.ui.core.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/lib/jquery/ui/js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/lib/jquery/ui/js/jquery.ui.mouse.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/lib/jquery/ui/js/jquery.ui.draggable.js"></script>
<script type="text/javascript" src="../public_html/jquery_plugin/jquery_hotkeys/jquery.hotkeys.js"></script>

<script type="text/javascript" src="../jquery/jquery_fluid/framework/core/js/jquery.keyboard-a11y.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/framework/core/js/Fluid.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/framework/core/js/FluidDOMUtilities.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/components/reorderer/js/ReordererDOMUtilities.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/components/reorderer/js/GeometricManager.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/components/reorderer/js/Reorderer.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/components/reorderer/js/LayoutReorderer.js"></script>
<script type="text/javascript" src="../jquery/jquery_fluid/components/reorderer/js/ModuleLayout.js"></script>
-->

<!-- JQUERY PLUGIN-CHART -->
<!--script type="text/javascript" language="javascript" src="../jquery/fgchart/1/sst_excanvas_compressed.js"></script>
<script type="text/javascript" language="javascript" src="../jquery/fgchart/1/sst_fg_charting.js"></script-->

<!-- JQUERY PLUGIN-ROUNDEDCRNER -->
<script type="text/javascript" language="javascript" src="../jquery/sst_jquery_corner.js"> </script>

<!-- JQUERY PLUGIN-TOOLTIP -->
<script type="text/javascript" language="javascript" src="../jquery/jquery-tooltip/jquery.tooltip.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/jquery-tooltip/lib/jquery.bgiframe.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/jquery-tooltip/lib/jquery.dimensions.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/sst_jquery_tooltip.js"> </script>

<!-- JQUERY PLUGIN-FACEBOX -->
<!--script type="text/javascript" language="javascript" src="../jquery/facebox.1.2/facebox.js"> </script-->
<script type="text/javascript" language="javascript" src="../jquery/facebox.1.3/src/facebox.js"> </script>

<!-- JQUERY PLUGIN-JALERT -->
<script type="text/javascript" language="javascript" src="../jquery/jquery_alert/sst_jquery.alerts.js"> </script>
<!--script type="text/javascript" language="javascript" src="../jquery/jquery_alert/sst_jquery.ui.draggable.js"> </script-->

<!-- Setup the jHTMLAREA editor IMPLEMENTATION -->
<script type="text/javascript" src="../public_html/jquery_plugin/htmleditor/jhtmlarea06/scripts/jHtmlArea-0.6.0.js"></script>
<script type="text/javascript" src="../public_html/jquery_plugin/htmleditor/jhtmlarea06/scripts/jHtmlArea.ColorPickerMenu-0.6.0.js"></script>

<!-- JQUERY PLUGIN-SLIDESHOW -->
<script language="javascript" src="../jquery/jquery_slideshow/sst_jquery.cycle.all.2.72.js"> </script>
<script language="javascript" src="../jquery/jquery_slideshow/sst_jquery.timers.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/jquery_slideshow/sst_jquery.easing.1.3.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/jquery_slideshow/sst_jquery.easing.compatibility.js"> </script>
<!--
<script language="javascript" src="../jquery/jquery_slideshow/sst_jquery.slideViewerPro.1.0.js"> </script>
<script type="text/javascript" language="javascript" src="../jquery/jquery_slideshow/sst_jquery.slideviewer.1.2.js"> </script>
-->

<!-- Setup the MOVIE PLAYER IMPLEMENTATION -->
<script type="text/javascript" src="../public_html/jquery_plugin/mediaplayer/sst_jquery_media.js"></script>

<!-- JQUERY ONREADY IMPLEMENTATION -->
<script type="text/javascript" language="javascript" src="../js/sst_jquery.js"> </script>

