function EesQuizSchRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("edu_org_id").value  = document.getElementById("edu_org_id"+"_r"+inRecNum).value; 
    document.getElementById("quiz_sch_id").value  = document.getElementById("quiz_sch_id"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("quiz_sch_date").value  = document.getElementById("quiz_sch_date"+"_r"+inRecNum).value; 
    document.getElementById("quiz_sch_time").value  = document.getElementById("quiz_sch_time"+"_r"+inRecNum).value; 
    document.getElementById("quiz_dur_min").value  = document.getElementById("quiz_dur_min"+"_r"+inRecNum).value; 
    //document.getElementById("sch_week_num").value  = document.getElementById("sch_week_num"+"_r"+inRecNum).value; 
    //document.getElementById("woy").value  = document.getElementById("woy"+"_r"+inRecNum).value; 
    document.getElementById("max_num_quest").value  = document.getElementById("max_num_quest"+"_r"+inRecNum).value; 
    //document.getElementById("paper_grp_cd").value  = document.getElementById("paper_grp_cd"+"_r"+inRecNum).value; 
    //document.getElementById("exam_id").value  = document.getElementById("exam_id"+"_r"+inRecNum).value; 
    //document.getElementById("paper_id").value  = document.getElementById("paper_id"+"_r"+inRecNum).value; 
    //document.getElementById("exam_term").value  = document.getElementById("exam_term"+"_r"+inRecNum).value; 
    //document.getElementById("exam_type").value  = document.getElementById("exam_type"+"_r"+inRecNum).value; 
    //document.getElementById("exam_date").value  = document.getElementById("exam_date"+"_r"+inRecNum).value; 
    //document.getElementById("display_paper_id").value  = document.getElementById("display_paper_id"+"_r"+inRecNum).value; 
    document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value; 
    //document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    //document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    //document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    //document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    //document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    //document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    //document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("js_act_code").value  = document.getElementById("js_act_code"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
    document.getElementById("sch_close_by").value  = document.getElementById("sch_close_by"+"_r"+inRecNum).value; 
    document.getElementById("sch_close_date").value  = document.getElementById("sch_close_date"+"_r"+inRecNum).value; 
    document.getElementById("sch_close_time").value  = document.getElementById("sch_close_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_by").value  = document.getElementById("rec_cre_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_by").value  = document.getElementById("rec_upd_by"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value; 
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    document.getElementById("university_board_name").value  = document.getElementById("university_board_name"+"_r"+inRecNum).value; 

    //document.getElementById("copy_new_sch_tr").style.display  = '';
    //-------------------------------------------------------
    //var lJsActCode = document.getElementById("js_act_code"+"_r"+inRecNum);
    //if ( lJsActCode && ( lJsActCode.value == '050' || lJsActCode.value == '060' || lJsActCode.value == '070' ) )
    //  document.getElementById("upload_sch_file_id").style.display  = '';
    //-------------------------------------------------------
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("edu_org_id").value  = '';
    document.getElementById("quiz_sch_id").value  = '';
    document.getElementById("academic_session").value  = '';
    document.getElementById("quiz_sch_date").value  = '';
    document.getElementById("quiz_sch_time").value  = '';
    document.getElementById("quiz_dur_min").value  = '';
    //document.getElementById("sch_week_num").value  = '';
    //document.getElementById("woy").value  = '';
    document.getElementById("max_num_quest").value  = '';
    //document.getElementById("paper_grp_cd").value  = '';
    //document.getElementById("exam_id").value  = '';
    //document.getElementById("paper_id").value  = '';
    //document.getElementById("exam_term").value  = '';
    //document.getElementById("exam_type").value  = '';
    //document.getElementById("exam_date").value  = '';
    //document.getElementById("display_paper_id").value  = '';
    document.getElementById("subject_code").value  = '';
    //document.getElementById("class_id").value  = '';
    //document.getElementById("class_num").value  = '';
    //document.getElementById("class_std").value  = '';
    //document.getElementById("class_section").value  = '';
    //document.getElementById("course_id").value  = '';
    //document.getElementById("course_term").value  = '';
    //document.getElementById("course_stream").value  = '';
    document.getElementById("status").value  = '';
    //document.getElementById("js_act_code").value  = '';
    document.getElementById("remark").value  = '';
    document.getElementById("sch_close_by").value  = '';
    document.getElementById("sch_close_date").value  = '';
    document.getElementById("sch_close_time").value  = '';
    //document.getElementById("rec_cre_by").value  = '';
    //document.getElementById("rec_cre_date").value  = '';
    //document.getElementById("rec_cre_time").value  = '';
    //document.getElementById("rec_upd_by").value  = '';
    //document.getElementById("rec_upd_date").value  = '';
    //document.getElementById("rec_upd_time").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("state").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("university_board_name").value  = '';
    //document.getElementById("copy_new_sch_tr").style.display  = 'none';
    //document.getElementById("upload_sch_file_id").style.display  = 'none';
  }
}
