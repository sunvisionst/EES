function EsmCustomerRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("customer_id").value  = document.getElementById("customer_id"+"_r"+inRecNum).value; 
    document.getElementById("customer_type").value  = document.getElementById("customer_type"+"_r"+inRecNum).value; 
    document.getElementById("customer_ctg").value  = document.getElementById("customer_ctg"+"_r"+inRecNum).value; 
    document.getElementById("customer_name").value  = document.getElementById("customer_name"+"_r"+inRecNum).value; 
    document.getElementById("customer_group").value  = document.getElementById("customer_group"+"_r"+inRecNum).value; 
    document.getElementById("referred_by").value  = document.getElementById("referred_by"+"_r"+inRecNum).value; 
    document.getElementById("turn_over").value  = document.getElementById("turn_over"+"_r"+inRecNum).value; 
    document.getElementById("business_area_cd").value  = document.getElementById("business_area_cd"+"_r"+inRecNum).value; 
    document.getElementById("state_code").value  = document.getElementById("state_code"+"_r"+inRecNum).value; 
    document.getElementById("region_id").value  = document.getElementById("region_id"+"_r"+inRecNum).value; 
    document.getElementById("country_code").value  = document.getElementById("country_code"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value; 
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value; 
    document.getElementById("business_type").value  = document.getElementById("business_type"+"_r"+inRecNum).value; 
    document.getElementById("business_est_date").value  = document.getElementById("business_est_date"+"_r"+inRecNum).value; 
    document.getElementById("employee_strength").value  = document.getElementById("employee_strength"+"_r"+inRecNum).value; 
    document.getElementById("business_currency").value  = document.getElementById("business_currency"+"_r"+inRecNum).value; 
    document.getElementById("tax_form_type").value  = document.getElementById("tax_form_type"+"_r"+inRecNum).value; 
    document.getElementById("tax_form_num").value  = document.getElementById("tax_form_num"+"_r"+inRecNum).value; 
    document.getElementById("tax_form_date").value  = document.getElementById("tax_form_date"+"_r"+inRecNum).value; 
    document.getElementById("cust_seq_num").value  = document.getElementById("cust_seq_num"+"_r"+inRecNum).value;

/////////////////////////////////////////////////////////////////////////////////////////////
    document.getElementById("customer_id").value  = document.getElementById("customer_id"+"_r"+inRecNum).value;
    document.getElementById("address_type").value  = document.getElementById("address_type"+"_r"+inRecNum).value;
    document.getElementById("address_field_seq").value  = document.getElementById("address_field_seq"+"_r"+inRecNum).value;
    document.getElementById("address_ctg").value  = document.getElementById("address_ctg"+"_r"+inRecNum).value;
    document.getElementById("address_field_name").value  = document.getElementById("address_field_name"+"_r"+inRecNum).value;
    document.getElementById("address_field_value").value  = document.getElementById("address_field_value"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;




    document.getElementById("customer_id").value  = document.getElementById("customer_id"+"_r"+inRecNum).value;
    document.getElementById("bank_code").value  = document.getElementById("bank_code"+"_r"+inRecNum).value;
    document.getElementById("bank_name").value  = document.getElementById("bank_name"+"_r"+inRecNum).value;
    document.getElementById("bank_act_num").value  = document.getElementById("bank_act_num"+"_r"+inRecNum).value;
    document.getElementById("bank_act_holder").value  = document.getElementById("bank_act_holder"+"_r"+inRecNum).value;
    document.getElementById("bank_act_type").value  = document.getElementById("bank_act_type"+"_r"+inRecNum).value;
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value;
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value;
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value;
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value;
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value;


///////////////////////////////////////////////////////////////////////////////////////////// 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("customer_id").value  = '';
    document.getElementById("customer_type").value  = '';
    document.getElementById("customer_ctg").value  = '';
    document.getElementById("customer_name").value  = '';
    document.getElementById("customer_group").value  = '';
    document.getElementById("referred_by").value  = '';
    document.getElementById("turn_over").value  = '';
    document.getElementById("business_area_cd").value  = '';
    document.getElementById("state_code").value  = '';
    document.getElementById("region_id").value  = '';
    document.getElementById("country_code").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("expiration_date").value  = '';
    document.getElementById("effective_date").value  = '';
    document.getElementById("business_type").value  = '';
    document.getElementById("business_est_date").value  = '';
    document.getElementById("employee_strength").value  = '';
    document.getElementById("business_currency").value  = '';
    document.getElementById("tax_form_type").value  = '';
    document.getElementById("tax_form_num").value  = '';
    document.getElementById("tax_form_date").value  = '';
    document.getElementById("cust_seq_num").value  = '';

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
    document.getElementById("customer_id").value  = '';
    document.getElementById("address_type").value  = '';
    document.getElementById("address_field_seq").value  = '';
    document.getElementById("address_ctg").value  = '';
    document.getElementById("address_field_name").value  = '';
    document.getElementById("address_field_value").value  = '';
    document.getElementById("expiration_date").value  = '';
    document.getElementById("effective_date").value  = '';


    document.getElementById("bank_code").value  = '';
    document.getElementById("bank_name").value  = '';
    document.getElementById("bank_act_num").value  = '';
    document.getElementById("bank_act_holder").value  = '';
    document.getElementById("bank_act_type").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("state").value  = '';
    document.getElementById("zip").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("phone_list").value  = '';
    document.getElementById("email_list").value  = '';

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

  }
}
