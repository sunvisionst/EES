function populateTimetableId(inSessionType)
{
  var lTimetableId     = '';
  var lAcademicSession = document.getElementById("academic_session").value.split('-')[0];
  var lClassNum        = document.getElementById("class_num").value;
  var lClassSection    = document.getElementById("class_section").value;

  if(inSessionType =='I')
  {
     var lCourseId     = document.getElementById("course_id").value;
     var lCourseTerm   = document.getElementById("course_term").value;
     var lCourseStream = document.getElementById("course_stream").value;

     if ( lAcademicSession != null && lAcademicSession.length > 0 ) lTimetableId =  lTimetableId + lAcademicSession;
     if ( lCourseId != null && lCourseId.length > 0 )         lTimetableId =  lTimetableId + '/' +lCourseId;
     if ( lCourseStream != null && lCourseStream.length > 0 && ( lCourseStream != 'NA' || lCourseStream == '' ) ) 
       lTimetableId =  lTimetableId + '/' + lCourseStream;
     if ( lClassNum != null && lClassNum.length > 0 )         lTimetableId =  lTimetableId + '/' + lClassNum;
     if ( lCourseTerm != null && lCourseTerm.length > 0 )     lTimetableId =  lTimetableId + '/' + lCourseTerm;
     if ( lClassSection != null && lClassSection.length > 0 ) lTimetableId =  lTimetableId + '/' + lClassSection;
   }
   else
   if(inSessionType =='S')
   {
     if ( lAcademicSession != null && lAcademicSession.length > 0 ) lTimetableId =  lTimetableId + lAcademicSession;
     if ( lClassNum != null && lClassNum.length > 0 )         lTimetableId =  lTimetableId + '/' + lClassNum;
     if ( lClassSection != null && lClassSection.length > 0 ) lTimetableId =  lTimetableId + '/' + lClassSection;
   }
   document.getElementById("timetable_id").value = lTimetableId;
}

