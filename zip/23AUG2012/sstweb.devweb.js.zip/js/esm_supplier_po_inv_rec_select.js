function EsmSupplierPoInvRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_num").value  = document.getElementById("po_invoice_num"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_date").value  = document.getElementById("po_invoice_date"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_recv_date").value  = document.getElementById("po_invoice_recv_date"+"_r"+inRecNum).value; 
    document.getElementById("supp_invoice_num").value  = document.getElementById("supp_invoice_num"+"_r"+inRecNum).value; 
    document.getElementById("supp_invoice_date").value  = document.getElementById("supp_invoice_date"+"_r"+inRecNum).value; 
    document.getElementById("supplier_id").value  = document.getElementById("supplier_id"+"_r"+inRecNum).value; 
    document.getElementById("po_num").value  = document.getElementById("po_num"+"_r"+inRecNum).value; 
    document.getElementById("po_date").value  = document.getElementById("po_date"+"_r"+inRecNum).value; 
    document.getElementById("order_type").value  = document.getElementById("order_type"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("status_date").value  = document.getElementById("status_date"+"_r"+inRecNum).value; 
    document.getElementById("discount_percent").value  = document.getElementById("discount_percent"+"_r"+inRecNum).value; 
    document.getElementById("discount_fix").value  = document.getElementById("discount_fix"+"_r"+inRecNum).value; 
    document.getElementById("import_license_num").value  = document.getElementById("import_license_num"+"_r"+inRecNum).value; 
    document.getElementById("import_license_date").value  = document.getElementById("import_license_date"+"_r"+inRecNum).value; 
    document.getElementById("import_duty").value  = document.getElementById("import_duty"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_head1").value  = document.getElementById("po_invoice_head1"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_head2").value  = document.getElementById("po_invoice_head2"+"_r"+inRecNum).value; 
    document.getElementById("carrier").value  = document.getElementById("carrier"+"_r"+inRecNum).value; 
    document.getElementById("ship_load_date").value  = document.getElementById("ship_load_date"+"_r"+inRecNum).value; 
    document.getElementById("bl_num").value  = document.getElementById("bl_num"+"_r"+inRecNum).value; 
    document.getElementById("bl_date").value  = document.getElementById("bl_date"+"_r"+inRecNum).value; 
    document.getElementById("inv_amt_fc").value  = document.getElementById("inv_amt_fc"+"_r"+inRecNum).value; 
    document.getElementById("fc_id").value  = document.getElementById("fc_id"+"_r"+inRecNum).value; 
    document.getElementById("fc_exch_rate").value  = document.getElementById("fc_exch_rate"+"_r"+inRecNum).value; 
    document.getElementById("inv_amt_home_curr").value  = document.getElementById("inv_amt_home_curr"+"_r"+inRecNum).value; 
    document.getElementById("landing_cost").value  = document.getElementById("landing_cost"+"_r"+inRecNum).value; 
    document.getElementById("total_cost_incl_land").value  = document.getElementById("total_cost_incl_land"+"_r"+inRecNum).value; 
    document.getElementById("custom_duty").value  = document.getElementById("custom_duty"+"_r"+inRecNum).value; 
    document.getElementById("additional_duty").value  = document.getElementById("additional_duty"+"_r"+inRecNum).value; 
    document.getElementById("inland_frieght").value  = document.getElementById("inland_frieght"+"_r"+inRecNum).value; 
    document.getElementById("demrage_charge").value  = document.getElementById("demrage_charge"+"_r"+inRecNum).value; 
    document.getElementById("landing_amt").value  = document.getElementById("landing_amt"+"_r"+inRecNum).value; 
    document.getElementById("start_destination_id").value  = document.getElementById("start_destination_id"+"_r"+inRecNum).value; 
    document.getElementById("port_of_shipment").value  = document.getElementById("port_of_shipment"+"_r"+inRecNum).value; 
    document.getElementById("port_of_unloading").value  = document.getElementById("port_of_unloading"+"_r"+inRecNum).value; 
    document.getElementById("final_destination").value  = document.getElementById("final_destination"+"_r"+inRecNum).value; 
    document.getElementById("paid_amt").value  = document.getElementById("paid_amt"+"_r"+inRecNum).value; 
    document.getElementById("account_num").value  = document.getElementById("account_num"+"_r"+inRecNum).value; 
    document.getElementById("account_date").value  = document.getElementById("account_date"+"_r"+inRecNum).value; 
    document.getElementById("issued_by").value  = document.getElementById("issued_by"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("po_invoice_num").value  = '';
    document.getElementById("po_invoice_date").value  = '';
    document.getElementById("po_invoice_recv_date").value  = '';
    document.getElementById("supp_invoice_num").value  = '';
    document.getElementById("supp_invoice_date").value  = '';
    document.getElementById("supplier_id").value  = '';
    document.getElementById("po_num").value  = '';
    document.getElementById("po_date").value  = '';
    document.getElementById("order_type").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("status_date").value  = '';
    document.getElementById("discount_percent").value  = '';
    document.getElementById("discount_fix").value  = '';
    document.getElementById("import_license_num").value  = '';
    document.getElementById("import_license_date").value  = '';
    document.getElementById("import_duty").value  = '';
    document.getElementById("po_invoice_head1").value  = '';
    document.getElementById("po_invoice_head2").value  = '';
    document.getElementById("carrier").value  = '';
    document.getElementById("ship_load_date").value  = '';
    document.getElementById("bl_num").value  = '';
    document.getElementById("bl_date").value  = '';
    document.getElementById("inv_amt_fc").value  = '';
    document.getElementById("fc_id").value  = '';
    document.getElementById("fc_exch_rate").value  = '';
    document.getElementById("inv_amt_home_curr").value  = '';
    document.getElementById("landing_cost").value  = '';
    document.getElementById("total_cost_incl_land").value  = '';
    document.getElementById("custom_duty").value  = '';
    document.getElementById("additional_duty").value  = '';
    document.getElementById("inland_frieght").value  = '';
    document.getElementById("demrage_charge").value  = '';
    document.getElementById("landing_amt").value  = '';
    document.getElementById("start_destination_id").value  = '';
    document.getElementById("port_of_shipment").value  = '';
    document.getElementById("port_of_unloading").value  = '';
    document.getElementById("final_destination").value  = '';
    document.getElementById("paid_amt").value  = '';
    document.getElementById("account_num").value  = '';
    document.getElementById("account_date").value  = '';
    document.getElementById("issued_by").value  = '';
  }
}
