function EesAsChecklistRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("checklist_id").value  = document.getElementById("checklist_id"+"_r"+inRecNum).value; 
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
    document.getElementById("checklist_sts").value  = document.getElementById("checklist_sts"+"_r"+inRecNum).value; 
    document.getElementById("checklist_sts_date").value  = document.getElementById("checklist_sts_date"+"_r"+inRecNum).value; 
    document.getElementById("apr_sts_date").value  = document.getElementById("apr_sts_date"+"_r"+inRecNum).value; 
    document.getElementById("apr_remark").value  = document.getElementById("apr_remark"+"_r"+inRecNum).value; 
    document.getElementById("rej_remark").value  = document.getElementById("rej_remark"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("academic_session").value  = '';
    document.getElementById("checklist_id").value  = '';
    document.getElementById("description").value  = '';
    document.getElementById("checklist_sts").value  = '';
    document.getElementById("checklist_sts_date").value  = '';
    document.getElementById("apr_sts_date").value  = '';
    document.getElementById("apr_remark").value  = '';
    document.getElementById("rej_remark").value  = '';
  }
}
