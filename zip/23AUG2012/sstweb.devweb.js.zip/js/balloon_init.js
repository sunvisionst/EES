
 var lBalloonObj;
 var box;
 var fadeBox;
 function invoke_balloon( evt, inBalloonType, inToolTipText )
 {
   //alert('inBalloonType, inToolTipText '+inBalloonType+' '+inToolTipText );
   if ( inBalloonType == 'WHITE' ) 
   { 
     lBalloonObj = new Balloon;
     lBalloonObj.showTooltip(evt, inToolTipText);
   } 
   else
   if ( inBalloonType == 'BLUE' ) 
   {
     // stemless,shadowless blue balloon
     lBalloonObj  = new Balloon;
     lBalloonObj.balloonTextSize  = '90%';
     //lBalloonObj.images           = 'images/balloons'; // COMMENTED BECAUSE INIT IN CONFIG CLASS FILE
     lBalloonObj.balloonImage     = 'balloon.png';
     //lBalloonObj.balloonImage     = 'blue_balloon.png';
     lBalloonObj.vOffset          = 15;
     //lBalloonObj.shadow           = 0;
     //lBalloonObj.stem             = false;
     lBalloonObj.ieImage          = null;
     lBalloonObj.showTooltip(evt, inToolTipText);
   }
   else
   if ( inBalloonType == 'STICKY' ) 
   { 
     lBalloonObj = new Balloon;
     lBalloonObj.showTooltip(evt, inToolTipText,1);
   } 
   else
   if ( inBalloonType == 'POPUP' ) 
   { 
     // a plainer popup box
     box         = new Box;
     box.bgcolor     = 'ivory';
     box.fontColor   = 'green';
     box.borderStyle = '4px ridge blue';
     box.showTooltip(evt, inToolTipText,1);
   } 
   else
   if ( inBalloonType == 'FADED' ) 
   { 
     // a box that fades in/out
     fadeBox     = new Box;
     fadeBox.bgColor     = 'url(../images/SST/sst_blue_rectangle.jpg)';//'black';
     fadeBox.fontColor   = 'black';
     fadeBox.borderStyle = 'none';
     fadeBox.delayTime   = 200;
     fadeBox.allowFade   = true;
     fadeBox.fadeIn      = 750;
     fadeBox.fadeOut     = 200;
     fadeBox.showTooltip(evt, inToolTipText,1);
   } 
   else
   if ( inBalloonType == 'IMAGE' ) 
   { 
     lBalloonObj = new Balloon;
     lBalloonObj.showTooltip(evt, 'load:'+inToolTipText);
   } 
 }
   
