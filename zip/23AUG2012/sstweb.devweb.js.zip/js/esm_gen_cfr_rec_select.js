function EsmGenCfrRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("followup_id").value  = document.getElementById("followup_id"+"_r"+inRecNum).value; 
    document.getElementById("link_followup_id").value  = document.getElementById("link_followup_id"+"_r"+inRecNum).value; 
    document.getElementById("prospect_name").value  = document.getElementById("prospect_name"+"_r"+inRecNum).value; 
    document.getElementById("follow_type").value  = document.getElementById("follow_type"+"_r"+inRecNum).value; 
    document.getElementById("followup_mode").value  = document.getElementById("followup_mode"+"_r"+inRecNum).value; 
    document.getElementById("followup_date").value  = document.getElementById("followup_date"+"_r"+inRecNum).value; 
    document.getElementById("followup_time").value  = document.getElementById("followup_time"+"_r"+inRecNum).value; 
    document.getElementById("followup_remark").value  = document.getElementById("followup_remark"+"_r"+inRecNum).value; 
    document.getElementById("followup_status").value  = document.getElementById("followup_status"+"_r"+inRecNum).value; 
    document.getElementById("interacted_person").value  = document.getElementById("interacted_person"+"_r"+inRecNum).value; 
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value; 
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value; 
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value; 
    document.getElementById("user_id").value  = document.getElementById("user_id"+"_r"+inRecNum).value; 
    document.getElementById("user_emp_id").value  = document.getElementById("user_emp_id"+"_r"+inRecNum).value; 
    document.getElementById("interacting_person").value  = document.getElementById("interacting_person"+"_r"+inRecNum).value; 
    document.getElementById("last_followup_ind").value  = document.getElementById("last_followup_ind"+"_r"+inRecNum).value; 
    document.getElementById("next_action_type").value  = document.getElementById("next_action_type"+"_r"+inRecNum).value; 
    document.getElementById("next_action_date").value  = document.getElementById("next_action_date"+"_r"+inRecNum).value; 
    document.getElementById("business_type").value  = document.getElementById("business_type"+"_r"+inRecNum).value; 
    document.getElementById("business_est_date").value  = document.getElementById("business_est_date"+"_r"+inRecNum).value; 
    document.getElementById("employee_strength").value  = document.getElementById("employee_strength"+"_r"+inRecNum).value; 
    document.getElementById("business_currency").value  = document.getElementById("business_currency"+"_r"+inRecNum).value; 
    document.getElementById("region_id").value  = document.getElementById("region_id"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("address_3").value  = document.getElementById("address_3"+"_r"+inRecNum).value; 
    document.getElementById("state_code").value  = document.getElementById("state_code"+"_r"+inRecNum).value; 
    document.getElementById("country_code").value  = document.getElementById("country_code"+"_r"+inRecNum).value; 
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value; 
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value; 
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("followup_id").value  = '';
    document.getElementById("link_followup_id").value  = '';
    document.getElementById("prospect_name").value  = '';
    document.getElementById("follow_type").value  = '';
    document.getElementById("followup_mode").value  = '';
    document.getElementById("followup_date").value  = '';
    document.getElementById("followup_time").value  = '';
    document.getElementById("followup_remark").value  = '';
    document.getElementById("followup_status").value  = '';
    document.getElementById("interacted_person").value  = '';
    document.getElementById("phone_list").value  = '';
    document.getElementById("email_list").value  = '';
    document.getElementById("fax_list").value  = '';
    document.getElementById("user_id").value  = '';
    document.getElementById("user_emp_id").value  = '';
    document.getElementById("interacting_person").value  = '';
    document.getElementById("last_followup_ind").value  = '';
    document.getElementById("next_action_type").value  = '';
    document.getElementById("next_action_date").value  = '';
    document.getElementById("business_type").value  = '';
    document.getElementById("business_est_date").value  = '';
    document.getElementById("employee_strength").value  = '';
    document.getElementById("business_currency").value  = '';
    document.getElementById("region_id").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
    document.getElementById("address_3").value  = '';
    document.getElementById("state_code").value  = '';
    document.getElementById("country_code").value  = '';
    document.getElementById("city").value  = '';
    document.getElementById("state").value  = '';
    document.getElementById("zip").value  = '';
  }
}
