function pop_stud_fee_head()
{
   var lRecNumCount = 1;

   var lStudentCtgObj = document.getElementById('student_ctg');
   for (var lRecNum = 1; lRecNum <= lEesFeeHeadTabObjJSArr.length; lRecNum++)
   {
     //alert("hello "+lRecNum);
     if ( lEesFeeHeadTabObjJSArr[lRecNum-1].fee_flag == 'O' )
     {
       document.getElementById("fee_head"+"_r"+lRecNumCount).value = lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head;
       document.getElementById("default_amt"+"_r"+lRecNumCount).value = lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt;
       document.getElementById("paid_amt"+"_r"+lRecNumCount).value 
        = lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt
          - calcConcession( lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head 
                          , lStudentCtgObj
                          , lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt );
       document.getElementById("late_fee_amt"+"_r"+lRecNumCount).value = 0;
                 
 

      lRecNumCount++;
     }
     else
     if ( lEesFeeHeadTabObjJSArr[lRecNum-1].fee_flag == 'Y' )
     {
       document.getElementById("fee_head"+"_r"+lRecNumCount).value = lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head;
       document.getElementById("default_amt"+"_r"+lRecNumCount).value = lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt;
       document.getElementById("paid_amt"+"_r"+lRecNumCount).value 
        = lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt
          - calcConcession( lEesFeeHeadTabObjJSArr[lRecNum-1].fee_head
                          , lStudentCtgObj
                          , lEesFeeHeadTabObjJSArr[lRecNum-1].default_amt );
       document.getElementById("late_fee_amt"+"_r"+lRecNumCount).value = 0;
       lRecNumCount++;
     }
   }
}
