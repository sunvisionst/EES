function EesFeeCycleItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("cycle_id").value  = document.getElementById("cycle_id"+"_r"+inRecNum).value; 
    document.getElementById("fee_head").value  = document.getElementById("fee_head"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value  = '';
    document.getElementById("academic_session").value  = '';
    document.getElementById("cycle_id").value  = '';
    document.getElementById("fee_head").value  = '';
    document.getElementById("remark").value  = '';
  }
}
