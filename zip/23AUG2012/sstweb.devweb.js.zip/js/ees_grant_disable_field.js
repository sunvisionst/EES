function EesGrantDisable()
{
  var lSubmitObj;
  if ( document.getElementById("installment_flag").value  == 'N' )
  {
       //      document.getElementById("installment_flag").value   = document.getElementById("installment_flag"+"_r"+inRecNum).value;
    document.getElementById("installment_type").value           = '';
    document.getElementById("installment_period").value         = '';
    document.getElementById("current_installment_id").value     = '';
    document.getElementById("next_installment_id").value        = '';
  
    lSubmitObj = document.getElementById("installment_type"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("installment_period"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("current_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("next_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
  }
  else
  {
       lSubmitObj = document.getElementById("installment_type"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("installment_period"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("current_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("next_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
  }
}
