function EesExamRoomInvStsRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("exam_id").value      = document.getElementById("exam_id"+"_r"+inRecNum).value;
    document.getElementById("room_num").value     = document.getElementById("room_num"+"_r"+inRecNum).value;
    document.getElementById("room_incharge").value= document.getElementById("room_incharge"+"_r"+inRecNum).value;
    document.getElementById("room_sts").value     = document.getElementById("room_sts"+"_r"+inRecNum).value;
    document.getElementById("incharge_sts").value = document.getElementById("incharge_sts"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("exam_id").value       = '';
    document.getElementById("room_num").value      = '';
    document.getElementById("room_incharge").value = '';
    document.getElementById("room_sts").value      = '';
    document.getElementById("incharge_sts").value  = '';
    // add other fields like above
  }
}
