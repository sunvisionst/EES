function EesLabIdSchRecSelect( inSelectFlag, inRecNum)
{
  if ( inSelectFlag == 'Y' )
  {
    document.getElementById("org_id").value        = document.getElementById("org_id_menu"+"_r"+inRecNum).value;
    document.getElementById("lab_id").value        = document.getElementById("lab_id_menu"+"_r"+inRecNum).value;
    //document.getElementById("assistant_name").value= document.getElementById("assistant_name_menu"+"_r"+inRecNum).value;
    document.getElementById("assistant_id").value= document.getElementById("assistant_name_menu"+"_r"+inRecNum).value;
  }
 /* else
  {
    document.getElementById("org_id").value        = '';
    document.getElementById("lab_id").value        = '';
    document.getElementById("assistant_name").value= '';
  }
*/
}
