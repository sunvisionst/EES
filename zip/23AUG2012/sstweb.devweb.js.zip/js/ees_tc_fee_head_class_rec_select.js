function EesFeeHeadClassRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    //document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    //document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    //document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    //document.getElementById("fee_head").value  = document.getElementById("fee_head"+"_r"+inRecNum).value; 
    document.getElementById("default_amt").value  = document.getElementById("default_amt"+"_r"+inRecNum).value; 
    document.getElementById("installment_flag").value  = document.getElementById("installment_flag"+"_r"+inRecNum).value; 
    document.getElementById("discount_percent").value  = document.getElementById("discount_percent"+"_r"+inRecNum).value; 
    document.getElementById("num_installment").value  = document.getElementById("num_installment"+"_r"+inRecNum).value; 
    document.getElementById("installment_period").value  = document.getElementById("installment_period"+"_r"+inRecNum).value; 
    document.getElementById("adnl_fee_per_inst").value  = document.getElementById("adnl_fee_per_inst"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';

    lCurrAcademicSession = document.getElementById("curr_academic_session");
    if ( lCurrAcademicSession && lCurrAcademicSession.value.length > 0 )
      document.getElementById("academic_session").value  = lCurrAcademicSession.value;
    else
      document.getElementById("academic_session").value  = '';

    document.getElementById("course_id").value  = '';
    //document.getElementById("class_num").value  = '';
    //document.getElementById("course_stream").value  = '';
    //document.getElementById("course_term").value  = '';
    //document.getElementById("fee_head").value  = '';
    document.getElementById("default_amt").value  = '0.00';
    document.getElementById("installment_flag").value  = 'N';
    document.getElementById("discount_percent").value  = '0.00';
    document.getElementById("num_installment").value  = '';
    document.getElementById("installment_period").value  = '';
    document.getElementById("adnl_fee_per_inst").value  = '0.00';
  }
}
