function ees_exam_schedule_check_list( evt, inExamScheduleArr )
{
  //alert('AAAAAAAAA');
  //alert('inExamScheduleArr'+inExamScheduleArr);
  var return_value = 0;

  {
    var lEmptyFieldlist = "";
    var lFieldObj       = "";
    var lFieldLabelObj  = "";
    var lEmptyFieldlistArr = new Array();
    var k = 0;
    for ( var lFieldNum1 = 1; lFieldNum1 <= inExamScheduleArr; lFieldNum1++ )
    {
      for ( var lFieldNum = 1; lFieldNum <= 4; lFieldNum++ )
      {
        lFieldObj  = document.getElementById("room_num_r"+lFieldNum1+"_"+lFieldNum);
        if ( lFieldObj != null && stringTrim(lFieldObj.value).length > 0 )
          ;
        else
          lEmptyFieldlist += "Room No.("+lFieldNum1+"x"+lFieldNum+"),"; 
        lFieldObj  = document.getElementById("roll_num_start_r"+lFieldNum1+"_"+lFieldNum);
        if ( lFieldObj != null && stringTrim(lFieldObj.value).length > 0 )
          ;
        else
          lEmptyFieldlist += "Roll Start("+lFieldNum1+"x"+lFieldNum+"),"; 
        lFieldObj  = document.getElementById("roll_num_end_r"+lFieldNum1+"_"+lFieldNum);
        if ( lFieldObj != null && stringTrim(lFieldObj.value).length > 0 )
          ;
        else
          lEmptyFieldlist += "Roll End("+lFieldNum1+"x"+lFieldNum+"),"; 
        lFieldObj  = document.getElementById("room_incharge_1_r"+lFieldNum1+"_"+lFieldNum);
        if ( lFieldObj != null && stringTrim(lFieldObj.value).length > 0 )
          ;
        else
          lEmptyFieldlist += "Room Incharge("+lFieldNum1+"x"+lFieldNum+"),"; 
        break;
      }
    } 

    if ( lEmptyFieldlist.length > 0 )
    {
      return_value = -1;
      lEmptyFieldlist = lEmptyFieldlist.substring(0,(lEmptyFieldlist.length)-1); 
      alert("Please fill  "+ lEmptyFieldlist +" to continue.");
      //document.getElementById(lFieldObjArr[lFieldObjArr.length-k]).focus();

      //------------------------------------------------------------
      var lBrowserName = getBrowserName();
      if ( lBrowserName == 'Microsoft Internet Explorer' )
        window.event.returnValue=false;
      else
      if ( lBrowserName == 'Netscape' )
      {
         evt.preventDefault();
         evt.stopPropagation();
      }
      //------------------------------------------------------------
    }
  }
  return return_value;
}


function stringTrim( inString )
{
  a = inString.replace(/^\s+/, '');
  return a.replace(/\s+$/, '');
};
