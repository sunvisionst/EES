function EesMarksheetLoRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("class_num").value      = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("ms_subject_code").value    = document.getElementById("ms_subject_code"+"_r"+inRecNum).value;
    document.getElementById("grp_subject_code").value   = document.getElementById("grp_subject_code"+"_r"+inRecNum).value;
    document.getElementById("group_subject_ind").value  = document.getElementById("group_subject_ind"+"_r"+inRecNum).value;
    document.getElementById("act_subject_code").value   = document.getElementById("act_subject_code"+"_r"+inRecNum).value;
    document.getElementById("description").value        = document.getElementById("description"+"_r"+inRecNum).value;
    document.getElementById("subject_type").value       = document.getElementById("subject_type"+"_r"+inRecNum).value;
    document.getElementById("subject_ctg").value        = document.getElementById("subject_ctg"+"_r"+inRecNum).value;
    document.getElementById("subject_seq").value        = document.getElementById("subject_seq"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("class_num").value      = '';
    document.getElementById("ms_subject_code").value      = '';
    document.getElementById("grp_subject_code").value     = ''; 
    document.getElementById("group_subject_ind").value    = '';
    document.getElementById("act_subject_code").value     = '';
    document.getElementById("description").value          = '';
    document.getElementById("subject_type").value         = '';
    document.getElementById("subject_ctg").value          = '';
    document.getElementById("subject_seq").value          = '';

    // add other fields like above
  }
}
