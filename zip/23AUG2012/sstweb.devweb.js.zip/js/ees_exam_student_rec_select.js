function EesExamStudentRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("exam_id").value       = document.getElementById("exam_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value     = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_section").value = document.getElementById("class_section"+"_r"+inRecNum).value;
   document.getElementById("subject_code").value   = document.getElementById("subject_code"+"_r"+inRecNum).value;
   document.getElementById("student_id").value     = document.getElementById("student_id"+"_r"+inRecNum).value;
   document.getElementById("roll_num").value       = document.getElementById("roll_num"+"_r"+inRecNum).value;
   document.getElementById("enrollment_num").value = document.getElementById("enrollment_num"+"_r"+inRecNum).value;
   document.getElementById("room_num").value       = document.getElementById("room_num"+"_r"+inRecNum).value;
   document.getElementById("exam_date").value      = document.getElementById("exam_date"+"_r"+inRecNum).value;
   document.getElementById("student_status").value = document.getElementById("student_status"+"_r"+inRecNum).value;
  document.getElementById("max_mark").value        = document.getElementById("max_mark"+"_r"+inRecNum).value;
  document.getElementById("obtained_mark").value   = document.getElementById("obtained_mark"+"_r"+inRecNum).value;





 // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;


   document.getElementById("exam_id").value            = '';
   document.getElementById("class_num").value          = '';
   document.getElementById("class_section").value      = '';
   document.getElementById("subject_code").value       = '';
   document.getElementById("student_id").value         = '';
   document.getElementById("roll_num").value           = '';
   document.getElementById("enrollment_num").value     = '';
   document.getElementById("room_num").value           = '';
   document.getElementById("exam_date").value           = '';
   document.getElementById("student_status").value     = '';
   document.getElementById("max_mark").value           = '';
   document.getElementById("obtained_mark").value      = '';
 // add other fields like above
  }
}
