function EesPeriodRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value          = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("period_num").value      = document.getElementById("period_num"+"_r"+inRecNum).value;
    document.getElementById("period_type").value     = document.getElementById("period_type"+"_r"+inRecNum).value;
    document.getElementById("start_time").value      = document.getElementById("start_time"+"_r"+inRecNum).value;
    document.getElementById("end_time").value        = document.getElementById("end_time"+"_r"+inRecNum).value;        
    document.getElementById("period_ind").value      = document.getElementById("period_ind"+"_r"+inRecNum).value;        
    document.getElementById("period_desc").value     = document.getElementById("period_desc"+"_r"+inRecNum).value;        


// add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value          = '';
    document.getElementById("period_num").value      = '';
    //document.getElementById("period_type").value     = '';
    document.getElementById("start_time").value      = '';
    document.getElementById("end_time").value        = '';
    document.getElementById("period_ind").value      = '';
    document.getElementById("period_desc").value     = '';



    // add other fields like above
  }
}
