function EesSchDateFromTOButtenVld()
{
  if(document.getElementById("sch_date_from").value  == '' && document.getElementById("sch_date_to").value  == '' ) 
  {
    alert("Select Date From and Date To");

    window.event.returnValue = false;
  }
  else
   if(document.getElementById("sch_date_from").value  == '' || document.getElementById("sch_date_to").value  == ''  )
  {
    alert("Select Both Date To Continue ");

    window.event.returnValue = false;
  }
}
