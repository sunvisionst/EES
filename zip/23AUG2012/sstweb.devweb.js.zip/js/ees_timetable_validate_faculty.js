function validateFaculty( inSemFlag, inFacultyDetailListing, lRow, lCol )
{

  
  //////////////////////////////////////////////////////////////////////////////////////////

      //////////////////////////////////////////////////////////////////////////////////////////
      if ( inSemFlag == 1 ) checkSemaphore('sst_semaphore');
      //////////////////////////////////////////////////////////////////////////////////////////

      /////////////////////////////////////////////////////////////////////////////////////////////////////////
      var lEmployeeId  = document.getElementById("employee_id"+"_r"+lRow+"_c"+lCol).value;
      var lSubjectCode = document.getElementById("subject_code"+"_r"+lRow+"_c"+lCol).value;

      var lWeekDay   = lRow;
      var lPeriodNum = lCol;
      var lFlag      = 0;

      var lFacultyDetailListingArr = new Array();
      FacultyDetailListingArr = inFacultyDetailListing.split('$');

 
      for ( var lFieldCnt = 0; lFieldCnt < FacultyDetailListingArr.length; lFieldCnt++)
      {
        var lFacultyWeekPeriodDetail = new Array();
        lFacultyWeekPeriodDetail = FacultyDetailListingArr[lFieldCnt].split(',');

        //alert('EMP ID : '+lFacultyWeekPeriodDetail[0]+' - '+lEmployeeId);
        // alert('Week Day : '+lFacultyWeekPeriodDetail[1]+' - '+lWeekDay);
        // alert('Period : '+lFacultyWeekPeriodDetail[2]+' - '+lPeriodNum);

        if( lFacultyWeekPeriodDetail[0] == lEmployeeId )
        {
          if( lFacultyWeekPeriodDetail[1] == parseInt(lWeekDay)  && lFacultyWeekPeriodDetail[2] ==  parseInt(lPeriodNum) )
          {
            lFlag = 1;
            alert('This Faculty is Already Assigned in Class '+lFacultyWeekPeriodDetail[4]+' For Subject '+lFacultyWeekPeriodDetail[3]);
            document.getElementById("employee_id"+"_r"+lRow+"_c"+lCol).value  = '';
            document.getElementById("subject_code"+"_r"+lRow+"_c"+lCol).value = '';
            break;
          }
        }
      }

      //////////////////////////////////////////////////////////////////////////////////////////
      if ( inSemFlag == 1 ) releaseSemaphore('sst_semaphore');
      //////////////////////////////////////////////////////////////////////////////////////////

}
