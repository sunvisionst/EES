function EesRouteRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value      = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("route_id").value    = document.getElementById("route_id"+"_r"+inRecNum).value;
    document.getElementById("route_name").value  = document.getElementById("route_name"+"_r"+inRecNum).value;   
    document.getElementById("start_loc").value   = document.getElementById("start_loc"+"_r"+inRecNum).value;   
    document.getElementById("end_loc").value     = document.getElementById("end_loc"+"_r"+inRecNum).value;   

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value        = '';
    //document.getElementById("route_id").value      = '';
    document.getElementById("route_name").value    = '';  
    document.getElementById("start_loc").value     = '';   
    document.getElementById("end_loc").value       = '';  

    // add other fields like above
  }

  action_1_on_EesRouteRecSelect();
}




function action_1_on_EesRouteRecSelect()
{
  //-------------------------------------------------------------------
  document.getElementById("vehicle_id_tr").style.display             = 'none';
  document.getElementById("vehicle_action_tr").style.display         = 'none';
  document.getElementById("vehicle_detail_multi_part").style.display = 'none';
  document.getElementById("vehicle_mapping_select_checkbox").checked = false;

  document.getElementById("trip_num_tr").style.display               = 'none';
  //document.getElementById("trip_action_tr").style.display            = 'none';
  //document.getElementById("trip_detail_multi_part").style.display    = 'none';
  document.getElementById("trip_mapping_select_checkbox").checked    = false;
  //-------------------------------------------------------------------
}
