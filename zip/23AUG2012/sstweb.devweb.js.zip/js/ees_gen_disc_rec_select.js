function EesGenDiscRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("disc_code").value  = document.getElementById("disc_code"+"_r"+inRecNum).value; 
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
    document.getElementById("score").value  = document.getElementById("score"+"_r"+inRecNum).value; 
    document.getElementById("fine_ind").value  = document.getElementById("fine_ind"+"_r"+inRecNum).value; 
    document.getElementById("default_amt").value  = document.getElementById("default_amt"+"_r"+inRecNum).value; 
    //document.getElementById("uom_type").value  = document.getElementById("uom_type"+"_r"+inRecNum).value; 
    //document.getElementById("uom_qty").value  = document.getElementById("uom_qty"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("disc_code").value  = '';
    document.getElementById("description").value  = '';
    document.getElementById("score").value  = '';
    document.getElementById("fine_ind").value  = '';
    document.getElementById("default_amt").value  = '';
    //document.getElementById("uom_type").value  = '';
    //document.getElementById("uom_qty").value  = '';
  }
}
