function setFocusOnTextBox()
{
 var lFocusObj;
  lFocusObj = document.getElementById('roll_num');
  lFocusObj.focus();
}
