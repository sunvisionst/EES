function EesHostelVisitRegRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value;
   document.getElementById("hostel_id").value     = document.getElementById("hostel_id"+"_r"+inRecNum).value;
   document.getElementById("visit_date").value    = document.getElementById("visit_date"+"_r"+inRecNum).value;
   document.getElementById("seq_num").value       = document.getElementById("seq_num"+"_r"+inRecNum).value;
   document.getElementById("visitor_name").value  = document.getElementById("visitor_name"+"_r"+inRecNum).value;
   document.getElementById("address_1").value     = document.getElementById("address_1"+"_r"+inRecNum).value;
   document.getElementById("address_2").value     = document.getElementById("address_2"+"_r"+inRecNum).value;
   document.getElementById("to_meet_id").value    = document.getElementById("to_meet_id"+"_r"+inRecNum).value;
   document.getElementById("to_meet_type").value  = document.getElementById("to_meet_type"+"_r"+inRecNum).value;
   document.getElementById("visit_time").value    = document.getElementById("visit_time"+"_r"+inRecNum).value;
   document.getElementById("out_time").value      = document.getElementById("out_time"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value          = '';
    document.getElementById("hostel_id").value       = '';
    document.getElementById("visit_date").value      = '';
    document.getElementById("seq_num").value         = '';
    document.getElementById("visitor_name").value    = '';
    document.getElementById("address_1").value       = '';
    document.getElementById("address_2").value       = '';
    document.getElementById("to_meet_id").value      = '';
    document.getElementById("to_meet_type").value    = '';
    document.getElementById("visit_time").value      = '';
    document.getElementById("out_time").value        = '';
    // add other fields like above
  }
}
