function setRemarkField(inRemark,inItemCode)
{

   var lItemCode = document.getElementById(inItemCode);
   var lRemark   = document.getElementById(inRemark);
   
   if ( lRemark.value=="" ) 
   ;
   else 
     lItemCode.value = lRemark.value;
}
