document.write('<option value=></option>');
document.write('<option value=15>Graduation</option>');
document.write('<option value=12>12th</option>');
document.write('<option value=10>10th</option>');
