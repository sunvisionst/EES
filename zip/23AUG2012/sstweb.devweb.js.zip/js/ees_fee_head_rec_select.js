function EesFeeHeadRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("fee_head").value  = document.getElementById("fee_head"+"_r"+inRecNum).value; 
    document.getElementById("default_amt").value  = document.getElementById("default_amt"+"_r"+inRecNum).value; 
    document.getElementById("class_flag").value  = document.getElementById("class_flag"+"_r"+inRecNum).value; 
    document.getElementById("fee_flag").value  = document.getElementById("fee_flag"+"_r"+inRecNum).value; 
    document.getElementById("late_fee_flag").value  = document.getElementById("late_fee_flag"+"_r"+inRecNum).value; 
    document.getElementById("adm_fee_ind").value  = document.getElementById("adm_fee_ind"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("fee_head").value  = '';
    document.getElementById("default_amt").value  = '';
    document.getElementById("class_flag").value  = '';
    document.getElementById("fee_flag").value  = '';
    document.getElementById("late_fee_flag").value  = '';
    document.getElementById("adm_fee_ind").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("description").value  = '';
  }
}
