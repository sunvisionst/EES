function populateSubjectCode( inOrgCtg )
{
  var lSubjectCode = '';
  var lCourseIdObj     = document.getElementById("course_id");
  var lCourseStreamObj = document.getElementById("course_stream");
  var lClassNumObj     = document.getElementById("class_num");
  var lCourseTermObj   = document.getElementById("course_term");
  var lShortCodeObj    = document.getElementById("short_subject_code");


  //---------------------------------------------------------------
  if ( inOrgCtg == 'I')
  {
    var lCourseIdListNoStreamObj = document.getElementById('course_id_list_no_stream_str');
    if ( lCourseIdListNoStreamObj && ( lCourseIdListNoStreamObj.value.indexOf(lCourseIdObj.value) != -1 ) )
      lSubjectCode = lCourseIdObj.value+"/"+lClassNumObj.value+"/"+lCourseTermObj.value;
    else
      lSubjectCode = lCourseIdObj.value+"/"+lCourseStreamObj.value+"/"+lClassNumObj.value+"/"+lCourseTermObj.value;
  } 
  else
  if ( inOrgCtg =='S')
  {
    var lClassNumListStreamObj = document.getElementById('class_num_list_stream_str');
    if ( lClassNumListStreamObj && ( lClassNumListStreamObj.value.indexOf(lClassNumObj.value) != -1 ) )
      lSubjectCodeObj.value = lClassNumObj.value+"/"+lCourseStreamObj.value;
    else
      lSubjectCodeObj.value = lClassNumObj.value;
  }

  if ( lShortCodeObj.value != null && lShortCodeObj.value.length >0 )
    document.getElementById("subject_code").value = lShortCodeObj.value+"-"+lSubjectCode;
  else
    document.getElementById("subject_code").value = '';
  //---------------------------------------------------------------

  //---------------------------------------------------------------
  var lSubjectType     = document.getElementById("subject_type");
  if ( lSubjectType && lShortCodeObj && document.getElementById("description") )
    document.getElementById("description").value = lSubjectType.value+'-'+lShortCodeObj.value;
  //---------------------------------------------------------------

}
