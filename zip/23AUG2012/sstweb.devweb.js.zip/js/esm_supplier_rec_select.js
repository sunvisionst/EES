function EsmSupplierRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("supplier_id").value  = document.getElementById("supplier_id"+"_r"+inRecNum).value; 
    document.getElementById("supplier_type").value  = document.getElementById("supplier_type"+"_r"+inRecNum).value; 
    document.getElementById("supplier_ctg").value  = document.getElementById("supplier_ctg"+"_r"+inRecNum).value; 
    document.getElementById("supplier_name").value  = document.getElementById("supplier_name"+"_r"+inRecNum).value; 
    document.getElementById("referred_by").value  = document.getElementById("referred_by"+"_r"+inRecNum).value; 
    document.getElementById("turn_over").value  = document.getElementById("turn_over"+"_r"+inRecNum).value; 
    document.getElementById("supply_capacity").value  = document.getElementById("supply_capacity"+"_r"+inRecNum).value; 
    document.getElementById("area_code").value  = document.getElementById("area_code"+"_r"+inRecNum).value; 
    document.getElementById("business_type").value  = document.getElementById("business_type"+"_r"+inRecNum).value; 
    document.getElementById("business_est_date").value  = document.getElementById("business_est_date"+"_r"+inRecNum).value; 
    document.getElementById("employee_strength").value  = document.getElementById("employee_strength"+"_r"+inRecNum).value; 
    document.getElementById("pan_num").value  = document.getElementById("pan_num"+"_r"+inRecNum).value; 
    document.getElementById("tan_num").value  = document.getElementById("tan_num"+"_r"+inRecNum).value; 
    document.getElementById("account_num").value  = document.getElementById("account_num"+"_r"+inRecNum).value; 
    document.getElementById("bal_close").value  = document.getElementById("bal_close"+"_r"+inRecNum).value; 
    document.getElementById("bal_open").value  = document.getElementById("bal_open"+"_r"+inRecNum).value; 
    document.getElementById("country_code").value  = document.getElementById("country_code"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value; 
    //document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value; 
    document.getElementById("business_currency").value  = document.getElementById("business_currency"+"_r"+inRecNum).value; 
    document.getElementById("cst_form_num").value  = document.getElementById("cst_form_num"+"_r"+inRecNum).value; 
    document.getElementById("cst_form_date").value  = document.getElementById("cst_form_date"+"_r"+inRecNum).value; 
    document.getElementById("lst_form_num").value  = document.getElementById("lst_form_num"+"_r"+inRecNum).value; 
    document.getElementById("lst_form_date").value  = document.getElementById("lst_form_date"+"_r"+inRecNum).value; 
    document.getElementById("tin_num").value  = document.getElementById("tin_num"+"_r"+inRecNum).value; 
    document.getElementById("tin_date").value  = document.getElementById("tin_date"+"_r"+inRecNum).value; 
    document.getElementById("pan_date").value  = document.getElementById("pan_date"+"_r"+inRecNum).value; 
    document.getElementById("tan_date").value  = document.getElementById("tan_date"+"_r"+inRecNum).value; 
    document.getElementById("strn_num").value  = document.getElementById("strn_num"+"_r"+inRecNum).value; 
    document.getElementById("strn_date").value  = document.getElementById("strn_date"+"_r"+inRecNum).value; 
    //document.getElementById("dr_amt").value  = document.getElementById("dr_amt"+"_r"+inRecNum).value; 
    //document.getElementById("cr_amt").value  = document.getElementById("cr_amt"+"_r"+inRecNum).value; 
    //document.getElementById("ar_bal").value  = document.getElementById("ar_bal"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("supplier_id").value  = '';
    document.getElementById("supplier_type").value  = '';
    document.getElementById("supplier_ctg").value  = '';
    document.getElementById("supplier_name").value  = '';
    document.getElementById("referred_by").value  = '';
    document.getElementById("turn_over").value  = '';
    document.getElementById("supply_capacity").value  = '';
    document.getElementById("area_code").value  = '';
    document.getElementById("business_type").value  = '';
    document.getElementById("business_est_date").value  = '';
    document.getElementById("employee_strength").value  = '';
    document.getElementById("pan_num").value  = '';
    document.getElementById("tan_num").value  = '';
    document.getElementById("account_num").value  = '';
    document.getElementById("bal_close").value  = '';
    document.getElementById("bal_open").value  = '';
    document.getElementById("country_code").value  = '';
    document.getElementById("status").value  = '';
    //document.getElementById("expiration_date").value  = '';
    //document.getElementById("effective_date").value  = '';
    document.getElementById("business_currency").value  = '';
    document.getElementById("cst_form_num").value  = '';
    document.getElementById("cst_form_date").value  = '';
    document.getElementById("lst_form_num").value  = '';
    document.getElementById("lst_form_date").value  = '';
    document.getElementById("tin_num").value  = '';
    document.getElementById("tin_date").value  = '';
    document.getElementById("pan_date").value  = '';
    document.getElementById("tan_date").value  = '';
    document.getElementById("strn_num").value  = '';
    document.getElementById("strn_date").value  = '';
    //document.getElementById("dr_amt").value  = '';
    //document.getElementById("cr_amt").value  = '';
    //document.getElementById("ar_bal").value  = '';
  }
}
