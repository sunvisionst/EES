function EesEventRegGuestRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("activity_id").value   = document.getElementById("activity_id"+"_r"+inRecNum).value;
    document.getElementById("event_id").value      = document.getElementById("event_id"+"_r"+inRecNum).value;
    document.getElementById("attendee_name").value = document.getElementById("attendee_name"+"_r"+inRecNum).value;
    document.getElementById("attendee_email").value= document.getElementById("attendee_email"+"_r"+inRecNum).value;
    document.getElementById("attendee_phone").value= document.getElementById("attendee_phone"+"_r"+inRecNum).value;
    document.getElementById("attendee_fax").value  = document.getElementById("attendee_fax"+"_r"+inRecNum).value;
    document.getElementById("status_date").value   = document.getElementById("status_date"+"_r"+inRecNum).value;
    document.getElementById("status").value        = document.getElementById("status"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("activity_id").value      = '';
    document.getElementById("event_id").value         = '';
    document.getElementById("attendee_name").value    = '';
    document.getElementById("attendee_email").value   = '';
    document.getElementById("attendee_phone").value   = '';
    document.getElementById("attendee_fax").value     = '';
    document.getElementById("status_date").value      = '';
    document.getElementById("status").value           = '';
    // add other fields like above
  }
}
