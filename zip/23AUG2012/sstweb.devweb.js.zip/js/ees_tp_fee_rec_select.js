function EesTpFeeRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("route_id").value  = document.getElementById("route_id"+"_r"+inRecNum).value; 
    document.getElementById("from_stoppage_id").value  = document.getElementById("from_stoppage_id"+"_r"+inRecNum).value; 
    document.getElementById("to_stoppage_id").value  = document.getElementById("to_stoppage_id"+"_r"+inRecNum).value; 
    document.getElementById("tp_charges").value  = document.getElementById("tp_charges"+"_r"+inRecNum).value; 
    document.getElementById("uom_type").value  = document.getElementById("uom_type"+"_r"+inRecNum).value; 
    document.getElementById("uom_qty").value  = document.getElementById("uom_qty"+"_r"+inRecNum).value; 
    document.getElementById("late_fee_flag").value  = document.getElementById("late_fee_flag"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("route_id").value  = '';
    document.getElementById("from_stoppage_id").value  = '';
    document.getElementById("to_stoppage_id").value  = '';
    document.getElementById("tp_charges").value  = '';
    document.getElementById("uom_type").value  = '';
    document.getElementById("uom_qty").value  = '';
    document.getElementById("late_fee_flag").value  = '';
  }
}
