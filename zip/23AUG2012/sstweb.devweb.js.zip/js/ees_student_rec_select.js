function EesStudentRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1");
    if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2");
    if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("student_id").value     = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").value         = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("student_name").value   = document.getElementById("student_name"+"_r"+inRecNum).value;
    document.getElementById("father_name").value    = document.getElementById("father_name"+"_r"+inRecNum).value;
    document.getElementById("student_ctg").value    = document.getElementById("student_ctg"+"_r"+inRecNum).value;   
    document.getElementById("dob").value            = document.getElementById("dob"+"_r"+inRecNum).value;   
    document.getElementById("doj").value            = document.getElementById("doj"+"_r"+inRecNum).value;   
    document.getElementById("p_address_1").value    = document.getElementById("p_address_1"+"_r"+inRecNum).value;   
    document.getElementById("p_address_2").value    = document.getElementById("p_address_2"+"_r"+inRecNum).value;   
    document.getElementById("class_std").value      = document.getElementById("class_std"+"_r"+inRecNum).value;   
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value;   
    document.getElementById("phone").value          = document.getElementById("phone"+"_r"+inRecNum).value;   
    document.getElementById("email_id").value       = document.getElementById("email_id"+"_r"+inRecNum).value;   
    document.getElementById("p_country").value      = document.getElementById("p_country"+"_r"+inRecNum).value;   
  }
  else
  {
    lSubmitObj = document.getElementById("submit1");
    if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2");
    if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("student_id").value     = "";
    document.getElementById("org_id").value         = "";
    document.getElementById("student_name").value   = "";
    document.getElementById("father_name").value    = "";
    document.getElementById("student_ctg").value    = "";
    document.getElementById("dob").value            = "";
    document.getElementById("doj").value            = "";
    document.getElementById("p_address_1").value    = "";
    document.getElementById("p_address_2").value    = "";
    document.getElementById("class_std").value      = "";
    document.getElementById("class_section").value  = "";
    document.getElementById("phone").value          = "";
    document.getElementById("email_id").value       = "";
    document.getElementById("p_country").value      = "";
  }
}
