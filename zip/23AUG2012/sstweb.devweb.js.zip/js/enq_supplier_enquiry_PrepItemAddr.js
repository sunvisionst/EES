
function enqSupplierEnquiryPrepIaddr( inMenuOption, inDBOpr,inRecNum )
{
    var lDelAddrTypeObj = document.getElementById("delivery_address_type_r"+inRecNum);
    if ( inMenuOption == 'Update' || inMenuOption == 'approveToSend' || inMenuOption == 'approveQuote' || inMenuOption == 'discardEnquiry' || inMenuOption == 'CNEnqV' )
    {
       if ( inDBOpr == 'Query' )
         var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum+"_dummy");
       else
         var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum);
    }
    else
    var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum+"_dummy");
    var lDeliveryAddress = "";
    if ( lDelAddrTypeObj.value != "" && lDelAddrTypeObj.value != 'N')
    {
      for ( var  lNumRec = 0; lNumRec < lEsmSupplierAddressTabObjJSArr.length; lNumRec++ )
      {
        if( lEsmSupplierAddressTabObjJSArr[lNumRec].address_type == lDelAddrTypeObj.value )
        {
          lDeliveryAddress = lDeliveryAddress + lEsmSupplierAddressTabObjJSArr[lNumRec].address_field_value;
          if ( lNumRec+1 < lEsmSupplierAddressTabObjJSArr.length )
            lDeliveryAddress = lDeliveryAddress + " , ";
        }
      }
    }
    else
    {
      var lItemCodeObj = document.getElementById("item_code_r"+inRecNum);
      var lMakeIdObj = document.getElementById("make_id_r"+inRecNum);
                                                                                                                             
      for ( var  lNumRec = 0; lNumRec < lEnqSupplierEnquiryIaddrTabObjJSArr.length; lNumRec++ )
      {
        if( lEnqSupplierEnquiryIaddrTabObjJSArr[lNumRec].item_code == lItemCodeObj.value
            && lEnqSupplierEnquiryIaddrTabObjJSArr[lNumRec].make_id == lMakeIdObj.value
          )
           lDeliveryAddress = lDeliveryAddress + lEnqSupplierEnquiryIaddrTabObjJSArr[lNumRec].delivery_address;
      }
    }
    lDelAddrObj.value = lDeliveryAddress;
}
