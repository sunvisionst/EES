function EesGenDiscActRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("disc_id").value  = document.getElementById("disc_id"+"_r"+inRecNum).value; 
    //document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value;
    //--------------------------------------------------------------------------
    {
      var lWhereText = '';
      gSelectedValue = document.getElementById("roll_num"+"_r"+inRecNum).value;
      gErrorMessage  = 'STUDENT NOT FOUND';
      lWhereText += ' org_id = \''+document.getElementById('org_id').value+'\'';
      lWhereText += ' and class_id = \''+document.getElementById('class_id').value+'\'';
      //lWhereText += ' and roll_num = \''+document.getElementById('roll_num').value+'\'';
      invokeRefreshField( lWhereText, 'ees_gen_disc_act', 'get_student_id', 'STUDENT_ID,ROLL_NUM', 'roll_num', 'option', 'SELECT' );
    }
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    //--------------------------------------------------------------------------
 
    //document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("disc_code").value  = document.getElementById("disc_code"+"_r"+inRecNum).value; 
    document.getElementById("disc_date").value  = document.getElementById("disc_date"+"_r"+inRecNum).value; 
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
    document.getElementById("score").value  = document.getElementById("score"+"_r"+inRecNum).value; 
    document.getElementById("fine_ind").value  = document.getElementById("fine_ind"+"_r"+inRecNum).value; 
    document.getElementById("default_amt").value  = document.getElementById("default_amt"+"_r"+inRecNum).value; 
    //document.getElementById("uom_type").value  = document.getElementById("uom_type"+"_r"+inRecNum).value; 
    //document.getElementById("uom_qty").value  = document.getElementById("uom_qty"+"_r"+inRecNum).value; 
    document.getElementById("total_fine_amt").value  = document.getElementById("total_fine_amt"+"_r"+inRecNum).value; 
    document.getElementById("created_by").value  = document.getElementById("created_by"+"_r"+inRecNum).value; 
    document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    document.getElementById("approved_by").value  = document.getElementById("approved_by"+"_r"+inRecNum).value; 
    document.getElementById("rec_apr_date").value  = document.getElementById("rec_apr_date"+"_r"+inRecNum).value; 
    document.getElementById("action_text").value  = document.getElementById("action_text"+"_r"+inRecNum).value; 
    document.getElementById("action_apply_date").value  = document.getElementById("action_apply_date"+"_r"+inRecNum).value; 
    document.getElementById("action_close_date").value  = document.getElementById("action_close_date"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("disc_id").value  = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("student_id").value  = '';
    document.getElementById("disc_code").value  = '';
    document.getElementById("disc_date").value  = '';
    document.getElementById("description").value  = '';
    document.getElementById("score").value  = '';
    document.getElementById("fine_ind").value  = '';
    document.getElementById("default_amt").value  = '';
    //document.getElementById("uom_type").value  = '';
    //document.getElementById("uom_qty").value  = '';
    document.getElementById("total_fine_amt").value  = '';
    document.getElementById("roll_num").value  = '';
    document.getElementById("created_by").value  = '';
    document.getElementById("rec_cre_date").value  = '';
    document.getElementById("approved_by").value  = '';
    document.getElementById("rec_apr_date").value  = '';
    document.getElementById("action_text").value  = '';
    document.getElementById("action_apply_date").value  = '';
    document.getElementById("action_close_date").value  = '';
  }
}
