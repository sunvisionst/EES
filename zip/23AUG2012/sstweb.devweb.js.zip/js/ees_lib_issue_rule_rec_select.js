function EesLibIssueRuleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   // document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("library_id").value  = document.getElementById("library_id"+"_r"+inRecNum).value;
    document.getElementById("rule_id").value  = document.getElementById("rule_id"+"_r"+inRecNum).value; 
    document.getElementById("rule_desc").value  = document.getElementById("rule_desc"+"_r"+inRecNum).value; 
    document.getElementById("duration_in_days").value  = document.getElementById("duration_in_days"+"_r"+inRecNum).value; 
    document.getElementById("per_day_fine").value  = document.getElementById("per_day_fine"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("library_id").value  = '';
    document.getElementById("rule_id").value  = '';
    document.getElementById("rule_desc").value  = '';
    document.getElementById("duration_in_days").value  = '';
    document.getElementById("per_day_fine").value  = '';
  }
}
