function EesAdrRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

document.getElementById("employee_id").value        = document.getElementById("employee_id"+"_r"+inRecNum).value;
document.getElementById("period_num").value         = document.getElementById("period_num"+"_r"+inRecNum).value;
document.getElementById("adr_date").value           = document.getElementById("adr_date"+"_r"+inRecNum).value;
document.getElementById("adr_time").value           = document.getElementById("adr_time"+"_r"+inRecNum).value;
document.getElementById("org_id").value             = document.getElementById("org_id"+"_r"+inRecNum).value;
document.getElementById("lecture_num").value        = document.getElementById("lecture_num"+"_r"+inRecNum).value;
document.getElementById("subject_code").value       = document.getElementById("subject_code"+"_r"+inRecNum).value;
document.getElementById("topic_id").value           = document.getElementById("topic_id"+"_r"+inRecNum).value;
    







// add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

   document.getElementById("employee_id").value       = '';
   document.getElementById("period_num").value        = '';
   document.getElementById("adr_date").value          = '';
   document.getElementById("adr_time").value          = '';
   document.getElementById("org_id").value            = '';
   document.getElementById("lecture_num").value       = '';
   document.getElementById("subject_code").value      = '';
   document.getElementById("topic_id").value          = '';
  
 // add other fields like above
  }
}
