function EesRouteStoppageRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

   lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
   lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
   lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   //document.getElementById("vehicle_id").value       = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
   //document.getElementById("org_id").value           = document.getElementById("org_id"+"_r"+inRecNum).value;
   document.getElementById("stoppage_id").value      = document.getElementById("stoppage_id"+"_r"+inRecNum).value;
   document.getElementById("stoppage_name").value    = document.getElementById("stoppage_name"+"_r"+inRecNum).value;
   document.getElementById("route_id").value         = document.getElementById("route_id"+"_r"+inRecNum).value;    
   document.getElementById("stoppage_time").value          = document.getElementById("stoppage_time"+"_r"+inRecNum).value;
   document.getElementById("xx_axis").value          = document.getElementById("xx_axis"+"_r"+inRecNum).value;
   document.getElementById("yy_axis").value          = document.getElementById("yy_axis"+"_r"+inRecNum).value;
   document.getElementById("zz_axis").value          = document.getElementById("zz_axis"+"_r"+inRecNum).value;

 // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

   //document.getElementById("vehicle_id").value       = '';
   //document.getElementById("org_id").value           = '';
   document.getElementById("stoppage_id").value      = '';
   document.getElementById("stoppage_name").value    = '';
   //document.getElementById("route_id").value         = '';
   document.getElementById("stoppage_time").value    = '';
   document.getElementById("xx_axis").value          = '';
   document.getElementById("yy_axis").value          = '';
   document.getElementById("zz_axis").value          = '';



    // add other fields like above
  }
}
