function EesVehicleLocationRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    document.getElementById("vehicle_id").value      = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
    document.getElementById("loc_rec_date").value      = document.getElementById("loc_rec_date"+"_r"+inRecNum).value;
    document.getElementById("time").value      = document.getElementById("time"+"_r"+inRecNum).value;
    document.getElementById("x_axis").value      = document.getElementById("x_axis"+"_r"+inRecNum).value;
    document.getElementById("y_axis").value      = document.getElementById("y_axis"+"_r"+inRecNum).value;
    document.getElementById("z_axis").value      = document.getElementById("z_axis"+"_r"+inRecNum).value;
 // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("vehicle_id").value      = '';
    document.getElementById("loc_rec_date").value    = '';
    document.getElementById("time").value            = '';
    document.getElementById("x_axis").value          = '';
    document.getElementById("y_axis").value          = '';
    document.getElementById("z_axis").value          = '';
// add other fields like above
  }
}
