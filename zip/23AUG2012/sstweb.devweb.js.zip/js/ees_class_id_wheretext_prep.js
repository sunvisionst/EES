function ees_class_id_wheretext_prep( inOrgCtg, inClassId )
{
  // IS NOW OBSO
  alert('BBBBBBBB---->>'+inClassId);
  var lCourseId     = '' ;
  var lCourseTerm   = '' ;
  var lClassNum     = '' ;
  var lCourseStream = '' ;
  var course_id     = '' ;
  var class_num     = '' ;
  var course_stream = '' ;
  var course_term   = '' ;
  var class_section = '' ;
 
  var lClassIdArr   = inClassId.split(',') ;
  //alert('lClassIdArr[0]'+lClassIdArr[0]);
  //alert('lClassIdArr[1]'+lClassIdArr[1]);
  //alert('lClassIdArr[2]'+lClassIdArr[2]);

  alert('lClassIdArrLength'+lClassIdArr.length);

  for( var lClassIndex = 1; lClassIndex < lClassIdArr.length; lClassIndex++ )
  { 
    alert(lClassIdArr[lClassIndex-1]);
    splitClassId( inOrgCtg, lClassIdArr[lClassIndex], 'course_id', 'class_num', 'course_stream', 'course_term', 'class_section' );
    alert('SPLITMETHO');
    
    alert('course_id'+course_id);
    alert('class_num'+class_num);
    alert('course_stream'+course_stream);
    alert('course_term'+course_term);
    //alert('lCourseId'+lCourseId);
    lCourseId     += ''+course_id+','; 
    lCourseStream += ''+course_stream+','; 
    lCourseTerm   += ''+course_term+','; 
    lClassNum     += ''+class_num+','; 
    alert('lCourseId'+lCourseId);
    alert('lCourseStream'+lCourseStream);
    alert('lCourseTerm'+lCourseTerm);
    alert('lClassNum'+lClassNum);
  /* 
    if( lClassNum != null && lClassNum.length > 0 )
    { 
      lWhereText += ' and class_num = ''+lClassNum+''';
    } 
    if( lCourseId != null && lCourseId.length > 0 )
    { 
      lWhereText += ' and course_id = ''+lCourseId+''';
    } 
    if( lCourseStream != null && lCourseStream.length > 0 )
    { 
      lWhereText += ' and course_stream = ''+lCourseStream+''';
    } 
    if( lCourseTerm != null && lCourseTerm.length > 0 )
    { 
      lWhereText += ' and course_term = ''+lCourseTerm+''';
    } 
  */
  } 
}
