function EesClassRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value; 
    document.getElementById("duration_type").value  = document.getElementById("duration_type"+"_r"+inRecNum).value; 
    document.getElementById("course_duration").value  = document.getElementById("course_duration"+"_r"+inRecNum).value; 
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value; 
    document.getElementById("upgrade_ind").value  = document.getElementById("upgrade_ind"+"_r"+inRecNum).value; 
    document.getElementById("run_ind").value  = document.getElementById("run_ind"+"_r"+inRecNum).value; 
    document.getElementById("room_num").value  = document.getElementById("room_num"+"_r"+inRecNum).value; 
    document.getElementById("building_id").value  = document.getElementById("building_id"+"_r"+inRecNum).value; 
    document.getElementById("class_teacher").value  = document.getElementById("class_teacher"+"_r"+inRecNum).value; 
    document.getElementById("stream_ind").value  = document.getElementById("stream_ind"+"_r"+inRecNum).value; 
    document.getElementById("shift_code").value  = document.getElementById("shift_code"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("class_section").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("description").value  = '';
    document.getElementById("duration_type").value  = '';
    document.getElementById("course_duration").value  = '';
    document.getElementById("remark").value  = '';
    document.getElementById("upgrade_ind").value  = '';
    document.getElementById("run_ind").value  = '';
    document.getElementById("room_num").value  = '';
    document.getElementById("building_id").value  = '';
    document.getElementById("class_teacher").value  = '';
    document.getElementById("stream_ind").value  = '';
    document.getElementById("shift_code").value  = '';
  }
}
