function formSubmit()
{
document.form.action ='?action=ees_lib_book_return_update_submit';
document.form.submit();
}
