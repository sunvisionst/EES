function EesHostelRoomRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

     document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value;
     document.getElementById("hostel_id").value     = document.getElementById("hostel_id"+"_r"+inRecNum).value;
     document.getElementById("room_num").value      = document.getElementById("room_num"+"_r"+inRecNum).value;
     document.getElementById("room_type").value     = document.getElementById("room_type"+"_r"+inRecNum).value;
     document.getElementById("floor").value         = document.getElementById("floor"+"_r"+inRecNum).value;
     document.getElementById("wing").value          = document.getElementById("wing"+"_r"+inRecNum).value;
     document.getElementById("num_of_bed").value    = document.getElementById("num_of_bed"+"_r"+inRecNum).value;
     document.getElementById("room_status").value   = document.getElementById("room_status"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    
    //document.getElementById("org_id").value         = '';
    document.getElementById("hostel_id").value      = '';
    document.getElementById("room_num").value       = '';
    document.getElementById("room_type").value      = '';
    document.getElementById("floor").value          = '';
    document.getElementById("wing").value           = '';
    document.getElementById("num_of_bed").value     = '';
    document.getElementById("room_status").value    = '';
    // add other fields like above
  }
}
