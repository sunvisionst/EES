function EesExamQuestMoRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("exam_id").value  = document.getElementById("exam_id"+"_r"+inRecNum).value; 
    document.getElementById("paper_id").value  = document.getElementById("paper_id"+"_r"+inRecNum).value; 
    document.getElementById("mandatory_seq").value  = document.getElementById("mandatory_seq"+"_r"+inRecNum).value; 
    document.getElementById("question_num").value  = document.getElementById("question_num"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value  = '';
    document.getElementById("exam_id").value  = '';
    document.getElementById("paper_id").value  = '';
    document.getElementById("mandatory_seq").value  = '';
    document.getElementById("question_num").value  = '';
  }
}
