function getStartEndDate( inCurrentYear )
{
  var lCurrentMonth = document.getElementById("month").value;
  var lMonth        = lCurrentMonth;
  var lYear         = inCurrentYear;

  //alert('lMonth--'+lMonth);
  //alert('lYear--'+lYear);

  var lLeapYear     = 'N';
  var lMonthValue   = '';
  var lFirstDays    = 0;
  var lLastDays     = 0;
  var lFirstDate    = '';
  var lLastDate     = '';


  if ((lYear % 4) == 0) 
  {
    if ((lYear % 100) == 0 && (lYear % 400) != 0)
      lLeapYear = 'Y';
    else
      lLeapYear = 'N';
  }
  else
    lLeapYear = 'N';

  
  if( lMonth == 1 )
  {
    lMonthValue = 'Jan';
    lFirstDays  = '0'+1;
    lLastDays   = 31;
  }
  if( lMonth == 2 )
  {
    lMonthValue = 'Feb';
    lFirstDays  = '0'+1;
    if( lLeapYear == 'Y')
      lLastDays   = 29;
    if( lLeapYear == 'N')
      lLastDays = 28;
  }
  if( lMonth == 3 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Mar';
    lLastDays   = 31;
  }
  if( lMonth == 4 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Apr';
    lLastDays   = 30;
  }
  if( lMonth == 5 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'May';
    lLastDays   = 31;
  }
  if( lMonth == 6 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Jun';
    lLastDays   = 30;
  }
  if( lMonth == 7 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Jul';
    lLastDays   = 31;
  }
  if( lMonth == 8 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Aug';
    lLastDays   = 31;
  }
  if( lMonth == 9 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Sep';
    lLastDays   = 30;
  }
  if( lMonth == 10 )
  {
    lFirstDays  = '0'+1;
    lMonthValue =  'Oct';
    lLastDays   = 31;
  } 
  if( lMonth == 11 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Nov';
    lLastDays   = 30;
  }
  if( lMonth == 12 )
  {
    lFirstDays  = '0'+1;
    lMonthValue = 'Dec';
    lLastDays   = 31;
  }
   lFirstDate = lFirstDays + '-' + lMonthValue + '-' + lYear;
   lLastDate  = lLastDays + '-' + lMonthValue + '-' + lYear; 

   document.getElementById("start_date").value = lFirstDate;
   document.getElementById("end_date").value   = lLastDate; 
}

