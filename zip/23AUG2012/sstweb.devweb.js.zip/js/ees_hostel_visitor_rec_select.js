function EesHostelVisitorRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value  = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("visitor_name").value  = document.getElementById("visitor_name"+"_r"+inRecNum).value; 
    document.getElementById("lg_ind").value  = document.getElementById("lg_ind"+"_r"+inRecNum).value; 
    document.getElementById("relation_type").value  = document.getElementById("relation_type"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("student_id").value  = '';
    //document.getElementById("seq_num").value  = '';
    //document.getElementById("hostel_id").value  = '';
    document.getElementById("visitor_name").value  = '';
    document.getElementById("lg_ind").value  = '';
    document.getElementById("relation_type").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
  }
}
