 var lvCnAme = "";
 var lvCId = "";
 var lCurrFocus;
 var lvCnAmeArr = "";
function getVcName (inVcTdId)
{
  lVcIdName = document.getElementById(''+inVcTdId+'').value;
  lvCnAmeArr = lVcIdName.split(','); 
  lvCnAme = lvCnAmeArr[0];
  lvCId = lvCnAmeArr[1];
  document.getElementById(''+lCurrFocus+'').focus();  
  lvCnAme = '';  
} 

function setDescValue(event)
{
  var lBrowserName = getBrowserName();
  if ( lBrowserName == 'Microsoft Internet Explorer' )
  {
    if ( window.event && window.event.srcElement )
    {
      var lTagName =  window.event.srcElement.tagName
      if (lTagName == 'INPUT')
      {
        var lId    = getElementIdByWindowEvent();
        var lObj   = document.getElementById(lId);
        lCurrFocus = lId;
        if ( lId == 'dr_desc' ) 
        {
         lObj.value = lvCnAme;
         document.getElementById("dr_account_id_val").value = lvCId;
        }
        else
        if ( lId == 'cr_desc' )
        {
         lObj.value = lvCnAme;
         document.getElementById("cr_account_id_val").value = lvCId;
        }
      }
    }
  }
  else
  if ( lBrowserName == 'Netscape' )
  {
    if ( event && event.target )
    {
      var lTagName =  event.target.tagName;
      
      if (lTagName == 'INPUT')
      {
        var lObj = event.target;
        lCurrFocus = lObj.id;
        if ( lObj.id == 'dr_desc' ) 
        {
          lObj.value = lvCnAme;
          document.getElementById("dr_account_id_val").value = lvCId;
        }
        else
        if ( lObj.id == 'cr_desc' ) 
        {
          lObj.value = lvCnAme;
          document.getElementById("cr_account_id_val").value = lvCId;
        }
      }
    }
  }

 /* if ( lBrowserName == 'Netscape' )
  { alert('aaaaa-111-->>');
    if ( event && event.target )
    {
  { alert('aaaaa-222-->>');
      var lHiddenField =  document.form.hiddenObject;
      if(lHiddenField != null && lHiddenField.id == 'dr_account_id_val') alert('aaa--->>>'+lHiddenField.id)
    }
  }
*/
 










}


function defaultDivVcDis()
{
  var lDivObj = document.getElementById('TabView'); ///getting parent Div Tag
  var lChildDiv = lDivObj.getElementsByTagName('div'); ///getting all child div tag
  for( var lRecNum =0; lRecNum < lChildDiv.length; lRecNum++)
  {
    if( lChildDiv[lRecNum].id == 'VcAc' )
    {
      lChildDiv[lRecNum].disabled = true;
      //var lChildElem = lChildDiv[i].childNodes;
      //lChildDiv[i].disabled = true; 
    }
  } 

  //alert('aaa---->>'+Abc);
  //Abc.disabled = true;
  /*var lBrowserName = getBrowserName();
  if ( lBrowserName == 'Microsoft Internet Explorer' )
  {
    if ( window.event && window.event.srcElement )
    {
      var lTagName =  window.event.srcElement.tagName
      if (lTagName == 'DIV')
      {
        var lId    = getElementIdByWindowEvent();
        var lObj   = document.getElementById(lId);
        if ( lId == 'lVcAc' ) lObj.disabled = true;
      }
    }
  }
  else
  if ( lBrowserName == 'Netscape' )
  {
  alert('aaa' + event);
     if ( event && event.target )
     {
         var lTagName =  event.target.tagName;
         if (lTagName == 'DIV')
         {
           var lObj = event.target;
           if ( lObj.id == 'lVcAc' ) lObj.disable = true;
         }
     }
  }*/
}

