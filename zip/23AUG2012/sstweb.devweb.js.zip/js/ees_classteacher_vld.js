function ClassTeacherVld( inDBValFlag, inFieldValue, inNumOfRec, inRecNum )
{
  var lAssignFacultyObj = document.getElementById("class_teacher"+"_r"+inRecNum);
  var lRoomShareIndObj = document.getElementById("room_share_ind"+"_r"+inRecNum);
  for ( var lRecNum = 1; lRecNum <= parseInt(inNumOfRec); lRecNum++)
  {
    var lFacultyObj = document.getElementById("class_teacher"+"_r"+lRecNum);
    if ( lRecNum != parseInt(inRecNum) )
    {
      if ( ( lRoomShareIndObj && lRoomShareIndObj.value != 'Y' ) && ( lFacultyObj.value == lAssignFacultyObj.value ) )
      {
        alert('This Faculty is Already Assigned');
        if ( inDBValFlag == 'N' )
          lAssignFacultyObj.value = '';
        else
        if ( inDBValFlag == 'Y' )
          lAssignFacultyObj.value = inFieldValue;
        break;
      }
    }
  }
}
