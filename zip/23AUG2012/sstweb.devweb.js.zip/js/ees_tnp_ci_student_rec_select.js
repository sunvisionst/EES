function EesTnpCiStudentRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("followup_id").value      = document.getElementById("followup_id"+"_r"+inRecNum).value;
    document.getElementById("student_id").value      = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("link_followup_id").value      = document.getElementById("link_followup_id"+"_r"+inRecNum).value;
    document.getElementById("company_id").value      = document.getElementById("company_id"+"_r"+inRecNum).value;
    document.getElementById("attendance_status").value      = document.getElementById("attendance_status"+"_r"+inRecNum).value;
    document.getElementById("attendance_date").value      = document.getElementById("attendance_date"+"_r"+inRecNum).value;
    document.getElementById("mark_obtained").value      = document.getElementById("mark_obtained"+"_r"+inRecNum).value;
    document.getElementById("selection_status").value      = document.getElementById("selection_status"+"_r"+inRecNum).value;

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("followup_id").value      = '';
    document.getElementById("student_id").value      = '';
    document.getElementById("link_followup_id").value      = '';
    document.getElementById("company_id").value      = '';
    document.getElementById("attendance_status").value      = '';
    document.getElementById("attendance_date").value      = '';
    document.getElementById("mark_obtained").value      = '';
    document.getElementById("selection_status").value      = '';

  }
}
