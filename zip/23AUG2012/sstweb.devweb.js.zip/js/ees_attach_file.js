function AttachFile( inAction )
{
   var Window = open("","","width=450,height=500,status=no,resizable=no,top=150,left=250");
       
       Window.bgColor = "lightsteelblue";
       Window.document.write(" <form name=\"form\" id=\"form\" method =\"post\">");

     //  Window.document.write("<table>");
     //  Window.document.write("<tr>");

     //  Window.document.write("<input type=\"hidden\" name=\"action_send\" id=\"action_send\" "
     //                       +"value=\""+inAction+"\"/>");

     //  Window.document.write("<td align='center'><input type ='submit' name='submit' id = 'submit' value='Continue to Message'"
//                          +" onClick ='if(ToText.value == \"\"){alert(\"Please fill To address\");self.event.returnValue=false;ToText.focus();}"
  //                        +"else if(SubjectText.value == \"\"){alert(\"Please fill Subject\");self.event.returnValue=false;SubjectText.focus();}"
    //                      +"else if(MessageArea.value == \"\"){alert(\"Please write message\");self.event.returnValue=false;MessageArea.focus();}"
                        //  +"else {self.close();}'></td>");
     //                       +"></td>");


       Window.document.write("Select File OnClick Browse.. Button");
       Window.document.write("<br>");

       Window.document.write("<br><center>");
      

       Window.document.write("<table>");
       Window.document.write("<tr>");
       Window.document.write("<td align='center'><b>File 1: </b></td>");
       Window.document.write("<td><input type ='file' name='ToText1'id ='ToText1'size='25'></td>");
       Window.document.write("<input type=\"hidden\" name=\"ToText1\" id=\"ToText1\" "
                            +"value=\""+inAction+"\"/>");
       Window.document.write("</tr>");
       
       Window.document.write("<tr>");
       Window.document.write("<td align='center'><b>File 2: </b></td>");
       Window.document.write("<td><input type ='file' name='ToText2'id ='ToText2'size='25'></td>");
       Window.document.write("<input type=\"hidden\" name=\"ToText2\" id=\"ToText2\" "
                            +"value=\""+inAction+"\"/>");
       Window.document.write("</tr>");

       Window.document.write("<tr>");
       Window.document.write("<td align='center'><b>File 3: </b></td>");
       Window.document.write("<td><input type ='file' name='ToText3'id ='ToText3'size='25'></td>");
       Window.document.write("<input type=\"hidden\" name=\"ToText3\" id=\"ToText3\" "
                            +"value=\""+inAction+"\"/>");
       Window.document.write("</tr>");

       Window.document.write("<tr>");
       Window.document.write("<td align='center'><b>File 4: </b></td>");
       Window.document.write("<td><input type ='file' name='ToText4'id ='ToText4'size='25'></td>");
       Window.document.write("<input type=\"hidden\" name=\"ToText4\" id=\"ToText4\" "
                            +"value=\""+inAction+"\"/>");
       Window.document.write("</tr>");
  
       Window.document.write("<tr>");
       Window.document.write("<td align='center'><b>File 5: </b></td>");
       Window.document.write("<td><input type ='file' name='ToText5'id ='ToText5'size='25'></td>");
       Window.document.write("<input type=\"hidden\" name=\"ToText5\" id=\"ToText5\" "
                            +"value=\""+inAction+"\"/>");
       Window.document.write("</tr>");

       Window.document.write("</table>");
       
       Window.document.write("<br><center>");

       Window.document.write("<table>");
       Window.document.write("<tr>");

       Window.document.write("<input type=\"hidden\" name=\"action_upload\" id=\"action_upload\" "
                            +"value=\""+inAction+"\"/>");

      Window.document.write("<td align='center'><input type ='submit' name='submit' id = 'submit' value='Upload'"

                            + " onClick = \""
                            + " var lSourceFieldId;"
                            + " var lTargerFieldId;"
                            + " lSourceFieldId = document.getElementById('ToText1'); "
                           // + " alert('inside loop '+lSourceFieldId.value);"
                            +"  self.opener.document.getElementById('syllabus_file_path').value = lSourceFieldId.value; "
                            + " window.close();"
                            + "  \""
                            + " >");



       Window.document.write("</tr>");
       Window.document.write("</table>");
       Window.document.write("</form>");
 }

