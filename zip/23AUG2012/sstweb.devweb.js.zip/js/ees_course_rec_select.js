function EesCourseRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value         = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("course_id").value        = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("description").value      = document.getElementById("description"+"_r"+inRecNum).value;
    document.getElementById("dept_id").value          = document.getElementById("dept_id"+"_r"+inRecNum).value;
    document.getElementById("course_code").value      = document.getElementById("course_code"+"_r"+inRecNum).value;
    document.getElementById("short_code").value       = document.getElementById("short_code"+"_r"+inRecNum).value;
    document.getElementById("sst_course_id").value    = document.getElementById("sst_course_id"+"_r"+inRecNum).value;
    document.getElementById("duration_type").value    = document.getElementById("duration_type"+"_r"+inRecNum).value;
    document.getElementById("course_duration").value  = document.getElementById("course_duration"+"_r"+inRecNum).value;
    document.getElementById("remark").value           = document.getElementById("remark"+"_r"+inRecNum).value;
    document.getElementById("board_university").value = document.getElementById("board_university"+"_r"+inRecNum).value;
    document.getElementById("min_fee_amt").value      = document.getElementById("min_fee_amt"+"_r"+inRecNum).value;
    document.getElementById("stream_ind").value       = document.getElementById("stream_ind"+"_r"+inRecNum).value;
    if ( document.getElementById("stream_ind"+"_r"+inRecNum).value == 'Y' )
    {
      document.getElementById("ees_course_href_tr").style.display = '';
      document.getElementById("course_strength_tr").style.display = 'none';
      document.getElementById("quota_qty_tr").style.display = 'none';
    }
    else
    if ( document.getElementById("stream_ind"+"_r"+inRecNum).value == 'N' )
    {
      document.getElementById("ees_course_href_tr").style.display = 'none';
      document.getElementById("course_strength_tr").style.display = '';
      document.getElementById("quota_qty_tr").style.display = '';
    }
    document.getElementById("course_strength").value  = document.getElementById("course_strength"+"_r"+inRecNum).value;
    document.getElementById("quota_qty").value        = document.getElementById("quota_qty"+"_r"+inRecNum).value;
    document.getElementById("class_id_pattern").value = document.getElementById("class_id_pattern"+"_r"+inRecNum).value;
    document.getElementById("course_coord").value     = document.getElementById("course_coord"+"_r"+inRecNum).value;
    if ( document.getElementById("sst_course_id"+"_r"+inRecNum).value == '999' )
      document.getElementById("description_tr").style.display = '';
    else 
      document.getElementById("description_tr").style.display = 'none';
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value         = '';
    document.getElementById("course_id").value        = '';
    document.getElementById("description").value      = '';
    document.getElementById("dept_id").value          = '';
    document.getElementById("course_code").value      = '';
    document.getElementById("short_code").value       = '';
    document.getElementById("sst_course_id").value    = '';
    document.getElementById("duration_type").value    = '';
    document.getElementById("course_duration").value  = '';
    document.getElementById("remark").value           = '';
    document.getElementById("board_university").value = '';
    document.getElementById("min_fee_amt").value      = '';
    document.getElementById("stream_ind").value       = '';
    document.getElementById("course_strength").value  = '';
    document.getElementById("quota_qty").value        = '';
    document.getElementById("class_id_pattern").value = '';
    document.getElementById("course_coord").value     = '';
    document.getElementById("ees_course_href_tr").style.display = 'none';
    document.getElementById("description_tr").style.display = 'none';
    // add other fields like above
  }
}
