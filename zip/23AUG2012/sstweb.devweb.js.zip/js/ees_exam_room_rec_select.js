function EesExamRoomRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

 document.getElementById("exam_id").value      = document.getElementById("exam_id"+"_r"+inRecNum).value;
document.getElementById("room_num").value      = document.getElementById("room_num"+"_r"+inRecNum).value;
document.getElementById("room_incharge_1").value      = document.getElementById("room_incharge_1"+"_r"+inRecNum).value;
document.getElementById("room_incharge_2").value      = document.getElementById("room_incharge_2"+"_r"+inRecNum).value;
document.getElementById("room_incharge_3").value      = document.getElementById("room_incharge_3"+"_r"+inRecNum).value;
document.getElementById("room_incharge_4").value      = document.getElementById("room_incharge_4"+"_r"+inRecNum).value;
document.getElementById("room_incharge_5").value      = document.getElementById("room_incharge_5"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

   document.getElementById("exam_id").value      = '';
    document.getElementById("room_num").value      = '';
document.getElementById("room_incharge_1").value      = '';
document.getElementById("room_incharge_2").value      = '';
document.getElementById("room_incharge_3").value      = '';
document.getElementById("room_incharge_4").value      = '';
document.getElementById("room_incharge_5").value      = '';
  
  // add other fields like above
  }
}
