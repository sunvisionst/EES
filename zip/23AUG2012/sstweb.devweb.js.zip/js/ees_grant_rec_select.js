function EesGrantRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  var lGrantIdNext ;
  lGrantIdNext = document.getElementById("grant_id_next").value;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;


lSubmitObj = document.getElementById("installment_type"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("installment_period"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("current_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("next_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;


    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("grant_id").value      	= document.getElementById("grant_id"+"_r"+inRecNum).value;
    document.getElementById("grant_id_dummy").value           = document.getElementById("grant_id"+"_r"+inRecNum).value;
    document.getElementById("grant_entry_date").value   = document.getElementById("grant_entry_date"+"_r"+inRecNum).value;
    document.getElementById("granter_id").value      	= document.getElementById("granter_id"+"_r"+inRecNum).value;
    document.getElementById("grant_remark").value      	= document.getElementById("grant_remark"+"_r"+inRecNum).value;
    document.getElementById("grant_ref_num").value      = document.getElementById("grant_ref_num"+"_r"+inRecNum).value;
    document.getElementById("grant_ref_date").value     = document.getElementById("grant_ref_date"+"_r"+inRecNum).value;
    document.getElementById("grant_apr_date").value     = document.getElementById("grant_apr_date"+"_r"+inRecNum).value;
    document.getElementById("benifited_org_id").value   = document.getElementById("benifited_org_id"+"_r"+inRecNum).value;
    document.getElementById("grant_status").value      	= document.getElementById("grant_status"+"_r"+inRecNum).value;
    document.getElementById("installment_flag").value   = document.getElementById("installment_flag"+"_r"+inRecNum).value;
    document.getElementById("installment_type").value   = document.getElementById("installment_type"+"_r"+inRecNum).value;
    document.getElementById("installment_period").value = document.getElementById("installment_period"+"_r"+inRecNum).value;
    document.getElementById("current_installment_id").value  	= document.getElementById("current_installment_id"+"_r"+inRecNum).value;
    document.getElementById("current_installment_id_dummy").value     = document.getElementById("current_installment_id"+"_r"+inRecNum).value;
    document.getElementById("next_installment_id").value= document.getElementById("next_installment_id"+"_r"+inRecNum).value;
     document.getElementById("next_installment_id_dummy").value= document.getElementById("next_installment_id"+"_r"+inRecNum).value;
    document.getElementById("grant_act_amt").value      = document.getElementById("grant_act_amt"+"_r"+inRecNum).value;
    document.getElementById("grant_bal_amt").value      = document.getElementById("grant_bal_amt"+"_r"+inRecNum).value;
     document.getElementById("grant_bal_amt_dummy").value      = document.getElementById("grant_bal_amt"+"_r"+inRecNum).value;
    // add other fields like above
  }

  else
  {
       lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
       lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
       lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;


       lSubmitObj = document.getElementById("installment_type"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("installment_period"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("current_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
       lSubmitObj = document.getElementById("next_installment_id"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("__field_name__").value      = '';

    document.getElementById("grant_id").value      		  = lGrantIdNext;
    document.getElementById("grant_id_dummy").value               = lGrantIdNext;
    document.getElementById("grant_entry_date").value   	  = '';
    document.getElementById("granter_id").value      		  = '';
    document.getElementById("grant_remark").value      		  = '';
    document.getElementById("grant_ref_num").value      	  = '';
    document.getElementById("grant_ref_date").value     	  = '';
    document.getElementById("grant_apr_date").value     	  = '';
    document.getElementById("benifited_org_id").value   	  = '';
    document.getElementById("grant_status").value      		  = '';
    document.getElementById("installment_flag").value   	  = '';
    document.getElementById("installment_type").value   	  = '';
    document.getElementById("installment_period").value 	  = '';
    document.getElementById("current_installment_id").value  	  = '';
    document.getElementById("current_installment_id_dummy").value = '';
    document.getElementById("next_installment_id").value      	  = '';
    document.getElementById("next_installment_id_dummy").value    = '';
    document.getElementById("grant_act_amt").value      	  = '';
    document.getElementById("grant_bal_amt").value      	  = '';
    document.getElementById("grant_bal_amt_dummy").value          = '';
    // add other fields like above
  }
}
