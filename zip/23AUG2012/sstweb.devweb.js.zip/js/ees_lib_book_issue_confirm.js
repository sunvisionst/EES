function confirmBookIssue()
{
  var lFlag = confirm('Do you want to issue another book?');
  if(lFlag == true)
  {
    document.getElementById('book_id').value          = '';
    document.getElementById('book_name').value        = '';
    document.getElementById('author').value           = '';
    document.getElementById('book_ctg_1').value       = '';
    document.getElementById('book_status').value      = 'I';
    document.getElementById('book_id').focus();

  }
  else
  {
    document.getElementById('book_id').value          = '';
    document.getElementById('book_name').value        = '';
    document.getElementById('author').value           = '';
    document.getElementById('book_ctg_1').value       = '';
    document.getElementById('book_status').value      = 'I';

    document.getElementById('roll_num').value 	      = '';
    document.getElementById('course_id').value        = '';
    document.getElementById('class_num').value        = '';
    document.getElementById('course_term').value      = '';
    document.getElementById('class_section').value    = '';
    document.getElementById('course_stream').value    = '';
    document.getElementById('roll_num').focus();

  }
} 

