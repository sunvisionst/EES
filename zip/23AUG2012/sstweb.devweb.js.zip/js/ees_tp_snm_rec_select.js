function EesTpSnmRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("txn_id").value  = document.getElementById("txn_id"+"_r"+inRecNum).value; 
    document.getElementById("entry_seq_num").value  = document.getElementById("entry_seq_num"+"_r"+inRecNum).value; 
    document.getElementById("txn_date").value  = document.getElementById("txn_date"+"_r"+inRecNum).value; 
    document.getElementById("txn_time").value  = document.getElementById("txn_time"+"_r"+inRecNum).value; 
    document.getElementById("order_type").value  = document.getElementById("order_type"+"_r"+inRecNum).value; 
    document.getElementById("vehicle_id").value  = document.getElementById("vehicle_id"+"_r"+inRecNum).value; 
    document.getElementById("item_code").value  = document.getElementById("item_code"+"_r"+inRecNum).value; 
    document.getElementById("item_desc").value  = document.getElementById("item_desc"+"_r"+inRecNum).value; 
    document.getElementById("snm_remark").value  = document.getElementById("snm_remark"+"_r"+inRecNum).value; 
    document.getElementById("item_qty").value  = document.getElementById("item_qty"+"_r"+inRecNum).value; 
    document.getElementById("unit_rate").value  = document.getElementById("unit_rate"+"_r"+inRecNum).value; 
    document.getElementById("tax_rate").value  = document.getElementById("tax_rate"+"_r"+inRecNum).value; 
    document.getElementById("service_center_cd").value  = document.getElementById("service_center_cd"+"_r"+inRecNum).value; 
    document.getElementById("cur_mr").value  = document.getElementById("cur_mr"+"_r"+inRecNum).value; 
    document.getElementById("free_ind").value  = document.getElementById("free_ind"+"_r"+inRecNum).value; 
    document.getElementById("free_srv_num").value  = document.getElementById("free_srv_num"+"_r"+inRecNum).value; 
    document.getElementById("next_srv_mr").value  = document.getElementById("next_srv_mr"+"_r"+inRecNum).value; 
    document.getElementById("next_srv_date").value  = document.getElementById("next_srv_date"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("status_date").value  = document.getElementById("status_date"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("txn_id").value  = '';
    document.getElementById("entry_seq_num").value  = '';
    document.getElementById("txn_date").value  = '';
    document.getElementById("txn_time").value  = '';
    document.getElementById("order_type").value  = '';
    document.getElementById("vehicle_id").value  = '';
    document.getElementById("item_code").value  = '';
    document.getElementById("item_desc").value  = '';
    document.getElementById("snm_remark").value  = '';
    document.getElementById("item_qty").value  = '';
    document.getElementById("unit_rate").value  = '';
    document.getElementById("tax_rate").value  = '';
    document.getElementById("service_center_cd").value  = '';
    document.getElementById("cur_mr").value  = '';
    document.getElementById("free_ind").value  = '';
    document.getElementById("free_srv_num").value  = '';
    document.getElementById("next_srv_mr").value  = '';
    document.getElementById("next_srv_date").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("status_date").value  = '';
  }
}
