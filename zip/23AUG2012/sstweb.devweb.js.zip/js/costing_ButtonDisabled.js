function costing_ButtonDisabled()
{
   var lValueQuery = document.getElementById('Query');
   var lValueSubmit = document.getElementById('Sub');
   var lEnqNum = document.getElementById('enq_num');
   var lEnqValue = lEnqNum.value; 
 
   if ( lEnqValue == '' )
   {
    lValueSubmit.disabled=false;
    lValueQuery.disabled=true; 
   }
   else
   {
    lValueSubmit.disabled=true;
    lValueQuery.disabled=false; 
   }
}
