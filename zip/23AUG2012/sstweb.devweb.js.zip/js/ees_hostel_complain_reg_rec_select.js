function EesHostelComplainRegRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value             = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("hostel_id").value          = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    document.getElementById("comp_reg_date").value      = document.getElementById("comp_reg_date"+"_r"+inRecNum).value;
    document.getElementById("seq_num").value            = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("complain_remark").value    = document.getElementById("complain_remark"+"_r"+inRecNum).value;
    document.getElementById("compaliner_type").value    = document.getElementById("compaliner_type"+"_r"+inRecNum).value;
    document.getElementById("complainer_id").value      = document.getElementById("complainer_id"+"_r"+inRecNum).value;
    document.getElementById("status").value             = document.getElementById("status"+"_r"+inRecNum).value;
    document.getElementById("attended_date").value      = document.getElementById("attended_date"+"_r"+inRecNum).value;
    document.getElementById("close_date").value         = document.getElementById("close_date"+"_r"+inRecNum).value;
    document.getElementById("closing_remark").value     = document.getElementById("closing_remark"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value             = '';
    document.getElementById("hostel_id").value          = '';
    document.getElementById("com_reg_date").value       = '';
    document.getElementById("seq_num").value            = '';
    document.getElementById("complain_remark").value    = '';
    document.getElementById("compaliner_type").value    = '';
    document.getElementById("complainer_id").value      = '';
    document.getElementById("status").value             = '';
    document.getElementById("attended_date").value      = '';
    document.getElementById("close_date").value         = '';
    document.getElementById("closing_remark").value     = '';
    // add other fields like above
  }
}
