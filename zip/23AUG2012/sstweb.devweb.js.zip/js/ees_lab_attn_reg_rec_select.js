function EesLabAttnRegRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("lab_id").value  = document.getElementById("lab_id"+"_r"+inRecNum).value; 
    document.getElementById("entry_date").value  = document.getElementById("entry_date"+"_r"+inRecNum).value; 

    //--------------------------------------------------------------------------
    {
      var lWhereText = '';
      var lTodayDate = lTodayDate; 
      gSelectedValue = document.getElementById("session_id"+"_r"+inRecNum).value;
      gErrorMessage  = 'SESSION NOT FOUND';
      lWhereText += ' org_id = \''+document.getElementById("org_id"+"_r"+inRecNum).value+'\'';
      lWhereText += ' and lab_id = \''+document.getElementById("lab_id"+"_r"+inRecNum).value+'\'';
      invokeRefreshField( lWhereText, 'ees_lab_attn_reg', 'get_session_record', 'DISTINCT SESSION_ID,SESSION_ID', 'session_id', 'option', 'SELECT' );
    }
    document.getElementById("session_id").value  = document.getElementById("session_id"+"_r"+inRecNum).value; 
    //--------------------------------------------------------------------------

    //document.getElementById("session_id").value  = document.getElementById("session_id"+"_r"+inRecNum).value; 
    document.getElementById("card_os_flag").value  = document.getElementById("card_os_flag"+"_r"+inRecNum).value; 
    document.getElementById("lab_entry_seq").value  = document.getElementById("lab_entry_seq"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("student_name").value  = document.getElementById("student_name"+"_r"+inRecNum).value; 
    document.getElementById("check_in_date").value  = document.getElementById("check_in_date"+"_r"+inRecNum).value; 
    document.getElementById("check_in_time").value  = document.getElementById("check_in_time"+"_r"+inRecNum).value; 
    document.getElementById("check_out_date").value  = document.getElementById("check_out_date"+"_r"+inRecNum).value; 
    document.getElementById("check_out_time").value  = document.getElementById("check_out_time"+"_r"+inRecNum).value; 
    document.getElementById("week_day").value  = document.getElementById("week_day"+"_r"+inRecNum).value; 
    document.getElementById("barcode").value  = document.getElementById("barcode"+"_r"+inRecNum).value; 
    document.getElementById("user_id").value  = document.getElementById("user_id"+"_r"+inRecNum).value; 
    document.getElementById("eqp_id").value  = document.getElementById("eqp_id"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("lab_ets_flag").value  = document.getElementById("lab_ets_flag"+"_r"+inRecNum).value; 
    document.getElementById("lab_exam_flag").value  = document.getElementById("lab_exam_flag"+"_r"+inRecNum).value; 
    document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("lab_id").value  = '';
    document.getElementById("entry_date").value  = '';
    document.getElementById("session_id").value  = '';
    document.getElementById("card_os_flag").value  = '';
    document.getElementById("lab_entry_seq").value  = '';
    document.getElementById("student_id").value  = '';
    document.getElementById("student_name").value  = '';
    document.getElementById("check_in_date").value  = '';
    document.getElementById("check_in_time").value  = '';
    document.getElementById("check_out_date").value  = '';
    document.getElementById("check_out_time").value  = '';
    document.getElementById("week_day").value  = '';
    document.getElementById("barcode").value  = '';
    document.getElementById("user_id").value  = '';
    document.getElementById("eqp_id").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("class_section").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("lab_ets_flag").value  = '';
    document.getElementById("lab_exam_flag").value  = '';
    document.getElementById("subject_code").value  = '';
  }
}
