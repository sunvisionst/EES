function penaltySubmit()
{
    
          
         var cnfrm = confirm('You are fined ! Do you want to Pay it right now?');
         if(cnfrm == true )
          {
         document.form.action ='?action=ees_lib_book_return_penalty';
         document.form.submit();
          }
         else
          {
         document.form.action ='?action=ees_lib_book_return_no';
         document.form.submit();
          }
       
  
      
}
