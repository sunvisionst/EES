function EsmSiOrderRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("si_ord_num").value  = document.getElementById("si_ord_num"+"_r"+inRecNum).value; 
    document.getElementById("si_ord_date").value  = document.getElementById("si_ord_date"+"_r"+inRecNum).value; 
    document.getElementById("requested_by").value  = document.getElementById("requested_by"+"_r"+inRecNum).value; 
    document.getElementById("issued_by").value  = document.getElementById("issued_by"+"_r"+inRecNum).value; 
    document.getElementById("issue_date").value  = document.getElementById("issue_date"+"_r"+inRecNum).value; 
    document.getElementById("si_order_status").value  = document.getElementById("si_order_status"+"_r"+inRecNum).value; 
    if ( document.getElementById("si_order_status"+"_r"+inRecNum).value == 'A' )
    {
      lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    }
    else
    if ( document.getElementById("si_order_status"+"_r"+inRecNum).value == 'O' )
    {
      lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
      lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    }
    document.getElementById("si_order_status_date").value  = document.getElementById("si_order_status_date"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit6"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("si_ord_num").value  = '';
    document.getElementById("si_ord_date").value  = '';
    document.getElementById("requested_by").value  = '';
    document.getElementById("issued_by").value  = '';
    document.getElementById("issue_date").value  = '';
    document.getElementById("si_order_status").value  = '';
    document.getElementById("si_order_status_date").value  = '';
  }
}
