function EesBarcodeVld( TotalRow )
{
  var flag = false ;
  var j = 0;
 for( var i = 1; i <= TotalRow ; i++ )
 {
   if(document.getElementById("barcode"+"_r"+i).value == document.getElementById("barcode").value)
   {
     j = i;
     flag = true;
     break; 
   }
 }
 if(flag == true)
 {
    
    alert(document.getElementById("student_name"+"_r"+j).value+" Already scanned"); 
    window.event.returnValue=false;
    document.getElementById("barcode").value = '';
 }
/*
 else
 {
    document.form.action='?action=ees_lab_alltendence_at_the_time_check_in_view&menuOption=eesLabAttnCheckIn';
    '?eesLabAttnCheckIn'; 
    document.form.submit();
 } 
*/
//  alert("0000000");
 // document.form1.action='?action=ees_lab_alltendence_at_the_time_check_in_view&menuOption=eesLabAttnCheckIn';
//  document.form1.submit();
//  alert("11111111");
}
