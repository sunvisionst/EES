function pop_stud_qrt_fee()
{

  var flag = false;
  var lRecIndexNum = 0;

  if (document.getElementById("year").value == '' )
  {
    alert( 'First Select Year!!!' );
    document.getElementById("year_qrt_num").value = '';
    return;
  }

  for (var lEesStudentlen=0 ;lEesStudentlen < lEesStudentTabObjJSArr.length  ; lEesStudentlen++)
  {
     lRecIndexNum++;
     if ( document.getElementById("select"+"_r"+lRecIndexNum).value == 'Y' )
       break;
  }

  if ( lRecIndexNum >= 0 && (document.getElementById("select"+"_r"+lRecIndexNum).value == 'Y') )
  {
    for( var len = 0; len < lEesStudentFeeTabObjJSArr.length  ;len++)
    {
      if ( (lEesStudentFeeTabObjJSArr[len].fee_flag == 'Q')
        && (document.getElementById("year_qrt_num").value == lEesStudentFeeTabObjJSArr[len].year_qrt_num )
        && (document.getElementById("year").value == lEesStudentFeeTabObjJSArr[len].dop.substring(7,12) )
        && (lEesStudentFeeTabObjJSArr[len].student_id == document.getElementById("student_id"+"_r"+lRecIndexNum).value) )
      {
        flag = true;
        break;
      }
    }


    var lRecIndex = 0;
    if ( flag == false)
    {
      for (;;)
      {
        lRecIndex++;
        if ( document.getElementById("select"+"_r"+lRecIndex).value == 'Y' )
        { break; }
      }
      var lStudentCtgObj = document.getElementById("student_ctg"+"_r"+lRecIndex);
      var lStudentClassObj = document.getElementById("class_std"+"_r"+lRecIndex);
      for (var lRecNum = 1; lRecNum <= lEesFeeHeadClassTabObjJSArr.length; lRecNum++)
      {
        if( (lEesFeeHeadClassTabObjJSArr[lRecNum-1].fee_head == 'TUT_FEE')  
         &&  (lEesFeeHeadClassTabObjJSArr[lRecNum-1].class_std ==lStudentClassObj.value ))
        {
           document.getElementById("fee_head").value = lEesFeeHeadClassTabObjJSArr[lRecNum-1].fee_head;
           document.getElementById("default_amt").value = lEesFeeHeadClassTabObjJSArr[lRecNum-1].default_amt;
           document.getElementById("paid_amt").value 
            = lEesFeeHeadClassTabObjJSArr[lRecNum-1].default_amt
              - calcConcession( lEesFeeHeadClassTabObjJSArr[lRecNum-1].fee_head 
                              , lStudentCtgObj
                              , lEesFeeHeadClassTabObjJSArr[lRecNum-1].default_amt );
           document.getElementById("late_fee_amt").value = 0;
           document.getElementById("year").value = '';
           document.getElementById("year_qrt_num").value = '';
        }
      }
    }
    else
    { 
      alert('already deposited'); 
      document.getElementById("year").value = '';
      document.getElementById("year_qrt_num").value = '';
    }
  }
  else
  {
    alert("plz first select the student record");
  }
}
