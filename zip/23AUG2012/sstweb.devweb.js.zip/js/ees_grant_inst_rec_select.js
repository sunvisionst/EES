function EesGrantInstRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("installment_id").value        = document.getElementById("installment_id"+"_r"+inRecNum).value;
    document.getElementById("grant_id").value              = document.getElementById("grant_id"+"_r"+inRecNum).value;
    document.getElementById("installment_date").value      = document.getElementById("installment_date"+"_r"+inRecNum).value;
    document.getElementById("month").value                 = document.getElementById("month"+"_r"+inRecNum).value;
    document.getElementById("year").value                  = document.getElementById("year"+"_r"+inRecNum).value;
    document.getElementById("due_date").value              = document.getElementById("due_date"+"_r"+inRecNum).value;
    document.getElementById("installment_amt").value       = document.getElementById("installment_amt"+"_r"+inRecNum).value;
    document.getElementById("paid_amt").value              = document.getElementById("paid_amt"+"_r"+inRecNum).value;
    document.getElementById("balance_amt").value           = document.getElementById("balance_amt"+"_r"+inRecNum).value;
    document.getElementById("installment_status").value    = document.getElementById("installment_status"+"_r"+inRecNum).value;
    document.getElementById("mode_of_payment").value       = document.getElementById("mode_of_payment"+"_r"+inRecNum).value;
    document.getElementById("pym_doc_date").value          = document.getElementById("pym_doc_date"+"_r"+inRecNum).value;
    document.getElementById("pym_doc_recv_date").value     = document.getElementById("pym_doc_recv_date"+"_r"+inRecNum).value;
    document.getElementById("pym_doc_deposit_date").value  = document.getElementById("pym_doc_deposit_date"+"_r"+inRecNum).value;
    document.getElementById("pym_doc_status").value        = document.getElementById("pym_doc_status"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("installment_id").value        = ''; 
    document.getElementById("grant_id").value              = ''; 
    document.getElementById("installment_date").value      = ''; 
    document.getElementById("month").value                 = ''; 
    document.getElementById("year").value                  = ''; 
    document.getElementById("due_date").value              = ''; 
    document.getElementById("installment_amt").value       = ''; 
    document.getElementById("paid_amt").value              = ''; 
    document.getElementById("balance_amt").value           = ''; 
    document.getElementById("installment_status").value    = ''; 
    document.getElementById("mode_of_payment").value       = ''; 
    document.getElementById("pym_doc_date").value          = ''; 
    document.getElementById("pym_doc_recv_date").value     = ''; 
    document.getElementById("pym_doc_deposit_date").value  = '';
    document.getElementById("pym_doc_status").value        = '';
    // add other fields like above
  }
}
