function populateClassId( inOrgCtg )
{
  var lClassId = '';
  var lClassNum     = document.getElementById("class_num").value;
  var lClassSection = document.getElementById("class_section").value;
  var lCourseStream = document.getElementById("course_stream").value;

  if ( inOrgCtg == 'I' )
  {
     var lCourseId     = document.getElementById("course_id").value;
     var lCourseTerm   = document.getElementById("course_term").value;

     if ( lCourseId != null && lCourseId.length > 0 ) lClassId =  lClassId + lCourseId;
     if ( lCourseStream != null && lCourseStream.length > 0 && ( lCourseStream != 'NA' || lCourseStream == '' ) ) 
       lClassId =  lClassId + '/' + lCourseStream;
     if ( lClassNum != null && lClassNum.length > 0 ) lClassId =  lClassId + '/' + lClassNum;
     if ( lCourseTerm != null && lCourseTerm.length > 0 ) lClassId =  lClassId + '/' + lCourseTerm;
     if ( lClassSection != null && lClassSection.length > 0 ) lClassId =  lClassId + '/' + lClassSection;
   }
   else
   if ( inOrgCtg == 'S' )
   {
     if ( lClassNum != null && lClassNum.length > 0 )         lClassId =  lClassId  + lClassNum;
     if ( lCourseStream != null && lCourseStream.length > 0 && ( lCourseStream != 'NA' || lCourseStream == '' ) ) 
       lClassId =  lClassId + '/' + lCourseStream;
     if ( lClassSection != null && lClassSection.length > 0 ) lClassId =  lClassId + '/' + lClassSection;
   }
   document.getElementById("class_id").value = lClassId;
}


function splitClassId( inOrgCtg
                     , inClassIdValue
                     , inCourseIdFieldName
                     , inClassNumFieldName
                     , inCourseStreamFieldName
                     , inCourseTermFieldName
                     , inClassSectionFieldName )
{
  //---------------------------------------------------------
  // Example of CLASS_ID
  // 1. MCA/1/1
  // 2. MCA/1/1/A
  // 3. BTECH/CS/1/1
  // 4. BTECH/CS/1/1/A
  // 5. 12/S
  // 6. 12/S/A
  // 7. 10
  // 8. 10
  //---------------------------------------------------------
  var lCourseIdValue     = '';
  var lClassNumValue     = '';
  var lCourseStreamValue = '';
  var lCourseTermValue   = '';
  var lClassSectionValue = '';

  var lClassIdValue = inClassIdValue.split('/');
  
  if ( inOrgCtg == 'I' )
  {
    //if ( lClassIdValue[0] == 'MCA' || lClassIdValue[0] == 'BCA' )
    var lCourseIdListNoStreamObj = document.getElementById('course_id_list_no_stream_str');
    if ( lCourseIdListNoStreamObj && ( lCourseIdListNoStreamObj.value.indexOf(lClassIdValue[0]) != -1 ) )
    {
      lCourseIdValue    = lClassIdValue[0];
      lClassNumValue    = lClassIdValue[1];
      lCourseTermValue  = lClassIdValue[2];
      if ( lClassIdValue.length == 4 )
        lClassSectionValue = lClassIdValue[3];
    }
    else
    {
      lCourseIdValue     = lClassIdValue[0];
      lCourseStreamValue = lClassIdValue[1];
      lClassNumValue     = lClassIdValue[2];
      lCourseTermValue   = lClassIdValue[3];
      if ( lClassIdValue.length == 5 )
        lClassSectionValue = lClassIdValue[4];
    }
  }
  else
  if ( inOrgCtg == 'S' )
  {
    //if ( lClassIdValue[0] == '11' || lClassIdValue[0] == '12' )
    var lClassNumListStreamObj = document.getElementById('class_num_list_stream_str');
    if ( lClassNumListStreamObj && ( lClassNumListStreamObj.value.indexOf( lClassIdValue[0] ) != -1 ) )
    {
      lClassNumValue     = lClassIdValue[0];
      lCourseStreamValue = lClassIdValue[1];
      if ( lClassIdValue.length == 3 )
        lClassSectionValue = lClassIdValue[2];
    }
    else
    {
      lClassNumValue     = lClassIdValue[0];
      if ( lClassIdValue.length == 2 )
        lClassSectionValue = lClassIdValue[1];
    }
  }

  document.getElementById(inCourseIdFieldName).value     = lCourseIdValue;
  document.getElementById(inClassNumFieldName).value     = lClassNumValue;
  document.getElementById(inCourseTermFieldName).value   = lCourseTermValue;
  document.getElementById(inCourseStreamFieldName).value = lCourseStreamValue;
  document.getElementById(inClassSectionFieldName).value = lClassSectionValue;

  hideCourseStream( inOrgCtg, lCourseIdValue, lClassNumValue, inCourseStreamFieldName );

  //alert( document.getElementById(inCourseId).value );
  //alert( document.getElementById(inClassNum).value );
  //alert( document.getElementById(inCourseTerm).value );
  //alert( document.getElementById(inCourseStream).value );
  //alert( document.getElementById(inClassSection).value );
}


function hideCourseStream( inOrgCtg, inCourseIdValue, inClassNumValue, inCourseStreamFieldName )
{

  var lCourseIdValue = inCourseIdValue;
  var lClassNumValue = inClassNumValue;

  var lCourseStreamFieldNameDiv = document.getElementById(inCourseStreamFieldName+'_div');
  var lCourseStreamFieldName    = document.getElementById(inCourseStreamFieldName);

  if ( !lCourseStreamFieldNameDiv || !lCourseStreamFieldName ) return -1;

  if ( inOrgCtg == 'I' )
  {
    //if ( lCourseIdValue=='MCA' || lCourseIdValue=='BCA' )
    var lCourseIdListNoStreamObj = document.getElementById('course_id_list_no_stream_str');
    if ( lCourseIdListNoStreamObj && ( lCourseIdListNoStreamObj.value.indexOf( lCourseIdValue ) != -1 ) )
    {
      document.getElementById(inCourseStreamFieldName+'_div').style.display='none';
      document.getElementById(inCourseStreamFieldName).value='';
    }
    else
      document.getElementById(inCourseStreamFieldName+'_div').style.display='';
  }
  else
  if ( inOrgCtg == 'S' )
  {
    //if ( lClassNumValue=='11' || lClassNumValue=='12' )
    var lClassNumListStreamObj = document.getElementById('class_num_list_stream_str');
    if ( lClassNumListStreamObj && ( lClassNumListStreamObj.value.indexOf( lClassNumValue ) != -1 ) )
    {
      document.getElementById(inCourseStreamFieldName+'_div').style.display='none';
      document.getElementById(inCourseStreamFieldName).value='';
    }
    else
      document.getElementById(inCourseStreamFieldName+'_div').style.display='';
  }
}
