function EesHostelExitEntryRegRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   // document.getElementById("rec_cre_date").value      = document.getElementById("rec_cre_date"+"_r"+inRecNum).value;
    //document.getElementById("seq_num").value      = document.getElementById("seq_num"+"_r"+inRecNum).value;
//    document.getElementById("org_id").value      = document.getElementById("org_id"+"_r"+inRecNum).value;
    //document.getElementById("hostel_id").value      = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    //document.getElementById("student_id_entry").value      = document.getElementById("student_id_entry"+"_r"+inRecNum).value;
    document.getElementById("student_id_exit").value      = document.getElementById("student_id_exit"+"_r"+inRecNum).value;
    document.getElementById("purpose").value      = document.getElementById("purpose"+"_r"+inRecNum).value;
    document.getElementById("dest_address").value      = document.getElementById("dest_address"+"_r"+inRecNum).value;
    //document.getElementById("exit_date").value      = document.getElementById("exit_date"+"_r"+inRecNum).value;
    //document.getElementById("exit_time").value      = document.getElementById("exit_time"+"_r"+inRecNum).value;
    //document.getElementById("entry_date").value      = document.getElementById("entry_date"+"_r"+inRecNum).value;
    //document.getElementById("entry_time").value      = document.getElementById("entry_time"+"_r"+inRecNum).value;
    //document.getElementById("status").value      = document.getElementById("status"+"_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value      = '';
    //document.getElementById("rec_cre_date").value      = '';
    //document.getElementById("seq_num").value      = '';
  //  document.getElementById("org_id").value      = '';
    //document.getElementById("hostel_id").value      = '';
    //document.getElementById("student_id_entry").value      = '';
    document.getElementById("student_id_exit").value      = '';
    document.getElementById("purpose").value      = '';
    document.getElementById("dest_address").value      = '';
    //document.getElementById("exit_date").value      = '';
    //document.getElementById("exit_time").value      = '';
    //document.getElementById("entry_date").value      = '';
    //document.getElementById("entry_time").value      = '';
    //document.getElementById("status").value      = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
