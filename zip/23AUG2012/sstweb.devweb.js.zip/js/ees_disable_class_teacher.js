function disableClassTeacher()
{
  var lClassSection;
  var lClassTeacher;
  lClassSection = document.getElementById('class_section').value;
  lClassTeacher = document.getElementById("class_teacher");
  if ( lClassSection != null && lClassSection > 0)
   lClassTeacher.disabled = true;
  else
   lClassTeacher.disabled = false;
}
