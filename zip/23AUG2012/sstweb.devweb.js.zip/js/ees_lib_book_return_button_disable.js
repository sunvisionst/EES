
function buttonDisable(inFlag)
{
  var lDisable = document.getElementById('submit1');

  if(inFlag == 'Y')
    lDisable.disabled = false;
  else
    lDisable.disabled = true;
}



