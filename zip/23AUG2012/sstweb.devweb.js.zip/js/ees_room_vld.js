function RoomVld( inDBValFlag, inFieldValue, inNumOfRec, inRecNum )
{
  var lAssignRoomNumObj = document.getElementById("room_num"+"_r"+inRecNum);
  var lRoomShareIndObj = document.getElementById("room_share_ind"+"_r"+inRecNum);
  for ( var lRecNum = 1; lRecNum <= parseInt(inNumOfRec); lRecNum++)
  {
    var lRoomNumObj = document.getElementById("room_num"+"_r"+lRecNum);
    if ( lRecNum != parseInt(inRecNum) )
    {
      if ( ( lRoomShareIndObj && lRoomShareIndObj.value != 'Y' ) && ( lRoomNumObj.value == lAssignRoomNumObj.value ) )
      {
        alert('This Room No. is Already Assigned');
        if ( inDBValFlag == 'N' )
          lAssignRoomNumObj.value = '';
        else
        if ( inDBValFlag == 'Y' )
          lAssignRoomNumObj.value = inFieldValue;
        break;
      }
    }
  }
}
