function  showForClassField1()
{
  if ( document.form.select_radio_1.checked )
  {
    document.getElementById("class_num_tr").style.display= 'none';
    document.getElementById("course_id_tr").style.display= 'none';
    document.getElementById("course_term_tr").style.display= 'none';
    document.getElementById("course_stream_tr").style.display= 'none';
    document.getElementById("course_std_tr").style.display= 'none';
  }
  else
  {
    document.getElementById("class_num_tr").style.display= '';
    document.getElementById("course_id_tr").style.display= '';
    document.getElementById("course_term_tr").style.display= '';
    document.getElementById("course_stream_tr").style.display= '';
    document.getElementById("course_std_tr").style.display= '';
  }

}
