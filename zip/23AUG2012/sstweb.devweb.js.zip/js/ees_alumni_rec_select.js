function EesAlumniRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("alumni_id").value  = document.getElementById("alumni_id"+"_r"+inRecNum).value; 
    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("alumni_cre_date").value  = document.getElementById("alumni_cre_date"+"_r"+inRecNum).value; 
    document.getElementById("barcode").value  = document.getElementById("barcode"+"_r"+inRecNum).value; 
    document.getElementById("user_id").value  = document.getElementById("user_id"+"_r"+inRecNum).value; 
    document.getElementById("pswd_0").value  = document.getElementById("pswd_0"+"_r"+inRecNum).value; 
    document.getElementById("student_name").value  = document.getElementById("student_name"+"_r"+inRecNum).value; 
    document.getElementById("father_name").value  = document.getElementById("father_name"+"_r"+inRecNum).value; 
    document.getElementById("mother_name").value  = document.getElementById("mother_name"+"_r"+inRecNum).value; 
    document.getElementById("student_ctg").value  = document.getElementById("student_ctg"+"_r"+inRecNum).value; 
    document.getElementById("gender_flag").value  = document.getElementById("gender_flag"+"_r"+inRecNum).value; 
    document.getElementById("dob").value  = document.getElementById("dob"+"_r"+inRecNum).value; 
    document.getElementById("doj").value  = document.getElementById("doj"+"_r"+inRecNum).value; 
    document.getElementById("dot").value  = document.getElementById("dot"+"_r"+inRecNum).value; 
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value; 
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    document.getElementById("enrollment_num").value  = document.getElementById("enrollment_num"+"_r"+inRecNum).value; 
    document.getElementById("shift_code").value  = document.getElementById("shift_code"+"_r"+inRecNum).value; 
    document.getElementById("prev_org_id").value  = document.getElementById("prev_org_id"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_id").value  = document.getElementById("prev_class_id"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_num").value  = document.getElementById("prev_class_num"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_std").value  = document.getElementById("prev_class_std"+"_r"+inRecNum).value; 
    document.getElementById("prev_class_section").value  = document.getElementById("prev_class_section"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_id").value  = document.getElementById("prev_course_id"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_term").value  = document.getElementById("prev_course_term"+"_r"+inRecNum).value; 
    document.getElementById("prev_course_stream").value  = document.getElementById("prev_course_stream"+"_r"+inRecNum).value; 
    document.getElementById("prev_shift_code").value  = document.getElementById("prev_shift_code"+"_r"+inRecNum).value; 
    document.getElementById("promotion_sts").value  = document.getElementById("promotion_sts"+"_r"+inRecNum).value; 
    document.getElementById("promotion_date").value  = document.getElementById("promotion_date"+"_r"+inRecNum).value; 
    document.getElementById("phone").value  = document.getElementById("phone"+"_r"+inRecNum).value; 
    document.getElementById("email_id").value  = document.getElementById("email_id"+"_r"+inRecNum).value; 
    document.getElementById("student_sts").value  = document.getElementById("student_sts"+"_r"+inRecNum).value; 
    document.getElementById("student_sts_date").value  = document.getElementById("student_sts_date"+"_r"+inRecNum).value; 
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value; 
    document.getElementById("photo_file_name").value  = document.getElementById("photo_file_name"+"_r"+inRecNum).value; 
    document.getElementById("batch_number").value  = document.getElementById("batch_number"+"_r"+inRecNum).value; 
    document.getElementById("num_of_yr_in_class").value  = document.getElementById("num_of_yr_in_class"+"_r"+inRecNum).value; 
    document.getElementById("passing_year").value  = document.getElementById("passing_year"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("alumni_id").value  = '';
    document.getElementById("org_id").value  = '';
    document.getElementById("alumni_cre_date").value  = '';
    document.getElementById("barcode").value  = '';
    document.getElementById("user_id").value  = '';
    document.getElementById("pswd_0").value  = '';
    document.getElementById("student_name").value  = '';
    document.getElementById("father_name").value  = '';
    document.getElementById("mother_name").value  = '';
    document.getElementById("student_ctg").value  = '';
    document.getElementById("gender_flag").value  = '';
    document.getElementById("dob").value  = '';
    document.getElementById("doj").value  = '';
    document.getElementById("dot").value  = '';
    document.getElementById("address_1").value  = '';
    document.getElementById("address_2").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("class_section").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("roll_num").value  = '';
    document.getElementById("enrollment_num").value  = '';
    document.getElementById("shift_code").value  = '';
    document.getElementById("prev_org_id").value  = '';
    document.getElementById("prev_class_id").value  = '';
    document.getElementById("prev_class_num").value  = '';
    document.getElementById("prev_class_std").value  = '';
    document.getElementById("prev_class_section").value  = '';
    document.getElementById("prev_course_id").value  = '';
    document.getElementById("prev_course_term").value  = '';
    document.getElementById("prev_course_stream").value  = '';
    document.getElementById("prev_shift_code").value  = '';
    document.getElementById("promotion_sts").value  = '';
    document.getElementById("promotion_date").value  = '';
    document.getElementById("phone").value  = '';
    document.getElementById("email_id").value  = '';
    document.getElementById("student_sts").value  = '';
    document.getElementById("student_sts_date").value  = '';
    document.getElementById("country").value  = '';
    document.getElementById("photo_file_name").value  = '';
    document.getElementById("batch_number").value  = '';
    document.getElementById("num_of_yr_in_class").value  = '';
    document.getElementById("passing_year").value  = '';
  }
}
