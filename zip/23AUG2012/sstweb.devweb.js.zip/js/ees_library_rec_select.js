function EesLibraryRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("library_id").value  = document.getElementById("library_id"+"_r"+inRecNum).value; 
    document.getElementById("library_type").value  = document.getElementById("library_type"+"_r"+inRecNum).value; 
    document.getElementById("library_name").value  = document.getElementById("library_name"+"_r"+inRecNum).value; 
    document.getElementById("capacity").value  = document.getElementById("capacity"+"_r"+inRecNum).value; 
    //document.getElementById("faculty_id").value  = document.getElementById("faculty_id"+"_r"+inRecNum).value; 
    //document.getElementById("faculty_name").value  = document.getElementById("faculty_name"+"_r"+inRecNum).value; 
    document.getElementById("assistant_id").value  = document.getElementById("assistant_id"+"_r"+inRecNum).value; 
    document.getElementById("assistant_name").value  = document.getElementById("assistant_name"+"_r"+inRecNum).value; 
    document.getElementById("building_id").value  = document.getElementById("building_id"+"_r"+inRecNum).value; 
    document.getElementById("building_name").value  = document.getElementById("building_name"+"_r"+inRecNum).value; 
    //document.getElementById("floor_num").value  = document.getElementById("floor_num"+"_r"+inRecNum).value; 

    {
      gSelectedValue = document.getElementById("room_num"+"_r"+inRecNum).value;
      gErrorMessage  = 'ROOM NOT FOUND';
      var lWhereText='org_id = \''+document.getElementById('org_id').value+'\'';
      lWhereText= lWhereText + ' and building_id = \''+document.getElementById("building_id"+"_r"+inRecNum).value+'\'';
      invokeRefreshField( lWhereText, 'ees_library', 'get_room_num', 'ROOM_NUM,ROOM_NUM', 'room_num', 'option', 'SELECT' );
    }

    document.getElementById("room_num").value  = document.getElementById("room_num"+"_r"+inRecNum).value; 
    document.getElementById("open_time").value  = document.getElementById("open_time"+"_r"+inRecNum).value; 
    document.getElementById("close_time").value  = document.getElementById("close_time"+"_r"+inRecNum).value; 
    document.getElementById("max_book_issue").value  = document.getElementById("max_book_issue"+"_r"+inRecNum).value;

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("library_id").value  = '';
    document.getElementById("library_type").value  = '';
    document.getElementById("library_name").value  = '';
    document.getElementById("capacity").value  = '';
    //document.getElementById("faculty_id").value  = '';
    //document.getElementById("faculty_name").value  = '';
    document.getElementById("assistant_id").value  = '';
    document.getElementById("assistant_name").value  = '';
    //document.getElementById("building_id").value  = '';
    document.getElementById("building_name").value  = '';
    //document.getElementById("floor_num").value  = '';
    document.getElementById("room_num").value  = '';
    document.getElementById("open_time").value  = '';
    document.getElementById("close_time").value  = '';
    document.getElementById("max_book_issue").value  = '';
  }
}
