
function radio_cb_select(event, inEsmGenCfrArrSize )
{


  /*
    INDICATOR TO CHECK RADIO IS 
    SELECTED OR NOT (DEFAULT NOT SELECTED).
  */
  var lRadioSelInd = false; 

  /*
    INDICATOR TO CHECK CHECK BOX IS
    SELECTED OR NOT (DEFAULT NOT SELECTED).
  */
  var truefalse      = true;

  for ( var lRecNum = 0; lRecNum < inEsmGenCfrArrSize; lRecNum++ )
  {
    var lRadioObj = document.getElementById('select_radio'+lRecNum+'');
    if ( lRadioObj != null && lRadioObj.checked )
    {
      lRadioSelInd = true;
      break;  
    }
  } 

  var lCheckBoxInd = false; 
  var lCheckBoxObj        = document.getElementById('new_chapter');
  //lCheckBoxObj.value  = document.form.new_chapter_1.checked; 

  if ( lCheckBoxObj != null && lCheckBoxObj.checked )
    lCheckBoxInd = true;

   
  /*
   FOLLOWING IS CHECKED FOR IF 
   BOTH OPTION IS SELECTED 
   THEN DISPLAY A ALERT MSG
   (RADIO & CHECK BOX).
  */ 
 if( lCheckBoxInd && lRadioSelInd  )
 {
   alert('Please Select Only One Fron Both Check Box & Radio !!');
   truefalse = false;

   var lCheckBoxObj        = document.getElementById('new_chapter');
  /*
   REMOVING OF SELECTION OF  
   CHECK BOX. 
  */ 
   if ( lCheckBoxObj != null && lCheckBoxObj.checked )
     lCheckBoxObj.checked = false; 
  
   for ( var lRecNum = 0; lRecNum < inEsmGenCfrArrSize; lRecNum++ )
   {
     var lRadioObj = document.getElementById('select_radio'+lRecNum+'');

     /*
      REMOVING OF SELECTION OF  
      RADIO BUTTON.
     */ 
     if( lRadioObj.checked) 
        lRadioObj.checked = false;
   }
 }


  /*
   FOLLOWING IS CHECKED FOR IF 
   NOT ANY OPTION IS SELECTED 
   (RADIO OR CHECK BOX).
  */ 
  if( !lCheckBoxInd || !lRadioSelInd )
    truefalse = false; 

  /*
   IF ANY ONE OPTION IS SELECTED,
   HERE IF RADIO IS SELECTED AND 
   CHECK BOX IS NOT SELECTED
   (RADIO OR CHECK BOX).
  */ 
  if( !lCheckBoxInd && lRadioSelInd )
    truefalse = true; 
  
  /*
   IF ANY ONE OPTION IS SELECTED,
   HERE IF CHECK BOX IS SELECTED AND 
   RADIO IS NOT SELECTED
   (RADIO OR CHECK BOX).
  */ 
  if( !lRadioSelInd && lCheckBoxInd )
    truefalse = true; 
    
 

 
  if(!truefalse)
  {
     lReturnValue = -1;
     alert("Please mark atleast one checkbox or radio to continue ")
     var lBrowserName = getBrowserName();
     if ( lBrowserName == 'Microsoft Internet Explorer' )
       window.event.returnValue=false;
     else
     if ( lBrowserName == 'Netscape' )
     {
       event.preventDefault();
       event.stopPropagation();
     }
  }
  return ( lReturnValue );
 

}
