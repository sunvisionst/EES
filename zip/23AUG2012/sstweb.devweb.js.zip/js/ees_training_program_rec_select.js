function EesTrainingProgramRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("program_id").value         = document.getElementById("program_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").value             = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("program_name").value       = document.getElementById("program_name"+"_r"+inRecNum).value;
    document.getElementById("remark").value             = document.getElementById("remark"+"_r"+inRecNum).value;
    document.getElementById("program_duration").value   = document.getElementById("program_duration"+"_r"+inRecNum).value;
    document.getElementById("class_num").value          = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("course_id").value          = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value        = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("program_type").value       = document.getElementById("program_type"+"_r"+inRecNum).value;
    document.getElementById("ei_flag").value            = document.getElementById("ei_flag"+"_r"+inRecNum).value;
    document.getElementById("tpm_file_name").value      = document.getElementById("tpm_file_name"+"_r"+inRecNum).value;
    document.getElementById("class_std").value          = document.getElementById("class_std"+"_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    document.getElementById("program_id").value      = '';
    document.getElementById("org_id").value          = '';
    document.getElementById("program_name").value    = '';
    document.getElementById("remark").value          = '';
    document.getElementById("program_duration").value      = '';
    document.getElementById("class_num").value       = '';
    document.getElementById("course_id").value       = '';
    document.getElementById("course_term").value     = '';
    document.getElementById("program_type").value    = '';
    document.getElementById("ei_flag").value         = '';
    document.getElementById("tpm_file_name").value   = '';
    document.getElementById("class_std").value   = '';

    //document.getElementById("__field_name__").value      = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
