function EesLabSchButtenVld(inRecOnPage)
{
  var lSubmitObj;
  var lFlag = "N";
  for(var i=1; i<= inRecOnPage; i++)
  {
      var lSelect = document.getElementById("select_radio"+(i-1));
      if ( lSelect.checked )
      {
          lFlag = "Y";
          break;
      }
      else
      {
         lFlag = "N";
      }

  }

  if(lFlag == "N" && document.getElementById("week_day").value  == '' ) 
  {
    alert("Select Lab and Week Day To Continue");

    window.event.returnValue = false;
  }
  else
  if(lFlag == "N" && document.getElementById("week_day").value  != '' )
  {
    alert("Select Lab To Continue");

    window.event.returnValue = false;
  }
  else
  if(lFlag == "Y" && document.getElementById("week_day").value  == '' )
  {
    alert("Select Week Day To Continue");

    window.event.returnValue = false;
  }

}
