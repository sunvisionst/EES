function EesLecturePlanRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value;
    //document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value;
    document.getElementById("seq_num").value       = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("topic_id").value      = document.getElementById("topic_id"+"_r"+inRecNum).value;
    document.getElementById("unit_num").value      = document.getElementById("unit_num"+"_r"+inRecNum).value;
    document.getElementById("num_session").value   = document.getElementById("num_session"+"_r"+inRecNum).value;
    document.getElementById("topic_desc").value    = document.getElementById("topic_desc"+"_r"+inRecNum).value;
    document.getElementById("course_id").value     = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("lp_version").value    = document.getElementById("lp_version"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value        = '';
    //document.getElementById("subject_code").value  = '';
    document.getElementById("seq_num").value       = inRecNum;
    document.getElementById("topic_id").value      = '';
    document.getElementById("unit_num").value      = '';
    document.getElementById("num_session").value   = '';
    document.getElementById("topic_desc").value    = '';
    document.getElementById("course_id").value     = '';
    document.getElementById("lp_version").value    = '';



// add other fields like above
  }
}
