function EesFeeDueDateRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value      = document.getElementById("org_id"+"_r"+inRecNum).value;
    //document.getElementById("academic_session").value   = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("year_qrt_num").value       = document.getElementById("year_qrt_num"+"_r"+inRecNum).value;
    document.getElementById("dop_start").value          = document.getElementById("dop_start"+"_r"+inRecNum).value;
    document.getElementById("dop_end").value            = document.getElementById("dop_end"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;;


    //document.getElementById("org_id").value      = '';
    //document.getElementById("academic_session").value  = '';
    document.getElementById("year_qrt_num").value      = '';
    document.getElementById("dop_start").value         = '';
    document.getElementById("dop_end").value           = '';
  }
}
