function show_alert_msg( inSrcFieldObj )
{
  alert('Already Select This Choice');
  inSrcFieldObj.value = '';
  inSrcFieldObj.focus();
}



function check_course_stream( inNumOption, inSrcFieldObj )
{
    var lTrgDDObj_1;  ///OBJ FOR DROP DOWN FOR ASCENDING ORDER SELECTION OF STREAM
    var lTrgDDObj_2;  ///OBJ FOR DROP DOWN FOR DESCENDING ORDER SELECTION OF STREAM;

    for( var lOptNum = 0; lOptNum <= (inNumOption*1); lOptNum++ ) //OUTER LOOP FOR ASCENDING ORDER SELECTION
    {

      if( lOptNum == 5 )///THIS CONDITION IS ONLY STOP EXCESS ITERATION OF LOOP
        break;

      if( lOptNum == 0 )
        lTrgDDObj_1 = document.getElementById('course_stream');//OBJECT FOR ASCENDING OREDER SELECTION
      else
        lTrgDDObj_1 = document.getElementById('course_stream_'+lOptNum+'');//OBJECT FOR ASCENDING OREDER SELECTION

      if( inNumOption == lOptNum ) ///CHECK IF THE DD IS THE CURRENT DD FOR STREAM IN THE OUTER LOOP
      {
        /*
         FOLLOWING LOOP CHECKED IF THE VALUE SELECTED
         FROM THE CURRENT D/D IS NOT ALREADY SELECTED
         BY THE OTHER FURTHER D/D.
        */
        for( var lOptRec = ((inNumOption*1) +1); lOptRec <= 4; lOptRec++ )//LOOP FOR DESC ORDER SELECTION
        {
            lTrgDDObj_2 = document.getElementById('course_stream_'+lOptRec+'');//OBJECT FOR DESCENDING OREDR SELECTION 

          if( inSrcFieldObj != null && lTrgDDObj_2 != null //CHECK THE VALUE OF CURRENT OBJECT 
              && inSrcFieldObj.value == lTrgDDObj_2.value  //AND THE VALUE GET FROM THE ALREADY SELECTED DD
            ) 
          {
            show_alert_msg(inSrcFieldObj);///METHOD TO CALL ALERT MESSAGE
            break;
          }
        }  
      }  
      else
      if( inSrcFieldObj != null && lTrgDDObj_1 != null //CHECK THE VALUE OF CURRENT OBJECT  
          && inSrcFieldObj.value == lTrgDDObj_1.value  //AND THE VALUE GET FROM THE ALREADY SELECTED DD IN ASC ORDER FROM LOOP
        ) 
      {
        show_alert_msg(inSrcFieldObj);///METHOD TO CALL ALERT MESSAGE
        break;
      } 
    }  
}
