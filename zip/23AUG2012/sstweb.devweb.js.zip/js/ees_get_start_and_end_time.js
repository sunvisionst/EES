function getStartAndEndTime( lAllPeriod, inRecNum)
{
 var lFlag = false;
 var lIndexNum = -1; 
 var lSessionId = document.getElementById("session_id").value
 if(inRecNum == 0)
 {
   alert("Please Define Perids in period table");
 }
 else
 {
    var lPeriodDetail = lAllPeriod.split('/');
    var lPeriodNumArr = new Array(inRecNum);
    var lStartTimeArr = new Array(inRecNum);
    var lEndTimeArr   = new Array(inRecNum);
    for(var num = 0; num<inRecNum; num++)
    {
     //alert("lPeriodDetail[num]:-- "+lPeriodDetail[num]);
       var l_pn_st_and_et = lPeriodDetail[num].split('-');
       lPeriodNumArr[num] = l_pn_st_and_et[0];
       lStartTimeArr[num] = l_pn_st_and_et[1];
       lEndTimeArr[num]   = l_pn_st_and_et[2];
    } 
   
    for(num = 0; num<inRecNum; num++)
    {
      if(lPeriodNumArr[num] == lSessionId)
      {
        lFlag     = true;
        lIndexNum = num;
        break;
      }
    }
    if(lFlag == true)
    { 
      if(lSessionId == lPeriodNumArr[lIndexNum])
      {
        document.getElementById("sch_time_from").value       = lStartTimeArr[lIndexNum];
        //document.getElementById("sch_time_from_dummy").value = lStartTimeArr[lIndexNum];
        document.getElementById("sch_time_to").value         = lEndTimeArr[lIndexNum];
       // document.getElementById("sch_time_to_dummy").value   = lEndTimeArr[lIndexNum];  
      }
    }
    else
    {
        if(lSessionId != '')
          alert("Today For  Session "+lSessionId+" No Scedule is Creataed,First Create Schedule");
        document.getElementById("sch_time_from").value       = '';
        //document.getElementById("sch_time_from_dummy").value = '';
        document.getElementById("sch_time_to").value         = '';
       // document.getElementById("sch_time_to_dummy").value   = '';
    } 
 } 
}
