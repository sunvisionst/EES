function EesLabDateRecSelect( inSelectFlag, inRecNum)
{
  if ( inSelectFlag == 'Y' )
  {
    document.getElementById("sch_date").value = document.getElementById("select_radio_date"+inRecNum).value;
    document.getElementById("week_day").value = inRecNum; 
    document.getElementById("week_day"+"_dummy").value = inRecNum; 
  }
}
