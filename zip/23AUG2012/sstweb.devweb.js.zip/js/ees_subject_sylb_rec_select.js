function EesSubjectSylbRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
   
    document.getElementById("subject_code").value       = document.getElementById("subject_code"+"_r"+inRecNum).value;
    //if (document.getElementById("subject_code").value =='###')
    //    document.getElementById("subject_code"+"_td").style.color ='#993300' ;
    //{
    //  var lRegularExpression =new RegExp(document.getElementById("subject_code").value,"g");
    //  var lString = document.getElementById("subject_code").innerHTML;
    //  lString = lString.replace(lRegularExpression,document.getElementById("subject_code"+"_r"+inRecNum).value);
    //  document.getElementById("subject_code"+"_td").innerHTML = lString;
    //}
    //alert( document.getElementById("subject_code").value );
    //alert( document.getElementById("select_r"+inRecNum).value );


    //document.getElementById("org_id").value             = document.getElementById("org_id"+"_r"+inRecNum).value;

    //if ( document.getElementById("org_ctg").value == 'I' )
    //{
    //  document.getElementById("course_id").value          = document.getElementById("course_id"+"_r"+inRecNum).value;
    //  document.getElementById("course_term").value        = document.getElementById("course_term"+"_r"+inRecNum).value;
    //}
    //document.getElementById("class_num").value          = document.getElementById("class_num"+"_r"+inRecNum).value;
    //document.getElementById("course_stream").value      = document.getElementById("course_stream"+"_r"+inRecNum).value;
    
    document.getElementById("num_of_lecture").value     = document.getElementById("num_of_lecture"+"_r"+inRecNum).value;
    document.getElementById("per_week_lecture").value   = document.getElementById("per_week_lecture"+"_r"+inRecNum).value;
    document.getElementById("num_unit").value           = document.getElementById("num_unit"+"_r"+inRecNum).value;
    document.getElementById("syllabus_file_name").value = document.getElementById("syllabus_file_name"+"_r"+inRecNum).value;
    document.getElementById("syllabus_file_path").value = document.getElementById("syllabus_file_path"+"_r"+inRecNum).value;
    document.getElementById("syllabus_file_type").value = document.getElementById("syllabus_file_type"+"_r"+inRecNum).value;
    document.getElementById("upload_sylb_file_tr").style.display = '';
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit5"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("subject_code").value       = '';
    //var lRegularExpression =new RegExp(document.getElementById("subject_code").value,"g");
    //var lString = document.getElementById("subject_code"+"_td").innerHTML;
    //lString = lString.replace(lRegularExpression,'###');
    //document.getElementById("subject_code"+"_td").innerHTML = lString;
    //document.getElementById("subject_code"+"_td").style.color ='#FFFFFF' ;


    //document.getElementById("org_id").value             = '';
    //if ( document.getElementById("org_ctg").value == 'I' )
    //{
      //document.getElementById("course_id").value        = '';
      //document.getElementById("course_term").value      = '';
    //}
    //document.getElementById("class_num").value          = '';
    //document.getElementById("course_stream").value      = '';
    
    document.getElementById("num_of_lecture").value     = '40';
    document.getElementById("per_week_lecture").value   = '4';
    document.getElementById("num_unit").value           = '5';
    document.getElementById("syllabus_file_name").value = '';
    document.getElementById("syllabus_file_path").value = '';
    document.getElementById("syllabus_file_type").value = 'TXT';
    document.getElementById("upload_sylb_file_tr").style.display = 'none';
  }
}
