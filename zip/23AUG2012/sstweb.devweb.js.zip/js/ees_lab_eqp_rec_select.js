function EesLabEqpRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("lab_id").value  = document.getElementById("lab_id"+"_r"+inRecNum).value; 
    document.getElementById("eqp_id").value  = document.getElementById("eqp_id"+"_r"+inRecNum).value; 
    document.getElementById("eqp_type").value  = document.getElementById("eqp_type"+"_r"+inRecNum).value; 
    document.getElementById("eqp_name").value  = document.getElementById("eqp_name"+"_r"+inRecNum).value; 
    document.getElementById("ip_address").value  = document.getElementById("ip_address"+"_r"+inRecNum).value; 
    document.getElementById("vendor_name").value  = document.getElementById("vendor_name"+"_r"+inRecNum).value; 
    document.getElementById("dop").value  = document.getElementById("dop"+"_r"+inRecNum).value; 
    document.getElementById("wg_period").value  = document.getElementById("wg_period"+"_r"+inRecNum).value; 
    document.getElementById("specification").value  = document.getElementById("specification"+"_r"+inRecNum).value; 
    document.getElementById("complain_sts").value  = document.getElementById("complain_sts"+"_r"+inRecNum).value; 
    document.getElementById("complain_date").value  = document.getElementById("complain_date"+"_r"+inRecNum).value; 
    document.getElementById("complain_text").value  = document.getElementById("complain_text"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("lab_id").value  = '';
    document.getElementById("eqp_id").value  = '';
    document.getElementById("eqp_type").value  = '';
    document.getElementById("eqp_name").value  = '';
    document.getElementById("ip_address").value  = '';
    document.getElementById("vendor_name").value  = '';
    document.getElementById("dop").value  = '';
    document.getElementById("wg_period").value  = '';
    document.getElementById("specification").value  = '';
    document.getElementById("complain_sts").value  = '';
    document.getElementById("complain_date").value  = '';
    document.getElementById("complain_text").value  = '';
  }
}
