function EesLockerRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("location_id").value  = document.getElementById("location_id"+"_r"+inRecNum).value; 
    document.getElementById("locker_num").value  = document.getElementById("locker_num"+"_r"+inRecNum).value; 
    document.getElementById("locker_holder_type").value  = document.getElementById("locker_holder_type"+"_r"+inRecNum).value; 
    document.getElementById("locker_holder_id").value  = document.getElementById("locker_holder_id"+"_r"+inRecNum).value; 
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("allotted_date").value  = document.getElementById("allotted_date"+"_r"+inRecNum).value; 
    document.getElementById("allotted_time").value  = document.getElementById("allotted_time"+"_r"+inRecNum).value; 

    lSubmitObj = document.getElementById("submit2"); 
    var lSubmitObj1 = document.getElementById("submit3"); 
    if ( lSubmitObj != null || lSubmitObj1 != null ) 
    {
      if ( document.getElementById("status").value == 'A' )
      {
        lSubmitObj.disabled = true;
        lSubmitObj1.disabled = false;
      }
      else
      if ( document.getElementById("status").value == 'O' )
      {
        lSubmitObj.disabled = false;
        lSubmitObj1.disabled = true;
      }
      else
      {
        lSubmitObj.disabled = true;
        lSubmitObj1.disabled = true;
      }
    }
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("location_id").value  = '';
    document.getElementById("locker_num").value  = '';
    document.getElementById("locker_holder_type").value  = '';
    document.getElementById("locker_holder_id").value  = '';
    document.getElementById("roll_num").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("allotted_date").value  = '';
    document.getElementById("allotted_time").value  = '';
  }
}
