function EesExamSeatPlanRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("exam_id").value        = document.getElementById("exam_id"+"_r"+inRecNum).value;
    document.getElementById("room_num").value       = document.getElementById("room_num"+"_r"+inRecNum).value;
    document.getElementById("num_row").value        = document.getElementById("num_row"+"_r"+inRecNum).value;
    document.getElementById("student_per_row").value= document.getElementById("student_per_row"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("exam_id").value        = '';
    document.getElementById("room_num").value       = '';
    document.getElementById("num_row").value        = '';
    document.getElementById("student_per_row").value= '';
    // add other fields like above
  }
}
