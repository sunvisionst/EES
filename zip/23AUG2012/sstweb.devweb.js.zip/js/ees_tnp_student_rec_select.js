function EesTnpStudentRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("training_sch_id").value       = document.getElementById("training_sch_id"+"_r"+inRecNum).value;
    document.getElementById("student_id").value            = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").value                = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("company_id").value            = document.getElementById("company_id"+"_r"+inRecNum).value;
    document.getElementById("ei_flag").value               = document.getElementById("ei_flag"+"_r"+inRecNum).value;
    document.getElementById("from_date").value             = document.getElementById("from_date"+"_r"+inRecNum).value;
    document.getElementById("to_date").value               = document.getElementById("to_date"+"_r"+inRecNum).value;
    document.getElementById("project_name").value          = document.getElementById("project_name"+"_r"+inRecNum).value;
    document.getElementById("development_platform").value  = document.getElementById("development_platform"+"_r"+inRecNum).value;
    document.getElementById("project_manager").value       = document.getElementById("project_manager"+"_r"+inRecNum).value;
    document.getElementById("feedback").value              = document.getElementById("feedback"+"_r"+inRecNum).value;
    document.getElementById("print_ind_trl").value         = document.getElementById("print_ind_trl"+"_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value      = '';
    document.getElementById("training_sch_id").value       = '';
    document.getElementById("student_id").value            = '';
    document.getElementById("org_id").value                = '';
    document.getElementById("company_id").value            = '';
    document.getElementById("ei_flag").value               = '';
    document.getElementById("from_date").value             = '';
    document.getElementById("to_date").value               = '';
    document.getElementById("project_name").value          = '';
    document.getElementById("development_platform").value  = '';
    document.getElementById("project_manager").value       = '';
    document.getElementById("feedback").value              = '';
    document.getElementById("print_ind_trl").value         = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
