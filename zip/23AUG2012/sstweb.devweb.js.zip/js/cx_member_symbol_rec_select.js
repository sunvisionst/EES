function CxMemberSymbolRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    //document.getElementById("member_id").value  = document.getElementById("member_id"+"_r"+inRecNum).value; 
    document.getElementById("contract_id").value  = document.getElementById("contract_id"+"_r"+inRecNum).value; 
    document.getElementById("symbol_cd").value  = document.getElementById("symbol_cd"+"_r"+inRecNum).value; 
    document.getElementById("link_member_id").value  = document.getElementById("link_member_id"+"_r"+inRecNum).value; 
    document.getElementById("symbol_name").value  = document.getElementById("symbol_name"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value; 
    //document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    //document.getElementById("member_id").value  = '';
    document.getElementById("contract_id").value  = '';
    document.getElementById("symbol_cd").value  = '';
    document.getElementById("link_member_id").value  = '';
    document.getElementById("symbol_name").value  = '';
    document.getElementById("status").value  = '';
    //document.getElementById("rec_cre_date").value  = '';
    //document.getElementById("rec_cre_time").value  = '';
    //document.getElementById("rec_upd_date").value  = '';
    //document.getElementById("rec_upd_time").value  = '';
  }
}
