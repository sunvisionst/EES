function EsmSupplierPoInvItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_num").value  = document.getElementById("po_invoice_num"+"_r"+inRecNum).value; 
    document.getElementById("item_code").value  = document.getElementById("item_code"+"_r"+inRecNum).value; 
    document.getElementById("make_id").value  = document.getElementById("make_id"+"_r"+inRecNum).value; 
    document.getElementById("po_num").value  = document.getElementById("po_num"+"_r"+inRecNum).value; 
    document.getElementById("po_invoice_date").value  = document.getElementById("po_invoice_date"+"_r"+inRecNum).value; 
    document.getElementById("supp_invoice_num").value  = document.getElementById("supp_invoice_num"+"_r"+inRecNum).value; 
    document.getElementById("po_date").value  = document.getElementById("po_date"+"_r"+inRecNum).value; 
    document.getElementById("qty").value  = document.getElementById("qty"+"_r"+inRecNum).value; 
    document.getElementById("qty_received").value  = document.getElementById("qty_received"+"_r"+inRecNum).value; 
    document.getElementById("rate").value  = document.getElementById("rate"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("status_date").value  = document.getElementById("status_date"+"_r"+inRecNum).value; 
    document.getElementById("discount_percent").value  = document.getElementById("discount_percent"+"_r"+inRecNum).value; 
    document.getElementById("discount_fix").value  = document.getElementById("discount_fix"+"_r"+inRecNum).value; 
    document.getElementById("quality_status").value  = document.getElementById("quality_status"+"_r"+inRecNum).value; 
    document.getElementById("quality_status_date").value  = document.getElementById("quality_status_date"+"_r"+inRecNum).value; 
    document.getElementById("qty_rejected").value  = document.getElementById("qty_rejected"+"_r"+inRecNum).value; 
    document.getElementById("reject_remark").value  = document.getElementById("reject_remark"+"_r"+inRecNum).value; 
    document.getElementById("page_num").value  = document.getElementById("page_num"+"_r"+inRecNum).value; 
    document.getElementById("entry_num").value  = document.getElementById("entry_num"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("po_invoice_num").value  = '';
    document.getElementById("item_code").value  = '';
    document.getElementById("make_id").value  = '';
    document.getElementById("po_num").value  = '';
    document.getElementById("po_invoice_date").value  = '';
    document.getElementById("supp_invoice_num").value  = '';
    document.getElementById("po_date").value  = '';
    document.getElementById("qty").value  = '';
    document.getElementById("qty_received").value  = '';
    document.getElementById("rate").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("status_date").value  = '';
    document.getElementById("discount_percent").value  = '';
    document.getElementById("discount_fix").value  = '';
    document.getElementById("quality_status").value  = '';
    document.getElementById("quality_status_date").value  = '';
    document.getElementById("qty_rejected").value  = '';
    document.getElementById("reject_remark").value  = '';
    document.getElementById("page_num").value  = '';
    document.getElementById("entry_num").value  = '';
  }
}
