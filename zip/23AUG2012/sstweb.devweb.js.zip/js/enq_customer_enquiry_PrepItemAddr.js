
function enqCustomerEnquiryPrepIaddr( inMenuOption, inDBOpr, inRecNum )
{
    var lDelAddrTypeObj = document.getElementById("delivery_address_type_r"+inRecNum);
    if ( inMenuOption == 'Update' || inMenuOption == 'approveQuote' || inMenuOption == 'discardQuote' || inMenuOption == 'CNEnqV' )
    {
       if ( inDBOpr == 'Query' )
         var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum+"_dummy");
       else
         var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum);
    }
    else
    var lDelAddrObj = document.getElementById("delivery_address_r"+inRecNum+"_dummy");
    var lDeliveryAddress = "";
    if ( lDelAddrTypeObj.value != "" && lDelAddrTypeObj.value != 'N')
    {
      for ( var  lNumRec = 0; lNumRec < lEsmCustomerAddressTabObjJSArr.length; lNumRec++ )
      {
        if( lEsmCustomerAddressTabObjJSArr[lNumRec].address_type == lDelAddrTypeObj.value )
        {
          lDeliveryAddress = lDeliveryAddress + lEsmCustomerAddressTabObjJSArr[lNumRec].address_field_value;
          if ( lNumRec+1 < lEsmCustomerAddressTabObjJSArr.length )
            lDeliveryAddress = lDeliveryAddress + " , ";
        }
      }
    }
    else
    {
      var lItemCodeObj = document.getElementById("item_code_r"+inRecNum);
      var lMakeIdObj = document.getElementById("make_id_r"+inRecNum);
                                                                                                                             
      for ( var  lNumRec = 0; lNumRec < lEnqCustomerEnquiryIaddrTabObjJSArr.length; lNumRec++ )
      {
        if( lEnqCustomerEnquiryIaddrTabObjJSArr[lNumRec].item_code == lItemCodeObj.value
            && lEnqCustomerEnquiryIaddrTabObjJSArr[lNumRec].make_id == lMakeIdObj.value
          )
           lDeliveryAddress = lDeliveryAddress + lEnqCustomerEnquiryIaddrTabObjJSArr[lNumRec].delivery_address;
      }
    }
    lDelAddrObj.value = lDeliveryAddress;
}
