function EesTrainingSchRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("training_sch_id").value     = document.getElementById("training_sch_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").value              = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("program_id").value          = document.getElementById("program_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value           = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_std").value           = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("course_id").value           = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value         = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("course_stream").value       = document.getElementById("course_stream"+"_r"+inRecNum).value;
    document.getElementById("room_num").value            = document.getElementById("room_num"+"_r"+inRecNum).value;
    document.getElementById("period_type").value         = document.getElementById("period_type"+"_r"+inRecNum).value;
    document.getElementById("period").value              = document.getElementById("period"+"_r"+inRecNum).value;
    document.getElementById("from_date").value           = document.getElementById("from_date"+"_r"+inRecNum).value;
    document.getElementById("to_date").value             = document.getElementById("to_date"+"_r"+inRecNum).value;
    document.getElementById("paid_flag").value           = document.getElementById("paid_flag"+"_r"+inRecNum).value;
    document.getElementById("activity_amt").value        = document.getElementById("activity_amt"+"_r"+inRecNum).value;
    document.getElementById("ei_flag").value             = document.getElementById("ei_flag"+"_r"+inRecNum).value;
    document.getElementById("freelancer_flag").value     = document.getElementById("freelancer_flag"+"_r"+inRecNum).value;
    document.getElementById("trainer_org_id").value      = document.getElementById("trainer_org_id"+"_r"+inRecNum).value;
    document.getElementById("trainer_org").value         = document.getElementById("trainer_org"+"_r"+inRecNum).value;

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("training_sch_id").value      = '';
    document.getElementById("org_id").value      = '';
    document.getElementById("program_id").value      = '';
    document.getElementById("class_num").value      = '';
    document.getElementById("class_std").value      = '';
    document.getElementById("course_id").value      = '';
    document.getElementById("course_term").value      = '';
    document.getElementById("course_stream").value      = '';
    document.getElementById("room_num").value      = '';
    document.getElementById("period_type").value      = '';
    document.getElementById("period").value      = '';
    document.getElementById("from_date").value      = '';
    document.getElementById("to_date").value      = '';
    document.getElementById("paid_flag").value      = '';
    document.getElementById("activity_amt").value      = '';
    document.getElementById("ei_flag").value      = '';
    document.getElementById("freelancer_flag").value      = '';
    document.getElementById("trainer_org_id").value      = '';
    document.getElementById("trainer_org").value      = '';

  }
}
