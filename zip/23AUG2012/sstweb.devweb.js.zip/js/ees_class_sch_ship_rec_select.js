function EesClassSchShipRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("scholorship_id").value  = document.getElementById("scholorship_id"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("scholorship_amt").value  = document.getElementById("scholorship_amt"+"_r"+inRecNum).value; 
    document.getElementById("start_date").value  = document.getElementById("start_date"+"_r"+inRecNum).value; 
    document.getElementById("end_date").value  = document.getElementById("end_date"+"_r"+inRecNum).value; 
    document.getElementById("scholorship_status").value  = document.getElementById("scholorship_status"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("scholorship_id").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("org_id").value  = '';
    document.getElementById("scholorship_amt").value  = '';
    document.getElementById("start_date").value  = '';
    document.getElementById("end_date").value  = '';
    document.getElementById("scholorship_status").value  = '';
  }
}
