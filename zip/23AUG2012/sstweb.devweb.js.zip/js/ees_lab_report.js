function EesLabReportButtenVld()
{
  if(document.getElementById("sch_date_from").value  == ''&& document.getElementById("sch_date_to").value  == ''&&  document.getElementById("lab_id").value  == '' ) 
  {
    alert("Select Date From Date To And Lab Name To Continue ");

    window.event.returnValue = false;
  }

  else
  if(document.getElementById("sch_date_from").value  != ''&& document.getElementById("sch_date_to").value  != ''&&  document.getElementById("lab_id").value  == '' )
  {
    alert("Select Lab Name To Continue");

    window.event.returnValue = false;
  }
  else
  if(document.getElementById("sch_date_from").value  == ''|| document.getElementById("sch_date_to").value  == ''||  document.getElementById("lab_id").value  == '' )
  {
    alert("Select Date From Date To And Lab Name To Continue");

    window.event.returnValue = false;
  }



}
