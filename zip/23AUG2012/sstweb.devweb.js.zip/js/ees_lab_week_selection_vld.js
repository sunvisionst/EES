function EesLabWeekSelectionVld( inRecOnPage )
{
   var lFlag_Radio = "N";
   for(var i=1; i<= inRecOnPage; i++)
   {
      var lSelect = document.getElementById("select_radio_date"+i);
      if ( lSelect.checked )
      {
         lFlag_Radio = "Y";
         break;
         return i;
      }
      else
      {
         lFlag_Radio = "N";
      }

    }

    var lFlag_Lab_ID = "N";
    var lLabID = document.getElementById("lab_id").value;
    if(lLabID == '')
      lFlag_Lab_ID = "N";
    else
      lFlag_Lab_ID = "Y";
     
    if(lFlag_Radio == "N" && lFlag_Lab_ID == "N")
    {
       alert("Please Select any radio button and a Lab Name");
        window.event.returnValue = false;
    } 
    else
    if(lFlag_Radio == "N" && lFlag_Lab_ID == "Y")
    {
       alert("Please Select any radio button ");
        window.event.returnValue = false;
    }
    else
    if(lFlag_Radio == "Y" && lFlag_Lab_ID == "N")
    {
       alert("Please Select a Lab Name");
        window.event.returnValue = false;
    } 
}

