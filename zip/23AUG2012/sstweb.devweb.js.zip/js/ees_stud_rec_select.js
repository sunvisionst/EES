function EesStudRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value          = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("student_id").value      = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("barcode").value         = document.getElementById("barcode"+"_r"+inRecNum).value;
    document.getElementById("student_name").value    = document.getElementById("student_name"+"_r"+inRecNum).value;
    document.getElementById("father_name").value     = document.getElementById("father_name"+"_r"+inRecNum).value;
//    document.getElementById("student_ctg").value     = document.getElementById("student_ctg"+"_r"+inRecNum).value;
//    document.getElementById("dob").value             = document.getElementById("dob"+"_r"+inRecNum).value;
//    document.getElementById("doj").value             = document.getElementById("doj"+"_r"+inRecNum).value;
//    document.getElementById("dot").value             = document.getElementById("dot"+"_r"+inRecNum).value;
    document.getElementById("address_1").value       = document.getElementById("address_1"+"_r"+inRecNum).value;
    document.getElementById("address_2").value       = document.getElementById("address_2"+"_r"+inRecNum).value;
//    document.getElementById("class_std").value       = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("class_section").value   = document.getElementById("class_section"+"_r"+inRecNum).value;
//    document.getElementById("shift_code").value      = document.getElementById("shift_code"+"_r"+inRecNum).value;
//    document.getElementById("prev_class_std").value  = document.getElementById("prev_class_std"+"_r"+inRecNum).value;
//    document.getElementById("prev_section").value    = document.getElementById("prev_section"+"_r"+inRecNum).value;
//    document.getElementById("prev_shift_code").value = document.getElementById("prev_shift_code"+"_r"+inRecNum).value;
//    document.getElementById("promotion_sts").value   = document.getElementById("promotion_sts"+"_r"+inRecNum).value;
//    document.getElementById("promotion_date").value  = document.getElementById("promotion_date"+"_r"+inRecNum).value;
    document.getElementById("phone").value           = document.getElementById("phone"+"_r"+inRecNum).value;
    document.getElementById("email_id").value        = document.getElementById("email_id"+"_r"+inRecNum).value;
//    document.getElementById("student_sts").value     = document.getElementById("student_sts"+"_r"+inRecNum).value;
//    document.getElementById("student_sts_date").value= document.getElementById("student_sts_date"+"_r"+inRecNum).value;
//    document.getElementById("country").value         = document.getElementById("country"+"_r"+inRecNum).value;
//    document.getElementById("user_id").value         = document.getElementById("user_id"+"_r"+inRecNum).value;
//    document.getElementById("pswd_0").value          = document.getElementById("pswd_0"+"_r"+inRecNum).value;
    document.getElementById("class_id").value        = document.getElementById("class_id"+"_r"+inRecNum).value;
//    document.getElementById("class_num").value       = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("course_id").value       = document.getElementById("course_id"+"_r"+inRecNum).value;
//    document.getElementById("course_term").value     = document.getElementById("course_term"+"_r"+inRecNum).value;
//    document.getElementById("course_stream").value   = document.getElementById("course_stream"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("student_id").value         = '';
    document.getElementById("student_name").value       = '';
    document.getElementById("father_name").value        = '';
//    document.getElementById("student_ctg").value        = '';
//    document.getElementById("dob").value                = '';
//    document.getElementById("doj").value                = '';
//    document.getElementById("dot").value                = '';
    document.getElementById("address_1").value          = '';
    document.getElementById("address_2").value          = '';
//    document.getElementById("class_std").value          = '';
//    document.getElementById("section").value            = '';
//    document.getElementById("shift_code").value         = '';
//    document.getElementById("prev_class_std").value     = '';
//    document.getElementById("prev_section").value       = '';
//    document.getElementById("prev_shift_code").value    = '';
//    document.getElementById("promotion_sts").value      = '';
//    document.getElementById("promotion_date").value     = '';
    document.getElementById("phone").value              = '';
    document.getElementById("email_id").value           = '';
//    document.getElementById("student_sts").value        = '';
//    document.getElementById("student_sts_date").value   = '';
//    document.getElementById("country").value            = '';
//    document.getElementById("user_id").value            = '';
//    document.getElementById("pswd_0").value             = '';
    document.getElementById("class_id").value           = '';
//    document.getElementById("class_num").value          = '';
    document.getElementById("course_id").value          = ''; 
//    document.getElementById("course_term").value        = '';
//    document.getElementById("course_stream").value      = '';
    // add other fields like above
  }
}
