function EesAdmReqRecSelect( inSelectFlag, inRecNum)
{
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value      	  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id").value      	  = document.getElementById("adm_req_id"+"_r"+inRecNum).value;
    document.getElementById("application_form_num").value = document.getElementById("application_form_num"+"_r"+inRecNum).value;
    document.getElementById("applicant_id").value      	  = document.getElementById("applicant_id"+"_r"+inRecNum).value;
    document.getElementById("student_f_name").value       = document.getElementById("student_f_name"+"_r"+inRecNum).value;
    document.getElementById("student_m_name").value       = document.getElementById("student_m_name"+"_r"+inRecNum).value;
    document.getElementById("student_l_name").value       = document.getElementById("student_l_name"+"_r"+inRecNum).value;
    document.getElementById("gender_flag").value          = document.getElementById("gender_flag"+"_r"+inRecNum).value;
    document.getElementById("father_name").value          = document.getElementById("father_name"+"_r"+inRecNum).value;
    document.getElementById("mother_name").value          = document.getElementById("mother_name"+"_r"+inRecNum).value;
    document.getElementById("academic_session").value     = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("adm_academic_session").value = document.getElementById("adm_academic_session"+"_r"+inRecNum).value;
  }

  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;


    document.getElementById("org_id").value               = '';
    document.getElementById("adm_req_id").value           = '';
    document.getElementById("application_form_num").value = '';
    document.getElementById("applicant_id").value      	  = '';
    document.getElementById("student_f_name").value       = '';
    document.getElementById("student_m_name").value       = '';
    document.getElementById("student_l_name").value       = '';
    document.getElementById("gender_flag").value          = '';
    document.getElementById("father_name").value          = '';
    document.getElementById("mother_name").value          = '';
    document.getElementById("academic_session").value     = '';
    document.getElementById("adm_academic_session").value = '';
    // add other fields like above
  }
}




/*
function checkDefaultRadioButton()
{
  var lSelectRadioForCC = document.getElementById('select_radio_for_cc_4');
  if ( lSelectRadioForCC && lSelectRadioForCC.checked )
    showApproveCourse();
}


function checkDefaultRadio1()
{
  var lSelectRadioForCC = document.getElementById('select_radio_for_cc_8');
  if ( lSelectRadioForCC && lSelectRadioForCC.checked )
    showApplicationFormNo();
}
*/
