function eesHostelRoomClick(lWebApplnRoot,inMenuOption )
{
//  alert(lWebApplnRoot);
  document.form.target = "_blank";
  document.form.action = lWebApplnRoot+"/servlet/ees_room";
  document.form.action = "ees_room";
  document.form.action = document.form.action +"?menuOption="+inMenuOption;
}
