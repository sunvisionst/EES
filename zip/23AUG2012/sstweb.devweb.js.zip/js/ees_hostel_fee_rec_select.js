function EesHostelFeeRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value  = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("room_type").value  = document.getElementById("room_type"+"_r"+inRecNum).value; 
    document.getElementById("default_amt").value  = document.getElementById("default_amt"+"_r"+inRecNum).value; 
    document.getElementById("uom_type").value  = document.getElementById("uom_type"+"_r"+inRecNum).value; 
    document.getElementById("uom_qty").value  = document.getElementById("uom_qty"+"_r"+inRecNum).value; 
    document.getElementById("late_fee_flag").value  = document.getElementById("late_fee_flag"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("academic_session").value  = '';
    document.getElementById("hostel_id").value  = '';
    document.getElementById("room_type").value  = '';
    document.getElementById("default_amt").value  = '';
    document.getElementById("uom_type").value  = '';
    document.getElementById("uom_qty").value  = '';
    document.getElementById("late_fee_flag").value  = '';
  }
}
