function EesHostelBsRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value  = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("student_id").value = document.getElementById("student_id"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value   = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("roll_num").value   = document.getElementById("roll_num"+"_r"+inRecNum).value; 
    document.getElementById("in_date").value    = document.getElementById("in_date"+"_r"+inRecNum).value; 
    document.getElementById("in_time").value    = document.getElementById("in_time"+"_r"+inRecNum).value; 
    document.getElementById("out_date").value   = document.getElementById("out_date"+"_r"+inRecNum).value; 
    document.getElementById("out_time").value   = document.getElementById("out_time"+"_r"+inRecNum).value; 
    document.getElementById("num_nug").value    = document.getElementById("num_nug"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("hostel_id").value  = '';
    document.getElementById("student_id").value = '';
    document.getElementById("roll_num").value   = ''; 
    document.getElementById("class_id").value   = '';
    document.getElementById("in_date").value    = '';
    document.getElementById("in_time").value    = '';
    document.getElementById("out_date").value   = '';
    document.getElementById("out_time").value   = '';
    document.getElementById("num_nug").value    = '';
  }
}
