function EesClassRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("class_id").value       = document.getElementById("class_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value      = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value;
    document.getElementById("class_teacher").value      = document.getElementById("class_teacher"+"_r"+inRecNum).value;
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value;
    if ( document.getElementById("org_ctg").value == 'I' )
    {
      document.getElementById("course_id").value      = document.getElementById("course_id"+"_r"+inRecNum).value;
      document.getElementById("course_term").value    = document.getElementById("course_term"+"_r"+inRecNum).value;

      {
        var lWhereText='org_id = \''+document.getElementById('org_id').value+'\'';
        lWhereText= lWhereText + ' and course_id = \''+document.getElementById('course_id').value+'\'';
        invokeRefreshField( lWhereText, 'ees_course', 'get_class_id_pattern', 'CLASS_ID_PATTERN', 'class_id_pattern', 'option', 'TEXT' );
      }

      var lCourseStreamObj = document.getElementById("course_stream");
      var lCourseStreamObjMulti = document.getElementById("course_stream"+"_r"+inRecNum);
      var lCourseIdListNoStreamObj = document.getElementById('course_id_list_no_stream_str');
      if ( lCourseIdListNoStreamObj && ( lCourseIdListNoStreamObj.value.indexOf(document.getElementById("course_id").value) != -1 ) )
        document.getElementById("course_stream_query_div").style.display  = 'none';
      else
      {
        document.getElementById("course_stream_query_div").style.display  = '';
        for ( lIndex = 0; lIndex < lCourseStreamObj.options.length; lIndex++ )
          lCourseStreamObj.options[ lIndex ] = null;
        addOptVal('course_stream', lCourseStreamObjMulti.value, lCourseStreamObjMulti.value );
      }
    }
    else
    if ( document.getElementById("org_ctg").value == 'S' )
    {;
      //var lClassNumListStreamObj = document.getElementById('class_num_list_stream_str');
      //if ( lClassNumListStreamObj && ( lClassNumListStreamObj.value.indexOf(document.getElementById("class_num").value) != -1 ) )
    }
    document.getElementById("class_teacher").value      = document.getElementById("class_teacher"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("class_id").value       = '';
    document.getElementById("class_num").value      = '';
    document.getElementById("class_section").value  = '';
    if ( document.getElementById("org_ctg").value == 'I' )
    {
      document.getElementById("course_id").value      = '';
      document.getElementById("course_term").value    = '';
    }
    else
    if ( document.getElementById("org_ctg").value == 'S' )
    {;
    }
    document.getElementById("class_teacher").value      = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("class_id_pattern").value  = '';
  }
}
