function EesMessFeeRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value         = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("month").value          = document.getElementById("month"+"_r"+inRecNum).value;
    document.getElementById("year").value           = document.getElementById("year"+"_r"+inRecNum).value;
    document.getElementById("mess_id").value        = document.getElementById("mess_id"+"_r"+inRecNum).value;
    document.getElementById("hostel_id").value      = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    document.getElementById("student_id").value     = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("emp_flag").value       = document.getElementById("emp_flag"+"_r"+inRecNum).value;
    document.getElementById("num_days").value       = document.getElementById("num_days"+"_r"+inRecNum).value;
    document.getElementById("diet_charge").value    = document.getElementById("diet_charge"+"_r"+inRecNum).value;
    document.getElementById("due_date").value       = document.getElementById("due_date"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value         = '';
    document.getElementById("month").value          = '';
    document.getElementById("year").value           = '';
    document.getElementById("mess_id").value        = '';
    document.getElementById("hostel_id").value      = '';
    document.getElementById("student_id").value     = '';
    document.getElementById("emp_flag").value       = '';
    document.getElementById("num_days").value       = '';
    document.getElementById("diet_charge").value    = '';
    document.getElementById("due_date").value       = '';
    // add other fields like above
  }
}
