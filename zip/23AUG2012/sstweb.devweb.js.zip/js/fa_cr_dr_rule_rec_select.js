function FaCrDrRuleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value         = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("rule_id").value        = document.getElementById("rule_id"+"_r"+inRecNum).value;
    document.getElementById("vc_sub_type").value    = document.getElementById("vc_sub_type"+"_r"+inRecNum).value;
    document.getElementById("vc_type").value        = document.getElementById("vc_type"+"_r"+inRecNum).value;

    { 
       var lWhereText='';
       lWhereText = lWhereText + 'org_id=\''+document.getElementById("org_id").value+'\'';
       lWhereText = lWhereText + ' order by ag_id ';
       invokeRefreshField ( lWhereText, 'fa_cr_dr_rule', 'get_ag_id', 'AG_ID,AG_NAME','dr_ag_id','option', 'SELECT' ); 
    }
    document.getElementById("dr_account_num").value = document.getElementById("dr_account_num"+"_r"+inRecNum).value;
    document.getElementById("dr_ag_id").value       = document.getElementById("dr_ag_id"+"_r"+inRecNum).value;
    document.getElementById("dr_lag_id").value      = document.getElementById("dr_lag_id"+"_r"+inRecNum).value;


    { 
       var lWhereText='';
       lWhereText = lWhereText + 'org_id=\''+document.getElementById("org_id").value+'\'';
       lWhereText = lWhereText + ' order by ag_id ';
       invokeRefreshField ( lWhereText, 'fa_cr_dr_rule', 'get_ag_id', 'AG_ID,AG_NAME','cr_ag_id','option', 'SELECT' ); 
    }
    document.getElementById("cr_account_num").value = document.getElementById("cr_account_num"+"_r"+inRecNum).value;
    document.getElementById("cr_ag_id").value       = document.getElementById("cr_ag_id"+"_r"+inRecNum).value;
    document.getElementById("cr_lag_id").value      = document.getElementById("cr_lag_id"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("__field_name__").value      = '';
    //document.getElementById("org_id").value          = '';
    document.getElementById("rule_id").value         = '';
    document.getElementById("vc_sub_type").value     = '';
    document.getElementById("vc_type").value         = '';

    document.getElementById("dr_ag_id").value        = '';
    document.getElementById("dr_lag_id").value       = '';
    document.getElementById("dr_account_num").value  = '';

    document.getElementById("cr_ag_id").value        = '';
    document.getElementById("cr_lag_id").value       = '';
    document.getElementById("cr_account_num").value  = '';
    // add other fields like above
  }
}
