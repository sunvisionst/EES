function EesTnpCfrRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

   // lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
   // lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
  //  lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value            = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("followup_id").value       = document.getElementById("followup_id"+"_r"+inRecNum).value;
    document.getElementById("link_followup_id").value  = document.getElementById("link_followup_id"+"_r"+inRecNum).value;
    document.getElementById("company_id").value        = document.getElementById("company_id"+"_r"+inRecNum).value;
    document.getElementById("followup_mode").value     = document.getElementById("followup_mode"+"_r"+inRecNum).value;
    document.getElementById("followup_date").value     = document.getElementById("followup_date"+"_r"+inRecNum).value;
    document.getElementById("followup_time").value     = document.getElementById("followup_time"+"_r"+inRecNum).value;
    document.getElementById("followup_remark").value   = document.getElementById("followup_remark"+"_r"+inRecNum).value;
    document.getElementById("followup_status").value   = document.getElementById("followup_status"+"_r"+inRecNum).value;
    document.getElementById("tnp_flag").value          = document.getElementById("tnp_flag"+"_r"+inRecNum).value;
    //document.getElementById("combine_venue_ind").value    = document.getElementById("combine_venue_ind"+"_r"+inRecNum).value;
    document.getElementById("interacted_person").value= document.getElementById("interacted_person"+"_r"+inRecNum).value;
    document.getElementById("interacting_person").value= document.getElementById("interacting_person"+"_r"+inRecNum).value;
    document.getElementById("next_action_type").value  = document.getElementById("next_action_type"+"_r"+inRecNum).value;
    document.getElementById("next_action_date").value  = document.getElementById("next_action_date"+"_r"+inRecNum).value;

  }
  else
  {
   // lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
   // lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
   // lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value      = '';
    document.getElementById("followup_id").value      = '';
    document.getElementById("link_followup_id").value      = '';
    document.getElementById("company_id").value      = '';
    document.getElementById("followup_mode").value      = '';
    document.getElementById("followup_date").value      = '';
    document.getElementById("followup_time").value      = '';
    document.getElementById("followup_remark").value      = '';
    document.getElementById("tnp_flag").value      = '';
    document.getElementById("followup_status").value      = '';
    //document.getElementById("combine_venue_ind").value      = '';
    document.getElementById("interacted_person").value      = '';
    document.getElementById("interacting_person").value      = '';
    document.getElementById("next_action_type").value      = '';
    document.getElementById("next_action_date").value      = '';

    // add other fields like above
  }
}
