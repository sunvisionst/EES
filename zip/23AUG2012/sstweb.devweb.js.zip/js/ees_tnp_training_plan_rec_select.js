function EesTnpTrainingPlanRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("training_sch_id").value      = document.getElementById("training_sch_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").value      = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("seq_num").value      = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("topic_desc").value      = document.getElementById("topic_desc"+"_r"+inRecNum).value;
    document.getElementById("trainer_id").value      = document.getElementById("trainer_id"+"_r"+inRecNum).value;
    document.getElementById("trainer_name").value      = document.getElementById("trainer_name"+"_r"+inRecNum).value;
    document.getElementById("period").value      = document.getElementById("period"+"_r"+inRecNum).value;
    document.getElementById("from_date").value      = document.getElementById("from_date"+"_r"+inRecNum).value;
    document.getElementById("to_date").value      = document.getElementById("to_date"+"_r"+inRecNum).value;

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("training_sch_id").value      = '';
    document.getElementById("org_id").value      = '';
    document.getElementById("seq_num").value      = '';
    document.getElementById("topic_desc").value      = '';
    document.getElementById("trainer_id").value      = '';
    document.getElementById("trainer_name").value      = '';
    document.getElementById("period").value      = '';
    document.getElementById("from_date").value      = '';
    document.getElementById("to_date").value      = '';

  }
}
