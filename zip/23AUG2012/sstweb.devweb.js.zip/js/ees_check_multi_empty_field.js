function check_multi_empty_field( inEvt, inFieldList, inSize )
{
  var return_value = 0;
  var lFieldList   = inFieldList;
  var lFieldObjArr = new Array();

  var lFieldNameList = "";
  var lFieldObj      = "";
  var lRecNum        = 0;
  var lBrowserName   = getBrowserName();

  {
    lFieldObjArr = lFieldList.split(',');
    var lEmptyFieldlist = "";
    var lFieldObj       = "";  
    var lEmptyFieldlistArr = new Array();
    var k = 0;
    var lFlagInd = 'Y';
    for ( var lFieldNum = 0; lFieldNum < lFieldObjArr.length; lFieldNum++ )
    {
      for( lRecNum = 1; lRecNum <= inSize; lRecNum++ )
      {
        lFieldObj  = document.getElementById(lFieldObjArr[lFieldNum]+lRecNum);
        if (lFieldObj.value == "")
        {
          alert('Please Fill Empty Field(s)');

          if ( lBrowserName == 'Microsoft Internet Explorer' )
            window.event.returnValue=false;
          else
          if ( lBrowserName == 'Netscape' )
          {
            inEvt.preventDefault();
            inEvt.stopPropagation();
          }
          lFlagInd = 'N';
          break;
        }
      }
      if( lFlagInd == 'N' )
        break;
    }
  }
}

