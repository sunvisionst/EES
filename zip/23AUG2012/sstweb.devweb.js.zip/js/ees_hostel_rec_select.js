function EesHostelRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  var lLinkFloorSubmit;
  var lLinkWingSubmit;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value          = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value       = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("hostel_name").value     = document.getElementById("hostel_name"+"_r"+inRecNum).value; 
    document.getElementById("hostel_type").value     = document.getElementById("hostel_type"+"_r"+inRecNum).value; 
    document.getElementById("num_wing").value        = document.getElementById("num_wing"+"_r"+inRecNum).value; 
    document.getElementById("num_locker").value      = document.getElementById("num_locker"+"_r"+inRecNum).value; 
    document.getElementById("email_id").value        = document.getElementById("email_id"+"_r"+inRecNum).value; 
    document.getElementById("grp_email_id").value    = document.getElementById("grp_email_id"+"_r"+inRecNum).value; 
    document.getElementById("capacity_room").value   = document.getElementById("capacity_room"+"_r"+inRecNum).value; 
    document.getElementById("capacity_student").value= document.getElementById("capacity_student"+"_r"+inRecNum).value; 
    document.getElementById("location").value        = document.getElementById("location"+"_r"+inRecNum).value; 
    document.getElementById("num_floor").value       = document.getElementById("num_floor"+"_r"+inRecNum).value; 
    document.getElementById("visit_in_hours").value  = document.getElementById("visit_in_hours"+"_r"+inRecNum).value; 
    document.getElementById("visit_out_hours").value = document.getElementById("visit_out_hours"+"_r"+inRecNum).value; 
    document.getElementById("warden_emp_id").value   = document.getElementById("warden_emp_id"+"_r"+inRecNum).value; 
    document.getElementById("date_of_apt").value     = document.getElementById("date_of_apt"+"_r"+inRecNum).value; 
    document.getElementById("hostel_status").value   = document.getElementById("hostel_status"+"_r"+inRecNum).value; 


    lSubmitObj = document.getElementById("submit_finalize"); 
    if ( lSubmitObj != null ) 
    {
      if ( document.getElementById("hostel_status").value == 'F' )
        lSubmitObj.disabled = true;
      else
      if ( document.getElementById("hostel_status").value == 'O' )
        lSubmitObj.disabled = false;
      else
        lSubmitObj.disabled = true;
    }


    lLinkFloorSubmit = document.getElementById('ees_hostel_floor_href'); 
    if ( lLinkFloorSubmit != null ) 
    {
      if ( document.getElementById("hostel_status").value == 'O' )
        lLinkFloorSubmit.style.visibility="hidden";
        //window.document.form.ees_hostel_floor_href.disable=true;
      else
      if ( document.getElementById("hostel_status").value == 'F' )
        lLinkFloorSubmit.style.visibility="visible";
        //window.document.form.ees_hostel_floor_href.disable=false;
    }

    lLinkWingSubmit = document.getElementById('ees_hostel_wing_href'); 
    if ( lLinkWingSubmit != null ) 
    {
      if ( document.getElementById("hostel_status").value == 'O' )
      { 
        lLinkWingSubmit.style.visibility="hidden";
        //alert('First Finalize the Selected Hostel');
      }
      else
      if ( document.getElementById("hostel_status").value == 'F' )
      { 
        lLinkWingSubmit.style.visibility="visible";
      }
    }

  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit_finalize"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value            = '';
    document.getElementById("hostel_id").value         = '';
    document.getElementById("hostel_name").value       = '';
    document.getElementById("hostel_type").value       = '';
    document.getElementById("num_wing").value          = '';
    document.getElementById("num_locker").value        = '';
    document.getElementById("email_id").value          = '';
    document.getElementById("grp_email_id").value      = '';
    document.getElementById("capacity_room").value     = '';
    document.getElementById("capacity_student").value  = '';
    document.getElementById("location").value          = '';
    document.getElementById("num_floor").value         = '';
    document.getElementById("visit_in_hours").value    = '';
    document.getElementById("visit_out_hours").value   = '';
    document.getElementById("warden_emp_id").value     = '';
    document.getElementById("date_of_apt").value       = '';
    document.getElementById("hostel_status").value     = '';
  }
}
