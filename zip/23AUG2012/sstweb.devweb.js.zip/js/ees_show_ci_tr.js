function show_ci_tr()
{
  if( document.getElementById("next_action_type").value == 'C')
  {
    document.getElementById("in_campus_flag_tr").style.display='';
    document.getElementById("combine_venue_ind_tr").style.display='';  
  }
  else
  {
    document.getElementById("in_campus_flag_tr").style.display='none';
    document.getElementById("combine_venue_ind_tr").style.display='none';  
  }
}



