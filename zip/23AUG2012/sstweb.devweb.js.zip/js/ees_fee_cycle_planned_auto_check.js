function EesFeeCyclePlannedAutoCheck()
{
 
    alert('bbbbbbbbbbb'); 
    var lSubmitObj;
    lSubmitObj = document.getElementById("submitauto"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
}
