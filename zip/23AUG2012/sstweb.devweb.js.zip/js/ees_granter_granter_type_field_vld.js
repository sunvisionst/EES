function EesGrantergranterTypeFieldVld()
{
  var lSubmitObj;
  if ( (document.getElementById("granter_type").value  == 'G')||(document.getElementById("granter_type").value  == 'P')||(document.getElementById("granter_type").value  == 'O') )
  {

    document.getElementById("middle_name").value           = '';
    document.getElementById("last_name").value             = '';
    document.getElementById("granters_profession").value   = '';
    document.getElementById("gender_flag").value           = '';
    document.getElementById("dob").value                   = '';
  
    lSubmitObj = document.getElementById("middle_name");         if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("last_name");           if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("granters_profession"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("gender_flag");         if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("dob");                 if ( lSubmitObj != null ) lSubmitObj.disabled = true;
  }
  else
  if(document.getElementById("granter_type").value  == 'A')
  {
    lSubmitObj = document.getElementById("middle_name");         if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("last_name");           if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("granters_profession"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("gender_flag");         if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("dob");                 if ( lSubmitObj != null ) lSubmitObj.disabled = false;
  }
}
