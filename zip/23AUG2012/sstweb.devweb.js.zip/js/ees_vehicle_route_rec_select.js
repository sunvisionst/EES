function EesVehicleRouteRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

     document.getElementById("vehicle_id").value       = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
     document.getElementById("route_id").value         = document.getElementById("route_id"+"_r"+inRecNum).value;
     document.getElementById("org_id").value           = document.getElementById("org_id"+"_r"+inRecNum).value;
     document.getElementById("effective_date").value   = document.getElementById("effective_date"+"_r"+inRecNum).value;   

 // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

     document.getElementById("vehicle_id").value      = '';
     document.getElementById("route_id").value        = '';
     //document.getElementById("org_id").value          = '';
     document.getElementById("effective_date").value  = '';   


 // add other fields like above
  }
}
