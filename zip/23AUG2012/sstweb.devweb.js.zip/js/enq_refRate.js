function enq_refRate(inRecNum,inItemCode,inDBOpr)
{


  // var a = self.opener.document.form.ref_rate_2_r'"+inRecNum+"'.value';
   //alert(a);


   var lRefRate = new Array(4);
   lRefRate[0]  = "ref_rate_1_r";
   lRefRate[1]  = "ref_rate_2_r";
   lRefRate[2]  = "ref_rate_3_r";
   lRefRate[3]  = "ref_rate_4_r";
   lRefRate[4]  = "ref_rate_5_r";

   var lrefrate1 = document.getElementById(lRefRate[0]+inRecNum);
   var lrefrate2 = document.getElementById(lRefRate[1]+inRecNum);
   var lrefrate3 = document.getElementById(lRefRate[2]+inRecNum);
   var lrefrate4 = document.getElementById(lRefRate[3]+inRecNum);
   var lrefrate5 = document.getElementById(lRefRate[4]+inRecNum);
    
   var lICode = document.getElementById(inItemCode); 
   var lItemCode = "";
   if ( lICode.value != "" )
     lItemCode = lICode.value;   
   else 
     lItemCode = ''; 

   if (inDBOpr=='Query')
   {
     var Window = window.open("","","width=300,height=250,status=no,resizable=no,top=200,left=200");
 
     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<title>Reference Rate</title>");

     Window.document.write("<center>");
     Window.document.write("Item Code       : "+lItemCode);
     Window.document.write("</center>");
     Window.document.write("<br><br><center>");
     Window.document.write("Refrence rate 1 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_1_r"+inRecNum+"' id='ref_rate_1_r"+inRecNum+"' disabled='disabled' value='"+lrefrate1.value+"'/>");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 2 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_2_r"+inRecNum+"' id='ref_rate_2_r"+inRecNum+"'disabled='disabled' value='"+lrefrate2.value+"'/>");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 3 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_3_r"+inRecNum+"' id='ref_rate_3_r"+inRecNum+"'disabled='disabled' value='"+lrefrate3.value+"'/>");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 4 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_4_r"+inRecNum+"' id='ref_rate_4_r"+inRecNum+"'disabled='disabled' value='"+lrefrate4.value+"'/>");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 5 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_5_r"+inRecNum+"' id='ref_rate_5_r"+inRecNum+"'disabled='disabled' value='"+lrefrate5.value+"'/>");
     Window.document.write("<br>");
     Window.document.write("<br>");

     Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Close' onClick = 'window.close();'>");
  }

  else
  if(inDBOpr=='Update'||inDBOpr=='Insert')
  {
     var Window = open("","","width=300,height=250,status=no,resizable=no,top=200,left=200");

     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<title>Reference Rate</title>");
     Window.document.write("<center>");
     Window.document.write("Item Code       : "+lItemCode);
     Window.document.write("</center>");
     Window.document.write("<br><br><center>");
     Window.document.write("Refrence rate 1 : ");
//     Window.document.write("<input type='text' align='center' name='ref_rate_1_r"+inRecNum+"' id='ref_rate_1_r"+inRecNum+"' value='"+lrefrate1.value+"' onBlur='javascript:window.opener.a(this);'/>");
     Window.document.write("<input type='text' align='center' name='ref_rate_1_r"+inRecNum+"' id='ref_rate_1_r"+inRecNum+"' value='"+lrefrate1.value+"' onBlur='javascript:window.opener.checkAlphaNumericNumber(this);javascript:window.opener.checkLength(this,13);javascript:window.opener.checkNegativeNumber(this);';/>");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 2 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_2_r"+inRecNum+"' id='ref_rate_2_r"+inRecNum+"' value='"+lrefrate2.value+"'  onBlur='javascript:window.opener.checkAlphaNumericNumber(this);javascript:window.opener.checkLength(this,13);javascript:window.opener.checkNegativeNumber(this);'  />");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 3 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_3_r"+inRecNum+"' id='ref_rate_3_r"+inRecNum+"' value='"+lrefrate3.value+"'  onBlur='javascript:window.opener.checkAlphaNumericNumber(this);javascript:window.opener.checkLength(this,13);javascript:window.opener.checkNegativeNumber(this);'  />");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 4 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_4_r"+inRecNum+"' id='ref_rate_4_r"+inRecNum+"' value='"+lrefrate4.value+"'  onBlur='javascript:window.opener.checkAlphaNumericNumber(this);javascript:window.opener.checkLength(this,13);javascript:window.opener.checkNegativeNumber(this);' />");
     Window.document.write("<br>");
     Window.document.write("Refrence rate 5 : ");
     Window.document.write("<input type='text' align='center' name='ref_rate_5_r"+inRecNum+"' id='ref_rate_5_r"+inRecNum+"' value='"+lrefrate5.value+"'  onBlur='javascript:window.opener.checkAlphaNumericNumber(this);javascript:window.opener.checkLength(this,13);javascript:window.opener.checkNegativeNumber(this);' />");

     Window.document.write("<br>");
     Window.document.write("<br>");

     Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Submit'"
                          +"onClick = 'self.opener.document.form.ref_rate_1_r"+inRecNum+".value=ref_rate_1_r"+inRecNum+".value;"
                          +"self.opener.document.form.ref_rate_2_r"+inRecNum+".value=ref_rate_2_r"+inRecNum+".value;"
                          +"self.opener.document.form.ref_rate_3_r"+inRecNum+".value=ref_rate_3_r"+inRecNum+".value;"
                          +"self.opener.document.form.ref_rate_4_r"+inRecNum+".value=ref_rate_4_r"+inRecNum+".value;"
                          +"self.opener.document.form.ref_rate_5_r"+inRecNum+".value=ref_rate_5_r"+inRecNum+".value;"
                          +"window.close();'>");
  }
   //Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Submit'"
   //                       +"onClick = 'self.opener.document.form.ref_rate_1_r1.value=ref_rate_1_r1.value;'"
   //                       +">");
/*
   Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Submit'"
                          +"onClick =if(self.opener.document.form.ref_rate_1_r"+inRecNum+".value=='')ref_rate_1_r"+inRecNum+".value='ggggggg';else ref_rate_1_r"+inRecNum+".value='ooooooooo';"
                          +"if(self.opener.document.form.ref_rate_2_r"+inRecNum+".value=='')ref_rate_2_r"+inRecNum+".value='satish';"
                          +"if(self.opener.document.form.ref_rate_3_r"+inRecNum+".value=='')ref_rate_3_r"+inRecNum+".value='';"
                          +"if(self.opener.document.form.ref_rate_4_r"+inRecNum+".value=='')ref_rate_4_r"+inRecNum+".value='';"
                          +"if(self.opener.document.form.ref_rate_5_r"+inRecNum+".value=='')ref_rate_5_r"+inRecNum+".value='';"
                          +">");

*/
   //Window.document.write("<input type ='submit' align='right' name='submit' id = 'submit' value='Submit' onClick = 'self.opener.document.form."+lRemarkFieldNameObj.name+".value=RemarkArea.value; alert(RemarkArea.value)'>");
  

 }
