function FaAccountGroupRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("head_type").value   = document.getElementById("head_type"+"_r"+inRecNum).value;
    document.getElementById("ag_id").value       = document.getElementById("ag_id"+"_r"+inRecNum).value;
    document.getElementById("ag_name").value     = document.getElementById("ag_name"+"_r"+inRecNum).value;
    // add other fields like above

    { 
       var lWhereText='';
       lWhereText = lWhereText + 'org_id=\''+document.getElementById("org_id").value+'\'';
       lWhereText = lWhereText + ' and head_type=\''+document.getElementById("head_type").value+'\'';
       lWhereText = lWhereText + ' and ag_id in (select lag_id from fa_account_group '
                               + ' where head_type = \''+document.getElementById("head_type").value+'\''+')';
       invokeRefreshField ( lWhereText, 'fa_account_group', 'get_lag_id_on_head_type', 'AG_ID,AG_NAME','lag_id','option', 'SELECT' ); 
    }
    alert('Parent Group : '+document.getElementById("lag_id"+"_r"+inRecNum).value);
    //setTimeout('a=0;',10);
    //for ( ;; )
    //{
      //if ( document.getElementById("lag_id").value != null && document.getElementById("lag_id").value.length > 0 );
      document.getElementById("lag_id").value      = document.getElementById("lag_id"+"_r"+inRecNum).value;
    //}
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("head_type").value   = '';
    document.getElementById("ag_id").value       = '';
    document.getElementById("ag_name").value     = '';
    document.getElementById("lag_id").value      = '';

    //document.getElementById("__field_name__").value      = '';
    // add other fields like above
  }
}
