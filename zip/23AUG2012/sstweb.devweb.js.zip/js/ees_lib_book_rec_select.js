function EesLibBookRecSelect( inSelectFlag, inRecNum)
{
  var lOrgCtg = document.getElementById("org_ctg");
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("library_id").value  = document.getElementById("library_id"+"_r"+inRecNum).value;
    document.getElementById("book_id").value  = document.getElementById("book_id"+"_r"+inRecNum).value; 
    document.getElementById("book_name").value  = document.getElementById("book_name"+"_r"+inRecNum).value; 
    document.getElementById("author").value  = document.getElementById("author"+"_r"+inRecNum).value; 
    document.getElementById("co_author_1").value  = document.getElementById("co_author_1"+"_r"+inRecNum).value; 
    document.getElementById("co_author_2").value  = document.getElementById("co_author_2"+"_r"+inRecNum).value; 
    document.getElementById("publisher").value  = document.getElementById("publisher"+"_r"+inRecNum).value; 
    document.getElementById("edition").value  = document.getElementById("edition"+"_r"+inRecNum).value; 
    document.getElementById("year_of_print").value  = document.getElementById("year_of_print"+"_r"+inRecNum).value; 
    document.getElementById("isbn_code").value  = document.getElementById("isbn_code"+"_r"+inRecNum).value; 
    //document.getElementById("book_type").value  = document.getElementById("book_type"+"_r"+inRecNum).value; 
    document.getElementById("book_ctg_1").value  = document.getElementById("book_ctg_1"+"_r"+inRecNum).value; 
    //document.getElementById("book_ctg_2").value  = document.getElementById("book_ctg_2"+"_r"+inRecNum).value; 
    //document.getElementById("book_ctg_3").value  = document.getElementById("book_ctg_3"+"_r"+inRecNum).value; 
    //document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    //document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    //document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value; 
    if ( lOrgCtg && lOrgCtg.value == 'I' )
    {
      document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
      document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    }
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("book_grp_id").value  = document.getElementById("book_grp_id"+"_r"+inRecNum).value; 
    document.getElementById("book_upload_tr").style.display  = '';
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value             = '';
    document.getElementById("library_id").value           = '';
    document.getElementById("book_id").value              = '';
    document.getElementById("book_name").value            = '';
    document.getElementById("author").value               = '';
    document.getElementById("co_author_1").value          = '';
    document.getElementById("co_author_2").value          = '';
    document.getElementById("publisher").value            = '';
    document.getElementById("edition").value              = '';
    document.getElementById("year_of_print").value        = '';
    document.getElementById("isbn_code").value            = '';
    //document.getElementById("book_type").value          = '';
    document.getElementById("book_ctg_1").value           = '';
    //document.getElementById("book_ctg_2").value         = '';
    //document.getElementById("book_ctg_3").value         = '';
    //document.getElementById("class_id").value           = '';
    document.getElementById("class_num").value            = '';
    //document.getElementById("class_std").value          = '';
    //document.getElementById("class_section").value      = '';
    if ( lOrgCtg && lOrgCtg.value == 'I' )
    {
      document.getElementById("course_id").value            = '';
      document.getElementById("course_term").value          = '';
    }
    document.getElementById("course_stream").value        = '';
    document.getElementById("book_grp_id").value        = '';
    document.getElementById("book_upload_tr").style.display  = 'none';
  }
}
