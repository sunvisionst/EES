function EesLabRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  var lLabRoomDummy = '';
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    
    //-----------------------------------------------------------------
    lLabRoomDummy = ''+document.getElementById("building_id"+"_r"+inRecNum).value+''
                      +'_'
                      +''+document.getElementById("floor_num"+"_r"+inRecNum).value+''
                      +'_'
                      +''+document.getElementById("room_num"+"_r"+inRecNum).value+'';
    //-----------------------------------------------------------------

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("lab_id").value  = document.getElementById("lab_id"+"_r"+inRecNum).value; 
    document.getElementById("lab_type").value  = document.getElementById("lab_type"+"_r"+inRecNum).value; 
    document.getElementById("lab_name").value  = document.getElementById("lab_name"+"_r"+inRecNum).value; 
    document.getElementById("capacity").value  = document.getElementById("capacity"+"_r"+inRecNum).value; 
    document.getElementById("faculty_id").value  = document.getElementById("faculty_id"+"_r"+inRecNum).value; 
    document.getElementById("faculty_name").value  = document.getElementById("faculty_name"+"_r"+inRecNum).value; 
    document.getElementById("assistant_id").value  = document.getElementById("assistant_id"+"_r"+inRecNum).value; 
    document.getElementById("assistant_name").value  = document.getElementById("assistant_name"+"_r"+inRecNum).value; 
    document.getElementById("building_id").value  = document.getElementById("building_id"+"_r"+inRecNum).value; 
    document.getElementById("building_name").value  = document.getElementById("building_name"+"_r"+inRecNum).value; 
    document.getElementById("floor_num").value  = document.getElementById("floor_num"+"_r"+inRecNum).value; 
    document.getElementById("room_num").value  = document.getElementById("room_num"+"_r"+inRecNum).value; 
    document.getElementById("open_time").value  = document.getElementById("open_time"+"_r"+inRecNum).value; 
    document.getElementById("close_time").value  = document.getElementById("close_time"+"_r"+inRecNum).value; 
    document.getElementById("lab_room_dummy").value  = lLabRoomDummy; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("lab_id").value  = '';
    document.getElementById("lab_type").value  = '';
    document.getElementById("lab_name").value  = '';
    document.getElementById("capacity").value  = '';
    document.getElementById("faculty_id").value  = '';
    document.getElementById("faculty_name").value  = '';
    document.getElementById("assistant_id").value  = '';
    document.getElementById("assistant_name").value  = '';
    document.getElementById("building_id").value  = '';
    document.getElementById("building_name").value  = '';
    document.getElementById("floor_num").value  = '';
    document.getElementById("room_num").value  = '';
    document.getElementById("open_time").value  = '';
    document.getElementById("close_time").value  = '';
    document.getElementById("lab_room_dummy").value  = '';
  }
}
