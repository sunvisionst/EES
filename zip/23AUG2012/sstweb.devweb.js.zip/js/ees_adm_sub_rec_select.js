function EesAdmSubRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("academic_session").value = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("subject_code").value     = document.getElementById("subject_code"+"_r"+inRecNum).value;
    document.getElementById("description").value      = document.getElementById("description"+"_r"+inRecNum).value;
    document.getElementById("max_mark").value         = document.getElementById("max_mark"+"_r"+inRecNum).value;
    document.getElementById("min_mark").value         = document.getElementById("min_mark"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("academic_session").value = '';
    document.getElementById("description").value      = '';
    document.getElementById("subject_code").value     = '';
    document.getElementById("max_mark").value         = '0';
    document.getElementById("min_mark").value         = '0';
  }
}
