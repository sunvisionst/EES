function EesLateFeeRuleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("slab_num").value = document.getElementById("slab_num"+"_r"+inRecNum).value;
    document.getElementById("slab_start_day").value = document.getElementById("slab_start_day"+"_r"+inRecNum).value;
    document.getElementById("slab_end_day").value = document.getElementById("slab_end_day"+"_r"+inRecNum).value;
    document.getElementById("penalty").value = document.getElementById("penalty"+"_r"+inRecNum).value;
    document.getElementById("daily_penalty_ind").value = document.getElementById("daily_penalty_ind"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("slab_num").value = '';
    document.getElementById("slab_start_day").value = '';
    document.getElementById("slab_end_day").value = '';
    document.getElementById("penalty").value = '';
    document.getElementById("daily_penalty_ind").value = '';
  }
}
