function chkEnqSupplierEnquiryItemMakeDup( inRecNum )
{
  var lFound = false;
  
  for( var lRecNum = 1; lRecNum <= inRecNum; lRecNum++ )
  {
    var lItemCodeObj = document.getElementById("item_code_r"+lRecNum);
    var lMakeIdObj = document.getElementById("make_id_r"+lRecNum);
    for ( var lRecNumDup = 1; lRecNumDup <= inRecNum; lRecNumDup++ )
    {
      if (lRecNumDup != lRecNum )
      {
        var lItemCodeObjDup = document.getElementById("item_code_r"+lRecNumDup);
        var lMakeIdObjDup = document.getElementById("make_id_r"+lRecNumDup);
        if ( lItemCodeObj.value != "" && lMakeIdObj.value != "" && lItemCodeObjDup.value != "" && lMakeIdObjDup.value != "" && lItemCodeObj.value == lItemCodeObjDup.value && lMakeIdObj.value == lMakeIdObjDup.value )
        {
          alert("Item (item code and make id combination) is duplicated in row number "+lRecNum);
          lFound = true;
          break;
        }
      }
    }
    if ( lFound ) break;
  }
  if ( lFound )
  {
    lItemCodeObjDup.focus();
    window.event.returnValue = false;
  }
}

