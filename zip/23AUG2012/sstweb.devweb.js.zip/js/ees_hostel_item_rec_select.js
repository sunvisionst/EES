function EesHostelItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("hostel_id").value  = document.getElementById("hostel_id"+"_r"+inRecNum).value; 
    document.getElementById("item_code").value  = document.getElementById("item_code"+"_r"+inRecNum).value; 
    document.getElementById("std_item_flag").value  = document.getElementById("std_item_flag"+"_r"+inRecNum).value; 
    document.getElementById("od_item_flag").value  = document.getElementById("od_item_flag"+"_r"+inRecNum).value; 
    document.getElementById("os_item_flag").value  = document.getElementById("os_item_flag"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("hostel_id").value  = '';
    document.getElementById("item_code").value  = '';
    document.getElementById("std_item_flag").value  = '';
    document.getElementById("od_item_flag").value  = '';
    document.getElementById("os_item_flag").value  = '';
  }
}
