function EesAdmReqRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value; 
    document.getElementById("adm_req_id").value  = document.getElementById("adm_req_id"+"_r"+inRecNum).value; 
    document.getElementById("application_form_num").value  = document.getElementById("application_form_num"+"_r"+inRecNum).value; 
    document.getElementById("applicant_id").value  = document.getElementById("applicant_id"+"_r"+inRecNum).value; 
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value; 
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value; 
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value; 
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value; 
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value; 
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value; 
    document.getElementById("student_f_name").value  = document.getElementById("student_f_name"+"_r"+inRecNum).value; 
    document.getElementById("student_m_name").value  = document.getElementById("student_m_name"+"_r"+inRecNum).value; 
    document.getElementById("student_l_name").value  = document.getElementById("student_l_name"+"_r"+inRecNum).value; 
    document.getElementById("dob").value  = document.getElementById("dob"+"_r"+inRecNum).value; 
    document.getElementById("s_nationality").value  = document.getElementById("s_nationality"+"_r"+inRecNum).value; 
    document.getElementById("student_ctg").value  = document.getElementById("student_ctg"+"_r"+inRecNum).value; 
    document.getElementById("gender_flag").value  = document.getElementById("gender_flag"+"_r"+inRecNum).value; 
    document.getElementById("p_address_1").value  = document.getElementById("p_address_1"+"_r"+inRecNum).value; 
    document.getElementById("p_address_2").value  = document.getElementById("p_address_2"+"_r"+inRecNum).value; 
    document.getElementById("p_country").value  = document.getElementById("p_country"+"_r"+inRecNum).value; 
    document.getElementById("p_state").value  = document.getElementById("p_state"+"_r"+inRecNum).value; 
    document.getElementById("p_city").value  = document.getElementById("p_city"+"_r"+inRecNum).value; 
    document.getElementById("p_district").value  = document.getElementById("p_district"+"_r"+inRecNum).value; 
    document.getElementById("p_zip").value  = document.getElementById("p_zip"+"_r"+inRecNum).value; 
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value; 
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value; 
    document.getElementById("father_name").value  = document.getElementById("father_name"+"_r"+inRecNum).value; 
    document.getElementById("mother_name").value  = document.getElementById("mother_name"+"_r"+inRecNum).value; 
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value; 
    document.getElementById("adm_req_sts").value  = document.getElementById("adm_req_sts"+"_r"+inRecNum).value; 
    document.getElementById("adm_req_sts_date").value  = document.getElementById("adm_req_sts_date"+"_r"+inRecNum).value; 
    document.getElementById("adm_academic_session").value  = document.getElementById("adm_academic_session"+"_r"+inRecNum).value; 
    document.getElementById("online_flag").value  = document.getElementById("online_flag"+"_r"+inRecNum).value; 
    document.getElementById("admission_mode").value  = document.getElementById("admission_mode"+"_r"+inRecNum).value; 
    document.getElementById("university_rank_1").value  = document.getElementById("university_rank_1"+"_r"+inRecNum).value; 
    document.getElementById("university_rank_2").value  = document.getElementById("university_rank_2"+"_r"+inRecNum).value; 
    document.getElementById("prev_mark_percent").value  = document.getElementById("prev_mark_percent"+"_r"+inRecNum).value; 
    document.getElementById("domecile_ind").value  = document.getElementById("domecile_ind"+"_r"+inRecNum).value; 
    document.getElementById("org_transport_req_ind").value  = document.getElementById("org_transport_req_ind"+"_r"+inRecNum).value; 
    document.getElementById("org_hostel_req_ind").value  = document.getElementById("org_hostel_req_ind"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value  = '';
    document.getElementById("adm_req_id").value  = '';
    document.getElementById("application_form_num").value  = '';
    document.getElementById("applicant_id").value  = '';
    document.getElementById("class_id").value  = '';
    document.getElementById("class_num").value  = '';
    document.getElementById("class_std").value  = '';
    document.getElementById("course_id").value  = '';
    document.getElementById("course_term").value  = '';
    document.getElementById("course_stream").value  = '';
    document.getElementById("student_f_name").value  = '';
    document.getElementById("student_m_name").value  = '';
    document.getElementById("student_l_name").value  = '';
    document.getElementById("dob").value  = '';
    document.getElementById("s_nationality").value  = '';
    document.getElementById("student_ctg").value  = '';
    document.getElementById("gender_flag").value  = '';
    document.getElementById("p_address_1").value  = '';
    document.getElementById("p_address_2").value  = '';
    document.getElementById("p_country").value  = '';
    document.getElementById("p_state").value  = '';
    document.getElementById("p_city").value  = '';
    document.getElementById("p_district").value  = '';
    document.getElementById("p_zip").value  = '';
    document.getElementById("phone_list").value  = '';
    document.getElementById("email_list").value  = '';
    document.getElementById("father_name").value  = '';
    document.getElementById("mother_name").value  = '';
    document.getElementById("academic_session").value  = '';
    document.getElementById("adm_req_sts").value  = '';
    document.getElementById("adm_req_sts_date").value  = '';
    document.getElementById("adm_academic_session").value  = '';
    document.getElementById("online_flag").value  = '';
    document.getElementById("admission_mode").value  = '';
    document.getElementById("university_rank_1").value  = '';
    document.getElementById("university_rank_2").value  = '';
    document.getElementById("prev_mark_percent").value  = '';
    document.getElementById("domecile_ind").value  = '';
    document.getElementById("org_transport_req_ind").value  = '';
    document.getElementById("org_hostel_req_ind").value  = '';
  }
}
