function EesHostelRoomItemRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

//    document.getElementById("org_id").value      = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("hostel_id").value      = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    document.getElementById("room_num").value      = document.getElementById("item_id"+"_r"+inRecNum).value;
    document.getElementById("item_id").value      = document.getElementById("item_id"+"_r"+inRecNum).value;
    document.getElementById("bed_num").value      = document.getElementById("bed_num"+"_r"+inRecNum).value;         
   
    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

  //  document.getElementById("org_id").value      = '';
    document.getElementById("hostel_id").value      = '';
    document.getElementById("room_num").value      = '';
    document.getElementById("item_id").value      = '';
    document.getElementById("bed_num").value      = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
