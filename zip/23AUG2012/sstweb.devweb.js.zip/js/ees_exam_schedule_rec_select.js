function EesExamScheduleRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   document.getElementById("exam_id").value          = document.getElementById("exam_id"+"_r"+inRecNum).value;
   document.getElementById("class_num").value        = document.getElementById("class_num"+"_r"+inRecNum).value;
   document.getElementById("class_section").value    = document.getElementById("class_section"+"_r"+inRecNum).value;
   document.getElementById("subject_code").value     = document.getElementById("subject_code"+"_r"+inRecNum).value;
   document.getElementById("org_id").value           = document.getElementById("org_id"+"_r"+inRecNum).value;
   document.getElementById("class_std").value        = document.getElementById("class_std"+"_r"+inRecNum).value;
   document.getElementById("course_id").value        = document.getElementById("course_id"+"_r"+inRecNum).value;
   document.getElementById("course_term").value      = document.getElementById("course_term"+"_r"+inRecNum).value;
   document.getElementById("exam_date").value        = document.getElementById("exam_date"+"_r"+inRecNum).value;
    document.getElementById("exam_start_time").value = document.getElementById("exam_start_time"+"_r"+inRecNum).value;
    document.getElementById("exam_end_time").value   = document.getElementById("exam_end_time"+"_r"+inRecNum).value;
   document.getElementById("status").value           = document.getElementById("status"+"_r"+inRecNum).value;
   document.getElementById("room_num").value         = document.getElementById("room_num"+"_r"+inRecNum).value;
   document.getElementById("room_incharge_1").value  = document.getElementById("room_incharge_1"+"_r"+inRecNum).value;
   document.getElementById("room_incharge_2").value  = document.getElementById("room_incharge_2"+"_r"+inRecNum).value;
   document.getElementById("room_incharge_3").value  = document.getElementById("room_incharge_3"+"_r"+inRecNum).value;
   document.getElementById("room_incharge_4").value  = document.getElementById("room_incharge_4"+"_r"+inRecNum).value;
   document.getElementById("room_incharge_5").value  = document.getElementById("room_incharge_5"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("exam_id").value           = '';
    document.getElementById("class_num").value         = '';
    document.getElementById("class_section").value     = '';
    document.getElementById("subject_code").value      = '';
    document.getElementById("org_id").value            = '';
    document.getElementById("class_std").value         = '';
    document.getElementById("course_id").value         = '';
    document.getElementById("course_term").value       = ''; 
    document.getElementById("exam_date").value         = '';
    document.getElementById("exam_start_time").value   = '';
    document.getElementById("exam_end_time").value     = '';
    document.getElementById("status").value            = ''; 
    document.getElementById("room_num").value          = '';
    document.getElementById("room_incharge_1").value   = '';
    document.getElementById("room_incharge_2").value   = '';
    document.getElementById("room_incharge_3").value   = '';
    document.getElementById("room_incharge_4").value   = '';
    document.getElementById("room_incharge_5").value   = '';
    // add other fields like above
  }
}
