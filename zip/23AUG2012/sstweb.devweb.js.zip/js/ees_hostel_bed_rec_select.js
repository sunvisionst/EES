function EesHostelBedRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    //document.getElementById("org_id").value        = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("hostel_id").value     = document.getElementById("hostel_id"+"_r"+inRecNum).value;
    document.getElementById("room_num").value      = document.getElementById("room_num"+"_r"+inRecNum).value;
    document.getElementById("bed_num").value       = document.getElementById("bed_num"+"_r"+inRecNum).value;
    document.getElementById("room_type").value     = document.getElementById("room_type"+"_r"+inRecNum).value;
    document.getElementById("bed_status").value    = document.getElementById("bed_status"+"_r"+inRecNum).value;
    document.getElementById("student_id").value    = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("allotted_date").value = document.getElementById("allotted_date"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  if ( inSelectFlag == 'N' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    //document.getElementById("org_id").value         = '';
    document.getElementById("hostel_id").value      = '';
    document.getElementById("room_num").value       = '';
    document.getElementById("bed_num").value        = '';
    document.getElementById("room_type").value      = '';
    document.getElementById("bed_status").value     = '';
    document.getElementById("student_id").value     = '';
    document.getElementById("allotted_date").value  = '';
    // add other fields like above
  }
}
