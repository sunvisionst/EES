function EesStudentTripRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

   document.getElementById("student_id").value      = document.getElementById("student_id"+"_r"+inRecNum).value;
   document.getElementById("trip_id").value         = document.getElementById("trip_id"+"_r"+inRecNum).value;
   document.getElementById("trip_num").value        = document.getElementById("trip_num"+"_r"+inRecNum).value;
   document.getElementById("stoppage_id").value     = document.getElementById("stoppage_id"+"_r"+inRecNum).value;
   document.getElementById("vehicle_id").value      = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
  // document.getElementById("direction_flag").value  = document.getElementById("direction_flag"+"_r"+inRecNum).value;   




 // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

   document.getElementById("student_id").value      = '';
   document.getElementById("trip_id").value         = '';
   document.getElementById("trip_num").value        = '';
   document.getElementById("stoppage_id").value     = '';
   document.getElementById("vehicle_id").value      = '';
   //document.getElementById("direction_flag").value  = '';  
  // add other fields like above
  }
}
