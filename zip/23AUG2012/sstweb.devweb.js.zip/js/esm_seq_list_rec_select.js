function lSEQ_LIST_ValuesRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("seq_name").value      = document.getElementById("seq_name"+"_r"+inRecNum).value;
    document.getElementById("start_value").value   = document.getElementById("start_value"+"_r"+inRecNum).value;
    document.getElementById("end_value").value     = document.getElementById("end_value"+"_r"+inRecNum).value;
    document.getElementById("current_value").value = document.getElementById("current_value"+"_r"+inRecNum).value;
    document.getElementById("next_value").value    = document.getElementById("next_value"+"_r"+inRecNum).value;
    document.getElementById("cycle_ind").value     = document.getElementById("cycle_ind"+"_r"+inRecNum).value;

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = document.getElementById("__field_name__"+"_r"+inRecNum).value;

    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("seq_name").value      = '';
    document.getElementById("start_value").value   = '';
    document.getElementById("end_value").value     = '';
    document.getElementById("current_value").value = '';
    document.getElementById("next_value").value    = '';
    document.getElementById("cycle_ind").value     = '';

    //OR 

    //lSubmitObj = document.getElementById("__field_name__"); 
    //if ( lSubmitObj != null ) lSubmitObj.value = '';

    // add other fields like above
  }
}
