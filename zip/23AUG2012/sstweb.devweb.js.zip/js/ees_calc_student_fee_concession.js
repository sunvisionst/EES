function calcConcession( inFeeHead, inStudentCtgObj, inDefaultAmt )
{
  var amount =0 ;
  for (var lRecNumConcession = 0; lRecNumConcession < lEesFeeConcessionTabObjJSArr.length; lRecNumConcession++)
  {
    //alert(inFeeHead + lEesFeeConcessionTabObjJSArr[lRecNumConcession].fee_head );
    if ( (inFeeHead == lEesFeeConcessionTabObjJSArr[lRecNumConcession].fee_head )
      && ( lEesFeeConcessionTabObjJSArr[lRecNumConcession].student_ctg == inStudentCtgObj.value) )
    {
      amount = (inDefaultAmt * (lEesFeeConcessionTabObjJSArr[lRecNumConcession].discount_percent))/100;
      break;
    }
  }
  return amount;
}
