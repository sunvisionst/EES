function setRemarkHidField(inRecNum,inItemCode,inDBOpr)
{


  // var a = self.opener.document.form.ref_rate_2_r'"+inRecNum+"'.value';
   //alert(a);


   var lRemarkFldArr = new Array();

   for ( var lRecNum = 0; lRecNum < 5; lRecNum++ )
    lRemarkFldArr[lRecNum]  = "item_remark_r"+(lRecNum+1);
   var lRemark = document.getElementById(lRemarkFldArr[inRecNum-1]);

   var lRemarkFldOnJspArr = new Array();

   for ( var lRecNum = 0; lRecNum < 5; lRecNum++ )
    lRemarkFldOnJspArr[lRecNum]  = "remark_r"+(lRecNum+1);
   var lRemarkFldOnJsp = document.getElementById(lRemarkFldOnJspArr[inRecNum-1]);

   var lICode = document.getElementById(inItemCode); 
   var lItemCode = "";
   if ( lICode.value != "" )
     lItemCode = lICode.value;   
   else 
     lItemCode = ''; 

   if ( inDBOpr=='Update' )
   {
     var Window = window.open("","","width=300,height=300,status=no,resizable=no,top=200,left=200");
     Window.opener =  self;
     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<title>Remark</title>");
     Window.document.write("<center>");

     Window.document.write("<center>");
     Window.document.write("Component      : "+lItemCode);
     Window.document.write("</center>");
     Window.document.write("<fieldset style='border-width: 1px; border-style: solid; border-color: Black' >");
     Window.document.write("<legend>Remark</legend>");

     Window.document.write("<table width='100%'>");
     Window.document.write("<tr><td>");
//     Window.document.write("<input type='text' align='center' name='ref_rate_1_r"+inRecNum+"' id='ref_rate_1_r"+inRecNum+"' value='"+lrefrate1.value+"' onBlur='javascript:window.opener.a(this);'/>");
     //Window.document.write("<textarea rows='10' cols='32'  name='item_remark_r"+inRecNum+"' id='item_remark_r"+inRecNum+"' value='"+lRemark.value+"' /></textarea> ");
     Window.document.write("<textarea rows='10' cols='32'  name='item_remark_r"+inRecNum+"' id='item_remark_r"+inRecNum+"' disabled='disabled'/>"+lRemark.value+"</textarea> ");

     Window.document.write("</tr></td>");
     Window.document.write("</table>");
     Window.document.write("</fieldset>");

     Window.document.write("<br>");
     Window.document.write("<br>");
     Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Close'"
                    +"onClick = 'window.close();'>");

  }

  else
  //if(inDBOpr=='Update'||inDBOpr=='Insert')
  if( inDBOpr=='Insert' )
  {
     var Window = open("","","width=300,height=300,status=no,resizable=no,top=200,left=200");

     Window.document.bgColor = "lightsteelblue";
     Window.document.write("<title>Remark</title>");
     Window.document.write("<center>");
     Window.document.write("Component      : "+lItemCode);
     Window.document.write("</center>");
     Window.document.write("<center>");
     Window.document.write("<fieldset style='border-width: 1px; border-style: solid; border-color: Black' >");
     Window.document.write("<legend>Remark</legend>");

     Window.document.write("<table width='100%'>");
     Window.document.write("<tr><td>");
//     Window.document.write("<input type='text' align='center' name='ref_rate_1_r"+inRecNum+"' id='ref_rate_1_r"+inRecNum+"' value='"+lrefrate1.value+"' onBlur='javascript:window.opener.a(this);'/>");
//     Window.document.write("<textarea rows='10' cols='32'  name='item_remark_r"+inRecNum+"' id='item_remark_r"+inRecNum+"' value='"+lRemark.value+"' onBlur='javascript:window.opener.vldFieldDBSizeThisItemRemark(\"EnqCustomerEnquiryItem\",this);'/></textarea> ");
    
     Window.document.write("<textarea rows='10' cols='32'  name='item_remark_r"+inRecNum+"' id='item_remark_r"+inRecNum+"' value='' onBlur='javascript:window.opener.vldFieldDBSizeThisItemRemark(\"EnqCustomerEnquiryItem\",this);'/>"+lRemarkFldOnJsp.value+lRemark.value+"</textarea> ");
//     Window.document.write("<textarea rows='10' cols='32'  name='item_remark_r"+inRecNum+"' id='item_remark_r"+inRecNum+"' value='' onBlur='javascript:window.opener.vldFieldDBSizeThisItemRemark(\"EnqCustomerEnquiryItem\",this);'/>"+lRemark.value+"</textarea> ");
     Window.document.write("</tr></td>");
     Window.document.write("</table>");
     Window.document.write("</fieldset>");

     Window.document.write("<br>");
     Window.document.write("<br>");
     Window.document.write("<input type ='submit' align='center' name='submit' id='submit' value='Submit'"
                    +"onClick = 'self.opener.document.form.item_remark_r"+inRecNum+".value=item_remark_r"+inRecNum+".value;"
                    //+" self.opener.document.form.remark_r"+inRecNum+".value=item_remark_r"+inRecNum+".value;"
                    +"window.close();'>");
     Window.document.write("</center>");
  }
}
