#   #!/usr/bin/ksh/
#/bin/ksh/

export OS_NAME=LINUX

CONFIG_FILE_PATH=/home/plagzb/sstweb/devweb/config/
export CONFIG_FILE_PATH

CONFIG_FILE=jdbc.database.driver.config
export CONFIG_FILE

DB_USR=oraclepla
export DB_USR

PRODUCT_PARAM_CONFIG_FILE_PATH=/home/esmma/sstweb/devweb/config/
export PRODUCT_PARAM_CONFIG_FILE_PATH

PRODUCT_PARAM_CONFIG_FILE=esm.param.config
export PRODUCT_PARAM_CONFIG_FILE

java HrEmpShiftRotaDrv $CONFIG_FILE_PATH \
                       $CONFIG_FILE \
                       $DB_USR \
                       $PRODUCT_PARAM_CONFIG_FILE_PATH \
                       $PRODUCT_PARAM_CONFIG_FILE \
                       $SAL_PREP_RUN_DATE \



