#!/bin/ksh

########################################################
command_usage()
{
  echo "Usage :"
  echo $0" <host ip> <database name> <destination dir>"
}

if [ $# -ne 3 ]
then
  echo 'Wrong number of parameters'
  command_usage
  exit
else
  CMD_PARAM1=$1
  CMD_PARAM2=$2
  CMD_PARAM3=$3
fi

echo ${CMD_PARAM1}
echo ${CMD_PARAM2}
echo ${CMD_PARAM3}

#######################################################

#export HOST=`hostname -i`
export HOST=${CMD_PARAM1}
export PG_HOME=/usr
#export PG_HOME=/home/sstpostgre/pg8.1.2
export PG_SERVER_PORT=5432
export PG_DUMP=pg_dump
export PG_DB_OWNER=postgres
export BACKUP_DEST=${CMD_PARAM3}
export BACKUP_FILE=${CMD_PARAM2}"_"`date '+%Y%m%d%H%M%S'`
export PG_DB=${CMD_PARAM2}


${PG_HOME}/bin/${PG_DUMP} -i -h ${HOST} -p ${PG_SERVER_PORT} -U ${PG_DB_OWNER} -F c -b -o -v -f "${BACKUP_DEST}/${BACKUP_FILE}" ${PG_DB}
STATUS=$?

TEMP_DIR=/tmp
if [ ${STATUS} = 0 ]
then
  echo "0" > ${TEMP_DIR}/${0}_status
else
  echo "-1" > ${TEMP_DIR}/${0}_status
fi
