#!/bin/ksh

export PGDATA=/var/lib/pgsql/data

#LD_LIBRARY_PATH=/usr/lib/pgsql/lib
#export LD_LIBRARY_PATH

#export PATH=${PATH}:/usr/bin/bin

#MANPATH=/opt/sstpostgres/pg8.3/man:$MANPATH
#export MANPATH

