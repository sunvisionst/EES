#!/bin/ksh

export PGDATA=/opt/sstpostgres/data

LD_LIBRARY_PATH=/opt/sstpostgres/pg8.3/lib
export LD_LIBRARY_PATH

export PATH=${PATH}:/opt/sstpostgres/pg8.3/bin

MANPATH=/opt/sstpostgres/pg8.3/man:$MANPATH
export MANPATH
