# .bashrc

# User specific aliases and functions

# Source global definitions
#if [ -f /etc/bashrc ]; then
#	. /etc/bashrc
#fi

######################################################################################
# Oracle 9i DB R2
######################################################################################
#export ORACLE_BASE=/home/ora9
#export ORACLE_HOME=/home/ora9/product/9.2
#export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/Apache/Apache/bin:$PATH
#export PATH=$HOME/product/9.2/jdk/bin:$PATH
#export PATH=$HOME/TOra/tora-1.3.9.2:$PATH
#export ORACLE_OWNER=ora9
#export ORACLE_SID=KRITI
#export ORACLE_TERM=xterm

#export LD_ASSUME_KERNEL=2.4.1
#export THREADS_FLAG=native
#LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib
#LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/jdk/jre/lib/i386/classic
#LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/jdk/jre/lib/i386/native_threads
#LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/jdk/jre/lib/i386
#export LD_LIBRARY_PATH
# Oracle 9i DB R2-Ends
######################################################################################

######################################################################################
# Java Env Vars-starts
. /home/eesma/sstweb/devweb/shellscript/sst_j2ee_env_var.sh
# Java Env Vars-ends
######################################################################################


######################################################################################
#Oracle jar file-starts
ORACLE_CLASSPATH=$JAVA_USER_HOME/sst_lib/oracle9.2/classes12.jar
ORACLE_CLASSPATH=$ORACLE_CLASSPATH:$JAVA_USER_HOME/sst_lib/oracle9.2/classes12.jar
ORACLE_CLASSPATH=$ORACLE_CLASSPATH:$JAVA_USER_HOME/sst_lib/oracle9.2/nls_charset12.jar
ORACLE_CLASSPATH=$ORACLE_CLASSPATH:$JAVA_USER_HOME/sst_lib/oracle9.2/ojdbc14.jar
export CLASSPATH=$CLASSPATH:$ORACLE_CLASSPATH
#Oracle jar file-starts
######################################################################################

######################################################################################
#Postgres jar file-starts
export JAVAPOSTGRESQL_CLASSPATH=$JAVA_USER_HOME/sst_lib/postgres/914/postgresql-9.1-902.jdbc3.jar
#export JAVAPOSTGRESQL_CLASSPATH=$JAVA_USER_HOME/sst_lib/postgres/814/postgresql-8.1-412.jdbc3.jar
#export JAVAPOSTGRESQL_CLASSPATH=/var/lib/tomcat5/common/lib/postgresql-8.1-412.jdbc3.jar
#export JAVAPOSTGRESQL_CLASSPATH=/var/lib/tomcat5/common/lib/postgresql-8.1-405.jdbc2.jar
#export JAVAPOSTGRESQL_CLASSPATH=/var/lib/tomcat5/common/lib/postgresql-8.1-405.jdbc2ee.jar
export CLASSPATH=$CLASSPATH:$JAVAPOSTGRESQL_CLASSPATH
#Postgres jar file-ends
######################################################################################

######################################################################################
#MYSQL jar file-starts
export JAVAMYSQL_CLASSPATH=$JAVA_USER_HOME/sst_lib/mysql/517/mysql-connector-java-5.1.7-bin.jar
export CLASSPATH=$CLASSPATH:$JAVAMYSQL_CLASSPATH
#MYSQL jar file-ends
######################################################################################

######################################################################################
#Javamail jar file-starts
JAVAMAIL_CLASSPATH=
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/jaf-1.0.2/activation.jar
#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/dnsjava-2.0.1.jar
#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/sendmail.jar


#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/jm/javamail-1.4ea/lib/imap.jar
#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/jm/javamail-1.4ea/lib/mailapi.jar
#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/jm/javamail-1.4ea/lib/pop3.jar
#JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/jm/javamail-1.4ea/lib/smtp.jar

JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/dsn.jar
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/imap.jar
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/mailapi.jar
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/mail.jar
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/pop3.jar
JAVAMAIL_CLASSPATH=$JAVAMAIL_CLASSPATH:$JAVA_USER_HOME/sst_lib/javamail/javamail-1.4.1/smtp.jar
export CLASSPATH=$CLASSPATH:$JAVAMAIL_CLASSPATH
#Javamail jar files-ends
######################################################################################

######################################################################################
#Javamail jar file-starts
FU_CLASSPATH=$JAVA_USER_HOME/sst_lib/fu/commons-fileupload-1.2.jar
export CLASSPATH=$CLASSPATH:$FU_CLASSPATH
#Javamail jar file-starts
######################################################################################

######################################################################################
#Jersey jar file-starts
JERSEY_CLASSPATH=$JAVA_USER_HOME/sst_lib/jersey1.4/lib/asm-3.1.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jackson-core-asl-1.5.5.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jackson-jaxrs-1.5.5.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jackson-mapper-asl-1.5.5.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jackson-xc-1.5.5.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jersey-client-1.4.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jersey-core-1.4.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jersey-json-1.4.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jersey-server-1.4.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jettison-1.1.jar
JERSEY_CLASSPATH=$JERSEY_CLASSPATH:$JAVA_USER_HOME/sst_lib/jersey1.4/lib/jsr311-api-1.1.1.jar
export CLASSPATH=$CLASSPATH:$JERSEY_CLASSPATH
#Jersey jar file-ends
######################################################################################

######################################################################################
#Hibernate jar file-starts
HIBERNATE_CLASSPATH=$JAVA_USER_HOME/sst_lib/hibernate/hibernate3.jar
export CLASSPATH=$CLASSPATH:$HIBERNATE_CLASSPATH
#Hibernate jar file-ends
######################################################################################

######################################################################################
# Itext Jar File-starts
#PDF_CLASSPATH=$JAVA_USER_HOME/sst_lib/pdf/itext/itext-1.4.jar
PDF_CLASSPATH=$JAVA_USER_HOME/sst_lib/pdf/itext/iText-2.0.7.jar
export CLASSPATH=$CLASSPATH:$PDF_CLASSPATH
# Itext Jar File-ends
######################################################################################

######################################################################################
# FOP Jar Files-starts
PDF_CLASSPATH=$JAVA_USER_HOME/sst_lib/pdf/fop/fop.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/batik-all-1.6.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/xalan-2.7.0.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/avalon-framework-4.2.0.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/commons-logging-1.0.4.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/commons-io-1.1.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/xercesImpl-2.7.1.jar
PDF_CLASSPATH=$PDF_CLASSPATH:$JAVA_USER_HOME/sst_lib/pdf/fop/xml-apis-1.3.02.jar
export CLASSPATH=$CLASSPATH:$PDF_CLASSPATH
# FOP Jar Files-ends
######################################################################################

######################################################################################
#Execlsheet vars-starts
#EXECL_CLASSPATH=$JAVA_USER_HOME/sst_lib/poi/poi-3.0-alpha2-20060616.jar
#EXECL_CLASSPATH=$EXCEL_CLASSPATH:$JAVA_USER_HOME/sst_lib/poi/poi-contrib-3.0-alpha2-20060616.jar
#EXECL_CLASSPATH=$EXCEL_CLASSPATH:$JAVA_USER_HOME/sst_lib/poi/poi-scratchpad-3.0-alpha2-20060616.jar
EXECL_CLASSPATH=$JAVA_USER_HOME/sst_lib/poi/poi-3.2-FINAL-20081019.jar
#EXECL_CLASSPATH=$EXCEL_CLASSPATH:$JAVA_USER_HOME/sst_lib/poi/poi-contrib-3.2-FINAL-20081019.jar
#EXECL_CLASSPATH=$EXCEL_CLASSPATH:$JAVA_USER_HOME/sst_lib/poi/poi-scratchpad-3.2-FINAL-20081019.jar
export CLASSPATH=$CLASSPATH:$EXECL_CLASSPATH
#Execlsheet vars-ends
######################################################################################


######################################################################################
#JFREE_CLASSPATH=$JAVA_USER_HOME/sst_lib/jfree/log4j-1.2.12.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jcommon-1.0.0.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/gnujaxp-1.0.0.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/junit-3.8.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.0.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/crimson-1.1.3.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/cewolf-1.0.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-xml-1.6.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-util-1.6.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-svggen-1.6.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-dom-1.6.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-awt-util-1.6.jar
#JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/batik-awt-util-1.6.jar
JFREE_CLASSPATH=$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/jfreechart-1.0.11.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/jfreechart-1.0.11-experimental.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/swtgraphics2d.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/jfreechart-1.0.11-swt.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/jcommon-1.0.14.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/junit.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/iText-2.1.3.jar
JFREE_CLASSPATH=$JFREE_CLASSPATH:$JAVA_USER_HOME/sst_lib/jfree/jfreechart-1.0.11/lib/gnujaxp.jar
export CLASSPATH=$CLASSPATH:$JFREE_CLASSPATH
######################################################################################

######################################################################################
export HOST=server.sunvisionst.com
#export HOST=sstdel10056
######################################################################################

######################################################################################
source ${SST_SCRIPT_HOME}/sys_cmd.alias
source ${SST_SCRIPT_HOME}/sst_ees_app_env_var.sh
export SST_SCRIPT_HOME1=/home/eesma/sstjava/dev/sstsrv/osshellscript/
######################################################################################
