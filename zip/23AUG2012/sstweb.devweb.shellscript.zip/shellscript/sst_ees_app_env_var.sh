#!/bin/ksh


#ADMISSION ENV VARS-STARTS
#export ST_CAP_ATTR="Intelliactual Academic,Fluent and Logical Communication,Written,Ability to Work Hard,Perseverance,Leadership Creativity,Warmth Social Skill" # NOW OBSO
#export HEALTH_PROBLEM="Dysiexia,Deaf,Hearing Impairment,Blind ,Partially Sighted,Wheelchair User,Mobility Difficulties,Need Personal Care Support,Mental Health Difficulties,Unseen Disability(Diabetes,Asthma),Two or More of the Above Disabilities,Disability Not Listed Above" # NOW OBSO
#export ADM_REG_ENCLOSURE="Highschool MarkSheet,Highschool Certificate,Intermediate Marksheet,Intermediate Certificate,Character Certificate,Migration/Tc,Degree(In case Of PG),Marksheet of Gradution" # NOW OBSO
#export ADM_ENQ_COURSE_ID_LIST="10,12,18,15,20" # CAN BE REMOVED NOW BCOZ ADDED IN GN_TYPE AS LEVELID
#export ADM_ENQ_COURSE_DESC_LIST="10th,12th,Diploma,Graduation,Post Graduation" # CAN BE REMOVED NOW BCOZ ADDED IN GN_TYPE AS LEVELID
#export COURSE_DISPLAY="10th,12th,Diploma,Graduation,Post Grad"
#ADMISSION ENV VARS-ENDS


#FEE ENV VARS-STARTS
export ADMISSION_CYCLE_ID=99
export HOSTEL_CYCLE_ID=98
export TRANSPORT_CYCLE_ID=97
export EXAM_CYCLE_ID=96
export FINE_CYCLE_ID=95
#FEE ENV VARS-ENDS

#ACADEMIC ENV VARS-STARTS
export NUM_OF_SUB_CHOICE=10
#ACADEMIC ENV VARS-ENDS

# PAYROLL PROCESS ENV VARS-STARTS
export ESI_MONTH_LIST_1=1,2,3,4,5,6
export ESI_MONTH_LIST_2=7,8,9,10,11,12

export SALARY_DB_FLAG=Y
export SALARY_DEBUG_FLAG=Y
# PAYROLL PROCESS ENV VARS-ENDS

########################################################
export APP_HOME=/home/eesma/
export APP_MIDDLE_PATH=/sstweb/devweb/
export APP_CONFIG_PATH=config
########################################################


# APPLICATION CFG ENV VARS-STARTS
# DATABASE PARAMETER VALUES
#export DB_HOST_IP=172.30.10.1
export DB_HOST_IP=216.45.55.184
export DB_HOST_IP=96.44.132.147
export DB_NAME=sst_eesma_test
export DB_DRIVER_NAME=org.postgresql.Driver
export DB_URL=jdbc:postgresql
export DB_USER_NAME=rajesh
export DB_USER_PSWD=Linux789

#export DB_DRIVER_NAME=com.mysql.jdbc.Driver
#export DB_URL=jdbc:mysql
#export DB_USER_NAME=root
#export DB_USER_PSWD=mysql

# APPLICATION HOST REAL AND PUBLIC IP
#export HOST_RIP=172.30.10.1
export HOST_RIP=216.45.55.184
export HOST_RIP=96.44.132.147
#export HOST_PIP=122.160.74.88
export HOST_PIP=216.45.55.184
export HOST_PIP=96.44.132.147

#WEB_APPLN_SERVER_PORT is same as URL_SERVER_PORT in ees_login.java
export WEB_APPLN_SERVER_PORT=8888
export WEB_APPLN_ROOT=eesmasstweb

#============================================
export GEO_TRC_URL=http://www.ipmango.com/api.php?ip=
export HOSTED_APPLN_SRV_IP=216.45.55.184
export HOSTED_APPLN_SRV_IP=96.44.132.147
#export PROXY_HOST_IP=172.30.10.29
#export PROXY_HOST_PORT=3128
#============================================

#============================================
#PORTAL_DOMAIN is same as URL_SERVER_NAME in ees_login.java
export PORTAL_DOMAIN=www.shiksharth.com
export MYWEBSITE=/mw/
export MYPROFILE=/mp/
#============================================
# APPLICATION CFG ENV VARS-ENDS

#============================================
# REPORT PROCESS ENV VARS-STARTS
export HTTP_INITIAL_URL="http://"$HOST_RIP":8888/eesmasstweb"
export HTTPS_INITIAL_URL="https://"$HOST_RIP":8443/eesmasstweb"

export HTTP_INITIAL_URL_APACHE="http://"$HOST_RIP"/eesmasstweb"
export HTTPS_INITIAL_URL_APACHE="https://"$HOST_RIP"/eesmasstweb"
# REPORT PROCESS ENV VARS-ENDS

# APPLN DEBUG FLAG -STARTS
export DEBUG_FLAG_REQ_PARAM=N
export DEBUG_FLAG_QRY_STR=N
# APPLN DEBUG FLAG -ENDS
#============================================

#============================================
# GURUTYPE ENV VARs
# GURU_TYPE_PROVIDER_N_EXPERT : keeps guru/feature code of provider and expert currently applicable
export GURU_TYPE_PROVIDER_N_EXPERT=112,113,114,115,116,122,123,126,127,128
# GURU_TYPE_VOLUNTEER : keeps code of SST features for which volunteers are required like Article monitor etc.
export GURU_TYPE_VOLUNTEER=100,101,102,103,104,105,106,107,108,109,110,111,119
# GURU_TYPE_VOLUNTEER_OPEN : keeps code of SST features for which volunteers are supported like Article monitor etc.
export GURU_TYPE_VOLUNTEER_OPEN=106,107,108,119
# GURU_TYPE_APPS_REQ_ACT_CFG : keeps code of OLAP app code which require account configuration
export GURU_TYPE_APPS_REQ_ACT_CFG=112,116,117,122,123,126,127,128
# GURU_TYPE_3PP : keeps code of SST features with are applicable for 3PP
export GURU_TYPE_3PP=112,116,117,127,128
# GURU_TYPE_SUPER_ADMIN : keeps code of SST super admin which can be given to any user
export GURU_TYPE_SUPER_ADMIN=199
# GURU_TYPE_ID_FOR_3PP : 
export GURU_TYPE_ID_FOR_3PP=119
#============================================

#============================================
export AIE_STD_MODULES=ADMADM-FEEADM-ACADADM-TTADM
#============================================
