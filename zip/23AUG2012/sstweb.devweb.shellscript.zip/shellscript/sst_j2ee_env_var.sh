#!/bin/ksh

######################################################################################
# Java Env Vars-starts
export JSSE_HOME=/home/java/sst_lib/jsse
export JAVA_USER_HOME=/home/java
export JAVA_HOME=${JAVA_USER_HOME}/jdk/jdk1.7.0_05
#export JAVA_HOME=/usr
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=$CLASSPATH:.
# Java Env Vars-ends
######################################################################################

######################################################################################
#tomcat CATALINA vars-starts
export CATALINA_HOME=${JAVA_USER_HOME}/tomcat/apache-tomcat-6.0.35
export CATALINA_HOME=${JAVA_USER_HOME}/tomcat/apache-tomcat-7.0.29
#export CATALINA_BASE=/home/java/apache-tomcat-6.0.16
#export CATALINA_TMPDIR=/home/java/apache-tomcat-6.0.16/temp
#tomcat CATALINA vars-ends
######################################################################################

######################################################################################
export OPENEJB_HOME=${JAVA_USER_HOME}/openejb30
export PATH=${OPENEJB_HOME}/bin:${PATH}
######################################################################################

######################################################################################
#J2EE jar file-starts
export CLASSPATH=$CLASSPATH:$JAVA_HOME/lib/tools.jar
J2EE_CLASSPATH=$J2EE_CLASSPATH:$CATALINA_HOME/lib/servlet-api.jar
#J2EE_CLASSPATH=$J2EE_CLASSPATH:/usr/share/java/servlet.jar
export CLASSPATH=$CLASSPATH:$J2EE_CLASSPATH
#J2EE jar file-ends
######################################################################################

######################################################################################
# JBOSS ENV VARS - STARTS
######################################################################################
export JBOSS_HOST=loc
export JBOSS_HOST=96.44.132.147
#Jboss jar files
export JBOSS_HOME=$JAVA_USER_HOME/jboss/jboss-as-7.1.1.Final
#JBOSS_JARS=$JBOSS_HOME/lib/commons-httpclient.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/concurrent.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/getopt.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/gnu-regexp.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/jboss-boot.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/jboss-common.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/jboss-jmx.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/jboss-system.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/jdom.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/log4j-boot.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/webdavlib.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/xercesImpl.jar
#JBOSS_JARS=$JBOSS_JARS:$JBOSS_HOME/lib/xml-apis.jar
export JBOSS_JARS
#Jboss jar files
######################################################################################
# JBOSS ENV VARS - ENDS
######################################################################################
