#export PATH=.:$PATH
#export PATH=$HOME/esm/v0100/product/bin:$PATH
#export PATH=$HOME/esm/v0100/product/config:$PATH
#export PATH=$HOME/bsnl/v0100/product/config:$PATH


#. $HOME/esm/v0100/product/config/init_db_env
#. $HOME/esm/v0100/product/config/init_work_env
#source $HOME/esm/v0100/product/config/set_alias.sh
#source $HOME/sstweb/devweb/WEB-INF/java.config

export MASTER_HOME=$HOME
export EESMA_USER_ACT_HOME=$HOME
export EESMA_USER_CLASS_DIR=${EESMA_USER_ACT_HOME}/sstweb/devweb/WEB-INF/classes
export CLASSPATH=$CLASSPATH:$EESMA_USER_CLASS_DIR
export PUBLIC_DIR=ees_public

export APP_HOME=$HOME
export APP_CONFIG_PATH=config
