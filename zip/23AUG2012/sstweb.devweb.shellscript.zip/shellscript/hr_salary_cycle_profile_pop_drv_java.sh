#   #!/usr/bin/ksh/
#/bin/ksh/

export OS_NAME=LINUX

CONFIG_FILE_PATH=/home/esmdemo/sstweb/devweb/config/
export CONFIG_FILE_PATH

CONFIG_FILE=jdbc.database.driver.config
export CONFIG_FILE

DB_USR=oracleesmdemo
export DB_USR

java HrSalaryCycleProfilePopPkg $CONFIG_FILE_PATH \
                           $CONFIG_FILE \
                           $DB_USR \

