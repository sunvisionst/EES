#!/bin/ksh
HOST='172.30.10.3'
USER='Administrator'
PASSWD='Sun949513'
PUT_FILE='delme.txt'
GET_FILE='from_win.txt'

sst_ftp_get()
{
ftp -n << END_SCRIPT
open ${HOST}
user ${USER} ${PASSWD}
get ${GET_FILE}
get ${FILE} retrieval.$$
bye
END_SCRIPT
}

sst_ftp_put()
{
ftp -n << END_SCRIPT
open ${HOST}
user ${USER} ${PASSWD}
put ${PUT_FILE}
get ${PUT_FILE} retrieval.$$
bye
END_SCRIPT

if [ -f retrieval.$$ ]
then
  echo "FTP of ${PUT_FILE} to ${HOST} worked"
  /home/eesma/rm -f retrieval.$$
else
  echo "FTP of ${PUT_FILE} did not work"
fi

}

if [ $# -ne 1 ]
then
  echo 'Wrong number of parameters'
  exit
fi

if [ $1 == "GET" ]
then
  sst_ftp_get
elif [ $1 == "PUT" ]
then
  sst_ftp_put
else
  echo 'Wrong number of parameters'
fi

