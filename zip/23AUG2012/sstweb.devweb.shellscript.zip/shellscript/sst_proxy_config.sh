#proxy.sh
export http_proxy=http://172.30.10.29:3128/
export ftp_proxy=http://172.30.10.29:3128/
export no_proxy=172.30.10.56
export HTTP_PROXY=http://172.30.10.29:3128/
export FTP_PROXY=http://172.30.10.29:3128/


#proxy.csh
#setenv http_proxy http://host.com:port/
#setenv ftp_proxy http://host.com:port/
#setenv no_proxy .domain.com
#setenv HTTP_PROXY http://host.com:port/
#setenv FTP_PROXY http://host.com:port/
