#   #!/usr/bin/ksh/
#/bin/ksh/

export OS_NAME=LINUX

CONFIG_FILE_PATH=/home/esmdemo/sstweb/devweb/config/
export CONFIG_FILE_PATH

CONFIG_FILE=jdbc.database.driver.config
export CONFIG_FILE

DB_USR=oracleesmdemo
export DB_USR

PRODUCT_PARAM_CONFIG_FILE_PATH=/home/esmma/sstweb/devweb/config/
export PRODUCT_PARAM_CONFIG_FILE_PATH

PRODUCT_PARAM_CONFIG_FILE=esm.param.config
export PRODUCT_PARAM_CONFIG_FILE

SAL_PREP_RUN_DATE=""
export SAL_PREP_RUN_DATE

java HrTimeCalcDrv $CONFIG_FILE_PATH \
                   $CONFIG_FILE \
                   $DB_USR \
                   $PRODUCT_PARAM_CONFIG_FILE_PATH \
                   $PRODUCT_PARAM_CONFIG_FILE \
                   $SAL_PREP_RUN_DATE \

java HrSalaryPrepDrv $CONFIG_FILE_PATH \
                     $CONFIG_FILE \
                     $DB_USR \
                     $PRODUCT_PARAM_CONFIG_FILE_PATH \
                     $PRODUCT_PARAM_CONFIG_FILE \
                     $SAL_PREP_RUN_DATE \



#  close previous month salary cycle
#java HrSalaryCycleCloseDrv

#  Create New Salary Cycle Record  for current month. 
#  If prev month cycle open , exit(-9999999)
#  and tell ADM that prev month salary cycle is still open. Close the cycle from GUI
 

#  populate hr_card_time table from card data file for existing employees
#java HrTimeCalcPopCardTimeDrv $CONFIG_FILE_PATH \ $CONFIG_FILE \ $DB_USR \ $PRODUCT_PARAM_CONFIG_FILE_PATH \ $PRODUCT_PARAM_CONFIG_FILE \ $SAL_PREP_RUN_DATE \
#
#
#  populate daily timeshet from hr_card_time table for existing employees
#
#
#  populate daily timeshet sum from daily timesheet table for existing employees
#
#
#
#
#
#
#
#
#

