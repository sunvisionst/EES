#!/bin/sh

# script to start and stop Postgre SQL Version 8.1.4

SERVER=/opt/sstpostgres/pg8.3/bin/postmaster
PGCTL=/opt/sstpostgres/pg8.3/bin/pg_ctl
PGDATA=/opt/sstpostgres/data
OPTIONS=-i
LOGFILE=/opt/sstpostgres/data/log_pg83

case "$1" in
     start)
          echo -n "Starting PostgreSQL Version 8.3 ..."
          su -l sstpostgres -c "nohup $SERVER $OPTIONS -D $PGDATA > $LOGFILE 2>&1 &"
          ;;

     stop)
          echo -n "Stopping PostgreSQL Version 8.3 ..."
          su -l sstpostgres -c "$PGCTL -D $PGDATA stop"
          ;;

     *)
          echo "Usage : $0 {start|stop}"
          exit 1
          ;;
esac
exit 0

