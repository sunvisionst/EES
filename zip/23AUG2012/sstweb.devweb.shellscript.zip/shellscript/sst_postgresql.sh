#!/bin/sh

# script to start and stop Postgre SQL

PG_VERSION=`postgres --version`
SERVER=/usr/bin/postmaster
PGCTL=/usr/bin/pg_ctl
PGDATA=/var/lib/pgsql/data
OPTIONS=-i
LOGFILE=/var/lib/pgsql/data/log_pg.db

case "$1" in
     start)
          echo -n "Starting "${PG_VERSION} " ..."
          su -l postgres -c "nohup $SERVER $OPTIONS -D $PGDATA > $LOGFILE 2>&1 &"
          ;;

     stop)
          echo -n "Stopping "${PG_VERSION} " ..."
          su -l postgres -c "$PGCTL -D $PGDATA stop"
          ;;

     *)
          echo "Usage : $0 {start|stop}"
          exit 1
          ;;
esac
exit 0

