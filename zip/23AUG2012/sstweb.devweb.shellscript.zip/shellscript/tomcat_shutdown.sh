#!/bin/ksh

if [ $# -lt 1 ]
then
  echo "Wrong number of parameters"
  echo "[USAGE] ${0} <instance_number>"
  echo "[EXAMPLE] ${0} 1"
  exit
fi


export CATALINA_BASE=~java/tc6mi/tc${1}
export CATALINA_TMPDIR=~java/tc6mi/tc${1}/temp
#\rm ${CATALINA_BASE}/logs/catalina.out
~java/apache-tomcat-6.0.16/bin/rm ${CATALINA_BASE}/logs/catalina.out
$CATALINA_HOME/bin/shutdown.sh
