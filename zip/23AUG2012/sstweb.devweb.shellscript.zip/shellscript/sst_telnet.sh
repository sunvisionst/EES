#!/bin/sh
host=172.30.10.29
port=23
cmd="whoami"
( echo open ${host} ${port}
sleep 1
echo -e "\r"
sleep 1
echo ${cmd}
sleep 1
echo -e "\r"
sleep 1
echo exit ) | telnet
