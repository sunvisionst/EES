#   #!/usr/bin/ksh/
#/bin/ksh/


DB_USER=oracledharams
export DB_USER

java hr_emp_vacation_batch $DB_USER
