#!/bin/ksh

########################################################
command_usage()
{
  echo "Usage :"
  echo $0" <host ip> <database name> <backup dir> <backup file>"
  echo "Help command to restore single table [pg_restore -i -h 172.30.10.56 -p 5432 -U postgres -d sst_eesma_test --table=cx_symbol_cntr -v /media/Riti/sst10056/sst_eesma_test_20100428090430_LAPTOP]"
}

if [ $# -ne 4 ]
then
  echo 'Wrong number of parameters'
  command_usage
  exit
else
  CMD_PARAM1=$1
  CMD_PARAM2=$2
  CMD_PARAM3=$3
  CMD_PARAM4=$4
fi

echo ${CMD_PARAM1}
echo ${CMD_PARAM2}
echo ${CMD_PARAM3}
echo ${CMD_PARAM4}

#######################################################

#export HOST=`hostname -i`
export HOST=${CMD_PARAM1}
export PG_HOME=/usr
#export PG_HOME=/home/sstpostgre/pg8.1.2
export PG_SERVER_PORT=5432
export PG_RES=pg_restore
export PG_DB_OWNER=postgres
export BACKUP_DEST=${CMD_PARAM3}
export BACKUP_FILE=${CMD_PARAM4}
export PG_DB=${CMD_PARAM2}

${PG_HOME}/bin/${PG_RES} -i -h ${HOST} -p ${PG_SERVER_PORT} -U ${PG_DB_OWNER} -d ${PG_DB} -v "${BACKUP_DEST}/${BACKUP_FILE}"
STATUS=$?

TEMP_DIR=/tmp
if [ ${STATUS} = 0 ]
then
  echo "0" > ${TEMP_DIR}/${0}_status
else
  echo "-1" > ${TEMP_DIR}/${0}_status
fi
