#!/bin/sh

PWD=`pwd`
SRC_PATH=$1
RUN_APP=$2
RUN_CMD=$3

#echo ${PWD} ${SRC_PATH} ${RUN_APP} ${RUN_CMD}

cd ${SRC_PATH}
${RUN_APP} ${RUN_CMD}
cd ${PWD}
