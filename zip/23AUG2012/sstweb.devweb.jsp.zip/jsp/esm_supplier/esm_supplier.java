//////////////////// Common Packages /////////////////////
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.util.ArrayList;

import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTMailPkg;
import sstcom.gn.SSTPage;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTLookAndFeel;
import sstcom.gn.SSTPrgTrackObj;
import sstcom.gn.SSTDateMethod;
import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTCommonAction;


import sstcom.gn.SSTSeq;

import sstdb.gn.GnTypeValue.*;
import sstdb.gn.GnApplnSession.*;

import sstdb.hr.HrEmployee.*;
import sstdb.hr.HrOrganization.*;
import sstdb.hr.HrFinanceYearDef.*;

import sstdb.ots.OtsMember.*;
import sstdb.ees.EesAcademicSession.*;


//////////////////// Common Packages - Ends /////////////////////

import sstdb.esm.EsmSupplier.*;

      /////////////////////////////Servlet Templet Fix Part - Starts ////////////////////////////
public class esm_supplier extends HttpServlet
{

   int MAX_PAGE_REC        = 0;

   String  GUI_DATE_FORMAT = "";
   String  DB_DATE_FORMAT  = "";

   String lConfigFilePath  = "";
   String lConfigFile      = "";
   String lDBUsr           = "";
   String lOSUsr           = "";
   String lDebugFlagQueryStr = "";  

   Properties   lProperties;
   SSTProperty  lSSTProperty;

   String lSeqFilePath     = "";
   String lSeqFileName     = "";
   String lCacheFilePath   = "";

   String lJavaSystemErrorFlag;
   String lServletInitErrorText = "";

   SSTErrorObj gSSTErrorObj = new SSTErrorObj();

   /* Initialize global variables */
   public void init(ServletConfig config) throws ServletException
   {
     int lReturnValue = 0;

     try
     {
       gSSTErrorObj.sourceClass = "esm_supplier";
       gSSTErrorObj.sourceMethod = "init";

       System.out.println("initializing controller servlet.");

       ServletContext context = config.getServletContext();
       context.setAttribute("base", config.getInitParameter("base"));
       context.setAttribute("imageUrl", config.getInitParameter("imageUrl"));

       //Load Product Parameter config file
       String lProductParamConfigFilePath = "";
       lProductParamConfigFilePath = (String)context.getAttribute("product_param_config_file_path");

       String lProductParamConfigFile = "";
       lProductParamConfigFile = (String)context.getAttribute("product_param_config_file");

       lSSTProperty = new SSTProperty(lProductParamConfigFilePath+lProductParamConfigFile);
       if ( lSSTProperty.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTProperty.gSSTErrorObj.errorCode;
         gSSTErrorObj.errorText = lSSTProperty.gSSTErrorObj.errorText;
         lReturnValue = lSSTProperty.gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lProperties = lSSTProperty.getSSTProperty();
       if ( lProperties == null )
       {
         lReturnValue=-999500000;
         throw new Exception();
       }
       //Load Product Parameter config file - Ends


       //Assign Product Parameter configration in Servlet Variables
       lDBUsr = (String)context.getAttribute("DB_USR");
       lOSUsr = (String)context.getAttribute("OS_USR");

       lSeqFilePath    =lProperties.getProperty("SEQ_FILE_PATH").toString().replaceAll("<osusr>", lOSUsr);
       lSeqFileName    =lProperties.getProperty("SEQ_FILE_NAME").toString();
       GUI_DATE_FORMAT = lProperties.getProperty("DEFAULT_GUI_DATE_FORMAT_JAVA").toString();
       DB_DATE_FORMAT  = lProperties.getProperty("DEFAULT_DATE_FORMAT_JAVA").toString();

       lConfigFilePath =(String)context.getAttribute("CONFIG_FILE_PATH"); //delme
       lConfigFile     = lProperties.getProperty("CONFIG_FILE").toString();
       lCacheFilePath  = lProperties.getProperty("CACHE_FILE_PATH");

       MAX_PAGE_REC    = Integer.parseInt(lProperties.getProperty("MAX_PAGE_REC").toString());

       lDebugFlagQueryStr       = lProperties.getProperty("DEBUG_FLAG_QRY_STR").toString();
       if ( lDebugFlagQueryStr == null )
       {
         lReturnValue=-999500010;
         throw new Exception();
       }

       lJavaSystemErrorFlag     = lProperties.getProperty("JAVA_SYSTEM_ERROR_FLAG").toString();
       if ( lJavaSystemErrorFlag == null )
       {
         lReturnValue=-999500010;
         throw new Exception();
       }
       //Assign Product Parameter configration in Servlet Variables - Ends
     }
     catch( Exception e )
     {
       lServletInitErrorText = "Error From init method";
     }
      super.init(config);
   }

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// AJAX Code - Starts 
   protected void processRequest(HttpServletRequest request, HttpServletResponse response)
   throws ServletException, IOException
   {
      //System.out.println("processRequest - starts");


      ///////////////////////////////////// ------Fix Part [1] For Ajax ----------/////////////////
      ////////////////////////////////Start/////////////////////////////////////////////////////

      //Sets the content type made to xml specific
      response.setContentType("text/xml");

      //Initializing PrintWriter
      PrintWriter out = response.getWriter();

      String lAjaxAction = (String) request.getParameter("ajaxAction");
      String action      = (String) request.getParameter("action");

      /////////////////////////////End///////////////////////////////////////////////////////////
                                                                                                                             
      ////////////////////////////// Variable Part //////////////////////////////////////////////
      ///////////////////////////////////////Start///////////////////////////////////////////////

      //TODO : Change lAjaxAction compare value as per your need
      //TODO : Add else if conditions as per your need
      if ( lAjaxAction !=null && lAjaxAction.equals("__first_ajax_action_value__") )
         action = "__first_ajax_action_value__";
      else
      if ( lAjaxAction !=null && lAjaxAction.equals("__second_ajax_action_value__") )
         action = "__second_ajax_action_value__";

      if ( action != null)
      {
        // Fix Part of this __first_ajax_action_value__ - starts
        String lWhereText = request.getParameter("whereText");
        String lFieldList = request.getParameter("fieldList");
        String lDestFieldList = request.getParameter("destFieldList");
                                                                                                                             
        if ( lWhereText == null )
        {
          System.out.println("ERROR: where text is not set");
          // set lErrorMessage = request value not set
          // throw exceptions
        }
        else
        if ( lFieldList == null )
        {
          System.out.println("ERROR: Field List is not set");
          // set lErrorMessage = Field List not set
          // throw exceptions
        }
        else
        if ( lDestFieldList == null )
        {
          System.out.println("ERROR: Destination List is not set");
          // set lErrorMessage = destination field not set
          // throw exceptions
        }
        //System.out.println("MESSAGE : "+lWhereText+" - "+lFieldList+" - "+lDestFieldList);
        // Fix Part of this __first_ajax_action_value__ - ends

        if (action.equals("__first_ajax_action_value__"))
        {
           EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
           lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
           lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
           lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
           lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;
           String lEsmSupplierTabObjArrXML = new String();
           lEsmSupplierTabObjArrXML = lEsmSupplierMethodObj.gtEsmSupplierArr2XML( lWhereText, lFieldList );
                                                                                                                             
           //System.out.println("-lesm_supplierTabObjArrXML -"+lesm_supplierTabObjArrXML);
           out.write(lEsmSupplierTabObjArrXML);
        }
        //TODO : add another action bloack as per your need
        //TODO : COPY and PASTE the whole else-if block if new action is added on JSP for AJAX
        else
        if (action.equals("__second_ajax_action_value__"))
        {
           EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
           lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
           lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
           lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
           lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;
           String lEsmSupplierTabObjArrXML = new String();
           lEsmSupplierTabObjArrXML = lEsmSupplierMethodObj.gtEsmSupplierArr2XML( lWhereText, lFieldList );
                                                                                                                             
           //System.out.println("-lEsmSupplierTabObjArrXML -"+lEsmSupplierTabObjArrXML);
           out.write(lEsmSupplierTabObjArrXML);
        }
      }
      out.close();
      //System.out.println("processRequest - ends");
   }
// AJAX Code - Ends  
/////////////////////////////////////////////////////////////////////////////////////////////////////////

   /* Process the HTTP Get request */
   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
   {
      String lAjaxFlag   = request.getParameter("ajaxFlag");
      if (lAjaxFlag  != null && lAjaxFlag.equals("true"))
         processRequest(request, response);
      else
         doPost(request, response);

   }


   /* Process the HTTP Post request */
   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
   {
      ServletContext context = getServletContext();
      response.setContentType("text/html");
      //response.setHeader("Cache-Control","no-cache");
      //response.setHeader("Cache-Control","no-store");
      //response.setDateHeader("Expires", 0);
      //response.setHeader("Pragma","no-cache");

      PrintWriter out       = response.getWriter();
      HttpSession session   = request.getSession();
      lProperties           = (Properties)session.getAttribute("lProperties");
      lDebugFlagQueryStr    = lProperties.getProperty("DEBUG_FLAG_QRY_STR").toString();


      ///////////////////////////
      // Get Development DB User
      ///////////////////////////
      if ( lProperties.getProperty("DB_USR_CTX_SWT") != null
        && lProperties.getProperty("DB_USR_CTX_SWT").toString().equals("1") )
      {
        String lDevDbUserId = (String)session.getAttribute("lDevDbUserId");
        if ( lDevDbUserId != null && lDevDbUserId.trim().length() > 0 )
        {
          lDBUsr = lDevDbUserId;
          System.out.println("lDBUsr and lDevDbUserId "+lDBUsr+" "+lDevDbUserId);
        }
      }
      ///////////////////////////

      String  lResponseText   = "";
      ArrayList    lPrgTrackObjArr = new ArrayList();

      SSTPrgTrackObj  lSSTPrgTrackObj    = new SSTPrgTrackObj();

      GnApplnSessionTabObj lGnApplnSessionTabObj = new GnApplnSessionTabObj();
      lGnApplnSessionTabObj = (GnApplnSessionTabObj)session.getAttribute("lGnApplnSessionTabObj");

      String lErrorMessage = "";
      session.setAttribute("lErrorMessage",null);

      String lUserId = "";
      {
        if ( lGnApplnSessionTabObj != null )
         lUserId = lGnApplnSessionTabObj.user_id;

        /*
        SSTLookAndFeel lSSTLookAndFeel = new SSTLookAndFeel();

        lSSTLookAndFeel.setCssFilePath( lProperties.getProperty("CSS_FILE_PATH").toString().replaceAll("<osusr>", lOSUsr) );
        lSSTLookAndFeel.setUserId( lUserId );

        String lLogoBarCssStr  = lSSTLookAndFeel.getLogoBarCssString();
        String lCriteriaCssStr = lSSTLookAndFeel.getCriteriaCssString();
        String lLoginCssStr    = lSSTLookAndFeel.getLoginCssString();
        String lMenuCssStr     = lSSTLookAndFeel.getMenuCssString();
        String lDataCssStr     = lSSTLookAndFeel.getDataCssString();

        session.setAttribute("lLogoBarCssStr",lLogoBarCssStr);
        session.setAttribute("lCriteriaCssStr",lCriteriaCssStr);
        session.setAttribute("lLoginCssStr",lLoginCssStr);
        session.setAttribute("lMenuCssStr",lMenuCssStr);
        session.setAttribute("lDataCssStr",lDataCssStr);
        */
      }

      ///////////  SET NAVIGATION PATH - STARTS ////////////////////
      {
        String lMenuNum    = request.getParameter("sst_menu_num");
        String lItemNum    = request.getParameter("sst_item_num");
        String lNodeName   = request.getParameter("sst_node_name");
        //if ( lMenuNum != null && lItemNum != null && lNodeName != null )
        {
          SSTCommonAction lSSTCommonAction = new SSTCommonAction();
          lSSTCommonAction.setConfigFilePath(lConfigFilePath);
          lSSTCommonAction.setConfigFile(lConfigFile);
          lSSTCommonAction.setDBUsr( lDBUsr );
          lSSTCommonAction.setOrgId( lProperties.getProperty("DEFAULT_ORG_ID").toString());
          lSSTCommonAction.setReqObj( request, true );
          lSSTCommonAction.setMenuNum( lMenuNum );
          lSSTCommonAction.setItemNum( lItemNum );
          lSSTCommonAction.setNodeName( lNodeName );
          String lNavigationPathStr = lSSTCommonAction.getNavigationPath();
          session.setAttribute("lNavigationPathStr", lNavigationPathStr);
        }
      }
      ///////////  SET NAVIGATION PATH - ENDS ////////////////////

      String DB_INS_RESPONSE_MSG  = lProperties.getProperty("DB_INS_RESPONSE_MSG").toString();
      String DB_UPD_RESPONSE_MSG  = lProperties.getProperty("DB_UPD_RESPONSE_MSG").toString();
      String DB_DEL_RESPONSE_MSG  = lProperties.getProperty("DB_DEL_RESPONSE_MSG").toString();
      String DB_FAIL_RESPONSE_MSG = lProperties.getProperty("DB_FAIL_RESPONSE_MSG").toString();

      // Make the product param configuration global
      // No need to set on each servlet, alreasy set on login servlet
      // session.setAttribute("lProperties",lProperties);

      session.setAttribute("lResponseText", null);
      session.setAttribute("lErrorMessage", null);
      session.setAttribute("lErrorText", null);
      session.setAttribute("lErrorTextSRec", null);

      int lReturnValue      = 0;

      SSTErrorObj lSSTErrorObj = new SSTErrorObj();
      lSSTErrorObj.sourceClass = "esm_supplier";
      lSSTErrorObj.sourceMethod = "doPost";

      String base        = "/jsp/";
      String url         = "";

      String action      = request.getParameter("action");
      String lMenuOption = request.getParameter("menuOption");
      session.setAttribute("lMenuOption",lMenuOption);
      /////////////////////////////Servlet Templet Fix Part - Ends ////////////////////////////

      if( lMenuOption != null && lMenuOption.equals("defineSupplier"))
      {
        action = "show_esm_supplier_view";
      }


      try
      {
        if ( lServletInitErrorText != null && lServletInitErrorText.trim().length() != 0 )
        {
          lSSTErrorObj = gSSTErrorObj;
          lReturnValue = lSSTErrorObj.errorCode;
          lServletInitErrorText = "";
          url = base + "gn_error.jsp";
          throw new Exception();
        }
       
        String action_create             = request.getParameter("action_create");
        String action_update             = request.getParameter("action_update");
        String action_delete             = request.getParameter("action_delete");
        String action_query              = request.getParameter("action_query");

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
        String DEBUG_FLAG_REQ_PARAM = lProperties.getProperty("DEBUG_FLAG_REQ_PARAM");
        if ( DEBUG_FLAG_REQ_PARAM != null && DEBUG_FLAG_REQ_PARAM.equals("Y") )
        {
          System.out.println("DEBUG MESSAGE : #################### Login Parameter List ############################ ");
          Enumeration lEnumeration = request.getParameterNames();
          while ( lEnumeration.hasMoreElements() )
          {
             String lParameterName = (String) lEnumeration.nextElement();
             System.out.println("DEBUG MESSAGE : "+ lParameterName+" | "+request.getParameter(lParameterName));
          }
          System.out.println("DEBUG MESSAGE : ####################  Parameter List Ends ############################ ");

          System.out.println("DEBUG MESSAGE : #################### Session Attribute List - Starts################## ");
          lEnumeration = session.getAttributeNames();
          while ( lEnumeration.hasMoreElements() )
          {
            String lParameterName = (String) lEnumeration.nextElement();
            System.out.println("DEBUG MESSAGE : Session Attribute "+lParameterName);
          }
          System.out.println("DEBUG MESSAGE : #################### Session Attribute List - Ends################## ");
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////


        if ( 
             action_create != null 
           ||action_update != null 
           ||action_delete != null 
           ||action_query  != null 
           )
        {
          if ( request.getParameter("submit").equals("Create"))
          {
            if ( action_create.equals("esm_supplier_create_submit") )
              action = "esm_supplier_create_submit";
          }
          else
          if ( request.getParameter("submit").equals("Update"))
          {
            if ( action_update.equals("esm_supplier_update_submit") )
              action = "esm_supplier_update_submit";
          }
          else
          if ( request.getParameter("submit").equals("Delete"))
          {
            if ( action_delete.equals("esm_supplier_delete_submit") )
              action = "esm_supplier_delete_submit";
          }
          else
          if ( request.getParameter("submit").equals("Query"))
          {
            if ( action_query.equals("esm_supplier_query_submit") )
              action = "esm_supplier_query_submit";
          }
        }


        System.out.println("Tom Action: "+action);
        System.out.println("Tom Menu option: "+lMenuOption);

        session.setAttribute("lAction", action);
        if ( action != null )
        {
          lPrgTrackObjArr = (ArrayList)session.getAttribute("lPrgTrackObjArr");
          if ( lPrgTrackObjArr != null )
            lSSTPrgTrackObj.action = action;
          else
            lSSTPrgTrackObj.action = "default";

          ////////////////////////////////////////////////////////////////////////////////////////////////
          // GET GLOBAL SESSION ATTRIBUTE
          ////////////////////////////////////////////////////////////////////////////////////////////////
          HrOrganizationTabObj lHrOrganizationTabObjGlobal = new HrOrganizationTabObj();
          lHrOrganizationTabObjGlobal = (HrOrganizationTabObj)session.getAttribute("lHrOrganizationTabObjGlobal");

          HrEmployeeTabObj lHrEmployeeTabObjGlobal = new HrEmployeeTabObj();
          lHrEmployeeTabObjGlobal = (HrEmployeeTabObj)session.getAttribute("lHrEmployeeTabObjGlobal");

          HrFinanceYearDefTabObj lHrFinanceYearDefTabObjGlobal   = new HrFinanceYearDefTabObj();
          lHrFinanceYearDefTabObjGlobal = (HrFinanceYearDefTabObj)session.getAttribute("lHrFinanceYearDefTabObjGlobal");

          EesAcademicSessionTabObj lEesAcademicSessionTabObjGlobal = new EesAcademicSessionTabObj();
          lEesAcademicSessionTabObjGlobal = (EesAcademicSessionTabObj)session.getAttribute("lEesAcademicSessionTabObjGlobal");

          //GnApplnSessionTabObj lGnApplnSessionTabObj       = new GnApplnSessionTabObj();
          //lGnApplnSessionTabObj = (GnApplnSessionTabObj)session.getAttribute("lGnApplnSessionTabObj");

          OtsMemberTabObj lOtsMemberTabObjGlobal = new OtsMemberTabObj();
          lOtsMemberTabObjGlobal = (OtsMemberTabObj)session.getAttribute("lOtsMemberTabObjGlobal");
          ////////////////////////////////////////////////////////////////////////////////////////////////

          ////////////////////////////////////////////////////////////////////////
          // GET DATABASE CONNECTION                                            //
          ////////////////////////////////////////////////////////////////////////
          SSTDBMethod lSSTDBMethod = new SSTDBMethod();
          lSSTDBMethod.getSSTDBConnection( lConfigFilePath, lConfigFile, lDBUsr );
          ////////////////////////////////////////////////////////////////////////

          if ( action.equals("show_esm_supplier_view"))
          {

            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );
            if ( lReturnValue < 0 )
            {
              lErrorMessage = "No Record Found ";
              session.setAttribute("lErrorMessage", lErrorMessage);
            }

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
            System.out.println("lReturnValue : after CLOSEDB  url "+url);
          }
          else
          if ( action.equals("esm_supplier_query_submit"))
          {

            String __qc_field_name__ = request.getParameter("__qc_field_name__");
            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            if ( __qc_field_name__ != null && __qc_field_name__.length() > 0 )
              lWhereText = " __qc_field_name__ = '"+__qc_field_name__+"'";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );
            if ( lReturnValue < 0 )
            {
              lErrorMessage = "No Record Found ";
              session.setAttribute("lErrorMessage", lErrorMessage);
            }

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
          }
          else
          if ( action.equals("esm_supplier_create_submit"))
          {

            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            EsmSupplierTabObj lEsmSupplierTabObj = new EsmSupplierTabObj();
            lReturnValue = lEsmSupplierMethodObj.popEsmSupplierReq2Obj( request, lEsmSupplierTabObj);

            lReturnValue = lEsmSupplierMethodObj.insEsmSupplierRec( lEsmSupplierTabObj );

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
          }
          else
          if ( action.equals("esm_supplier_update_submit"))
          {

            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            EsmSupplierTabObj lEsmSupplierTabObj = new EsmSupplierTabObj();
            lReturnValue = lEsmSupplierMethodObj.popEsmSupplierReq2Obj( request, lEsmSupplierTabObj);

            EsmSupplierPkeyObj lEsmSupplierPkeyObj = new EsmSupplierPkeyObj();
            lEsmSupplierPkeyObj.supplier_id= lEsmSupplierTabObj.supplier_id;
            lReturnValue = lEsmSupplierMethodObj.updEsmSupplierRecByPkey( lEsmSupplierPkeyObj, lEsmSupplierTabObj );

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
          }
          else
          if ( action.equals("esm_supplier_delete_submit"))
          {

            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            int lRecOnPage = ((ArrayList)session.getAttribute("lEsmSupplierTabObjArr")).size();
            ArrayList lEsmSupplierTabObjM2FArr = new ArrayList();
            lReturnValue = lEsmSupplierMethodObj.popEsmSupplierReq2ObjM2F( request, lRecOnPage, lEsmSupplierTabObjM2FArr);

            if ( lEsmSupplierTabObjM2FArr != null && lEsmSupplierTabObjM2FArr.size() > 0 )
            for ( int lRecNum = 0; lRecNum < lEsmSupplierTabObjM2FArr.size(); lRecNum++ )
            {
              EsmSupplierTabObj lEsmSupplierTabObj = new EsmSupplierTabObj();
              lEsmSupplierTabObj = (EsmSupplierTabObj)lEsmSupplierTabObjM2FArr.get(lRecNum);

              EsmSupplierPkeyObj lEsmSupplierPkeyObj = new EsmSupplierPkeyObj();
              lEsmSupplierPkeyObj.supplier_id= lEsmSupplierTabObj.supplier_id;
              lReturnValue = lEsmSupplierMethodObj.delEsmSupplierRecByPkey( lEsmSupplierPkeyObj );
            }

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
          }
          else
          if ( action.equals("esm_supplier_delete_submit_single"))
          {

            EsmSupplierMethodObj lEsmSupplierMethodObj = new EsmSupplierMethodObj();
            lEsmSupplierMethodObj.gConfigFilePath     = lConfigFilePath;
            lEsmSupplierMethodObj.gConfigFile         = lConfigFile;
            lEsmSupplierMethodObj.gDBUsr              = lDBUsr;
            lEsmSupplierMethodObj.gConnectInd         = true;
            lEsmSupplierMethodObj.gConnection         = lSSTDBMethod.getConnection();
            lEsmSupplierMethodObj.gDebugFlagQryStr    = lDebugFlagQueryStr;

            EsmSupplierTabObj lEsmSupplierTabObj = new EsmSupplierTabObj();
            lReturnValue = lEsmSupplierMethodObj.popEsmSupplierReq2Obj( request, lEsmSupplierTabObj);

            EsmSupplierPkeyObj lEsmSupplierPkeyObj = new EsmSupplierPkeyObj();
            lEsmSupplierPkeyObj.supplier_id= lEsmSupplierTabObj.supplier_id;
            lReturnValue = lEsmSupplierMethodObj.delEsmSupplierRecByPkey( lEsmSupplierPkeyObj );

            ArrayList lEsmSupplierTabObjArr = new ArrayList();
            String lWhereText = "";
            //lWhereText = lWhereText + "org_id = '"+lHrOrganizationTabObjGlobal.org_id+"' ";
            lReturnValue = lEsmSupplierMethodObj.gtEsmSupplierArr( lWhereText, lEsmSupplierTabObjArr );

            url = base + "esm_supplier_envelop.jsp";
            session.setAttribute("lEsmSupplierTabObjArr", lEsmSupplierTabObjArr);
            session.setAttribute( "lDBOpr", "Query" );
          }

          ////////////////////////////////////////////////////////////////////////
          // CLOSE DATABASE CONNECTION                                          //
          ////////////////////////////////////////////////////////////////////////
          lSSTDBMethod.closeSSTDBConnection();
          //////////////////////////////////////////////////////////////////////////
          
        }
      } //Try Block                                                                               
      /////////////////////////////Servlet Templet Varying Part - Starts ////////////////////////////
      catch( Exception e )
      {
        if ( lSSTErrorObj.errorCode  == +999901031 )
          ;
        else
        {
           SSTError lSSTError = new SSTError( e );
           String lExceptionText = "";
           lExceptionText = lSSTError.getErrorText(); // Java Exception Error Text
           lErrorMessage = lSSTError.getErrorText( lSSTErrorObj, lReturnValue ); // Sunvision Error Text
           if ( lJavaSystemErrorFlag != null && lJavaSystemErrorFlag.equals( "Y" ))
             lErrorMessage = lErrorMessage+lExceptionText;
           else
             lErrorMessage = lErrorMessage;
           session.setAttribute("lErrorMessage", lErrorMessage );
        }
      }
      {
        lSSTPrgTrackObj.url = url;
        if ( lSSTPrgTrackObj != null )
        {
          if ( lPrgTrackObjArr != null && lPrgTrackObjArr.size() > 0 )
          {
           lPrgTrackObjArr.add(lSSTPrgTrackObj);
           session.setAttribute("lPrgTrackObjArr",lPrgTrackObjArr);
          }
        }
        session.setAttribute("lResponseText", lResponseText);
      }
      RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher(url);
      requestDispatcher.forward(request, response);
      /////////////////////////////Servlet Templet Varying Part - Starts ////////////////////////////
   }
}
