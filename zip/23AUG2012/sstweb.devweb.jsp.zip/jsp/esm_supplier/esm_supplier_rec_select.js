function EsmSupplierRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("supplier_id").value  = document.getElementById("supplier_id"+"_r"+inRecNum).value; 
    document.getElementById("supplier_type").value  = document.getElementById("supplier_type"+"_r"+inRecNum).value; 
    document.getElementById("supplier_ctg").value  = document.getElementById("supplier_ctg"+"_r"+inRecNum).value; 
    document.getElementById("supplier_name").value  = document.getElementById("supplier_name"+"_r"+inRecNum).value; 
    document.getElementById("referred_by").value  = document.getElementById("referred_by"+"_r"+inRecNum).value; 
    document.getElementById("turn_over").value  = document.getElementById("turn_over"+"_r"+inRecNum).value; 
    document.getElementById("supply_capacity").value  = document.getElementById("supply_capacity"+"_r"+inRecNum).value; 
    document.getElementById("area_code").value  = document.getElementById("area_code"+"_r"+inRecNum).value; 
    document.getElementById("country_code").value  = document.getElementById("country_code"+"_r"+inRecNum).value; 
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value; 
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value; 
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value; 
    document.getElementById("business_type").value  = document.getElementById("business_type"+"_r"+inRecNum).value; 
    document.getElementById("business_est_date").value  = document.getElementById("business_est_date"+"_r"+inRecNum).value; 
    document.getElementById("employee_strength").value  = document.getElementById("employee_strength"+"_r"+inRecNum).value; 
    document.getElementById("business_currency").value  = document.getElementById("business_currency"+"_r"+inRecNum).value; 
    document.getElementById("supp_seq_num").value  = document.getElementById("supp_seq_num"+"_r"+inRecNum).value; 
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("supplier_id").value  = '';
    document.getElementById("supplier_type").value  = '';
    document.getElementById("supplier_ctg").value  = '';
    document.getElementById("supplier_name").value  = '';
    document.getElementById("referred_by").value  = '';
    document.getElementById("turn_over").value  = '';
    document.getElementById("supply_capacity").value  = '';
    document.getElementById("area_code").value  = '';
    document.getElementById("country_code").value  = '';
    document.getElementById("status").value  = '';
    document.getElementById("expiration_date").value  = '';
    document.getElementById("effective_date").value  = '';
    document.getElementById("business_type").value  = '';
    document.getElementById("business_est_date").value  = '';
    document.getElementById("employee_strength").value  = '';
    document.getElementById("business_currency").value  = '';
    document.getElementById("supp_seq_num").value  = '';
  }
}
