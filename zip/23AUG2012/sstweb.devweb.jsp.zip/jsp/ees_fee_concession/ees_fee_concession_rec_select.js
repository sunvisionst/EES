function EesFeeConcessionRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {

    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("fee_head").value         = document.getElementById("fee_head"+"_r"+inRecNum).value;
    document.getElementById("student_ctg").value      = document.getElementById("student_ctg"+"_r"+inRecNum).value;
    document.getElementById("discount_percent").value = document.getElementById("discount_percent"+"_r"+inRecNum).value;
    // add other fields like above
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("fee_head").value         = '';
    document.getElementById("student_ctg").value      = '';
    document.getElementById("discount_percent").value = '';
  }
}
