update gn_sstptl_user_data set collect_seq_num = 13 WHERE  org_id = 'SST' and party_ctg = '05'  and party_type = '05-001'  and business_type = '00' and file_type = 'FEESCH';
update gn_sstptl_user_data set collect_seq_num = 12 WHERE  org_id = 'SST' and party_ctg = '05'  and party_type = '05-001'  and business_type = '00' and file_type = 'LATEFEERL';
