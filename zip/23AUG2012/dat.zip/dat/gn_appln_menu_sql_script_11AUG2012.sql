update gn_appln_menu set node_url = '../servlet/gn_user?menuOption=gnUserRole' where org_id = 'SST' and node_id = '10772';
