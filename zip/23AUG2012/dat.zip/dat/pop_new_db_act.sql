truncate table gn_user;
truncate table hr_organization;
truncate table hr_employee;
truncate table gn_user_access;
truncate table ees_academic_session;

-- GN_USER
insert into gn_user (user_id, user_name, user_emp_id, pswd_change_cnt, pswd_0, pswd_effective_date, expiry_period ) values ('SSTSU', 'SST Super User', '999999999', 0, 'sst', '20070701', 99);
insert into gn_user (user_id, user_name, user_emp_id, pswd_change_cnt, pswd_0, pswd_effective_date, expiry_period ) values ('sstguest', 'SST Guest User', '888888888', 0, 'sstguest', '20070701', 99);

-- HR_ORGANIZATION
insert into hr_organization ( org_id, org_name, related_org_id, address_1, address_2, city, state, zip, country, org_type, org_ctg  )
values ('SST', 'Sunvision','','','','DEL','DEL','110092','IND','','I');

-- HR_EMPLOYEE
insert into hr_employee (employee_id, name_initials, employee_f_name, employee_m_name, employee_l_name, employee_short_name, emp_type, org_id )
values ( '999999999', '', 'SSTSTU', '','','SSTSU', '','SST');
insert into hr_employee (employee_id, name_initials, employee_f_name, employee_m_name, employee_l_name, employee_short_name, emp_type, org_id )
values ( '888888888', '', 'sstguest', '','','SSTGU', '','SST');

--GN_USER
insert into gn_user_access ( appln_short_name, appln_user_id, user_area_id, user_emp_id, role_type ) values ('STD', 'SSTSU', 'STD', '999999999','99' );
insert into gn_user_access ( appln_short_name, appln_user_id, user_area_id, user_emp_id, role_type ) values ('STD', 'sstguest', 'STD', '888888888','99' );

--EES_ACADEMIC_SESSION
insert into ees_academic_session ( academic_session, org_id, start_date, end_date, close_date, academic_session_sts, semester_start_date, semester_end_date, semester_close_date ) values ('2007-2008', 'SST', '20070701', '20080731', '', '1', '20070701', '20071231', '' );


-- GN_TYPE_CODE
-- GN_TYPE_VALUE
-- GN_APPLN_MENU
-- GN_MENU_ACCESS

