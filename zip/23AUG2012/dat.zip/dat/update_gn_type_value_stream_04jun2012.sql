update gn_type_value set id_type_code='0'||id_type_code WHERE  org_id = 'SST' and ID_TYPE = 'STREAM' and length(id_type_code)=2 and id_type_code != 'NA';
update gn_type_value set id_type_code='0'||id_type_code WHERE  org_id = 'SST' and ID_TYPE = 'STREAM' and length(id_type_code)=3 and id_type_code != 'NA';
update gn_type_value set priority_seq=to_number(id_type_code,'9999') WHERE  org_id = 'SST' and ID_TYPE = 'STREAM' and id_type_code != 'NA';

