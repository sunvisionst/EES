update hr_organization 
set 
business_type = (select business_type from gn_sstptl_user b where b.party_id=hr_organization.org_id and b.user_ctg='SP')
,party_ctg = (select party_ctg from gn_sstptl_user b where b.party_id=hr_organization.org_id and b.user_ctg='SP')
,party_type = (select party_type from gn_sstptl_user b where b.party_id=hr_organization.org_id and b.user_ctg='SP')
where hr_organization.org_id = (select party_id from gn_sstptl_user b where b.party_id=hr_organization.org_id and b.user_ctg='SP');
