// GLOBAL JAVASCRIPT FILE FOR WILDLYSOPHISTICATED

function openWin(theURL,winName,features) 
{
  window.open(theURL,winName,features);
}

/*
function noSpam(user,domain) 
{
  locationstring = "mailto:" + user + "@" + domain;
  window.location = locationstring;
}
*/

var strImagePath = "/DDIndia/images/";
	
function newImage(strFilename) 
{
  strFilename = strImagePath + strFilename;
  if (document.images) 
  {
    objTempImage = new Image();
    objTempImage.src = strFilename;
    return objTempImage;
  }
}
	
nav01 = newImage("nav01.gif");
nav01Over = newImage("nav01over.gif");
nav02 = newImage("nav02.gif");
nav02Over = newImage("nav02over.gif");
nav03 = newImage("nav03.gif");
nav03Over = newImage("nav03over.gif");
nav04 = newImage("nav04.gif");
nav04Over = newImage("nav04over.gif");
nav05 = newImage("nav05.gif");
nav05Over = newImage("nav05over.gif");
nav06 = newImage("nav06.gif");
nav06Over = newImage("nav06over.gif");
nav07 = newImage("nav07.gif");
nav07Over = newImage("nav07over.gif");
nav08 = newImage("nav08.gif");
nav08Over = newImage("nav08over.gif");
nav09 = newImage("nav09.gif");
nav09Over = newImage("nav09over.gif");

function changeImage(strLocation, strImage) 
{
  document.images[strLocation].src = eval(strImage + ".src");
}

/*****************************************************
* ypSlideOutMenu
* 3/04/2001
* --youngpup--
*****************************************************/
ypSlideOutMenu.Registry = []
ypSlideOutMenu.aniLen = 150
ypSlideOutMenu.hideDelay = 200
ypSlideOutMenu.minCPUResolution = 10
// constructor


function ypSlideOutMenu(id, dir, left, top, width, height)
{
  this.ie = document.all ? 1 : 0
  this.ns4 = document.layers ? 1 : 0
  this.dom = document.getElementById ? 1 : 0
  if (this.ie || this.ns4 || this.dom) 
  {
    this.id = id
    this.dir = dir
    this.orientation = dir == "left" || dir == "right" ? "h" : "v"
    this.dirType = dir == "right" || dir == "down" ? "-" : "+"
    this.dim = this.orientation == "h" ? width : height
    this.hideTimer = false
    this.aniTimer = false
    this.open = false
    this.over = false
    this.startTime = 0
    this.gRef = "ypSlideOutMenu_"+id
    eval(this.gRef+"=this")
    ypSlideOutMenu.Registry[id] = this
    var d = document
    var strCSS = '<style type="text/css">';
    strCSS += '#' + this.id + 'Container { visibility:hidden; '
    strCSS += 'left:' + left + 'px; '
    strCSS += 'top:' + top + 'px; '
    strCSS += 'overflow:hidden; z-index:10; }'
    strCSS += '#' + this.id + 'Container, #' + this.id + 'Content { position:absolute; '
    strCSS += 'width:' + width + 'px; '
    strCSS += 'height:' + height + 'px; '
    strCSS += '}'
    strCSS += '</style>'
    d.write(strCSS)
    this.load()
  }
}

ypSlideOutMenu.prototype.load = function() 
{
  var d = document
  var lyrId1 = this.id + "Container"
  var lyrId2 = this.id + "Content"
  var obj1 = this.dom ? d.getElementById(lyrId1) : this.ie ? d.all[lyrId1] : d.layers[lyrId1]
  if (obj1) var obj2 = this.ns4 ? obj1.layers[lyrId2] : this.ie ? d.all[lyrId2] : d.getElementById(lyrId2)
  var temp
  if (!obj1 || !obj2) window.setTimeout(this.gRef + ".load()", 100)
  else 
  {
    this.container = obj1
    this.menu = obj2
    this.style = this.ns4 ? this.menu : this.menu.style
    this.homePos = eval("0" + this.dirType + this.dim)
    this.outPos = 0
    this.accelConst = (this.outPos - this.homePos) / ypSlideOutMenu.aniLen / ypSlideOutMenu.aniLen 
    // set event handlers.
    if (this.ns4) this.menu.captureEvents(Event.MOUSEOVER | Event.MOUSEOUT);
      this.menu.onmouseover = new Function("ypSlideOutMenu.showMenu('" + this.id + "')")
    this.menu.onmouseout = new Function("ypSlideOutMenu.hideMenu('" + this.id + "')")
    //set initial state
    this.endSlide()
  }
}

ypSlideOutMenu.showMenu = function(id)
{
  var reg = ypSlideOutMenu.Registry
  var obj = ypSlideOutMenu.Registry[id]
  if (obj.container) 
  {
    obj.over = true
    for (menu in reg) if (id != menu) ypSlideOutMenu.hide(menu)
    if (obj.hideTimer) { reg[id].hideTimer = window.clearTimeout(reg[id].hideTimer) }
    if (!obj.open && !obj.aniTimer) reg[id].startSlide(true)
  }
}

ypSlideOutMenu.hideMenu = function(id)
{
  var obj = ypSlideOutMenu.Registry[id]
  if (obj.container) 
  {
    if (obj.hideTimer) window.clearTimeout(obj.hideTimer)
    obj.hideTimer = window.setTimeout("ypSlideOutMenu.hide('" + id + "')", ypSlideOutMenu.hideDelay);
  }
}

ypSlideOutMenu.hideAll = function()
{
  var reg = ypSlideOutMenu.Registry
  for (menu in reg) 
  {
    ypSlideOutMenu.hide(menu);
    if (menu.hideTimer) window.clearTimeout(menu.hideTimer);
  }
}

ypSlideOutMenu.hide = function(id)
{
  var obj = ypSlideOutMenu.Registry[id]
  obj.over = false
  if (obj.hideTimer) window.clearTimeout(obj.hideTimer)
  obj.hideTimer = 0
  if (obj.open && !obj.aniTimer) obj.startSlide(false)
}

ypSlideOutMenu.prototype.startSlide = function(open) 
{
  this[open ? "onactivate" : "ondeactivate"]()
  this.open = open
  if (open) this.setVisibility(true)
  this.startTime = (new Date()).getTime() 
  this.aniTimer = window.setInterval(this.gRef + ".slide()", ypSlideOutMenu.minCPUResolution)
}

ypSlideOutMenu.prototype.slide = function() 
{
  var elapsed = (new Date()).getTime() - this.startTime
  if (elapsed > ypSlideOutMenu.aniLen) this.endSlide()
  else 
  {
    var d = Math.round(Math.pow(ypSlideOutMenu.aniLen-elapsed, 2) * this.accelConst)
    if (this.open && this.dirType == "-") d = -d
    else if (this.open && this.dirType == "+") d = -d
    else if (!this.open && this.dirType == "-") d = -this.dim + d
    else d = this.dim + d 
    this.moveTo(d)
  }
}

ypSlideOutMenu.prototype.endSlide = function() 
{
  this.aniTimer = window.clearTimeout(this.aniTimer)
  this.moveTo(this.open ? this.outPos : this.homePos)
  if (!this.open) this.setVisibility(false)
  if ((this.open && !this.over) || (!this.open && this.over)) 
  {
    this.startSlide(this.over)
  }
}

ypSlideOutMenu.prototype.setVisibility = function(bShow) 
{ 
  var s = this.ns4 ? this.container : this.container.style
  s.visibility = bShow ? "visible" : "hidden"
}

ypSlideOutMenu.prototype.moveTo = function(p) 
{ 
  this.style[this.orientation == "h" ? "left" : "top"] = this.ns4 ? p : p + "px"
}

ypSlideOutMenu.prototype.getPos = function(c) 
{
  return parseInt(this.style[c])
}

ypSlideOutMenu.prototype.onactivate = function() { }

ypSlideOutMenu.prototype.ondeactivate = function() { }


// settings for the actual instance
var myMenu1 = new ypSlideOutMenu("menu1", "down", 0, 80, 150, 500)
var myMenu2 = new ypSlideOutMenu("menu2", "down", 0, 80, 150, 350)
var myMenu3 = new ypSlideOutMenu("menu3", "down", 0, 80, 150, 350)
var myMenu4 = new ypSlideOutMenu("menu4", "down", 0, 80, 150, 350)
var myMenu5 = new ypSlideOutMenu("menu5", "down", 0, 80, 150, 350)
var myMenu6 = new ypSlideOutMenu("menu6", "down", 0, 80, 150, 350)
var myMenu7 = new ypSlideOutMenu("menu7", "down", 0, 80, 150, 350)

var myOffset1 = -335;
var myOffset2 = -270;
var myOffset3 = -205;
var myOffset4 = -143;
var myOffset5 = 46;
var myOffset6 = 131;
var myOffset7 = 205;

myMenu1.onactivate = repositionMenu1
myMenu2.onactivate = repositionMenu2
myMenu3.onactivate = repositionMenu3
myMenu4.onactivate = repositionMenu4
myMenu5.onactivate = repositionMenu5
myMenu6.onactivate = repositionMenu6
myMenu7.onactivate = repositionMenu7


function repositionMenu1() 
{
  var newLeft = getWindowWidth() / 2 + myOffset1;
  myMenu1.container.style ? myMenu1.container.style.left = newLeft + "px" : myMenu1.container.left = newLeft;
}

function repositionMenu2() 
{
  var newLeft = getWindowWidth() / 2 + myOffset2;
  myMenu2.container.style ? myMenu2.container.style.left = newLeft + "px" : myMenu2.container.left = newLeft;
}

function repositionMenu3() 
{
  var newLeft = getWindowWidth() / 2 + myOffset3;
  myMenu3.container.style ? myMenu3.container.style.left = newLeft + "px" : myMenu3.container.left = newLeft;
}

function repositionMenu4() 
{
  var newLeft = getWindowWidth() / 2 + myOffset4;
  myMenu4.container.style ? myMenu4.container.style.left = newLeft + "px" : myMenu4.container.left = newLeft;
}

function repositionMenu5() 
{
  var newLeft = getWindowWidth() / 2 + myOffset5;
  myMenu5.container.style ? myMenu5.container.style.left = newLeft + "px" : myMenu5.container.left = newLeft;
}

function repositionMenu6() 
{
  var newLeft = getWindowWidth() / 2 + myOffset6;
  myMenu6.container.style ? myMenu6.container.style.left = newLeft + "px" : myMenu6.container.left = newLeft;
}

function repositionMenu7() 
{
  var newLeft = getWindowWidth() / 2 + myOffset7;
  myMenu7.container.style ? myMenu7.container.style.left = newLeft + "px" : myMenu7.container.left = newLeft;
}

function getWindowWidth() 
{
  return window.innerWidth ? window.innerWidth : document.body.offsetWidth;
}
