<script language="JavaScript1.2">

/*
Title Bar Clock script by Jim Stiles - 
Shows date and time in title bar 
*/

if (document.all){
actualtitle=document.title;
var scroller; //scroll down to set it
var ampm;
function antiMilitaryTime()
{
if (hr == "12"){
ampm="P.M."
}
else if (hr == "13"){
hr="1"
ampm="P.M."
}
else if (hr == "14"){
hr="2"
ampm="P.M."
}
else if (hr == "15"){
hr ="3"
ampm="P.M."
}
else if (hr == "16"){
hr = "4"
ampm="P.M."
}
else if (hr == "17"){
hr = "5"
ampm="P.M."
}
else if (hr == "18"){
hr = "6"
ampm="P.M."
}
else if (hr == "19"){
hr = "7"
ampm="P.M."
}
else if (hr == "20"){
hr = "8"
ampm="P.M."
}
else if (hr == "21"){
hr = "9"
ampm="P.M."
}
else if (hr == "22"){
hr = "10"
ampm="P.M."
}
else if (hr == "23"){
hr = "11"
ampm="P.M."
}
else if (hr == "24"){
hr = "12"
}
}
function addZero(){
if (min <= 9){
min = "0"+min
}
if (sec <= 9){
sec = "0"+sec
}
if (hr <= 9){
hr = "0"+hr
}
}
function time(){
dt=new Date()
date=dt.getDate()
month=dt.getMonth()
month=month+1
sec=dt.getSeconds()
hr=dt.getHours()
yr=dt.getYear()
ampm="A.M."
min=dt.getMinutes()
}
function scroll() {
time()
antiMilitaryTime()
addZero()
var scroller="Today's Date: "+month+"/"+date+"/"+yr
var scroller2=" - Time: "+hr+":"+min+":"+sec+" "+ampm
var timeout=setTimeout("scroll()", 1)
scroller=scroller+scroller2
  document.title = actualtitle+" - "+scroller
  }
var timeout=setTimeout('scroll()',1000);
}
else{

}
</script>

