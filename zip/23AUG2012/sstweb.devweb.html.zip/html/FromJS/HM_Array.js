
HM_Array1 = [
[,         // menu width
0,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;About us","about.htm",1,0,0],
["&nbsp;Company","#",1,0,1],
["&nbsp;HRD","company/hrd.htm",1,0,1],
["&nbsp;Finance","company/finance.htm",1,0,1],
["&nbsp;Procurement Policy","#",1,0,1],
["&nbsp;Assets","company/assets.htm",1,0,0],
["&nbsp;Results","company/achivement.htm",1,0,0],
["&nbsp;Growth Plan","company/growth.htm",1,0,1],
//["&nbsp;Alliances","company/allience.htm",1,0,0],
["&nbsp;Information Technology","company/it.htm",1,0,0],
["&nbsp;Social Commitment","company/social_commitment.htm",1,0,0],
]

HM_Array1_2 = [
[],
["&nbsp;Mission & Vision","company/vision.htm",1,0,0],
//["&nbsp;Objective","company/objective.htm",1,0,0],
["&nbsp;Chairman's Desk","company/chairman_desk.htm",1,0,0],
["&nbsp;Board of Directors","company/board_directors.htm",1,0,0],
]
HM_Array1_3 = [
[],
["&nbsp;Organization","company/organization.htm",1,0,0],
["&nbsp;Staff","company/staff.htm",1,0,0],
["&nbsp;Jobs","company/job.htm",1,0,0],
]


HM_Array1_4 = [
[],
["&nbsp;Revenue","company/revenue.htm",1,0,0],
["&nbsp;Capital Investment","company/capital_investment.htm",1,0,0],
["&nbsp;Capital Outlay","company/comultive.htm",1,0,0],
]

HM_Array1_5 = [
[],
["&nbsp;MS Word format","company/pro_policy.doc",1,0,0],
["&nbsp;PDF format","company/pro_policy.pdf",1,0,0],
["&nbsp;WinZip format","company/pro_policy.zip",1,0,0],
]

HM_Array1_8 = [
[],
["&nbsp;National Internet Backbone","company/sanchar.htm",1,0,0],
]


HM_Array2 = [
[,         // menu width
70,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;Telephone","service/telephone.htm",1,0,1],
["&nbsp;Mobile Phone","service/mobile.htm",1,0,1],
["&nbsp;WLL Phone","service/wll.htm",1,0,0],
["&nbsp;Internet","service/internet.htm",1,0,1],
["&nbsp;Broadband(DataOne)","service/dataone.htm",1,0,1],
["&nbsp;MPLS VPN","service/mplsvpn.htm",1,0,0],
["&nbsp;ISDN","service/isdn.htm",1,0,1],
["&nbsp;Leased Line","service/leased.htm",1,0,1],
["&nbsp;Intelligent Network(IN)","service/inteligent_network.htm",1,0,1],
["&nbsp;I-Net","service/inet.htm",1,0,1],
["&nbsp;Telex/Telegraph","service/telex.htm",1,0,1],
["&nbsp;EPABX","service/epebx.htm",1,0,1],
["&nbsp;HV Net","service/hvnet.htm",1,0,0],
["&nbsp;RABMN","service/rabmn.htm",1,0,1],
["&nbsp;INSAT","service/insat.htm",1,0,0],
["&nbsp;INMARSAT","service/inmarsat.htm",1,0,0],
["&nbsp;KU-Band","service/kuband.htm",1,0,0],
["&nbsp;Transponder","service/transponder.htm",1,0,0],


]

HM_Array2_12 = [
[],
["&nbsp;EPABX","service/epebx.htm",1,0,0],
["&nbsp;Tariff","service/epebx_tariff.htm",1,0,0],
["&nbsp;Centrex","service/centrex.htm",1,0,0],
["&nbsp;Centrex Tariff","service/centrex_tariff.htm",1,0,0],
]


HM_Array2_10 = [
[],
["&nbsp;Overview","service/inet_network.htm",1,0,0],
["&nbsp;Services on I-NET","service/inet_services.htm",1,0,0],
["&nbsp;Using I-NET","service/inet_using.htm",1,0,0],
["&nbsp;I-Net Connections","service/inet_connection.htm",1,0,0],
["&nbsp;I-Net Tariff","service/inet_tariff.htm",1,0,0],
]


HM_Array2_9 = [
[],
["&nbsp;Free-phone Service","service/fph.htm",1,0,0],
["&nbsp;Premium Rate Service","service/prm.htm",1,0,0],
["&nbsp;India Telephone Card","service/itc.htm",1,0,0],
["&nbsp;Virtual Private Network","service/vpn.htm",1,0,0],
["&nbsp;Universal Number","service/un.htm",1,0,0],
["&nbsp;Tele voting","service/in_network1.htm#1",1,0,0],
]

HM_Array2_4 = [
[],
["&nbsp;Network","service/internet_network.htm",1,0,0],
["&nbsp;Types of Access","service/internet_typeofaccess.htm",1,0,0],
["&nbsp;Co-location Service","service/web-colocation.htm",1,0,0],
["&nbsp;Web Hosting","service/webhosting.htm",1,0,0],
["&nbsp;Internet Tariff","service/internet_tariff_home.htm",1,0,0],
["&nbsp;Sancharnet","http://www.sancharnet.in",1,0,0],
["&nbsp;Webfone","http://webfone.bsnl.co.in/",1,0,0],

]

HM_Array2_7 = [
[],
["&nbsp;ISDN","service/isdn.htm",1,0,0],
["&nbsp;Tariff","service/isdn_tariff.htm",1,0,0],
]

HM_Array2_8 = [
[],
["&nbsp;Leased Line","service/leased.htm",1,0,0],
["&nbsp;Tariff","service/leased_tariff.htm",1,0,0],
]

HM_Array2_2 = [
[],
["&nbsp;CellOne","service/mobile_cellone.htm",1,0,0],
["&nbsp;Excel","service/mobile_excel.htm",1,0,0],
["&nbsp;Unified Messaging","service/mobile_ums.htm",1,0,0],
["&nbsp;GPRS/WAP/MMS","service/mobile_gprswap.htm",1,0,0],
["&nbsp;Demos","service/mobile_demos.htm",1,0,0],
["&nbsp;Tariff","service/mobile_tariff.htm",1,0,0],
]

HM_Array2_5 = [
[],
["&nbsp;Register Online","service/dataoneform.php",1,0,0],
]

HM_Array2_1 = [
[],
["&nbsp;Phone Plus Services","service/plus.htm",1,0,0],
["&nbsp;New Telephone Con.","service/telephone_new.htm",1,0,0],
["&nbsp;Permanent Connection","service/permanent.htm",1,0,0],
["&nbsp;Concessions in Rentals","service/telephone_concesstion.htm",1,0,0],
["&nbsp;Shift of Telephones","service/shift.htm",1,0,0],
["&nbsp;Transfer of Telephones","service/transfer.htm",1,0,0],
["&nbsp;Telephone Tariff","service/tele_tariff.htm",1,0,0],
]

HM_Array2_11 = [
[],
["&nbsp;Telex/Telegraph","service/telex.htm",1,0,0],
["&nbsp;Tariff","service/telex_1.htm",1,0,0],
]

HM_Array2_10_2 = [
[],
["&nbsp;Telex Charges","service/telex_1.htm",1,0,0],
["&nbsp;Telegrams","service/telegrams.htm",1,0,0],
["&nbsp;Bureaufax services","service/bureaufax.htm",1,0,0],
]

HM_Array3 = [
[,         // menu width
135,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;Telephone","network/telephone.htm",1,0,0],
["&nbsp;Telegraph & Telex","network/telex.htm",1,0,0],
["&nbsp;Mobile Service","network/mobile.htm",1,0,0],
["&nbsp;Data Network","network/data.htm",1,0,0],
["&nbsp;NIB","network/nib.htm",1,0,0],
["&nbsp;Customer Service Centers","network/cust_care_center.htm",1,0,0],
//["&nbsp;Network Statistics","network/statistic.htm",1,0,0],
]

HM_Array3_7 = [
[],
["&nbsp;1000 dels","network/statistic9.htm",1,0,0],

["&nbsp;Employee","network/statistic10.htm",1,0,0],
["&nbsp;Outlay per annum","network/statistic2.htm",1,0,0],
["&nbsp;Psus","network/statistic8.htm",1,0,0],
["&nbsp;Surplus and capital","network/statistic1.htm",1,0,0],
["&nbsp;Telecom network","network/statistic6.htm",1,0,0],
["&nbsp;Tele-density","network/statistic3.htm",1,0,0],
["&nbsp;Value added","network/statistic5.htm",1,0,0],
["&nbsp;Vpts and Pcos","network/statistic4.htm",1,0,0],
["&nbsp;Waiting List and MCUs","network/statistic.htm",1,0,0],
]


HM_Array4 = [
[,         // menu width
225,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;Tenders","tenderindex.php",1,0,1],
["&nbsp;For Customers","newsindex.php",1,0,1],
]

HM_Array4_1 = [
[],
["&nbsp;Forthcoming Tenders","tenderindex.php",1,0,0],
["&nbsp;Get updates on e-mail","tender1/newuserreg.php",1,0,0],
["&nbsp;Archive","tender1/archive3.php",1,0,0],
]
HM_Array4_2 = [
[],
["&nbsp;Archive","newsarchive.php",1,0,0],
]


HM_Array5 = [
[,         // menu width
317,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;BSNL Portal","http://www.bsnl.in",1,0,0],
["&nbsp;BSNL Units","bsnl_unit.htm",1,0,0],
["&nbsp;Sancharnet","http://www.sancharnet.in",1,0,0],
["&nbsp;Web Fone","http://webfone.sancharnet.in",1,0,0],
["&nbsp;Cellular Unified Messaging ","#",1,0,1],
["&nbsp;Useful links","useful_site.htm",1,0,0],

]

HM_Array5_5 = [
[],
["&nbsp;North Zone","http://www.bsnlumn.com",1,0,0],
["&nbsp;South Zone","http://www.bsnlums.com",1,0,0],
["&nbsp;East Zone","http://www.bsnlume.com",1,0,0],
["&nbsp;West  Zone","http://www.bsnlumw.com",1,0,0],
]


HM_Array6 = [
[,         // menu width
390,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;India Telephone Directory","map.htm",1,0,1],
["&nbsp;Search STD Codes","stdsearch.php",1,0,0],
["&nbsp;Search ISD Codes","isdsearch.php",1,0,0],
["&nbsp;Online Billing Information","service/onlinebilling.htm",1,0,0],
["&nbsp;Services in Metros","#",1,0,1],
["&nbsp;Senior Officers Directory","directory_officer.htm",1,0,0],
["&nbsp;Toll Free Numbers","service/tollfree.htm",1,0,0],
]

HM_Array6_1 = [
[],
["&nbsp;On India Map","map.htm",1,0,0],
["&nbsp;State Wise ","onlinedirectory.htm",1,0,0],
["&nbsp;Find a City","citysearch.php",1,0,0],
]

HM_Array6_5 = [
[],
["&nbsp;Delhi","http://delhi.mtnl.net.in",1,0,0],
["&nbsp;Mumbai","http://mumbai.mtnl.net.in",1,0,0],
["&nbsp;Chennai","http://chennai.bsnl.co.in",1,0,0],
["&nbsp;Kolkata","http://kolkata.bsnl.co.in",1,0,0],
]


HM_Array7 = [
[,         // menu width
528,       // left_position
71,       // top_position
,,,,,,
0,         // top_is_permanent
0,         // top_is_horizontal
0,         // tree_is_horizontal
1,         // position_under
1,         // top_more_images_visible
1,         // tree_more_images_visible
"null",    // evaluate_upon_tree_show
"null",    // evaluate_upon_tree_hide
,          // right_to_left
],        // display_on_click
["&nbsp;Forms","forms.htm",1,0,0],
["&nbsp;Webfone Dialer","http://webfone.bsnl.co.in/Webfone-download.htm",1,0,0],
]

