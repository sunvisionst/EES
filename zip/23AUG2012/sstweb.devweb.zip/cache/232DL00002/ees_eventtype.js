document.write('<option value=></option>');
document.write('<option value=E>News and Alerts</option>');
document.write('<option value=A>Article</option>');
