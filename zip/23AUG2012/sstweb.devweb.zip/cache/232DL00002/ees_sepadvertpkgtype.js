document.write('<option value=></option>');
document.write('<option value=00000>Showroom</option>');
document.write('<option value=00010>Top Bar</option>');
document.write('<option value=00020>Side Bar</option>');
document.write('<option value=00030>General Listing</option>');
document.write('<option value=90000>On Application Page</option>');
