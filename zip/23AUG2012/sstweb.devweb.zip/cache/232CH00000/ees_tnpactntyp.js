document.write('<option value=></option>');
document.write('<option value=T>Telephone</option>');
document.write('<option value=M>E-Mail</option>');
document.write('<option value=V>Company Visit</option>');
document.write('<option value=C>Campus Interview</option>');

