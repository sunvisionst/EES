document.write('<option value=></option>');
document.write('<option value=A>GradeA</option>');
document.write('<option value=B>GradeA</option>');
document.write('<option value=C>GradeA</option>');
document.write('<option value=D>GradeA</option>');
