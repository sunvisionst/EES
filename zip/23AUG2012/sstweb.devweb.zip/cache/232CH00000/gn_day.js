document.write('<option value=></option>');
document.write('<option value=1>SUN</option>');
document.write('<option value=2>MON</option>');
document.write('<option value=3>TUE</option>');
document.write('<option value=4>WED</option>');
document.write('<option value=5>THU</option>');
document.write('<option value=6>FRI</option>');
document.write('<option value=7>SAT</option>');
