document.write('<option value=></option>');
document.write('<option value=1>First</option>');
document.write('<option value=2>Second</option>');
document.write('<option value=3>Third</option>');
document.write('<option value=4>Fourth</option>');
document.write('<option value=5>Fifth</option>');
