document.write('<option value=></option>');
document.write('<option value=B>Bank</option>');
document.write('<option value=T>Travel Agent</option>');
document.write('<option value=R>Recruitment Agent</option>');
document.write('<option value=N>News Agency</option>');
document.write('<option value=EH>ESI Hospital</option>');
