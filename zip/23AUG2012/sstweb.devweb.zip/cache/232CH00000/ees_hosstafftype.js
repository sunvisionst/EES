document.write('<option value=></option>');
document.write('<option value=W>Warden</option>');
document.write('<option value=RW>Resident Warden</option>');
