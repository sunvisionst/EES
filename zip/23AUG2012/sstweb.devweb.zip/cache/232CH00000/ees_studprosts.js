document.write('<option value=></option>');
document.write('<option value=P>Pass</option>');
document.write('<option value=F>Fail</option>');
document.write('<option value=S>Special Promotion</option>');
