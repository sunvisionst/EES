document.write('<option value=></option>');
document.write('<option value=N>Not Required</option>');
document.write('<option value=E>Extra Value</option>');
