document.write('<option value=></option>');
document.write('<option value=Y>Yearly</option>');
document.write('<option value=Q>Quarterly</option>');
