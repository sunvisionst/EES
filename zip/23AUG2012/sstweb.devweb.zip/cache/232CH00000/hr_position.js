document.write('<option value=></option>');
document.write('<option value=100>Principal</option>');
document.write('<option value=110>Registrar</option>');
document.write('<option value=120>HOD</option>');
document.write('<option value=140>Lecturer</option>');
document.write('<option value=150>Lab Assistant</option>');
