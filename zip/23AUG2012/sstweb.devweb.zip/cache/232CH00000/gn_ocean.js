document.write('<option value=></option>');
document.write('<option value=IO>Indian</option>');
document.write('<option value=PO>Pecific</option>');
