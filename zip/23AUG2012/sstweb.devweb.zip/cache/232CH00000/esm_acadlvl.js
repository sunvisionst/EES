document.write('<option value=></option>');
document.write('<option value=1>10</option>');
document.write('<option value=2>12</option>');
document.write('<option value=3>Graduation</option>');
document.write('<option value=4>Master</option>');
