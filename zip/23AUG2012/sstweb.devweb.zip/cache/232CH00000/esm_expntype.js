document.write('<option value=></option>');
document.write('<option value=L>Local Conveyance</option>');
document.write('<option value=B>Book</option>');
document.write('<option value=G>GeneralExpense</option>');
