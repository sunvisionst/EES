document.write('<option value=></option>');
document.write('<option value=EES>EES</option>');
document.write('<option value=ESM>ESM</option>');
document.write('<option value=EHS>EHS</option>');
