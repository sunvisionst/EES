document.write('<option value=></option>');
document.write('<option value=M>Mozilla</option>');
document.write('<option value=IE>Internet Explorer</option>');
document.write('<option value=O>Opera</option>');
document.write('<option value=FF>Firefox</option>');
