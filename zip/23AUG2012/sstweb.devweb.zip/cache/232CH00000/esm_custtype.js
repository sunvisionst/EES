document.write('<option value=></option>');
document.write('<option value=B>Branch</option>');
document.write('<option value=C>Direct Customer</option>');
document.write('<option value=D>Dealer</option>');
document.write('<option value=O>OEM</option>');
