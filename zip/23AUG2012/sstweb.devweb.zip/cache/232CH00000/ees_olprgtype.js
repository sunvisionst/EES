document.write('<option value=></option>');
document.write('<option value=C>C Program</option>');
document.write('<option value=CPP>C++ Program</option>');
document.write('<option value=JAVA>Java Program</option>');
document.write('<option value=PHP>PHP Scripting</option>');
document.write('<option value=JSP>Java Servlet Pages</option>');
document.write('<option value=SQL>SQL Script</option>');
