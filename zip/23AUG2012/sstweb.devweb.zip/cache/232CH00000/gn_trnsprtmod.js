document.write('<option value=></option>');
document.write('<option value=A>By Air</option>');
document.write('<option value=C>By Courier</option>');
document.write('<option value=R>By Road</option>');
document.write('<option value=S>By Ship</option>');
document.write('<option value=T>By Train</option>');
