document.write('<option value=></option>');
document.write('<option value=P>Planned</option>');
document.write('<option value=U>UnPlanned</option>');
document.write('<option value=E>ETS</option>');
