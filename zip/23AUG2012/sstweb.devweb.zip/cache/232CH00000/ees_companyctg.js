document.write('<option value=></option>');
document.write('<option value=D>DREAM</option>');
document.write('<option value=G>GENERAL</option>');
