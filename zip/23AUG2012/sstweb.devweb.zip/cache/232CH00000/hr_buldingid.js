document.write('<option value=></option>');
document.write('<option value=Block_A>Block A</option>');
document.write('<option value=Block_B>Block B</option>');
document.write('<option value=Block_C>Block C</option>');
document.write('<option value=Block_D>Block D</option>');
