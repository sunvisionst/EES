document.write('<option value=></option>');
document.write('<option value=T>Telephone</option>');
document.write('<option value=M>E-Mail</option>');

