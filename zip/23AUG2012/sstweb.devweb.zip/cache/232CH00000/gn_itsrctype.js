document.write('<option value=></option>');
document.write('<option value=S>Supplier</option>');
document.write('<option value=P>Production</option>');
