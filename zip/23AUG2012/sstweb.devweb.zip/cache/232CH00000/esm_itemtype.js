document.write('<option value=></option>');
document.write('<option value=F>Finish Goods</option>');
document.write('<option value=R>Raw Material</option>');
