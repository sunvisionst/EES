document.write('<option value=></option>');
document.write('<option value=C>Company</option>');
document.write('<option value=I>Individual</option>');
