document.write('<option value=></option>');
document.write('<option value=A>Ashoka</option>');
document.write('<option value=TO>Toyota</option>');
document.write('<option value=M>Maruti</option>');
document.write('<option value=F>Ford</option>');
document.write('<option value=H>Honda</option>');
document.write('<option value=TA>Tata</option>');
