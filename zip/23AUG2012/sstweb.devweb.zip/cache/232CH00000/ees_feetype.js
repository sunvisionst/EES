document.write('<option value=></option>');
document.write('<option value=99>Admission</option>');
document.write('<option value=98>Hostel</option>');
document.write('<option value=97>Transport</option>');
document.write('<option value=96>Exam</option>');
document.write('<option value=95>Fine</option>');
document.write('<option value=94>Misc</option>');
