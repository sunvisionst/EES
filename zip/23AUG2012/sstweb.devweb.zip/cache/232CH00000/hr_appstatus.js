document.write('<option value=></option>');
document.write('<option value=A>Applied</option>');
document.write('<option value=WT>Shortlisted for Written Test</option>');
document.write('<option value=I>Shortlisted for Interview</option>');
document.write('<option value=R>Rejected</option>');
document.write('<option value=S>Selected</option>');
