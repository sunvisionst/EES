document.write('<option value=></option>');
document.write('<option value=C>Cash</option>');
document.write('<option value=CH>Check</option>');
document.write('<option value=D>Draft</option>');
