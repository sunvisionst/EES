document.write('<option value=></option>');
document.write('<option value=E>Event</option>');
document.write('<option value=A>Announcement</option>');
