document.write('<option value=></option>');
document.write('<option value=S>Son</option>');
document.write('<option value=D>Daughter</option>');
document.write('<option value=W>Wife</option>');
document.write('<option value=H>Husband</option>');
document.write('<option value=N>Nephew</option>');
document.write('<option value=B>Brother</option>');
document.write('<option value=F>Father</option>');
