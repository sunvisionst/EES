document.write('<option value=></option>');
document.write('<option value=1>ADM</option>');
document.write('<option value=2>IT</option>');
