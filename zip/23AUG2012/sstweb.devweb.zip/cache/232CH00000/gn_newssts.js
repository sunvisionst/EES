document.write('<option value=></option>');
document.write('<option value=A>Approved</option>');
document.write('<option value=C>Being Created</option>');
document.write('<option value=D>To Delete</option>');
document.write('<option value=R>To Amend</option>');
document.write('<option value=S>Sent</option>');
