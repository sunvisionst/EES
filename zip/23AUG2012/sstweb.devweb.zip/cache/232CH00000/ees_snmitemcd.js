document.write('<option value=></option>');
document.write('<option value=FU>Fuel</option>');
document.write('<option value=RE>Repairing</option>');
document.write('<option value=WA>Washing</option>');
document.write('<option value=PR>Part Replacement</option>');
document.write('<option value=RS>Regular Service</option>');
