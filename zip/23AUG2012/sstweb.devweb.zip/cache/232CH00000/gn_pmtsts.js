document.write('<option value=></option>');
document.write('<option value=O>Pending</option>');
document.write('<option value=PP>Partial Payment</option>');
document.write('<option value=FP>Full Payment</option>');
document.write('<option value=C>Close</option>');
