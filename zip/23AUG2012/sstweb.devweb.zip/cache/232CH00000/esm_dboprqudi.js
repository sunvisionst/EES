document.write('<option value=></option>');
document.write('<option value=Q>Query</option>');
document.write('<option value=U>Update</option>');
document.write('<option value=D>Delete</option>');
document.write('<option value=I>Insert</option>');
