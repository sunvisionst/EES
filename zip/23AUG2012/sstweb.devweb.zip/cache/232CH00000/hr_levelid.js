document.write('<option value=></option>');
document.write('<option value=10th>10th</option>');
document.write('<option value=12th>12th</option>');
document.write('<option value=GRADUATE>Graduate</option>');
document.write('<option value=PG>Post Graduate</option>');
