document.write('<option value=></option>');
document.write('<option value=IC>IC</option>');
document.write('<option value=ME>ME</option>');
document.write('<option value=BC>BC</option>');
document.write('<option value=PLC>PLC</option>');
document.write('<option value=FBR>FBR</option>');
document.write('<option value=BB>BB</option>');
document.write('<option value=OG>OG</option>');
