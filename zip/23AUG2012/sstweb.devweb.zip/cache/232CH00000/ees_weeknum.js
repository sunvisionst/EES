document.write('<option value=></option>');
document.write('<option value=1>1st</option>');
document.write('<option value=2>2nd</option>');
document.write('<option value=3>3rd</option>');
document.write('<option value=4>4th</option>');
document.write('<option value=5>5th</option>');
