document.write('<option value=></option>');
document.write('<option value=B>VOTER ID</option>');
document.write('<option value=D>DRIVING LISENCE</option>');
document.write('<option value=S>SOCIAL SECURITY ID</option>');
document.write('<option value=P>PASSPORT</option>');
