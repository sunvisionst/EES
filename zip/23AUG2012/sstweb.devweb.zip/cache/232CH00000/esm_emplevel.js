document.write('<option value=></option>');
document.write('<option value=L1>Level 1</option>');
document.write('<option value=L2>Level 2</option>');
document.write('<option value=L3>Level 3</option>');
document.write('<option value=L4>Level 4</option>');
