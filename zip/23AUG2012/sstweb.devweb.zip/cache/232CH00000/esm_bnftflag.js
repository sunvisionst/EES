document.write('<option value=></option>');
document.write('<option value=A>Allowances</option>');
document.write('<option value=V>Vacation</option>');
