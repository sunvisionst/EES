document.write('<option value=></option>');
document.write('<option value=S>Single</option>');
document.write('<option value=E>ETS</option>');
document.write('<option value=X>Exam</option>');
document.write('<option value=M>Multiple</option>');
