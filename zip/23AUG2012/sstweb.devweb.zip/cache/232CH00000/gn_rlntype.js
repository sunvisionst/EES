document.write('<option value=></option>');
document.write('<option value=F>FATHER</option>');
document.write('<option value=M>MOTHER</option>');
document.write('<option value=B>BROTHER</option>');
document.write('<option value=S>SISTER</option>');
document.write('<option value=D>FRIEND</option>');
