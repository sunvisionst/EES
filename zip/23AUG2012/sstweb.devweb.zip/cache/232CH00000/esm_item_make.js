document.write('<option value=></option>');
document.write('<option value=IBM>IBM</option>');
document.write('<option value=HP>HP</option>');
document.write('<option value=SONY>SONY</option>');
