document.write('<option value=></option>');
document.write('<option value=P>Present</option>');
document.write('<option value=A>Absent</option>');
document.write('<option value=H>Halfday</option>');
document.write('<option value=W>Weakend</option>');
