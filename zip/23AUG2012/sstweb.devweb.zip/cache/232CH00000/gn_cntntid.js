document.write('<option value=></option>');
document.write('<option value=Asia>Asia</option>');
document.write('<option value=NA>North America</option>');
document.write('<option value=SA>South America</option>');
document.write('<option value=EU>Europe</option>');
document.write('<option value=AUS>Australlia</option>');
document.write('<option value=ANTK>Antartika</option>');
