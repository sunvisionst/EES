document.write('<option value=></option>');
document.write('<option value=1>Employee Level</option>');
document.write('<option value=2>Zonal Level</option>');
