document.write('<option value=></option>');
document.write('<option value=C>Comp. System</option>');
document.write('<option value=O>Others</option>');
