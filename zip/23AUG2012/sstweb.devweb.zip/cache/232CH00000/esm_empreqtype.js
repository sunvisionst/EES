document.write('<option value=></option>');
document.write('<option value=1>Shift Change Request</option>');
document.write('<option value=2>Shift Swap Request</option>');
document.write('<option value=3>Early Coming</option>');
document.write('<option value=4>Late Going</option>');
