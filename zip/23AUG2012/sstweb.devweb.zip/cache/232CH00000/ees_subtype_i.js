document.write('<option value=></option>');
document.write('<option value=D>DBMS</option>');
document.write('<option value=J>Java</option>');
document.write('<option value=MI>MIS</option>');
document.write('<option value=W>Web Tech.</option>');
document.write('<option value=U>Unix</option>');
document.write('<option value=CO>Comp. Organization</option>');
document.write('<option value=S>Soft. Engineering</option>');
