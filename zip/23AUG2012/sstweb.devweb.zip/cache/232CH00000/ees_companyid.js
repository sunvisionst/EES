document.write('<option value=></option>');
document.write('<option value=2006/0001>Ghtat</option>');
document.write('<option value=2007/1002>Sunvision</option>');
document.write('<option value=2007/1003>SysDos</option>');
document.write('<option value=2007/1004>TCS</option>');
