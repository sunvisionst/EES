document.write('<option value=></option>');
document.write('<option value=S>Standard</option>');
document.write('<option value=L>Loan</option>');
document.write('<option value=A>Advance</option>');
document.write('<option value=I>Imprest</option>');
