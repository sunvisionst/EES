document.write('<option value=></option>');
document.write('<option value=A>Assets</option>');
document.write('<option value=I>Income</option>');
document.write('<option value=E>Expense</option>');
document.write('<option value=L>Libilities</option>');
