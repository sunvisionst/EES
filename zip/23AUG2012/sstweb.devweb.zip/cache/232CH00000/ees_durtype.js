document.write('<option value=></option>');
document.write('<option value=S>Semester</option>');
document.write('<option value=Y>Yearly</option>');
document.write('<option value=M>Monthly</option>');
