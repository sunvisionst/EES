document.write('<option value=></option>');
document.write('<option value=S>Service</option>');
document.write('<option value=B>Business</option>');
document.write('<option value=O>Others</option>');
