document.write('<option value=></option>');
document.write('<option value=1>Open</option>');
document.write('<option value=0>Close</option>');
