document.write('<option value=></option>');
document.write('<option value=1>1st</option>');
document.write('<option value=3>3rd</option>');
