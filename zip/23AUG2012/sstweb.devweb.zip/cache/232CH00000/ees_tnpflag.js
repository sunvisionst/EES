document.write('<option value=></option>');
document.write('<option value=T>Training</option>');
document.write('<option value=P>Placement</option>');
document.write('<option value=B>Both</option>');
