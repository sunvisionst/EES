document.write('<option value=></option>');
document.write('<option value=C>Complete</option>');
document.write('<option value=P>Pending</option>');
