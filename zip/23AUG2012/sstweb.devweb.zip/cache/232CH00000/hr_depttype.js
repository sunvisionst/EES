document.write('<option value=></option>');
document.write('<option value=I>INTERNAL</option>');
document.write('<option value=O>OUTSOURCE</option>');
document.write('<option value=A>ACADEMIC</option>');
document.write('<option value=N>NON ACADEMIC</option>');
