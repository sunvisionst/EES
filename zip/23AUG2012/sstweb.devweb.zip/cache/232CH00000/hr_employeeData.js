document.write('<OPTION VALUE=></OPTION>');
document.write('<OPTION VALUE=1>RajeshVerma</OPTION>');
document.write('<OPTION VALUE=2>MeeraVerma</OPTION>');
