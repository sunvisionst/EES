document.write('<option value=></option>');
document.write('<option value=T>Two Wheeler</option>');
document.write('<option value=FC>Four Wheeler Car</option>');
document.write('<option value=FM>Four Wheeler Mini</option>');
document.write('<option value=FL>Four Wheeler Large</option>');
document.write('<option value=FV>Four Wheeler Van</option>');
