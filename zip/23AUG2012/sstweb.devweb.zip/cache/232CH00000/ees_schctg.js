document.write('<option value=></option>');
document.write('<option value=A>A</option>');
document.write('<option value=B>B</option>');
