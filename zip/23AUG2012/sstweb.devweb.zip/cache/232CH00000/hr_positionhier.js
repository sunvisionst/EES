document.write('<option value=></option>');
document.write('<option value=1000>Heir 1</option>');
document.write('<option value=2000>Heir 2</option>');
document.write('<option value=3000>Heir 3</option>');
document.write('<option value=4000>Heir 4</option>');
document.write('<option value=5000>Hier 5</option>');
document.write('<option value=6000>Hier 6</option>');
