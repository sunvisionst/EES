document.write('<option value=></option>');
document.write('<option value=P>Pcs</option>');
document.write('<option value=K>KG</option>');
document.write('<option value=T>Ton</option>');
