document.write('<option value=></option>');
document.write('<option value=C>Corres</option>');
document.write('<option value=D>Delivery Address</option>');
document.write('<option value=I>Invoicing/Billing Address</option>');
document.write('<option value=R>Org Regd</option>');
document.write('<option value=W>Work Address</option>');
document.write('<option value=N>New Address</option>');
