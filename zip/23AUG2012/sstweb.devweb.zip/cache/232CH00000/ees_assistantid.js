document.write('<option value=></option>');
document.write('<option value=1001>1001</option>');
document.write('<option value=9001>9001</option>');
