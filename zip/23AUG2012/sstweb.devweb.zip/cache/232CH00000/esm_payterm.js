document.write('<option value=></option>');
document.write('<option value=20>On Sight (20 Days)</option>');
document.write('<option value=60>60 Days</option>');
document.write('<option value=90>90 Days</option>');
