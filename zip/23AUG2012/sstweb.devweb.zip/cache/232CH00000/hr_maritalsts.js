document.write('<option value=></option>');
document.write('<option value=S>Single</option>');
document.write('<option value=M>Married</option>');
document.write('<option value=D>Divorced</option>');
document.write('<option value=W>Widow</option>');
