document.write('<option value=></option>');
document.write('<option value=T>Text Book</option>');
document.write('<option value=R>Reference Book</option>');
