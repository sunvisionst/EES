document.write('<option value=></option>');
document.write('<option value=D>Domestic</option>');
document.write('<option value=F>Foreign</option>');
