document.write('<option value=></option>');
document.write('<option value=AL>Allocated</option>');
document.write('<option value=AS>Assigned</option>');
document.write('<option value=C>Close</option>');
document.write('<option value=O>Open</option>');
document.write('<option value=F>Fixed</option>');
