document.write('<option value=></option>');
document.write('<option value=CA>Cash</option>');
document.write('<option value=CQ>Cheque</option>');
document.write('<option value=DD>Demand Draft</option>');
document.write('<option value=CC>Credit Card</option>');
