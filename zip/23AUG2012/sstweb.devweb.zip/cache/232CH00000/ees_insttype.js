document.write('<option value=></option>');
document.write('<option value=Y>Yearly</option>');
document.write('<option value=M>Monthly</option>');
document.write('<option value=H>Half Yearly</option>');
document.write('<option value=N>No Installment</option>');
