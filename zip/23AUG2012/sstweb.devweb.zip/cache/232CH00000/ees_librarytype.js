document.write('<option value=></option>');
document.write('<option value=I>IT</option>');
document.write('<option value=M>Management</option>');
document.write('<option value=L>Law</option>');
