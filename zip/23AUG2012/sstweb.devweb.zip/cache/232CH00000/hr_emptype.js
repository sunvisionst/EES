document.write('<option value=></option>');
document.write('<option value=P>Permanent</option>');
document.write('<option value=C>Contract</option>');
document.write('<option value=A>Ad-hoc</option>');
document.write('<option value=HS>Hostel</option>');
