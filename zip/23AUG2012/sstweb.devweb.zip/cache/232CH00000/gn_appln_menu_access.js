function returnMenu( inUserId, inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{
  for (;;)
  {
    var menu;
    if ( inUserId == 'SSTSU' )    { menu = return_SSTSU_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'sstguest' )    { menu = return_sstguest_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'Shailendra' )    { menu = return_Shailendra_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'Maneesh' )    { menu = return_Maneesh_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'Anand' )    { menu = return_Anand_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'vivek' )    { menu = return_vivek_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'Mohit' )    { menu = return_Mohit_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'Prabodh' )    { menu = return_Prabodh_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
    if ( inUserId == 'SHAN' )    { menu = return_SHAN_Menu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY ); break; }
  break;
  }
  rteurn menu;
}
