document.write('<option value=></option>');
document.write('<option value=R>Radio</option>');
document.write('<option value=C>Checkbox</option>');
document.write('<option value=N>Numeric</option>');
