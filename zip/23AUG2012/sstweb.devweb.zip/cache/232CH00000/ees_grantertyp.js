document.write('<option value=></option>');
document.write('<option value=A>Alumini</option>');
document.write('<option value=G>Govt.Org</option>');
document.write('<option value=P>Private Org</option>');
document.write('<option value=O>Others</option>');
