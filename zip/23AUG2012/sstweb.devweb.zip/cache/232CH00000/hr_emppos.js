document.write('<option value=></option>');
document.write('<option value=EMP>Employee</option>');
document.write('<option value=MGR>Manager</option>');
document.write('<option value=3>TL</option>');
document.write('<option value=4>PL</option>');
document.write('<option value=5>PM</option>');
