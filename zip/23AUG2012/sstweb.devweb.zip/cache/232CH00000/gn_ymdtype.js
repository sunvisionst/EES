document.write('<option value=></option>');
document.write('<option value=D>Day</option>');
document.write('<option value=M>Month</option>');
document.write('<option value=Y>Year</option>');
