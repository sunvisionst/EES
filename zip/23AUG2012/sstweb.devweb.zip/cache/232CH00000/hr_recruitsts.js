document.write('<option value=></option>');
document.write('<option value=O>Open</option>');
document.write('<option value=RP>Request Pending</option>');
