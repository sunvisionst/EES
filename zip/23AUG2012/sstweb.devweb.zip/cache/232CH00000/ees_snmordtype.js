document.write('<option value=></option>');
document.write('<option value=FU>Fuel</option>');
document.write('<option value=SNM>Service and Maint.</option>');
