document.write('<option value=></option>');
document.write('<option value=CA>Cash</option>');
document.write('<option value=CQ>Cheque</option>');
document.write('<option value=PA>Pay Card</option>');
document.write('<option value=BA>Bank Account</option>');
