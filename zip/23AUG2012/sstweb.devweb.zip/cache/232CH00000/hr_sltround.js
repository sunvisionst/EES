document.write('<option value=></option>');
document.write('<option value=T>Technical Interview</option>');
document.write('<option value=W>Written</option>');
document.write('<option value=G>Group Discussion</option>');
document.write('<option value=H>HR Interview</option>');
