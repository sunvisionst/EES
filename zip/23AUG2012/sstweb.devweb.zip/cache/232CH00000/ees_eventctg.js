document.write('<option value=></option>');
document.write('<option value=CE>Cultural</option>');
document.write('<option value=S>Sport</option>');
document.write('<option value=L>Lecture</option>');
document.write('<option value=OT>Outside Tour</option>');
document.write('<option value=CO>Camp Outing</option>');
document.write('<option value=AC>Award Ceremony</option>');
document.write('<option value=O>Other</option>');
