document.write('<option value=></option>');
document.write('<option value=C>Contractual</option>');
document.write('<option value=T>Temporary</option>');
