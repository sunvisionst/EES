document.write('<option value=></option>');
document.write('<option value=P>Passed</option>');
document.write('<option value=N>Not Passed</option>');
