document.write('<option value=></option>');
document.write('<option value=UP>U.P.</option>');
document.write('<option value=MP>M.P.</option>');
document.write('<option value=DEL>Delhi</option>');
document.write('<option value=MAH>Maharastra</option>');
document.write('<option value=UTK>UTK</option>');
