document.write('<option value=></option>');
document.write('<option value=FOB>Frieght on board</option>');
document.write('<option value=C&F>Cost and Frieght</option>');
document.write('<option value=CIF>Cost Insurance And Frieght</option>');
