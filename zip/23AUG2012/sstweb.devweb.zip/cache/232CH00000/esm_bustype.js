document.write('<option value=></option>');
document.write('<option value=G>Govt</option>');
document.write('<option value=PSU>PSU</option>');
document.write('<option value=PVT>PVT</option>');
