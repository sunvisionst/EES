document.write('<option value=></option>');
document.write('<option value=KP>K.P.Singh</option>');
document.write('<option value=RNG>R.N.Govind Rao</option>');
document.write('<option value=BK>Brijesh Kumar</option>');
