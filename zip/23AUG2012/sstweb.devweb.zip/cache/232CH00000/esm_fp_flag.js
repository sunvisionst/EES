document.write('<option value=></option>');
document.write('<option value=F>Fixed</option>');
document.write('<option value=P>Percent</option>');
