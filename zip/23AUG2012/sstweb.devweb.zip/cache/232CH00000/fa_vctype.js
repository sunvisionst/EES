document.write('<option value=></option>');
document.write('<option value=S>Sale</option>');
document.write('<option value=P>Purchase</option>');
document.write('<option value=B>Bank</option>');
document.write('<option value=C>Cash</option>');
document.write('<option value=J>Journal</option>');
document.write('<option value=DN>Debit Note</option>');
document.write('<option value=CN>Credit Note</option>');
