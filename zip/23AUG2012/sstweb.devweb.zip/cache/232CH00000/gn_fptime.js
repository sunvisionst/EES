document.write('<option value=></option>');
document.write('<option value=F>FULL</option>');
document.write('<option value=P>PART</option>');
document.write('<option value=C>Correspondance</option>');
