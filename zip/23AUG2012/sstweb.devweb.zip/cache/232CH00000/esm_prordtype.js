document.write('<option value=></option>');
document.write('<option value=G>General/Std Production Order</option>');
document.write('<option value=R>Rework Production Order</option>');
document.write('<option value=S>Sample Production Order</option>');
document.write('<option value=SPL>Special Production Order</option>');
document.write('<option value=T>Tool Production Order</option>');
