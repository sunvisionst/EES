document.write('<option value=></option>');
document.write('<option value=CO>Computer</option>');
document.write('<option value=T>Table</option>');
document.write('<option value=F>Fan</option>');
document.write('<option value=CH>Chair</option>');
