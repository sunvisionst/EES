document.write('<option value=></option>');
document.write('<option value=C>Customer</option>');
document.write('<option value=S>Supplier</option>');
document.write('<option value=E>Employee</option>');
document.write('<option value=V>Vendor</option>');
document.write('<option value=ST>Student</option>');
