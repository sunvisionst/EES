document.write('<option value=></option>');
document.write('<option value=O>One Time</option>');
document.write('<option value=Y>Yearly</option>');
document.write('<option value=Q>Quarterly</option>');
document.write('<option value=H>Half Yearly</option>');
