document.write('<option value=></option>');
document.write('<option value=Y>Yes</option>');
document.write('<option value=N>No</option>');
