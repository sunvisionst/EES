document.write('<option value=></option>');
document.write('<option value=T>Theory</option>');
document.write('<option value=P>Practical</option>');
document.write('<option value=G>Games</option>');
document.write('<option value=M>Music</option>');
document.write('<option value=A>Arts</option>');
document.write('<option value=C>Craft</option>');
