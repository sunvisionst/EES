document.write('<option value=></option>');
document.write('<option value=I>Invoice</option>');
document.write('<option value=P>Purchase</option>');
document.write('<option value=S>Salary Slip</option>');
