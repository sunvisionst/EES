document.write('<option value=></option>');
document.write('<option value=HR>Human Resource</option>');
document.write('<option value=LAB>Lab</option>');
document.write('<option value=FA>Finance&Act</option>');
document.write('<option value=EXAM>Exam</option>');
document.write('<option value=ACD>Academic</option>');
