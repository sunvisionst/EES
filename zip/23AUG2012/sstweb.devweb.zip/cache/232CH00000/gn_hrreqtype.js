document.write('<option value=></option>');
document.write('<option value=SFTCNG>SHIFTCHANGE</option>');
document.write('<option value=SFTSWP>SHIFTSWAP</option>');
