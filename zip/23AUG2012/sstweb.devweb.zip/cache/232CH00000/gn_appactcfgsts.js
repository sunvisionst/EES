document.write('<option value=></option>');
document.write('<option value=O>Pending</option>');
document.write('<option value=C>Complete</option>');
document.write('<option value=A>Approved</option>');
