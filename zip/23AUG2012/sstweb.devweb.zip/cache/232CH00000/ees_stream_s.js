document.write('<option value=></option>');
document.write('<option value=S>Science</option>');
document.write('<option value=C>Commerce</option>');
document.write('<option value=A>Arts</option>');
