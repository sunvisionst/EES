document.write('<option value=></option>');
document.write('<option value=2W>Two Wheeler</option>');
document.write('<option value=4W>Four Wheeler</option>');
document.write('<option value=4WM>Four Wheeler Mini</option>');
document.write('<option value=4WL>Four Wheeler Large</option>');
