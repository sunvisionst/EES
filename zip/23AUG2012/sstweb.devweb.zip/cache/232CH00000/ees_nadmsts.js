document.write('<option value=></option>');
document.write('<option value=A>Approve</option>');
document.write('<option value=ANG>Admission Number Generated</option>');
document.write('<option value=P>Prospectus Fee Deposited</option>');
document.write('<option value=F>Applicant Id generated</option>');
document.write('<option value=RF>Prospectus Form Received</option>');
