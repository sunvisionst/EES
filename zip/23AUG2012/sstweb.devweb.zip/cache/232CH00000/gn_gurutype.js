document.write('<option value=></option>');
document.write('<option value=1>Atleast 10+ year experience</option>');
document.write('<option value=2>Atleast 5+ year experience</option>');
document.write('<option value=3>Atleast 2+ year experience</option>');
