document.write('<option value=></option>');
document.write('<option value=1>India</option>');
document.write('<option value=2>USA</option>');
