document.write('<option value=></option>');
document.write('<option value=1>1</option>');
document.write('<option value=2>2</option>');
