document.write('<option value=></option>');
document.write('<option value=A>Asia</option>');
document.write('<option value=N>North America</option>');
document.write('<option value=L>Australlia</option>');
document.write('<option value=F>Africa</option>');
document.write('<option value=E>Europe</option>');
document.write('<option value=S>South America</option>');
