document.write('<option value=></option>');
document.write('<option value=00>Government Service</option>');
document.write('<option value=01>Private Service</option>');
document.write('<option value=02>PSU Service</option>');
document.write('<option value=03>Industrialist</option>');
document.write('<option value=04>Self Employed</option>');
document.write('<option value=05>Freelancer</option>');
document.write('<option value=99>Other</option>');
