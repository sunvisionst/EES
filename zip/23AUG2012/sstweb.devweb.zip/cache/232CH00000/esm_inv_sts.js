document.write('<option value=></option>');
document.write('<option value=D>Dispatch</option>');
document.write('<option value=X>Cancel</option>');
