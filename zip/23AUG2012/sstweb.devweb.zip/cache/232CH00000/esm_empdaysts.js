document.write('<option value=></option>');
document.write('<option value=F>Full Day</option>');
document.write('<option value=H>Half Day</option>');
document.write('<option value=P>Partial</option>');
document.write('<option value=A>Full Absent</option>');
