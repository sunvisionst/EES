document.write('<option value=></option>');
document.write('<option value=I>Issue</option>');
document.write('<option value=R>Return</option>');
