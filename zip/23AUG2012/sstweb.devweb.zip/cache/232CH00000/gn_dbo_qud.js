document.write('<option value=></option>');
document.write('<option value=Query>Query</option>');
document.write('<option value=Update>Update</option>');
document.write('<option value=Delete>Delete</option>');
