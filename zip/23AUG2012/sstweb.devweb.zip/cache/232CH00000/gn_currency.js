document.write('<option value=></option>');
document.write('<option value=AUSD>Australlian $</option>');
document.write('<option value=EURO>EURO</option>');
document.write('<option value=MRINGIT>Malasian Ringit</option>');
document.write('<option value=USD>USD</option>');
document.write('<option value=RS>Rupee</option>');
