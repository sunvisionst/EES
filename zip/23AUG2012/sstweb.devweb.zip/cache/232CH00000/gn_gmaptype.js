document.write('<option value=></option>');
document.write('<option value=G_NORMAL_MAP>Map</option>');
document.write('<option value=G_SATELLITE_MAP>Satellite</option>');
document.write('<option value=G_HYBRID_MAP>Hybrid</option>');
