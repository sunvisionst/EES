document.write('<option value=></option>');
document.write('<option value=B>Birthday</option>');
document.write('<option value=W>Wedding Anniversary</option>');
