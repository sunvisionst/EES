document.write('<option value=></option>');
document.write('<option value=Ghz>Ghizabad</option>');
document.write('<option value=Kan>Kanpur</option>');
document.write('<option value=Unn>Unnao</option>');
