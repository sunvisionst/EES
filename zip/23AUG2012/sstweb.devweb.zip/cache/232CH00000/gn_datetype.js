document.write('<option value=></option>');
document.write('<option value=B>BIRTH DAY</option>');
document.write('<option value=M>MARRIAGE </option>');
