document.write('<option value=></option>');
document.write('<option value=1>Hindi</option>');
