document.write('<option value=></option>');
document.write('<option value=SS>Short Story</option>');
document.write('<option value=RE>Religious</option>');
document.write('<option value=CO>Comics</option>');
