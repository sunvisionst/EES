document.write('<option value=></option>');
document.write('<option value=1>Suspension</option>');
document.write('<option value=9>Other</option>');
