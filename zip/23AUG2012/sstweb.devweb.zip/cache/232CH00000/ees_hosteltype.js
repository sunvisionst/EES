document.write('<option value=></option>');
document.write('<option value=B>Boys</option>');
document.write('<option value=G>Girls</option>');
document.write('<option value=F>Faculty</option>');
document.write('<option value=R>Research Scholors</option>');
