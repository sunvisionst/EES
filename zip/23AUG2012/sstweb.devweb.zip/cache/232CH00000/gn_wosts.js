document.write('<option value=></option>');
document.write('<option value=O>OPEN</option>');
document.write('<option value=C>CLOSE</option>');
document.write('<option value=A>ALL</option>');
