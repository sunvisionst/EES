document.write('<option value=></option>');
document.write('<option value=A>Alumni</option>');
document.write('<option value=P>Private Org</option>');
document.write('<option value=G>Govt Org</option>');
document.write('<option value=O>Other</option>');
