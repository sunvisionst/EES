document.write('<option value=></option>');
document.write('<option value=A>Absent</option>');
document.write('<option value=P>Present</option>');
