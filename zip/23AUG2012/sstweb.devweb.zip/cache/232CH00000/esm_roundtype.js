document.write('<option value=></option>');
document.write('<option value=1>WrittenTest</option>');
document.write('<option value=2>TechInterview</option>');
document.write('<option value=3>HRInterview</option>');
