document.write('<option value=></option>');
document.write('<option value=D>Days</option>');
document.write('<option value=W>Weeks</option>');
document.write('<option value=M>Months</option>');

