document.write('<option value=></option>');
document.write('<option value=SR>Request Sent</option>');
document.write('<option value=RR>Request Raise</option>');
document.write('<option value=RA>Request Accept</option>');
document.write('<option value=RJ>Request Reject</option>');
document.write('<option value=AA>Approved</option>');
document.write('<option value=N>Request Saved</option>');
