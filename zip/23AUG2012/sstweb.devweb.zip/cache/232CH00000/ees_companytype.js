document.write('<option value=></option>');
document.write('<option value=B>BPO</option>');
document.write('<option value=I>IT</option>');
document.write('<option value=S>SOFTWARE  TECHNOLOGIES</option>');
document.write('<option value=K>KPO</option>');
document.write('<option value=C>CONSULTANCY</option>');
