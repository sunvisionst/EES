document.write('<option value=></option>');
document.write('<option value=A>Active</option>');
document.write('<option value=O>Obsolete</option>');
