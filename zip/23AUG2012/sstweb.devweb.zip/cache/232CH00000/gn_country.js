document.write('<option value=></option>');
document.write('<option value=I>India</option>');
document.write('<option value=P>Pakistan</option>');
document.write('<option value=U>United State</option>');
document.write('<option value=W>West India</option>');
