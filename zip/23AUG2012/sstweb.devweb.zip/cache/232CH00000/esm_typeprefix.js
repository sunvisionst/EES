document.write('<option value=></option>');
document.write('<option value=esm>esm</option>');
document.write('<option value=gn>gn</option>');
document.write('<option value=hr>hr</option>');
document.write('<option value=ees>ees</option>');
document.write('<option value=fa>fa</option>');
