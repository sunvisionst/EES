document.write('<option value=></option>');
document.write('<option value=T1>TERM1</option>');
document.write('<option value=T2>TERM2</option>');
