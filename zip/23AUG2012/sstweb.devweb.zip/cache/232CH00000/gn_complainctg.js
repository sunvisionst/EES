document.write('<option value=></option>');
document.write('<option value=1>Electricity</option>');
document.write('<option value=2>Plumber</option>');
document.write('<option value=3>carpenter</option>');
document.write('<option value=4>Internet</option>');
document.write('<option value=5>House Keeping</option>');
document.write('<option value=6>Washer man</option>');
document.write('<option value=7>Masson</option>');
