document.write('<option value=></option>');
document.write('<option value=A>Cash</option>');
document.write('<option value=B>Cheque</option>');
document.write('<option value=C>Draft</option>');
