document.write('<option value=></option>');
document.write('<option value=E>Electrician</option>');
document.write('<option value=H>Hostel</option>');
