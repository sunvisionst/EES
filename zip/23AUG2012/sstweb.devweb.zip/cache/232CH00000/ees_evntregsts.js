document.write('<option value=></option>');
document.write('<option value=E>Expected</option>');
document.write('<option value=C>Confirm</option>');
