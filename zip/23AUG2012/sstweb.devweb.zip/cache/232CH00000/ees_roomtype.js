document.write('<option value=></option>');
document.write('<option value=1>1 Seater</option>');
document.write('<option value=2>2 Seater</option>');
document.write('<option value=3>3 Seater</option>');
document.write('<option value=4>4 Seater</option>');
document.write('<option value=D>Dormetory</option>');
