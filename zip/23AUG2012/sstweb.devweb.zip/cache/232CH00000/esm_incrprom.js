document.write('<option value=></option>');
document.write('<option value=I>Increment</option>');
document.write('<option value=P>Promotion</option>');
