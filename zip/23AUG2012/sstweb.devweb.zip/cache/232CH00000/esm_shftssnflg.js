document.write('<option value=></option>');
document.write('<option value=S>Summer</option>');
document.write('<option value=W>Winter</option>');
