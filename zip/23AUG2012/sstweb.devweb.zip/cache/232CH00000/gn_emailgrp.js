document.write('<option value=></option>');
document.write('<option value=1>World Wide</option>');
document.write('<option value=2>Country</option>');
document.write('<option value=3>Center</option>');
document.write('<option value=4>Delivery Group</option>');
document.write('<option value=5>Cost Center</option>');
document.write('<option value=6>Department</option>');
document.write('<option value=7>Emp Level</option>');
