document.write('<option value=></option>');
document.write('<option value=1>SelfPay</option>');
document.write('<option value=2>Sponsor</option>');
document.write('<option value=3>Staff</option>');
document.write('<option value=4>Other</option>');
