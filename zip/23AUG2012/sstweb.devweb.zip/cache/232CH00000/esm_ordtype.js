document.write('<option value=></option>');
document.write('<option value=F>Final</option>');
document.write('<option value=S>Sample</option>');
document.write('<option value=B>Booking</option>');
