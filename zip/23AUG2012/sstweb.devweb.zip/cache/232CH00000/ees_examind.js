document.write('<option value=></option>');
document.write('<option value=0>No</option>');
document.write('<option value=1>Yes</option>');
