document.write('<option value=></option>');
document.write('<option value=B>Build</option>');
document.write('<option value=C>Coloney</option>');
document.write('<option value=S>Society</option>');
