document.write('<option value=></option>');
document.write('<option value=00>School</option>');
document.write('<option value=05>College</option>');
document.write('<option value=10>University</option>');
document.write('<option value=85>Training Center</option>');
document.write('<option value=15>Diploma School or College</option>');
