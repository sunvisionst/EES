document.write('<option value=></option>');
document.write('<option value=C>Current Account</option>');
document.write('<option value=S>Saving Account</option>');
document.write('<option value=R>Recurring Account</option>');
