document.write('<option value=></option>');
document.write('<option value=F>Full Time</option>');
document.write('<option value=P>Part Time</option>');
