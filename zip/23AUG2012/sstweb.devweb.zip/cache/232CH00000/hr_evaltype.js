document.write('<option value=></option>');
document.write('<option value=000>About Organization</option>');
document.write('<option value=005>About Computer Lab</option>');
document.write('<option value=010>About Chemistry Lab</option>');
document.write('<option value=015>About Physics Lab</option>');
document.write('<option value=020>About Library</option>');
document.write('<option value=025>About Transport</option>');
document.write('<option value=030>About Hostel</option>');
