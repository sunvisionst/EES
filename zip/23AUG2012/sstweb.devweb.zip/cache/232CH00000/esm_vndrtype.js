document.write('<option value=></option>');
document.write('<option value=B>Bank</option>');
document.write('<option value=T>TravelAgent</option>');
document.write('<option value=R>RecruitmentAgent</option>');
document.write('<option value=N>NewsAgency</option>');
