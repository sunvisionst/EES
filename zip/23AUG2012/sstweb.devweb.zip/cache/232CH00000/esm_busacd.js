document.write('<option value=></option>');
document.write('<option value=M>Master</option>');
document.write('<option value=V>Visa</option>');
