document.write('<option value=></option>');
document.write('<option value=DOC>MS Word Document</option>');
document.write('<option value=PDF>PDF File</option>');
document.write('<option value=RTF>Rich Text Format</option>');
document.write('<option value=TXT>Normal Text FIle(Notepad)</option>');
