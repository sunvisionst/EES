document.write('<option value=></option>');
document.write('<option value=0>Yearly</option>');
document.write('<option value=1>Monthly</option>');
document.write('<option value=6>Half Yearly</option>');
document.write('<option value=7>No Installment</option>');
