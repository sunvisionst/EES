document.write('<option value=></option>');
document.write('<option value=EDU>EDU</option>');
document.write('<option value=HL>HL</option>');
document.write('<option value=LIC>LIC</option>');
document.write('<option value=MI>MI</option>');
document.write('<option value=NSC>NSC</option>');
document.write('<option value=PF>PF</option>');
document.write('<option value=PPF>PPF</option>');
