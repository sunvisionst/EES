document.write('<option value=></option>');
document.write('<option value=I>Income</option>');
document.write('<option value=D>Deduction</option>');
