document.write('<option value=></option>');
document.write('<option value=C>C</option>');
document.write('<option value=J>Java</option>');
document.write('<option value=M>MIS</option>');
document.write('<option value=D>DBMS</option>');
document.write('<option value=N>Networking</option>');
