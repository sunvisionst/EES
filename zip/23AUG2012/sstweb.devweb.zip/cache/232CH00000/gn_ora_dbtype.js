document.write('<option value=></option>');
document.write('<option value=CHAR>Char</option>');
document.write('<option value=VARCHAR2>Varchar2</option>');
document.write('<option value=NUMBER>Number</option>');
