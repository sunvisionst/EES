document.write('<option value=></option>');
document.write('<option value=C>Corporate</option>');
document.write('<option value=P>Personal</option>');
