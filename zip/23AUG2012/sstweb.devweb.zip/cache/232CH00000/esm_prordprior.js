document.write('<option value=></option>');
document.write('<option value=1>High</option>');
document.write('<option value=2>Medium</option>');
document.write('<option value=3>Low</option>');
