document.write('<option value=></option>');
document.write('<option value=LR>Leave Request</option>');
document.write('<option value=TRVR>Travel Request</option>');
document.write('<option value=TRVE>Travel Expense</option>');
document.write('<option value=GEXP>General Expense</option>');
document.write('<option value=LOCO>Local Conveyance</option>');
