document.write('<option value=></option>');
document.write('<option value=C>Class</option>');
document.write('<option value=L>Lab</option>');
document.write('<option value=S>Staff</option>');
document.write('<option value=P>Principal</option>');
document.write('<option value=H>HOD</option>');
