document.write('<option value=></option>');
document.write('<option value=1>Single</option>');
document.write('<option value=2>Double</option>');
document.write('<option value=3>Triple</option>');
document.write('<option value=D>Dormetry</option>');
