document.write('<option value=></option>');
document.write('<option value=N>Newspaper</option>');
document.write('<option value=W>Website</option>');
document.write('<option value=F>Friend</option>');
document.write('<option value=O>Other</option>');
document.write('<option value=S>Sunvision</option>');
