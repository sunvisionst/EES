document.write('<option value=></option>');
document.write('<option value=R>Root</option>');
document.write('<option value=B>Branch</option>');
document.write('<option value=L>Leaf</option>');
