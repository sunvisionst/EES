document.write('<option value=></option>');
document.write('<option value=R>Request</option>');
document.write('<option value=A>Approve</option>');
document.write('<option value=P>Pending</option>');
document.write('<option value=W>WIP</option>');
document.write('<option value=RMR>RMR</option>');
document.write('<option value=RMI>RMI</option>');
