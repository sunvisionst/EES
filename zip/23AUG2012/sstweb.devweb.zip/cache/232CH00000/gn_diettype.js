document.write('<option value=></option>');
document.write('<option value=B>Breakfast</option>');
document.write('<option value=L>Lunch</option>');
document.write('<option value=D>Diner</option>');
