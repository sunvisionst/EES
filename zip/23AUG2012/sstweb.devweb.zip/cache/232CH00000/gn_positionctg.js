document.write('<option value=></option>');
document.write('<option value=00>Board of Directors</option>');
document.write('<option value=05>Owner/MD/CEO</option>');
document.write('<option value=10>Senior Management</option>');
document.write('<option value=15>Middle Management</option>');
document.write('<option value=20>Executive Staff</option>');
