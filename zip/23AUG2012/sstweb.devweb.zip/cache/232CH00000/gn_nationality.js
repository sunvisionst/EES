document.write('<option value=></option>');
document.write('<option value=100>Indian</option>');
document.write('<option value=101>Russion</option>');
document.write('<option value=102>Pakistan</option>');
document.write('<option value=103>German</option>');
document.write('<option value=104>American</option>');
document.write('<option value=999>Other</option>');

