document.write('<option value=></option>');
document.write('<option value=O>Initial Stage</option>');
document.write('<option value=CC>Filter </option>');
document.write('<option value=A>Admission</option>');
document.write('<option value=M2A>Move To Admission</option>');
