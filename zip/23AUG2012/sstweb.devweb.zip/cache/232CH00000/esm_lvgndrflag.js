document.write('<option value=></option>');
document.write('<option value=M>Male</option>');
document.write('<option value=F>Female</option>');
document.write('<option value=B>Both</option>');
