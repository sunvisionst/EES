document.write('<option value=></option>');
document.write('<option value=D>Dr</option>');
document.write('<option value=C>Cr</option>');
