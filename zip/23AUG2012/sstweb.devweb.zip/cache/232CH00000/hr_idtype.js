document.write('<option value=></option>');
document.write('<option value=P>Passport</option>');
document.write('<option value=V>Voter Id</option>');
document.write('<option value=R>Ration Card</option>');
