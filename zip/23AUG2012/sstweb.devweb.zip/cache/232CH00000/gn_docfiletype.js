document.write('<option value=></option>');
document.write('<option value=DOC>Document</option>');
document.write('<option value=VOI>Voice</option>');
document.write('<option value=VED>Vedio</option>');
