document.write('<option value=></option>');
document.write('<option value=P>Proposed</option>');
document.write('<option value=A>Actual</option>');
