document.write('<option value=></option>');
document.write('<option value=N>New</option>');
document.write('<option value=O>Open</option>');
document.write('<option value=C>Close</option>');
