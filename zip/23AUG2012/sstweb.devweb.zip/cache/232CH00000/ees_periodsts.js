document.write('<option value=></option>');
document.write('<option value=E>Empty</option>');
document.write('<option value=F>Full</option>');
