document.write('<option value=></option>');
document.write('<option value=P>PERCENT</option>');
document.write('<option value=G>GRADE</option>');
