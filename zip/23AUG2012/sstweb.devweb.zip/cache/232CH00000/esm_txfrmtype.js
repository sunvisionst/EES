document.write('<option value=></option>');
document.write('<option value=C>C-Form</option>');
document.write('<option value=H>H-Form</option>');
