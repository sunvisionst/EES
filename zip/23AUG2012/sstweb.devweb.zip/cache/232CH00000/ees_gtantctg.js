document.write('<option value=></option>');
document.write('<option value=H>High</option>');
document.write('<option value=L>Low</option>');
document.write('<option value=M>Medium</option>');
