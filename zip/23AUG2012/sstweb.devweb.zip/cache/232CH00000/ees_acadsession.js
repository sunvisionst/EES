document.write('<option value=></option>');
document.write('<option value=2006-2007>2006-2007</option>');
document.write('<option value=2007-2008>2007-2008</option>');
document.write('<option value=2008-2009>2008-2009</option>');
document.write('<option value=2009-2010>2009-2010</option>');
