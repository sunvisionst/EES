document.write('<option value=></option>');
document.write('<option value=B>Branch</option>');
document.write('<option value=I>Internal</option>');
