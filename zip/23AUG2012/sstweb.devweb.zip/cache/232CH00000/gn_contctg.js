document.write('<option value=></option>');
document.write('<option value=B>BUSINESS</option>');
document.write('<option value=P>PERSONAL</option>');
