document.write('<option value=></option>');
document.write('<option value=H>Hindu</option>');
document.write('<option value=M>Muslim</option>');
document.write('<option value=C>Christian</option>');
document.write('<option value=S>Sikh</option>');
document.write('<option value=B>Buddhisim</option>');
document.write('<option value=J>Jain</option>');
document.write('<option value=O>Other</option>');
