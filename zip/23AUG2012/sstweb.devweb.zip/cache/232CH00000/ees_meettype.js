document.write('<option value=></option>');
document.write('<option value=E>Employee</option>');
document.write('<option value=S>Student</option>');
