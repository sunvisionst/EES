document.write('<option value=></option>');
document.write('<option value=1001>India</option>');
document.write('<option value=1002>USA</option>');
