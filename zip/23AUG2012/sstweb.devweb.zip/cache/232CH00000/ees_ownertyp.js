document.write('<option value=></option>');
document.write('<option value=S>Self</option>');
document.write('<option value=TA>Transport Agent</option>');
