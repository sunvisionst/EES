document.write('<option value=></option>');
document.write('<option value=1>SL</option>');
document.write('<option value=2>PL</option>');
