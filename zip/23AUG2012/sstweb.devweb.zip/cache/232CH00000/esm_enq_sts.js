document.write('<option value=></option>');
document.write('<option value=O>Open</option>');
document.write('<option value=X>Cancel</option>');
document.write('<option value=C>Close</option>');
document.write('<option value=R>Reject</option>');
