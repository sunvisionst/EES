document.write('<option value=></option>');
document.write('<option value=T>Travel Agent</option>');
document.write('<option value=I>Insurance Agent</option>');
document.write('<option value=R>Recruitment Agent</option>');
document.write('<option value=A>Advertise Company</option>');
document.write('<option value=N>News Agency</option>');
