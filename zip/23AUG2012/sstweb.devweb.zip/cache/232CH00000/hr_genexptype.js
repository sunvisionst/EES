document.write('<option value=></option>');
document.write('<option value=10>Telephone</option>');
document.write('<option value=15>Stationary</option>');
document.write('<option value=20>Maintenance</option>');
document.write('<option value=99>Others</option>');
