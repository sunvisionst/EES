document.write('<option value=></option>');
document.write('<option value=O>Open</option>');
document.write('<option value=P>Post</option>');
document.write('<option value=C>Complete</option>');
