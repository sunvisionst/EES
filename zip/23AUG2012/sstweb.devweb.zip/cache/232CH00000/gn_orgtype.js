document.write('<option value=></option>');
document.write('<option value=H>Headoffice</option>');
document.write('<option value=B>Branchoff</option>');
document.write('<option value=C>Corp</option>');
document.write('<option value=S>Suboffice</option>');
