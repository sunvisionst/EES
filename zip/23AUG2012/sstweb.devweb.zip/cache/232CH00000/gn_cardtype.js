document.write('<option value=></option>');
document.write('<option value=C>Credit</option>');
document.write('<option value=D>Debit</option>');
