document.write('<option value=></option>');
document.write('<option value=S>Student</option>');
document.write('<option value=E>Employee</option>');
