document.write('<option value=></option>');
document.write('<option value=T>Theory</option>');
document.write('<option value=P>Practical</option>');
