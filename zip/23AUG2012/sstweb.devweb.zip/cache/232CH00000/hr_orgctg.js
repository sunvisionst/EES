document.write('<option value=></option>');
document.write('<option value=I>Institute</option>');
document.write('<option value=S>School</option>');
