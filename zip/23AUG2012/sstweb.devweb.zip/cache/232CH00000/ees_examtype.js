document.write('<option value=></option>');
document.write('<option value=H>Half Yearly</option>');
document.write('<option value=M>Monthly</option>');
document.write('<option value=Q>Quarterly</option>');
document.write('<option value=Y>Yearly</option>');
