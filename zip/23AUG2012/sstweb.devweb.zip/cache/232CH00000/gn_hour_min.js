document.write('<option value=></option>');
document.write('<option value=HOUR>Hour</option>');
document.write('<option value=MINUTE>Minute</option>');
