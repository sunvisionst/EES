document.write('<option value=></option>');
document.write('<option value=2007>2007</option>');
document.write('<option value=2008>2008</option>');
document.write('<option value=2009>2009</option>');
document.write('<option value=2010>2010</option>');
document.write('<option value=2011>2011</option>');
