document.write('<option value=></option>');
document.write('<option value=E>East</option>');
document.write('<option value=W>West</option>');
document.write('<option value=N>North</option>');
document.write('<option value=S>South</option>');
