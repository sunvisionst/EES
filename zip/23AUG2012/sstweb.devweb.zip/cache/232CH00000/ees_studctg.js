document.write('<option value=></option>');
document.write('<option value=A>Avas Vikas</option>');
document.write('<option value=T>Teacher Ward</option>');
document.write('<option value=O>Other</option>');
