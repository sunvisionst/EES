document.write('<option value=></option>');
document.write('<option value=P>Phone</option>');
document.write('<option value=F>Fax</option>');
document.write('<option value=E>Email</option>');
