document.write('<option value=></option>');
document.write('<option value=MR>Mr.</option>');
document.write('<option value=MRS>Mrs.</option>');
document.write('<option value=MS>Ms.</option>');
