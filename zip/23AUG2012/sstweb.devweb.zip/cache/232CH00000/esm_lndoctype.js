document.write('<option value=></option>');
document.write('<option value=I>Invoice</option>');
document.write('<option value=P>Purchase Order</option>');
