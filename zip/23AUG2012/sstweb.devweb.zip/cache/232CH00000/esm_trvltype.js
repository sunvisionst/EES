document.write('<option value=></option>');
document.write('<option value=O>Official</option>');
document.write('<option value=P>Personal</option>');
