document.write('<option value=></option>');
document.write('<option value=G>Government</option>');
document.write('<option value=N>No</option>');
document.write('<option value=P>Private</option>');
document.write('<option value=WB>WorldBank</option>');
