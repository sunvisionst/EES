document.write('<option value=></option>');
document.write('<option value=I>In</option>');
document.write('<option value=O>Out</option>');
