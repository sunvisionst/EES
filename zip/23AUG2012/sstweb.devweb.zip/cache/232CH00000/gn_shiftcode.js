document.write('<option value=></option>');
document.write('<option value=GEN>General</option>');
document.write('<option value=SFT1ST>SHIFTFIRST</option>');
document.write('<option value=SFT2ND>SHIFTSECOND</option>');
document.write('<option value=SFT3RD>SHIFTTHIRD</option>');
