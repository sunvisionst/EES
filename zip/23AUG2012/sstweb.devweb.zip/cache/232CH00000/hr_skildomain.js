document.write('<option value=></option>');
document.write('<option value=S>Skill</option>');
document.write('<option value=D>Domain</option>');
