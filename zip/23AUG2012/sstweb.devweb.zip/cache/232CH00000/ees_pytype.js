document.write('<option value=></option>');
document.write('<option value=1>cash</option>');
document.write('<option value=2>cheque</option>');
document.write('<option value=3>hand</option>');
