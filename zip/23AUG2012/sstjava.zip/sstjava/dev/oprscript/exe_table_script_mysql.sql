
  source /tmp/ees_public//mysql/bbm_blood_bank_tab.sql
  source /tmp/ees_public//mysql/bbm_blood_bank_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_blood_bottle_tab.sql
  source /tmp/ees_public//mysql/bbm_blood_bottle_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_blood_bottle_history_tab.sql
  source /tmp/ees_public//mysql/bbm_blood_bottle_history_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_blood_charge_tab.sql
  source /tmp/ees_public//mysql/bbm_blood_charge_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_blood_master_tab.sql
  source /tmp/ees_public//mysql/bbm_blood_master_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_address_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_address_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_blood_dtl_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_blood_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_employer_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_employer_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_identity_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_identity_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_mail_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_mail_pkey.sql
  

  source /tmp/ees_public//mysql/bbm_donor_phone_tab.sql
  source /tmp/ees_public//mysql/bbm_donor_phone_pkey.sql
  

  source /tmp/ees_public//mysql/dm_cust_agreement_tab.sql
  source /tmp/ees_public//mysql/dm_cust_agreement_pkey.sql
  

  source /tmp/ees_public//mysql/dm_customer_tab.sql
  source /tmp/ees_public//mysql/dm_customer_pkey.sql
  

  source /tmp/ees_public//mysql/dm_employee_tab.sql
  source /tmp/ees_public//mysql/dm_employee_pkey.sql
  

  source /tmp/ees_public//mysql/dm_employee_mon_dtl_tab.sql
  source /tmp/ees_public//mysql/dm_employee_mon_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/dm_src_file_tab.sql
  source /tmp/ees_public//mysql/dm_src_file_pkey.sql
  

  source /tmp/ees_public//mysql/ees_academic_session_tab.sql
  source /tmp/ees_public//mysql/ees_academic_session_pkey.sql
  

  source /tmp/ees_public//mysql/ees_adm_list_tab.sql
  source /tmp/ees_public//mysql/ees_adm_list_pkey.sql
  

  source /tmp/ees_public//mysql/ees_adm_mark_tab.sql
  source /tmp/ees_public//mysql/ees_adm_mark_pkey.sql
  

  source /tmp/ees_public//mysql/ees_adm_req_tab.sql
  source /tmp/ees_public//mysql/ees_adm_req_pkey.sql
  

  source /tmp/ees_public//mysql/ees_adm_sub_tab.sql
  source /tmp/ees_public//mysql/ees_adm_sub_pkey.sql
  

  source /tmp/ees_public//mysql/ees_adr_tab.sql
  source /tmp/ees_public//mysql/ees_adr_pkey.sql
  

  source /tmp/ees_public//mysql/ees_alumni_tab.sql
  source /tmp/ees_public//mysql/ees_alumni_pkey.sql
  

  source /tmp/ees_public//mysql/ees_alumni_prof_tab.sql
  source /tmp/ees_public//mysql/ees_alumni_prof_pkey.sql
  

  source /tmp/ees_public//mysql/ees_appc_academic_tab.sql
  source /tmp/ees_public//mysql/ees_appc_academic_pkey.sql
  

  source /tmp/ees_public//mysql/ees_appc_prev_mark_tab.sql
  source /tmp/ees_public//mysql/ees_appc_prev_mark_pkey.sql
  

  source /tmp/ees_public//mysql/ees_appc_ref_tab.sql
  source /tmp/ees_public//mysql/ees_appc_ref_pkey.sql
  

  source /tmp/ees_public//mysql/ees_as_checklist_tab.sql
  source /tmp/ees_public//mysql/ees_as_checklist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_award_tab.sql
  source /tmp/ees_public//mysql/ees_award_pkey.sql
  

  source /tmp/ees_public//mysql/ees_award_distribution_tab.sql
  source /tmp/ees_public//mysql/ees_award_distribution_pkey.sql
  

  source /tmp/ees_public//mysql/ees_class_tab.sql
  source /tmp/ees_public//mysql/ees_class_pkey.sql
  

  source /tmp/ees_public//mysql/ees_class_sch_ship_tab.sql
  source /tmp/ees_public//mysql/ees_class_sch_ship_pkey.sql
  

  source /tmp/ees_public//mysql/ees_contract_tab.sql
  source /tmp/ees_public//mysql/ees_contract_pkey.sql
  

  source /tmp/ees_public//mysql/ees_course_tab.sql
  source /tmp/ees_public//mysql/ees_course_pkey.sql
  

  source /tmp/ees_public//mysql/ees_course_stream_tab.sql
  source /tmp/ees_public//mysql/ees_course_stream_pkey.sql
  

  source /tmp/ees_public//mysql/ees_daily_trip_tab.sql
  source /tmp/ees_public//mysql/ees_daily_trip_pkey.sql
  

  source /tmp/ees_public//mysql/ees_event_tab.sql
  source /tmp/ees_public//mysql/ees_event_pkey.sql
  

  source /tmp/ees_public//mysql/ees_event_activity_tab.sql
  source /tmp/ees_public//mysql/ees_event_activity_pkey.sql
  

  source /tmp/ees_public//mysql/ees_event_contact_tab.sql
  source /tmp/ees_public//mysql/ees_event_contact_pkey.sql
  

  source /tmp/ees_public//mysql/ees_event_reg_guest_tab.sql
  source /tmp/ees_public//mysql/ees_event_reg_guest_pkey.sql
  

  source /tmp/ees_public//mysql/ees_event_reg_stud_tab.sql
  source /tmp/ees_public//mysql/ees_event_reg_stud_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_tab.sql
  source /tmp/ees_public//mysql/ees_exam_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_class_tab.sql
  source /tmp/ees_public//mysql/ees_exam_class_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_paper_tab.sql
  source /tmp/ees_public//mysql/ees_exam_paper_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_question_tab.sql
  source /tmp/ees_public//mysql/ees_exam_question_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_quest_mo_tab.sql
  source /tmp/ees_public//mysql/ees_exam_quest_mo_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_room_map_tab.sql
  source /tmp/ees_public//mysql/ees_exam_room_map_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_schedule_tab.sql
  source /tmp/ees_public//mysql/ees_exam_schedule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_seat_plan_tab.sql
  source /tmp/ees_public//mysql/ees_exam_seat_plan_pkey.sql
  

  source /tmp/ees_public//mysql/ees_exam_term_tab.sql
  source /tmp/ees_public//mysql/ees_exam_term_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_concession_tab.sql
  source /tmp/ees_public//mysql/ees_fee_concession_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_cycle_tab.sql
  source /tmp/ees_public//mysql/ees_fee_cycle_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_cycle_item_tab.sql
  source /tmp/ees_public//mysql/ees_fee_cycle_item_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_due_date_tab.sql
  source /tmp/ees_public//mysql/ees_fee_due_date_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_head_tab.sql
  source /tmp/ees_public//mysql/ees_fee_head_pkey.sql
  

  source /tmp/ees_public//mysql/ees_fee_head_class_tab.sql
  source /tmp/ees_public//mysql/ees_fee_head_class_pkey.sql
  

  source /tmp/ees_public//mysql/ees_gen_acad_rule_tab.sql
  source /tmp/ees_public//mysql/ees_gen_acad_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_gen_disc_tab.sql
  source /tmp/ees_public//mysql/ees_gen_disc_pkey.sql
  

  source /tmp/ees_public//mysql/ees_gen_disc_act_tab.sql
  source /tmp/ees_public//mysql/ees_gen_disc_act_pkey.sql
  

  source /tmp/ees_public//mysql/ees_grade_system_tab.sql
  source /tmp/ees_public//mysql/ees_grade_system_pkey.sql
  

  source /tmp/ees_public//mysql/ees_grant_tab.sql
  source /tmp/ees_public//mysql/ees_grant_pkey.sql
  

  source /tmp/ees_public//mysql/ees_granter_tab.sql
  source /tmp/ees_public//mysql/ees_granter_pkey.sql
  

  source /tmp/ees_public//mysql/ees_grant_inst_tab.sql
  source /tmp/ees_public//mysql/ees_grant_inst_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_attn_reg_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_attn_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_bed_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_bed_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_bs_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_bs_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_complain_reg_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_complain_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_exit_entry_reg_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_exit_entry_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_fee_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_fee_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_flw_qty_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_flw_qty_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_item_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_item_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_room_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_room_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_room_inv_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_room_inv_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_room_item_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_room_item_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_rtw_qty_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_rtw_qty_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_visitor_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_visitor_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_visit_reg_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_visit_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_warden_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_warden_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_warden_hist_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_warden_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_hostel_wing_tab.sql
  source /tmp/ees_public//mysql/ees_hostel_wing_pkey.sql
  

  source /tmp/ees_public//mysql/ees_institute_tab.sql
  source /tmp/ees_public//mysql/ees_institute_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_tab.sql
  source /tmp/ees_public//mysql/ees_lab_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_attn_reg_tab.sql
  source /tmp/ees_public//mysql/ees_lab_attn_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_attn_reg_hist_tab.sql
  source /tmp/ees_public//mysql/ees_lab_attn_reg_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_eqp_tab.sql
  source /tmp/ees_public//mysql/ees_lab_eqp_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_sch_tab.sql
  source /tmp/ees_public//mysql/ees_lab_sch_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lab_sch_hist_tab.sql
  source /tmp/ees_public//mysql/ees_lab_sch_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_late_fee_rule_tab.sql
  source /tmp/ees_public//mysql/ees_late_fee_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lecture_attend_tab.sql
  source /tmp/ees_public//mysql/ees_lecture_attend_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lecture_plan_tab.sql
  source /tmp/ees_public//mysql/ees_lecture_plan_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lib_attn_reg_tab.sql
  source /tmp/ees_public//mysql/ees_lib_attn_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lib_book_tab.sql
  source /tmp/ees_public//mysql/ees_lib_book_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lib_book_issue_tab.sql
  source /tmp/ees_public//mysql/ees_lib_book_issue_pkey.sql
  

  source /tmp/ees_public//mysql/ees_lib_issue_rule_tab.sql
  source /tmp/ees_public//mysql/ees_lib_issue_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_library_tab.sql
  source /tmp/ees_public//mysql/ees_library_pkey.sql
  

  source /tmp/ees_public//mysql/ees_locker_tab.sql
  source /tmp/ees_public//mysql/ees_locker_pkey.sql
  

  source /tmp/ees_public//mysql/ees_locker_use_tab.sql
  source /tmp/ees_public//mysql/ees_locker_use_pkey.sql
  

  source /tmp/ees_public//mysql/ees_marksheet_lo_tab.sql
  source /tmp/ees_public//mysql/ees_marksheet_lo_pkey.sql
  

  source /tmp/ees_public//mysql/ees_mess_tab.sql
  source /tmp/ees_public//mysql/ees_mess_pkey.sql
  

  source /tmp/ees_public//mysql/ees_mess_diet_reg_tab.sql
  source /tmp/ees_public//mysql/ees_mess_diet_reg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_mess_fee_tab.sql
  source /tmp/ees_public//mysql/ees_mess_fee_pkey.sql
  

  source /tmp/ees_public//mysql/ees_mess_hist_tab.sql
  source /tmp/ees_public//mysql/ees_mess_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_mon_frt_acad_rep_tab.sql
  source /tmp/ees_public//mysql/ees_mon_frt_acad_rep_pkey.sql
  

  source /tmp/ees_public//mysql/ees_period_tab.sql
  source /tmp/ees_public//mysql/ees_period_pkey.sql
  

  source /tmp/ees_public//mysql/ees_room_allotment_hist_tab.sql
  source /tmp/ees_public//mysql/ees_room_allotment_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_route_tab.sql
  source /tmp/ees_public//mysql/ees_route_pkey.sql
  

  source /tmp/ees_public//mysql/ees_route_stoppage_tab.sql
  source /tmp/ees_public//mysql/ees_route_stoppage_pkey.sql
  

  source /tmp/ees_public//mysql/ees_sch_ship_tab.sql
  source /tmp/ees_public//mysql/ees_sch_ship_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_tab.sql
  source /tmp/ees_public//mysql/ees_student_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_academic_tab.sql
  source /tmp/ees_public//mysql/ees_student_academic_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_ctg_tab.sql
  source /tmp/ees_public//mysql/ees_student_ctg_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_extra_ach_tab.sql
  source /tmp/ees_public//mysql/ees_student_extra_ach_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_family_acad_tab.sql
  source /tmp/ees_public//mysql/ees_student_family_acad_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_fee_tab.sql
  source /tmp/ees_public//mysql/ees_student_fee_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_hist_tab.sql
  source /tmp/ees_public//mysql/ees_student_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_mark_tab.sql
  source /tmp/ees_public//mysql/ees_student_mark_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_marksheet_tab.sql
  source /tmp/ees_public//mysql/ees_student_marksheet_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_quest_mark_tab.sql
  source /tmp/ees_public//mysql/ees_student_quest_mark_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_ref_tab.sql
  source /tmp/ees_public//mysql/ees_student_ref_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_sch_ship_tab.sql
  source /tmp/ees_public//mysql/ees_student_sch_ship_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_subject_tab.sql
  source /tmp/ees_public//mysql/ees_student_subject_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_tab.sql
  source /tmp/ees_public//mysql/ees_subject_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_allocation_tab.sql
  source /tmp/ees_public//mysql/ees_subject_allocation_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_elect_tab.sql
  source /tmp/ees_public//mysql/ees_subject_elect_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_mark_rule_tab.sql
  source /tmp/ees_public//mysql/ees_subject_mark_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_ms_tab.sql
  source /tmp/ees_public//mysql/ees_subject_ms_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_ms_hist_tab.sql
  source /tmp/ees_public//mysql/ees_subject_ms_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_sylb_tab.sql
  source /tmp/ees_public//mysql/ees_subject_sylb_pkey.sql
  

  source /tmp/ees_public//mysql/ees_timetable_tab.sql
  source /tmp/ees_public//mysql/ees_timetable_pkey.sql
  

  source /tmp/ees_public//mysql/ees_timetable_hdr_tab.sql
  source /tmp/ees_public//mysql/ees_timetable_hdr_pkey.sql
  

  source /tmp/ees_public//mysql/ees_timetable_model_tab.sql
  source /tmp/ees_public//mysql/ees_timetable_model_pkey.sql
  

  source /tmp/ees_public//mysql/ees_timetable_rule_tab.sql
  source /tmp/ees_public//mysql/ees_timetable_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_cfr_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_cfr_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_cic_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_cic_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_ci_student_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_ci_student_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_civ_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_civ_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_company_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_company_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_invitee_inst_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_invitee_inst_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_organizer_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_organizer_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_program_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_program_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_sch_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_sch_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_student_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_student_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tnp_training_plan_tab.sql
  source /tmp/ees_public//mysql/ees_tnp_training_plan_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tp_fee_tab.sql
  source /tmp/ees_public//mysql/ees_tp_fee_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tp_snm_tab.sql
  source /tmp/ees_public//mysql/ees_tp_snm_pkey.sql
  

  source /tmp/ees_public//mysql/ees_trip_tab.sql
  source /tmp/ees_public//mysql/ees_trip_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tt_af_req_tab.sql
  source /tmp/ees_public//mysql/ees_tt_af_req_pkey.sql
  

  source /tmp/ees_public//mysql/ees_vehicle_tab.sql
  source /tmp/ees_public//mysql/ees_vehicle_pkey.sql
  

  source /tmp/ees_public//mysql/ees_vehicle_driver_tab.sql
  source /tmp/ees_public//mysql/ees_vehicle_driver_pkey.sql
  

  source /tmp/ees_public//mysql/ees_vehicle_location_tab.sql
  source /tmp/ees_public//mysql/ees_vehicle_location_pkey.sql
  

  source /tmp/ees_public//mysql/ees_vehicle_route_tab.sql
  source /tmp/ees_public//mysql/ees_vehicle_route_pkey.sql
  

  source /tmp/ees_public//mysql/ees_vehicle_route_hist_tab.sql
  source /tmp/ees_public//mysql/ees_vehicle_route_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_adm_dtl_tab.sql
  source /tmp/ees_public//mysql/ehs_adm_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_adm_req_tab.sql
  source /tmp/ees_public//mysql/ehs_adm_req_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_appointment_tab.sql
  source /tmp/ees_public//mysql/ehs_appointment_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_bed_avail_stat_tab.sql
  source /tmp/ees_public//mysql/ehs_bed_avail_stat_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_birth_certificate_tab.sql
  source /tmp/ees_public//mysql/ehs_birth_certificate_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_death_certificate_tab.sql
  source /tmp/ees_public//mysql/ehs_death_certificate_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_doctor_tab.sql
  source /tmp/ees_public//mysql/ehs_doctor_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_doctor_avail_status_tab.sql
  source /tmp/ees_public//mysql/ehs_doctor_avail_status_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_doctor_fee_tab.sql
  source /tmp/ees_public//mysql/ehs_doctor_fee_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_doctor_timesheet_tab.sql
  source /tmp/ees_public//mysql/ehs_doctor_timesheet_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_drug_master_tab.sql
  source /tmp/ees_public//mysql/ehs_drug_master_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_emergency_record_tab.sql
  source /tmp/ees_public//mysql/ehs_emergency_record_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_emr_medi_iv_order_tab.sql
  source /tmp/ees_public//mysql/ehs_emr_medi_iv_order_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_emr_nurse_assesment_tab.sql
  source /tmp/ees_public//mysql/ehs_emr_nurse_assesment_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_eqp_tab.sql
  source /tmp/ees_public//mysql/ehs_eqp_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_eqp_srv_req_tab.sql
  source /tmp/ees_public//mysql/ehs_eqp_srv_req_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_item_pricing_tab.sql
  source /tmp/ees_public//mysql/ehs_item_pricing_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_item_purchase_tab.sql
  source /tmp/ees_public//mysql/ehs_item_purchase_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_item_sale_tab.sql
  source /tmp/ees_public//mysql/ehs_item_sale_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_medical_test_tab.sql
  source /tmp/ees_public//mysql/ehs_medical_test_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ot_tab.sql
  source /tmp/ees_public//mysql/ehs_ot_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ot_ans_tab.sql
  source /tmp/ees_public//mysql/ehs_ot_ans_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ot_eqp_tab.sql
  source /tmp/ees_public//mysql/ehs_ot_eqp_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ot_sch_tab.sql
  source /tmp/ees_public//mysql/ehs_ot_sch_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ot_staff_tab.sql
  source /tmp/ees_public//mysql/ehs_ot_staff_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_address_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_address_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_attendant_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_attendant_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_contact_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_contact_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_diagnosis_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_diagnosis_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_family_hist_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_family_hist_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_hist_dtl_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_hist_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_identity_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_identity_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_life_style_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_life_style_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_past_illness_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_past_illness_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_vaccination_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_vaccination_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_vital_sign_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_vital_sign_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_prescription_tab.sql
  source /tmp/ees_public//mysql/ehs_prescription_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_room_tab.sql
  source /tmp/ees_public//mysql/ehs_room_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_room_bed_tab.sql
  source /tmp/ees_public//mysql/ehs_room_bed_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_salesman_tab.sql
  source /tmp/ees_public//mysql/ehs_salesman_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_spnship_pymnt_stmt_tab.sql
  source /tmp/ees_public//mysql/ehs_spnship_pymnt_stmt_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_spnship_pymnt_stmt_dtl_tab.sql
  source /tmp/ees_public//mysql/ehs_spnship_pymnt_stmt_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_sponsorship_policy_tab.sql
  source /tmp/ees_public//mysql/ehs_sponsorship_policy_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_srv_charge_tab.sql
  source /tmp/ees_public//mysql/ehs_srv_charge_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_test_report_tab.sql
  source /tmp/ees_public//mysql/ehs_test_report_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_test_sample_tab.sql
  source /tmp/ees_public//mysql/ehs_test_sample_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_vaccination_rule_tab.sql
  source /tmp/ees_public//mysql/ehs_vaccination_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_ward_tab.sql
  source /tmp/ees_public//mysql/ehs_ward_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_doc_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_doc_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_iaddr_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_iaddr_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_ihier_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_ihier_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_item_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_item_pkey.sql
  

  source /tmp/ees_public//mysql/enq_customer_enquiry_note_tab.sql
  source /tmp/ees_public//mysql/enq_customer_enquiry_note_pkey.sql
  

  source /tmp/ees_public//mysql/enq_supplier_enquiry_tab.sql
  source /tmp/ees_public//mysql/enq_supplier_enquiry_pkey.sql
  

  source /tmp/ees_public//mysql/enq_supplier_enquiry_iaddr_tab.sql
  source /tmp/ees_public//mysql/enq_supplier_enquiry_iaddr_pkey.sql
  

  source /tmp/ees_public//mysql/enq_supplier_enquiry_item_tab.sql
  source /tmp/ees_public//mysql/enq_supplier_enquiry_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_attribute_list_tab.sql
  source /tmp/ees_public//mysql/esm_attribute_list_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cabin_rack_tab.sql
  source /tmp/ees_public//mysql/esm_cabin_rack_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cust_item_code_tab.sql
  source /tmp/ees_public//mysql/esm_cust_item_code_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_tab.sql
  source /tmp/ees_public//mysql/esm_customer_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_address_tab.sql
  source /tmp/ees_public//mysql/esm_customer_address_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_banker_tab.sql
  source /tmp/ees_public//mysql/esm_customer_banker_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_contact_tab.sql
  source /tmp/ees_public//mysql/esm_customer_contact_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_grp_tab.sql
  source /tmp/ees_public//mysql/esm_customer_grp_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_pack_list_tab.sql
  source /tmp/ees_public//mysql/esm_customer_pack_list_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_pay_card_tab.sql
  source /tmp/ees_public//mysql/esm_customer_pay_card_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_hist_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_iaddr_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_iaddr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_iaddr_hist_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_iaddr_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_item_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_po_item_hist_tab.sql
  source /tmp/ees_public//mysql/esm_customer_po_item_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cust_pack_list_item_tab.sql
  source /tmp/ees_public//mysql/esm_cust_pack_list_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cust_po_sch_tab.sql
  source /tmp/ees_public//mysql/esm_cust_po_sch_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cust_po_sch_item_tab.sql
  source /tmp/ees_public//mysql/esm_cust_po_sch_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_cust_po_sch_item_hist_tab.sql
  source /tmp/ees_public//mysql/esm_cust_po_sch_item_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_doc_item_spec_tab.sql
  source /tmp/ees_public//mysql/esm_doc_item_spec_pkey.sql
  

  source /tmp/ees_public//mysql/esm_doc_item_spec_hist_tab.sql
  source /tmp/ees_public//mysql/esm_doc_item_spec_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_epcg_tab.sql
  source /tmp/ees_public//mysql/esm_epcg_pkey.sql
  

  source /tmp/ees_public//mysql/esm_epcg_dtl_tab.sql
  source /tmp/ees_public//mysql/esm_epcg_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/esm_export_license_tab.sql
  source /tmp/ees_public//mysql/esm_export_license_pkey.sql
  

  source /tmp/ees_public//mysql/esm_export_license_dtl_tab.sql
  source /tmp/ees_public//mysql/esm_export_license_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/esm_gen_cfr_tab.sql
  source /tmp/ees_public//mysql/esm_gen_cfr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_general_license_tab.sql
  source /tmp/ees_public//mysql/esm_general_license_pkey.sql
  

  source /tmp/ees_public//mysql/esm_insurance_agent_tab.sql
  source /tmp/ees_public//mysql/esm_insurance_agent_pkey.sql
  

  source /tmp/ees_public//mysql/esm_insurance_org_tab.sql
  source /tmp/ees_public//mysql/esm_insurance_org_pkey.sql
  

  source /tmp/ees_public//mysql/esm_insurance_policy_tab.sql
  source /tmp/ees_public//mysql/esm_insurance_policy_pkey.sql
  

  source /tmp/ees_public//mysql/esm_invoice_tab.sql
  source /tmp/ees_public//mysql/esm_invoice_pkey.sql
  

  source /tmp/ees_public//mysql/esm_invoice_item_tab.sql
  source /tmp/ees_public//mysql/esm_invoice_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_invoice_item_revert_tab.sql
  source /tmp/ees_public//mysql/esm_invoice_item_revert_pkey.sql
  

  source /tmp/ees_public//mysql/esm_invoice_item_src_tab.sql
  source /tmp/ees_public//mysql/esm_invoice_item_src_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_tab.sql
  source /tmp/ees_public//mysql/esm_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_attribute_tab.sql
  source /tmp/ees_public//mysql/esm_item_attribute_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_box_map_tab.sql
  source /tmp/ees_public//mysql/esm_item_box_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_code_lable_tab.sql
  source /tmp/ees_public//mysql/esm_item_code_lable_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_code_scheme_tab.sql
  source /tmp/ees_public//mysql/esm_item_code_scheme_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_cust_agr_tab.sql
  source /tmp/ees_public//mysql/esm_item_cust_agr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_grp_opr_path_tab.sql
  source /tmp/ees_public//mysql/esm_item_grp_opr_path_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_loc_map_tab.sql
  source /tmp/ees_public//mysql/esm_item_loc_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_loc_ref_tab.sql
  source /tmp/ees_public//mysql/esm_item_loc_ref_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_make_tab.sql
  source /tmp/ees_public//mysql/esm_item_make_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_opr_path_tab.sql
  source /tmp/ees_public//mysql/esm_item_opr_path_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_phy_loc_tab.sql
  source /tmp/ees_public//mysql/esm_item_phy_loc_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_qc_param_tab.sql
  source /tmp/ees_public//mysql/esm_item_qc_param_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_rate_tab.sql
  source /tmp/ees_public//mysql/esm_item_rate_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_raw_mat_cost_tab.sql
  source /tmp/ees_public//mysql/esm_item_raw_mat_cost_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_raw_mat_map_tab.sql
  source /tmp/ees_public//mysql/esm_item_raw_mat_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_rm_grp_map_tab.sql
  source /tmp/ees_public//mysql/esm_item_rm_grp_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_loc_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_loc_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_month_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_month_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_month_hist_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_month_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_txn_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_txn_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_txn_dtl_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_txn_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_stock_txn_loc_tab.sql
  source /tmp/ees_public//mysql/esm_item_stock_txn_loc_pkey.sql
  

  source /tmp/ees_public//mysql/esm_machine_sv_map_tab.sql
  source /tmp/ees_public//mysql/esm_machine_sv_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_mi_order_tab.sql
  source /tmp/ees_public//mysql/esm_mi_order_pkey.sql
  

  source /tmp/ees_public//mysql/esm_mi_order_item_tab.sql
  source /tmp/ees_public//mysql/esm_mi_order_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_opr_machine_map_tab.sql
  source /tmp/ees_public//mysql/esm_opr_machine_map_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pack_box_tab.sql
  source /tmp/ees_public//mysql/esm_pack_box_pkey.sql
  

  source /tmp/ees_public//mysql/esm_prod_machine_tab.sql
  source /tmp/ees_public//mysql/esm_prod_machine_pkey.sql
  

  source /tmp/ees_public//mysql/esm_prod_operation_tab.sql
  source /tmp/ees_public//mysql/esm_prod_operation_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_item_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_item_opr_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_item_opr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_item_opr_d_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_item_opr_d_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_item_opr_dh_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_item_opr_dh_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_order_item_opr_hist_tab.sql
  source /tmp/ees_public//mysql/esm_pr_order_item_opr_hist_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_ord_item_req_tab.sql
  source /tmp/ees_public//mysql/esm_pr_ord_item_req_pkey.sql
  

  source /tmp/ees_public//mysql/esm_pr_ord_item_req_dtl_tab.sql
  source /tmp/ees_public//mysql/esm_pr_ord_item_req_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/esm_qa_order_tab.sql
  source /tmp/ees_public//mysql/esm_qa_order_pkey.sql
  

  source /tmp/ees_public//mysql/esm_qa_order_item_tab.sql
  source /tmp/ees_public//mysql/esm_qa_order_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_qa_order_item_dtl_tab.sql
  source /tmp/ees_public//mysql/esm_qa_order_item_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/esm_qa_order_item_loc_tab.sql
  source /tmp/ees_public//mysql/esm_qa_order_item_loc_pkey.sql
  

  source /tmp/ees_public//mysql/esm_rack_slab_tab.sql
  source /tmp/ees_public//mysql/esm_rack_slab_pkey.sql
  

  source /tmp/ees_public//mysql/esm_room_cabin_tab.sql
  source /tmp/ees_public//mysql/esm_room_cabin_pkey.sql
  

  source /tmp/ees_public//mysql/esm_si_order_tab.sql
  source /tmp/ees_public//mysql/esm_si_order_pkey.sql
  

  source /tmp/ees_public//mysql/esm_si_order_item_tab.sql
  source /tmp/ees_public//mysql/esm_si_order_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_store_house_tab.sql
  source /tmp/ees_public//mysql/esm_store_house_pkey.sql
  

  source /tmp/ees_public//mysql/esm_store_room_tab.sql
  source /tmp/ees_public//mysql/esm_store_room_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_address_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_address_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_banker_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_banker_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_contact_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_contact_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_pay_card_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_pay_card_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_iaddr_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_iaddr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_inv_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_inv_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_inv_item_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_inv_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_item_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_po_payment_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_po_payment_pkey.sql
  

  source /tmp/ees_public//mysql/esm_tr_order_tab.sql
  source /tmp/ees_public//mysql/esm_tr_order_pkey.sql
  

  source /tmp/ees_public//mysql/esm_tr_order_item_tab.sql
  source /tmp/ees_public//mysql/esm_tr_order_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_warehouse_tab.sql
  source /tmp/ees_public//mysql/esm_warehouse_pkey.sql
  

  source /tmp/ees_public//mysql/esm_wrk_ord_tab.sql
  source /tmp/ees_public//mysql/esm_wrk_ord_pkey.sql
  

  source /tmp/ees_public//mysql/esm_wrk_ord_item_tab.sql
  source /tmp/ees_public//mysql/esm_wrk_ord_item_pkey.sql
  

  source /tmp/ees_public//mysql/esm_wrk_ord_item_dly_tab.sql
  source /tmp/ees_public//mysql/esm_wrk_ord_item_dly_pkey.sql
  

  source /tmp/ees_public//mysql/esm_wrk_ord_item_opr_tab.sql
  source /tmp/ees_public//mysql/esm_wrk_ord_item_opr_pkey.sql
  

  source /tmp/ees_public//mysql/esm_wrk_ord_item_oqa_tab.sql
  source /tmp/ees_public//mysql/esm_wrk_ord_item_oqa_pkey.sql
  

  source /tmp/ees_public//mysql/fa_account_group_tab.sql
  source /tmp/ees_public//mysql/fa_account_group_pkey.sql
  

  source /tmp/ees_public//mysql/fa_cr_dr_rule_tab.sql
  source /tmp/ees_public//mysql/fa_cr_dr_rule_pkey.sql
  

  source /tmp/ees_public//mysql/fa_gl_account_tab.sql
  source /tmp/ees_public//mysql/fa_gl_account_pkey.sql
  

  source /tmp/ees_public//mysql/fa_vc_limit_rule_tab.sql
  source /tmp/ees_public//mysql/fa_vc_limit_rule_pkey.sql
  

  source /tmp/ees_public//mysql/fa_vc_txn_tab.sql
  source /tmp/ees_public//mysql/fa_vc_txn_pkey.sql
  

  source /tmp/ees_public//mysql/fa_vc_txn_dtl_tab.sql
  source /tmp/ees_public//mysql/fa_vc_txn_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/fa_voucher_tab.sql
  source /tmp/ees_public//mysql/fa_voucher_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_file_attribute_tab.sql
  source /tmp/ees_public//mysql/gfh_file_attribute_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_file_format_tab.sql
  source /tmp/ees_public//mysql/gfh_file_format_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_format_header_field_tab.sql
  source /tmp/ees_public//mysql/gfh_format_header_field_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_format_layout_tab.sql
  source /tmp/ees_public//mysql/gfh_format_layout_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_function_def_tab.sql
  source /tmp/ees_public//mysql/gfh_function_def_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_layout_detrmn_tab.sql
  source /tmp/ees_public//mysql/gfh_layout_detrmn_pkey.sql
  

  source /tmp/ees_public//mysql/gfh_layout_field_tab.sql
  source /tmp/ees_public//mysql/gfh_layout_field_pkey.sql
  

  source /tmp/ees_public//mysql/gn_adjustment_tab.sql
  source /tmp/ees_public//mysql/gn_adjustment_pkey.sql
  

  source /tmp/ees_public//mysql/gn_alert_type_tab.sql
  source /tmp/ees_public//mysql/gn_alert_type_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_date_tab.sql
  source /tmp/ees_public//mysql/gn_appln_date_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_menu_tab.sql
  source /tmp/ees_public//mysql/gn_appln_menu_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_parameter_tab.sql
  source /tmp/ees_public//mysql/gn_appln_parameter_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_servlet_tab.sql
  source /tmp/ees_public//mysql/gn_appln_servlet_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_session_tab.sql
  source /tmp/ees_public//mysql/gn_appln_session_pkey.sql
  

  source /tmp/ees_public//mysql/gn_appln_tree_tab.sql
  source /tmp/ees_public//mysql/gn_appln_tree_pkey.sql
  

  source /tmp/ees_public//mysql/gn_bill_cycle_tab.sql
  source /tmp/ees_public//mysql/gn_bill_cycle_pkey.sql
  

  source /tmp/ees_public//mysql/gn_bill_cycle_profile_tab.sql
  source /tmp/ees_public//mysql/gn_bill_cycle_profile_pkey.sql
  

  source /tmp/ees_public//mysql/gn_business_area_tab.sql
  source /tmp/ees_public//mysql/gn_business_area_pkey.sql
  

  source /tmp/ees_public//mysql/gn_charge_tab.sql
  source /tmp/ees_public//mysql/gn_charge_pkey.sql
  

  source /tmp/ees_public//mysql/gn_charge_clubbed_tab.sql
  source /tmp/ees_public//mysql/gn_charge_clubbed_pkey.sql
  

  source /tmp/ees_public//mysql/gn_city_tab.sql
  source /tmp/ees_public//mysql/gn_city_pkey.sql
  

  source /tmp/ees_public//mysql/gn_continent_tab.sql
  source /tmp/ees_public//mysql/gn_continent_pkey.sql
  

  source /tmp/ees_public//mysql/gn_country_tab.sql
  source /tmp/ees_public//mysql/gn_country_pkey.sql
  

  source /tmp/ees_public//mysql/gn_css_tab.sql
  source /tmp/ees_public//mysql/gn_css_pkey.sql
  

  source /tmp/ees_public//mysql/gn_currency_tab.sql
  source /tmp/ees_public//mysql/gn_currency_pkey.sql
  

  source /tmp/ees_public//mysql/gn_doc_file_tab.sql
  source /tmp/ees_public//mysql/gn_doc_file_pkey.sql
  

  source /tmp/ees_public//mysql/gn_email_grp_tab.sql
  source /tmp/ees_public//mysql/gn_email_grp_pkey.sql
  

  source /tmp/ees_public//mysql/gn_faq_tab.sql
  source /tmp/ees_public//mysql/gn_faq_pkey.sql
  

  source /tmp/ees_public//mysql/gn_faq_ans_tab.sql
  source /tmp/ees_public//mysql/gn_faq_ans_pkey.sql
  

  source /tmp/ees_public//mysql/gn_fy_checklist_tab.sql
  source /tmp/ees_public//mysql/gn_fy_checklist_pkey.sql
  

  source /tmp/ees_public//mysql/gn_letter_head_tab.sql
  source /tmp/ees_public//mysql/gn_letter_head_pkey.sql
  

  source /tmp/ees_public//mysql/gn_letter_rule_tab.sql
  source /tmp/ees_public//mysql/gn_letter_rule_pkey.sql
  

  source /tmp/ees_public//mysql/gn_letter_text_tab.sql
  source /tmp/ees_public//mysql/gn_letter_text_pkey.sql
  

  source /tmp/ees_public//mysql/gn_lnf_template_tab.sql
  source /tmp/ees_public//mysql/gn_lnf_template_pkey.sql
  

  source /tmp/ees_public//mysql/gn_menu_access_tab.sql
  source /tmp/ees_public//mysql/gn_menu_access_pkey.sql
  

  source /tmp/ees_public//mysql/gn_menu_access_by_role_tab.sql
  source /tmp/ees_public//mysql/gn_menu_access_by_role_pkey.sql
  

  source /tmp/ees_public//mysql/gn_message_tab.sql
  source /tmp/ees_public//mysql/gn_message_pkey.sql
  

  source /tmp/ees_public//mysql/gn_news_tab.sql
  source /tmp/ees_public//mysql/gn_news_pkey.sql
  

  source /tmp/ees_public//mysql/gn_ol_dev_tab.sql
  source /tmp/ees_public//mysql/gn_ol_dev_pkey.sql
  

  source /tmp/ees_public//mysql/gn_ord_route_rule_tab.sql
  source /tmp/ees_public//mysql/gn_ord_route_rule_pkey.sql
  

  source /tmp/ees_public//mysql/gn_ord_route_tree_tab.sql
  source /tmp/ees_public//mysql/gn_ord_route_tree_pkey.sql
  

  source /tmp/ees_public//mysql/gn_os_user_tab.sql
  source /tmp/ees_public//mysql/gn_os_user_pkey.sql
  

  source /tmp/ees_public//mysql/gn_payment_charge_tab.sql
  source /tmp/ees_public//mysql/gn_payment_charge_pkey.sql
  

  source /tmp/ees_public//mysql/gn_payment_invoice_tab.sql
  source /tmp/ees_public//mysql/gn_payment_invoice_pkey.sql
  

  source /tmp/ees_public//mysql/gn_payment_txn_tab.sql
  source /tmp/ees_public//mysql/gn_payment_txn_pkey.sql
  

  source /tmp/ees_public//mysql/gn_prod_reg_tab.sql
  source /tmp/ees_public//mysql/gn_prod_reg_pkey.sql
  

  source /tmp/ees_public//mysql/gn_project_tab.sql
  source /tmp/ees_public//mysql/gn_project_pkey.sql
  

  source /tmp/ees_public//mysql/gn_project_unit_txn_tab.sql
  source /tmp/ees_public//mysql/gn_project_unit_txn_pkey.sql
  

  source /tmp/ees_public//mysql/gn_project_unit_txn_hist_tab.sql
  source /tmp/ees_public//mysql/gn_project_unit_txn_hist_pkey.sql
  

  source /tmp/ees_public//mysql/gn_project_user_tab.sql
  source /tmp/ees_public//mysql/gn_project_user_pkey.sql
  

  source /tmp/ees_public//mysql/gn_qa_feedback_tab.sql
  source /tmp/ees_public//mysql/gn_qa_feedback_pkey.sql
  

  source /tmp/ees_public//mysql/gn_qa_feedback_sch_tab.sql
  source /tmp/ees_public//mysql/gn_qa_feedback_sch_pkey.sql
  

  source /tmp/ees_public//mysql/gn_query_tab.sql
  source /tmp/ees_public//mysql/gn_query_pkey.sql
  

  source /tmp/ees_public//mysql/gn_refund_tab.sql
  source /tmp/ees_public//mysql/gn_refund_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sst_app_cfg_param_tab.sql
  source /tmp/ees_public//mysql/gn_sst_app_cfg_param_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_party_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_party_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_advert_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_advert_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_data_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_data_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_it_sol_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_it_sol_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_pre_pro_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_pre_pro_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sstptl_user_web_tab.sql
  source /tmp/ees_public//mysql/gn_sstptl_user_web_pkey.sql
  

  source /tmp/ees_public//mysql/gn_sst_seq_tab.sql
  source /tmp/ees_public//mysql/gn_sst_seq_pkey.sql
  

  source /tmp/ees_public//mysql/gn_state_tab.sql
  source /tmp/ees_public//mysql/gn_state_pkey.sql
  

  source /tmp/ees_public//mysql/gn_tree_object_tab.sql
  source /tmp/ees_public//mysql/gn_tree_object_pkey.sql
  

  source /tmp/ees_public//mysql/gn_type_code_tab.sql
  source /tmp/ees_public//mysql/gn_type_code_pkey.sql
  

  source /tmp/ees_public//mysql/gn_type_value_tab.sql
  source /tmp/ees_public//mysql/gn_type_value_pkey.sql
  

  source /tmp/ees_public//mysql/gn_user_tab.sql
  source /tmp/ees_public//mysql/gn_user_pkey.sql
  

  source /tmp/ees_public//mysql/gn_user_access_tab.sql
  source /tmp/ees_public//mysql/gn_user_access_pkey.sql
  

  source /tmp/ees_public//mysql/gn_user_role_tab.sql
  source /tmp/ees_public//mysql/gn_user_role_pkey.sql
  

  source /tmp/ees_public//mysql/job_flow_tab.sql
  source /tmp/ees_public//mysql/job_flow_pkey.sql
  

  source /tmp/ees_public//mysql/job_program_tab.sql
  source /tmp/ees_public//mysql/job_program_pkey.sql
  

  source /tmp/ees_public//mysql/job_status_dtl_tab.sql
  source /tmp/ees_public//mysql/job_status_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/rms_action_tab.sql
  source /tmp/ees_public//mysql/rms_action_pkey.sql
  

  source /tmp/ees_public//mysql/rms_condition_tab.sql
  source /tmp/ees_public//mysql/rms_condition_pkey.sql
  

  source /tmp/ees_public//mysql/rms_function_tab.sql
  source /tmp/ees_public//mysql/rms_function_pkey.sql
  

  source /tmp/ees_public//mysql/rms_function_param_tab.sql
  source /tmp/ees_public//mysql/rms_function_param_pkey.sql
  

  source /tmp/ees_public//mysql/rms_macro_tab.sql
  source /tmp/ees_public//mysql/rms_macro_pkey.sql
  

  source /tmp/ees_public//mysql/rms_rule_tab.sql
  source /tmp/ees_public//mysql/rms_rule_pkey.sql
  

  source /tmp/ees_public//mysql/rms_threshold_tab.sql
  source /tmp/ees_public//mysql/rms_threshold_pkey.sql
  

  source /tmp/ees_public//mysql/hr_absent_type_tab.sql
  source /tmp/ees_public//mysql/hr_absent_type_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_academic_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_academic_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_address_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_address_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_contact_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_contact_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_employer_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_employer_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_health_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_health_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_identity_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_identity_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_rate_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_rate_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_req_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_req_pkey.sql
  

  source /tmp/ees_public//mysql/hr_applicant_skill_domain_tab.sql
  source /tmp/ees_public//mysql/hr_applicant_skill_domain_pkey.sql
  

  source /tmp/ees_public//mysql/hr_banker_tab.sql
  source /tmp/ees_public//mysql/hr_banker_pkey.sql
  

  source /tmp/ees_public//mysql/hr_budget_code_tab.sql
  source /tmp/ees_public//mysql/hr_budget_code_pkey.sql
  

  source /tmp/ees_public//mysql/hr_building_tab.sql
  source /tmp/ees_public//mysql/hr_building_pkey.sql
  

  source /tmp/ees_public//mysql/hr_building_room_tab.sql
  source /tmp/ees_public//mysql/hr_building_room_pkey.sql
  

  source /tmp/ees_public//mysql/hr_card_file_tab.sql
  source /tmp/ees_public//mysql/hr_card_file_pkey.sql
  

  source /tmp/ees_public//mysql/hr_card_time_tab.sql
  source /tmp/ees_public//mysql/hr_card_time_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cost_center_tab.sql
  source /tmp/ees_public//mysql/hr_cost_center_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_agr_act_tab.sql
  source /tmp/ees_public//mysql/hr_cust_agr_act_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_agr_act_hist_tab.sql
  source /tmp/ees_public//mysql/hr_cust_agr_act_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_agreement_tab.sql
  source /tmp/ees_public//mysql/hr_cust_agreement_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_agreement_hist_tab.sql
  source /tmp/ees_public//mysql/hr_cust_agreement_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_agr_form_tab.sql
  source /tmp/ees_public//mysql/hr_cust_agr_form_pkey.sql
  

  source /tmp/ees_public//mysql/hr_cust_rate_plan_tab.sql
  source /tmp/ees_public//mysql/hr_cust_rate_plan_pkey.sql
  

  source /tmp/ees_public//mysql/hr_department_tab.sql
  source /tmp/ees_public//mysql/hr_department_pkey.sql
  

  source /tmp/ees_public//mysql/hr_dept_expense_summary_tab.sql
  source /tmp/ees_public//mysql/hr_dept_expense_summary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_dept_general_expense_tab.sql
  source /tmp/ees_public//mysql/hr_dept_general_expense_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_academic_tab.sql
  source /tmp/ees_public//mysql/hr_emp_academic_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_activity_tab.sql
  source /tmp/ees_public//mysql/hr_emp_activity_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_activity_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_activity_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_address_tab.sql
  source /tmp/ees_public//mysql/hr_emp_address_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_agreement_tab.sql
  source /tmp/ees_public//mysql/hr_emp_agreement_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_agreement_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_agreement_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_appraisal_tab.sql
  source /tmp/ees_public//mysql/hr_emp_appraisal_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_attendance_sum_tab.sql
  source /tmp/ees_public//mysql/hr_emp_attendance_sum_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_clubbed_salary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_clubbed_salary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_clubbed_salary_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_clubbed_salary_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_daily_timesheet_tab.sql
  source /tmp/ees_public//mysql/hr_emp_daily_timesheet_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_daily_timesheet_sum_tab.sql
  source /tmp/ees_public//mysql/hr_emp_daily_timesheet_sum_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_employer_tab.sql
  source /tmp/ees_public//mysql/hr_emp_employer_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_expense_summary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_expense_summary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_family_academic_tab.sql
  source /tmp/ees_public//mysql/hr_emp_family_academic_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_feedback_tab.sql
  source /tmp/ees_public//mysql/hr_emp_feedback_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_general_expense_tab.sql
  source /tmp/ees_public//mysql/hr_emp_general_expense_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_health_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_emp_health_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_identity_tab.sql
  source /tmp/ees_public//mysql/hr_emp_identity_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_inc_prom_tab.sql
  source /tmp/ees_public//mysql/hr_emp_inc_prom_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_inc_prom_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_emp_inc_prom_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_inc_prom_dtl_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_inc_prom_dtl_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_inc_prom_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_inc_prom_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_installment_tab.sql
  source /tmp/ees_public//mysql/hr_emp_installment_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_local_conveyance_tab.sql
  source /tmp/ees_public//mysql/hr_emp_local_conveyance_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_tab.sql
  source /tmp/ees_public//mysql/hr_employee_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_family_tab.sql
  source /tmp/ees_public//mysql/hr_employee_family_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_hist_tab.sql
  source /tmp/ees_public//mysql/hr_employee_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_rate_tab.sql
  source /tmp/ees_public//mysql/hr_employee_rate_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_request_tab.sql
  source /tmp/ees_public//mysql/hr_employee_request_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_shift_tab.sql
  source /tmp/ees_public//mysql/hr_employee_shift_pkey.sql
  

  source /tmp/ees_public//mysql/hr_employee_shift_hist_tab.sql
  source /tmp/ees_public//mysql/hr_employee_shift_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_medi_claim_tab.sql
  source /tmp/ees_public//mysql/hr_emp_medi_claim_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_medi_claim_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_emp_medi_claim_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_rr_accrued_amt_tab.sql
  source /tmp/ees_public//mysql/hr_emp_rr_accrued_amt_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_salary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_salary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_salary_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_salary_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_salary_summary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_salary_summary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_salary_summary_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_salary_summary_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_shift_change_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_emp_shift_change_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_skill_domain_tab.sql
  source /tmp/ees_public//mysql/hr_emp_skill_domain_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_spl_date_tab.sql
  source /tmp/ees_public//mysql/hr_emp_spl_date_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_timesheet_tab.sql
  source /tmp/ees_public//mysql/hr_emp_timesheet_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_timesheet_summary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_timesheet_summary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_total_salary_tab.sql
  source /tmp/ees_public//mysql/hr_emp_total_salary_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_total_salary_hist_tab.sql
  source /tmp/ees_public//mysql/hr_emp_total_salary_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_vacation_bal_tab.sql
  source /tmp/ees_public//mysql/hr_emp_vacation_bal_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_vacation_encash_tab.sql
  source /tmp/ees_public//mysql/hr_emp_vacation_encash_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_yearly_tax_tab.sql
  source /tmp/ees_public//mysql/hr_emp_yearly_tax_pkey.sql
  

  source /tmp/ees_public//mysql/hr_eval_criteria_tab.sql
  source /tmp/ees_public//mysql/hr_eval_criteria_pkey.sql
  

  source /tmp/ees_public//mysql/hr_finance_year_def_tab.sql
  source /tmp/ees_public//mysql/hr_finance_year_def_pkey.sql
  

  source /tmp/ees_public//mysql/hr_holiday_tab.sql
  source /tmp/ees_public//mysql/hr_holiday_pkey.sql
  

  source /tmp/ees_public//mysql/hr_job_alloc_tab.sql
  source /tmp/ees_public//mysql/hr_job_alloc_pkey.sql
  

  source /tmp/ees_public//mysql/hr_job_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_job_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_logical_grp_tab.sql
  source /tmp/ees_public//mysql/hr_logical_grp_pkey.sql
  

  source /tmp/ees_public//mysql/hr_org_account_tab.sql
  source /tmp/ees_public//mysql/hr_org_account_pkey.sql
  

  source /tmp/ees_public//mysql/hr_organization_tab.sql
  source /tmp/ees_public//mysql/hr_organization_pkey.sql
  

  source /tmp/ees_public//mysql/hr_organization_address_tab.sql
  source /tmp/ees_public//mysql/hr_organization_address_pkey.sql
  

  source /tmp/ees_public//mysql/hr_org_parameter_tab.sql
  source /tmp/ees_public//mysql/hr_org_parameter_pkey.sql
  

  source /tmp/ees_public//mysql/hr_org_project_tab.sql
  source /tmp/ees_public//mysql/hr_org_project_pkey.sql
  

  source /tmp/ees_public//mysql/hr_outsource_emp_tab.sql
  source /tmp/ees_public//mysql/hr_outsource_emp_pkey.sql
  

  source /tmp/ees_public//mysql/hr_outsource_emp_hist_tab.sql
  source /tmp/ees_public//mysql/hr_outsource_emp_hist_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_tab.sql
  source /tmp/ees_public//mysql/hr_position_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_eligibility_tab.sql
  source /tmp/ees_public//mysql/hr_position_eligibility_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_job_profile_tab.sql
  source /tmp/ees_public//mysql/hr_position_job_profile_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_level_tab.sql
  source /tmp/ees_public//mysql/hr_position_level_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_quali_tab.sql
  source /tmp/ees_public//mysql/hr_position_quali_pkey.sql
  

  source /tmp/ees_public//mysql/hr_position_skill_tab.sql
  source /tmp/ees_public//mysql/hr_position_skill_pkey.sql
  

  source /tmp/ees_public//mysql/hr_project_requirement_tab.sql
  source /tmp/ees_public//mysql/hr_project_requirement_pkey.sql
  

  source /tmp/ees_public//mysql/hr_project_team_member_tab.sql
  source /tmp/ees_public//mysql/hr_project_team_member_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruitment_tab.sql
  source /tmp/ees_public//mysql/hr_recruitment_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruitment_memo_tab.sql
  source /tmp/ees_public//mysql/hr_recruitment_memo_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruitment_req_tab.sql
  source /tmp/ees_public//mysql/hr_recruitment_req_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruitment_round_tab.sql
  source /tmp/ees_public//mysql/hr_recruitment_round_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruitment_vendor_tab.sql
  source /tmp/ees_public//mysql/hr_recruitment_vendor_pkey.sql
  

  source /tmp/ees_public//mysql/hr_recruit_post_skill_tab.sql
  source /tmp/ees_public//mysql/hr_recruit_post_skill_pkey.sql
  

  source /tmp/ees_public//mysql/hr_salary_cycle_tab.sql
  source /tmp/ees_public//mysql/hr_salary_cycle_pkey.sql
  

  source /tmp/ees_public//mysql/hr_salary_cycle_profile_tab.sql
  source /tmp/ees_public//mysql/hr_salary_cycle_profile_pkey.sql
  

  source /tmp/ees_public//mysql/hr_salary_head_tab.sql
  source /tmp/ees_public//mysql/hr_salary_head_pkey.sql
  

  source /tmp/ees_public//mysql/hr_salary_run_date_tab.sql
  source /tmp/ees_public//mysql/hr_salary_run_date_pkey.sql
  

  source /tmp/ees_public//mysql/hr_shift_tab.sql
  source /tmp/ees_public//mysql/hr_shift_pkey.sql
  

  source /tmp/ees_public//mysql/hr_skill_set_tab.sql
  source /tmp/ees_public//mysql/hr_skill_set_pkey.sql
  

  source /tmp/ees_public//mysql/hr_tax_rebate_reason_tab.sql
  source /tmp/ees_public//mysql/hr_tax_rebate_reason_pkey.sql
  

  source /tmp/ees_public//mysql/hr_tax_rebate_reason_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_tax_rebate_reason_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_tax_rule_tab.sql
  source /tmp/ees_public//mysql/hr_tax_rule_pkey.sql
  

  source /tmp/ees_public//mysql/hr_timesheet_rep_tab.sql
  source /tmp/ees_public//mysql/hr_timesheet_rep_pkey.sql
  

  source /tmp/ees_public//mysql/hr_trainee_attn_tab.sql
  source /tmp/ees_public//mysql/hr_trainee_attn_pkey.sql
  

  source /tmp/ees_public//mysql/hr_training_charge_tab.sql
  source /tmp/ees_public//mysql/hr_training_charge_pkey.sql
  

  source /tmp/ees_public//mysql/hr_training_course_tab.sql
  source /tmp/ees_public//mysql/hr_training_course_pkey.sql
  

  source /tmp/ees_public//mysql/hr_training_grp_req_tab.sql
  source /tmp/ees_public//mysql/hr_training_grp_req_pkey.sql
  

  source /tmp/ees_public//mysql/hr_training_req_tab.sql
  source /tmp/ees_public//mysql/hr_training_req_pkey.sql
  

  source /tmp/ees_public//mysql/hr_training_sch_tab.sql
  source /tmp/ees_public//mysql/hr_training_sch_pkey.sql
  

  source /tmp/ees_public//mysql/hr_travel_expense_report_tab.sql
  source /tmp/ees_public//mysql/hr_travel_expense_report_pkey.sql
  

  source /tmp/ees_public//mysql/hr_travel_req_tab.sql
  source /tmp/ees_public//mysql/hr_travel_req_pkey.sql
  

  source /tmp/ees_public//mysql/hr_travel_req_dtl_tab.sql
  source /tmp/ees_public//mysql/hr_travel_req_dtl_pkey.sql
  

  source /tmp/ees_public//mysql/hr_vacation_request_tab.sql
  source /tmp/ees_public//mysql/hr_vacation_request_pkey.sql
  

  source /tmp/ees_public//mysql/hr_vendor_tab.sql
  source /tmp/ees_public//mysql/hr_vendor_pkey.sql
  

  source /tmp/ees_public//mysql/hr_wages_statewise_tab.sql
  source /tmp/ees_public//mysql/hr_wages_statewise_pkey.sql
  

  source /tmp/ees_public//mysql/im_item_stock_tab.sql
  source /tmp/ees_public//mysql/im_item_stock_pkey.sql
  

  source /tmp/ees_public//mysql/im_monthly_stock_temp_tab.sql
  source /tmp/ees_public//mysql/im_monthly_stock_temp_pkey.sql
  

  source /tmp/ees_public//mysql/jag_cnsty_tab.sql
  source /tmp/ees_public//mysql/jag_cnsty_pkey.sql
  

  source /tmp/ees_public//mysql/jag_eval_criteria_tab.sql
  source /tmp/ees_public//mysql/jag_eval_criteria_pkey.sql
  

  source /tmp/ees_public//mysql/jag_member_rate_tab.sql
  source /tmp/ees_public//mysql/jag_member_rate_pkey.sql
  

  source /tmp/ees_public//mysql/jag_my_mem_team_tab.sql
  source /tmp/ees_public//mysql/jag_my_mem_team_pkey.sql
  

  source /tmp/ees_public//mysql/jag_my_mf_tab.sql
  source /tmp/ees_public//mysql/jag_my_mf_pkey.sql
  

  source /tmp/ees_public//mysql/jag_my_quiz_choice_tab.sql
  source /tmp/ees_public//mysql/jag_my_quiz_choice_pkey.sql
  

  source /tmp/ees_public//mysql/jag_quiz_quest_tab.sql
  source /tmp/ees_public//mysql/jag_quiz_quest_pkey.sql
  

  source /tmp/ees_public//mysql/ees_class_student_tab.sql
  source /tmp/ees_public//mysql/ees_class_student_pkey.sql
  

  source /tmp/ees_public//mysql/ees_room_class_tab.sql
  source /tmp/ees_public//mysql/ees_room_class_pkey.sql
  

  source /tmp/ees_public//mysql/ees_student_trip_tab.sql
  source /tmp/ees_public//mysql/ees_student_trip_pkey.sql
  

  source /tmp/ees_public//mysql/ees_subject_faculty_obso_tab.sql
  source /tmp/ees_public//mysql/ees_subject_faculty_obso_pkey.sql
  

  source /tmp/ees_public//mysql/ees_tt_faculty_prd_cons_tab.sql
  source /tmp/ees_public//mysql/ees_tt_faculty_prd_cons_pkey.sql
  

  source /tmp/ees_public//mysql/ehs_patient_medi_hist_obso_tab.sql
  source /tmp/ees_public//mysql/ehs_patient_medi_hist_obso_pkey.sql
  

  source /tmp/ees_public//mysql/esm_customer_address_delme_tab.sql
  source /tmp/ees_public//mysql/esm_customer_address_delme_pkey.sql
  

  source /tmp/ees_public//mysql/esm_item_make_rate_obso_tab.sql
  source /tmp/ees_public//mysql/esm_item_make_rate_obso_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_address_delme_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_address_delme_pkey.sql
  

  source /tmp/ees_public//mysql/esm_supplier_address_delme1_tab.sql
  source /tmp/ees_public//mysql/esm_supplier_address_delme1_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_banker_tab.sql
  source /tmp/ees_public//mysql/hr_emp_banker_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_contact_tab.sql
  source /tmp/ees_public//mysql/hr_emp_contact_pkey.sql
  

  source /tmp/ees_public//mysql/hr_emp_daily_hour_tab.sql
  source /tmp/ees_public//mysql/hr_emp_daily_hour_pkey.sql
  

  source /tmp/ees_public//mysql/jag_user_hist_tab.sql
  source /tmp/ees_public//mysql/jag_user_hist_pkey.sql
  

  source /tmp/ees_public//mysql/job_flow_tab_tab.sql
  source /tmp/ees_public//mysql/job_flow_tab_pkey.sql
  

  source /tmp/ees_public//mysql/ots_doc_tab.sql
  source /tmp/ees_public//mysql/ots_doc_pkey.sql
  

  source /tmp/ees_public//mysql/ots_doc_item_tab.sql
  source /tmp/ees_public//mysql/ots_doc_item_pkey.sql
  

  source /tmp/ees_public//mysql/ots_inv_amt_dist_tab.sql
  source /tmp/ees_public//mysql/ots_inv_amt_dist_pkey.sql
  

  source /tmp/ees_public//mysql/ots_inv_amt_dist_clubbed_tab.sql
  source /tmp/ees_public//mysql/ots_inv_amt_dist_clubbed_pkey.sql
  

  source /tmp/ees_public//mysql/ots_inv_amt_dist_rule_tab.sql
  source /tmp/ees_public//mysql/ots_inv_amt_dist_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ots_item_om_rule_tab.sql
  source /tmp/ees_public//mysql/ots_item_om_rule_pkey.sql
  

  source /tmp/ees_public//mysql/ots_member_tab.sql
  source /tmp/ees_public//mysql/ots_member_pkey.sql
  

  source /tmp/ees_public//mysql/ots_ord_sts_wait_tab.sql
  source /tmp/ees_public//mysql/ots_ord_sts_wait_pkey.sql
  

  source /tmp/ees_public//mysql/ots_shopping_cart_tab.sql
  source /tmp/ees_public//mysql/ots_shopping_cart_pkey.sql
  

  source /tmp/ees_public//mysql/pbs_club_tab.sql
  source /tmp/ees_public//mysql/pbs_club_pkey.sql
  

  source /tmp/ees_public//mysql/pbs_pkg_ftr_tab.sql
  source /tmp/ees_public//mysql/pbs_pkg_ftr_pkey.sql
  

  source /tmp/ees_public//mysql/pbs_point_tab.sql
  source /tmp/ees_public//mysql/pbs_point_pkey.sql
  

  source /tmp/ees_public//mysql/pbs_point_clubbed_tab.sql
  source /tmp/ees_public//mysql/pbs_point_clubbed_pkey.sql
  

  source /tmp/ees_public//mysql/pbs_point_info_tab.sql
  source /tmp/ees_public//mysql/pbs_point_info_pkey.sql
  

  source /tmp/ees_public//mysql/qa_defect_tab.sql
  source /tmp/ees_public//mysql/qa_defect_pkey.sql
  

  source /tmp/ees_public//mysql/qa_testcase_tab.sql
  source /tmp/ees_public//mysql/qa_testcase_pkey.sql
  

  source /tmp/ees_public//mysql/qa_testcase_step_tab.sql
  source /tmp/ees_public//mysql/qa_testcase_step_pkey.sql
  

  source /tmp/ees_public//mysql/all_circle_tab.sql
  source /tmp/ees_public//mysql/all_circle_pkey.sql
  

  source /tmp/ees_public//mysql/all_division_tab.sql
  source /tmp/ees_public//mysql/all_division_pkey.sql
  
