SST_ESM_JAR=
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//mysql/sst_com_mysql.jar
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//mysql/sst_opr_mysql.jar



sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BANK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE_HISTORY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_CHARGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_MASTER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_BLOOD_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_EMPLOYER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_IDENTITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_MAIL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_PHONE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUST_AGREEMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUSTOMER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE_MON_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_SRC_FILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ACADEMIC_SESSION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_LIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_MARK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_SUB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI_PROF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_ACADEMIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_PREV_MARK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_REF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AS_CHECKLIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD_DISTRIBUTION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_SCH_SHIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CONTRACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE_STREAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_DAILY_TRIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_ACTIVITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_GUEST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_STUD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_CLASS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_PAPER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUESTION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUEST_MO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_ROOM_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SCHEDULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SEAT_PLAN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_TERM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CONCESSION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_DUE_DATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD_CLASS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_ACAD_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC_ACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRADE_SYSTEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANTER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT_INST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ATTN_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BED mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_COMPLAIN_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_EXIT_ENTRY_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FLW_QTY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_INV mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_RTW_QTY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISITOR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISIT_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WING mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_INSTITUTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_EQP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LATE_FEE_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_ATTEND mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_PLAN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ATTN_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK_ISSUE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ISSUE_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIBRARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER_USE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MARKSHEET_LO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_DIET_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_FEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MON_FRT_ACAD_REP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_PERIOD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_ALLOTMENT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE_STOPPAGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SCH_SHIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_ACADEMIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_CTG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_EXTRA_ACH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FAMILY_ACAD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARKSHEET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_QUEST_MARK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_REF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SCH_SHIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SUBJECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ALLOCATION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ELECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MARK_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_SYLB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_HDR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_MODEL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CFR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CI_STUDENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIV mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_COMPANY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_INVITEE_INST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_ORGANIZER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_PROGRAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_STUDENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_TRAINING_PLAN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TP_FEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TP_SNM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TRIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_AF_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_DRIVER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_LOCATION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_APPOINTMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BED_AVAIL_STAT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BIRTH_CERTIFICATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DEATH_CERTIFICATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_AVAIL_STATUS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_FEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_TIMESHEET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DRUG_MASTER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMERGENCY_RECORD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_MEDI_IV_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_NURSE_ASSESMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP_SRV_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PRICING mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PURCHASE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_SALE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_MEDICAL_TEST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_ANS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_EQP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_STAFF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ATTENDANT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_DIAGNOSIS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_FAMILY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_HIST_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_IDENTITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_LIFE_STYLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_PAST_ILLNESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VACCINATION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VITAL_SIGN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PRESCRIPTION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM_BED mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SALESMAN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPONSORSHIP_POLICY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SRV_CHARGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_REPORT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_SAMPLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_VACCINATION_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_WARD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_DOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IADDR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IHIER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_NOTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_IADDR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ATTRIBUTE_LIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CABIN_RACK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_ITEM_CODE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_BANKER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_GRP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PACK_LIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PAY_CARD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PACK_LIST_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GEN_CFR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GENERAL_LICENSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_AGENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_ORG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_POLICY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_REVERT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_SRC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_ATTRIBUTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_BOX_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_LABLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_SCHEME mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CUST_AGR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_GRP_OPR_PATH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_REF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_OPR_PATH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_PHY_LOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_QC_PARAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_COST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RM_GRP_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_LOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_LOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MACHINE_SV_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_OPR_MACHINE_MAP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PACK_BOX mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_MACHINE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_OPERATION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_D mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_DH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_LOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_RACK_SLAB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ROOM_CABIN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_HOUSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_ROOM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_BANKER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PAY_CARD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_IADDR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_PAYMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WAREHOUSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_DLY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OPR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OQA mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_ACCOUNT_GROUP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_CR_DR_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_GL_ACCOUNT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_LIMIT_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VOUCHER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FILE_ATTRIBUTE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FILE_FORMAT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FORMAT_HEADER_FIELD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FORMAT_LAYOUT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FUNCTION_DEF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_LAYOUT_DETRMN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_LAYOUT_FIELD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ADJUSTMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ALERT_TYPE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_DATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_MENU mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_PARAMETER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SERVLET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SESSION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_TREE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE_PROFILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BUSINESS_AREA mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE_CLUBBED mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CONTINENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_COUNTRY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CSS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CURRENCY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_DOC_FILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_EMAIL_GRP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FAQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FAQ_ANS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FY_CHECKLIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_HEAD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_TEXT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LNF_TEMPLATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS_BY_ROLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MESSAGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_NEWS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_OL_DEV mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_TREE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_OS_USER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_CHARGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_INVOICE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_TXN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROD_REG mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_USER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QA_FEEDBACK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QA_FEEDBACK_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QUERY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_REFUND mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SST_APP_CFG_PARAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_PARTY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_ADVERT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_DATA mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_IT_SOL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PRE_PRO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_WEB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SST_SEQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_STATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TREE_OBJECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_CODE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_VALUE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ACCESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ROLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_FLOW mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_PROGRAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_STATUS_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_ACTION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_CONDITION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_FUNCTION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_FUNCTION_PARAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_MACRO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_THRESHOLD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ABSENT_TYPE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ACADEMIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_EMPLOYER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_HEALTH_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_IDENTITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_RATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_SKILL_DOMAIN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BANKER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUDGET_CODE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING_ROOM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_FILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_TIME mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_COST_CENTER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_ACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_ACT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_FORM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_RATE_PLAN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPARTMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_EXPENSE_SUMMARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_GENERAL_EXPENSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACADEMIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_APPRAISAL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ATTENDANCE_SUM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET_SUM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EMPLOYER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EXPENSE_SUMMARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FAMILY_ACADEMIC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FEEDBACK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_GENERAL_EXPENSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_HEALTH_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_IDENTITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INSTALLMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_LOCAL_CONVEYANCE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_FAMILY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_RATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_REQUEST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_RR_ACCRUED_AMT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SHIFT_CHANGE_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SKILL_DOMAIN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SPL_DATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET_SUMMARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_BAL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_ENCASH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_YEARLY_TAX mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EVAL_CRITERIA mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_FINANCE_YEAR_DEF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_HOLIDAY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_ALLOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_LOGICAL_GRP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_ACCOUNT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION_ADDRESS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PARAMETER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PROJECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_ELIGIBILITY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_JOB_PROFILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_LEVEL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_QUALI mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_SKILL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_REQUIREMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_TEAM_MEMBER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_MEMO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_ROUND mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_VENDOR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUIT_POST_SKILL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE_PROFILE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_HEAD mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_RUN_DATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SHIFT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SKILL_SET mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TIMESHEET_REP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINEE_ATTN mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_CHARGE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_COURSE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_GRP_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_SCH mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_EXPENSE_REPORT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ_DTL mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VACATION_REQUEST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VENDOR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_WAGES_STATEWISE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_ITEM_STOCK mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_MONTHLY_STOCK_TEMP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_CNSTY mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_EVAL_CRITERIA mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MEMBER_RATE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_MEM_TEAM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_MF mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_QUIZ_CHOICE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_QUIZ_QUEST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_STUDENT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_CLASS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_TRIP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_FACULTY_OBSO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_FACULTY_PRD_CONS mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_MEDI_HIST_OBSO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS_DELME mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE_RATE_OBSO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME1 mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_BANKER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CONTACT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_HOUR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_USER_HIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_FLOW_TAB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC_ITEM mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_CLUBBED mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ITEM_OM_RULE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_MEMBER mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ORD_STS_WAIT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_SHOPPING_CART mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_CLUB mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_PKG_FTR mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_CLUBBED mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_INFO mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_DEFECT mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE_STEP mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ALL_CIRCLE mysql 
sleep 1
sh opr_tab_obj_gen_java.sh  ALL_DIVISION mysql 
sleep 1
