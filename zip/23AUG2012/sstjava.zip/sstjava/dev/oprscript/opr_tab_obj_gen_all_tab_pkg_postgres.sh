SST_ESM_JAR=
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//postgres/sst_com_postgres.jar
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//postgres/sst_opr_postgres.jar



sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BANK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE_HISTORY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_CHARGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_MASTER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_BLOOD_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_EMPLOYER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_MAIL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_PHONE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_CRON_JOB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_DTXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_DTXN_CF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_MEMBER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_MEMBER_SYMBOL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_ORG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_SYMBOL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_SYMBOL_CNTR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  CX_SYMBOL_DAILY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUST_AGREEMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUSTOMER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE_MON_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_SRC_FILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ACADEMIC_SESSION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_LIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_MARK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_SUB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI_PROF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_PREV_MARK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_REF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AS_CHECKLIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD_DISTRIBUTION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_SCH_SHIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CONTRACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE_STREAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_DAILY_TRIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_ACTIVITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_GUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_STUD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_PAPER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUESTION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUEST_MO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_ROOM_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SCHEDULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SEAT_PLAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_TERM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CONCESSION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_DUE_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_PKG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_PKG_STRUCT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_ACAD_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC_ACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRADE_SYSTEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANTER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT_INST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ATTN_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BED postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_COMPLAIN_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_EXIT_ENTRY_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FLW_QTY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_INV postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_RTW_QTY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISITOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISIT_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_INSTITUTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_EQP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LATE_FEE_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_ATTEND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_PLAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ATTN_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK_ISSUE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ISSUE_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIBRARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER_USE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MARKSHEET_LO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_DIET_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_FEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MON_FRT_ACAD_REP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_OD_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_OD_CLASS_CAND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_OD_CLASS_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_PERIOD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_QUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_QUEST_BY_USER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_SCH_CAND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_SCH_INST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_QUIZ_SCH_QUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_ALLOTMENT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE_STOPPAGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SCH_SHIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_CTG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_CTG_FEE_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_EXTRA_ACH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FAMILY_ACAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARKSHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_QUEST_MARK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_REF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SCH_SHIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SUBJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ALLOCATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ELECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MARK_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_SYLB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_HDR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_MODEL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CFR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CI_STUDENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIV postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_COMPANY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_INVITEE_INST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_ORGANIZER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_PROGRAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_STUDENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_TRAINING_PLAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TP_FEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TP_SNM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TRIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_AF_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_DRIVER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_LOCATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_APPOINTMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BED_AVAIL_STAT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BIRTH_CERTIFICATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DEATH_CERTIFICATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_AVAIL_STATUS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_FEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_TIMESHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DRUG_MASTER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMERGENCY_RECORD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_MEDI_IV_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_NURSE_ASSESMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP_SRV_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PRICING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PURCHASE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_SALE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_MEDICAL_TEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_ANS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_EQP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_STAFF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ATTENDANT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_DIAGNOSIS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_FAMILY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_HIST_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_LIFE_STYLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_PAST_ILLNESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VACCINATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VITAL_SIGN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PRESCRIPTION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM_BED postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SALESMAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPONSORSHIP_POLICY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SRV_CHARGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_REPORT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_SAMPLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_VACCINATION_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_WARD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_DOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IADDR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IHIER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_NOTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_IADDR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ATTRIBUTE_LIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CABIN_RACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_ITEM_CODE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_GRP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PACK_LIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PAY_CARD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PACK_LIST_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GEN_CFR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GENERAL_LICENSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_AGENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_ORG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_POLICY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_REVERT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_SRC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_ATTRIBUTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_BOX_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_LABLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_SCHEME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CUST_AGR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_GRP_OPR_PATH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_REF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_OPR_PATH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_PHY_LOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_QC_PARAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_COST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RM_GRP_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_LOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_LOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MACHINE_SV_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_OPR_MACHINE_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PACK_BOX postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_MACHINE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_OPERATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_D postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_DH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_LOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_RACK_SLAB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ROOM_CABIN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_HOUSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_ROOM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PAY_CARD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_IADDR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_PAYMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WAREHOUSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_DLY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OPR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OQA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_ACCOUNT_GROUP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_CR_DR_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_GL_ACCOUNT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_LIMIT_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VOUCHER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FILE_ATTRIBUTE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FILE_FORMAT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FORMAT_HEADER_FIELD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FORMAT_LAYOUT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_FUNCTION_DEF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_LAYOUT_DETRMN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GFH_LAYOUT_FIELD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ADDR_TOKEN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ADJUSTMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ALERT_TYPE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_MENU postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_PARAMETER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SERVLET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SESSION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_TREE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APP_USER_ROLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE_PROFILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BUSINESS_AREA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE_CLUBBED postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CONTINENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_COUNTRY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CSS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CURRENCY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_DOC_FILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_EMAIL_GRP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ERROR_CODE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FAQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FAQ_ANS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_FY_CHECKLIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_HEAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_TEXT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LNF_TEMPLATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS_BY_ROLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MESSAGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MESSAGE_SEND_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MESSAGE_TEMPLATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_NEWS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_OL_DEV postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_TREE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_OS_USER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_CHARGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_INVOICE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_TXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROD_REG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_USER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PTL_GRP_CTG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QA_FEEDBACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QA_FEEDBACK_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QUERY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_REFUND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SST_APP_CFG_PARAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_JS_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_PARTY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_RG_APPLN_VISIT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_RG_JOB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_RG_JOB_APPLN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_ACAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_ADVERT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_APP_DD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_DATA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_GQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_GURU postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_IT_SOL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_MRQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_MRS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_NREG postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PRE_PRO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PRIV_CTRL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PRQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_PRS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_RCMND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_SMS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_WEB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SST_SEQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_STATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TREE_OBJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_CODE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_VALUE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_VALUE_MAP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ACCESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_JS_MTH_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_JS_TOT_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_JS_TXN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_PRIVACY_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ROLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_FLOW postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_PROGRAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_STATUS_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_ACTION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_CONDITION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_FUNCTION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_FUNCTION_PARAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_MACRO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  RMS_THRESHOLD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_SSTPTL_USER_WEB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ABSENT_TYPE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_EMPLOYER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_HEALTH_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_SKILL_DOMAIN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUDGET_CODE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING_ROOM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_FILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_TIME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_COST_CENTER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_ACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_ACT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_FORM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_RATE_PLAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPARTMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_EXPENSE_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_GENERAL_EXPENSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_APPRAISAL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ATTENDANCE_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EMPLOYER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EXPENSE_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FAMILY_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FEEDBACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_GENERAL_EXPENSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_HEALTH_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INSTALLMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_LOCAL_CONVEYANCE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_FAMILY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_REQUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_RR_ACCRUED_AMT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SHIFT_CHANGE_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SKILL_DOMAIN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SPL_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_BAL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_ENCASH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_YEARLY_TAX postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EVAL_CRITERIA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_FINANCE_YEAR_DEF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_HOLIDAY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_ALLOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_LOGICAL_GRP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_ACCOUNT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PARAMETER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PROJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_ELIGIBILITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_JOB_PROFILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_LEVEL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_QUALI postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_SKILL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_REQUIREMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_TEAM_MEMBER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_MEMO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_ROUND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_VENDOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUIT_POST_SKILL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE_PROFILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_HEAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_RUN_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SHIFT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SKILL_SET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TIMESHEET_REP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINEE_ATTN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_CHARGE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_COURSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_GRP_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_EXPENSE_REPORT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VACATION_REQUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VENDOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_WAGES_STATEWISE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_ITEM_STOCK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_MONTHLY_STOCK_TEMP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_CNSTY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_EVAL_CRITERIA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MEMBER_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_MEM_TEAM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_MF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_MY_QUIZ_CHOICE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_QUIZ_QUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_STUDENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_CLASS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_TRIP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_FACULTY_OBSO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_FACULTY_PRD_CONS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_MEDI_HIST_OBSO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS_DELME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE_RATE_OBSO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME1 postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_HOUR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JAG_USER_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  JOB_FLOW_TAB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC_ITEM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_CLUBBED postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ITEM_OM_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_MEMBER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ORD_STS_WAIT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_SHOPPING_CART postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_CLUB postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_PKG_FTR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_CLUBBED postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_INFO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_DAILY_STATUS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_ESTIMATION_MODEL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_FP_PROJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_PROJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_QA_CHECKLIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_RELEASE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_RELEASE_PLAN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_RELEASE_SPRINT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_USER_STORY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_USER_STORY_BREAKUP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  PM_USER_STORY_IMPACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_APPS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_ENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_ENTITY_ATTR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_INDEX postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_SEQUENCE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_SYNONYM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_TYPE_DEF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  SDM_VIEW postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_DEFECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE_STEP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ALL_CIRCLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  ALL_DIVISION postgres 
sleep 1
