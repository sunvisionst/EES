SST_ESM_JAR=
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//postgres/sst_com_postgres.jar
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//postgres/sst_opr_postgres.jar



sh opr_tab_obj_gen_java.sh  HR_ABSENT_TYPE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_EMPLOYER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ROUND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_SKILL_DOMAIN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUDGET_CODE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING_ROOM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_TIME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_COST_CENTER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPARTMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_APPRAISAL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ARREAR_DELME postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ATTENDENCE_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_BANKER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CONTACT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_HOUR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET_SUM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DEF_TRAIN_COURSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EMPLOYER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EXPENSE_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FAMILY_ACADEMIC postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FEEDBACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_GENERAL_EXPENSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_GRP_TRAINING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_IDENTITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INSTALLMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_LOCAL_CONVEYANCE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_FAMILY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_REQUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_PERSONAL_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_REQ_TRAINING postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_RR_ACCRUED_AMT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SHIFT_CHANGE_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SKILL_DOMAIN postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SPL_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET_SUMMARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY_HIST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TRAINING_COURSE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TRAINING_SCH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_BAL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_ENCASH postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_YEARLY_TAX postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EVAL_CRITERIA postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_FINANCE_YEAR_DEF postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_HOLIDAY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_INTERVIEWEE_RATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_LOGICAL_GRP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_ACCOUNT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION_ADDRESS postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PARAMETER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PROJECT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_ELIGIBILITY postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_JOB_PROFILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_LEVEL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_QUALI postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_SKILL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_REQUIREMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_TEAM_MEMBER postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_MEMO postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_ROUND postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_VENDOR postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUIT_POST_SKILL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE_PROFILE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_HEAD postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_RUN_DATE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SHIFT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SKILL_SET postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_RULE postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TIMESHEET_REP postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINEE_FEEDBACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINER_FEEDBACK postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_EXPENSE_REPORT postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ_DTL postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VACATION_REQUEST postgres 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VENDOR postgres 
sleep 1
