useradd eesma -d /home/eesma -g users -s /bin/bash
