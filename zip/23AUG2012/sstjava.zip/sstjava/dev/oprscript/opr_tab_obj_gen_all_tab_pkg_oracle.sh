SST_ESM_JAR=
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//oracle/sst_com_oracle.jar
export SST_ESM_JAR=${SST_ESM_JAR}:${HOME}//sstweb/devweb/WEB-INF/classes/../lib//oracle/sst_opr_oracle.jar



sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BANK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_BOTTLE_HISTORY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_CHARGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_BLOOD_MASTER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_BLOOD_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_EMPLOYER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_IDENTITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_MAIL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  BBM_DONOR_PHONE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUST_AGREEMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_CUSTOMER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  DM_EMPLOYEE_ATTN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ACADEMIC_SESSION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_LIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_MARK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADM_SUB oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ADR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ALUMNI_PROF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_ACADEMIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_PREV_MARK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_APPC_REF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_AWARD_DISTRIBUTION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_SCH_SHIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CONTRACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_COURSE_STREAM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_DAILY_TRIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_ACTIVITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_GUEST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EVENT_REG_STUD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_PAPER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUESTION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_QUEST_MO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_ROOM_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SCHEDULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_SEAT_PLAN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_EXAM_TERM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CONCESSION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_CYCLE_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_DUE_DATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_FEE_HEAD_CLASS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_ACAD_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GEN_DISC_ACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRADE_SYSTEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANTER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRANT_INST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ATTN_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BED oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_BS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_COMPLAIN_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_EXIT_ENTRY_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_FLW_QTY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_INV oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_ROOM_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_RTW_QTY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISITOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISIT_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WARDEN_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_WING oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_INSTITUTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_ATTN_REG_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_EQP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LAB_SCH_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LATE_FEE_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_ATTEND oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LECTURE_PLAN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ATTN_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_BOOK_ISSUE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIB_ISSUE_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LIBRARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_LOCKER_USE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MARKSHEET_LO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_DIET_REG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_FEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MESS_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_MON_FRT_ACAD_REP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_PERIOD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_ALLOTMENT_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROUTE_STOPPAGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SCH_SHIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_ACADEMIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_CTG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_EXTRA_ACH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FAMILY_ACAD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_FEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_MARKSHEET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_QUEST_MARK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_REF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SCH_SHIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_SUBJECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ALLOCATION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_ELECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MARK_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_MS_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_SYLB oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_HDR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_MODEL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TIMETABLE_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CFR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CI_STUDENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_CIV oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_COMPANY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_INVITEE_INST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_ORGANIZER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_PROGRAM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_SCH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_STUDENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_TRAINING_PLAN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TP_FEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TRIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_AF_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_DRIVER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_LOCATION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_ROUTE_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ADM_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_APPOINTMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BED_AVAIL_STAT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_BIRTH_CERTIFICATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DEATH_CERTIFICATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_AVAIL_STATUS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_FEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DOCTOR_TIMESHEET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_DRUG_MASTER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMERGENCY_RECORD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_MEDI_IV_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EMR_NURSE_ASSESMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_EQP_SRV_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PRICING oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_PURCHASE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ITEM_SALE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_MEDICAL_TEST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_ANS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_EQP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_SCH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_OT_STAFF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_ATTENDANT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_DIAGNOSIS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_FAMILY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_HIST_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_IDENTITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_LIFE_STYLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_PAST_ILLNESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VACCINATION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_VITAL_SIGN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PRESCRIPTION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_ROOM_BED oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SALESMAN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPNSHIP_PYMNT_STMT_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SPONSORSHIP_POLICY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_SRV_CHARGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_REPORT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_TEST_SAMPLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_VACCINATION_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_WARD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_GRADE_SYSTEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_INSTITUTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TNP_COMPANY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_VEHICLE_DRIVER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_DOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IADDR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_IHIER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_CUSTOMER_ENQUIRY_NOTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_IADDR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ENQ_SUPPLIER_ENQUIRY_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ATTRIBUTE_LIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CABIN_RACK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_ITEM_CODE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_BANKER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_GRP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PACK_LIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PAY_CARD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_IADDR_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_PO_ITEM_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PACK_LIST_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUST_PO_SCH_ITEM_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_DOC_ITEM_SPEC_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EPCG_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_EXPORT_LICENSE_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GEN_CFR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_GENERAL_LICENSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_AGENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_ORG oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INSURANCE_POLICY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_REVERT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_INVOICE_ITEM_SRC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_ATTRIBUTE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_BOX_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_LABLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CODE_SCHEME oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_CUST_AGR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_GRP_OPR_PATH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_LOC_REF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_OPR_PATH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_PHY_LOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_QC_PARAM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_COST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RAW_MAT_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_RM_GRP_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_LOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_MONTH_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_STOCK_TXN_LOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MACHINE_SV_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_MI_ORDER_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_OPR_MACHINE_MAP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PACK_BOX oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_MACHINE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PROD_OPERATION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_D oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_DH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORDER_ITEM_OPR_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_PR_ORD_ITEM_REQ_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_QA_ORDER_ITEM_LOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_RACK_SLAB oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ROOM_CABIN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SI_ORDER_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_HOUSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_STORE_ROOM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_BANKER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PAY_CARD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_IADDR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_INV_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_PO_PAYMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_TR_ORDER_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WAREHOUSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_DLY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OPR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_WRK_ORD_ITEM_OQA oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_ACCOUNT_GROUP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_CR_DR_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_GL_ACCOUNT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_LIMIT_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VC_TXN_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  FA_VOUCHER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ADJUSTMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ALERT_TYPE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_DATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_MENU oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_PARAMETER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SERVLET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_SESSION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_APPLN_TREE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BILL_CYCLE_PROFILE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_BUSINESS_AREA oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CHARGE_CLUBBED oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CONTINENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_COUNTRY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CSS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_CURRENCY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_EMAIL_GRP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_HEAD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LETTER_TEXT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_LNF_TEMPLATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_MENU_ACCESS_BY_ROLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_NEWS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_ORD_ROUTE_TREE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_OS_USER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_CHARGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_INVOICE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PAYMENT_TXN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_UNIT_TXN_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_PROJECT_USER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_QUERY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_REFUND oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_STATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TREE_OBJECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_CODE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_TYPE_VALUE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ACCESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  GN_USER_ROLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_HOSTEL_VISITOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ABSENT_TYPE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ACADEMIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_EMPLOYER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_HEALTH_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_IDENTITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_RATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_APPLICANT_SKILL_DOMAIN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BANKER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUDGET_CODE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_BUILDING_ROOM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_FILE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CARD_TIME oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_COST_CENTER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGREEMENT_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_AGR_FORM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_CUST_RATE_PLAN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPARTMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_EXPENSE_SUMMARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_DEPT_GENERAL_EXPENSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACADEMIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ACTIVITY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_AGREEMENT_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_APPRAISAL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_ATTENDANCE_SUM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CLUBBED_SALARY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_TIMESHEET_SUM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EMPLOYER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_EXPENSE_SUMMARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FAMILY_ACADEMIC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_FEEDBACK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_GENERAL_EXPENSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_HEALTH_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_IDENTITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_DTL_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INC_PROM_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_INSTALLMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_LOCAL_CONVEYANCE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_FAMILY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_RATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_REQUEST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMPLOYEE_SHIFT_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_MEDI_CLAIM_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_RR_ACCRUED_AMT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SALARY_SUMMARY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SHIFT_CHANGE_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SKILL_DOMAIN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_SPL_DATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TIMESHEET_SUMMARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_TOTAL_SALARY_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_BAL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_VACATION_ENCASH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_YEARLY_TAX oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EVAL_CRITERIA oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_FINANCE_YEAR_DEF oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_HOLIDAY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_ALLOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_JOB_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_LOGICAL_GRP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_ACCOUNT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORGANIZATION_ADDRESS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PARAMETER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_ORG_PROJECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_OUTSOURCE_EMP_HIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_ELIGIBILITY oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_JOB_PROFILE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_LEVEL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_QUALI oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_POSITION_SKILL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_REQUIREMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_PROJECT_TEAM_MEMBER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_MEMO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_ROUND oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUITMENT_VENDOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_RECRUIT_POST_SKILL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_CYCLE_PROFILE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_HEAD oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SALARY_RUN_DATE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SHIFT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_SKILL_SET oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_REBATE_REASON_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TAX_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TIMESHEET_REP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINEE_ATTN oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_CHARGE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_COURSE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_FEEDBACK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_GRP_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAINING_SCH oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_EXPENSE_REPORT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_TRAVEL_REQ_DTL oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VACATION_REQUEST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_VENDOR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_WAGES_STATEWISE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_ITEM_STOCK oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  IM_MONTHLY_STOCK_TEMP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_CLASS_STUDENT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_ROOM_CLASS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_STUDENT_TRIP oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_SUBJECT_FACULTY_OBSO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EES_TT_FACULTY_PRD_CONS oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  EHS_PATIENT_MEDI_HIST_OBSO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_CUSTOMER_ADDRESS_DELME oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_ITEM_MAKE_RATE_OBSO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  ESM_SUPPLIER_ADDRESS_DELME1 oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_BANKER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_CONTACT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  HR_EMP_DAILY_HOUR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_DOC_ITEM oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_CLUBBED oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_INV_AMT_DIST_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ITEM_OM_RULE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_MEMBER oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_ORD_STS_WAIT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  OTS_SHOPPING_CART oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_CLUB oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_PKG_FTR oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_CLUBBED oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  PBS_POINT_INFO oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_DEFECT oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE oracle 
sleep 1
sh opr_tab_obj_gen_java.sh  QA_TESTCASE_STEP oracle 
sleep 1
