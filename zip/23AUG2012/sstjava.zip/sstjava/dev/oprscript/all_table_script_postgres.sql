declare                                                                         
  returnCode number;                                                            
begin                                                                           
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_CUSTOMER');               
DBMS_OUTPUT.PUT_LINE('ESM_CUSTOMER Executed ');                                 
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_CUSTOMER_ADDRESS');       
DBMS_OUTPUT.PUT_LINE('ESM_CUSTOMER_ADDRESS Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_CUSTOMER_CONTACT');       
DBMS_OUTPUT.PUT_LINE('ESM_CUSTOMER_CONTACT Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_CUSTOMER_PO');            
DBMS_OUTPUT.PUT_LINE('ESM_CUSTOMER_PO Executed ');                              
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_CUSTOMER_PO_ITEM');       
DBMS_OUTPUT.PUT_LINE('ESM_CUSTOMER_PO_ITEM Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_INVOICE');                
DBMS_OUTPUT.PUT_LINE('ESM_INVOICE Executed ');                                  
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_INVOICE_ITEM');           
DBMS_OUTPUT.PUT_LINE('ESM_INVOICE_ITEM Executed ');                             
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER');               
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER Executed ');                                 
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_ADDRESS');       
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_ADDRESS Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_CONTACT');       
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_CONTACT Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_PO');            
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_PO Executed ');                              
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_PO_INV');        
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_PO_INV Executed ');                          
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_PO_INV_ITEM');   
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_PO_INV_ITEM Executed ');                     
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','ESM_SUPPLIER_PO_ITEM');       
DBMS_OUTPUT.PUT_LINE('ESM_SUPPLIER_PO_ITEM Executed ');                         
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_APPLN_SESSION');           
DBMS_OUTPUT.PUT_LINE('GN_APPLN_SESSION Executed ');                             
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_TYPE_CODE');               
DBMS_OUTPUT.PUT_LINE('GN_TYPE_CODE Executed ');                                 
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_TYPE_VALUE');              
DBMS_OUTPUT.PUT_LINE('GN_TYPE_VALUE Executed ');                                
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_USER');                    
DBMS_OUTPUT.PUT_LINE('GN_USER Executed ');                                      
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_USER_ACCESS');             
DBMS_OUTPUT.PUT_LINE('GN_USER_ACCESS Executed ');                               
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','GN_USER_ROLE');               
DBMS_OUTPUT.PUT_LINE('GN_USER_ROLE Executed ');                                 
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','HR_ORGANIZATION');            
DBMS_OUTPUT.PUT_LINE('HR_ORGANIZATION Executed ');                              
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','HR_ORGANIZATION_ADDRESS');    
DBMS_OUTPUT.PUT_LINE('HR_ORGANIZATION_ADDRESS Executed ');                      
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','HR_VENDOR');                  
DBMS_OUTPUT.PUT_LINE('HR_VENDOR Executed ');                                    
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','HR_VENDOR_ADDRESS');          
DBMS_OUTPUT.PUT_LINE('HR_VENDOR_ADDRESS Executed ');                            
                                                                                
returnCode:=creSqlScriptDBPPkg.creSql('postgres','HR_VENDOR_CONTACT');          
DBMS_OUTPUT.PUT_LINE('HR_VENDOR_CONTACT Executed ');                            
                                                                                
end;                                                                            
/                                                                               
exit;                                                                           
