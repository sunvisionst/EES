
  \i /tmp/ees_public//postgres/bbm_blood_bank_tab.sql
  \i /tmp/ees_public//postgres/bbm_blood_bank_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_blood_bottle_tab.sql
  \i /tmp/ees_public//postgres/bbm_blood_bottle_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_blood_bottle_history_tab.sql
  \i /tmp/ees_public//postgres/bbm_blood_bottle_history_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_blood_charge_tab.sql
  \i /tmp/ees_public//postgres/bbm_blood_charge_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_blood_master_tab.sql
  \i /tmp/ees_public//postgres/bbm_blood_master_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_address_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_address_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_blood_dtl_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_blood_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_employer_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_employer_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_identity_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_identity_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_mail_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_mail_pkey.sql
  

  \i /tmp/ees_public//postgres/bbm_donor_phone_tab.sql
  \i /tmp/ees_public//postgres/bbm_donor_phone_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_cron_job_tab.sql
  \i /tmp/ees_public//postgres/cx_cron_job_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_dtxn_tab.sql
  \i /tmp/ees_public//postgres/cx_dtxn_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_dtxn_cf_tab.sql
  \i /tmp/ees_public//postgres/cx_dtxn_cf_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_member_tab.sql
  \i /tmp/ees_public//postgres/cx_member_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_member_symbol_tab.sql
  \i /tmp/ees_public//postgres/cx_member_symbol_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_order_tab.sql
  \i /tmp/ees_public//postgres/cx_order_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_org_tab.sql
  \i /tmp/ees_public//postgres/cx_org_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_symbol_tab.sql
  \i /tmp/ees_public//postgres/cx_symbol_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_symbol_cntr_tab.sql
  \i /tmp/ees_public//postgres/cx_symbol_cntr_pkey.sql
  

  \i /tmp/ees_public//postgres/cx_symbol_daily_tab.sql
  \i /tmp/ees_public//postgres/cx_symbol_daily_pkey.sql
  

  \i /tmp/ees_public//postgres/dm_cust_agreement_tab.sql
  \i /tmp/ees_public//postgres/dm_cust_agreement_pkey.sql
  

  \i /tmp/ees_public//postgres/dm_customer_tab.sql
  \i /tmp/ees_public//postgres/dm_customer_pkey.sql
  

  \i /tmp/ees_public//postgres/dm_employee_tab.sql
  \i /tmp/ees_public//postgres/dm_employee_pkey.sql
  

  \i /tmp/ees_public//postgres/dm_employee_mon_dtl_tab.sql
  \i /tmp/ees_public//postgres/dm_employee_mon_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/dm_src_file_tab.sql
  \i /tmp/ees_public//postgres/dm_src_file_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_academic_session_tab.sql
  \i /tmp/ees_public//postgres/ees_academic_session_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_adm_list_tab.sql
  \i /tmp/ees_public//postgres/ees_adm_list_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_adm_mark_tab.sql
  \i /tmp/ees_public//postgres/ees_adm_mark_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_adm_req_tab.sql
  \i /tmp/ees_public//postgres/ees_adm_req_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_adm_sub_tab.sql
  \i /tmp/ees_public//postgres/ees_adm_sub_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_adr_tab.sql
  \i /tmp/ees_public//postgres/ees_adr_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_alumni_tab.sql
  \i /tmp/ees_public//postgres/ees_alumni_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_alumni_prof_tab.sql
  \i /tmp/ees_public//postgres/ees_alumni_prof_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_appc_academic_tab.sql
  \i /tmp/ees_public//postgres/ees_appc_academic_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_appc_prev_mark_tab.sql
  \i /tmp/ees_public//postgres/ees_appc_prev_mark_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_appc_ref_tab.sql
  \i /tmp/ees_public//postgres/ees_appc_ref_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_as_checklist_tab.sql
  \i /tmp/ees_public//postgres/ees_as_checklist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_award_tab.sql
  \i /tmp/ees_public//postgres/ees_award_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_award_distribution_tab.sql
  \i /tmp/ees_public//postgres/ees_award_distribution_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_class_tab.sql
  \i /tmp/ees_public//postgres/ees_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_class_sch_ship_tab.sql
  \i /tmp/ees_public//postgres/ees_class_sch_ship_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_contract_tab.sql
  \i /tmp/ees_public//postgres/ees_contract_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_course_tab.sql
  \i /tmp/ees_public//postgres/ees_course_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_course_stream_tab.sql
  \i /tmp/ees_public//postgres/ees_course_stream_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_daily_trip_tab.sql
  \i /tmp/ees_public//postgres/ees_daily_trip_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_event_tab.sql
  \i /tmp/ees_public//postgres/ees_event_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_event_activity_tab.sql
  \i /tmp/ees_public//postgres/ees_event_activity_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_event_contact_tab.sql
  \i /tmp/ees_public//postgres/ees_event_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_event_reg_guest_tab.sql
  \i /tmp/ees_public//postgres/ees_event_reg_guest_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_event_reg_stud_tab.sql
  \i /tmp/ees_public//postgres/ees_event_reg_stud_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_class_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_paper_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_paper_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_question_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_question_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_quest_mo_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_quest_mo_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_room_map_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_room_map_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_schedule_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_schedule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_seat_plan_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_seat_plan_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_exam_term_tab.sql
  \i /tmp/ees_public//postgres/ees_exam_term_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_concession_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_concession_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_cycle_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_cycle_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_cycle_class_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_cycle_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_cycle_item_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_cycle_item_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_due_date_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_due_date_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_head_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_head_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_head_class_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_head_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_pkg_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_pkg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_fee_pkg_struct_tab.sql
  \i /tmp/ees_public//postgres/ees_fee_pkg_struct_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_gen_acad_rule_tab.sql
  \i /tmp/ees_public//postgres/ees_gen_acad_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_gen_disc_tab.sql
  \i /tmp/ees_public//postgres/ees_gen_disc_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_gen_disc_act_tab.sql
  \i /tmp/ees_public//postgres/ees_gen_disc_act_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_grade_system_tab.sql
  \i /tmp/ees_public//postgres/ees_grade_system_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_grant_tab.sql
  \i /tmp/ees_public//postgres/ees_grant_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_granter_tab.sql
  \i /tmp/ees_public//postgres/ees_granter_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_grant_inst_tab.sql
  \i /tmp/ees_public//postgres/ees_grant_inst_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_attn_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_attn_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_bed_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_bed_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_bs_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_bs_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_complain_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_complain_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_exit_entry_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_exit_entry_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_fee_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_fee_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_flw_qty_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_flw_qty_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_item_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_item_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_room_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_room_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_room_inv_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_room_inv_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_room_item_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_room_item_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_rtw_qty_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_rtw_qty_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_visitor_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_visitor_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_visit_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_visit_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_warden_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_warden_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_warden_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_warden_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_hostel_wing_tab.sql
  \i /tmp/ees_public//postgres/ees_hostel_wing_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_institute_tab.sql
  \i /tmp/ees_public//postgres/ees_institute_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_attn_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_attn_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_attn_reg_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_attn_reg_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_eqp_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_eqp_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_sch_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lab_sch_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_lab_sch_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_late_fee_rule_tab.sql
  \i /tmp/ees_public//postgres/ees_late_fee_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lecture_attend_tab.sql
  \i /tmp/ees_public//postgres/ees_lecture_attend_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lecture_plan_tab.sql
  \i /tmp/ees_public//postgres/ees_lecture_plan_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lib_attn_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_lib_attn_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lib_book_tab.sql
  \i /tmp/ees_public//postgres/ees_lib_book_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lib_book_issue_tab.sql
  \i /tmp/ees_public//postgres/ees_lib_book_issue_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_lib_issue_rule_tab.sql
  \i /tmp/ees_public//postgres/ees_lib_issue_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_library_tab.sql
  \i /tmp/ees_public//postgres/ees_library_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_locker_tab.sql
  \i /tmp/ees_public//postgres/ees_locker_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_locker_use_tab.sql
  \i /tmp/ees_public//postgres/ees_locker_use_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_marksheet_lo_tab.sql
  \i /tmp/ees_public//postgres/ees_marksheet_lo_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_mess_tab.sql
  \i /tmp/ees_public//postgres/ees_mess_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_mess_diet_reg_tab.sql
  \i /tmp/ees_public//postgres/ees_mess_diet_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_mess_fee_tab.sql
  \i /tmp/ees_public//postgres/ees_mess_fee_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_mess_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_mess_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_mon_frt_acad_rep_tab.sql
  \i /tmp/ees_public//postgres/ees_mon_frt_acad_rep_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_od_class_tab.sql
  \i /tmp/ees_public//postgres/ees_od_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_od_class_cand_tab.sql
  \i /tmp/ees_public//postgres/ees_od_class_cand_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_od_class_sch_tab.sql
  \i /tmp/ees_public//postgres/ees_od_class_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_period_tab.sql
  \i /tmp/ees_public//postgres/ees_period_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_quest_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_quest_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_quest_by_user_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_quest_by_user_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_sch_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_sch_cand_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_sch_cand_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_sch_inst_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_sch_inst_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_quiz_sch_quest_tab.sql
  \i /tmp/ees_public//postgres/ees_quiz_sch_quest_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_room_allotment_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_room_allotment_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_route_tab.sql
  \i /tmp/ees_public//postgres/ees_route_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_route_stoppage_tab.sql
  \i /tmp/ees_public//postgres/ees_route_stoppage_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_sch_ship_tab.sql
  \i /tmp/ees_public//postgres/ees_sch_ship_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_tab.sql
  \i /tmp/ees_public//postgres/ees_student_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_academic_tab.sql
  \i /tmp/ees_public//postgres/ees_student_academic_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_ctg_tab.sql
  \i /tmp/ees_public//postgres/ees_student_ctg_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_ctg_fee_map_tab.sql
  \i /tmp/ees_public//postgres/ees_student_ctg_fee_map_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_extra_ach_tab.sql
  \i /tmp/ees_public//postgres/ees_student_extra_ach_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_family_acad_tab.sql
  \i /tmp/ees_public//postgres/ees_student_family_acad_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_fee_tab.sql
  \i /tmp/ees_public//postgres/ees_student_fee_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_student_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_mark_tab.sql
  \i /tmp/ees_public//postgres/ees_student_mark_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_marksheet_tab.sql
  \i /tmp/ees_public//postgres/ees_student_marksheet_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_quest_mark_tab.sql
  \i /tmp/ees_public//postgres/ees_student_quest_mark_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_ref_tab.sql
  \i /tmp/ees_public//postgres/ees_student_ref_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_sch_ship_tab.sql
  \i /tmp/ees_public//postgres/ees_student_sch_ship_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_subject_tab.sql
  \i /tmp/ees_public//postgres/ees_student_subject_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_allocation_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_allocation_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_elect_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_elect_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_mark_rule_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_mark_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_ms_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_ms_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_ms_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_ms_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_sylb_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_sylb_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_timetable_tab.sql
  \i /tmp/ees_public//postgres/ees_timetable_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_timetable_hdr_tab.sql
  \i /tmp/ees_public//postgres/ees_timetable_hdr_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_timetable_model_tab.sql
  \i /tmp/ees_public//postgres/ees_timetable_model_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_timetable_rule_tab.sql
  \i /tmp/ees_public//postgres/ees_timetable_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_cfr_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_cfr_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_cic_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_cic_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_ci_student_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_ci_student_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_civ_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_civ_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_company_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_company_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_invitee_inst_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_invitee_inst_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_organizer_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_organizer_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_program_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_program_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_sch_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_student_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_student_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tnp_training_plan_tab.sql
  \i /tmp/ees_public//postgres/ees_tnp_training_plan_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tp_fee_tab.sql
  \i /tmp/ees_public//postgres/ees_tp_fee_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tp_snm_tab.sql
  \i /tmp/ees_public//postgres/ees_tp_snm_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_trip_tab.sql
  \i /tmp/ees_public//postgres/ees_trip_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tt_af_req_tab.sql
  \i /tmp/ees_public//postgres/ees_tt_af_req_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_vehicle_tab.sql
  \i /tmp/ees_public//postgres/ees_vehicle_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_vehicle_driver_tab.sql
  \i /tmp/ees_public//postgres/ees_vehicle_driver_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_vehicle_location_tab.sql
  \i /tmp/ees_public//postgres/ees_vehicle_location_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_vehicle_route_tab.sql
  \i /tmp/ees_public//postgres/ees_vehicle_route_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_vehicle_route_hist_tab.sql
  \i /tmp/ees_public//postgres/ees_vehicle_route_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_adm_dtl_tab.sql
  \i /tmp/ees_public//postgres/ehs_adm_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_adm_req_tab.sql
  \i /tmp/ees_public//postgres/ehs_adm_req_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_appointment_tab.sql
  \i /tmp/ees_public//postgres/ehs_appointment_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_bed_avail_stat_tab.sql
  \i /tmp/ees_public//postgres/ehs_bed_avail_stat_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_birth_certificate_tab.sql
  \i /tmp/ees_public//postgres/ehs_birth_certificate_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_death_certificate_tab.sql
  \i /tmp/ees_public//postgres/ehs_death_certificate_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_doctor_tab.sql
  \i /tmp/ees_public//postgres/ehs_doctor_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_doctor_avail_status_tab.sql
  \i /tmp/ees_public//postgres/ehs_doctor_avail_status_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_doctor_fee_tab.sql
  \i /tmp/ees_public//postgres/ehs_doctor_fee_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_doctor_timesheet_tab.sql
  \i /tmp/ees_public//postgres/ehs_doctor_timesheet_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_drug_master_tab.sql
  \i /tmp/ees_public//postgres/ehs_drug_master_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_emergency_record_tab.sql
  \i /tmp/ees_public//postgres/ehs_emergency_record_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_emr_medi_iv_order_tab.sql
  \i /tmp/ees_public//postgres/ehs_emr_medi_iv_order_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_emr_nurse_assesment_tab.sql
  \i /tmp/ees_public//postgres/ehs_emr_nurse_assesment_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_eqp_tab.sql
  \i /tmp/ees_public//postgres/ehs_eqp_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_eqp_srv_req_tab.sql
  \i /tmp/ees_public//postgres/ehs_eqp_srv_req_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_item_pricing_tab.sql
  \i /tmp/ees_public//postgres/ehs_item_pricing_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_item_purchase_tab.sql
  \i /tmp/ees_public//postgres/ehs_item_purchase_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_item_sale_tab.sql
  \i /tmp/ees_public//postgres/ehs_item_sale_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_medical_test_tab.sql
  \i /tmp/ees_public//postgres/ehs_medical_test_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ot_tab.sql
  \i /tmp/ees_public//postgres/ehs_ot_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ot_ans_tab.sql
  \i /tmp/ees_public//postgres/ehs_ot_ans_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ot_eqp_tab.sql
  \i /tmp/ees_public//postgres/ehs_ot_eqp_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ot_sch_tab.sql
  \i /tmp/ees_public//postgres/ehs_ot_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ot_staff_tab.sql
  \i /tmp/ees_public//postgres/ehs_ot_staff_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_address_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_address_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_attendant_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_attendant_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_contact_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_diagnosis_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_diagnosis_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_family_hist_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_family_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_hist_dtl_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_hist_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_identity_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_identity_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_life_style_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_life_style_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_past_illness_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_past_illness_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_vaccination_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_vaccination_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_vital_sign_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_vital_sign_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_prescription_tab.sql
  \i /tmp/ees_public//postgres/ehs_prescription_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_room_tab.sql
  \i /tmp/ees_public//postgres/ehs_room_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_room_bed_tab.sql
  \i /tmp/ees_public//postgres/ehs_room_bed_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_salesman_tab.sql
  \i /tmp/ees_public//postgres/ehs_salesman_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_spnship_pymnt_stmt_tab.sql
  \i /tmp/ees_public//postgres/ehs_spnship_pymnt_stmt_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_spnship_pymnt_stmt_dtl_tab.sql
  \i /tmp/ees_public//postgres/ehs_spnship_pymnt_stmt_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_sponsorship_policy_tab.sql
  \i /tmp/ees_public//postgres/ehs_sponsorship_policy_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_srv_charge_tab.sql
  \i /tmp/ees_public//postgres/ehs_srv_charge_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_test_report_tab.sql
  \i /tmp/ees_public//postgres/ehs_test_report_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_test_sample_tab.sql
  \i /tmp/ees_public//postgres/ehs_test_sample_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_vaccination_rule_tab.sql
  \i /tmp/ees_public//postgres/ehs_vaccination_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_ward_tab.sql
  \i /tmp/ees_public//postgres/ehs_ward_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_doc_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_doc_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_iaddr_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_iaddr_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_ihier_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_ihier_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_item_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_item_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_customer_enquiry_note_tab.sql
  \i /tmp/ees_public//postgres/enq_customer_enquiry_note_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_supplier_enquiry_tab.sql
  \i /tmp/ees_public//postgres/enq_supplier_enquiry_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_supplier_enquiry_iaddr_tab.sql
  \i /tmp/ees_public//postgres/enq_supplier_enquiry_iaddr_pkey.sql
  

  \i /tmp/ees_public//postgres/enq_supplier_enquiry_item_tab.sql
  \i /tmp/ees_public//postgres/enq_supplier_enquiry_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_attribute_list_tab.sql
  \i /tmp/ees_public//postgres/esm_attribute_list_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cabin_rack_tab.sql
  \i /tmp/ees_public//postgres/esm_cabin_rack_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cust_item_code_tab.sql
  \i /tmp/ees_public//postgres/esm_cust_item_code_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_address_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_address_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_banker_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_banker_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_contact_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_grp_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_grp_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_pack_list_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_pack_list_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_pay_card_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_pay_card_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_iaddr_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_iaddr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_iaddr_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_iaddr_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_item_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_po_item_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_po_item_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cust_pack_list_item_tab.sql
  \i /tmp/ees_public//postgres/esm_cust_pack_list_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cust_po_sch_tab.sql
  \i /tmp/ees_public//postgres/esm_cust_po_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cust_po_sch_item_tab.sql
  \i /tmp/ees_public//postgres/esm_cust_po_sch_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_cust_po_sch_item_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_cust_po_sch_item_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_doc_item_spec_tab.sql
  \i /tmp/ees_public//postgres/esm_doc_item_spec_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_doc_item_spec_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_doc_item_spec_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_epcg_tab.sql
  \i /tmp/ees_public//postgres/esm_epcg_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_epcg_dtl_tab.sql
  \i /tmp/ees_public//postgres/esm_epcg_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_export_license_tab.sql
  \i /tmp/ees_public//postgres/esm_export_license_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_export_license_dtl_tab.sql
  \i /tmp/ees_public//postgres/esm_export_license_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_gen_cfr_tab.sql
  \i /tmp/ees_public//postgres/esm_gen_cfr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_general_license_tab.sql
  \i /tmp/ees_public//postgres/esm_general_license_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_insurance_agent_tab.sql
  \i /tmp/ees_public//postgres/esm_insurance_agent_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_insurance_org_tab.sql
  \i /tmp/ees_public//postgres/esm_insurance_org_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_insurance_policy_tab.sql
  \i /tmp/ees_public//postgres/esm_insurance_policy_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_invoice_tab.sql
  \i /tmp/ees_public//postgres/esm_invoice_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_invoice_item_tab.sql
  \i /tmp/ees_public//postgres/esm_invoice_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_invoice_item_revert_tab.sql
  \i /tmp/ees_public//postgres/esm_invoice_item_revert_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_invoice_item_src_tab.sql
  \i /tmp/ees_public//postgres/esm_invoice_item_src_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_tab.sql
  \i /tmp/ees_public//postgres/esm_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_attribute_tab.sql
  \i /tmp/ees_public//postgres/esm_item_attribute_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_box_map_tab.sql
  \i /tmp/ees_public//postgres/esm_item_box_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_code_lable_tab.sql
  \i /tmp/ees_public//postgres/esm_item_code_lable_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_code_scheme_tab.sql
  \i /tmp/ees_public//postgres/esm_item_code_scheme_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_cust_agr_tab.sql
  \i /tmp/ees_public//postgres/esm_item_cust_agr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_grp_opr_path_tab.sql
  \i /tmp/ees_public//postgres/esm_item_grp_opr_path_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_loc_map_tab.sql
  \i /tmp/ees_public//postgres/esm_item_loc_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_loc_ref_tab.sql
  \i /tmp/ees_public//postgres/esm_item_loc_ref_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_make_tab.sql
  \i /tmp/ees_public//postgres/esm_item_make_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_opr_path_tab.sql
  \i /tmp/ees_public//postgres/esm_item_opr_path_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_phy_loc_tab.sql
  \i /tmp/ees_public//postgres/esm_item_phy_loc_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_qc_param_tab.sql
  \i /tmp/ees_public//postgres/esm_item_qc_param_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_rate_tab.sql
  \i /tmp/ees_public//postgres/esm_item_rate_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_raw_mat_cost_tab.sql
  \i /tmp/ees_public//postgres/esm_item_raw_mat_cost_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_raw_mat_map_tab.sql
  \i /tmp/ees_public//postgres/esm_item_raw_mat_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_rm_grp_map_tab.sql
  \i /tmp/ees_public//postgres/esm_item_rm_grp_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_loc_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_loc_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_month_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_month_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_month_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_month_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_txn_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_txn_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_txn_dtl_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_txn_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_stock_txn_loc_tab.sql
  \i /tmp/ees_public//postgres/esm_item_stock_txn_loc_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_machine_sv_map_tab.sql
  \i /tmp/ees_public//postgres/esm_machine_sv_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_mi_order_tab.sql
  \i /tmp/ees_public//postgres/esm_mi_order_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_mi_order_item_tab.sql
  \i /tmp/ees_public//postgres/esm_mi_order_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_opr_machine_map_tab.sql
  \i /tmp/ees_public//postgres/esm_opr_machine_map_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pack_box_tab.sql
  \i /tmp/ees_public//postgres/esm_pack_box_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_prod_machine_tab.sql
  \i /tmp/ees_public//postgres/esm_prod_machine_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_prod_operation_tab.sql
  \i /tmp/ees_public//postgres/esm_prod_operation_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_item_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_d_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_d_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_dh_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_dh_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_hist_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_order_item_opr_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_ord_item_req_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_ord_item_req_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_pr_ord_item_req_dtl_tab.sql
  \i /tmp/ees_public//postgres/esm_pr_ord_item_req_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_qa_order_tab.sql
  \i /tmp/ees_public//postgres/esm_qa_order_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_qa_order_item_tab.sql
  \i /tmp/ees_public//postgres/esm_qa_order_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_qa_order_item_dtl_tab.sql
  \i /tmp/ees_public//postgres/esm_qa_order_item_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_qa_order_item_loc_tab.sql
  \i /tmp/ees_public//postgres/esm_qa_order_item_loc_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_rack_slab_tab.sql
  \i /tmp/ees_public//postgres/esm_rack_slab_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_room_cabin_tab.sql
  \i /tmp/ees_public//postgres/esm_room_cabin_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_si_order_tab.sql
  \i /tmp/ees_public//postgres/esm_si_order_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_si_order_item_tab.sql
  \i /tmp/ees_public//postgres/esm_si_order_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_store_house_tab.sql
  \i /tmp/ees_public//postgres/esm_store_house_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_store_room_tab.sql
  \i /tmp/ees_public//postgres/esm_store_room_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_address_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_address_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_banker_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_banker_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_contact_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_pay_card_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_pay_card_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_iaddr_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_iaddr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_inv_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_inv_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_inv_item_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_inv_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_item_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_po_payment_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_po_payment_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_tr_order_tab.sql
  \i /tmp/ees_public//postgres/esm_tr_order_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_tr_order_item_tab.sql
  \i /tmp/ees_public//postgres/esm_tr_order_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_warehouse_tab.sql
  \i /tmp/ees_public//postgres/esm_warehouse_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_wrk_ord_tab.sql
  \i /tmp/ees_public//postgres/esm_wrk_ord_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_wrk_ord_item_tab.sql
  \i /tmp/ees_public//postgres/esm_wrk_ord_item_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_wrk_ord_item_dly_tab.sql
  \i /tmp/ees_public//postgres/esm_wrk_ord_item_dly_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_wrk_ord_item_opr_tab.sql
  \i /tmp/ees_public//postgres/esm_wrk_ord_item_opr_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_wrk_ord_item_oqa_tab.sql
  \i /tmp/ees_public//postgres/esm_wrk_ord_item_oqa_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_account_group_tab.sql
  \i /tmp/ees_public//postgres/fa_account_group_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_cr_dr_rule_tab.sql
  \i /tmp/ees_public//postgres/fa_cr_dr_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_gl_account_tab.sql
  \i /tmp/ees_public//postgres/fa_gl_account_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_vc_limit_rule_tab.sql
  \i /tmp/ees_public//postgres/fa_vc_limit_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_vc_txn_tab.sql
  \i /tmp/ees_public//postgres/fa_vc_txn_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_vc_txn_dtl_tab.sql
  \i /tmp/ees_public//postgres/fa_vc_txn_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/fa_voucher_tab.sql
  \i /tmp/ees_public//postgres/fa_voucher_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_file_attribute_tab.sql
  \i /tmp/ees_public//postgres/gfh_file_attribute_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_file_format_tab.sql
  \i /tmp/ees_public//postgres/gfh_file_format_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_format_header_field_tab.sql
  \i /tmp/ees_public//postgres/gfh_format_header_field_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_format_layout_tab.sql
  \i /tmp/ees_public//postgres/gfh_format_layout_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_function_def_tab.sql
  \i /tmp/ees_public//postgres/gfh_function_def_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_layout_detrmn_tab.sql
  \i /tmp/ees_public//postgres/gfh_layout_detrmn_pkey.sql
  

  \i /tmp/ees_public//postgres/gfh_layout_field_tab.sql
  \i /tmp/ees_public//postgres/gfh_layout_field_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_addr_token_tab.sql
  \i /tmp/ees_public//postgres/gn_addr_token_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_adjustment_tab.sql
  \i /tmp/ees_public//postgres/gn_adjustment_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_alert_type_tab.sql
  \i /tmp/ees_public//postgres/gn_alert_type_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_app_tab.sql
  \i /tmp/ees_public//postgres/gn_app_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_date_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_date_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_menu_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_menu_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_parameter_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_parameter_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_servlet_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_servlet_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_session_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_session_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_appln_tree_tab.sql
  \i /tmp/ees_public//postgres/gn_appln_tree_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_app_user_role_tab.sql
  \i /tmp/ees_public//postgres/gn_app_user_role_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_bill_cycle_tab.sql
  \i /tmp/ees_public//postgres/gn_bill_cycle_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_bill_cycle_profile_tab.sql
  \i /tmp/ees_public//postgres/gn_bill_cycle_profile_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_business_area_tab.sql
  \i /tmp/ees_public//postgres/gn_business_area_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_charge_tab.sql
  \i /tmp/ees_public//postgres/gn_charge_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_charge_clubbed_tab.sql
  \i /tmp/ees_public//postgres/gn_charge_clubbed_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_city_tab.sql
  \i /tmp/ees_public//postgres/gn_city_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_continent_tab.sql
  \i /tmp/ees_public//postgres/gn_continent_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_country_tab.sql
  \i /tmp/ees_public//postgres/gn_country_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_css_tab.sql
  \i /tmp/ees_public//postgres/gn_css_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_currency_tab.sql
  \i /tmp/ees_public//postgres/gn_currency_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_doc_file_tab.sql
  \i /tmp/ees_public//postgres/gn_doc_file_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_email_grp_tab.sql
  \i /tmp/ees_public//postgres/gn_email_grp_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_error_code_tab.sql
  \i /tmp/ees_public//postgres/gn_error_code_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_faq_tab.sql
  \i /tmp/ees_public//postgres/gn_faq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_faq_ans_tab.sql
  \i /tmp/ees_public//postgres/gn_faq_ans_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_fy_checklist_tab.sql
  \i /tmp/ees_public//postgres/gn_fy_checklist_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_letter_head_tab.sql
  \i /tmp/ees_public//postgres/gn_letter_head_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_letter_rule_tab.sql
  \i /tmp/ees_public//postgres/gn_letter_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_letter_text_tab.sql
  \i /tmp/ees_public//postgres/gn_letter_text_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_lnf_template_tab.sql
  \i /tmp/ees_public//postgres/gn_lnf_template_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_menu_access_tab.sql
  \i /tmp/ees_public//postgres/gn_menu_access_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_menu_access_by_role_tab.sql
  \i /tmp/ees_public//postgres/gn_menu_access_by_role_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_message_tab.sql
  \i /tmp/ees_public//postgres/gn_message_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_message_send_rule_tab.sql
  \i /tmp/ees_public//postgres/gn_message_send_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_message_template_tab.sql
  \i /tmp/ees_public//postgres/gn_message_template_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_news_tab.sql
  \i /tmp/ees_public//postgres/gn_news_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_ol_dev_tab.sql
  \i /tmp/ees_public//postgres/gn_ol_dev_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_ord_route_rule_tab.sql
  \i /tmp/ees_public//postgres/gn_ord_route_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_ord_route_tree_tab.sql
  \i /tmp/ees_public//postgres/gn_ord_route_tree_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_os_user_tab.sql
  \i /tmp/ees_public//postgres/gn_os_user_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_payment_charge_tab.sql
  \i /tmp/ees_public//postgres/gn_payment_charge_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_payment_invoice_tab.sql
  \i /tmp/ees_public//postgres/gn_payment_invoice_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_payment_txn_tab.sql
  \i /tmp/ees_public//postgres/gn_payment_txn_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_prod_reg_tab.sql
  \i /tmp/ees_public//postgres/gn_prod_reg_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_project_tab.sql
  \i /tmp/ees_public//postgres/gn_project_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_project_unit_txn_tab.sql
  \i /tmp/ees_public//postgres/gn_project_unit_txn_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_project_unit_txn_hist_tab.sql
  \i /tmp/ees_public//postgres/gn_project_unit_txn_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_project_user_tab.sql
  \i /tmp/ees_public//postgres/gn_project_user_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_ptl_grp_ctg_tab.sql
  \i /tmp/ees_public//postgres/gn_ptl_grp_ctg_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_qa_feedback_tab.sql
  \i /tmp/ees_public//postgres/gn_qa_feedback_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_qa_feedback_sch_tab.sql
  \i /tmp/ees_public//postgres/gn_qa_feedback_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_query_tab.sql
  \i /tmp/ees_public//postgres/gn_query_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_refund_tab.sql
  \i /tmp/ees_public//postgres/gn_refund_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sst_app_cfg_param_tab.sql
  \i /tmp/ees_public//postgres/gn_sst_app_cfg_param_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_js_rule_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_js_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_party_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_party_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_rg_appln_visit_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_rg_appln_visit_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_rg_job_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_rg_job_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_rg_job_appln_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_rg_job_appln_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_acad_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_acad_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_advert_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_advert_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_app_dd_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_app_dd_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_data_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_data_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_gq_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_gq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_guru_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_guru_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_it_sol_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_it_sol_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_mrq_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_mrq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_mrs_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_mrs_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_nreg_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_nreg_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_pq_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_pq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_pre_pro_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_pre_pro_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_priv_ctrl_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_priv_ctrl_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_prq_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_prq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_prs_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_prs_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_rcmnd_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_rcmnd_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_sms_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_sms_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_web_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_web_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sst_seq_tab.sql
  \i /tmp/ees_public//postgres/gn_sst_seq_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_state_tab.sql
  \i /tmp/ees_public//postgres/gn_state_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_tree_object_tab.sql
  \i /tmp/ees_public//postgres/gn_tree_object_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_type_code_tab.sql
  \i /tmp/ees_public//postgres/gn_type_code_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_type_value_tab.sql
  \i /tmp/ees_public//postgres/gn_type_value_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_type_value_map_tab.sql
  \i /tmp/ees_public//postgres/gn_type_value_map_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_tab.sql
  \i /tmp/ees_public//postgres/gn_user_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_access_tab.sql
  \i /tmp/ees_public//postgres/gn_user_access_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_js_mth_sum_tab.sql
  \i /tmp/ees_public//postgres/gn_user_js_mth_sum_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_js_tot_sum_tab.sql
  \i /tmp/ees_public//postgres/gn_user_js_tot_sum_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_js_txn_tab.sql
  \i /tmp/ees_public//postgres/gn_user_js_txn_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_privacy_rule_tab.sql
  \i /tmp/ees_public//postgres/gn_user_privacy_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_user_role_tab.sql
  \i /tmp/ees_public//postgres/gn_user_role_pkey.sql
  

  \i /tmp/ees_public//postgres/job_flow_tab.sql
  \i /tmp/ees_public//postgres/job_flow_pkey.sql
  

  \i /tmp/ees_public//postgres/job_program_tab.sql
  \i /tmp/ees_public//postgres/job_program_pkey.sql
  

  \i /tmp/ees_public//postgres/job_status_dtl_tab.sql
  \i /tmp/ees_public//postgres/job_status_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_action_tab.sql
  \i /tmp/ees_public//postgres/rms_action_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_condition_tab.sql
  \i /tmp/ees_public//postgres/rms_condition_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_function_tab.sql
  \i /tmp/ees_public//postgres/rms_function_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_function_param_tab.sql
  \i /tmp/ees_public//postgres/rms_function_param_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_macro_tab.sql
  \i /tmp/ees_public//postgres/rms_macro_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_rule_tab.sql
  \i /tmp/ees_public//postgres/rms_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/rms_threshold_tab.sql
  \i /tmp/ees_public//postgres/rms_threshold_pkey.sql
  

  \i /tmp/ees_public//postgres/gn_sstptl_user_web_tab.sql
  \i /tmp/ees_public//postgres/gn_sstptl_user_web_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_absent_type_tab.sql
  \i /tmp/ees_public//postgres/hr_absent_type_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_academic_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_academic_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_address_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_address_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_contact_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_employer_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_employer_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_health_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_health_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_identity_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_identity_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_rate_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_rate_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_req_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_req_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_applicant_skill_domain_tab.sql
  \i /tmp/ees_public//postgres/hr_applicant_skill_domain_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_banker_tab.sql
  \i /tmp/ees_public//postgres/hr_banker_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_budget_code_tab.sql
  \i /tmp/ees_public//postgres/hr_budget_code_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_building_tab.sql
  \i /tmp/ees_public//postgres/hr_building_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_building_room_tab.sql
  \i /tmp/ees_public//postgres/hr_building_room_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_card_file_tab.sql
  \i /tmp/ees_public//postgres/hr_card_file_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_card_time_tab.sql
  \i /tmp/ees_public//postgres/hr_card_time_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cost_center_tab.sql
  \i /tmp/ees_public//postgres/hr_cost_center_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_agr_act_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_agr_act_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_agr_act_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_agr_act_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_agreement_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_agreement_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_agreement_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_agreement_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_agr_form_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_agr_form_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_cust_rate_plan_tab.sql
  \i /tmp/ees_public//postgres/hr_cust_rate_plan_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_department_tab.sql
  \i /tmp/ees_public//postgres/hr_department_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_dept_expense_summary_tab.sql
  \i /tmp/ees_public//postgres/hr_dept_expense_summary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_dept_general_expense_tab.sql
  \i /tmp/ees_public//postgres/hr_dept_general_expense_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_academic_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_academic_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_activity_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_activity_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_activity_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_activity_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_address_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_address_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_agreement_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_agreement_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_agreement_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_agreement_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_appraisal_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_appraisal_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_attendance_sum_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_attendance_sum_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_clubbed_salary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_clubbed_salary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_clubbed_salary_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_clubbed_salary_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_daily_timesheet_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_daily_timesheet_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_daily_timesheet_sum_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_daily_timesheet_sum_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_employer_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_employer_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_expense_summary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_expense_summary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_family_academic_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_family_academic_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_feedback_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_feedback_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_general_expense_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_general_expense_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_health_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_health_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_identity_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_identity_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_inc_prom_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_inc_prom_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_inc_prom_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_inc_prom_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_inc_prom_dtl_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_inc_prom_dtl_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_inc_prom_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_inc_prom_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_installment_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_installment_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_local_conveyance_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_local_conveyance_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_family_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_family_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_rate_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_rate_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_request_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_request_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_shift_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_shift_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_employee_shift_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_employee_shift_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_medi_claim_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_medi_claim_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_medi_claim_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_medi_claim_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_rr_accrued_amt_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_rr_accrued_amt_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_salary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_salary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_salary_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_salary_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_salary_summary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_salary_summary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_salary_summary_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_salary_summary_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_shift_change_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_shift_change_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_skill_domain_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_skill_domain_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_spl_date_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_spl_date_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_timesheet_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_timesheet_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_timesheet_summary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_timesheet_summary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_total_salary_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_total_salary_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_total_salary_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_total_salary_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_vacation_bal_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_vacation_bal_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_vacation_encash_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_vacation_encash_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_yearly_tax_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_yearly_tax_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_eval_criteria_tab.sql
  \i /tmp/ees_public//postgres/hr_eval_criteria_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_finance_year_def_tab.sql
  \i /tmp/ees_public//postgres/hr_finance_year_def_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_holiday_tab.sql
  \i /tmp/ees_public//postgres/hr_holiday_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_job_alloc_tab.sql
  \i /tmp/ees_public//postgres/hr_job_alloc_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_job_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_job_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_logical_grp_tab.sql
  \i /tmp/ees_public//postgres/hr_logical_grp_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_org_account_tab.sql
  \i /tmp/ees_public//postgres/hr_org_account_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_organization_tab.sql
  \i /tmp/ees_public//postgres/hr_organization_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_organization_address_tab.sql
  \i /tmp/ees_public//postgres/hr_organization_address_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_org_parameter_tab.sql
  \i /tmp/ees_public//postgres/hr_org_parameter_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_org_project_tab.sql
  \i /tmp/ees_public//postgres/hr_org_project_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_outsource_emp_tab.sql
  \i /tmp/ees_public//postgres/hr_outsource_emp_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_outsource_emp_hist_tab.sql
  \i /tmp/ees_public//postgres/hr_outsource_emp_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_tab.sql
  \i /tmp/ees_public//postgres/hr_position_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_eligibility_tab.sql
  \i /tmp/ees_public//postgres/hr_position_eligibility_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_job_profile_tab.sql
  \i /tmp/ees_public//postgres/hr_position_job_profile_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_level_tab.sql
  \i /tmp/ees_public//postgres/hr_position_level_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_quali_tab.sql
  \i /tmp/ees_public//postgres/hr_position_quali_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_position_skill_tab.sql
  \i /tmp/ees_public//postgres/hr_position_skill_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_project_requirement_tab.sql
  \i /tmp/ees_public//postgres/hr_project_requirement_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_project_team_member_tab.sql
  \i /tmp/ees_public//postgres/hr_project_team_member_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruitment_tab.sql
  \i /tmp/ees_public//postgres/hr_recruitment_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruitment_memo_tab.sql
  \i /tmp/ees_public//postgres/hr_recruitment_memo_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruitment_req_tab.sql
  \i /tmp/ees_public//postgres/hr_recruitment_req_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruitment_round_tab.sql
  \i /tmp/ees_public//postgres/hr_recruitment_round_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruitment_vendor_tab.sql
  \i /tmp/ees_public//postgres/hr_recruitment_vendor_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_recruit_post_skill_tab.sql
  \i /tmp/ees_public//postgres/hr_recruit_post_skill_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_salary_cycle_tab.sql
  \i /tmp/ees_public//postgres/hr_salary_cycle_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_salary_cycle_profile_tab.sql
  \i /tmp/ees_public//postgres/hr_salary_cycle_profile_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_salary_head_tab.sql
  \i /tmp/ees_public//postgres/hr_salary_head_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_salary_run_date_tab.sql
  \i /tmp/ees_public//postgres/hr_salary_run_date_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_shift_tab.sql
  \i /tmp/ees_public//postgres/hr_shift_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_skill_set_tab.sql
  \i /tmp/ees_public//postgres/hr_skill_set_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_tax_rebate_reason_tab.sql
  \i /tmp/ees_public//postgres/hr_tax_rebate_reason_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_tax_rebate_reason_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_tax_rebate_reason_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_tax_rule_tab.sql
  \i /tmp/ees_public//postgres/hr_tax_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_timesheet_rep_tab.sql
  \i /tmp/ees_public//postgres/hr_timesheet_rep_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_trainee_attn_tab.sql
  \i /tmp/ees_public//postgres/hr_trainee_attn_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_training_charge_tab.sql
  \i /tmp/ees_public//postgres/hr_training_charge_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_training_course_tab.sql
  \i /tmp/ees_public//postgres/hr_training_course_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_training_grp_req_tab.sql
  \i /tmp/ees_public//postgres/hr_training_grp_req_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_training_req_tab.sql
  \i /tmp/ees_public//postgres/hr_training_req_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_training_sch_tab.sql
  \i /tmp/ees_public//postgres/hr_training_sch_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_travel_expense_report_tab.sql
  \i /tmp/ees_public//postgres/hr_travel_expense_report_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_travel_req_tab.sql
  \i /tmp/ees_public//postgres/hr_travel_req_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_travel_req_dtl_tab.sql
  \i /tmp/ees_public//postgres/hr_travel_req_dtl_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_vacation_request_tab.sql
  \i /tmp/ees_public//postgres/hr_vacation_request_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_vendor_tab.sql
  \i /tmp/ees_public//postgres/hr_vendor_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_wages_statewise_tab.sql
  \i /tmp/ees_public//postgres/hr_wages_statewise_pkey.sql
  

  \i /tmp/ees_public//postgres/im_item_stock_tab.sql
  \i /tmp/ees_public//postgres/im_item_stock_pkey.sql
  

  \i /tmp/ees_public//postgres/im_monthly_stock_temp_tab.sql
  \i /tmp/ees_public//postgres/im_monthly_stock_temp_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_cnsty_tab.sql
  \i /tmp/ees_public//postgres/jag_cnsty_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_eval_criteria_tab.sql
  \i /tmp/ees_public//postgres/jag_eval_criteria_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_member_rate_tab.sql
  \i /tmp/ees_public//postgres/jag_member_rate_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_my_mem_team_tab.sql
  \i /tmp/ees_public//postgres/jag_my_mem_team_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_my_mf_tab.sql
  \i /tmp/ees_public//postgres/jag_my_mf_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_my_quiz_choice_tab.sql
  \i /tmp/ees_public//postgres/jag_my_quiz_choice_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_quiz_quest_tab.sql
  \i /tmp/ees_public//postgres/jag_quiz_quest_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_class_student_tab.sql
  \i /tmp/ees_public//postgres/ees_class_student_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_room_class_tab.sql
  \i /tmp/ees_public//postgres/ees_room_class_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_student_trip_tab.sql
  \i /tmp/ees_public//postgres/ees_student_trip_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_subject_faculty_obso_tab.sql
  \i /tmp/ees_public//postgres/ees_subject_faculty_obso_pkey.sql
  

  \i /tmp/ees_public//postgres/ees_tt_faculty_prd_cons_tab.sql
  \i /tmp/ees_public//postgres/ees_tt_faculty_prd_cons_pkey.sql
  

  \i /tmp/ees_public//postgres/ehs_patient_medi_hist_obso_tab.sql
  \i /tmp/ees_public//postgres/ehs_patient_medi_hist_obso_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_customer_address_delme_tab.sql
  \i /tmp/ees_public//postgres/esm_customer_address_delme_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_item_make_rate_obso_tab.sql
  \i /tmp/ees_public//postgres/esm_item_make_rate_obso_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_address_delme_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_address_delme_pkey.sql
  

  \i /tmp/ees_public//postgres/esm_supplier_address_delme1_tab.sql
  \i /tmp/ees_public//postgres/esm_supplier_address_delme1_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_banker_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_banker_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_contact_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_contact_pkey.sql
  

  \i /tmp/ees_public//postgres/hr_emp_daily_hour_tab.sql
  \i /tmp/ees_public//postgres/hr_emp_daily_hour_pkey.sql
  

  \i /tmp/ees_public//postgres/jag_user_hist_tab.sql
  \i /tmp/ees_public//postgres/jag_user_hist_pkey.sql
  

  \i /tmp/ees_public//postgres/job_flow_tab_tab.sql
  \i /tmp/ees_public//postgres/job_flow_tab_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_doc_tab.sql
  \i /tmp/ees_public//postgres/ots_doc_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_doc_item_tab.sql
  \i /tmp/ees_public//postgres/ots_doc_item_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_inv_amt_dist_tab.sql
  \i /tmp/ees_public//postgres/ots_inv_amt_dist_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_inv_amt_dist_clubbed_tab.sql
  \i /tmp/ees_public//postgres/ots_inv_amt_dist_clubbed_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_inv_amt_dist_rule_tab.sql
  \i /tmp/ees_public//postgres/ots_inv_amt_dist_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_item_om_rule_tab.sql
  \i /tmp/ees_public//postgres/ots_item_om_rule_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_member_tab.sql
  \i /tmp/ees_public//postgres/ots_member_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_ord_sts_wait_tab.sql
  \i /tmp/ees_public//postgres/ots_ord_sts_wait_pkey.sql
  

  \i /tmp/ees_public//postgres/ots_shopping_cart_tab.sql
  \i /tmp/ees_public//postgres/ots_shopping_cart_pkey.sql
  

  \i /tmp/ees_public//postgres/pbs_club_tab.sql
  \i /tmp/ees_public//postgres/pbs_club_pkey.sql
  

  \i /tmp/ees_public//postgres/pbs_pkg_ftr_tab.sql
  \i /tmp/ees_public//postgres/pbs_pkg_ftr_pkey.sql
  

  \i /tmp/ees_public//postgres/pbs_point_tab.sql
  \i /tmp/ees_public//postgres/pbs_point_pkey.sql
  

  \i /tmp/ees_public//postgres/pbs_point_clubbed_tab.sql
  \i /tmp/ees_public//postgres/pbs_point_clubbed_pkey.sql
  

  \i /tmp/ees_public//postgres/pbs_point_info_tab.sql
  \i /tmp/ees_public//postgres/pbs_point_info_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_daily_status_tab.sql
  \i /tmp/ees_public//postgres/pm_daily_status_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_estimation_model_tab.sql
  \i /tmp/ees_public//postgres/pm_estimation_model_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_fp_project_tab.sql
  \i /tmp/ees_public//postgres/pm_fp_project_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_project_tab.sql
  \i /tmp/ees_public//postgres/pm_project_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_qa_checklist_tab.sql
  \i /tmp/ees_public//postgres/pm_qa_checklist_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_release_tab.sql
  \i /tmp/ees_public//postgres/pm_release_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_release_plan_tab.sql
  \i /tmp/ees_public//postgres/pm_release_plan_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_release_sprint_tab.sql
  \i /tmp/ees_public//postgres/pm_release_sprint_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_user_story_tab.sql
  \i /tmp/ees_public//postgres/pm_user_story_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_user_story_breakup_tab.sql
  \i /tmp/ees_public//postgres/pm_user_story_breakup_pkey.sql
  

  \i /tmp/ees_public//postgres/pm_user_story_impact_tab.sql
  \i /tmp/ees_public//postgres/pm_user_story_impact_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_apps_tab.sql
  \i /tmp/ees_public//postgres/sdm_apps_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_entity_tab.sql
  \i /tmp/ees_public//postgres/sdm_entity_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_entity_attr_tab.sql
  \i /tmp/ees_public//postgres/sdm_entity_attr_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_index_tab.sql
  \i /tmp/ees_public//postgres/sdm_index_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_sequence_tab.sql
  \i /tmp/ees_public//postgres/sdm_sequence_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_synonym_tab.sql
  \i /tmp/ees_public//postgres/sdm_synonym_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_type_def_tab.sql
  \i /tmp/ees_public//postgres/sdm_type_def_pkey.sql
  

  \i /tmp/ees_public//postgres/sdm_view_tab.sql
  \i /tmp/ees_public//postgres/sdm_view_pkey.sql
  

  \i /tmp/ees_public//postgres/qa_defect_tab.sql
  \i /tmp/ees_public//postgres/qa_defect_pkey.sql
  

  \i /tmp/ees_public//postgres/qa_testcase_tab.sql
  \i /tmp/ees_public//postgres/qa_testcase_pkey.sql
  

  \i /tmp/ees_public//postgres/qa_testcase_step_tab.sql
  \i /tmp/ees_public//postgres/qa_testcase_step_pkey.sql
  

  \i /tmp/ees_public//postgres/all_circle_tab.sql
  \i /tmp/ees_public//postgres/all_circle_pkey.sql
  

  \i /tmp/ees_public//postgres/all_division_tab.sql
  \i /tmp/ees_public//postgres/all_division_pkey.sql
  
