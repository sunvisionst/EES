
var lBbmDonorEmployerTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorEmployerTabObjArrCache != null && lBbmDonorEmployerTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorEmployerTabObjJSArr = new Array(<%=lBbmDonorEmployerTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorEmployerTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorEmployerTabObj lBbmDonorEmployerTabObj    =    new BbmDonorEmployerTabObj();
          lBbmDonorEmployerTabObj = (BbmDonorEmployerTabObj)lBbmDonorEmployerTabObjArrCache.get(lRecNum);
%>
          lBbmDonorEmployerTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorEmployer
          (
          "<%=lBbmDonorEmployerTabObj.donor_id%>",
          "<%=lBbmDonorEmployerTabObj.employer_name%>",
          "<%=lBbmDonorEmployerTabObj.period_from%>",
          "<%=lBbmDonorEmployerTabObj.period_to%>",
          "<%=lBbmDonorEmployerTabObj.project_handled%>",
          "<%=lBbmDonorEmployerTabObj.role_in_project%>",
          "<%=lBbmDonorEmployerTabObj.ctc%>",
          "<%=lBbmDonorEmployerTabObj.skill_set_in_project%>",
          "<%=lBbmDonorEmployerTabObj.project_description%>"
          );
<%
       }
   }
}
%>


