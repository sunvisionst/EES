
var lBbmDonorPhoneTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorPhoneTabObjArrCache != null && lBbmDonorPhoneTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorPhoneTabObjJSArr = new Array(<%=lBbmDonorPhoneTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorPhoneTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorPhoneTabObj lBbmDonorPhoneTabObj    =    new BbmDonorPhoneTabObj();
          lBbmDonorPhoneTabObj = (BbmDonorPhoneTabObj)lBbmDonorPhoneTabObjArrCache.get(lRecNum);
%>
          lBbmDonorPhoneTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorPhone
          (
          "<%=lBbmDonorPhoneTabObj.donor_id%>",
          "<%=lBbmDonorPhoneTabObj.seq_num%>",
          "<%=lBbmDonorPhoneTabObj.contact_type%>",
          "<%=lBbmDonorPhoneTabObj.phone_type%>",
          "<%=lBbmDonorPhoneTabObj.contact_num%>",
          "<%=lBbmDonorPhoneTabObj.effective_date%>",
          "<%=lBbmDonorPhoneTabObj.expiration_date%>",
          "<%=lBbmDonorPhoneTabObj.remark%>"
          );
<%
       }
   }
}
%>


