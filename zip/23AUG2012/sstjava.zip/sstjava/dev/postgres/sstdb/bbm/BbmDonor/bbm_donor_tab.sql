CREATE TABLE BBM_DONOR
(
  DONOR_ID                                                                                            VARCHAR(10),
  DONOR_TYPE                                                                                          VARCHAR(1),
  DONOR_F_NAME                                                                                        VARCHAR(30),
  DONOR_M_NAME                                                                                        VARCHAR(30),
  DONOR_L_NAME                                                                                        VARCHAR(30),
  GENDER                                                                                              VARCHAR(1),
  DOB                                                                                                 VARCHAR(8),
  BIRTH_CITY                                                                                          VARCHAR(30),
  BIRTH_COUNTRY                                                                                       VARCHAR(30),
  RELATION_NAME                                                                                       VARCHAR(1),
  RELATIVE_NAME                                                                                       VARCHAR(100),
  MARITAL_STATUS                                                                                      VARCHAR(50)
)
 WITH OIDS;
