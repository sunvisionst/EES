package sstdb.bbm.BbmDonorBloodDtl;


public class BbmDonorBloodDtlTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public String                                 blood_ingredient;
  public String                                 remark;





  public short                                  donor_id_ind;
  public short                                  blood_ingredient_ind;
  public short                                  remark_ind;


  public BbmDonorBloodDtlTabObj(){}


  public BbmDonorBloodDtlTabObj
  (
    String donor_id,
    String blood_ingredient,
    String remark
  )
  {
     this.donor_id = donor_id;
     this.blood_ingredient = blood_ingredient;
     this.remark = remark;
  }

  public String getdonor_id()                          { return donor_id; }
  public String getblood_ingredient()                      { return blood_ingredient; }
  public String getremark()                           { return remark; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setblood_ingredient(String blood_ingredient )          { this.blood_ingredient = blood_ingredient; }
  public void  setremark(String remark )                    { this.remark = remark; }
}