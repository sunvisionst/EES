CREATE TABLE BBM_BLOOD_BANK
(
  HOSPITAL_ID                                                                                         VARCHAR(10),
  BRANCH_ID                                                                                           VARCHAR(10),
  BLOOD_BANK_ID                                                                                       VARCHAR(10)
)
 WITH OIDS;
