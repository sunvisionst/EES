
var lBbmBloodBottleTabObjJSArr = new Array();
<%
{
   if ( lBbmBloodBottleTabObjArrCache != null && lBbmBloodBottleTabObjArrCache.size() > 0 )
   {
%>
       lBbmBloodBottleTabObjJSArr = new Array(<%=lBbmBloodBottleTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmBloodBottleTabObjArrCache.size(); lRecNum++ )
       {
          BbmBloodBottleTabObj lBbmBloodBottleTabObj    =    new BbmBloodBottleTabObj();
          lBbmBloodBottleTabObj = (BbmBloodBottleTabObj)lBbmBloodBottleTabObjArrCache.get(lRecNum);
%>
          lBbmBloodBottleTabObjJSArr[<%=lRecNum%>] = new constructorBbmBloodBottle
          (
          "<%=lBbmBloodBottleTabObj.hospital_id%>",
          "<%=lBbmBloodBottleTabObj.branch_id%>",
          "<%=lBbmBloodBottleTabObj.blood_bank_id%>",
          "<%=lBbmBloodBottleTabObj.bottle_id%>",
          "<%=lBbmBloodBottleTabObj.blood_group%>",
          "<%=lBbmBloodBottleTabObj.blood_type%>",
          "<%=lBbmBloodBottleTabObj.rate%>",
          "<%=lBbmBloodBottleTabObj.bottle_rack_num%>",
          "<%=lBbmBloodBottleTabObj.bottle_shelf_num%>",
          "<%=lBbmBloodBottleTabObj.effective_date%>",
          "<%=lBbmBloodBottleTabObj.expiration_date%>",
          "<%=lBbmBloodBottleTabObj.remark%>",
          "<%=lBbmBloodBottleTabObj.blood_source%>",
          "<%=lBbmBloodBottleTabObj.donor_id%>",
          "<%=lBbmBloodBottleTabObj.delivery_status%>",
          "<%=lBbmBloodBottleTabObj.patient_id%>",
          "<%=lBbmBloodBottleTabObj.receipt_num%>",
          "<%=lBbmBloodBottleTabObj.receipt_date%>"
          );
<%
       }
   }
}
%>


