function BbmDonorBloodDtlRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("donor_id").readOnly = true;
    document.getElementById("blood_ingredient").value  = document.getElementById("blood_ingredient"+"_r"+inRecNum).value;
    document.getElementById("blood_ingredient").readOnly = true;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("donor_id").value = '';
    document.getElementById("donor_id").readOnly = false;
    document.getElementById("blood_ingredient").value = '';
    document.getElementById("blood_ingredient").readOnly = false;
    document.getElementById("remark").value = '';
  }
}
