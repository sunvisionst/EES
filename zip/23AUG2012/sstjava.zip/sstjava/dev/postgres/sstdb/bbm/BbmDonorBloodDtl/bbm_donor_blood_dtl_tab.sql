CREATE TABLE BBM_DONOR_BLOOD_DTL
(
  DONOR_ID                                                                                            VARCHAR(10),
  BLOOD_INGREDIENT                                                                                    VARCHAR(10),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
