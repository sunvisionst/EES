CREATE TABLE BBM_DONOR_ADDRESS_EXT
(
  donor_id                                                                                            VARCHAR(10),
  address_type                                                                                        VARCHAR(10),
  address1                                                                                            VARCHAR(50),
  address2                                                                                            VARCHAR(50),
  city                                                                                                VARCHAR(50),
  zip                                                                                                 NUMERIC(10),
  country                                                                                             VARCHAR(50)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       ADDRESS_TYPE                                                                                        CHAR(10),
       ADDRESS1                                                                                            CHAR(50),
       ADDRESS2                                                                                            CHAR(50),
       CITY                                                                                                CHAR(50),
       ZIP                                                                                                 CHAR(10),
       COUNTRY                                                                                             CHAR(50)
    )
  )
  LOCATION ('bbm_donor_address_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
