{


   function vldDBSizeEnvBbmDonorMail
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeDonorId ( inTableName, inFieldName );
      vldFieldDBSizeSeqNum ( inTableName, inFieldName );
      vldFieldDBSizeMailType ( inTableName, inFieldName );
      vldFieldDBSizeMailId ( inTableName, inFieldName );
      vldFieldDBSizeEffectiveDate ( inTableName, inFieldName );
      vldFieldDBSizeExpirationDate ( inTableName, inFieldName );
      vldFieldDBSizeRemark ( inTableName, inFieldName );
   }



   function constructorBbmDonorMail
   (
      donor_id,
      seq_num,
      mail_type,
      mail_id,
      effective_date,
      expiration_date,
      remark
   )
   {
      this.donor_id = donor_id;
      this.seq_num = seq_num;
      this.mail_type = mail_type;
      this.mail_id = mail_id;
      this.effective_date = effective_date;
      this.expiration_date = expiration_date;
      this.remark = remark;
   }



   function BbmDonorMailFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lBbmDonorMailTabObjJSArr.length )
      {
         if
         ( 
           ( lBbmDonorMailTabObjJSArr[lRecNum].donor_id != document.form.donor_id.value ) &&
           ( lBbmDonorMailTabObjJSArr[lRecNum].seq_num != document.form.seq_num.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeBbmDonorMailTabObjDonorId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjSeqNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >2 )
      {
         alert("Data base field size error. Size should be <= 2");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjMailType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjMailId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjEffectiveDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjExpirationDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorMailTabObjRemark
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisDonorId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSeqNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >2 )
      {
         alert("Data base field size error. Size should be <= 2");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMailType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMailId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisEffectiveDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisExpirationDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRemark
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



}