function BbmBloodBankRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("hospital_id").value  = document.getElementById("hospital_id"+"_r"+inRecNum).value;
    document.getElementById("hospital_id").readOnly = true;
    document.getElementById("branch_id").value  = document.getElementById("branch_id"+"_r"+inRecNum).value;
    document.getElementById("branch_id").readOnly = true;
    document.getElementById("blood_bank_id").value  = document.getElementById("blood_bank_id"+"_r"+inRecNum).value;
    document.getElementById("blood_bank_id").readOnly = true;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("hospital_id").value = '';
    document.getElementById("hospital_id").readOnly = false;
    document.getElementById("branch_id").value = '';
    document.getElementById("branch_id").readOnly = false;
    document.getElementById("blood_bank_id").value = '';
    document.getElementById("blood_bank_id").readOnly = false;
  }
}
