CREATE TABLE BBM_DONOR_IDENTITY
(
  DONOR_ID                                                                                            VARCHAR(10),
  ID_TYPE                                                                                             VARCHAR(10),
  ID_TYPE_ID                                                                                          VARCHAR(20),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
