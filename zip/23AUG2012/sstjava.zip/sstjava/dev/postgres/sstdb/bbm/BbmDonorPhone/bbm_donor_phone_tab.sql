CREATE TABLE BBM_DONOR_PHONE
(
  DONOR_ID                                                                                            VARCHAR(10),
  SEQ_NUM                                                                                             NUMERIC(2),
  CONTACT_TYPE                                                                                        VARCHAR(10),
  PHONE_TYPE                                                                                          VARCHAR(10),
  CONTACT_NUM                                                                                         VARCHAR(30),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
