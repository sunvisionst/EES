package sstdb.bbm.BbmBloodBank;


public class BbmBloodBankPkeyObj
{
  public String                                 hospital_id;
  public String                                 branch_id;
  public String                                 blood_bank_id;
}