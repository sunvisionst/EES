
var lBbmDonorTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorTabObjArrCache != null && lBbmDonorTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorTabObjJSArr = new Array(<%=lBbmDonorTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorTabObj lBbmDonorTabObj    =    new BbmDonorTabObj();
          lBbmDonorTabObj = (BbmDonorTabObj)lBbmDonorTabObjArrCache.get(lRecNum);
%>
          lBbmDonorTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonor
          (
          "<%=lBbmDonorTabObj.donor_id%>",
          "<%=lBbmDonorTabObj.donor_type%>",
          "<%=lBbmDonorTabObj.donor_f_name%>",
          "<%=lBbmDonorTabObj.donor_m_name%>",
          "<%=lBbmDonorTabObj.donor_l_name%>",
          "<%=lBbmDonorTabObj.gender%>",
          "<%=lBbmDonorTabObj.dob%>",
          "<%=lBbmDonorTabObj.birth_city%>",
          "<%=lBbmDonorTabObj.birth_country%>",
          "<%=lBbmDonorTabObj.relation_name%>",
          "<%=lBbmDonorTabObj.relative_name%>",
          "<%=lBbmDonorTabObj.marital_status%>"
          );
<%
       }
   }
}
%>


