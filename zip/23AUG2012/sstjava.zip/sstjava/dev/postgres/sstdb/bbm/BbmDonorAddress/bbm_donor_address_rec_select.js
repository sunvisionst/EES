function BbmDonorAddressRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("donor_id").readOnly = true;
    document.getElementById("address_type").value  = document.getElementById("address_type"+"_r"+inRecNum).value;
    document.getElementById("address_type").readOnly = true;
    document.getElementById("address1").value  = document.getElementById("address1"+"_r"+inRecNum).value;
    document.getElementById("address2").value  = document.getElementById("address2"+"_r"+inRecNum).value;
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value;
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("donor_id").value = '';
    document.getElementById("donor_id").readOnly = false;
    document.getElementById("address_type").value = '';
    document.getElementById("address_type").readOnly = false;
    document.getElementById("address1").value = '';
    document.getElementById("address2").value = '';
    document.getElementById("city").value = '';
    document.getElementById("zip").value = '';
    document.getElementById("country").value = '';
  }
}
