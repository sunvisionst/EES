
var lBbmDonorMailTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorMailTabObjArrCache != null && lBbmDonorMailTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorMailTabObjJSArr = new Array(<%=lBbmDonorMailTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorMailTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorMailTabObj lBbmDonorMailTabObj    =    new BbmDonorMailTabObj();
          lBbmDonorMailTabObj = (BbmDonorMailTabObj)lBbmDonorMailTabObjArrCache.get(lRecNum);
%>
          lBbmDonorMailTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorMail
          (
          "<%=lBbmDonorMailTabObj.donor_id%>",
          "<%=lBbmDonorMailTabObj.seq_num%>",
          "<%=lBbmDonorMailTabObj.mail_type%>",
          "<%=lBbmDonorMailTabObj.mail_id%>",
          "<%=lBbmDonorMailTabObj.effective_date%>",
          "<%=lBbmDonorMailTabObj.expiration_date%>",
          "<%=lBbmDonorMailTabObj.remark%>"
          );
<%
       }
   }
}
%>


