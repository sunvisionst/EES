package sstdb.bbm.BbmBloodBottleHistory;


public class BbmBloodBottleHistoryPkeyObj
{
  public String                                 hospital_id;
  public String                                 branch_id;
  public String                                 blood_bank_id;
  public String                                 bottle_id;
  public String                                 history_date;
}