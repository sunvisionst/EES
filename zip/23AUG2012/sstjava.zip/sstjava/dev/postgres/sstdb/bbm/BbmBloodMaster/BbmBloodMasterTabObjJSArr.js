
var lBbmBloodMasterTabObjJSArr = new Array();
<%
{
   if ( lBbmBloodMasterTabObjArrCache != null && lBbmBloodMasterTabObjArrCache.size() > 0 )
   {
%>
       lBbmBloodMasterTabObjJSArr = new Array(<%=lBbmBloodMasterTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmBloodMasterTabObjArrCache.size(); lRecNum++ )
       {
          BbmBloodMasterTabObj lBbmBloodMasterTabObj    =    new BbmBloodMasterTabObj();
          lBbmBloodMasterTabObj = (BbmBloodMasterTabObj)lBbmBloodMasterTabObjArrCache.get(lRecNum);
%>
          lBbmBloodMasterTabObjJSArr[<%=lRecNum%>] = new constructorBbmBloodMaster
          (
          "<%=lBbmBloodMasterTabObj.blood_group%>",
          "<%=lBbmBloodMasterTabObj.blood_type%>",
          "<%=lBbmBloodMasterTabObj.description%>"
          );
<%
       }
   }
}
%>


