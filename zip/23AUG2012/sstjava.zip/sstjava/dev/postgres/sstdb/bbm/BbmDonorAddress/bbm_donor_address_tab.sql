CREATE TABLE BBM_DONOR_ADDRESS
(
  DONOR_ID                                                                                            VARCHAR(10),
  ADDRESS_TYPE                                                                                        VARCHAR(10),
  ADDRESS1                                                                                            VARCHAR(50),
  ADDRESS2                                                                                            VARCHAR(50),
  CITY                                                                                                VARCHAR(50),
  ZIP                                                                                                 NUMERIC(10),
  COUNTRY                                                                                             VARCHAR(50)
)
 WITH OIDS;
