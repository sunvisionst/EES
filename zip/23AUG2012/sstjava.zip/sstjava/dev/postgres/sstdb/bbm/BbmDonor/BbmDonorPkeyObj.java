package sstdb.bbm.BbmDonor;


public class BbmDonorPkeyObj
{
  public String                                 donor_id;
  public String                                 donor_type;
}