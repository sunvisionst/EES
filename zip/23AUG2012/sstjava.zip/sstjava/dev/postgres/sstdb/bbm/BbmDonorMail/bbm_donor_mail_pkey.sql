ALTER TABLE           BBM_DONOR_MAIL
  ADD                 CONSTRAINT BBM_DONOR_MAIL_PK
  PRIMARY             KEY
  ( DONOR_ID, SEQ_NUM )
;
