CREATE TABLE BBM_DONOR_MAIL
(
  DONOR_ID                                                                                            VARCHAR(10),
  SEQ_NUM                                                                                             NUMERIC(2),
  MAIL_TYPE                                                                                           VARCHAR(10),
  MAIL_ID                                                                                             VARCHAR(30),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
