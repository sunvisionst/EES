CREATE TABLE BBM_DONOR_EXT
(
  donor_id                                                                                            VARCHAR(10),
  donor_type                                                                                          VARCHAR(1),
  donor_f_name                                                                                        VARCHAR(30),
  donor_m_name                                                                                        VARCHAR(30),
  donor_l_name                                                                                        VARCHAR(30),
  gender                                                                                              VARCHAR(1),
  dob                                                                                                 VARCHAR(8),
  birth_city                                                                                          VARCHAR(30),
  birth_country                                                                                       VARCHAR(30),
  relation_name                                                                                       VARCHAR(1),
  relative_name                                                                                       VARCHAR(100),
  marital_status                                                                                      VARCHAR(50)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       DONOR_TYPE                                                                                          CHAR(1),
       DONOR_F_NAME                                                                                        CHAR(30),
       DONOR_M_NAME                                                                                        CHAR(30),
       DONOR_L_NAME                                                                                        CHAR(30),
       GENDER                                                                                              CHAR(1),
       DOB                                                                                                 CHAR(8),
       BIRTH_CITY                                                                                          CHAR(30),
       BIRTH_COUNTRY                                                                                       CHAR(30),
       RELATION_NAME                                                                                       CHAR(1),
       RELATIVE_NAME                                                                                       CHAR(100),
       MARITAL_STATUS                                                                                      CHAR(50)
    )
  )
  LOCATION ('bbm_donor_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
