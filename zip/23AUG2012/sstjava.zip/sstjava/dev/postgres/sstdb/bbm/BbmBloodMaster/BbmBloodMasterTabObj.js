{


   function vldDBSizeEnvBbmBloodMaster
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeBloodGroup ( inTableName, inFieldName );
      vldFieldDBSizeBloodType ( inTableName, inFieldName );
      vldFieldDBSizeDescription ( inTableName, inFieldName );
   }



   function constructorBbmBloodMaster
   (
      blood_group,
      blood_type,
      description
   )
   {
      this.blood_group = blood_group;
      this.blood_type = blood_type;
      this.description = description;
   }



   function BbmBloodMasterFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lBbmBloodMasterTabObjJSArr.length )
      {
         if
         ( 
           ( lBbmBloodMasterTabObjJSArr[lRecNum].blood_group != document.form.blood_group.value ) &&
           ( lBbmBloodMasterTabObjJSArr[lRecNum].blood_type != document.form.blood_type.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeBbmBloodMasterTabObjBloodGroup
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodMasterTabObjBloodType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodMasterTabObjDescription
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >60 )
      {
         alert("Data base field size error. Size should be <= 60");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisBloodGroup
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDescription
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >60 )
      {
         alert("Data base field size error. Size should be <= 60");
         inFieldName.focus();
      }
   }



}