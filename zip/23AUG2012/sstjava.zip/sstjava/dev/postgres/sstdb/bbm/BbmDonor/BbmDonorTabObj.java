package sstdb.bbm.BbmDonor;


public class BbmDonorTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public String                                 donor_type;
  public String                                 donor_f_name;
  public String                                 donor_m_name;
  public String                                 donor_l_name;
  public String                                 gender;
  public String                                 dob;
  public String                                 birth_city;
  public String                                 birth_country;
  public String                                 relation_name;
  public String                                 relative_name;
  public String                                 marital_status;





  public short                                  donor_id_ind;
  public short                                  donor_type_ind;
  public short                                  donor_f_name_ind;
  public short                                  donor_m_name_ind;
  public short                                  donor_l_name_ind;
  public short                                  gender_ind;
  public short                                  dob_ind;
  public short                                  birth_city_ind;
  public short                                  birth_country_ind;
  public short                                  relation_name_ind;
  public short                                  relative_name_ind;
  public short                                  marital_status_ind;


  public BbmDonorTabObj(){}


  public BbmDonorTabObj
  (
    String donor_id,
    String donor_type,
    String donor_f_name,
    String donor_m_name,
    String donor_l_name,
    String gender,
    String dob,
    String birth_city,
    String birth_country,
    String relation_name,
    String relative_name,
    String marital_status
  )
  {
     this.donor_id = donor_id;
     this.donor_type = donor_type;
     this.donor_f_name = donor_f_name;
     this.donor_m_name = donor_m_name;
     this.donor_l_name = donor_l_name;
     this.gender = gender;
     this.dob = dob;
     this.birth_city = birth_city;
     this.birth_country = birth_country;
     this.relation_name = relation_name;
     this.relative_name = relative_name;
     this.marital_status = marital_status;
  }

  public String getdonor_id()                          { return donor_id; }
  public String getdonor_type()                         { return donor_type; }
  public String getdonor_f_name()                        { return donor_f_name; }
  public String getdonor_m_name()                        { return donor_m_name; }
  public String getdonor_l_name()                        { return donor_l_name; }
  public String getgender()                           { return gender; }
  public String getdob()                            { return dob; }
  public String getbirth_city()                         { return birth_city; }
  public String getbirth_country()                       { return birth_country; }
  public String getrelation_name()                       { return relation_name; }
  public String getrelative_name()                       { return relative_name; }
  public String getmarital_status()                       { return marital_status; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setdonor_type(String donor_type )                { this.donor_type = donor_type; }
  public void  setdonor_f_name(String donor_f_name )              { this.donor_f_name = donor_f_name; }
  public void  setdonor_m_name(String donor_m_name )              { this.donor_m_name = donor_m_name; }
  public void  setdonor_l_name(String donor_l_name )              { this.donor_l_name = donor_l_name; }
  public void  setgender(String gender )                    { this.gender = gender; }
  public void  setdob(String dob )                       { this.dob = dob; }
  public void  setbirth_city(String birth_city )                { this.birth_city = birth_city; }
  public void  setbirth_country(String birth_country )             { this.birth_country = birth_country; }
  public void  setrelation_name(String relation_name )             { this.relation_name = relation_name; }
  public void  setrelative_name(String relative_name )             { this.relative_name = relative_name; }
  public void  setmarital_status(String marital_status )            { this.marital_status = marital_status; }
}