function BbmDonorEmployerRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("donor_id").readOnly = true;
    document.getElementById("employer_name").value  = document.getElementById("employer_name"+"_r"+inRecNum).value;
    document.getElementById("employer_name").readOnly = true;
    document.getElementById("period_from").value  = document.getElementById("period_from"+"_r"+inRecNum).value;
    document.getElementById("period_from").readOnly = true;
    document.getElementById("period_to").value  = document.getElementById("period_to"+"_r"+inRecNum).value;
    document.getElementById("project_handled").value  = document.getElementById("project_handled"+"_r"+inRecNum).value;
    document.getElementById("role_in_project").value  = document.getElementById("role_in_project"+"_r"+inRecNum).value;
    document.getElementById("ctc").value  = document.getElementById("ctc"+"_r"+inRecNum).value;
    document.getElementById("skill_set_in_project").value  = document.getElementById("skill_set_in_project"+"_r"+inRecNum).value;
    document.getElementById("project_description").value  = document.getElementById("project_description"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("donor_id").value = '';
    document.getElementById("donor_id").readOnly = false;
    document.getElementById("employer_name").value = '';
    document.getElementById("employer_name").readOnly = false;
    document.getElementById("period_from").value = '';
    document.getElementById("period_from").readOnly = false;
    document.getElementById("period_to").value = '';
    document.getElementById("project_handled").value = '';
    document.getElementById("role_in_project").value = '';
    document.getElementById("ctc").value = '';
    document.getElementById("skill_set_in_project").value = '';
    document.getElementById("project_description").value = '';
  }
}
