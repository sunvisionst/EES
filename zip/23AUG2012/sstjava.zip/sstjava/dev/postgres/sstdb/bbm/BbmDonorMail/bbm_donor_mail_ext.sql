CREATE TABLE BBM_DONOR_MAIL_EXT
(
  donor_id                                                                                            VARCHAR(10),
  seq_num                                                                                             NUMERIC(2),
  mail_type                                                                                           VARCHAR(10),
  mail_id                                                                                             VARCHAR(30),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       SEQ_NUM                                                                                             CHAR(2),
       MAIL_TYPE                                                                                           CHAR(10),
       MAIL_ID                                                                                             CHAR(30),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('bbm_donor_mail_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
