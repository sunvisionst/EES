CREATE TABLE BBM_BLOOD_BANK_EXT
(
  hospital_id                                                                                         VARCHAR(10),
  branch_id                                                                                           VARCHAR(10),
  blood_bank_id                                                                                       VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       HOSPITAL_ID                                                                                         CHAR(10),
       BRANCH_ID                                                                                           CHAR(10),
       BLOOD_BANK_ID                                                                                       CHAR(10)
    )
  )
  LOCATION ('bbm_blood_bank_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
