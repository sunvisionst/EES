CREATE TABLE BBM_DONOR_EMPLOYER_EXT
(
  donor_id                                                                                            VARCHAR(10),
  employer_name                                                                                       VARCHAR(100),
  period_from                                                                                         VARCHAR(10),
  period_to                                                                                           VARCHAR(10),
  project_handled                                                                                     VARCHAR(100),
  role_in_project                                                                                     VARCHAR(20),
  ctc                                                                                                 NUMERIC(12,2),
  skill_set_in_project                                                                                VARCHAR(100),
  project_description                                                                                 VARCHAR(2000)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       EMPLOYER_NAME                                                                                       CHAR(100),
       PERIOD_FROM                                                                                         CHAR(10),
       PERIOD_TO                                                                                           CHAR(10),
       PROJECT_HANDLED                                                                                     CHAR(100),
       ROLE_IN_PROJECT                                                                                     CHAR(20),
       CTC                                                                                                 CHAR(12),
       SKILL_SET_IN_PROJECT                                                                                CHAR(100),
       PROJECT_DESCRIPTION                                                                                 CHAR(2000)
    )
  )
  LOCATION ('bbm_donor_employer_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
