package sstdb.bbm.BbmBloodBottleHistory;

import sstdb.bbm.BbmBloodBottleHistory.BbmBloodBottleHistoryTabObj;
import sstdb.bbm.BbmBloodBottleHistory.BbmBloodBottleHistoryPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class BbmBloodBottleHistoryMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public BbmBloodBottleHistoryMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "BbmBloodBottleHistoryMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initBbmBloodBottleHistoryTabObj
               ( 
                 BbmBloodBottleHistoryTabObj  outBbmBloodBottleHistoryTabObj
               )
  {
  
     outBbmBloodBottleHistoryTabObj.hospital_id = ""; 
     outBbmBloodBottleHistoryTabObj.branch_id = ""; 
     outBbmBloodBottleHistoryTabObj.blood_bank_id = ""; 
     outBbmBloodBottleHistoryTabObj.bottle_id = ""; 
     outBbmBloodBottleHistoryTabObj.history_date = ""; 
     outBbmBloodBottleHistoryTabObj.blood_group = ""; 
     outBbmBloodBottleHistoryTabObj.blood_type = ""; 
     outBbmBloodBottleHistoryTabObj.rate = (double)0.00; 
     outBbmBloodBottleHistoryTabObj.bottle_rack_num = (int)0; 
     outBbmBloodBottleHistoryTabObj.bottle_shelf_num = (int)0; 
     outBbmBloodBottleHistoryTabObj.effective_date = ""; 
     outBbmBloodBottleHistoryTabObj.expiration_date = ""; 
     outBbmBloodBottleHistoryTabObj.remark = ""; 
     outBbmBloodBottleHistoryTabObj.blood_source = ""; 
     outBbmBloodBottleHistoryTabObj.donor_id = ""; 
     outBbmBloodBottleHistoryTabObj.delivery_status = ""; 
     outBbmBloodBottleHistoryTabObj.patient_id = ""; 
     outBbmBloodBottleHistoryTabObj.receipt_num = ""; 
     outBbmBloodBottleHistoryTabObj.receipt_date = ""; 
  }





  public void guiDateConvBbmBloodBottleHistoryTabObj
               ( 
                 BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;
  }





  public void refreshCtxBbmBloodBottleHistoryByTabObj
               ( 
                 BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lBbmBloodBottleHistoryTabObjArrCtx  = new ArrayList(); 
    lBbmBloodBottleHistoryTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lBbmBloodBottleHistoryTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lBbmBloodBottleHistoryTabObjArrCtx.add(inBbmBloodBottleHistoryTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lBbmBloodBottleHistoryTabObjArrCtx.size();  lRecNum++ )
      {
        BbmBloodBottleHistoryTabObj lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj();
        lBbmBloodBottleHistoryTabObj = (BbmBloodBottleHistoryTabObj)lBbmBloodBottleHistoryTabObjArrCtx.get(lRecNum);
    
        if ( 
              lBbmBloodBottleHistoryTabObj.hospital_id.equals(lBbmBloodBottleHistoryTabObj.hospital_id) &&
              lBbmBloodBottleHistoryTabObj.branch_id.equals(lBbmBloodBottleHistoryTabObj.branch_id) &&
              lBbmBloodBottleHistoryTabObj.blood_bank_id.equals(lBbmBloodBottleHistoryTabObj.blood_bank_id) &&
              lBbmBloodBottleHistoryTabObj.bottle_id.equals(lBbmBloodBottleHistoryTabObj.bottle_id) &&
              lBbmBloodBottleHistoryTabObj.history_date.equals(lBbmBloodBottleHistoryTabObj.history_date) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lBbmBloodBottleHistoryTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lBbmBloodBottleHistoryTabObjArrCtx.set(lRecNum, inBbmBloodBottleHistoryTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lBbmBloodBottleHistoryTabObjArrCtx",lBbmBloodBottleHistoryTabObjArrCtx);
  }





  public void sortBbmBloodBottleHistoryTabObjArr
               ( 
                 ArrayList  inBbmBloodBottleHistoryTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lBbmBloodBottleHistoryTabObjArr  = new ArrayList(); 
     lBbmBloodBottleHistoryTabObjArr = inBbmBloodBottleHistoryTabObjArr; 
     List lBbmBloodBottleHistoryTabObjList  = new ArrayList(lBbmBloodBottleHistoryTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lBbmBloodBottleHistoryTabObjArr.size();  lRecNum++ )
     {
       BbmBloodBottleHistoryTabObj  lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj(); 
       lBbmBloodBottleHistoryTabObj = (BbmBloodBottleHistoryTabObj)lBbmBloodBottleHistoryTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("hospital_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.hospital_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.hospital_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("branch_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.branch_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.branch_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("blood_bank_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.blood_bank_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.blood_bank_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bottle_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (12 - lBbmBloodBottleHistoryTabObj.bottle_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.bottle_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("history_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lBbmBloodBottleHistoryTabObj.history_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.history_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("blood_group") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.blood_group.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.blood_group+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("blood_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.blood_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.blood_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (12 - Double.toString(lBbmBloodBottleHistoryTabObj.rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bottle_rack_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lBbmBloodBottleHistoryTabObj.bottle_rack_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.bottle_rack_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bottle_shelf_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lBbmBloodBottleHistoryTabObj.bottle_shelf_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.bottle_shelf_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("effective_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lBbmBloodBottleHistoryTabObj.effective_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.effective_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("expiration_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lBbmBloodBottleHistoryTabObj.expiration_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.expiration_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lBbmBloodBottleHistoryTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("blood_source") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lBbmBloodBottleHistoryTabObj.blood_source.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.blood_source+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("donor_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.donor_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.donor_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("delivery_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lBbmBloodBottleHistoryTabObj.delivery_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.delivery_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("patient_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.patient_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.patient_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("receipt_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lBbmBloodBottleHistoryTabObj.receipt_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.receipt_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("receipt_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lBbmBloodBottleHistoryTabObj.receipt_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lBbmBloodBottleHistoryTabObj.receipt_date+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lBbmBloodBottleHistoryTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lBbmBloodBottleHistoryTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lBbmBloodBottleHistoryTabObjList ); 
     ArrayList lBbmBloodBottleHistoryTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lBbmBloodBottleHistoryTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lBbmBloodBottleHistoryTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lBbmBloodBottleHistoryTabObjArrSorted.add( (BbmBloodBottleHistoryTabObj)lBbmBloodBottleHistoryTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lBbmBloodBottleHistoryTabObjArr.size();  lRecNum++ )
     {
       inBbmBloodBottleHistoryTabObjArr.set( lRecNum, (BbmBloodBottleHistoryTabObj)lBbmBloodBottleHistoryTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvBbmBloodBottleHistoryTabObj
               ( 
                 BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";
  }





  public void vldFieldDBSizeHospitalId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HOSPITAL_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBranchId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BRANCH_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBloodBankId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BLOOD_BANK_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBottleId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 12 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BOTTLE_ID";
      String lErrorReason = "Size Greater Than 12";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHistoryDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HISTORY_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBloodGroup
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BLOOD_GROUP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBloodType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BLOOD_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 12 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE";
      String lErrorReason = "Size Greater Than 12";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBottleRackNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BOTTLE_RACK_NUM";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBottleShelfNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BOTTLE_SHELF_NUM";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffectiveDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFFECTIVE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpirationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXPIRATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBloodSource
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BLOOD_SOURCE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDonorId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DONOR_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDeliveryStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DELIVERY_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePatientId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PATIENT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReceiptNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RECEIPT_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReceiptDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RECEIPT_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtBbmBloodBottleHistoryCount
               ( String inBbmBloodBottleHistoryWhereText
               )
  {
    sop("gtBbmBloodBottleHistoryCount - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryCount
               ( String inBbmBloodBottleHistoryWhereText
               , String inBbmBloodBottleHistorySelectFieldList
               )
  {
    sop("gtBbmBloodBottleHistoryCount - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inBbmBloodBottleHistorySelectFieldList+" AS count "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryRecByPkey
               ( BbmBloodBottleHistoryPkeyObj inBbmBloodBottleHistoryPkeyObj
               , BbmBloodBottleHistoryTabObj  outBbmBloodBottleHistoryTabObj
               )
  {
    sop("gtBbmBloodBottleHistoryRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "hospital_id, "+
                                 "branch_id, "+
                                 "blood_bank_id, "+
                                 "bottle_id, "+
                                 "history_date, "+
                                 "blood_group, "+
                                 "blood_type, "+
                                 "rate, "+
                                 "bottle_rack_num, "+
                                 "bottle_shelf_num, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "remark, "+
                                 "blood_source, "+
                                 "donor_id, "+
                                 "delivery_status, "+
                                 "patient_id, "+
                                 "receipt_num, "+
                                 "receipt_date "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY " + 
                         "WHERE "+
                              "hospital_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.hospital_id+"' and "+
                              "branch_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.branch_id+"' and "+
                              "blood_bank_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.blood_bank_id+"' and "+
                              "bottle_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.bottle_id+"' and "+
                              "history_date = "+"'"+inBbmBloodBottleHistoryPkeyObj.history_date+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outBbmBloodBottleHistoryTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outBbmBloodBottleHistoryTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          outBbmBloodBottleHistoryTabObj.branch_id  =  lResultSet.getString("BRANCH_ID");
          outBbmBloodBottleHistoryTabObj.blood_bank_id  =  lResultSet.getString("BLOOD_BANK_ID");
          outBbmBloodBottleHistoryTabObj.bottle_id  =  lResultSet.getString("BOTTLE_ID");
          outBbmBloodBottleHistoryTabObj.history_date  =  lResultSet.getString("HISTORY_DATE");
          outBbmBloodBottleHistoryTabObj.blood_group  =  lResultSet.getString("BLOOD_GROUP");
          outBbmBloodBottleHistoryTabObj.blood_type  =  lResultSet.getString("BLOOD_TYPE");
          outBbmBloodBottleHistoryTabObj.rate  =  lResultSet.getDouble("RATE");
          outBbmBloodBottleHistoryTabObj.bottle_rack_num  =  lResultSet.getInt("BOTTLE_RACK_NUM");
          outBbmBloodBottleHistoryTabObj.bottle_shelf_num  =  lResultSet.getInt("BOTTLE_SHELF_NUM");
          outBbmBloodBottleHistoryTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
          outBbmBloodBottleHistoryTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
          outBbmBloodBottleHistoryTabObj.remark  =  lResultSet.getString("REMARK");
          outBbmBloodBottleHistoryTabObj.blood_source  =  lResultSet.getString("BLOOD_SOURCE");
          outBbmBloodBottleHistoryTabObj.donor_id  =  lResultSet.getString("DONOR_ID");
          outBbmBloodBottleHistoryTabObj.delivery_status  =  lResultSet.getString("DELIVERY_STATUS");
          outBbmBloodBottleHistoryTabObj.patient_id  =  lResultSet.getString("PATIENT_ID");
          outBbmBloodBottleHistoryTabObj.receipt_num  =  lResultSet.getString("RECEIPT_NUM");
          outBbmBloodBottleHistoryTabObj.receipt_date  =  lResultSet.getString("RECEIPT_DATE");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullBbmBloodBottleHistoryTabObj( outBbmBloodBottleHistoryTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryArr
               ( BbmBloodBottleHistoryPkeyObj inBbmBloodBottleHistoryPkeyObj
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {
    sop("gtBbmBloodBottleHistoryArr - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "hospital_id, "+
                                 "branch_id, "+
                                 "blood_bank_id, "+
                                 "bottle_id, "+
                                 "history_date, "+
                                 "blood_group, "+
                                 "blood_type, "+
                                 "rate, "+
                                 "bottle_rack_num, "+
                                 "bottle_shelf_num, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "remark, "+
                                 "blood_source, "+
                                 "donor_id, "+
                                 "delivery_status, "+
                                 "patient_id, "+
                                 "receipt_num, "+
                                 "receipt_date "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          BbmBloodBottleHistoryTabObj  lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj();
          lBbmBloodBottleHistoryTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lBbmBloodBottleHistoryTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          lBbmBloodBottleHistoryTabObj.branch_id  =  lResultSet.getString("BRANCH_ID");
          lBbmBloodBottleHistoryTabObj.blood_bank_id  =  lResultSet.getString("BLOOD_BANK_ID");
          lBbmBloodBottleHistoryTabObj.bottle_id  =  lResultSet.getString("BOTTLE_ID");
          lBbmBloodBottleHistoryTabObj.history_date  =  lResultSet.getString("HISTORY_DATE");
          lBbmBloodBottleHistoryTabObj.blood_group  =  lResultSet.getString("BLOOD_GROUP");
          lBbmBloodBottleHistoryTabObj.blood_type  =  lResultSet.getString("BLOOD_TYPE");
          lBbmBloodBottleHistoryTabObj.rate  =  lResultSet.getDouble("RATE");
          lBbmBloodBottleHistoryTabObj.bottle_rack_num  =  lResultSet.getInt("BOTTLE_RACK_NUM");
          lBbmBloodBottleHistoryTabObj.bottle_shelf_num  =  lResultSet.getInt("BOTTLE_SHELF_NUM");
          lBbmBloodBottleHistoryTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
          lBbmBloodBottleHistoryTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
          lBbmBloodBottleHistoryTabObj.remark  =  lResultSet.getString("REMARK");
          lBbmBloodBottleHistoryTabObj.blood_source  =  lResultSet.getString("BLOOD_SOURCE");
          lBbmBloodBottleHistoryTabObj.donor_id  =  lResultSet.getString("DONOR_ID");
          lBbmBloodBottleHistoryTabObj.delivery_status  =  lResultSet.getString("DELIVERY_STATUS");
          lBbmBloodBottleHistoryTabObj.patient_id  =  lResultSet.getString("PATIENT_ID");
          lBbmBloodBottleHistoryTabObj.receipt_num  =  lResultSet.getString("RECEIPT_NUM");
          lBbmBloodBottleHistoryTabObj.receipt_date  =  lResultSet.getString("RECEIPT_DATE");

          removeNullBbmBloodBottleHistoryTabObj( lBbmBloodBottleHistoryTabObj );

          outBbmBloodBottleHistoryTabObjArr.add(  lBbmBloodBottleHistoryTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outBbmBloodBottleHistoryTabObjArr != null && outBbmBloodBottleHistoryTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtBbmBloodBottleHistoryArr2XML
               ( String inBbmBloodBottleHistoryWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtBbmBloodBottleHistoryArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<BbmBloodBottleHistory>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hospital_id") )
              lXmlBuffer = lXmlBuffer +   "<HOSPITAL_ID>" +  lResultSet.getString("HOSPITAL_ID") +   "</HOSPITAL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("branch_id") )
              lXmlBuffer = lXmlBuffer +   "<BRANCH_ID>" +  lResultSet.getString("BRANCH_ID") +   "</BRANCH_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("blood_bank_id") )
              lXmlBuffer = lXmlBuffer +   "<BLOOD_BANK_ID>" +  lResultSet.getString("BLOOD_BANK_ID") +   "</BLOOD_BANK_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bottle_id") )
              lXmlBuffer = lXmlBuffer +   "<BOTTLE_ID>" +  lResultSet.getString("BOTTLE_ID") +   "</BOTTLE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("history_date") )
              lXmlBuffer = lXmlBuffer +   "<HISTORY_DATE>" +  lResultSet.getString("HISTORY_DATE") +   "</HISTORY_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("blood_group") )
              lXmlBuffer = lXmlBuffer +   "<BLOOD_GROUP>" +  lResultSet.getString("BLOOD_GROUP") +   "</BLOOD_GROUP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("blood_type") )
              lXmlBuffer = lXmlBuffer +   "<BLOOD_TYPE>" +  lResultSet.getString("BLOOD_TYPE") +   "</BLOOD_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate") )
              lXmlBuffer = lXmlBuffer +   "<RATE>" +  lResultSet.getDouble("RATE") +   "</RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bottle_rack_num") )
              lXmlBuffer = lXmlBuffer +   "<BOTTLE_RACK_NUM>" +  lResultSet.getInt("BOTTLE_RACK_NUM") +   "</BOTTLE_RACK_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bottle_shelf_num") )
              lXmlBuffer = lXmlBuffer +   "<BOTTLE_SHELF_NUM>" +  lResultSet.getInt("BOTTLE_SHELF_NUM") +   "</BOTTLE_SHELF_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("effective_date") )
              lXmlBuffer = lXmlBuffer +   "<EFFECTIVE_DATE>" +  lResultSet.getString("EFFECTIVE_DATE") +   "</EFFECTIVE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("expiration_date") )
              lXmlBuffer = lXmlBuffer +   "<EXPIRATION_DATE>" +  lResultSet.getString("EXPIRATION_DATE") +   "</EXPIRATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("blood_source") )
              lXmlBuffer = lXmlBuffer +   "<BLOOD_SOURCE>" +  lResultSet.getString("BLOOD_SOURCE") +   "</BLOOD_SOURCE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("donor_id") )
              lXmlBuffer = lXmlBuffer +   "<DONOR_ID>" +  lResultSet.getString("DONOR_ID") +   "</DONOR_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("delivery_status") )
              lXmlBuffer = lXmlBuffer +   "<DELIVERY_STATUS>" +  lResultSet.getString("DELIVERY_STATUS") +   "</DELIVERY_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("patient_id") )
              lXmlBuffer = lXmlBuffer +   "<PATIENT_ID>" +  lResultSet.getString("PATIENT_ID") +   "</PATIENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("receipt_num") )
              lXmlBuffer = lXmlBuffer +   "<RECEIPT_NUM>" +  lResultSet.getString("RECEIPT_NUM") +   "</RECEIPT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("receipt_date") )
              lXmlBuffer = lXmlBuffer +   "<RECEIPT_DATE>" +  lResultSet.getString("RECEIPT_DATE") +   "</RECEIPT_DATE>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</BbmBloodBottleHistory>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtBbmBloodBottleHistoryRecByRowid
               ( String inRowId
               , BbmBloodBottleHistoryTabObj  outBbmBloodBottleHistoryTabObj
               )
  {
    sop("gtBbmBloodBottleHistoryRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "hospital_id, "+
                                 "branch_id, "+
                                 "blood_bank_id, "+
                                 "bottle_id, "+
                                 "history_date, "+
                                 "blood_group, "+
                                 "blood_type, "+
                                 "rate, "+
                                 "bottle_rack_num, "+
                                 "bottle_shelf_num, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "remark, "+
                                 "blood_source, "+
                                 "donor_id, "+
                                 "delivery_status, "+
                                 "patient_id, "+
                                 "receipt_num, "+
                                 "receipt_date "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outBbmBloodBottleHistoryTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outBbmBloodBottleHistoryTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          outBbmBloodBottleHistoryTabObj.branch_id  =  lResultSet.getString("BRANCH_ID");
          outBbmBloodBottleHistoryTabObj.blood_bank_id  =  lResultSet.getString("BLOOD_BANK_ID");
          outBbmBloodBottleHistoryTabObj.bottle_id  =  lResultSet.getString("BOTTLE_ID");
          outBbmBloodBottleHistoryTabObj.history_date  =  lResultSet.getString("HISTORY_DATE");
          outBbmBloodBottleHistoryTabObj.blood_group  =  lResultSet.getString("BLOOD_GROUP");
          outBbmBloodBottleHistoryTabObj.blood_type  =  lResultSet.getString("BLOOD_TYPE");
          outBbmBloodBottleHistoryTabObj.rate  =  lResultSet.getDouble("RATE");
          outBbmBloodBottleHistoryTabObj.bottle_rack_num  =  lResultSet.getInt("BOTTLE_RACK_NUM");
          outBbmBloodBottleHistoryTabObj.bottle_shelf_num  =  lResultSet.getInt("BOTTLE_SHELF_NUM");
          outBbmBloodBottleHistoryTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
          outBbmBloodBottleHistoryTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
          outBbmBloodBottleHistoryTabObj.remark  =  lResultSet.getString("REMARK");
          outBbmBloodBottleHistoryTabObj.blood_source  =  lResultSet.getString("BLOOD_SOURCE");
          outBbmBloodBottleHistoryTabObj.donor_id  =  lResultSet.getString("DONOR_ID");
          outBbmBloodBottleHistoryTabObj.delivery_status  =  lResultSet.getString("DELIVERY_STATUS");
          outBbmBloodBottleHistoryTabObj.patient_id  =  lResultSet.getString("PATIENT_ID");
          outBbmBloodBottleHistoryTabObj.receipt_num  =  lResultSet.getString("RECEIPT_NUM");
          outBbmBloodBottleHistoryTabObj.receipt_date  =  lResultSet.getString("RECEIPT_DATE");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullBbmBloodBottleHistoryTabObj( outBbmBloodBottleHistoryTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryArr
               ( String inBbmBloodBottleHistoryWhereText
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {
    sop("gtBbmBloodBottleHistoryArr - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "hospital_id, "+
                                 "branch_id, "+
                                 "blood_bank_id, "+
                                 "bottle_id, "+
                                 "history_date, "+
                                 "blood_group, "+
                                 "blood_type, "+
                                 "rate, "+
                                 "bottle_rack_num, "+
                                 "bottle_shelf_num, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "remark, "+
                                 "blood_source, "+
                                 "donor_id, "+
                                 "delivery_status, "+
                                 "patient_id, "+
                                 "receipt_num, "+
                                 "receipt_date "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          BbmBloodBottleHistoryTabObj  lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj();
          lBbmBloodBottleHistoryTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lBbmBloodBottleHistoryTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          lBbmBloodBottleHistoryTabObj.branch_id  =  lResultSet.getString("BRANCH_ID");
          lBbmBloodBottleHistoryTabObj.blood_bank_id  =  lResultSet.getString("BLOOD_BANK_ID");
          lBbmBloodBottleHistoryTabObj.bottle_id  =  lResultSet.getString("BOTTLE_ID");
          lBbmBloodBottleHistoryTabObj.history_date  =  lResultSet.getString("HISTORY_DATE");
          lBbmBloodBottleHistoryTabObj.blood_group  =  lResultSet.getString("BLOOD_GROUP");
          lBbmBloodBottleHistoryTabObj.blood_type  =  lResultSet.getString("BLOOD_TYPE");
          lBbmBloodBottleHistoryTabObj.rate  =  lResultSet.getDouble("RATE");
          lBbmBloodBottleHistoryTabObj.bottle_rack_num  =  lResultSet.getInt("BOTTLE_RACK_NUM");
          lBbmBloodBottleHistoryTabObj.bottle_shelf_num  =  lResultSet.getInt("BOTTLE_SHELF_NUM");
          lBbmBloodBottleHistoryTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
          lBbmBloodBottleHistoryTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
          lBbmBloodBottleHistoryTabObj.remark  =  lResultSet.getString("REMARK");
          lBbmBloodBottleHistoryTabObj.blood_source  =  lResultSet.getString("BLOOD_SOURCE");
          lBbmBloodBottleHistoryTabObj.donor_id  =  lResultSet.getString("DONOR_ID");
          lBbmBloodBottleHistoryTabObj.delivery_status  =  lResultSet.getString("DELIVERY_STATUS");
          lBbmBloodBottleHistoryTabObj.patient_id  =  lResultSet.getString("PATIENT_ID");
          lBbmBloodBottleHistoryTabObj.receipt_num  =  lResultSet.getString("RECEIPT_NUM");
          lBbmBloodBottleHistoryTabObj.receipt_date  =  lResultSet.getString("RECEIPT_DATE");

          removeNullBbmBloodBottleHistoryTabObj( lBbmBloodBottleHistoryTabObj );

          outBbmBloodBottleHistoryTabObjArr.add(  lBbmBloodBottleHistoryTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outBbmBloodBottleHistoryTabObjArr != null && outBbmBloodBottleHistoryTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryArrDist
               ( String inBbmBloodBottleHistoryWhereText
               , String inDistBbmBloodBottleHistoryField
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {

    sop("gtBbmBloodBottleHistoryArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";
  

       String lDistBbmBloodBottleHistoryFieldQry = inDistBbmBloodBottleHistoryField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistBbmBloodBottleHistoryFieldQry+
                         " FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistBbmBloodBottleHistoryField.substring(inDistBbmBloodBottleHistoryField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          BbmBloodBottleHistoryTabObj  lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hospital_id") )
              lBbmBloodBottleHistoryTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("branch_id") )
              lBbmBloodBottleHistoryTabObj.branch_id  =  lResultSet.getString("BRANCH_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("blood_bank_id") )
              lBbmBloodBottleHistoryTabObj.blood_bank_id  =  lResultSet.getString("BLOOD_BANK_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bottle_id") )
              lBbmBloodBottleHistoryTabObj.bottle_id  =  lResultSet.getString("BOTTLE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("history_date") )
              lBbmBloodBottleHistoryTabObj.history_date  =  lResultSet.getString("HISTORY_DATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("blood_group") )
              lBbmBloodBottleHistoryTabObj.blood_group  =  lResultSet.getString("BLOOD_GROUP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("blood_type") )
              lBbmBloodBottleHistoryTabObj.blood_type  =  lResultSet.getString("BLOOD_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate") )
              lBbmBloodBottleHistoryTabObj.rate  =  lResultSet.getDouble("RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bottle_rack_num") )
              lBbmBloodBottleHistoryTabObj.bottle_rack_num  =  lResultSet.getInt("BOTTLE_RACK_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bottle_shelf_num") )
              lBbmBloodBottleHistoryTabObj.bottle_shelf_num  =  lResultSet.getInt("BOTTLE_SHELF_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("effective_date") )
              lBbmBloodBottleHistoryTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("expiration_date") )
              lBbmBloodBottleHistoryTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lBbmBloodBottleHistoryTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("blood_source") )
              lBbmBloodBottleHistoryTabObj.blood_source  =  lResultSet.getString("BLOOD_SOURCE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("donor_id") )
              lBbmBloodBottleHistoryTabObj.donor_id  =  lResultSet.getString("DONOR_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("delivery_status") )
              lBbmBloodBottleHistoryTabObj.delivery_status  =  lResultSet.getString("DELIVERY_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("patient_id") )
              lBbmBloodBottleHistoryTabObj.patient_id  =  lResultSet.getString("PATIENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("receipt_num") )
              lBbmBloodBottleHistoryTabObj.receipt_num  =  lResultSet.getString("RECEIPT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("receipt_date") )
              lBbmBloodBottleHistoryTabObj.receipt_date  =  lResultSet.getString("RECEIPT_DATE");

          }
          removeNullBbmBloodBottleHistoryTabObj( lBbmBloodBottleHistoryTabObj );

          outBbmBloodBottleHistoryTabObjArr.add(  lBbmBloodBottleHistoryTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outBbmBloodBottleHistoryTabObjArr != null && outBbmBloodBottleHistoryTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtBbmBloodBottleHistoryStrArrDist
               ( String inBbmBloodBottleHistoryWhereText
               , String inDistBbmBloodBottleHistoryField
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {

    sop("gtBbmBloodBottleHistoryStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtBbmBloodBottleHistoryStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";
  

       String lDistBbmBloodBottleHistoryFieldQry = inDistBbmBloodBottleHistoryField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistBbmBloodBottleHistoryFieldQry+
                         " FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistBbmBloodBottleHistoryField.substring(inDistBbmBloodBottleHistoryField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lBbmBloodBottleHistoryTabObjStr = "";
       while(lResultSet.next())
       {
          lBbmBloodBottleHistoryTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lBbmBloodBottleHistoryTabObjStr =   lBbmBloodBottleHistoryTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outBbmBloodBottleHistoryTabObjArr.add(  lBbmBloodBottleHistoryTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outBbmBloodBottleHistoryTabObjArr != null && outBbmBloodBottleHistoryTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValBbmBloodBottleHistory
               ( String inBbmBloodBottleHistoryWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValBbmBloodBottleHistory - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValBbmBloodBottleHistory";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullBbmBloodBottleHistoryTabObj
               ( 
                 BbmBloodBottleHistoryTabObj  outBbmBloodBottleHistoryTabObj
               )
  {
  
    if ( outBbmBloodBottleHistoryTabObj.hospital_id == null ) 
     outBbmBloodBottleHistoryTabObj.hospital_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.branch_id == null ) 
     outBbmBloodBottleHistoryTabObj.branch_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.blood_bank_id == null ) 
     outBbmBloodBottleHistoryTabObj.blood_bank_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.bottle_id == null ) 
     outBbmBloodBottleHistoryTabObj.bottle_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.history_date == null ) 
     outBbmBloodBottleHistoryTabObj.history_date = ""; 
    if ( outBbmBloodBottleHistoryTabObj.blood_group == null ) 
     outBbmBloodBottleHistoryTabObj.blood_group = ""; 
    if ( outBbmBloodBottleHistoryTabObj.blood_type == null ) 
     outBbmBloodBottleHistoryTabObj.blood_type = ""; 
    if ( outBbmBloodBottleHistoryTabObj.rate == (double)0.00 ) 
     outBbmBloodBottleHistoryTabObj.rate = (double)0.00; 
    if ( outBbmBloodBottleHistoryTabObj.bottle_rack_num == (int)0 ) 
     outBbmBloodBottleHistoryTabObj.bottle_rack_num = (int)0; 
    if ( outBbmBloodBottleHistoryTabObj.bottle_shelf_num == (int)0 ) 
     outBbmBloodBottleHistoryTabObj.bottle_shelf_num = (int)0; 
    if ( outBbmBloodBottleHistoryTabObj.effective_date == null ) 
     outBbmBloodBottleHistoryTabObj.effective_date = ""; 
    if ( outBbmBloodBottleHistoryTabObj.expiration_date == null ) 
     outBbmBloodBottleHistoryTabObj.expiration_date = ""; 
    if ( outBbmBloodBottleHistoryTabObj.remark == null ) 
     outBbmBloodBottleHistoryTabObj.remark = ""; 
    if ( outBbmBloodBottleHistoryTabObj.blood_source == null ) 
     outBbmBloodBottleHistoryTabObj.blood_source = ""; 
    if ( outBbmBloodBottleHistoryTabObj.donor_id == null ) 
     outBbmBloodBottleHistoryTabObj.donor_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.delivery_status == null ) 
     outBbmBloodBottleHistoryTabObj.delivery_status = ""; 
    if ( outBbmBloodBottleHistoryTabObj.patient_id == null ) 
     outBbmBloodBottleHistoryTabObj.patient_id = ""; 
    if ( outBbmBloodBottleHistoryTabObj.receipt_num == null ) 
     outBbmBloodBottleHistoryTabObj.receipt_num = ""; 
    if ( outBbmBloodBottleHistoryTabObj.receipt_date == null ) 
     outBbmBloodBottleHistoryTabObj.receipt_date = ""; 
  }





  public int insBbmBloodBottleHistoryRec
               ( BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj )
  {
    int lUpdateCount;
    sop("insBbmBloodBottleHistoryRec - Started");
    gSSTErrorObj.sourceMethod = "insBbmBloodBottleHistoryRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



          String lSqlStmt = "INSERT INTO BBM_BLOOD_BOTTLE_HISTORY"+
                        "("+
                                "hospital_id,"+
                                "branch_id,"+
                                "blood_bank_id,"+
                                "bottle_id,"+
                                "history_date,"+
                                "blood_group,"+
                                "blood_type,"+
                                "rate,"+
                                "bottle_rack_num,"+
                                "bottle_shelf_num,"+
                                "effective_date,"+
                                "expiration_date,"+
                                "remark,"+
                                "blood_source,"+
                                "donor_id,"+
                                "delivery_status,"+
                                "patient_id,"+
                                "receipt_num,"+
                                "receipt_date"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.hospital_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.branch_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.blood_bank_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.bottle_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.history_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.blood_group+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.blood_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inBbmBloodBottleHistoryTabObj.rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inBbmBloodBottleHistoryTabObj.bottle_rack_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inBbmBloodBottleHistoryTabObj.bottle_shelf_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.effective_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.expiration_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.blood_source+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.donor_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.delivery_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.patient_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.receipt_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inBbmBloodBottleHistoryTabObj.receipt_date+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inBbmBloodBottleHistoryTabObj.hospital_id);
        lPreparedStatement.setString(2, inBbmBloodBottleHistoryTabObj.branch_id);
        lPreparedStatement.setString(3, inBbmBloodBottleHistoryTabObj.blood_bank_id);
        lPreparedStatement.setString(4, inBbmBloodBottleHistoryTabObj.bottle_id);
        lPreparedStatement.setString(5, inBbmBloodBottleHistoryTabObj.history_date);
        lPreparedStatement.setString(6, inBbmBloodBottleHistoryTabObj.blood_group);
        lPreparedStatement.setString(7, inBbmBloodBottleHistoryTabObj.blood_type);
          lPreparedStatement.setDouble(8, inBbmBloodBottleHistoryTabObj.rate);
          lPreparedStatement.setInt(9, inBbmBloodBottleHistoryTabObj.bottle_rack_num);
          lPreparedStatement.setInt(10, inBbmBloodBottleHistoryTabObj.bottle_shelf_num);
        lPreparedStatement.setString(11, inBbmBloodBottleHistoryTabObj.effective_date);
        lPreparedStatement.setString(12, inBbmBloodBottleHistoryTabObj.expiration_date);
        lPreparedStatement.setString(13, inBbmBloodBottleHistoryTabObj.remark);
        lPreparedStatement.setString(14, inBbmBloodBottleHistoryTabObj.blood_source);
        lPreparedStatement.setString(15, inBbmBloodBottleHistoryTabObj.donor_id);
        lPreparedStatement.setString(16, inBbmBloodBottleHistoryTabObj.delivery_status);
        lPreparedStatement.setString(17, inBbmBloodBottleHistoryTabObj.patient_id);
        lPreparedStatement.setString(18, inBbmBloodBottleHistoryTabObj.receipt_num);
        lPreparedStatement.setString(19, inBbmBloodBottleHistoryTabObj.receipt_date);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insBbmBloodBottleHistoryArr
               ( ArrayList  inBbmBloodBottleHistoryTabObjArr 
               , String  inRowidFlag )
  {
    BbmBloodBottleHistoryTabObj  lBbmBloodBottleHistoryTabObj = new BbmBloodBottleHistoryTabObj();
    int lUpdateCount;
    sop("insBbmBloodBottleHistoryArr - Started");
    gSSTErrorObj.sourceMethod = "insBbmBloodBottleHistoryArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inBbmBloodBottleHistoryTabObjArr.size(); lNumRec++ )
      {
        lBbmBloodBottleHistoryTabObj = (BbmBloodBottleHistoryTabObj)inBbmBloodBottleHistoryTabObjArr.get(lNumRec);
          String lSqlStmt = "INSERT INTO BBM_BLOOD_BOTTLE_HISTORY"+
                        "("+
                        "hospital_id,"+
                        "branch_id,"+
                        "blood_bank_id,"+
                        "bottle_id,"+
                        "history_date,"+
                        "blood_group,"+
                        "blood_type,"+
                        "rate,"+
                        "bottle_rack_num,"+
                        "bottle_shelf_num,"+
                        "effective_date,"+
                        "expiration_date,"+
                        "remark,"+
                        "blood_source,"+
                        "donor_id,"+
                        "delivery_status,"+
                        "patient_id,"+
                        "receipt_num,"+
                        "receipt_date"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.hospital_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.branch_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.blood_bank_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.bottle_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.history_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.blood_group+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.blood_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lBbmBloodBottleHistoryTabObj.rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lBbmBloodBottleHistoryTabObj.bottle_rack_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lBbmBloodBottleHistoryTabObj.bottle_shelf_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.effective_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.expiration_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.blood_source+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.donor_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.delivery_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.patient_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.receipt_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lBbmBloodBottleHistoryTabObj.receipt_date+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lBbmBloodBottleHistoryTabObj.hospital_id);
            lPreparedStatement.setString(2, lBbmBloodBottleHistoryTabObj.branch_id);
            lPreparedStatement.setString(3, lBbmBloodBottleHistoryTabObj.blood_bank_id);
            lPreparedStatement.setString(4, lBbmBloodBottleHistoryTabObj.bottle_id);
            lPreparedStatement.setString(5, lBbmBloodBottleHistoryTabObj.history_date);
            lPreparedStatement.setString(6, lBbmBloodBottleHistoryTabObj.blood_group);
            lPreparedStatement.setString(7, lBbmBloodBottleHistoryTabObj.blood_type);
              lPreparedStatement.setDouble(8, lBbmBloodBottleHistoryTabObj.rate);
              lPreparedStatement.setInt(9, lBbmBloodBottleHistoryTabObj.bottle_rack_num);
              lPreparedStatement.setInt(10, lBbmBloodBottleHistoryTabObj.bottle_shelf_num);
            lPreparedStatement.setString(11, lBbmBloodBottleHistoryTabObj.effective_date);
            lPreparedStatement.setString(12, lBbmBloodBottleHistoryTabObj.expiration_date);
            lPreparedStatement.setString(13, lBbmBloodBottleHistoryTabObj.remark);
            lPreparedStatement.setString(14, lBbmBloodBottleHistoryTabObj.blood_source);
            lPreparedStatement.setString(15, lBbmBloodBottleHistoryTabObj.donor_id);
            lPreparedStatement.setString(16, lBbmBloodBottleHistoryTabObj.delivery_status);
            lPreparedStatement.setString(17, lBbmBloodBottleHistoryTabObj.patient_id);
            lPreparedStatement.setString(18, lBbmBloodBottleHistoryTabObj.receipt_num);
            lPreparedStatement.setString(19, lBbmBloodBottleHistoryTabObj.receipt_date);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popBbmBloodBottleHistoryReq2Obj
               ( HttpServletRequest inRequest
               , BbmBloodBottleHistoryTabObj  outBbmBloodBottleHistoryTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outBbmBloodBottleHistoryTabObj.tab_rowid = lTabRowidValue;

    outBbmBloodBottleHistoryTabObj.hospital_id = inRequest.getParameter("hospital_id");
    outBbmBloodBottleHistoryTabObj.branch_id = inRequest.getParameter("branch_id");
    outBbmBloodBottleHistoryTabObj.blood_bank_id = inRequest.getParameter("blood_bank_id");
    outBbmBloodBottleHistoryTabObj.bottle_id = inRequest.getParameter("bottle_id");
    outBbmBloodBottleHistoryTabObj.history_date = inRequest.getParameter("history_date");
    outBbmBloodBottleHistoryTabObj.blood_group = inRequest.getParameter("blood_group");
    outBbmBloodBottleHistoryTabObj.blood_type = inRequest.getParameter("blood_type");
    if ( inRequest.getParameter("rate") == null )
      outBbmBloodBottleHistoryTabObj.rate = 0;
    else
    if ( inRequest.getParameter("rate").trim().length() == 0 )
      outBbmBloodBottleHistoryTabObj.rate = 0;
    else
      outBbmBloodBottleHistoryTabObj.rate = Double.parseDouble( inRequest.getParameter("rate"));
    if ( inRequest.getParameter("bottle_rack_num") == null )
      outBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
    else
    if ( inRequest.getParameter("bottle_rack_num").trim().length() == 0 )
      outBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
    else
      outBbmBloodBottleHistoryTabObj.bottle_rack_num = Integer.parseInt( inRequest.getParameter("bottle_rack_num"));
    if ( inRequest.getParameter("bottle_shelf_num") == null )
      outBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
    else
    if ( inRequest.getParameter("bottle_shelf_num").trim().length() == 0 )
      outBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
    else
      outBbmBloodBottleHistoryTabObj.bottle_shelf_num = Integer.parseInt( inRequest.getParameter("bottle_shelf_num"));
    outBbmBloodBottleHistoryTabObj.effective_date = inRequest.getParameter("effective_date");
    outBbmBloodBottleHistoryTabObj.expiration_date = inRequest.getParameter("expiration_date");
    outBbmBloodBottleHistoryTabObj.remark = inRequest.getParameter("remark");
    outBbmBloodBottleHistoryTabObj.blood_source = inRequest.getParameter("blood_source");
    outBbmBloodBottleHistoryTabObj.donor_id = inRequest.getParameter("donor_id");
    outBbmBloodBottleHistoryTabObj.delivery_status = inRequest.getParameter("delivery_status");
    outBbmBloodBottleHistoryTabObj.patient_id = inRequest.getParameter("patient_id");
    outBbmBloodBottleHistoryTabObj.receipt_num = inRequest.getParameter("receipt_num");
    outBbmBloodBottleHistoryTabObj.receipt_date = inRequest.getParameter("receipt_date");
    return lReturnValue;
  }


  public int popBbmBloodBottleHistoryReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      BbmBloodBottleHistoryTabObj lBbmBloodBottleHistoryTabObj= new BbmBloodBottleHistoryTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.tab_rowid = lTabRowidValue;

      lBbmBloodBottleHistoryTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.branch_id = inRequest.getParameter("branch_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.blood_bank_id = inRequest.getParameter("blood_bank_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.bottle_id = inRequest.getParameter("bottle_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.history_date = inRequest.getParameter("history_date_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.blood_group = inRequest.getParameter("blood_group_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.blood_type = inRequest.getParameter("blood_type_r"+lNumRec);
      if ( inRequest.getParameter("rate_r"+lNumRec) == null )
        lBbmBloodBottleHistoryTabObj.rate = 0;
      else
      if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
        lBbmBloodBottleHistoryTabObj.rate = 0;
      else
        lBbmBloodBottleHistoryTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
      if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec) == null )
        lBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
      else
      if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec).trim().length() == 0 )
        lBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
      else
        lBbmBloodBottleHistoryTabObj.bottle_rack_num = Integer.parseInt( inRequest.getParameter("bottle_rack_num_r"+lNumRec));
      if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec) == null )
        lBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
      else
      if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec).trim().length() == 0 )
        lBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
      else
        lBbmBloodBottleHistoryTabObj.bottle_shelf_num = Integer.parseInt( inRequest.getParameter("bottle_shelf_num_r"+lNumRec));
      lBbmBloodBottleHistoryTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.blood_source = inRequest.getParameter("blood_source_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.donor_id = inRequest.getParameter("donor_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.delivery_status = inRequest.getParameter("delivery_status_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.patient_id = inRequest.getParameter("patient_id_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.receipt_num = inRequest.getParameter("receipt_num_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.receipt_date = inRequest.getParameter("receipt_date_r"+lNumRec);
      outBbmBloodBottleHistoryTabObjArr.add( lBbmBloodBottleHistoryTabObj);
    }
    return lReturnValue;
  }


  public int popBbmBloodBottleHistoryReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , BbmBloodBottleHistoryTabObj outBbmBloodBottleHistoryTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("bbm_blood_bottle_history_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.tab_rowid = lTabRowidValue;

        outBbmBloodBottleHistoryTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.branch_id = inRequest.getParameter("branch_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.blood_bank_id = inRequest.getParameter("blood_bank_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.bottle_id = inRequest.getParameter("bottle_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.history_date = inRequest.getParameter("history_date_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.blood_group = inRequest.getParameter("blood_group_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.blood_type = inRequest.getParameter("blood_type_r"+lNumRec);
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          outBbmBloodBottleHistoryTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          outBbmBloodBottleHistoryTabObj.rate = 0;
        else
          outBbmBloodBottleHistoryTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec) == null )
          outBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
        else
        if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec).trim().length() == 0 )
          outBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
        else
          outBbmBloodBottleHistoryTabObj.bottle_rack_num = Integer.parseInt( inRequest.getParameter("bottle_rack_num_r"+lNumRec));
        if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec) == null )
          outBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
        else
        if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec).trim().length() == 0 )
          outBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
        else
          outBbmBloodBottleHistoryTabObj.bottle_shelf_num = Integer.parseInt( inRequest.getParameter("bottle_shelf_num_r"+lNumRec));
        outBbmBloodBottleHistoryTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.blood_source = inRequest.getParameter("blood_source_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.donor_id = inRequest.getParameter("donor_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.delivery_status = inRequest.getParameter("delivery_status_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.patient_id = inRequest.getParameter("patient_id_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.receipt_num = inRequest.getParameter("receipt_num_r"+lNumRec);
        outBbmBloodBottleHistoryTabObj.receipt_date = inRequest.getParameter("receipt_date_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popBbmBloodBottleHistoryReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outBbmBloodBottleHistoryTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      BbmBloodBottleHistoryTabObj lBbmBloodBottleHistoryTabObj= new BbmBloodBottleHistoryTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("bbm_blood_bottle_history_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lBbmBloodBottleHistoryTabObj.tab_rowid = lTabRowidValue;

        lBbmBloodBottleHistoryTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.branch_id = inRequest.getParameter("branch_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.blood_bank_id = inRequest.getParameter("blood_bank_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.bottle_id = inRequest.getParameter("bottle_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.history_date = inRequest.getParameter("history_date_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.blood_group = inRequest.getParameter("blood_group_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.blood_type = inRequest.getParameter("blood_type_r"+lNumRec);
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          lBbmBloodBottleHistoryTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          lBbmBloodBottleHistoryTabObj.rate = 0;
        else
            lBbmBloodBottleHistoryTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec) == null )
          lBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
        else
        if ( inRequest.getParameter("bottle_rack_num_r"+lNumRec).trim().length() == 0 )
          lBbmBloodBottleHistoryTabObj.bottle_rack_num = 0;
        else
          lBbmBloodBottleHistoryTabObj.bottle_rack_num = Integer.parseInt( inRequest.getParameter("bottle_rack_num_r"+lNumRec));
        if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec) == null )
          lBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
        else
        if ( inRequest.getParameter("bottle_shelf_num_r"+lNumRec).trim().length() == 0 )
          lBbmBloodBottleHistoryTabObj.bottle_shelf_num = 0;
        else
          lBbmBloodBottleHistoryTabObj.bottle_shelf_num = Integer.parseInt( inRequest.getParameter("bottle_shelf_num_r"+lNumRec));
        lBbmBloodBottleHistoryTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.blood_source = inRequest.getParameter("blood_source_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.donor_id = inRequest.getParameter("donor_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.delivery_status = inRequest.getParameter("delivery_status_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.patient_id = inRequest.getParameter("patient_id_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.receipt_num = inRequest.getParameter("receipt_num_r"+lNumRec);
        lBbmBloodBottleHistoryTabObj.receipt_date = inRequest.getParameter("receipt_date_r"+lNumRec);
        outBbmBloodBottleHistoryTabObjArr.add( lBbmBloodBottleHistoryTabObj);
      }
    }
    return lReturnValue;
  }





  public int updBbmBloodBottleHistoryRecByRowid
               ( String inRowId
               , BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj
               )
  {
    int lUpdateCount;
    sop("updBbmBloodBottleHistoryRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updBbmBloodBottleHistoryRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE BBM_BLOOD_BOTTLE_HISTORY ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inBbmBloodBottleHistoryTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = "+"'"+inBbmBloodBottleHistoryTabObj.hospital_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.branch_id != null  )         lSqlStmt = lSqlStmt + "branch_id = "+"'"+inBbmBloodBottleHistoryTabObj.branch_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.blood_bank_id != null  )         lSqlStmt = lSqlStmt + "blood_bank_id = "+"'"+inBbmBloodBottleHistoryTabObj.blood_bank_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.bottle_id != null  )         lSqlStmt = lSqlStmt + "bottle_id = "+"'"+inBbmBloodBottleHistoryTabObj.bottle_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.history_date != null  )         lSqlStmt = lSqlStmt + "history_date = "+"'"+inBbmBloodBottleHistoryTabObj.history_date+"', ";
      if ( inBbmBloodBottleHistoryTabObj.blood_group != null  )         lSqlStmt = lSqlStmt + "blood_group = "+"'"+inBbmBloodBottleHistoryTabObj.blood_group+"', ";
      if ( inBbmBloodBottleHistoryTabObj.blood_type != null  )         lSqlStmt = lSqlStmt + "blood_type = "+"'"+inBbmBloodBottleHistoryTabObj.blood_type+"', ";
             lSqlStmt = lSqlStmt + "rate = "+inBbmBloodBottleHistoryTabObj.rate+", ";
             lSqlStmt = lSqlStmt + "bottle_rack_num = "+inBbmBloodBottleHistoryTabObj.bottle_rack_num+", ";
             lSqlStmt = lSqlStmt + "bottle_shelf_num = "+inBbmBloodBottleHistoryTabObj.bottle_shelf_num+", ";
      if ( inBbmBloodBottleHistoryTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inBbmBloodBottleHistoryTabObj.effective_date+"', ";
      if ( inBbmBloodBottleHistoryTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inBbmBloodBottleHistoryTabObj.expiration_date+"', ";
      if ( inBbmBloodBottleHistoryTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inBbmBloodBottleHistoryTabObj.remark+"', ";
      if ( inBbmBloodBottleHistoryTabObj.blood_source != null  )         lSqlStmt = lSqlStmt + "blood_source = "+"'"+inBbmBloodBottleHistoryTabObj.blood_source+"', ";
      if ( inBbmBloodBottleHistoryTabObj.donor_id != null  )         lSqlStmt = lSqlStmt + "donor_id = "+"'"+inBbmBloodBottleHistoryTabObj.donor_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.delivery_status != null  )         lSqlStmt = lSqlStmt + "delivery_status = "+"'"+inBbmBloodBottleHistoryTabObj.delivery_status+"', ";
      if ( inBbmBloodBottleHistoryTabObj.patient_id != null  )         lSqlStmt = lSqlStmt + "patient_id = "+"'"+inBbmBloodBottleHistoryTabObj.patient_id+"', ";
      if ( inBbmBloodBottleHistoryTabObj.receipt_num != null  )         lSqlStmt = lSqlStmt + "receipt_num = "+"'"+inBbmBloodBottleHistoryTabObj.receipt_num+"', ";
      if ( inBbmBloodBottleHistoryTabObj.receipt_date != null  )         lSqlStmt = lSqlStmt + "receipt_date = "+"'"+inBbmBloodBottleHistoryTabObj.receipt_date+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updBbmBloodBottleHistoryRecByPkey
               ( BbmBloodBottleHistoryPkeyObj inBbmBloodBottleHistoryPkeyObj
               , BbmBloodBottleHistoryTabObj  inBbmBloodBottleHistoryTabObj
               )
  {
    int lUpdateCount;
    sop("updBbmBloodBottleHistoryRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updBbmBloodBottleHistoryRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE BBM_BLOOD_BOTTLE_HISTORY ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inBbmBloodBottleHistoryTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.branch_id != null  )         lSqlStmt = lSqlStmt + "branch_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.blood_bank_id != null  )         lSqlStmt = lSqlStmt + "blood_bank_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.bottle_id != null  )         lSqlStmt = lSqlStmt + "bottle_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.history_date != null  )         lSqlStmt = lSqlStmt + "history_date = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.blood_group != null  )         lSqlStmt = lSqlStmt + "blood_group = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.blood_type != null  )         lSqlStmt = lSqlStmt + "blood_type = ? , ";
               lSqlStmt = lSqlStmt + "rate = ? , ";
               lSqlStmt = lSqlStmt + "bottle_rack_num = ? , ";
               lSqlStmt = lSqlStmt + "bottle_shelf_num = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.blood_source != null  )         lSqlStmt = lSqlStmt + "blood_source = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.donor_id != null  )         lSqlStmt = lSqlStmt + "donor_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.delivery_status != null  )         lSqlStmt = lSqlStmt + "delivery_status = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.patient_id != null  )         lSqlStmt = lSqlStmt + "patient_id = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.receipt_num != null  )         lSqlStmt = lSqlStmt + "receipt_num = ? , ";
        if ( inBbmBloodBottleHistoryTabObj.receipt_date != null  )         lSqlStmt = lSqlStmt + "receipt_date = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inBbmBloodBottleHistoryTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = "+"'"+inBbmBloodBottleHistoryTabObj.hospital_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.branch_id != null  )         lSqlStmt = lSqlStmt + "branch_id = "+"'"+inBbmBloodBottleHistoryTabObj.branch_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.blood_bank_id != null  )         lSqlStmt = lSqlStmt + "blood_bank_id = "+"'"+inBbmBloodBottleHistoryTabObj.blood_bank_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.bottle_id != null  )         lSqlStmt = lSqlStmt + "bottle_id = "+"'"+inBbmBloodBottleHistoryTabObj.bottle_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.history_date != null  )         lSqlStmt = lSqlStmt + "history_date = "+"'"+inBbmBloodBottleHistoryTabObj.history_date+"', ";
        if ( inBbmBloodBottleHistoryTabObj.blood_group != null  )         lSqlStmt = lSqlStmt + "blood_group = "+"'"+inBbmBloodBottleHistoryTabObj.blood_group+"', ";
        if ( inBbmBloodBottleHistoryTabObj.blood_type != null  )         lSqlStmt = lSqlStmt + "blood_type = "+"'"+inBbmBloodBottleHistoryTabObj.blood_type+"', ";
               lSqlStmt = lSqlStmt + "rate = "+inBbmBloodBottleHistoryTabObj.rate+", ";
               lSqlStmt = lSqlStmt + "bottle_rack_num = "+inBbmBloodBottleHistoryTabObj.bottle_rack_num+", ";
               lSqlStmt = lSqlStmt + "bottle_shelf_num = "+inBbmBloodBottleHistoryTabObj.bottle_shelf_num+", ";
        if ( inBbmBloodBottleHistoryTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inBbmBloodBottleHistoryTabObj.effective_date+"', ";
        if ( inBbmBloodBottleHistoryTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inBbmBloodBottleHistoryTabObj.expiration_date+"', ";
        if ( inBbmBloodBottleHistoryTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inBbmBloodBottleHistoryTabObj.remark+"', ";
        if ( inBbmBloodBottleHistoryTabObj.blood_source != null  )         lSqlStmt = lSqlStmt + "blood_source = "+"'"+inBbmBloodBottleHistoryTabObj.blood_source+"', ";
        if ( inBbmBloodBottleHistoryTabObj.donor_id != null  )         lSqlStmt = lSqlStmt + "donor_id = "+"'"+inBbmBloodBottleHistoryTabObj.donor_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.delivery_status != null  )         lSqlStmt = lSqlStmt + "delivery_status = "+"'"+inBbmBloodBottleHistoryTabObj.delivery_status+"', ";
        if ( inBbmBloodBottleHistoryTabObj.patient_id != null  )         lSqlStmt = lSqlStmt + "patient_id = "+"'"+inBbmBloodBottleHistoryTabObj.patient_id+"', ";
        if ( inBbmBloodBottleHistoryTabObj.receipt_num != null  )         lSqlStmt = lSqlStmt + "receipt_num = "+"'"+inBbmBloodBottleHistoryTabObj.receipt_num+"', ";
        if ( inBbmBloodBottleHistoryTabObj.receipt_date != null  )         lSqlStmt = lSqlStmt + "receipt_date = "+"'"+inBbmBloodBottleHistoryTabObj.receipt_date+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "hospital_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.hospital_id+"' and "+
                              "branch_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.branch_id+"' and "+
                              "blood_bank_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.blood_bank_id+"' and "+
                              "bottle_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.bottle_id+"' and "+
                              "history_date = "+"'"+inBbmBloodBottleHistoryPkeyObj.history_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inBbmBloodBottleHistoryTabObj.hospital_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.hospital_id); } 
         if ( inBbmBloodBottleHistoryTabObj.branch_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.branch_id); } 
         if ( inBbmBloodBottleHistoryTabObj.blood_bank_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.blood_bank_id); } 
         if ( inBbmBloodBottleHistoryTabObj.bottle_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.bottle_id); } 
         if ( inBbmBloodBottleHistoryTabObj.history_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.history_date); } 
         if ( inBbmBloodBottleHistoryTabObj.blood_group != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.blood_group); } 
         if ( inBbmBloodBottleHistoryTabObj.blood_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.blood_type); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(8, inBbmBloodBottleHistoryTabObj.rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(9, inBbmBloodBottleHistoryTabObj.bottle_rack_num);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(10, inBbmBloodBottleHistoryTabObj.bottle_shelf_num);
         if ( inBbmBloodBottleHistoryTabObj.effective_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.effective_date); } 
         if ( inBbmBloodBottleHistoryTabObj.expiration_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.expiration_date); } 
         if ( inBbmBloodBottleHistoryTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.remark); } 
         if ( inBbmBloodBottleHistoryTabObj.blood_source != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.blood_source); } 
         if ( inBbmBloodBottleHistoryTabObj.donor_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.donor_id); } 
         if ( inBbmBloodBottleHistoryTabObj.delivery_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.delivery_status); } 
         if ( inBbmBloodBottleHistoryTabObj.patient_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.patient_id); } 
         if ( inBbmBloodBottleHistoryTabObj.receipt_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.receipt_num); } 
         if ( inBbmBloodBottleHistoryTabObj.receipt_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inBbmBloodBottleHistoryTabObj.receipt_date); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delBbmBloodBottleHistoryRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delBbmBloodBottleHistoryRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delBbmBloodBottleHistoryRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updBbmBloodBottleHistoryRecByPkeyWithSet
               ( BbmBloodBottleHistoryPkeyObj inBbmBloodBottleHistoryPkeyObj
               , String  inBbmBloodBottleHistorySetlist
               )
  {
    int lUpdateCount;
    sop("updBbmBloodBottleHistoryRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updBbmBloodBottleHistoryRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE BBM_BLOOD_BOTTLE_HISTORY ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inBbmBloodBottleHistorySetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "hospital_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.hospital_id+"' and "+
                              "branch_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.branch_id+"' and "+
                              "blood_bank_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.blood_bank_id+"' and "+
                              "bottle_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.bottle_id+"' and "+
                              "history_date = "+"'"+inBbmBloodBottleHistoryPkeyObj.history_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updBbmBloodBottleHistoryRecByRowidWithSet
               ( String inRowId
               , String  inBbmBloodBottleHistorySetlist
               )
  {
    int lUpdateCount;
    sop("updBbmBloodBottleHistoryRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updBbmBloodBottleHistoryRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE BBM_BLOOD_BOTTLE_HISTORY ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inBbmBloodBottleHistorySetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updBbmBloodBottleHistoryRecByWhereWithSet
               ( String inBbmBloodBottleHistoryWhereText
               , String  inBbmBloodBottleHistorySetlist
               )
  {
    int lUpdateCount;
    sop("updBbmBloodBottleHistoryRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updBbmBloodBottleHistoryRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE BBM_BLOOD_BOTTLE_HISTORY ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inBbmBloodBottleHistorySetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delBbmBloodBottleHistoryRecByPkey
               ( BbmBloodBottleHistoryPkeyObj  inBbmBloodBottleHistoryPkeyObj
               )
  {
    int lUpdateCount;
    sop("delBbmBloodBottleHistoryRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delBbmBloodBottleHistoryRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY " + 
                         "WHERE "+
                              "hospital_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.hospital_id+"' and "+
                              "branch_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.branch_id+"' and "+
                              "blood_bank_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.blood_bank_id+"' and "+
                              "bottle_id = "+"'"+inBbmBloodBottleHistoryPkeyObj.bottle_id+"' and "+
                              "history_date = "+"'"+inBbmBloodBottleHistoryPkeyObj.history_date+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delBbmBloodBottleHistoryByWhere
               ( String inBbmBloodBottleHistoryWhereText
               )
  {
    int lUpdateCount;
    sop("delBbmBloodBottleHistoryByWhere - Started");
    gSSTErrorObj.sourceMethod = "delBbmBloodBottleHistoryByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inBbmBloodBottleHistoryWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inBbmBloodBottleHistoryWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   BBM_BLOOD_BOTTLE_HISTORY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
