function BbmBloodMasterRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("blood_group").value  = document.getElementById("blood_group"+"_r"+inRecNum).value;
    document.getElementById("blood_group").readOnly = true;
    document.getElementById("blood_type").value  = document.getElementById("blood_type"+"_r"+inRecNum).value;
    document.getElementById("blood_type").readOnly = true;
    document.getElementById("description").value  = document.getElementById("description"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("blood_group").value = '';
    document.getElementById("blood_group").readOnly = false;
    document.getElementById("blood_type").value = '';
    document.getElementById("blood_type").readOnly = false;
    document.getElementById("description").value = '';
  }
}
