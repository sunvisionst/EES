CREATE TABLE BBM_BLOOD_CHARGE
(
  BLOOD_GROUP                                                                                         VARCHAR(10),
  BLOOD_TYPE                                                                                          VARCHAR(10),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  RATE                                                                                                NUMERIC(12,2),
  UOM                                                                                                 VARCHAR(10),
  CATEGORY_ID                                                                                         VARCHAR(10),
  SUBCATEGORY_ID                                                                                      VARCHAR(10)
)
 WITH OIDS;
