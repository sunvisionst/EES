package sstdb.bbm.BbmDonorPhone;


public class BbmDonorPhonePkeyObj
{
  public String                                 donor_id;
  public byte                                  seq_num;
}