CREATE TABLE BBM_DONOR_BLOOD_DTL_EXT
(
  donor_id                                                                                            VARCHAR(10),
  blood_ingredient                                                                                    VARCHAR(10),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       BLOOD_INGREDIENT                                                                                    CHAR(10),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('bbm_donor_blood_dtl_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
