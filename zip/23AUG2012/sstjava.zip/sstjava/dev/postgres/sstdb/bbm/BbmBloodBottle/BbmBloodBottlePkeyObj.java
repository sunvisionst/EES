package sstdb.bbm.BbmBloodBottle;


public class BbmBloodBottlePkeyObj
{
  public String                                 hospital_id;
  public String                                 branch_id;
  public String                                 blood_bank_id;
  public String                                 bottle_id;
}