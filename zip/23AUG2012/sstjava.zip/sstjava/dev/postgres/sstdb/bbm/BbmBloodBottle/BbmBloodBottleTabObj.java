package sstdb.bbm.BbmBloodBottle;


public class BbmBloodBottleTabObj
{
  public String                                 tab_rowid;
  public String                                 hospital_id;
  public String                                 branch_id;
  public String                                 blood_bank_id;
  public String                                 bottle_id;
  public String                                 blood_group;
  public String                                 blood_type;
  public double                                 rate;
  public int                                  bottle_rack_num;
  public int                                  bottle_shelf_num;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 remark;
  public String                                 blood_source;
  public String                                 donor_id;
  public String                                 delivery_status;
  public String                                 patient_id;
  public String                                 receipt_num;
  public String                                 receipt_date;





  public short                                  hospital_id_ind;
  public short                                  branch_id_ind;
  public short                                  blood_bank_id_ind;
  public short                                  bottle_id_ind;
  public short                                  blood_group_ind;
  public short                                  blood_type_ind;
  public short                                  rate_ind;
  public short                                  bottle_rack_num_ind;
  public short                                  bottle_shelf_num_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  remark_ind;
  public short                                  blood_source_ind;
  public short                                  donor_id_ind;
  public short                                  delivery_status_ind;
  public short                                  patient_id_ind;
  public short                                  receipt_num_ind;
  public short                                  receipt_date_ind;


  public BbmBloodBottleTabObj(){}


  public BbmBloodBottleTabObj
  (
    String hospital_id,
    String branch_id,
    String blood_bank_id,
    String bottle_id,
    String blood_group,
    String blood_type,
    double rate,
    int bottle_rack_num,
    int bottle_shelf_num,
    String effective_date,
    String expiration_date,
    String remark,
    String blood_source,
    String donor_id,
    String delivery_status,
    String patient_id,
    String receipt_num,
    String receipt_date
  )
  {
     this.hospital_id = hospital_id;
     this.branch_id = branch_id;
     this.blood_bank_id = blood_bank_id;
     this.bottle_id = bottle_id;
     this.blood_group = blood_group;
     this.blood_type = blood_type;
     this.rate = rate;
     this.bottle_rack_num = bottle_rack_num;
     this.bottle_shelf_num = bottle_shelf_num;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.remark = remark;
     this.blood_source = blood_source;
     this.donor_id = donor_id;
     this.delivery_status = delivery_status;
     this.patient_id = patient_id;
     this.receipt_num = receipt_num;
     this.receipt_date = receipt_date;
  }

  public String gethospital_id()                        { return hospital_id; }
  public String getbranch_id()                         { return branch_id; }
  public String getblood_bank_id()                       { return blood_bank_id; }
  public String getbottle_id()                         { return bottle_id; }
  public String getblood_group()                        { return blood_group; }
  public String getblood_type()                         { return blood_type; }
  public double getrate()                            { return rate; }
  public int getbottle_rack_num()                        { return bottle_rack_num; }
  public int getbottle_shelf_num()                       { return bottle_shelf_num; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getremark()                           { return remark; }
  public String getblood_source()                        { return blood_source; }
  public String getdonor_id()                          { return donor_id; }
  public String getdelivery_status()                      { return delivery_status; }
  public String getpatient_id()                         { return patient_id; }
  public String getreceipt_num()                        { return receipt_num; }
  public String getreceipt_date()                        { return receipt_date; }



  public void  sethospital_id(String hospital_id )               { this.hospital_id = hospital_id; }
  public void  setbranch_id(String branch_id )                 { this.branch_id = branch_id; }
  public void  setblood_bank_id(String blood_bank_id )             { this.blood_bank_id = blood_bank_id; }
  public void  setbottle_id(String bottle_id )                 { this.bottle_id = bottle_id; }
  public void  setblood_group(String blood_group )               { this.blood_group = blood_group; }
  public void  setblood_type(String blood_type )                { this.blood_type = blood_type; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setbottle_rack_num(int bottle_rack_num )             { this.bottle_rack_num = bottle_rack_num; }
  public void  setbottle_shelf_num(int bottle_shelf_num )            { this.bottle_shelf_num = bottle_shelf_num; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setblood_source(String blood_source )              { this.blood_source = blood_source; }
  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setdelivery_status(String delivery_status )           { this.delivery_status = delivery_status; }
  public void  setpatient_id(String patient_id )                { this.patient_id = patient_id; }
  public void  setreceipt_num(String receipt_num )               { this.receipt_num = receipt_num; }
  public void  setreceipt_date(String receipt_date )              { this.receipt_date = receipt_date; }
}