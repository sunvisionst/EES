CREATE TABLE BBM_BLOOD_MASTER_EXT
(
  blood_group                                                                                         VARCHAR(10),
  blood_type                                                                                          VARCHAR(10),
  description                                                                                         VARCHAR(60)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       BLOOD_GROUP                                                                                         CHAR(10),
       BLOOD_TYPE                                                                                          CHAR(10),
       DESCRIPTION                                                                                         CHAR(60)
    )
  )
  LOCATION ('bbm_blood_master_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
