{


   function vldDBSizeEnvBbmBloodBank
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeHospitalId ( inTableName, inFieldName );
      vldFieldDBSizeBranchId ( inTableName, inFieldName );
      vldFieldDBSizeBloodBankId ( inTableName, inFieldName );
   }



   function constructorBbmBloodBank
   (
      hospital_id,
      branch_id,
      blood_bank_id
   )
   {
      this.hospital_id = hospital_id;
      this.branch_id = branch_id;
      this.blood_bank_id = blood_bank_id;
   }



   function BbmBloodBankFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lBbmBloodBankTabObjJSArr.length )
      {
         if
         ( 
           ( lBbmBloodBankTabObjJSArr[lRecNum].hospital_id != document.form.hospital_id.value ) &&
           ( lBbmBloodBankTabObjJSArr[lRecNum].branch_id != document.form.branch_id.value ) &&
           ( lBbmBloodBankTabObjJSArr[lRecNum].blood_bank_id != document.form.blood_bank_id.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeBbmBloodBankTabObjHospitalId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBankTabObjBranchId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBankTabObjBloodBankId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisHospitalId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBranchId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodBankId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



}