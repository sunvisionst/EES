function BbmDonorRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("donor_id").readOnly = true;
    document.getElementById("donor_type").value  = document.getElementById("donor_type"+"_r"+inRecNum).value;
    document.getElementById("donor_type").readOnly = true;
    document.getElementById("donor_f_name").value  = document.getElementById("donor_f_name"+"_r"+inRecNum).value;
    document.getElementById("donor_m_name").value  = document.getElementById("donor_m_name"+"_r"+inRecNum).value;
    document.getElementById("donor_l_name").value  = document.getElementById("donor_l_name"+"_r"+inRecNum).value;
    document.getElementById("gender").value  = document.getElementById("gender"+"_r"+inRecNum).value;
    document.getElementById("dob").value  = document.getElementById("dob"+"_r"+inRecNum).value;
    document.getElementById("birth_city").value  = document.getElementById("birth_city"+"_r"+inRecNum).value;
    document.getElementById("birth_country").value  = document.getElementById("birth_country"+"_r"+inRecNum).value;
    document.getElementById("relation_name").value  = document.getElementById("relation_name"+"_r"+inRecNum).value;
    document.getElementById("relative_name").value  = document.getElementById("relative_name"+"_r"+inRecNum).value;
    document.getElementById("marital_status").value  = document.getElementById("marital_status"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("donor_id").value = '';
    document.getElementById("donor_id").readOnly = false;
    document.getElementById("donor_type").value = '';
    document.getElementById("donor_type").readOnly = false;
    document.getElementById("donor_f_name").value = '';
    document.getElementById("donor_m_name").value = '';
    document.getElementById("donor_l_name").value = '';
    document.getElementById("gender").value = '';
    document.getElementById("dob").value = '';
    document.getElementById("birth_city").value = '';
    document.getElementById("birth_country").value = '';
    document.getElementById("relation_name").value = '';
    document.getElementById("relative_name").value = '';
    document.getElementById("marital_status").value = '';
  }
}
