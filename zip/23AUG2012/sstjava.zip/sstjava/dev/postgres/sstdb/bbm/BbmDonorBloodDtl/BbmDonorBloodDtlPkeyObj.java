package sstdb.bbm.BbmDonorBloodDtl;


public class BbmDonorBloodDtlPkeyObj
{
  public String                                 donor_id;
  public String                                 blood_ingredient;
}