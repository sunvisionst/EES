package sstdb.bbm.BbmBloodMaster;


public class BbmBloodMasterPkeyObj
{
  public String                                 blood_group;
  public String                                 blood_type;
}