CREATE TABLE BBM_BLOOD_BOTTLE
(
  HOSPITAL_ID                                                                                         VARCHAR(10),
  BRANCH_ID                                                                                           VARCHAR(10),
  BLOOD_BANK_ID                                                                                       VARCHAR(10),
  BOTTLE_ID                                                                                           VARCHAR(12),
  BLOOD_GROUP                                                                                         VARCHAR(10),
  BLOOD_TYPE                                                                                          VARCHAR(10),
  RATE                                                                                                NUMERIC(12,2),
  BOTTLE_RACK_NUM                                                                                     NUMERIC(9),
  BOTTLE_SHELF_NUM                                                                                    NUMERIC(9),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRATION_DATE                                                                                     VARCHAR(8),
  REMARK                                                                                              VARCHAR(100),
  BLOOD_SOURCE                                                                                        VARCHAR(1),
  DONOR_ID                                                                                            VARCHAR(10),
  DELIVERY_STATUS                                                                                     VARCHAR(1),
  PATIENT_ID                                                                                          VARCHAR(10),
  RECEIPT_NUM                                                                                         VARCHAR(10),
  RECEIPT_DATE                                                                                        VARCHAR(8)
)
 WITH OIDS;
