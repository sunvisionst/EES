function BbmBloodBottleHistoryRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("hospital_id").value  = document.getElementById("hospital_id"+"_r"+inRecNum).value;
    document.getElementById("hospital_id").readOnly = true;
    document.getElementById("branch_id").value  = document.getElementById("branch_id"+"_r"+inRecNum).value;
    document.getElementById("branch_id").readOnly = true;
    document.getElementById("blood_bank_id").value  = document.getElementById("blood_bank_id"+"_r"+inRecNum).value;
    document.getElementById("blood_bank_id").readOnly = true;
    document.getElementById("bottle_id").value  = document.getElementById("bottle_id"+"_r"+inRecNum).value;
    document.getElementById("bottle_id").readOnly = true;
    document.getElementById("history_date").value  = document.getElementById("history_date"+"_r"+inRecNum).value;
    document.getElementById("history_date").readOnly = true;
    document.getElementById("blood_group").value  = document.getElementById("blood_group"+"_r"+inRecNum).value;
    document.getElementById("blood_type").value  = document.getElementById("blood_type"+"_r"+inRecNum).value;
    document.getElementById("rate").value  = document.getElementById("rate"+"_r"+inRecNum).value;
    document.getElementById("bottle_rack_num").value  = document.getElementById("bottle_rack_num"+"_r"+inRecNum).value;
    document.getElementById("bottle_shelf_num").value  = document.getElementById("bottle_shelf_num"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
    document.getElementById("blood_source").value  = document.getElementById("blood_source"+"_r"+inRecNum).value;
    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("delivery_status").value  = document.getElementById("delivery_status"+"_r"+inRecNum).value;
    document.getElementById("patient_id").value  = document.getElementById("patient_id"+"_r"+inRecNum).value;
    document.getElementById("receipt_num").value  = document.getElementById("receipt_num"+"_r"+inRecNum).value;
    document.getElementById("receipt_date").value  = document.getElementById("receipt_date"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("hospital_id").value = '';
    document.getElementById("hospital_id").readOnly = false;
    document.getElementById("branch_id").value = '';
    document.getElementById("branch_id").readOnly = false;
    document.getElementById("blood_bank_id").value = '';
    document.getElementById("blood_bank_id").readOnly = false;
    document.getElementById("bottle_id").value = '';
    document.getElementById("bottle_id").readOnly = false;
    document.getElementById("history_date").value = '';
    document.getElementById("history_date").readOnly = false;
    document.getElementById("blood_group").value = '';
    document.getElementById("blood_type").value = '';
    document.getElementById("rate").value = '';
    document.getElementById("bottle_rack_num").value = '';
    document.getElementById("bottle_shelf_num").value = '';
    document.getElementById("effective_date").value = '';
    document.getElementById("expiration_date").value = '';
    document.getElementById("remark").value = '';
    document.getElementById("blood_source").value = '';
    document.getElementById("donor_id").value = '';
    document.getElementById("delivery_status").value = '';
    document.getElementById("patient_id").value = '';
    document.getElementById("receipt_num").value = '';
    document.getElementById("receipt_date").value = '';
  }
}
