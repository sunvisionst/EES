CREATE TABLE BBM_DONOR_PHONE_EXT
(
  donor_id                                                                                            VARCHAR(10),
  seq_num                                                                                             NUMERIC(2),
  contact_type                                                                                        VARCHAR(10),
  phone_type                                                                                          VARCHAR(10),
  contact_num                                                                                         VARCHAR(30),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       SEQ_NUM                                                                                             CHAR(2),
       CONTACT_TYPE                                                                                        CHAR(10),
       PHONE_TYPE                                                                                          CHAR(10),
       CONTACT_NUM                                                                                         CHAR(30),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('bbm_donor_phone_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
