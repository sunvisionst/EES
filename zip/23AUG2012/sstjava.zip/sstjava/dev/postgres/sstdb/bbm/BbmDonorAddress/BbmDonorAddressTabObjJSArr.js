
var lBbmDonorAddressTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorAddressTabObjArrCache != null && lBbmDonorAddressTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorAddressTabObjJSArr = new Array(<%=lBbmDonorAddressTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorAddressTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorAddressTabObj lBbmDonorAddressTabObj    =    new BbmDonorAddressTabObj();
          lBbmDonorAddressTabObj = (BbmDonorAddressTabObj)lBbmDonorAddressTabObjArrCache.get(lRecNum);
%>
          lBbmDonorAddressTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorAddress
          (
          "<%=lBbmDonorAddressTabObj.donor_id%>",
          "<%=lBbmDonorAddressTabObj.address_type%>",
          "<%=lBbmDonorAddressTabObj.address1%>",
          "<%=lBbmDonorAddressTabObj.address2%>",
          "<%=lBbmDonorAddressTabObj.city%>",
          "<%=lBbmDonorAddressTabObj.zip%>",
          "<%=lBbmDonorAddressTabObj.country%>"
          );
<%
       }
   }
}
%>


