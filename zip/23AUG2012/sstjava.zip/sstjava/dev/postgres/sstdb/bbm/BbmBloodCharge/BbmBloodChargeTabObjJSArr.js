
var lBbmBloodChargeTabObjJSArr = new Array();
<%
{
   if ( lBbmBloodChargeTabObjArrCache != null && lBbmBloodChargeTabObjArrCache.size() > 0 )
   {
%>
       lBbmBloodChargeTabObjJSArr = new Array(<%=lBbmBloodChargeTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmBloodChargeTabObjArrCache.size(); lRecNum++ )
       {
          BbmBloodChargeTabObj lBbmBloodChargeTabObj    =    new BbmBloodChargeTabObj();
          lBbmBloodChargeTabObj = (BbmBloodChargeTabObj)lBbmBloodChargeTabObjArrCache.get(lRecNum);
%>
          lBbmBloodChargeTabObjJSArr[<%=lRecNum%>] = new constructorBbmBloodCharge
          (
          "<%=lBbmBloodChargeTabObj.blood_group%>",
          "<%=lBbmBloodChargeTabObj.blood_type%>",
          "<%=lBbmBloodChargeTabObj.effective_date%>",
          "<%=lBbmBloodChargeTabObj.expiration_date%>",
          "<%=lBbmBloodChargeTabObj.rate%>",
          "<%=lBbmBloodChargeTabObj.uom%>",
          "<%=lBbmBloodChargeTabObj.category_id%>",
          "<%=lBbmBloodChargeTabObj.subcategory_id%>"
          );
<%
       }
   }
}
%>


