{


   function vldDBSizeEnvBbmDonor
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeDonorId ( inTableName, inFieldName );
      vldFieldDBSizeDonorType ( inTableName, inFieldName );
      vldFieldDBSizeDonorFName ( inTableName, inFieldName );
      vldFieldDBSizeDonorMName ( inTableName, inFieldName );
      vldFieldDBSizeDonorLName ( inTableName, inFieldName );
      vldFieldDBSizeGender ( inTableName, inFieldName );
      vldFieldDBSizeDob ( inTableName, inFieldName );
      vldFieldDBSizeBirthCity ( inTableName, inFieldName );
      vldFieldDBSizeBirthCountry ( inTableName, inFieldName );
      vldFieldDBSizeRelationName ( inTableName, inFieldName );
      vldFieldDBSizeRelativeName ( inTableName, inFieldName );
      vldFieldDBSizeMaritalStatus ( inTableName, inFieldName );
   }



   function constructorBbmDonor
   (
      donor_id,
      donor_type,
      donor_f_name,
      donor_m_name,
      donor_l_name,
      gender,
      dob,
      birth_city,
      birth_country,
      relation_name,
      relative_name,
      marital_status
   )
   {
      this.donor_id = donor_id;
      this.donor_type = donor_type;
      this.donor_f_name = donor_f_name;
      this.donor_m_name = donor_m_name;
      this.donor_l_name = donor_l_name;
      this.gender = gender;
      this.dob = dob;
      this.birth_city = birth_city;
      this.birth_country = birth_country;
      this.relation_name = relation_name;
      this.relative_name = relative_name;
      this.marital_status = marital_status;
   }



   function BbmDonorFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lBbmDonorTabObjJSArr.length )
      {
         if
         ( 
           ( lBbmDonorTabObjJSArr[lRecNum].donor_id != document.form.donor_id.value ) &&
           ( lBbmDonorTabObjJSArr[lRecNum].donor_type != document.form.donor_type.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeBbmDonorTabObjDonorId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjDonorType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjDonorFName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjDonorMName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjDonorLName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjGender
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjDob
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjBirthCity
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjBirthCountry
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjRelationName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjRelativeName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmDonorTabObjMaritalStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisDonorId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDonorType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDonorFName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDonorMName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDonorLName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisGender
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDob
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBirthCity
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBirthCountry
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRelationName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRelativeName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMaritalStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



}