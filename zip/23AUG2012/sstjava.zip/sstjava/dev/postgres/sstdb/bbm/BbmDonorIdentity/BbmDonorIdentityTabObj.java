package sstdb.bbm.BbmDonorIdentity;


public class BbmDonorIdentityTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public String                                 id_type;
  public String                                 id_type_id;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 remark;





  public short                                  donor_id_ind;
  public short                                  id_type_ind;
  public short                                  id_type_id_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  remark_ind;


  public BbmDonorIdentityTabObj(){}


  public BbmDonorIdentityTabObj
  (
    String donor_id,
    String id_type,
    String id_type_id,
    String effective_date,
    String expiration_date,
    String remark
  )
  {
     this.donor_id = donor_id;
     this.id_type = id_type;
     this.id_type_id = id_type_id;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.remark = remark;
  }

  public String getdonor_id()                          { return donor_id; }
  public String getid_type()                          { return id_type; }
  public String getid_type_id()                         { return id_type_id; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getremark()                           { return remark; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setid_type(String id_type )                   { this.id_type = id_type; }
  public void  setid_type_id(String id_type_id )                { this.id_type_id = id_type_id; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setremark(String remark )                    { this.remark = remark; }
}