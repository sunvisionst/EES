package sstdb.bbm.BbmDonorAddress;


public class BbmDonorAddressPkeyObj
{
  public String                                 donor_id;
  public String                                 address_type;
}