CREATE TABLE BBM_DONOR_EMPLOYER
(
  DONOR_ID                                                                                            VARCHAR(10),
  EMPLOYER_NAME                                                                                       VARCHAR(100),
  PERIOD_FROM                                                                                         VARCHAR(10),
  PERIOD_TO                                                                                           VARCHAR(10),
  PROJECT_HANDLED                                                                                     VARCHAR(100),
  ROLE_IN_PROJECT                                                                                     VARCHAR(20),
  CTC                                                                                                 NUMERIC(12,2),
  SKILL_SET_IN_PROJECT                                                                                VARCHAR(100),
  PROJECT_DESCRIPTION                                                                                 VARCHAR(2000)
)
 WITH OIDS;
