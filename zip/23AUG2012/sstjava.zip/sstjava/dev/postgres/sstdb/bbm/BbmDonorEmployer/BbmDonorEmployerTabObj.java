package sstdb.bbm.BbmDonorEmployer;


public class BbmDonorEmployerTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public String                                 employer_name;
  public String                                 period_from;
  public String                                 period_to;
  public String                                 project_handled;
  public String                                 role_in_project;
  public double                                 ctc;
  public String                                 skill_set_in_project;
  public String                                 project_description;





  public short                                  donor_id_ind;
  public short                                  employer_name_ind;
  public short                                  period_from_ind;
  public short                                  period_to_ind;
  public short                                  project_handled_ind;
  public short                                  role_in_project_ind;
  public short                                  ctc_ind;
  public short                                  skill_set_in_project_ind;
  public short                                  project_description_ind;


  public BbmDonorEmployerTabObj(){}


  public BbmDonorEmployerTabObj
  (
    String donor_id,
    String employer_name,
    String period_from,
    String period_to,
    String project_handled,
    String role_in_project,
    double ctc,
    String skill_set_in_project,
    String project_description
  )
  {
     this.donor_id = donor_id;
     this.employer_name = employer_name;
     this.period_from = period_from;
     this.period_to = period_to;
     this.project_handled = project_handled;
     this.role_in_project = role_in_project;
     this.ctc = ctc;
     this.skill_set_in_project = skill_set_in_project;
     this.project_description = project_description;
  }

  public String getdonor_id()                          { return donor_id; }
  public String getemployer_name()                       { return employer_name; }
  public String getperiod_from()                        { return period_from; }
  public String getperiod_to()                         { return period_to; }
  public String getproject_handled()                      { return project_handled; }
  public String getrole_in_project()                      { return role_in_project; }
  public double getctc()                            { return ctc; }
  public String getskill_set_in_project()                    { return skill_set_in_project; }
  public String getproject_description()                    { return project_description; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setemployer_name(String employer_name )             { this.employer_name = employer_name; }
  public void  setperiod_from(String period_from )               { this.period_from = period_from; }
  public void  setperiod_to(String period_to )                 { this.period_to = period_to; }
  public void  setproject_handled(String project_handled )           { this.project_handled = project_handled; }
  public void  setrole_in_project(String role_in_project )           { this.role_in_project = role_in_project; }
  public void  setctc(double ctc )                       { this.ctc = ctc; }
  public void  setskill_set_in_project(String skill_set_in_project )      { this.skill_set_in_project = skill_set_in_project; }
  public void  setproject_description(String project_description )       { this.project_description = project_description; }
}