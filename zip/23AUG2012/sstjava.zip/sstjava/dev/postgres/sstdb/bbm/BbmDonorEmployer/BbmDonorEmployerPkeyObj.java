package sstdb.bbm.BbmDonorEmployer;


public class BbmDonorEmployerPkeyObj
{
  public String                                 donor_id;
  public String                                 employer_name;
  public String                                 period_from;
}