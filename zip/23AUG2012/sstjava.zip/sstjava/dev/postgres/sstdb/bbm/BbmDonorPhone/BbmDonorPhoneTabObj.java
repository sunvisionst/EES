package sstdb.bbm.BbmDonorPhone;


public class BbmDonorPhoneTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public byte                                  seq_num;
  public String                                 contact_type;
  public String                                 phone_type;
  public String                                 contact_num;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 remark;





  public short                                  donor_id_ind;
  public short                                  seq_num_ind;
  public short                                  contact_type_ind;
  public short                                  phone_type_ind;
  public short                                  contact_num_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  remark_ind;


  public BbmDonorPhoneTabObj(){}


  public BbmDonorPhoneTabObj
  (
    String donor_id,
    byte seq_num,
    String contact_type,
    String phone_type,
    String contact_num,
    String effective_date,
    String expiration_date,
    String remark
  )
  {
     this.donor_id = donor_id;
     this.seq_num = seq_num;
     this.contact_type = contact_type;
     this.phone_type = phone_type;
     this.contact_num = contact_num;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.remark = remark;
  }

  public String getdonor_id()                          { return donor_id; }
  public byte getseq_num()                           { return seq_num; }
  public String getcontact_type()                        { return contact_type; }
  public String getphone_type()                         { return phone_type; }
  public String getcontact_num()                        { return contact_num; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getremark()                           { return remark; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setseq_num(byte seq_num )                    { this.seq_num = seq_num; }
  public void  setcontact_type(String contact_type )              { this.contact_type = contact_type; }
  public void  setphone_type(String phone_type )                { this.phone_type = phone_type; }
  public void  setcontact_num(String contact_num )               { this.contact_num = contact_num; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setremark(String remark )                    { this.remark = remark; }
}