
var lBbmDonorIdentityTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorIdentityTabObjArrCache != null && lBbmDonorIdentityTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorIdentityTabObjJSArr = new Array(<%=lBbmDonorIdentityTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorIdentityTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorIdentityTabObj lBbmDonorIdentityTabObj    =    new BbmDonorIdentityTabObj();
          lBbmDonorIdentityTabObj = (BbmDonorIdentityTabObj)lBbmDonorIdentityTabObjArrCache.get(lRecNum);
%>
          lBbmDonorIdentityTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorIdentity
          (
          "<%=lBbmDonorIdentityTabObj.donor_id%>",
          "<%=lBbmDonorIdentityTabObj.id_type%>",
          "<%=lBbmDonorIdentityTabObj.id_type_id%>",
          "<%=lBbmDonorIdentityTabObj.effective_date%>",
          "<%=lBbmDonorIdentityTabObj.expiration_date%>",
          "<%=lBbmDonorIdentityTabObj.remark%>"
          );
<%
       }
   }
}
%>


