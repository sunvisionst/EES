function BbmBloodChargeRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("blood_group").value  = document.getElementById("blood_group"+"_r"+inRecNum).value;
    document.getElementById("blood_group").readOnly = true;
    document.getElementById("blood_type").value  = document.getElementById("blood_type"+"_r"+inRecNum).value;
    document.getElementById("blood_type").readOnly = true;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("rate").value  = document.getElementById("rate"+"_r"+inRecNum).value;
    document.getElementById("uom").value  = document.getElementById("uom"+"_r"+inRecNum).value;
    document.getElementById("category_id").value  = document.getElementById("category_id"+"_r"+inRecNum).value;
    document.getElementById("subcategory_id").value  = document.getElementById("subcategory_id"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("blood_group").value = '';
    document.getElementById("blood_group").readOnly = false;
    document.getElementById("blood_type").value = '';
    document.getElementById("blood_type").readOnly = false;
    document.getElementById("effective_date").value = '';
    document.getElementById("expiration_date").value = '';
    document.getElementById("rate").value = '';
    document.getElementById("uom").value = '';
    document.getElementById("category_id").value = '';
    document.getElementById("subcategory_id").value = '';
  }
}
