package sstdb.bbm.BbmBloodBank;


public class BbmBloodBankTabObj
{
  public String                                 tab_rowid;
  public String                                 hospital_id;
  public String                                 branch_id;
  public String                                 blood_bank_id;





  public short                                  hospital_id_ind;
  public short                                  branch_id_ind;
  public short                                  blood_bank_id_ind;


  public BbmBloodBankTabObj(){}


  public BbmBloodBankTabObj
  (
    String hospital_id,
    String branch_id,
    String blood_bank_id
  )
  {
     this.hospital_id = hospital_id;
     this.branch_id = branch_id;
     this.blood_bank_id = blood_bank_id;
  }

  public String gethospital_id()                        { return hospital_id; }
  public String getbranch_id()                         { return branch_id; }
  public String getblood_bank_id()                       { return blood_bank_id; }



  public void  sethospital_id(String hospital_id )               { this.hospital_id = hospital_id; }
  public void  setbranch_id(String branch_id )                 { this.branch_id = branch_id; }
  public void  setblood_bank_id(String blood_bank_id )             { this.blood_bank_id = blood_bank_id; }
}