package sstdb.bbm.BbmBloodCharge;


public class BbmBloodChargeTabObj
{
  public String                                 tab_rowid;
  public String                                 blood_group;
  public String                                 blood_type;
  public String                                 effective_date;
  public String                                 expiration_date;
  public double                                 rate;
  public String                                 uom;
  public String                                 category_id;
  public String                                 subcategory_id;





  public short                                  blood_group_ind;
  public short                                  blood_type_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  rate_ind;
  public short                                  uom_ind;
  public short                                  category_id_ind;
  public short                                  subcategory_id_ind;


  public BbmBloodChargeTabObj(){}


  public BbmBloodChargeTabObj
  (
    String blood_group,
    String blood_type,
    String effective_date,
    String expiration_date,
    double rate,
    String uom,
    String category_id,
    String subcategory_id
  )
  {
     this.blood_group = blood_group;
     this.blood_type = blood_type;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.rate = rate;
     this.uom = uom;
     this.category_id = category_id;
     this.subcategory_id = subcategory_id;
  }

  public String getblood_group()                        { return blood_group; }
  public String getblood_type()                         { return blood_type; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public double getrate()                            { return rate; }
  public String getuom()                            { return uom; }
  public String getcategory_id()                        { return category_id; }
  public String getsubcategory_id()                       { return subcategory_id; }



  public void  setblood_group(String blood_group )               { this.blood_group = blood_group; }
  public void  setblood_type(String blood_type )                { this.blood_type = blood_type; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setuom(String uom )                       { this.uom = uom; }
  public void  setcategory_id(String category_id )               { this.category_id = category_id; }
  public void  setsubcategory_id(String subcategory_id )            { this.subcategory_id = subcategory_id; }
}