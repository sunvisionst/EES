
var lBbmBloodBottleHistoryTabObjJSArr = new Array();
<%
{
   if ( lBbmBloodBottleHistoryTabObjArrCache != null && lBbmBloodBottleHistoryTabObjArrCache.size() > 0 )
   {
%>
       lBbmBloodBottleHistoryTabObjJSArr = new Array(<%=lBbmBloodBottleHistoryTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmBloodBottleHistoryTabObjArrCache.size(); lRecNum++ )
       {
          BbmBloodBottleHistoryTabObj lBbmBloodBottleHistoryTabObj    =    new BbmBloodBottleHistoryTabObj();
          lBbmBloodBottleHistoryTabObj = (BbmBloodBottleHistoryTabObj)lBbmBloodBottleHistoryTabObjArrCache.get(lRecNum);
%>
          lBbmBloodBottleHistoryTabObjJSArr[<%=lRecNum%>] = new constructorBbmBloodBottleHistory
          (
          "<%=lBbmBloodBottleHistoryTabObj.hospital_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.branch_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.blood_bank_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.bottle_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.history_date%>",
          "<%=lBbmBloodBottleHistoryTabObj.blood_group%>",
          "<%=lBbmBloodBottleHistoryTabObj.blood_type%>",
          "<%=lBbmBloodBottleHistoryTabObj.rate%>",
          "<%=lBbmBloodBottleHistoryTabObj.bottle_rack_num%>",
          "<%=lBbmBloodBottleHistoryTabObj.bottle_shelf_num%>",
          "<%=lBbmBloodBottleHistoryTabObj.effective_date%>",
          "<%=lBbmBloodBottleHistoryTabObj.expiration_date%>",
          "<%=lBbmBloodBottleHistoryTabObj.remark%>",
          "<%=lBbmBloodBottleHistoryTabObj.blood_source%>",
          "<%=lBbmBloodBottleHistoryTabObj.donor_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.delivery_status%>",
          "<%=lBbmBloodBottleHistoryTabObj.patient_id%>",
          "<%=lBbmBloodBottleHistoryTabObj.receipt_num%>",
          "<%=lBbmBloodBottleHistoryTabObj.receipt_date%>"
          );
<%
       }
   }
}
%>


