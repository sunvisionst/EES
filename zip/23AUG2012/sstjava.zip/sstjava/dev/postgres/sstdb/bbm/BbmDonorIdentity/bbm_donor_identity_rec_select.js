function BbmDonorIdentityRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("donor_id").value  = document.getElementById("donor_id"+"_r"+inRecNum).value;
    document.getElementById("donor_id").readOnly = true;
    document.getElementById("id_type").value  = document.getElementById("id_type"+"_r"+inRecNum).value;
    document.getElementById("id_type").readOnly = true;
    document.getElementById("id_type_id").value  = document.getElementById("id_type_id"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("donor_id").value = '';
    document.getElementById("donor_id").readOnly = false;
    document.getElementById("id_type").value = '';
    document.getElementById("id_type").readOnly = false;
    document.getElementById("id_type_id").value = '';
    document.getElementById("effective_date").value = '';
    document.getElementById("expiration_date").value = '';
    document.getElementById("remark").value = '';
  }
}
