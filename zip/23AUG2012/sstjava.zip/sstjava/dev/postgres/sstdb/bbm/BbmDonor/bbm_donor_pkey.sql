ALTER TABLE           BBM_DONOR
  ADD                 CONSTRAINT BBM_DONOR_PK
  PRIMARY             KEY
  ( DONOR_ID, DONOR_TYPE )
;
