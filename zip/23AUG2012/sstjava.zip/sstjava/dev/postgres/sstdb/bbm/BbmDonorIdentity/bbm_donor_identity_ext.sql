CREATE TABLE BBM_DONOR_IDENTITY_EXT
(
  donor_id                                                                                            VARCHAR(10),
  id_type                                                                                             VARCHAR(10),
  id_type_id                                                                                          VARCHAR(20),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       DONOR_ID                                                                                            CHAR(10),
       ID_TYPE                                                                                             CHAR(10),
       ID_TYPE_ID                                                                                          CHAR(20),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('bbm_donor_identity_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
