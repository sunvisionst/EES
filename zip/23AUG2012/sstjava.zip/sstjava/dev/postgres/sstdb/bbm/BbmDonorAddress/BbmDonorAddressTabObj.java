package sstdb.bbm.BbmDonorAddress;


public class BbmDonorAddressTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public String                                 address_type;
  public String                                 address1;
  public String                                 address2;
  public String                                 city;
  public long                                  zip;
  public String                                 country;





  public short                                  donor_id_ind;
  public short                                  address_type_ind;
  public short                                  address1_ind;
  public short                                  address2_ind;
  public short                                  city_ind;
  public short                                  zip_ind;
  public short                                  country_ind;


  public BbmDonorAddressTabObj(){}


  public BbmDonorAddressTabObj
  (
    String donor_id,
    String address_type,
    String address1,
    String address2,
    String city,
    long zip,
    String country
  )
  {
     this.donor_id = donor_id;
     this.address_type = address_type;
     this.address1 = address1;
     this.address2 = address2;
     this.city = city;
     this.zip = zip;
     this.country = country;
  }

  public String getdonor_id()                          { return donor_id; }
  public String getaddress_type()                        { return address_type; }
  public String getaddress1()                          { return address1; }
  public String getaddress2()                          { return address2; }
  public String getcity()                            { return city; }
  public long getzip()                             { return zip; }
  public String getcountry()                          { return country; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setaddress_type(String address_type )              { this.address_type = address_type; }
  public void  setaddress1(String address1 )                  { this.address1 = address1; }
  public void  setaddress2(String address2 )                  { this.address2 = address2; }
  public void  setcity(String city )                      { this.city = city; }
  public void  setzip(long zip )                        { this.zip = zip; }
  public void  setcountry(String country )                   { this.country = country; }
}