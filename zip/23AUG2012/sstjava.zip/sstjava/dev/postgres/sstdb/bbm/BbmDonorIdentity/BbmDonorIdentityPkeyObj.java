package sstdb.bbm.BbmDonorIdentity;


public class BbmDonorIdentityPkeyObj
{
  public String                                 donor_id;
  public String                                 id_type;
}