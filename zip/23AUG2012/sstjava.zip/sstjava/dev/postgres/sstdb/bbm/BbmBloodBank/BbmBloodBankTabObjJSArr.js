
var lBbmBloodBankTabObjJSArr = new Array();
<%
{
   if ( lBbmBloodBankTabObjArrCache != null && lBbmBloodBankTabObjArrCache.size() > 0 )
   {
%>
       lBbmBloodBankTabObjJSArr = new Array(<%=lBbmBloodBankTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmBloodBankTabObjArrCache.size(); lRecNum++ )
       {
          BbmBloodBankTabObj lBbmBloodBankTabObj    =    new BbmBloodBankTabObj();
          lBbmBloodBankTabObj = (BbmBloodBankTabObj)lBbmBloodBankTabObjArrCache.get(lRecNum);
%>
          lBbmBloodBankTabObjJSArr[<%=lRecNum%>] = new constructorBbmBloodBank
          (
          "<%=lBbmBloodBankTabObj.hospital_id%>",
          "<%=lBbmBloodBankTabObj.branch_id%>",
          "<%=lBbmBloodBankTabObj.blood_bank_id%>"
          );
<%
       }
   }
}
%>


