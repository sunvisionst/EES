{


   function vldDBSizeEnvBbmBloodBottle
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeHospitalId ( inTableName, inFieldName );
      vldFieldDBSizeBranchId ( inTableName, inFieldName );
      vldFieldDBSizeBloodBankId ( inTableName, inFieldName );
      vldFieldDBSizeBottleId ( inTableName, inFieldName );
      vldFieldDBSizeBloodGroup ( inTableName, inFieldName );
      vldFieldDBSizeBloodType ( inTableName, inFieldName );
      vldFieldDBSizeRate ( inTableName, inFieldName );
      vldFieldDBSizeBottleRackNum ( inTableName, inFieldName );
      vldFieldDBSizeBottleShelfNum ( inTableName, inFieldName );
      vldFieldDBSizeEffectiveDate ( inTableName, inFieldName );
      vldFieldDBSizeExpirationDate ( inTableName, inFieldName );
      vldFieldDBSizeRemark ( inTableName, inFieldName );
      vldFieldDBSizeBloodSource ( inTableName, inFieldName );
      vldFieldDBSizeDonorId ( inTableName, inFieldName );
      vldFieldDBSizeDeliveryStatus ( inTableName, inFieldName );
      vldFieldDBSizePatientId ( inTableName, inFieldName );
      vldFieldDBSizeReceiptNum ( inTableName, inFieldName );
      vldFieldDBSizeReceiptDate ( inTableName, inFieldName );
   }



   function constructorBbmBloodBottle
   (
      hospital_id,
      branch_id,
      blood_bank_id,
      bottle_id,
      blood_group,
      blood_type,
      rate,
      bottle_rack_num,
      bottle_shelf_num,
      effective_date,
      expiration_date,
      remark,
      blood_source,
      donor_id,
      delivery_status,
      patient_id,
      receipt_num,
      receipt_date
   )
   {
      this.hospital_id = hospital_id;
      this.branch_id = branch_id;
      this.blood_bank_id = blood_bank_id;
      this.bottle_id = bottle_id;
      this.blood_group = blood_group;
      this.blood_type = blood_type;
      this.rate = rate;
      this.bottle_rack_num = bottle_rack_num;
      this.bottle_shelf_num = bottle_shelf_num;
      this.effective_date = effective_date;
      this.expiration_date = expiration_date;
      this.remark = remark;
      this.blood_source = blood_source;
      this.donor_id = donor_id;
      this.delivery_status = delivery_status;
      this.patient_id = patient_id;
      this.receipt_num = receipt_num;
      this.receipt_date = receipt_date;
   }



   function BbmBloodBottleFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lBbmBloodBottleTabObjJSArr.length )
      {
         if
         ( 
           ( lBbmBloodBottleTabObjJSArr[lRecNum].hospital_id != document.form.hospital_id.value ) &&
           ( lBbmBloodBottleTabObjJSArr[lRecNum].branch_id != document.form.branch_id.value ) &&
           ( lBbmBloodBottleTabObjJSArr[lRecNum].blood_bank_id != document.form.blood_bank_id.value ) &&
           ( lBbmBloodBottleTabObjJSArr[lRecNum].bottle_id != document.form.bottle_id.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeBbmBloodBottleTabObjHospitalId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBranchId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBloodBankId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBottleId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >12 )
      {
         alert("Data base field size error. Size should be <= 12");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBloodGroup
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBloodType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjRate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >15 )
      {
         alert("Data base field size error. Size should be <= 15");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >12 )
      {
         alert("Data base field size error. Integer Size should be <= 12");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBottleRackNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBottleShelfNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjEffectiveDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjExpirationDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjRemark
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjBloodSource
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjDonorId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjDeliveryStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjPatientId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjReceiptNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeBbmBloodBottleTabObjReceiptDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisHospitalId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBranchId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodBankId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBottleId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >12 )
      {
         alert("Data base field size error. Size should be <= 12");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodGroup
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >15 )
      {
         alert("Data base field size error. Size should be <= 15");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >12 )
      {
         alert("Data base field size error. Integer Size should be <= 12");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBottleRackNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBottleShelfNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisEffectiveDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisExpirationDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRemark
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBloodSource
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDonorId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDeliveryStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisPatientId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisReceiptNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisReceiptDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



}