CREATE TABLE BBM_BLOOD_CHARGE_EXT
(
  blood_group                                                                                         VARCHAR(10),
  blood_type                                                                                          VARCHAR(10),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  rate                                                                                                NUMERIC(12,2),
  uom                                                                                                 VARCHAR(10),
  category_id                                                                                         VARCHAR(10),
  subcategory_id                                                                                      VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       BLOOD_GROUP                                                                                         CHAR(10),
       BLOOD_TYPE                                                                                          CHAR(10),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       RATE                                                                                                CHAR(12),
       UOM                                                                                                 CHAR(10),
       CATEGORY_ID                                                                                         CHAR(10),
       SUBCATEGORY_ID                                                                                      CHAR(10)
    )
  )
  LOCATION ('bbm_blood_charge_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
