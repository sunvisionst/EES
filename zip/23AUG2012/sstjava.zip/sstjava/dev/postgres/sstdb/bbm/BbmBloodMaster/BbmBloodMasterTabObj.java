package sstdb.bbm.BbmBloodMaster;


public class BbmBloodMasterTabObj
{
  public String                                 tab_rowid;
  public String                                 blood_group;
  public String                                 blood_type;
  public String                                 description;





  public short                                  blood_group_ind;
  public short                                  blood_type_ind;
  public short                                  description_ind;


  public BbmBloodMasterTabObj(){}


  public BbmBloodMasterTabObj
  (
    String blood_group,
    String blood_type,
    String description
  )
  {
     this.blood_group = blood_group;
     this.blood_type = blood_type;
     this.description = description;
  }

  public String getblood_group()                        { return blood_group; }
  public String getblood_type()                         { return blood_type; }
  public String getdescription()                        { return description; }



  public void  setblood_group(String blood_group )               { this.blood_group = blood_group; }
  public void  setblood_type(String blood_type )                { this.blood_type = blood_type; }
  public void  setdescription(String description )               { this.description = description; }
}