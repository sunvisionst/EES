package sstdb.bbm.BbmDonorMail;


public class BbmDonorMailPkeyObj
{
  public String                                 donor_id;
  public byte                                  seq_num;
}