
var lBbmDonorBloodDtlTabObjJSArr = new Array();
<%
{
   if ( lBbmDonorBloodDtlTabObjArrCache != null && lBbmDonorBloodDtlTabObjArrCache.size() > 0 )
   {
%>
       lBbmDonorBloodDtlTabObjJSArr = new Array(<%=lBbmDonorBloodDtlTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lBbmDonorBloodDtlTabObjArrCache.size(); lRecNum++ )
       {
          BbmDonorBloodDtlTabObj lBbmDonorBloodDtlTabObj    =    new BbmDonorBloodDtlTabObj();
          lBbmDonorBloodDtlTabObj = (BbmDonorBloodDtlTabObj)lBbmDonorBloodDtlTabObjArrCache.get(lRecNum);
%>
          lBbmDonorBloodDtlTabObjJSArr[<%=lRecNum%>] = new constructorBbmDonorBloodDtl
          (
          "<%=lBbmDonorBloodDtlTabObj.donor_id%>",
          "<%=lBbmDonorBloodDtlTabObj.blood_ingredient%>",
          "<%=lBbmDonorBloodDtlTabObj.remark%>"
          );
<%
       }
   }
}
%>


