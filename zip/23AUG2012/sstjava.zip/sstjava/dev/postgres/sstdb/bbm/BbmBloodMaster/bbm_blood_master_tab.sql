CREATE TABLE BBM_BLOOD_MASTER
(
  BLOOD_GROUP                                                                                         VARCHAR(10),
  BLOOD_TYPE                                                                                          VARCHAR(10),
  DESCRIPTION                                                                                         VARCHAR(60)
)
 WITH OIDS;
