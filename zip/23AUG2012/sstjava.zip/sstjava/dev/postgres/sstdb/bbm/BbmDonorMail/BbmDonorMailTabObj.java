package sstdb.bbm.BbmDonorMail;


public class BbmDonorMailTabObj
{
  public String                                 tab_rowid;
  public String                                 donor_id;
  public byte                                  seq_num;
  public String                                 mail_type;
  public String                                 mail_id;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 remark;





  public short                                  donor_id_ind;
  public short                                  seq_num_ind;
  public short                                  mail_type_ind;
  public short                                  mail_id_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  remark_ind;


  public BbmDonorMailTabObj(){}


  public BbmDonorMailTabObj
  (
    String donor_id,
    byte seq_num,
    String mail_type,
    String mail_id,
    String effective_date,
    String expiration_date,
    String remark
  )
  {
     this.donor_id = donor_id;
     this.seq_num = seq_num;
     this.mail_type = mail_type;
     this.mail_id = mail_id;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.remark = remark;
  }

  public String getdonor_id()                          { return donor_id; }
  public byte getseq_num()                           { return seq_num; }
  public String getmail_type()                         { return mail_type; }
  public String getmail_id()                          { return mail_id; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getremark()                           { return remark; }



  public void  setdonor_id(String donor_id )                  { this.donor_id = donor_id; }
  public void  setseq_num(byte seq_num )                    { this.seq_num = seq_num; }
  public void  setmail_type(String mail_type )                 { this.mail_type = mail_type; }
  public void  setmail_id(String mail_id )                   { this.mail_id = mail_id; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setremark(String remark )                    { this.remark = remark; }
}