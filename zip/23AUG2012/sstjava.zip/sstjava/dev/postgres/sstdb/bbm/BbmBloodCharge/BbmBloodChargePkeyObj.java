package sstdb.bbm.BbmBloodCharge;


public class BbmBloodChargePkeyObj
{
  public String                                 blood_group;
  public String                                 blood_type;
}