CREATE TABLE BBM_BLOOD_BOTTLE_EXT
(
  hospital_id                                                                                         VARCHAR(10),
  branch_id                                                                                           VARCHAR(10),
  blood_bank_id                                                                                       VARCHAR(10),
  bottle_id                                                                                           VARCHAR(12),
  blood_group                                                                                         VARCHAR(10),
  blood_type                                                                                          VARCHAR(10),
  rate                                                                                                NUMERIC(12,2),
  bottle_rack_num                                                                                     NUMERIC(9),
  bottle_shelf_num                                                                                    NUMERIC(9),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  remark                                                                                              VARCHAR(100),
  blood_source                                                                                        VARCHAR(1),
  donor_id                                                                                            VARCHAR(10),
  delivery_status                                                                                     VARCHAR(1),
  patient_id                                                                                          VARCHAR(10),
  receipt_num                                                                                         VARCHAR(10),
  receipt_date                                                                                        VARCHAR(8)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       HOSPITAL_ID                                                                                         CHAR(10),
       BRANCH_ID                                                                                           CHAR(10),
       BLOOD_BANK_ID                                                                                       CHAR(10),
       BOTTLE_ID                                                                                           CHAR(12),
       BLOOD_GROUP                                                                                         CHAR(10),
       BLOOD_TYPE                                                                                          CHAR(10),
       RATE                                                                                                CHAR(12),
       BOTTLE_RACK_NUM                                                                                     CHAR(9),
       BOTTLE_SHELF_NUM                                                                                    CHAR(9),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       REMARK                                                                                              CHAR(100),
       BLOOD_SOURCE                                                                                        CHAR(1),
       DONOR_ID                                                                                            CHAR(10),
       DELIVERY_STATUS                                                                                     CHAR(1),
       PATIENT_ID                                                                                          CHAR(10),
       RECEIPT_NUM                                                                                         CHAR(10),
       RECEIPT_DATE                                                                                        CHAR(8)
    )
  )
  LOCATION ('bbm_blood_bottle_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
