{


   function vldDBSizeEnvCxDtxn
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeTxnNum ( inTableName, inFieldName );
      vldFieldDBSizeTxnDate ( inTableName, inFieldName );
      vldFieldDBSizeTxnTime ( inTableName, inFieldName );
      vldFieldDBSizeTxnType ( inTableName, inFieldName );
      vldFieldDBSizeMemberId ( inTableName, inFieldName );
      vldFieldDBSizeMemberName ( inTableName, inFieldName );
      vldFieldDBSizeContractId ( inTableName, inFieldName );
      vldFieldDBSizeSymbolCd ( inTableName, inFieldName );
      vldFieldDBSizeQty ( inTableName, inFieldName );
      vldFieldDBSizeMatureQty ( inTableName, inFieldName );
      vldFieldDBSizeRate ( inTableName, inFieldName );
      vldFieldDBSizeCfTxnNum ( inTableName, inFieldName );
      vldFieldDBSizeCfRate ( inTableName, inFieldName );
      vldFieldDBSizeCfDate ( inTableName, inFieldName );
      vldFieldDBSizeCfTime ( inTableName, inFieldName );
      vldFieldDBSizeStatus ( inTableName, inFieldName );
      vldFieldDBSizeRegInd ( inTableName, inFieldName );
      vldFieldDBSizeRegLimit ( inTableName, inFieldName );
      vldFieldDBSizeSlrInd ( inTableName, inFieldName );
      vldFieldDBSizeSlrLimit ( inTableName, inFieldName );
      vldFieldDBSizeRecCreDate ( inTableName, inFieldName );
      vldFieldDBSizeRecCreTime ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdDate ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdTime ( inTableName, inFieldName );
   }



   function constructorCxDtxn
   (
      org_id,
      txn_num,
      txn_date,
      txn_time,
      txn_type,
      member_id,
      member_name,
      contract_id,
      symbol_cd,
      qty,
      mature_qty,
      rate,
      cf_txn_num,
      cf_rate,
      cf_date,
      cf_time,
      status,
      reg_ind,
      reg_limit,
      slr_ind,
      slr_limit,
      rec_cre_date,
      rec_cre_time,
      rec_upd_date,
      rec_upd_time
   )
   {
      this.org_id = org_id;
      this.txn_num = txn_num;
      this.txn_date = txn_date;
      this.txn_time = txn_time;
      this.txn_type = txn_type;
      this.member_id = member_id;
      this.member_name = member_name;
      this.contract_id = contract_id;
      this.symbol_cd = symbol_cd;
      this.qty = qty;
      this.mature_qty = mature_qty;
      this.rate = rate;
      this.cf_txn_num = cf_txn_num;
      this.cf_rate = cf_rate;
      this.cf_date = cf_date;
      this.cf_time = cf_time;
      this.status = status;
      this.reg_ind = reg_ind;
      this.reg_limit = reg_limit;
      this.slr_ind = slr_ind;
      this.slr_limit = slr_limit;
      this.rec_cre_date = rec_cre_date;
      this.rec_cre_time = rec_cre_time;
      this.rec_upd_date = rec_upd_date;
      this.rec_upd_time = rec_upd_time;
   }



   function CxDtxnFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lCxDtxnTabObjJSArr.length )
      {
         if
         ( 
           ( lCxDtxnTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lCxDtxnTabObjJSArr[lRecNum].txn_num != document.form.txn_num.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeCxDtxnTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjTxnNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjTxnDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjTxnTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjTxnType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjMemberId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjMemberName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjContractId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjQty
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjMatureQty
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjCfTxnNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjCfRate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjCfDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjCfTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRegInd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRegLimit
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjSlrInd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjSlrLimit
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxDtxnTabObjRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisTxnNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisTxnDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisTxnTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisTxnType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMemberId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMemberName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisContractId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisQty
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMatureQty
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCfTxnNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCfRate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCfDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCfTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRegInd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRegLimit
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSlrInd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSlrLimit
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



}