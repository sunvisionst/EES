package sstdb.cx.CxOrg;


public class CxOrgTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 org_name;
  public String                                 related_org_id;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 city;
  public String                                 state;
  public String                                 zip;
  public String                                 country;
  public String                                 org_type;
  public String                                 org_ctg;
  public String                                 bus_type;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;
  public String                                 business_currency;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 org_url;
  public String                                 logo_file_name;
  public String                                 employer_reg_num;
  public String                                 employer_reg_date;
  public String                                 epf_act_num;
  public String                                 epf_act_open_dt;
  public String                                 esi_num;
  public String                                 esi_act_open_dt;
  public String                                 pan_num;
  public String                                 pan_create_date;
  public String                                 nss_num;
  public String                                 nss_create_date;
  public String                                 key_1;
  public String                                 key_2;
  public String                                 mkey;





  public short                                  org_id_ind;
  public short                                  org_name_ind;
  public short                                  related_org_id_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  city_ind;
  public short                                  state_ind;
  public short                                  zip_ind;
  public short                                  country_ind;
  public short                                  org_type_ind;
  public short                                  org_ctg_ind;
  public short                                  bus_type_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;
  public short                                  business_currency_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  org_url_ind;
  public short                                  logo_file_name_ind;
  public short                                  employer_reg_num_ind;
  public short                                  employer_reg_date_ind;
  public short                                  epf_act_num_ind;
  public short                                  epf_act_open_dt_ind;
  public short                                  esi_num_ind;
  public short                                  esi_act_open_dt_ind;
  public short                                  pan_num_ind;
  public short                                  pan_create_date_ind;
  public short                                  nss_num_ind;
  public short                                  nss_create_date_ind;
  public short                                  key_1_ind;
  public short                                  key_2_ind;
  public short                                  mkey_ind;


  public CxOrgTabObj(){}


  public CxOrgTabObj
  (
    String org_id,
    String org_name,
    String related_org_id,
    String address_1,
    String address_2,
    String city,
    String state,
    String zip,
    String country,
    String org_type,
    String org_ctg,
    String bus_type,
    String phone_list,
    String email_list,
    String fax_list,
    String business_currency,
    String effective_date,
    String expiration_date,
    String org_url,
    String logo_file_name,
    String employer_reg_num,
    String employer_reg_date,
    String epf_act_num,
    String epf_act_open_dt,
    String esi_num,
    String esi_act_open_dt,
    String pan_num,
    String pan_create_date,
    String nss_num,
    String nss_create_date,
    String key_1,
    String key_2,
    String mkey
  )
  {
     this.org_id = org_id;
     this.org_name = org_name;
     this.related_org_id = related_org_id;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.city = city;
     this.state = state;
     this.zip = zip;
     this.country = country;
     this.org_type = org_type;
     this.org_ctg = org_ctg;
     this.bus_type = bus_type;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
     this.business_currency = business_currency;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.org_url = org_url;
     this.logo_file_name = logo_file_name;
     this.employer_reg_num = employer_reg_num;
     this.employer_reg_date = employer_reg_date;
     this.epf_act_num = epf_act_num;
     this.epf_act_open_dt = epf_act_open_dt;
     this.esi_num = esi_num;
     this.esi_act_open_dt = esi_act_open_dt;
     this.pan_num = pan_num;
     this.pan_create_date = pan_create_date;
     this.nss_num = nss_num;
     this.nss_create_date = nss_create_date;
     this.key_1 = key_1;
     this.key_2 = key_2;
     this.mkey = mkey;
  }

  public String getorg_id()                           { return org_id; }
  public String getorg_name()                          { return org_name; }
  public String getrelated_org_id()                       { return related_org_id; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getcity()                            { return city; }
  public String getstate()                           { return state; }
  public String getzip()                            { return zip; }
  public String getcountry()                          { return country; }
  public String getorg_type()                          { return org_type; }
  public String getorg_ctg()                          { return org_ctg; }
  public String getbus_type()                          { return bus_type; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }
  public String getbusiness_currency()                     { return business_currency; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getorg_url()                          { return org_url; }
  public String getlogo_file_name()                       { return logo_file_name; }
  public String getemployer_reg_num()                      { return employer_reg_num; }
  public String getemployer_reg_date()                     { return employer_reg_date; }
  public String getepf_act_num()                        { return epf_act_num; }
  public String getepf_act_open_dt()                      { return epf_act_open_dt; }
  public String getesi_num()                          { return esi_num; }
  public String getesi_act_open_dt()                      { return esi_act_open_dt; }
  public String getpan_num()                          { return pan_num; }
  public String getpan_create_date()                      { return pan_create_date; }
  public String getnss_num()                          { return nss_num; }
  public String getnss_create_date()                      { return nss_create_date; }
  public String getkey_1()                           { return key_1; }
  public String getkey_2()                           { return key_2; }
  public String getmkey()                            { return mkey; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setorg_name(String org_name )                  { this.org_name = org_name; }
  public void  setrelated_org_id(String related_org_id )            { this.related_org_id = related_org_id; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setcity(String city )                      { this.city = city; }
  public void  setstate(String state )                     { this.state = state; }
  public void  setzip(String zip )                       { this.zip = zip; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setorg_type(String org_type )                  { this.org_type = org_type; }
  public void  setorg_ctg(String org_ctg )                   { this.org_ctg = org_ctg; }
  public void  setbus_type(String bus_type )                  { this.bus_type = bus_type; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
  public void  setbusiness_currency(String business_currency )         { this.business_currency = business_currency; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setorg_url(String org_url )                   { this.org_url = org_url; }
  public void  setlogo_file_name(String logo_file_name )            { this.logo_file_name = logo_file_name; }
  public void  setemployer_reg_num(String employer_reg_num )          { this.employer_reg_num = employer_reg_num; }
  public void  setemployer_reg_date(String employer_reg_date )         { this.employer_reg_date = employer_reg_date; }
  public void  setepf_act_num(String epf_act_num )               { this.epf_act_num = epf_act_num; }
  public void  setepf_act_open_dt(String epf_act_open_dt )           { this.epf_act_open_dt = epf_act_open_dt; }
  public void  setesi_num(String esi_num )                   { this.esi_num = esi_num; }
  public void  setesi_act_open_dt(String esi_act_open_dt )           { this.esi_act_open_dt = esi_act_open_dt; }
  public void  setpan_num(String pan_num )                   { this.pan_num = pan_num; }
  public void  setpan_create_date(String pan_create_date )           { this.pan_create_date = pan_create_date; }
  public void  setnss_num(String nss_num )                   { this.nss_num = nss_num; }
  public void  setnss_create_date(String nss_create_date )           { this.nss_create_date = nss_create_date; }
  public void  setkey_1(String key_1 )                     { this.key_1 = key_1; }
  public void  setkey_2(String key_2 )                     { this.key_2 = key_2; }
  public void  setmkey(String mkey )                      { this.mkey = mkey; }
}