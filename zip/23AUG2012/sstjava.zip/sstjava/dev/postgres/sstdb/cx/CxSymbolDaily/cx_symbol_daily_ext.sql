CREATE TABLE CX_SYMBOL_DAILY_EXT
(
  org_id                                                                                              VARCHAR(10),
  curr_date                                                                                           VARCHAR(8),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  symbol_name                                                                                         VARCHAR(50),
  status                                                                                              VARCHAR(5),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6),
  eff_date                                                                                            VARCHAR(8),
  eff_time                                                                                            VARCHAR(6),
  exp_date                                                                                            VARCHAR(8),
  exp_time                                                                                            VARCHAR(6),
  exp_rate                                                                                            NUMERIC(13,2),
  fwd_rate                                                                                            NUMERIC(13,2),
  fut_rate                                                                                            NUMERIC(13,2),
  spot_rate                                                                                           NUMERIC(13,2),
  ltp                                                                                                 NUMERIC(13,2),
  ltp_date                                                                                            VARCHAR(8),
  ltp_time                                                                                            VARCHAR(6),
  rate_currency                                                                                       VARCHAR(10),
  rate_per_uom                                                                                        VARCHAR(5),
  net_change                                                                                          NUMERIC(13,2),
  percent_change                                                                                      NUMERIC(5,2),
  high                                                                                                NUMERIC(13,2),
  low                                                                                                 NUMERIC(13,2),
  bbr                                                                                                 NUMERIC(13,2),
  bbq                                                                                                 NUMERIC(9),
  bsr                                                                                                 NUMERIC(13,2),
  bsq                                                                                                 NUMERIC(9),
  open_rate                                                                                           NUMERIC(13,2),
  close_rate                                                                                          NUMERIC(13,2)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       CURR_DATE                                                                                           CHAR(8),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       SYMBOL_NAME                                                                                         CHAR(50),
       STATUS                                                                                              CHAR(5),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6),
       EFF_DATE                                                                                            CHAR(8),
       EFF_TIME                                                                                            CHAR(6),
       EXP_DATE                                                                                            CHAR(8),
       EXP_TIME                                                                                            CHAR(6),
       EXP_RATE                                                                                            CHAR(13),
       FWD_RATE                                                                                            CHAR(13),
       FUT_RATE                                                                                            CHAR(13),
       SPOT_RATE                                                                                           CHAR(13),
       LTP                                                                                                 CHAR(13),
       LTP_DATE                                                                                            CHAR(8),
       LTP_TIME                                                                                            CHAR(6),
       RATE_CURRENCY                                                                                       CHAR(10),
       RATE_PER_UOM                                                                                        CHAR(5),
       NET_CHANGE                                                                                          CHAR(13),
       PERCENT_CHANGE                                                                                      CHAR(5),
       HIGH                                                                                                CHAR(13),
       LOW                                                                                                 CHAR(13),
       BBR                                                                                                 CHAR(13),
       BBQ                                                                                                 CHAR(9),
       BSR                                                                                                 CHAR(13),
       BSQ                                                                                                 CHAR(9),
       OPEN_RATE                                                                                           CHAR(13),
       CLOSE_RATE                                                                                          CHAR(13)
    )
  )
  LOCATION ('cx_symbol_daily_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
