package sstdb.cx.CxDtxn;


public class CxDtxnTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 txn_num;
  public String                                 txn_date;
  public String                                 txn_time;
  public String                                 txn_type;
  public String                                 member_id;
  public String                                 member_name;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public int                                  qty;
  public int                                  mature_qty;
  public double                                 rate;
  public String                                 cf_txn_num;
  public double                                 cf_rate;
  public String                                 cf_date;
  public String                                 cf_time;
  public String                                 status;
  public String                                 reg_ind;
  public double                                 reg_limit;
  public String                                 slr_ind;
  public double                                 slr_limit;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  txn_num_ind;
  public short                                  txn_date_ind;
  public short                                  txn_time_ind;
  public short                                  txn_type_ind;
  public short                                  member_id_ind;
  public short                                  member_name_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  qty_ind;
  public short                                  mature_qty_ind;
  public short                                  rate_ind;
  public short                                  cf_txn_num_ind;
  public short                                  cf_rate_ind;
  public short                                  cf_date_ind;
  public short                                  cf_time_ind;
  public short                                  status_ind;
  public short                                  reg_ind_ind;
  public short                                  reg_limit_ind;
  public short                                  slr_ind_ind;
  public short                                  slr_limit_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxDtxnTabObj(){}


  public CxDtxnTabObj
  (
    String org_id,
    String txn_num,
    String txn_date,
    String txn_time,
    String txn_type,
    String member_id,
    String member_name,
    String contract_id,
    String symbol_cd,
    int qty,
    int mature_qty,
    double rate,
    String cf_txn_num,
    double cf_rate,
    String cf_date,
    String cf_time,
    String status,
    String reg_ind,
    double reg_limit,
    String slr_ind,
    double slr_limit,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.txn_num = txn_num;
     this.txn_date = txn_date;
     this.txn_time = txn_time;
     this.txn_type = txn_type;
     this.member_id = member_id;
     this.member_name = member_name;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.qty = qty;
     this.mature_qty = mature_qty;
     this.rate = rate;
     this.cf_txn_num = cf_txn_num;
     this.cf_rate = cf_rate;
     this.cf_date = cf_date;
     this.cf_time = cf_time;
     this.status = status;
     this.reg_ind = reg_ind;
     this.reg_limit = reg_limit;
     this.slr_ind = slr_ind;
     this.slr_limit = slr_limit;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String gettxn_num()                          { return txn_num; }
  public String gettxn_date()                          { return txn_date; }
  public String gettxn_time()                          { return txn_time; }
  public String gettxn_type()                          { return txn_type; }
  public String getmember_id()                         { return member_id; }
  public String getmember_name()                        { return member_name; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public int getqty()                              { return qty; }
  public int getmature_qty()                          { return mature_qty; }
  public double getrate()                            { return rate; }
  public String getcf_txn_num()                         { return cf_txn_num; }
  public double getcf_rate()                          { return cf_rate; }
  public String getcf_date()                          { return cf_date; }
  public String getcf_time()                          { return cf_time; }
  public String getstatus()                           { return status; }
  public String getreg_ind()                          { return reg_ind; }
  public double getreg_limit()                         { return reg_limit; }
  public String getslr_ind()                          { return slr_ind; }
  public double getslr_limit()                         { return slr_limit; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  settxn_num(String txn_num )                   { this.txn_num = txn_num; }
  public void  settxn_date(String txn_date )                  { this.txn_date = txn_date; }
  public void  settxn_time(String txn_time )                  { this.txn_time = txn_time; }
  public void  settxn_type(String txn_type )                  { this.txn_type = txn_type; }
  public void  setmember_id(String member_id )                 { this.member_id = member_id; }
  public void  setmember_name(String member_name )               { this.member_name = member_name; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setqty(int qty )                         { this.qty = qty; }
  public void  setmature_qty(int mature_qty )                  { this.mature_qty = mature_qty; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setcf_txn_num(String cf_txn_num )                { this.cf_txn_num = cf_txn_num; }
  public void  setcf_rate(double cf_rate )                   { this.cf_rate = cf_rate; }
  public void  setcf_date(String cf_date )                   { this.cf_date = cf_date; }
  public void  setcf_time(String cf_time )                   { this.cf_time = cf_time; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setreg_ind(String reg_ind )                   { this.reg_ind = reg_ind; }
  public void  setreg_limit(double reg_limit )                 { this.reg_limit = reg_limit; }
  public void  setslr_ind(String slr_ind )                   { this.slr_ind = slr_ind; }
  public void  setslr_limit(double slr_limit )                 { this.slr_limit = slr_limit; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}