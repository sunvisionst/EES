package sstdb.cx.CxMember;


public class CxMemberTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 member_id;
  public String                                 member_name;
  public String                                 link_member_id;
  public String                                 member_type;
  public String                                 role_type;
  public String                                 remark;
  public int                                  pswd_change_cnt;
  public String                                 pswd_0;
  public String                                 pswd_1;
  public String                                 pswd_2;
  public String                                 pswd_3;
  public String                                 pswd_4;
  public String                                 pswd_5;
  public String                                 pswd_6;
  public String                                 pswd_7;
  public String                                 pswd_8;
  public String                                 pswd_9;
  public String                                 pswd_10;
  public String                                 pswd_11;
  public String                                 pswd_12;
  public String                                 pswd_effective_date;
  public short                                 expiry_period;
  public String                                 hint;
  public String                                 hint_ans;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 city;
  public String                                 state;
  public String                                 zip;
  public String                                 country;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;
  public String                                 auth_rep_name;
  public String                                 auth_rep_father_name;
  public String                                 auth_rep_phone_list;
  public double                                 pd_bal;
  public double                                 cd_bal;
  public double                                 cd_dr;
  public double                                 cd_cr;
  public double                                 cr_limit;
  public int                                  num_client_limit;





  public short                                  org_id_ind;
  public short                                  member_id_ind;
  public short                                  member_name_ind;
  public short                                  link_member_id_ind;
  public short                                  member_type_ind;
  public short                                  role_type_ind;
  public short                                  remark_ind;
  public short                                  pswd_change_cnt_ind;
  public short                                  pswd_0_ind;
  public short                                  pswd_1_ind;
  public short                                  pswd_2_ind;
  public short                                  pswd_3_ind;
  public short                                  pswd_4_ind;
  public short                                  pswd_5_ind;
  public short                                  pswd_6_ind;
  public short                                  pswd_7_ind;
  public short                                  pswd_8_ind;
  public short                                  pswd_9_ind;
  public short                                  pswd_10_ind;
  public short                                  pswd_11_ind;
  public short                                  pswd_12_ind;
  public short                                  pswd_effective_date_ind;
  public short                                  expiry_period_ind;
  public short                                  hint_ind;
  public short                                  hint_ans_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  city_ind;
  public short                                  state_ind;
  public short                                  zip_ind;
  public short                                  country_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;
  public short                                  auth_rep_name_ind;
  public short                                  auth_rep_father_name_ind;
  public short                                  auth_rep_phone_list_ind;
  public short                                  pd_bal_ind;
  public short                                  cd_bal_ind;
  public short                                  cd_dr_ind;
  public short                                  cd_cr_ind;
  public short                                  cr_limit_ind;
  public short                                  num_client_limit_ind;


  public CxMemberTabObj(){}


  public CxMemberTabObj
  (
    String org_id,
    String member_id,
    String member_name,
    String link_member_id,
    String member_type,
    String role_type,
    String remark,
    int pswd_change_cnt,
    String pswd_0,
    String pswd_1,
    String pswd_2,
    String pswd_3,
    String pswd_4,
    String pswd_5,
    String pswd_6,
    String pswd_7,
    String pswd_8,
    String pswd_9,
    String pswd_10,
    String pswd_11,
    String pswd_12,
    String pswd_effective_date,
    short expiry_period,
    String hint,
    String hint_ans,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String address_1,
    String address_2,
    String city,
    String state,
    String zip,
    String country,
    String phone_list,
    String email_list,
    String fax_list,
    String auth_rep_name,
    String auth_rep_father_name,
    String auth_rep_phone_list,
    double pd_bal,
    double cd_bal,
    double cd_dr,
    double cd_cr,
    double cr_limit,
    int num_client_limit
  )
  {
     this.org_id = org_id;
     this.member_id = member_id;
     this.member_name = member_name;
     this.link_member_id = link_member_id;
     this.member_type = member_type;
     this.role_type = role_type;
     this.remark = remark;
     this.pswd_change_cnt = pswd_change_cnt;
     this.pswd_0 = pswd_0;
     this.pswd_1 = pswd_1;
     this.pswd_2 = pswd_2;
     this.pswd_3 = pswd_3;
     this.pswd_4 = pswd_4;
     this.pswd_5 = pswd_5;
     this.pswd_6 = pswd_6;
     this.pswd_7 = pswd_7;
     this.pswd_8 = pswd_8;
     this.pswd_9 = pswd_9;
     this.pswd_10 = pswd_10;
     this.pswd_11 = pswd_11;
     this.pswd_12 = pswd_12;
     this.pswd_effective_date = pswd_effective_date;
     this.expiry_period = expiry_period;
     this.hint = hint;
     this.hint_ans = hint_ans;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.city = city;
     this.state = state;
     this.zip = zip;
     this.country = country;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
     this.auth_rep_name = auth_rep_name;
     this.auth_rep_father_name = auth_rep_father_name;
     this.auth_rep_phone_list = auth_rep_phone_list;
     this.pd_bal = pd_bal;
     this.cd_bal = cd_bal;
     this.cd_dr = cd_dr;
     this.cd_cr = cd_cr;
     this.cr_limit = cr_limit;
     this.num_client_limit = num_client_limit;
  }

  public String getorg_id()                           { return org_id; }
  public String getmember_id()                         { return member_id; }
  public String getmember_name()                        { return member_name; }
  public String getlink_member_id()                       { return link_member_id; }
  public String getmember_type()                        { return member_type; }
  public String getrole_type()                         { return role_type; }
  public String getremark()                           { return remark; }
  public int getpswd_change_cnt()                        { return pswd_change_cnt; }
  public String getpswd_0()                           { return pswd_0; }
  public String getpswd_1()                           { return pswd_1; }
  public String getpswd_2()                           { return pswd_2; }
  public String getpswd_3()                           { return pswd_3; }
  public String getpswd_4()                           { return pswd_4; }
  public String getpswd_5()                           { return pswd_5; }
  public String getpswd_6()                           { return pswd_6; }
  public String getpswd_7()                           { return pswd_7; }
  public String getpswd_8()                           { return pswd_8; }
  public String getpswd_9()                           { return pswd_9; }
  public String getpswd_10()                          { return pswd_10; }
  public String getpswd_11()                          { return pswd_11; }
  public String getpswd_12()                          { return pswd_12; }
  public String getpswd_effective_date()                    { return pswd_effective_date; }
  public short getexpiry_period()                        { return expiry_period; }
  public String gethint()                            { return hint; }
  public String gethint_ans()                          { return hint_ans; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getcity()                            { return city; }
  public String getstate()                           { return state; }
  public String getzip()                            { return zip; }
  public String getcountry()                          { return country; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }
  public String getauth_rep_name()                       { return auth_rep_name; }
  public String getauth_rep_father_name()                    { return auth_rep_father_name; }
  public String getauth_rep_phone_list()                    { return auth_rep_phone_list; }
  public double getpd_bal()                           { return pd_bal; }
  public double getcd_bal()                           { return cd_bal; }
  public double getcd_dr()                           { return cd_dr; }
  public double getcd_cr()                           { return cd_cr; }
  public double getcr_limit()                          { return cr_limit; }
  public int getnum_client_limit()                       { return num_client_limit; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setmember_id(String member_id )                 { this.member_id = member_id; }
  public void  setmember_name(String member_name )               { this.member_name = member_name; }
  public void  setlink_member_id(String link_member_id )            { this.link_member_id = link_member_id; }
  public void  setmember_type(String member_type )               { this.member_type = member_type; }
  public void  setrole_type(String role_type )                 { this.role_type = role_type; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setpswd_change_cnt(int pswd_change_cnt )             { this.pswd_change_cnt = pswd_change_cnt; }
  public void  setpswd_0(String pswd_0 )                    { this.pswd_0 = pswd_0; }
  public void  setpswd_1(String pswd_1 )                    { this.pswd_1 = pswd_1; }
  public void  setpswd_2(String pswd_2 )                    { this.pswd_2 = pswd_2; }
  public void  setpswd_3(String pswd_3 )                    { this.pswd_3 = pswd_3; }
  public void  setpswd_4(String pswd_4 )                    { this.pswd_4 = pswd_4; }
  public void  setpswd_5(String pswd_5 )                    { this.pswd_5 = pswd_5; }
  public void  setpswd_6(String pswd_6 )                    { this.pswd_6 = pswd_6; }
  public void  setpswd_7(String pswd_7 )                    { this.pswd_7 = pswd_7; }
  public void  setpswd_8(String pswd_8 )                    { this.pswd_8 = pswd_8; }
  public void  setpswd_9(String pswd_9 )                    { this.pswd_9 = pswd_9; }
  public void  setpswd_10(String pswd_10 )                   { this.pswd_10 = pswd_10; }
  public void  setpswd_11(String pswd_11 )                   { this.pswd_11 = pswd_11; }
  public void  setpswd_12(String pswd_12 )                   { this.pswd_12 = pswd_12; }
  public void  setpswd_effective_date(String pswd_effective_date )       { this.pswd_effective_date = pswd_effective_date; }
  public void  setexpiry_period(short expiry_period )              { this.expiry_period = expiry_period; }
  public void  sethint(String hint )                      { this.hint = hint; }
  public void  sethint_ans(String hint_ans )                  { this.hint_ans = hint_ans; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setcity(String city )                      { this.city = city; }
  public void  setstate(String state )                     { this.state = state; }
  public void  setzip(String zip )                       { this.zip = zip; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
  public void  setauth_rep_name(String auth_rep_name )             { this.auth_rep_name = auth_rep_name; }
  public void  setauth_rep_father_name(String auth_rep_father_name )      { this.auth_rep_father_name = auth_rep_father_name; }
  public void  setauth_rep_phone_list(String auth_rep_phone_list )       { this.auth_rep_phone_list = auth_rep_phone_list; }
  public void  setpd_bal(double pd_bal )                    { this.pd_bal = pd_bal; }
  public void  setcd_bal(double cd_bal )                    { this.cd_bal = cd_bal; }
  public void  setcd_dr(double cd_dr )                     { this.cd_dr = cd_dr; }
  public void  setcd_cr(double cd_cr )                     { this.cd_cr = cd_cr; }
  public void  setcr_limit(double cr_limit )                  { this.cr_limit = cr_limit; }
  public void  setnum_client_limit(int num_client_limit )            { this.num_client_limit = num_client_limit; }
}