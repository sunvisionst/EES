package sstdb.cx.CxOrder;


public class CxOrderPkeyObj
{
  public String                                 org_id;
  public String                                 ord_num;
  public int                                  ord_seq_num;
}