package sstdb.cx.CxMember;

import sstdb.cx.CxMember.CxMemberTabObj;
import sstdb.cx.CxMember.CxMemberPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxMemberMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxMemberMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxMemberMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxMemberTabObj
               ( 
                 CxMemberTabObj  outCxMemberTabObj
               )
  {
  
     outCxMemberTabObj.org_id = ""; 
     outCxMemberTabObj.member_id = ""; 
     outCxMemberTabObj.member_name = ""; 
     outCxMemberTabObj.link_member_id = ""; 
     outCxMemberTabObj.member_type = ""; 
     outCxMemberTabObj.role_type = ""; 
     outCxMemberTabObj.remark = ""; 
     outCxMemberTabObj.pswd_change_cnt = (int)0; 
     outCxMemberTabObj.pswd_0 = ""; 
     outCxMemberTabObj.pswd_1 = ""; 
     outCxMemberTabObj.pswd_2 = ""; 
     outCxMemberTabObj.pswd_3 = ""; 
     outCxMemberTabObj.pswd_4 = ""; 
     outCxMemberTabObj.pswd_5 = ""; 
     outCxMemberTabObj.pswd_6 = ""; 
     outCxMemberTabObj.pswd_7 = ""; 
     outCxMemberTabObj.pswd_8 = ""; 
     outCxMemberTabObj.pswd_9 = ""; 
     outCxMemberTabObj.pswd_10 = ""; 
     outCxMemberTabObj.pswd_11 = ""; 
     outCxMemberTabObj.pswd_12 = ""; 
     outCxMemberTabObj.pswd_effective_date = ""; 
     outCxMemberTabObj.expiry_period = (int)0; 
     outCxMemberTabObj.hint = ""; 
     outCxMemberTabObj.hint_ans = ""; 
     outCxMemberTabObj.status = ""; 
     outCxMemberTabObj.rec_cre_date = ""; 
     outCxMemberTabObj.rec_cre_time = ""; 
     outCxMemberTabObj.rec_upd_date = ""; 
     outCxMemberTabObj.rec_upd_time = ""; 
     outCxMemberTabObj.address_1 = ""; 
     outCxMemberTabObj.address_2 = ""; 
     outCxMemberTabObj.city = ""; 
     outCxMemberTabObj.state = ""; 
     outCxMemberTabObj.zip = ""; 
     outCxMemberTabObj.country = ""; 
     outCxMemberTabObj.phone_list = ""; 
     outCxMemberTabObj.email_list = ""; 
     outCxMemberTabObj.fax_list = ""; 
     outCxMemberTabObj.auth_rep_name = ""; 
     outCxMemberTabObj.auth_rep_father_name = ""; 
     outCxMemberTabObj.auth_rep_phone_list = ""; 
     outCxMemberTabObj.pd_bal = (double)0.00; 
     outCxMemberTabObj.cd_bal = (double)0.00; 
     outCxMemberTabObj.cd_dr = (double)0.00; 
     outCxMemberTabObj.cd_cr = (double)0.00; 
     outCxMemberTabObj.cr_limit = (double)0.00; 
     outCxMemberTabObj.num_client_limit = (int)0; 
  }





  public void guiDateConvCxMemberTabObj
               ( 
                 CxMemberTabObj  inCxMemberTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxMemberTabObj.pswd_effective_date != null && inCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            inCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);

          if ( inCxMemberTabObj.rec_cre_date != null && inCxMemberTabObj.rec_cre_date.length() > 0 ) 
            inCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxMemberTabObj.rec_upd_date != null && inCxMemberTabObj.rec_upd_date.length() > 0 ) 
            inCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxMemberByTabObj
               ( 
                 CxMemberTabObj  inCxMemberTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxMemberTabObjArrCtx  = new ArrayList(); 
    lCxMemberTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxMemberTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxMemberTabObjArrCtx.add(inCxMemberTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxMemberTabObjArrCtx.size();  lRecNum++ )
      {
        CxMemberTabObj lCxMemberTabObj = new CxMemberTabObj();
        lCxMemberTabObj = (CxMemberTabObj)lCxMemberTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxMemberTabObj.org_id.equals(lCxMemberTabObj.org_id) &&
              lCxMemberTabObj.member_id.equals(lCxMemberTabObj.member_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxMemberTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxMemberTabObjArrCtx.set(lRecNum, inCxMemberTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxMemberTabObjArrCtx",lCxMemberTabObjArrCtx);
  }





  public void sortCxMemberTabObjArr
               ( 
                 ArrayList  inCxMemberTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxMemberTabObjArr  = new ArrayList(); 
     lCxMemberTabObjArr = inCxMemberTabObjArr; 
     List lCxMemberTabObjList  = new ArrayList(lCxMemberTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxMemberTabObjArr.size();  lRecNum++ )
     {
       CxMemberTabObj  lCxMemberTabObj = new CxMemberTabObj(); 
       lCxMemberTabObj = (CxMemberTabObj)lCxMemberTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxMemberTabObj.member_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.member_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.member_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.member_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("link_member_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxMemberTabObj.link_member_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.link_member_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.member_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.member_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("role_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.role_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.role_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_change_cnt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxMemberTabObj.pswd_change_cnt).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_change_cnt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_0") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_0.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_0+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_9") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_9.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_9+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_10") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_10.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_10+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_11") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_11.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_11+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_12") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.pswd_12.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_12+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_effective_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxMemberTabObj.pswd_effective_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pswd_effective_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("expiry_period") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (3 - Short.toString(lCxMemberTabObj.expiry_period).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.expiry_period+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("hint") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lCxMemberTabObj.hint.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.hint+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("hint_ans") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lCxMemberTabObj.hint_ans.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.hint_ans+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxMemberTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxMemberTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxMemberTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxMemberTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxMemberTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxMemberTabObj.city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxMemberTabObj.country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.email_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.email_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fax_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.fax_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.fax_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("auth_rep_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.auth_rep_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.auth_rep_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("auth_rep_father_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.auth_rep_father_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.auth_rep_father_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("auth_rep_phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxMemberTabObj.auth_rep_phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.auth_rep_phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pd_bal") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxMemberTabObj.pd_bal).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.pd_bal+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cd_bal") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxMemberTabObj.cd_bal).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.cd_bal+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cd_dr") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxMemberTabObj.cd_dr).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.cd_dr+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cd_cr") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxMemberTabObj.cd_cr).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.cd_cr+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cr_limit") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxMemberTabObj.cr_limit).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.cr_limit+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("num_client_limit") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxMemberTabObj.num_client_limit).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxMemberTabObj.num_client_limit+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxMemberTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxMemberTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxMemberTabObjList ); 
     ArrayList lCxMemberTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxMemberTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxMemberTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxMemberTabObjArrSorted.add( (CxMemberTabObj)lCxMemberTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxMemberTabObjArr.size();  lRecNum++ )
     {
       inCxMemberTabObjArr.set( lRecNum, (CxMemberTabObj)lCxMemberTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxMemberTabObj
               ( 
                 CxMemberTabObj  inCxMemberTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxMemberTabObj.pswd_effective_date != null && inCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            inCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.pswd_effective_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_cre_date != null && inCxMemberTabObj.rec_cre_date.length() > 0 ) 
            inCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_upd_date != null && inCxMemberTabObj.rec_upd_date.length() > 0 ) 
            inCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLinkMemberId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LINK_MEMBER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRoleType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROLE_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswdChangeCnt
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_CHANGE_CNT";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd0
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_0";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_3";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_4";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_5";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_6";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_7";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_8";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd9
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_9";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd10
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_10";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd11
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_11";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd12
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_12";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswdEffectiveDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_EFFECTIVE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpiryPeriod
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 3 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXPIRY_PERIOD";
      String lErrorReason = "Size Greater Than 3";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHint
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HINT";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHintAns
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HINT_ANS";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCity
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeState
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeZip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFaxList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FAX_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAuthRepName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AUTH_REP_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAuthRepFatherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AUTH_REP_FATHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAuthRepPhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AUTH_REP_PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePdBal
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PD_BAL";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCdBal
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CD_BAL";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCdDr
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CD_DR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCdCr
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CD_CR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCrLimit
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CR_LIMIT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNumClientLimit
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NUM_CLIENT_LIMIT";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxMemberCount
               ( String inCxMemberWhereText
               )
  {
    sop("gtCxMemberCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberCount
               ( String inCxMemberWhereText
               , String inCxMemberSelectFieldList
               )
  {
    sop("gtCxMemberCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxMemberSelectFieldList+" AS count "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberRecByPkey
               ( CxMemberPkeyObj inCxMemberPkeyObj
               , CxMemberTabObj  outCxMemberTabObj
               )
  {
    sop("gtCxMemberRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "link_member_id, "+
                                 "member_type, "+
                                 "role_type, "+
                                 "remark, "+
                                 "pswd_change_cnt, "+
                                 "pswd_0, "+
                                 "pswd_1, "+
                                 "pswd_2, "+
                                 "pswd_3, "+
                                 "pswd_4, "+
                                 "pswd_5, "+
                                 "pswd_6, "+
                                 "pswd_7, "+
                                 "pswd_8, "+
                                 "pswd_9, "+
                                 "pswd_10, "+
                                 "pswd_11, "+
                                 "pswd_12, "+
                                 "pswd_effective_date, "+
                                 "expiry_period, "+
                                 "hint, "+
                                 "hint_ans, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "auth_rep_name, "+
                                 "auth_rep_father_name, "+
                                 "auth_rep_phone_list, "+
                                 "pd_bal, "+
                                 "cd_bal, "+
                                 "cd_dr, "+
                                 "cd_cr, "+
                                 "cr_limit, "+
                                 "num_client_limit "+
                         "FROM   CX_MEMBER " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxMemberPkeyObj.org_id+"' and "+
                              "member_id = "+"'"+inCxMemberPkeyObj.member_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxMemberTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxMemberTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxMemberTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxMemberTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxMemberTabObj.link_member_id  =  lResultSet.getString("LINK_MEMBER_ID");
          outCxMemberTabObj.member_type  =  lResultSet.getString("MEMBER_TYPE");
          outCxMemberTabObj.role_type  =  lResultSet.getString("ROLE_TYPE");
          outCxMemberTabObj.remark  =  lResultSet.getString("REMARK");
          outCxMemberTabObj.pswd_change_cnt  =  lResultSet.getInt("PSWD_CHANGE_CNT");
          outCxMemberTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outCxMemberTabObj.pswd_1  =  lResultSet.getString("PSWD_1");
          outCxMemberTabObj.pswd_2  =  lResultSet.getString("PSWD_2");
          outCxMemberTabObj.pswd_3  =  lResultSet.getString("PSWD_3");
          outCxMemberTabObj.pswd_4  =  lResultSet.getString("PSWD_4");
          outCxMemberTabObj.pswd_5  =  lResultSet.getString("PSWD_5");
          outCxMemberTabObj.pswd_6  =  lResultSet.getString("PSWD_6");
          outCxMemberTabObj.pswd_7  =  lResultSet.getString("PSWD_7");
          outCxMemberTabObj.pswd_8  =  lResultSet.getString("PSWD_8");
          outCxMemberTabObj.pswd_9  =  lResultSet.getString("PSWD_9");
          outCxMemberTabObj.pswd_10  =  lResultSet.getString("PSWD_10");
          outCxMemberTabObj.pswd_11  =  lResultSet.getString("PSWD_11");
          outCxMemberTabObj.pswd_12  =  lResultSet.getString("PSWD_12");
          outCxMemberTabObj.pswd_effective_date  =  lResultSet.getString("PSWD_EFFECTIVE_DATE");

          if ( outCxMemberTabObj.pswd_effective_date != null && outCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            outCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);
          outCxMemberTabObj.expiry_period  =  lResultSet.getShort("EXPIRY_PERIOD");
          outCxMemberTabObj.hint  =  lResultSet.getString("HINT");
          outCxMemberTabObj.hint_ans  =  lResultSet.getString("HINT_ANS");
          outCxMemberTabObj.status  =  lResultSet.getString("STATUS");
          outCxMemberTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxMemberTabObj.rec_cre_date != null && outCxMemberTabObj.rec_cre_date.length() > 0 ) 
            outCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxMemberTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxMemberTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxMemberTabObj.rec_upd_date != null && outCxMemberTabObj.rec_upd_date.length() > 0 ) 
            outCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxMemberTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outCxMemberTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outCxMemberTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outCxMemberTabObj.city  =  lResultSet.getString("CITY");
          outCxMemberTabObj.state  =  lResultSet.getString("STATE");
          outCxMemberTabObj.zip  =  lResultSet.getString("ZIP");
          outCxMemberTabObj.country  =  lResultSet.getString("COUNTRY");
          outCxMemberTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outCxMemberTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outCxMemberTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outCxMemberTabObj.auth_rep_name  =  lResultSet.getString("AUTH_REP_NAME");
          outCxMemberTabObj.auth_rep_father_name  =  lResultSet.getString("AUTH_REP_FATHER_NAME");
          outCxMemberTabObj.auth_rep_phone_list  =  lResultSet.getString("AUTH_REP_PHONE_LIST");
          outCxMemberTabObj.pd_bal  =  lResultSet.getDouble("PD_BAL");
          outCxMemberTabObj.cd_bal  =  lResultSet.getDouble("CD_BAL");
          outCxMemberTabObj.cd_dr  =  lResultSet.getDouble("CD_DR");
          outCxMemberTabObj.cd_cr  =  lResultSet.getDouble("CD_CR");
          outCxMemberTabObj.cr_limit  =  lResultSet.getDouble("CR_LIMIT");
          outCxMemberTabObj.num_client_limit  =  lResultSet.getInt("NUM_CLIENT_LIMIT");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxMemberTabObj( outCxMemberTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberArr
               ( CxMemberPkeyObj inCxMemberPkeyObj
               , ArrayList  outCxMemberTabObjArr
               )
  {
    sop("gtCxMemberArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "link_member_id, "+
                                 "member_type, "+
                                 "role_type, "+
                                 "remark, "+
                                 "pswd_change_cnt, "+
                                 "pswd_0, "+
                                 "pswd_1, "+
                                 "pswd_2, "+
                                 "pswd_3, "+
                                 "pswd_4, "+
                                 "pswd_5, "+
                                 "pswd_6, "+
                                 "pswd_7, "+
                                 "pswd_8, "+
                                 "pswd_9, "+
                                 "pswd_10, "+
                                 "pswd_11, "+
                                 "pswd_12, "+
                                 "pswd_effective_date, "+
                                 "expiry_period, "+
                                 "hint, "+
                                 "hint_ans, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "auth_rep_name, "+
                                 "auth_rep_father_name, "+
                                 "auth_rep_phone_list, "+
                                 "pd_bal, "+
                                 "cd_bal, "+
                                 "cd_dr, "+
                                 "cd_cr, "+
                                 "cr_limit, "+
                                 "num_client_limit "+
                         "FROM   CX_MEMBER";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxMemberTabObj  lCxMemberTabObj = new CxMemberTabObj();
          lCxMemberTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxMemberTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxMemberTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxMemberTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxMemberTabObj.link_member_id  =  lResultSet.getString("LINK_MEMBER_ID");
          lCxMemberTabObj.member_type  =  lResultSet.getString("MEMBER_TYPE");
          lCxMemberTabObj.role_type  =  lResultSet.getString("ROLE_TYPE");
          lCxMemberTabObj.remark  =  lResultSet.getString("REMARK");
          lCxMemberTabObj.pswd_change_cnt  =  lResultSet.getInt("PSWD_CHANGE_CNT");
          lCxMemberTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lCxMemberTabObj.pswd_1  =  lResultSet.getString("PSWD_1");
          lCxMemberTabObj.pswd_2  =  lResultSet.getString("PSWD_2");
          lCxMemberTabObj.pswd_3  =  lResultSet.getString("PSWD_3");
          lCxMemberTabObj.pswd_4  =  lResultSet.getString("PSWD_4");
          lCxMemberTabObj.pswd_5  =  lResultSet.getString("PSWD_5");
          lCxMemberTabObj.pswd_6  =  lResultSet.getString("PSWD_6");
          lCxMemberTabObj.pswd_7  =  lResultSet.getString("PSWD_7");
          lCxMemberTabObj.pswd_8  =  lResultSet.getString("PSWD_8");
          lCxMemberTabObj.pswd_9  =  lResultSet.getString("PSWD_9");
          lCxMemberTabObj.pswd_10  =  lResultSet.getString("PSWD_10");
          lCxMemberTabObj.pswd_11  =  lResultSet.getString("PSWD_11");
          lCxMemberTabObj.pswd_12  =  lResultSet.getString("PSWD_12");
          lCxMemberTabObj.pswd_effective_date  =  lResultSet.getString("PSWD_EFFECTIVE_DATE");

          if ( lCxMemberTabObj.pswd_effective_date != null && lCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            lCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);
          lCxMemberTabObj.expiry_period  =  lResultSet.getShort("EXPIRY_PERIOD");
          lCxMemberTabObj.hint  =  lResultSet.getString("HINT");
          lCxMemberTabObj.hint_ans  =  lResultSet.getString("HINT_ANS");
          lCxMemberTabObj.status  =  lResultSet.getString("STATUS");
          lCxMemberTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxMemberTabObj.rec_cre_date != null && lCxMemberTabObj.rec_cre_date.length() > 0 ) 
            lCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxMemberTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxMemberTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxMemberTabObj.rec_upd_date != null && lCxMemberTabObj.rec_upd_date.length() > 0 ) 
            lCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxMemberTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lCxMemberTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lCxMemberTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lCxMemberTabObj.city  =  lResultSet.getString("CITY");
          lCxMemberTabObj.state  =  lResultSet.getString("STATE");
          lCxMemberTabObj.zip  =  lResultSet.getString("ZIP");
          lCxMemberTabObj.country  =  lResultSet.getString("COUNTRY");
          lCxMemberTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lCxMemberTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lCxMemberTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lCxMemberTabObj.auth_rep_name  =  lResultSet.getString("AUTH_REP_NAME");
          lCxMemberTabObj.auth_rep_father_name  =  lResultSet.getString("AUTH_REP_FATHER_NAME");
          lCxMemberTabObj.auth_rep_phone_list  =  lResultSet.getString("AUTH_REP_PHONE_LIST");
          lCxMemberTabObj.pd_bal  =  lResultSet.getDouble("PD_BAL");
          lCxMemberTabObj.cd_bal  =  lResultSet.getDouble("CD_BAL");
          lCxMemberTabObj.cd_dr  =  lResultSet.getDouble("CD_DR");
          lCxMemberTabObj.cd_cr  =  lResultSet.getDouble("CD_CR");
          lCxMemberTabObj.cr_limit  =  lResultSet.getDouble("CR_LIMIT");
          lCxMemberTabObj.num_client_limit  =  lResultSet.getInt("NUM_CLIENT_LIMIT");

          removeNullCxMemberTabObj( lCxMemberTabObj );

          outCxMemberTabObjArr.add(  lCxMemberTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxMemberTabObjArr != null && outCxMemberTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxMemberArr2XML
               ( String inCxMemberWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxMemberArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxMember>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_id") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_ID>" +  lResultSet.getString("MEMBER_ID") +   "</MEMBER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_name") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_NAME>" +  lResultSet.getString("MEMBER_NAME") +   "</MEMBER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("link_member_id") )
              lXmlBuffer = lXmlBuffer +   "<LINK_MEMBER_ID>" +  lResultSet.getString("LINK_MEMBER_ID") +   "</LINK_MEMBER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_type") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_TYPE>" +  lResultSet.getString("MEMBER_TYPE") +   "</MEMBER_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("role_type") )
              lXmlBuffer = lXmlBuffer +   "<ROLE_TYPE>" +  lResultSet.getString("ROLE_TYPE") +   "</ROLE_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_change_cnt") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_CHANGE_CNT>" +  lResultSet.getInt("PSWD_CHANGE_CNT") +   "</PSWD_CHANGE_CNT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_0") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_0>" +  lResultSet.getString("PSWD_0") +   "</PSWD_0>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_1") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_1>" +  lResultSet.getString("PSWD_1") +   "</PSWD_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_2") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_2>" +  lResultSet.getString("PSWD_2") +   "</PSWD_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_3") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_3>" +  lResultSet.getString("PSWD_3") +   "</PSWD_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_4") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_4>" +  lResultSet.getString("PSWD_4") +   "</PSWD_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_5") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_5>" +  lResultSet.getString("PSWD_5") +   "</PSWD_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_6") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_6>" +  lResultSet.getString("PSWD_6") +   "</PSWD_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_7") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_7>" +  lResultSet.getString("PSWD_7") +   "</PSWD_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_8") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_8>" +  lResultSet.getString("PSWD_8") +   "</PSWD_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_9") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_9>" +  lResultSet.getString("PSWD_9") +   "</PSWD_9>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_10") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_10>" +  lResultSet.getString("PSWD_10") +   "</PSWD_10>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_11") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_11>" +  lResultSet.getString("PSWD_11") +   "</PSWD_11>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_12") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_12>" +  lResultSet.getString("PSWD_12") +   "</PSWD_12>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_effective_date") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_EFFECTIVE_DATE>" +  lResultSet.getString("PSWD_EFFECTIVE_DATE") +   "</PSWD_EFFECTIVE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("expiry_period") )
              lXmlBuffer = lXmlBuffer +   "<EXPIRY_PERIOD>" +  lResultSet.getShort("EXPIRY_PERIOD") +   "</EXPIRY_PERIOD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hint") )
              lXmlBuffer = lXmlBuffer +   "<HINT>" +  lResultSet.getString("HINT") +   "</HINT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hint_ans") )
              lXmlBuffer = lXmlBuffer +   "<HINT_ANS>" +  lResultSet.getString("HINT_ANS") +   "</HINT_ANS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_1") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_1>" +  lResultSet.getString("ADDRESS_1") +   "</ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_2") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_2>" +  lResultSet.getString("ADDRESS_2") +   "</ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("city") )
              lXmlBuffer = lXmlBuffer +   "<CITY>" +  lResultSet.getString("CITY") +   "</CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("state") )
              lXmlBuffer = lXmlBuffer +   "<STATE>" +  lResultSet.getString("STATE") +   "</STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("zip") )
              lXmlBuffer = lXmlBuffer +   "<ZIP>" +  lResultSet.getString("ZIP") +   "</ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY>" +  lResultSet.getString("COUNTRY") +   "</COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone_list") )
              lXmlBuffer = lXmlBuffer +   "<PHONE_LIST>" +  lResultSet.getString("PHONE_LIST") +   "</PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_list") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_LIST>" +  lResultSet.getString("EMAIL_LIST") +   "</EMAIL_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fax_list") )
              lXmlBuffer = lXmlBuffer +   "<FAX_LIST>" +  lResultSet.getString("FAX_LIST") +   "</FAX_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("auth_rep_name") )
              lXmlBuffer = lXmlBuffer +   "<AUTH_REP_NAME>" +  lResultSet.getString("AUTH_REP_NAME") +   "</AUTH_REP_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("auth_rep_father_name") )
              lXmlBuffer = lXmlBuffer +   "<AUTH_REP_FATHER_NAME>" +  lResultSet.getString("AUTH_REP_FATHER_NAME") +   "</AUTH_REP_FATHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("auth_rep_phone_list") )
              lXmlBuffer = lXmlBuffer +   "<AUTH_REP_PHONE_LIST>" +  lResultSet.getString("AUTH_REP_PHONE_LIST") +   "</AUTH_REP_PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pd_bal") )
              lXmlBuffer = lXmlBuffer +   "<PD_BAL>" +  lResultSet.getDouble("PD_BAL") +   "</PD_BAL>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cd_bal") )
              lXmlBuffer = lXmlBuffer +   "<CD_BAL>" +  lResultSet.getDouble("CD_BAL") +   "</CD_BAL>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cd_dr") )
              lXmlBuffer = lXmlBuffer +   "<CD_DR>" +  lResultSet.getDouble("CD_DR") +   "</CD_DR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cd_cr") )
              lXmlBuffer = lXmlBuffer +   "<CD_CR>" +  lResultSet.getDouble("CD_CR") +   "</CD_CR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cr_limit") )
              lXmlBuffer = lXmlBuffer +   "<CR_LIMIT>" +  lResultSet.getDouble("CR_LIMIT") +   "</CR_LIMIT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("num_client_limit") )
              lXmlBuffer = lXmlBuffer +   "<NUM_CLIENT_LIMIT>" +  lResultSet.getInt("NUM_CLIENT_LIMIT") +   "</NUM_CLIENT_LIMIT>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxMember>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxMemberRecByRowid
               ( String inRowId
               , CxMemberTabObj  outCxMemberTabObj
               )
  {
    sop("gtCxMemberRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "link_member_id, "+
                                 "member_type, "+
                                 "role_type, "+
                                 "remark, "+
                                 "pswd_change_cnt, "+
                                 "pswd_0, "+
                                 "pswd_1, "+
                                 "pswd_2, "+
                                 "pswd_3, "+
                                 "pswd_4, "+
                                 "pswd_5, "+
                                 "pswd_6, "+
                                 "pswd_7, "+
                                 "pswd_8, "+
                                 "pswd_9, "+
                                 "pswd_10, "+
                                 "pswd_11, "+
                                 "pswd_12, "+
                                 "pswd_effective_date, "+
                                 "expiry_period, "+
                                 "hint, "+
                                 "hint_ans, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "auth_rep_name, "+
                                 "auth_rep_father_name, "+
                                 "auth_rep_phone_list, "+
                                 "pd_bal, "+
                                 "cd_bal, "+
                                 "cd_dr, "+
                                 "cd_cr, "+
                                 "cr_limit, "+
                                 "num_client_limit "+
                         "FROM   CX_MEMBER "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxMemberTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxMemberTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxMemberTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxMemberTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxMemberTabObj.link_member_id  =  lResultSet.getString("LINK_MEMBER_ID");
          outCxMemberTabObj.member_type  =  lResultSet.getString("MEMBER_TYPE");
          outCxMemberTabObj.role_type  =  lResultSet.getString("ROLE_TYPE");
          outCxMemberTabObj.remark  =  lResultSet.getString("REMARK");
          outCxMemberTabObj.pswd_change_cnt  =  lResultSet.getInt("PSWD_CHANGE_CNT");
          outCxMemberTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outCxMemberTabObj.pswd_1  =  lResultSet.getString("PSWD_1");
          outCxMemberTabObj.pswd_2  =  lResultSet.getString("PSWD_2");
          outCxMemberTabObj.pswd_3  =  lResultSet.getString("PSWD_3");
          outCxMemberTabObj.pswd_4  =  lResultSet.getString("PSWD_4");
          outCxMemberTabObj.pswd_5  =  lResultSet.getString("PSWD_5");
          outCxMemberTabObj.pswd_6  =  lResultSet.getString("PSWD_6");
          outCxMemberTabObj.pswd_7  =  lResultSet.getString("PSWD_7");
          outCxMemberTabObj.pswd_8  =  lResultSet.getString("PSWD_8");
          outCxMemberTabObj.pswd_9  =  lResultSet.getString("PSWD_9");
          outCxMemberTabObj.pswd_10  =  lResultSet.getString("PSWD_10");
          outCxMemberTabObj.pswd_11  =  lResultSet.getString("PSWD_11");
          outCxMemberTabObj.pswd_12  =  lResultSet.getString("PSWD_12");
          outCxMemberTabObj.pswd_effective_date  =  lResultSet.getString("PSWD_EFFECTIVE_DATE");

          if ( outCxMemberTabObj.pswd_effective_date != null && outCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            outCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);
          outCxMemberTabObj.expiry_period  =  lResultSet.getShort("EXPIRY_PERIOD");
          outCxMemberTabObj.hint  =  lResultSet.getString("HINT");
          outCxMemberTabObj.hint_ans  =  lResultSet.getString("HINT_ANS");
          outCxMemberTabObj.status  =  lResultSet.getString("STATUS");
          outCxMemberTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxMemberTabObj.rec_cre_date != null && outCxMemberTabObj.rec_cre_date.length() > 0 ) 
            outCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxMemberTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxMemberTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxMemberTabObj.rec_upd_date != null && outCxMemberTabObj.rec_upd_date.length() > 0 ) 
            outCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxMemberTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outCxMemberTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outCxMemberTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outCxMemberTabObj.city  =  lResultSet.getString("CITY");
          outCxMemberTabObj.state  =  lResultSet.getString("STATE");
          outCxMemberTabObj.zip  =  lResultSet.getString("ZIP");
          outCxMemberTabObj.country  =  lResultSet.getString("COUNTRY");
          outCxMemberTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outCxMemberTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outCxMemberTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outCxMemberTabObj.auth_rep_name  =  lResultSet.getString("AUTH_REP_NAME");
          outCxMemberTabObj.auth_rep_father_name  =  lResultSet.getString("AUTH_REP_FATHER_NAME");
          outCxMemberTabObj.auth_rep_phone_list  =  lResultSet.getString("AUTH_REP_PHONE_LIST");
          outCxMemberTabObj.pd_bal  =  lResultSet.getDouble("PD_BAL");
          outCxMemberTabObj.cd_bal  =  lResultSet.getDouble("CD_BAL");
          outCxMemberTabObj.cd_dr  =  lResultSet.getDouble("CD_DR");
          outCxMemberTabObj.cd_cr  =  lResultSet.getDouble("CD_CR");
          outCxMemberTabObj.cr_limit  =  lResultSet.getDouble("CR_LIMIT");
          outCxMemberTabObj.num_client_limit  =  lResultSet.getInt("NUM_CLIENT_LIMIT");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxMemberTabObj( outCxMemberTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberArr
               ( String inCxMemberWhereText
               , ArrayList  outCxMemberTabObjArr
               )
  {
    sop("gtCxMemberArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "link_member_id, "+
                                 "member_type, "+
                                 "role_type, "+
                                 "remark, "+
                                 "pswd_change_cnt, "+
                                 "pswd_0, "+
                                 "pswd_1, "+
                                 "pswd_2, "+
                                 "pswd_3, "+
                                 "pswd_4, "+
                                 "pswd_5, "+
                                 "pswd_6, "+
                                 "pswd_7, "+
                                 "pswd_8, "+
                                 "pswd_9, "+
                                 "pswd_10, "+
                                 "pswd_11, "+
                                 "pswd_12, "+
                                 "pswd_effective_date, "+
                                 "expiry_period, "+
                                 "hint, "+
                                 "hint_ans, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "auth_rep_name, "+
                                 "auth_rep_father_name, "+
                                 "auth_rep_phone_list, "+
                                 "pd_bal, "+
                                 "cd_bal, "+
                                 "cd_dr, "+
                                 "cd_cr, "+
                                 "cr_limit, "+
                                 "num_client_limit "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxMemberTabObj  lCxMemberTabObj = new CxMemberTabObj();
          lCxMemberTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxMemberTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxMemberTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxMemberTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxMemberTabObj.link_member_id  =  lResultSet.getString("LINK_MEMBER_ID");
          lCxMemberTabObj.member_type  =  lResultSet.getString("MEMBER_TYPE");
          lCxMemberTabObj.role_type  =  lResultSet.getString("ROLE_TYPE");
          lCxMemberTabObj.remark  =  lResultSet.getString("REMARK");
          lCxMemberTabObj.pswd_change_cnt  =  lResultSet.getInt("PSWD_CHANGE_CNT");
          lCxMemberTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lCxMemberTabObj.pswd_1  =  lResultSet.getString("PSWD_1");
          lCxMemberTabObj.pswd_2  =  lResultSet.getString("PSWD_2");
          lCxMemberTabObj.pswd_3  =  lResultSet.getString("PSWD_3");
          lCxMemberTabObj.pswd_4  =  lResultSet.getString("PSWD_4");
          lCxMemberTabObj.pswd_5  =  lResultSet.getString("PSWD_5");
          lCxMemberTabObj.pswd_6  =  lResultSet.getString("PSWD_6");
          lCxMemberTabObj.pswd_7  =  lResultSet.getString("PSWD_7");
          lCxMemberTabObj.pswd_8  =  lResultSet.getString("PSWD_8");
          lCxMemberTabObj.pswd_9  =  lResultSet.getString("PSWD_9");
          lCxMemberTabObj.pswd_10  =  lResultSet.getString("PSWD_10");
          lCxMemberTabObj.pswd_11  =  lResultSet.getString("PSWD_11");
          lCxMemberTabObj.pswd_12  =  lResultSet.getString("PSWD_12");
          lCxMemberTabObj.pswd_effective_date  =  lResultSet.getString("PSWD_EFFECTIVE_DATE");

          if ( lCxMemberTabObj.pswd_effective_date != null && lCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            lCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);
          lCxMemberTabObj.expiry_period  =  lResultSet.getShort("EXPIRY_PERIOD");
          lCxMemberTabObj.hint  =  lResultSet.getString("HINT");
          lCxMemberTabObj.hint_ans  =  lResultSet.getString("HINT_ANS");
          lCxMemberTabObj.status  =  lResultSet.getString("STATUS");
          lCxMemberTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxMemberTabObj.rec_cre_date != null && lCxMemberTabObj.rec_cre_date.length() > 0 ) 
            lCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxMemberTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxMemberTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxMemberTabObj.rec_upd_date != null && lCxMemberTabObj.rec_upd_date.length() > 0 ) 
            lCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxMemberTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lCxMemberTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lCxMemberTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lCxMemberTabObj.city  =  lResultSet.getString("CITY");
          lCxMemberTabObj.state  =  lResultSet.getString("STATE");
          lCxMemberTabObj.zip  =  lResultSet.getString("ZIP");
          lCxMemberTabObj.country  =  lResultSet.getString("COUNTRY");
          lCxMemberTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lCxMemberTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lCxMemberTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lCxMemberTabObj.auth_rep_name  =  lResultSet.getString("AUTH_REP_NAME");
          lCxMemberTabObj.auth_rep_father_name  =  lResultSet.getString("AUTH_REP_FATHER_NAME");
          lCxMemberTabObj.auth_rep_phone_list  =  lResultSet.getString("AUTH_REP_PHONE_LIST");
          lCxMemberTabObj.pd_bal  =  lResultSet.getDouble("PD_BAL");
          lCxMemberTabObj.cd_bal  =  lResultSet.getDouble("CD_BAL");
          lCxMemberTabObj.cd_dr  =  lResultSet.getDouble("CD_DR");
          lCxMemberTabObj.cd_cr  =  lResultSet.getDouble("CD_CR");
          lCxMemberTabObj.cr_limit  =  lResultSet.getDouble("CR_LIMIT");
          lCxMemberTabObj.num_client_limit  =  lResultSet.getInt("NUM_CLIENT_LIMIT");

          removeNullCxMemberTabObj( lCxMemberTabObj );

          outCxMemberTabObjArr.add(  lCxMemberTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxMemberTabObjArr != null && outCxMemberTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberArrDist
               ( String inCxMemberWhereText
               , String inDistCxMemberField
               , ArrayList  outCxMemberTabObjArr
               )
  {

    sop("gtCxMemberArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";
  

       String lDistCxMemberFieldQry = inDistCxMemberField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxMemberFieldQry+
                         " FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxMemberField.substring(inDistCxMemberField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxMemberTabObj  lCxMemberTabObj = new CxMemberTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxMemberTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_id") )
              lCxMemberTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_name") )
              lCxMemberTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("link_member_id") )
              lCxMemberTabObj.link_member_id  =  lResultSet.getString("LINK_MEMBER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_type") )
              lCxMemberTabObj.member_type  =  lResultSet.getString("MEMBER_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("role_type") )
              lCxMemberTabObj.role_type  =  lResultSet.getString("ROLE_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lCxMemberTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_change_cnt") )
              lCxMemberTabObj.pswd_change_cnt  =  lResultSet.getInt("PSWD_CHANGE_CNT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_0") )
              lCxMemberTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_1") )
              lCxMemberTabObj.pswd_1  =  lResultSet.getString("PSWD_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_2") )
              lCxMemberTabObj.pswd_2  =  lResultSet.getString("PSWD_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_3") )
              lCxMemberTabObj.pswd_3  =  lResultSet.getString("PSWD_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_4") )
              lCxMemberTabObj.pswd_4  =  lResultSet.getString("PSWD_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_5") )
              lCxMemberTabObj.pswd_5  =  lResultSet.getString("PSWD_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_6") )
              lCxMemberTabObj.pswd_6  =  lResultSet.getString("PSWD_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_7") )
              lCxMemberTabObj.pswd_7  =  lResultSet.getString("PSWD_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_8") )
              lCxMemberTabObj.pswd_8  =  lResultSet.getString("PSWD_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_9") )
              lCxMemberTabObj.pswd_9  =  lResultSet.getString("PSWD_9");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_10") )
              lCxMemberTabObj.pswd_10  =  lResultSet.getString("PSWD_10");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_11") )
              lCxMemberTabObj.pswd_11  =  lResultSet.getString("PSWD_11");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_12") )
              lCxMemberTabObj.pswd_12  =  lResultSet.getString("PSWD_12");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_effective_date") )
              {
              lCxMemberTabObj.pswd_effective_date  =  lResultSet.getString("PSWD_EFFECTIVE_DATE");
  
          if ( lCxMemberTabObj.pswd_effective_date != null && lCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            lCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.pswd_effective_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("expiry_period") )
              lCxMemberTabObj.expiry_period  =  lResultSet.getShort("EXPIRY_PERIOD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hint") )
              lCxMemberTabObj.hint  =  lResultSet.getString("HINT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hint_ans") )
              lCxMemberTabObj.hint_ans  =  lResultSet.getString("HINT_ANS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxMemberTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxMemberTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxMemberTabObj.rec_cre_date != null && lCxMemberTabObj.rec_cre_date.length() > 0 ) 
            lCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxMemberTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxMemberTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxMemberTabObj.rec_upd_date != null && lCxMemberTabObj.rec_upd_date.length() > 0 ) 
            lCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxMemberTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxMemberTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_1") )
              lCxMemberTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_2") )
              lCxMemberTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("city") )
              lCxMemberTabObj.city  =  lResultSet.getString("CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("state") )
              lCxMemberTabObj.state  =  lResultSet.getString("STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("zip") )
              lCxMemberTabObj.zip  =  lResultSet.getString("ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country") )
              lCxMemberTabObj.country  =  lResultSet.getString("COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone_list") )
              lCxMemberTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_list") )
              lCxMemberTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fax_list") )
              lCxMemberTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("auth_rep_name") )
              lCxMemberTabObj.auth_rep_name  =  lResultSet.getString("AUTH_REP_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("auth_rep_father_name") )
              lCxMemberTabObj.auth_rep_father_name  =  lResultSet.getString("AUTH_REP_FATHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("auth_rep_phone_list") )
              lCxMemberTabObj.auth_rep_phone_list  =  lResultSet.getString("AUTH_REP_PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pd_bal") )
              lCxMemberTabObj.pd_bal  =  lResultSet.getDouble("PD_BAL");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cd_bal") )
              lCxMemberTabObj.cd_bal  =  lResultSet.getDouble("CD_BAL");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cd_dr") )
              lCxMemberTabObj.cd_dr  =  lResultSet.getDouble("CD_DR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cd_cr") )
              lCxMemberTabObj.cd_cr  =  lResultSet.getDouble("CD_CR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cr_limit") )
              lCxMemberTabObj.cr_limit  =  lResultSet.getDouble("CR_LIMIT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("num_client_limit") )
              lCxMemberTabObj.num_client_limit  =  lResultSet.getInt("NUM_CLIENT_LIMIT");

          }
          removeNullCxMemberTabObj( lCxMemberTabObj );

          outCxMemberTabObjArr.add(  lCxMemberTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxMemberTabObjArr != null && outCxMemberTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxMemberStrArrDist
               ( String inCxMemberWhereText
               , String inDistCxMemberField
               , ArrayList  outCxMemberTabObjArr
               )
  {

    sop("gtCxMemberStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxMemberStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";
  

       String lDistCxMemberFieldQry = inDistCxMemberField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxMemberFieldQry+
                         " FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxMemberField.substring(inDistCxMemberField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxMemberTabObjStr = "";
       while(lResultSet.next())
       {
          lCxMemberTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxMemberTabObjStr =   lCxMemberTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxMemberTabObjArr.add(  lCxMemberTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxMemberTabObjArr != null && outCxMemberTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxMember
               ( String inCxMemberWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxMember - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxMember";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxMemberTabObj
               ( 
                 CxMemberTabObj  outCxMemberTabObj
               )
  {
  
    if ( outCxMemberTabObj.org_id == null ) 
     outCxMemberTabObj.org_id = ""; 
    if ( outCxMemberTabObj.member_id == null ) 
     outCxMemberTabObj.member_id = ""; 
    if ( outCxMemberTabObj.member_name == null ) 
     outCxMemberTabObj.member_name = ""; 
    if ( outCxMemberTabObj.link_member_id == null ) 
     outCxMemberTabObj.link_member_id = ""; 
    if ( outCxMemberTabObj.member_type == null ) 
     outCxMemberTabObj.member_type = ""; 
    if ( outCxMemberTabObj.role_type == null ) 
     outCxMemberTabObj.role_type = ""; 
    if ( outCxMemberTabObj.remark == null ) 
     outCxMemberTabObj.remark = ""; 
    if ( outCxMemberTabObj.pswd_change_cnt == (int)0 ) 
     outCxMemberTabObj.pswd_change_cnt = (int)0; 
    if ( outCxMemberTabObj.pswd_0 == null ) 
     outCxMemberTabObj.pswd_0 = ""; 
    if ( outCxMemberTabObj.pswd_1 == null ) 
     outCxMemberTabObj.pswd_1 = ""; 
    if ( outCxMemberTabObj.pswd_2 == null ) 
     outCxMemberTabObj.pswd_2 = ""; 
    if ( outCxMemberTabObj.pswd_3 == null ) 
     outCxMemberTabObj.pswd_3 = ""; 
    if ( outCxMemberTabObj.pswd_4 == null ) 
     outCxMemberTabObj.pswd_4 = ""; 
    if ( outCxMemberTabObj.pswd_5 == null ) 
     outCxMemberTabObj.pswd_5 = ""; 
    if ( outCxMemberTabObj.pswd_6 == null ) 
     outCxMemberTabObj.pswd_6 = ""; 
    if ( outCxMemberTabObj.pswd_7 == null ) 
     outCxMemberTabObj.pswd_7 = ""; 
    if ( outCxMemberTabObj.pswd_8 == null ) 
     outCxMemberTabObj.pswd_8 = ""; 
    if ( outCxMemberTabObj.pswd_9 == null ) 
     outCxMemberTabObj.pswd_9 = ""; 
    if ( outCxMemberTabObj.pswd_10 == null ) 
     outCxMemberTabObj.pswd_10 = ""; 
    if ( outCxMemberTabObj.pswd_11 == null ) 
     outCxMemberTabObj.pswd_11 = ""; 
    if ( outCxMemberTabObj.pswd_12 == null ) 
     outCxMemberTabObj.pswd_12 = ""; 
    if ( outCxMemberTabObj.pswd_effective_date == null ) 
     outCxMemberTabObj.pswd_effective_date = ""; 
    if ( outCxMemberTabObj.expiry_period == (int)0 ) 
     outCxMemberTabObj.expiry_period = (int)0; 
    if ( outCxMemberTabObj.hint == null ) 
     outCxMemberTabObj.hint = ""; 
    if ( outCxMemberTabObj.hint_ans == null ) 
     outCxMemberTabObj.hint_ans = ""; 
    if ( outCxMemberTabObj.status == null ) 
     outCxMemberTabObj.status = ""; 
    if ( outCxMemberTabObj.rec_cre_date == null ) 
     outCxMemberTabObj.rec_cre_date = ""; 
    if ( outCxMemberTabObj.rec_cre_time == null ) 
     outCxMemberTabObj.rec_cre_time = ""; 
    if ( outCxMemberTabObj.rec_upd_date == null ) 
     outCxMemberTabObj.rec_upd_date = ""; 
    if ( outCxMemberTabObj.rec_upd_time == null ) 
     outCxMemberTabObj.rec_upd_time = ""; 
    if ( outCxMemberTabObj.address_1 == null ) 
     outCxMemberTabObj.address_1 = ""; 
    if ( outCxMemberTabObj.address_2 == null ) 
     outCxMemberTabObj.address_2 = ""; 
    if ( outCxMemberTabObj.city == null ) 
     outCxMemberTabObj.city = ""; 
    if ( outCxMemberTabObj.state == null ) 
     outCxMemberTabObj.state = ""; 
    if ( outCxMemberTabObj.zip == null ) 
     outCxMemberTabObj.zip = ""; 
    if ( outCxMemberTabObj.country == null ) 
     outCxMemberTabObj.country = ""; 
    if ( outCxMemberTabObj.phone_list == null ) 
     outCxMemberTabObj.phone_list = ""; 
    if ( outCxMemberTabObj.email_list == null ) 
     outCxMemberTabObj.email_list = ""; 
    if ( outCxMemberTabObj.fax_list == null ) 
     outCxMemberTabObj.fax_list = ""; 
    if ( outCxMemberTabObj.auth_rep_name == null ) 
     outCxMemberTabObj.auth_rep_name = ""; 
    if ( outCxMemberTabObj.auth_rep_father_name == null ) 
     outCxMemberTabObj.auth_rep_father_name = ""; 
    if ( outCxMemberTabObj.auth_rep_phone_list == null ) 
     outCxMemberTabObj.auth_rep_phone_list = ""; 
    if ( outCxMemberTabObj.pd_bal == (double)0.00 ) 
     outCxMemberTabObj.pd_bal = (double)0.00; 
    if ( outCxMemberTabObj.cd_bal == (double)0.00 ) 
     outCxMemberTabObj.cd_bal = (double)0.00; 
    if ( outCxMemberTabObj.cd_dr == (double)0.00 ) 
     outCxMemberTabObj.cd_dr = (double)0.00; 
    if ( outCxMemberTabObj.cd_cr == (double)0.00 ) 
     outCxMemberTabObj.cd_cr = (double)0.00; 
    if ( outCxMemberTabObj.cr_limit == (double)0.00 ) 
     outCxMemberTabObj.cr_limit = (double)0.00; 
    if ( outCxMemberTabObj.num_client_limit == (int)0 ) 
     outCxMemberTabObj.num_client_limit = (int)0; 
  }





  public int insCxMemberRec
               ( CxMemberTabObj  inCxMemberTabObj )
  {
    int lUpdateCount;
    sop("insCxMemberRec - Started");
    gSSTErrorObj.sourceMethod = "insCxMemberRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxMemberTabObj.pswd_effective_date != null && inCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            inCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.pswd_effective_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_cre_date != null && inCxMemberTabObj.rec_cre_date.length() > 0 ) 
            inCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_upd_date != null && inCxMemberTabObj.rec_upd_date.length() > 0 ) 
            inCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_MEMBER"+
                        "("+
                                "org_id,"+
                                "member_id,"+
                                "member_name,"+
                                "link_member_id,"+
                                "member_type,"+
                                "role_type,"+
                                "remark,"+
                                "pswd_change_cnt,"+
                                "pswd_0,"+
                                "pswd_1,"+
                                "pswd_2,"+
                                "pswd_3,"+
                                "pswd_4,"+
                                "pswd_5,"+
                                "pswd_6,"+
                                "pswd_7,"+
                                "pswd_8,"+
                                "pswd_9,"+
                                "pswd_10,"+
                                "pswd_11,"+
                                "pswd_12,"+
                                "pswd_effective_date,"+
                                "expiry_period,"+
                                "hint,"+
                                "hint_ans,"+
                                "status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "address_1,"+
                                "address_2,"+
                                "city,"+
                                "state,"+
                                "zip,"+
                                "country,"+
                                "phone_list,"+
                                "email_list,"+
                                "fax_list,"+
                                "auth_rep_name,"+
                                "auth_rep_father_name,"+
                                "auth_rep_phone_list,"+
                                "pd_bal,"+
                                "cd_bal,"+
                                "cd_dr,"+
                                "cd_cr,"+
                                "cr_limit,"+
                                "num_client_limit"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.member_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.member_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.link_member_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.member_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.role_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.pswd_change_cnt+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_0+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_9+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_10+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_11+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_12+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.pswd_effective_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.expiry_period+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.hint+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.hint_ans+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.email_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.fax_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.auth_rep_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.auth_rep_father_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxMemberTabObj.auth_rep_phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.pd_bal+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.cd_bal+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.cd_dr+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.cd_cr+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxMemberTabObj.cr_limit+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += inCxMemberTabObj.num_client_limit+"";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxMemberTabObj.org_id);
        lPreparedStatement.setString(2, inCxMemberTabObj.member_id);
        lPreparedStatement.setString(3, inCxMemberTabObj.member_name);
        lPreparedStatement.setString(4, inCxMemberTabObj.link_member_id);
        lPreparedStatement.setString(5, inCxMemberTabObj.member_type);
        lPreparedStatement.setString(6, inCxMemberTabObj.role_type);
        lPreparedStatement.setString(7, inCxMemberTabObj.remark);
          lPreparedStatement.setInt(8, inCxMemberTabObj.pswd_change_cnt);
        lPreparedStatement.setString(9, inCxMemberTabObj.pswd_0);
        lPreparedStatement.setString(10, inCxMemberTabObj.pswd_1);
        lPreparedStatement.setString(11, inCxMemberTabObj.pswd_2);
        lPreparedStatement.setString(12, inCxMemberTabObj.pswd_3);
        lPreparedStatement.setString(13, inCxMemberTabObj.pswd_4);
        lPreparedStatement.setString(14, inCxMemberTabObj.pswd_5);
        lPreparedStatement.setString(15, inCxMemberTabObj.pswd_6);
        lPreparedStatement.setString(16, inCxMemberTabObj.pswd_7);
        lPreparedStatement.setString(17, inCxMemberTabObj.pswd_8);
        lPreparedStatement.setString(18, inCxMemberTabObj.pswd_9);
        lPreparedStatement.setString(19, inCxMemberTabObj.pswd_10);
        lPreparedStatement.setString(20, inCxMemberTabObj.pswd_11);
        lPreparedStatement.setString(21, inCxMemberTabObj.pswd_12);
        lPreparedStatement.setString(22, inCxMemberTabObj.pswd_effective_date);
          lPreparedStatement.setShort(23, inCxMemberTabObj.expiry_period);
        lPreparedStatement.setString(24, inCxMemberTabObj.hint);
        lPreparedStatement.setString(25, inCxMemberTabObj.hint_ans);
        lPreparedStatement.setString(26, inCxMemberTabObj.status);
        lPreparedStatement.setString(27, inCxMemberTabObj.rec_cre_date);
        lPreparedStatement.setString(28, inCxMemberTabObj.rec_cre_time);
        lPreparedStatement.setString(29, inCxMemberTabObj.rec_upd_date);
        lPreparedStatement.setString(30, inCxMemberTabObj.rec_upd_time);
        lPreparedStatement.setString(31, inCxMemberTabObj.address_1);
        lPreparedStatement.setString(32, inCxMemberTabObj.address_2);
        lPreparedStatement.setString(33, inCxMemberTabObj.city);
        lPreparedStatement.setString(34, inCxMemberTabObj.state);
        lPreparedStatement.setString(35, inCxMemberTabObj.zip);
        lPreparedStatement.setString(36, inCxMemberTabObj.country);
        lPreparedStatement.setString(37, inCxMemberTabObj.phone_list);
        lPreparedStatement.setString(38, inCxMemberTabObj.email_list);
        lPreparedStatement.setString(39, inCxMemberTabObj.fax_list);
        lPreparedStatement.setString(40, inCxMemberTabObj.auth_rep_name);
        lPreparedStatement.setString(41, inCxMemberTabObj.auth_rep_father_name);
        lPreparedStatement.setString(42, inCxMemberTabObj.auth_rep_phone_list);
          lPreparedStatement.setDouble(43, inCxMemberTabObj.pd_bal);
          lPreparedStatement.setDouble(44, inCxMemberTabObj.cd_bal);
          lPreparedStatement.setDouble(45, inCxMemberTabObj.cd_dr);
          lPreparedStatement.setDouble(46, inCxMemberTabObj.cd_cr);
          lPreparedStatement.setDouble(47, inCxMemberTabObj.cr_limit);
          lPreparedStatement.setInt(48, inCxMemberTabObj.num_client_limit);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxMemberArr
               ( ArrayList  inCxMemberTabObjArr 
               , String  inRowidFlag )
  {
    CxMemberTabObj  lCxMemberTabObj = new CxMemberTabObj();
    int lUpdateCount;
    sop("insCxMemberArr - Started");
    gSSTErrorObj.sourceMethod = "insCxMemberArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxMemberTabObjArr.size(); lNumRec++ )
      {
        lCxMemberTabObj = (CxMemberTabObj)inCxMemberTabObjArr.get(lNumRec);

          if ( lCxMemberTabObj.pswd_effective_date != null && lCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            lCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxMemberTabObj.pswd_effective_date, lDateTimeSrcFmt);

          if ( lCxMemberTabObj.rec_cre_date != null && lCxMemberTabObj.rec_cre_date.length() > 0 ) 
            lCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxMemberTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxMemberTabObj.rec_upd_date != null && lCxMemberTabObj.rec_upd_date.length() > 0 ) 
            lCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxMemberTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_MEMBER"+
                        "("+
                        "org_id,"+
                        "member_id,"+
                        "member_name,"+
                        "link_member_id,"+
                        "member_type,"+
                        "role_type,"+
                        "remark,"+
                        "pswd_change_cnt,"+
                        "pswd_0,"+
                        "pswd_1,"+
                        "pswd_2,"+
                        "pswd_3,"+
                        "pswd_4,"+
                        "pswd_5,"+
                        "pswd_6,"+
                        "pswd_7,"+
                        "pswd_8,"+
                        "pswd_9,"+
                        "pswd_10,"+
                        "pswd_11,"+
                        "pswd_12,"+
                        "pswd_effective_date,"+
                        "expiry_period,"+
                        "hint,"+
                        "hint_ans,"+
                        "status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "address_1,"+
                        "address_2,"+
                        "city,"+
                        "state,"+
                        "zip,"+
                        "country,"+
                        "phone_list,"+
                        "email_list,"+
                        "fax_list,"+
                        "auth_rep_name,"+
                        "auth_rep_father_name,"+
                        "auth_rep_phone_list,"+
                        "pd_bal,"+
                        "cd_bal,"+
                        "cd_dr,"+
                        "cd_cr,"+
                        "cr_limit,"+
                        "num_client_limit"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.member_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.member_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.link_member_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.member_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.role_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.pswd_change_cnt+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_0+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_9+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_10+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_11+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_12+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.pswd_effective_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.expiry_period+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.hint+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.hint_ans+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.email_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.fax_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.auth_rep_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.auth_rep_father_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxMemberTabObj.auth_rep_phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.pd_bal+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.cd_bal+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.cd_dr+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.cd_cr+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxMemberTabObj.cr_limit+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += lCxMemberTabObj.num_client_limit+"";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxMemberTabObj.org_id);
            lPreparedStatement.setString(2, lCxMemberTabObj.member_id);
            lPreparedStatement.setString(3, lCxMemberTabObj.member_name);
            lPreparedStatement.setString(4, lCxMemberTabObj.link_member_id);
            lPreparedStatement.setString(5, lCxMemberTabObj.member_type);
            lPreparedStatement.setString(6, lCxMemberTabObj.role_type);
            lPreparedStatement.setString(7, lCxMemberTabObj.remark);
              lPreparedStatement.setInt(8, lCxMemberTabObj.pswd_change_cnt);
            lPreparedStatement.setString(9, lCxMemberTabObj.pswd_0);
            lPreparedStatement.setString(10, lCxMemberTabObj.pswd_1);
            lPreparedStatement.setString(11, lCxMemberTabObj.pswd_2);
            lPreparedStatement.setString(12, lCxMemberTabObj.pswd_3);
            lPreparedStatement.setString(13, lCxMemberTabObj.pswd_4);
            lPreparedStatement.setString(14, lCxMemberTabObj.pswd_5);
            lPreparedStatement.setString(15, lCxMemberTabObj.pswd_6);
            lPreparedStatement.setString(16, lCxMemberTabObj.pswd_7);
            lPreparedStatement.setString(17, lCxMemberTabObj.pswd_8);
            lPreparedStatement.setString(18, lCxMemberTabObj.pswd_9);
            lPreparedStatement.setString(19, lCxMemberTabObj.pswd_10);
            lPreparedStatement.setString(20, lCxMemberTabObj.pswd_11);
            lPreparedStatement.setString(21, lCxMemberTabObj.pswd_12);
            lPreparedStatement.setString(22, lCxMemberTabObj.pswd_effective_date);
              lPreparedStatement.setShort(23, lCxMemberTabObj.expiry_period);
            lPreparedStatement.setString(24, lCxMemberTabObj.hint);
            lPreparedStatement.setString(25, lCxMemberTabObj.hint_ans);
            lPreparedStatement.setString(26, lCxMemberTabObj.status);
            lPreparedStatement.setString(27, lCxMemberTabObj.rec_cre_date);
            lPreparedStatement.setString(28, lCxMemberTabObj.rec_cre_time);
            lPreparedStatement.setString(29, lCxMemberTabObj.rec_upd_date);
            lPreparedStatement.setString(30, lCxMemberTabObj.rec_upd_time);
            lPreparedStatement.setString(31, lCxMemberTabObj.address_1);
            lPreparedStatement.setString(32, lCxMemberTabObj.address_2);
            lPreparedStatement.setString(33, lCxMemberTabObj.city);
            lPreparedStatement.setString(34, lCxMemberTabObj.state);
            lPreparedStatement.setString(35, lCxMemberTabObj.zip);
            lPreparedStatement.setString(36, lCxMemberTabObj.country);
            lPreparedStatement.setString(37, lCxMemberTabObj.phone_list);
            lPreparedStatement.setString(38, lCxMemberTabObj.email_list);
            lPreparedStatement.setString(39, lCxMemberTabObj.fax_list);
            lPreparedStatement.setString(40, lCxMemberTabObj.auth_rep_name);
            lPreparedStatement.setString(41, lCxMemberTabObj.auth_rep_father_name);
            lPreparedStatement.setString(42, lCxMemberTabObj.auth_rep_phone_list);
              lPreparedStatement.setDouble(43, lCxMemberTabObj.pd_bal);
              lPreparedStatement.setDouble(44, lCxMemberTabObj.cd_bal);
              lPreparedStatement.setDouble(45, lCxMemberTabObj.cd_dr);
              lPreparedStatement.setDouble(46, lCxMemberTabObj.cd_cr);
              lPreparedStatement.setDouble(47, lCxMemberTabObj.cr_limit);
              lPreparedStatement.setInt(48, lCxMemberTabObj.num_client_limit);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxMemberReq2Obj
               ( HttpServletRequest inRequest
               , CxMemberTabObj  outCxMemberTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxMemberTabObj.tab_rowid = lTabRowidValue;

    outCxMemberTabObj.org_id = inRequest.getParameter("org_id");
    outCxMemberTabObj.member_id = inRequest.getParameter("member_id");
    outCxMemberTabObj.member_name = inRequest.getParameter("member_name");
    outCxMemberTabObj.link_member_id = inRequest.getParameter("link_member_id");
    outCxMemberTabObj.member_type = inRequest.getParameter("member_type");
    outCxMemberTabObj.role_type = inRequest.getParameter("role_type");
    outCxMemberTabObj.remark = inRequest.getParameter("remark");
    if ( inRequest.getParameter("pswd_change_cnt") == null )
      outCxMemberTabObj.pswd_change_cnt = 0;
    else
    if ( inRequest.getParameter("pswd_change_cnt").trim().length() == 0 )
      outCxMemberTabObj.pswd_change_cnt = 0;
    else
      outCxMemberTabObj.pswd_change_cnt = Integer.parseInt( inRequest.getParameter("pswd_change_cnt"));
    outCxMemberTabObj.pswd_0 = inRequest.getParameter("pswd_0");
    outCxMemberTabObj.pswd_1 = inRequest.getParameter("pswd_1");
    outCxMemberTabObj.pswd_2 = inRequest.getParameter("pswd_2");
    outCxMemberTabObj.pswd_3 = inRequest.getParameter("pswd_3");
    outCxMemberTabObj.pswd_4 = inRequest.getParameter("pswd_4");
    outCxMemberTabObj.pswd_5 = inRequest.getParameter("pswd_5");
    outCxMemberTabObj.pswd_6 = inRequest.getParameter("pswd_6");
    outCxMemberTabObj.pswd_7 = inRequest.getParameter("pswd_7");
    outCxMemberTabObj.pswd_8 = inRequest.getParameter("pswd_8");
    outCxMemberTabObj.pswd_9 = inRequest.getParameter("pswd_9");
    outCxMemberTabObj.pswd_10 = inRequest.getParameter("pswd_10");
    outCxMemberTabObj.pswd_11 = inRequest.getParameter("pswd_11");
    outCxMemberTabObj.pswd_12 = inRequest.getParameter("pswd_12");
    outCxMemberTabObj.pswd_effective_date = inRequest.getParameter("pswd_effective_date");
    if ( inRequest.getParameter("expiry_period") == null )
      outCxMemberTabObj.expiry_period = 0;
    else
    if ( inRequest.getParameter("expiry_period").trim().length() == 0 )
      outCxMemberTabObj.expiry_period = 0;
    else
      outCxMemberTabObj.expiry_period = Short.parseShort( inRequest.getParameter("expiry_period"));
    outCxMemberTabObj.hint = inRequest.getParameter("hint");
    outCxMemberTabObj.hint_ans = inRequest.getParameter("hint_ans");
    outCxMemberTabObj.status = inRequest.getParameter("status");
    outCxMemberTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxMemberTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxMemberTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxMemberTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outCxMemberTabObj.address_1 = inRequest.getParameter("address_1");
    outCxMemberTabObj.address_2 = inRequest.getParameter("address_2");
    outCxMemberTabObj.city = inRequest.getParameter("city");
    outCxMemberTabObj.state = inRequest.getParameter("state");
    outCxMemberTabObj.zip = inRequest.getParameter("zip");
    outCxMemberTabObj.country = inRequest.getParameter("country");
    outCxMemberTabObj.phone_list = inRequest.getParameter("phone_list");
    outCxMemberTabObj.email_list = inRequest.getParameter("email_list");
    outCxMemberTabObj.fax_list = inRequest.getParameter("fax_list");
    outCxMemberTabObj.auth_rep_name = inRequest.getParameter("auth_rep_name");
    outCxMemberTabObj.auth_rep_father_name = inRequest.getParameter("auth_rep_father_name");
    outCxMemberTabObj.auth_rep_phone_list = inRequest.getParameter("auth_rep_phone_list");
    if ( inRequest.getParameter("pd_bal") == null )
      outCxMemberTabObj.pd_bal = 0;
    else
    if ( inRequest.getParameter("pd_bal").trim().length() == 0 )
      outCxMemberTabObj.pd_bal = 0;
    else
      outCxMemberTabObj.pd_bal = Double.parseDouble( inRequest.getParameter("pd_bal"));
    if ( inRequest.getParameter("cd_bal") == null )
      outCxMemberTabObj.cd_bal = 0;
    else
    if ( inRequest.getParameter("cd_bal").trim().length() == 0 )
      outCxMemberTabObj.cd_bal = 0;
    else
      outCxMemberTabObj.cd_bal = Double.parseDouble( inRequest.getParameter("cd_bal"));
    if ( inRequest.getParameter("cd_dr") == null )
      outCxMemberTabObj.cd_dr = 0;
    else
    if ( inRequest.getParameter("cd_dr").trim().length() == 0 )
      outCxMemberTabObj.cd_dr = 0;
    else
      outCxMemberTabObj.cd_dr = Double.parseDouble( inRequest.getParameter("cd_dr"));
    if ( inRequest.getParameter("cd_cr") == null )
      outCxMemberTabObj.cd_cr = 0;
    else
    if ( inRequest.getParameter("cd_cr").trim().length() == 0 )
      outCxMemberTabObj.cd_cr = 0;
    else
      outCxMemberTabObj.cd_cr = Double.parseDouble( inRequest.getParameter("cd_cr"));
    if ( inRequest.getParameter("cr_limit") == null )
      outCxMemberTabObj.cr_limit = 0;
    else
    if ( inRequest.getParameter("cr_limit").trim().length() == 0 )
      outCxMemberTabObj.cr_limit = 0;
    else
      outCxMemberTabObj.cr_limit = Double.parseDouble( inRequest.getParameter("cr_limit"));
    if ( inRequest.getParameter("num_client_limit") == null )
      outCxMemberTabObj.num_client_limit = 0;
    else
    if ( inRequest.getParameter("num_client_limit").trim().length() == 0 )
      outCxMemberTabObj.num_client_limit = 0;
    else
      outCxMemberTabObj.num_client_limit = Integer.parseInt( inRequest.getParameter("num_client_limit"));
    return lReturnValue;
  }


  public int popCxMemberReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxMemberTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxMemberTabObj lCxMemberTabObj= new CxMemberTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxMemberTabObj.tab_rowid = lTabRowidValue;

      lCxMemberTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxMemberTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
      lCxMemberTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
      lCxMemberTabObj.link_member_id = inRequest.getParameter("link_member_id_r"+lNumRec);
      lCxMemberTabObj.member_type = inRequest.getParameter("member_type_r"+lNumRec);
      lCxMemberTabObj.role_type = inRequest.getParameter("role_type_r"+lNumRec);
      lCxMemberTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec) == null )
        lCxMemberTabObj.pswd_change_cnt = 0;
      else
      if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.pswd_change_cnt = 0;
      else
        lCxMemberTabObj.pswd_change_cnt = Integer.parseInt( inRequest.getParameter("pswd_change_cnt_r"+lNumRec));
      lCxMemberTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
      lCxMemberTabObj.pswd_1 = inRequest.getParameter("pswd_1_r"+lNumRec);
      lCxMemberTabObj.pswd_2 = inRequest.getParameter("pswd_2_r"+lNumRec);
      lCxMemberTabObj.pswd_3 = inRequest.getParameter("pswd_3_r"+lNumRec);
      lCxMemberTabObj.pswd_4 = inRequest.getParameter("pswd_4_r"+lNumRec);
      lCxMemberTabObj.pswd_5 = inRequest.getParameter("pswd_5_r"+lNumRec);
      lCxMemberTabObj.pswd_6 = inRequest.getParameter("pswd_6_r"+lNumRec);
      lCxMemberTabObj.pswd_7 = inRequest.getParameter("pswd_7_r"+lNumRec);
      lCxMemberTabObj.pswd_8 = inRequest.getParameter("pswd_8_r"+lNumRec);
      lCxMemberTabObj.pswd_9 = inRequest.getParameter("pswd_9_r"+lNumRec);
      lCxMemberTabObj.pswd_10 = inRequest.getParameter("pswd_10_r"+lNumRec);
      lCxMemberTabObj.pswd_11 = inRequest.getParameter("pswd_11_r"+lNumRec);
      lCxMemberTabObj.pswd_12 = inRequest.getParameter("pswd_12_r"+lNumRec);
      lCxMemberTabObj.pswd_effective_date = inRequest.getParameter("pswd_effective_date_r"+lNumRec);
      if ( inRequest.getParameter("expiry_period_r"+lNumRec) == null )
        lCxMemberTabObj.expiry_period = 0;
      else
      if ( inRequest.getParameter("expiry_period_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.expiry_period = 0;
      else
        lCxMemberTabObj.expiry_period = Short.parseShort( inRequest.getParameter("expiry_period_r"+lNumRec));
      lCxMemberTabObj.hint = inRequest.getParameter("hint_r"+lNumRec);
      lCxMemberTabObj.hint_ans = inRequest.getParameter("hint_ans_r"+lNumRec);
      lCxMemberTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxMemberTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxMemberTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxMemberTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxMemberTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lCxMemberTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
      lCxMemberTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
      lCxMemberTabObj.city = inRequest.getParameter("city_r"+lNumRec);
      lCxMemberTabObj.state = inRequest.getParameter("state_r"+lNumRec);
      lCxMemberTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
      lCxMemberTabObj.country = inRequest.getParameter("country_r"+lNumRec);
      lCxMemberTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
      lCxMemberTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
      lCxMemberTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      lCxMemberTabObj.auth_rep_name = inRequest.getParameter("auth_rep_name_r"+lNumRec);
      lCxMemberTabObj.auth_rep_father_name = inRequest.getParameter("auth_rep_father_name_r"+lNumRec);
      lCxMemberTabObj.auth_rep_phone_list = inRequest.getParameter("auth_rep_phone_list_r"+lNumRec);
      if ( inRequest.getParameter("pd_bal_r"+lNumRec) == null )
        lCxMemberTabObj.pd_bal = 0;
      else
      if ( inRequest.getParameter("pd_bal_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.pd_bal = 0;
      else
        lCxMemberTabObj.pd_bal = Double.parseDouble( inRequest.getParameter("pd_bal_r"+lNumRec));
      if ( inRequest.getParameter("cd_bal_r"+lNumRec) == null )
        lCxMemberTabObj.cd_bal = 0;
      else
      if ( inRequest.getParameter("cd_bal_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.cd_bal = 0;
      else
        lCxMemberTabObj.cd_bal = Double.parseDouble( inRequest.getParameter("cd_bal_r"+lNumRec));
      if ( inRequest.getParameter("cd_dr_r"+lNumRec) == null )
        lCxMemberTabObj.cd_dr = 0;
      else
      if ( inRequest.getParameter("cd_dr_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.cd_dr = 0;
      else
        lCxMemberTabObj.cd_dr = Double.parseDouble( inRequest.getParameter("cd_dr_r"+lNumRec));
      if ( inRequest.getParameter("cd_cr_r"+lNumRec) == null )
        lCxMemberTabObj.cd_cr = 0;
      else
      if ( inRequest.getParameter("cd_cr_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.cd_cr = 0;
      else
        lCxMemberTabObj.cd_cr = Double.parseDouble( inRequest.getParameter("cd_cr_r"+lNumRec));
      if ( inRequest.getParameter("cr_limit_r"+lNumRec) == null )
        lCxMemberTabObj.cr_limit = 0;
      else
      if ( inRequest.getParameter("cr_limit_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.cr_limit = 0;
      else
        lCxMemberTabObj.cr_limit = Double.parseDouble( inRequest.getParameter("cr_limit_r"+lNumRec));
      if ( inRequest.getParameter("num_client_limit_r"+lNumRec) == null )
        lCxMemberTabObj.num_client_limit = 0;
      else
      if ( inRequest.getParameter("num_client_limit_r"+lNumRec).trim().length() == 0 )
        lCxMemberTabObj.num_client_limit = 0;
      else
        lCxMemberTabObj.num_client_limit = Integer.parseInt( inRequest.getParameter("num_client_limit_r"+lNumRec));
      outCxMemberTabObjArr.add( lCxMemberTabObj);
    }
    return lReturnValue;
  }


  public int popCxMemberReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxMemberTabObj outCxMemberTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_member_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxMemberTabObj.tab_rowid = lTabRowidValue;

        outCxMemberTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxMemberTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        outCxMemberTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        outCxMemberTabObj.link_member_id = inRequest.getParameter("link_member_id_r"+lNumRec);
        outCxMemberTabObj.member_type = inRequest.getParameter("member_type_r"+lNumRec);
        outCxMemberTabObj.role_type = inRequest.getParameter("role_type_r"+lNumRec);
        outCxMemberTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec) == null )
          outCxMemberTabObj.pswd_change_cnt = 0;
        else
        if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.pswd_change_cnt = 0;
        else
          outCxMemberTabObj.pswd_change_cnt = Integer.parseInt( inRequest.getParameter("pswd_change_cnt_r"+lNumRec));
        outCxMemberTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        outCxMemberTabObj.pswd_1 = inRequest.getParameter("pswd_1_r"+lNumRec);
        outCxMemberTabObj.pswd_2 = inRequest.getParameter("pswd_2_r"+lNumRec);
        outCxMemberTabObj.pswd_3 = inRequest.getParameter("pswd_3_r"+lNumRec);
        outCxMemberTabObj.pswd_4 = inRequest.getParameter("pswd_4_r"+lNumRec);
        outCxMemberTabObj.pswd_5 = inRequest.getParameter("pswd_5_r"+lNumRec);
        outCxMemberTabObj.pswd_6 = inRequest.getParameter("pswd_6_r"+lNumRec);
        outCxMemberTabObj.pswd_7 = inRequest.getParameter("pswd_7_r"+lNumRec);
        outCxMemberTabObj.pswd_8 = inRequest.getParameter("pswd_8_r"+lNumRec);
        outCxMemberTabObj.pswd_9 = inRequest.getParameter("pswd_9_r"+lNumRec);
        outCxMemberTabObj.pswd_10 = inRequest.getParameter("pswd_10_r"+lNumRec);
        outCxMemberTabObj.pswd_11 = inRequest.getParameter("pswd_11_r"+lNumRec);
        outCxMemberTabObj.pswd_12 = inRequest.getParameter("pswd_12_r"+lNumRec);
        outCxMemberTabObj.pswd_effective_date = inRequest.getParameter("pswd_effective_date_r"+lNumRec);
        if ( inRequest.getParameter("expiry_period_r"+lNumRec) == null )
          outCxMemberTabObj.expiry_period = 0;
        else
        if ( inRequest.getParameter("expiry_period_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.expiry_period = 0;
        else
          outCxMemberTabObj.expiry_period = Short.parseShort( inRequest.getParameter("expiry_period_r"+lNumRec));
        outCxMemberTabObj.hint = inRequest.getParameter("hint_r"+lNumRec);
        outCxMemberTabObj.hint_ans = inRequest.getParameter("hint_ans_r"+lNumRec);
        outCxMemberTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxMemberTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxMemberTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxMemberTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxMemberTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxMemberTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        outCxMemberTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        outCxMemberTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        outCxMemberTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        outCxMemberTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        outCxMemberTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        outCxMemberTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        outCxMemberTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        outCxMemberTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        outCxMemberTabObj.auth_rep_name = inRequest.getParameter("auth_rep_name_r"+lNumRec);
        outCxMemberTabObj.auth_rep_father_name = inRequest.getParameter("auth_rep_father_name_r"+lNumRec);
        outCxMemberTabObj.auth_rep_phone_list = inRequest.getParameter("auth_rep_phone_list_r"+lNumRec);
        if ( inRequest.getParameter("pd_bal_r"+lNumRec) == null )
          outCxMemberTabObj.pd_bal = 0;
        else
        if ( inRequest.getParameter("pd_bal_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.pd_bal = 0;
        else
          outCxMemberTabObj.pd_bal = Double.parseDouble( inRequest.getParameter("pd_bal_r"+lNumRec));
        if ( inRequest.getParameter("cd_bal_r"+lNumRec) == null )
          outCxMemberTabObj.cd_bal = 0;
        else
        if ( inRequest.getParameter("cd_bal_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.cd_bal = 0;
        else
          outCxMemberTabObj.cd_bal = Double.parseDouble( inRequest.getParameter("cd_bal_r"+lNumRec));
        if ( inRequest.getParameter("cd_dr_r"+lNumRec) == null )
          outCxMemberTabObj.cd_dr = 0;
        else
        if ( inRequest.getParameter("cd_dr_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.cd_dr = 0;
        else
          outCxMemberTabObj.cd_dr = Double.parseDouble( inRequest.getParameter("cd_dr_r"+lNumRec));
        if ( inRequest.getParameter("cd_cr_r"+lNumRec) == null )
          outCxMemberTabObj.cd_cr = 0;
        else
        if ( inRequest.getParameter("cd_cr_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.cd_cr = 0;
        else
          outCxMemberTabObj.cd_cr = Double.parseDouble( inRequest.getParameter("cd_cr_r"+lNumRec));
        if ( inRequest.getParameter("cr_limit_r"+lNumRec) == null )
          outCxMemberTabObj.cr_limit = 0;
        else
        if ( inRequest.getParameter("cr_limit_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.cr_limit = 0;
        else
          outCxMemberTabObj.cr_limit = Double.parseDouble( inRequest.getParameter("cr_limit_r"+lNumRec));
        if ( inRequest.getParameter("num_client_limit_r"+lNumRec) == null )
          outCxMemberTabObj.num_client_limit = 0;
        else
        if ( inRequest.getParameter("num_client_limit_r"+lNumRec).trim().length() == 0 )
          outCxMemberTabObj.num_client_limit = 0;
        else
          outCxMemberTabObj.num_client_limit = Integer.parseInt( inRequest.getParameter("num_client_limit_r"+lNumRec));
      }
    }
    return lReturnValue;
  }


  public int popCxMemberReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxMemberTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxMemberTabObj lCxMemberTabObj= new CxMemberTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_member_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxMemberTabObj.tab_rowid = lTabRowidValue;

        lCxMemberTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxMemberTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        lCxMemberTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        lCxMemberTabObj.link_member_id = inRequest.getParameter("link_member_id_r"+lNumRec);
        lCxMemberTabObj.member_type = inRequest.getParameter("member_type_r"+lNumRec);
        lCxMemberTabObj.role_type = inRequest.getParameter("role_type_r"+lNumRec);
        lCxMemberTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec) == null )
          lCxMemberTabObj.pswd_change_cnt = 0;
        else
        if ( inRequest.getParameter("pswd_change_cnt_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.pswd_change_cnt = 0;
        else
          lCxMemberTabObj.pswd_change_cnt = Integer.parseInt( inRequest.getParameter("pswd_change_cnt_r"+lNumRec));
        lCxMemberTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        lCxMemberTabObj.pswd_1 = inRequest.getParameter("pswd_1_r"+lNumRec);
        lCxMemberTabObj.pswd_2 = inRequest.getParameter("pswd_2_r"+lNumRec);
        lCxMemberTabObj.pswd_3 = inRequest.getParameter("pswd_3_r"+lNumRec);
        lCxMemberTabObj.pswd_4 = inRequest.getParameter("pswd_4_r"+lNumRec);
        lCxMemberTabObj.pswd_5 = inRequest.getParameter("pswd_5_r"+lNumRec);
        lCxMemberTabObj.pswd_6 = inRequest.getParameter("pswd_6_r"+lNumRec);
        lCxMemberTabObj.pswd_7 = inRequest.getParameter("pswd_7_r"+lNumRec);
        lCxMemberTabObj.pswd_8 = inRequest.getParameter("pswd_8_r"+lNumRec);
        lCxMemberTabObj.pswd_9 = inRequest.getParameter("pswd_9_r"+lNumRec);
        lCxMemberTabObj.pswd_10 = inRequest.getParameter("pswd_10_r"+lNumRec);
        lCxMemberTabObj.pswd_11 = inRequest.getParameter("pswd_11_r"+lNumRec);
        lCxMemberTabObj.pswd_12 = inRequest.getParameter("pswd_12_r"+lNumRec);
        lCxMemberTabObj.pswd_effective_date = inRequest.getParameter("pswd_effective_date_r"+lNumRec);
        if ( inRequest.getParameter("expiry_period_r"+lNumRec) == null )
          lCxMemberTabObj.expiry_period = 0;
        else
        if ( inRequest.getParameter("expiry_period_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.expiry_period = 0;
        else
          lCxMemberTabObj.expiry_period = Short.parseShort( inRequest.getParameter("expiry_period_r"+lNumRec));
        lCxMemberTabObj.hint = inRequest.getParameter("hint_r"+lNumRec);
        lCxMemberTabObj.hint_ans = inRequest.getParameter("hint_ans_r"+lNumRec);
        lCxMemberTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxMemberTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxMemberTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxMemberTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxMemberTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lCxMemberTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        lCxMemberTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        lCxMemberTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        lCxMemberTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        lCxMemberTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        lCxMemberTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        lCxMemberTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        lCxMemberTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        lCxMemberTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        lCxMemberTabObj.auth_rep_name = inRequest.getParameter("auth_rep_name_r"+lNumRec);
        lCxMemberTabObj.auth_rep_father_name = inRequest.getParameter("auth_rep_father_name_r"+lNumRec);
        lCxMemberTabObj.auth_rep_phone_list = inRequest.getParameter("auth_rep_phone_list_r"+lNumRec);
        if ( inRequest.getParameter("pd_bal_r"+lNumRec) == null )
          lCxMemberTabObj.pd_bal = 0;
        else
        if ( inRequest.getParameter("pd_bal_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.pd_bal = 0;
        else
            lCxMemberTabObj.pd_bal = Double.parseDouble( inRequest.getParameter("pd_bal_r"+lNumRec));
        if ( inRequest.getParameter("cd_bal_r"+lNumRec) == null )
          lCxMemberTabObj.cd_bal = 0;
        else
        if ( inRequest.getParameter("cd_bal_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.cd_bal = 0;
        else
            lCxMemberTabObj.cd_bal = Double.parseDouble( inRequest.getParameter("cd_bal_r"+lNumRec));
        if ( inRequest.getParameter("cd_dr_r"+lNumRec) == null )
          lCxMemberTabObj.cd_dr = 0;
        else
        if ( inRequest.getParameter("cd_dr_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.cd_dr = 0;
        else
            lCxMemberTabObj.cd_dr = Double.parseDouble( inRequest.getParameter("cd_dr_r"+lNumRec));
        if ( inRequest.getParameter("cd_cr_r"+lNumRec) == null )
          lCxMemberTabObj.cd_cr = 0;
        else
        if ( inRequest.getParameter("cd_cr_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.cd_cr = 0;
        else
            lCxMemberTabObj.cd_cr = Double.parseDouble( inRequest.getParameter("cd_cr_r"+lNumRec));
        if ( inRequest.getParameter("cr_limit_r"+lNumRec) == null )
          lCxMemberTabObj.cr_limit = 0;
        else
        if ( inRequest.getParameter("cr_limit_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.cr_limit = 0;
        else
            lCxMemberTabObj.cr_limit = Double.parseDouble( inRequest.getParameter("cr_limit_r"+lNumRec));
        if ( inRequest.getParameter("num_client_limit_r"+lNumRec) == null )
          lCxMemberTabObj.num_client_limit = 0;
        else
        if ( inRequest.getParameter("num_client_limit_r"+lNumRec).trim().length() == 0 )
          lCxMemberTabObj.num_client_limit = 0;
        else
          lCxMemberTabObj.num_client_limit = Integer.parseInt( inRequest.getParameter("num_client_limit_r"+lNumRec));
        outCxMemberTabObjArr.add( lCxMemberTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxMemberRecByRowid
               ( String inRowId
               , CxMemberTabObj  inCxMemberTabObj
               )
  {
    int lUpdateCount;
    sop("updCxMemberRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxMemberRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxMemberTabObj.pswd_effective_date != null && inCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            inCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.pswd_effective_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_cre_date != null && inCxMemberTabObj.rec_cre_date.length() > 0 ) 
            inCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_upd_date != null && inCxMemberTabObj.rec_upd_date.length() > 0 ) 
            inCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_MEMBER ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxMemberTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxMemberTabObj.org_id+"', ";
      if ( inCxMemberTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxMemberTabObj.member_id+"', ";
      if ( inCxMemberTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxMemberTabObj.member_name+"', ";
      if ( inCxMemberTabObj.link_member_id != null  )         lSqlStmt = lSqlStmt + "link_member_id = "+"'"+inCxMemberTabObj.link_member_id+"', ";
      if ( inCxMemberTabObj.member_type != null  )         lSqlStmt = lSqlStmt + "member_type = "+"'"+inCxMemberTabObj.member_type+"', ";
      if ( inCxMemberTabObj.role_type != null  )         lSqlStmt = lSqlStmt + "role_type = "+"'"+inCxMemberTabObj.role_type+"', ";
      if ( inCxMemberTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inCxMemberTabObj.remark+"', ";
             lSqlStmt = lSqlStmt + "pswd_change_cnt = "+inCxMemberTabObj.pswd_change_cnt+", ";
      if ( inCxMemberTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inCxMemberTabObj.pswd_0+"', ";
      if ( inCxMemberTabObj.pswd_1 != null  )         lSqlStmt = lSqlStmt + "pswd_1 = "+"'"+inCxMemberTabObj.pswd_1+"', ";
      if ( inCxMemberTabObj.pswd_2 != null  )         lSqlStmt = lSqlStmt + "pswd_2 = "+"'"+inCxMemberTabObj.pswd_2+"', ";
      if ( inCxMemberTabObj.pswd_3 != null  )         lSqlStmt = lSqlStmt + "pswd_3 = "+"'"+inCxMemberTabObj.pswd_3+"', ";
      if ( inCxMemberTabObj.pswd_4 != null  )         lSqlStmt = lSqlStmt + "pswd_4 = "+"'"+inCxMemberTabObj.pswd_4+"', ";
      if ( inCxMemberTabObj.pswd_5 != null  )         lSqlStmt = lSqlStmt + "pswd_5 = "+"'"+inCxMemberTabObj.pswd_5+"', ";
      if ( inCxMemberTabObj.pswd_6 != null  )         lSqlStmt = lSqlStmt + "pswd_6 = "+"'"+inCxMemberTabObj.pswd_6+"', ";
      if ( inCxMemberTabObj.pswd_7 != null  )         lSqlStmt = lSqlStmt + "pswd_7 = "+"'"+inCxMemberTabObj.pswd_7+"', ";
      if ( inCxMemberTabObj.pswd_8 != null  )         lSqlStmt = lSqlStmt + "pswd_8 = "+"'"+inCxMemberTabObj.pswd_8+"', ";
      if ( inCxMemberTabObj.pswd_9 != null  )         lSqlStmt = lSqlStmt + "pswd_9 = "+"'"+inCxMemberTabObj.pswd_9+"', ";
      if ( inCxMemberTabObj.pswd_10 != null  )         lSqlStmt = lSqlStmt + "pswd_10 = "+"'"+inCxMemberTabObj.pswd_10+"', ";
      if ( inCxMemberTabObj.pswd_11 != null  )         lSqlStmt = lSqlStmt + "pswd_11 = "+"'"+inCxMemberTabObj.pswd_11+"', ";
      if ( inCxMemberTabObj.pswd_12 != null  )         lSqlStmt = lSqlStmt + "pswd_12 = "+"'"+inCxMemberTabObj.pswd_12+"', ";
      if ( inCxMemberTabObj.pswd_effective_date != null  )         lSqlStmt = lSqlStmt + "pswd_effective_date = "+"'"+inCxMemberTabObj.pswd_effective_date+"', ";
             lSqlStmt = lSqlStmt + "expiry_period = "+inCxMemberTabObj.expiry_period+", ";
      if ( inCxMemberTabObj.hint != null  )         lSqlStmt = lSqlStmt + "hint = "+"'"+inCxMemberTabObj.hint+"', ";
      if ( inCxMemberTabObj.hint_ans != null  )         lSqlStmt = lSqlStmt + "hint_ans = "+"'"+inCxMemberTabObj.hint_ans+"', ";
      if ( inCxMemberTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxMemberTabObj.status+"', ";
      if ( inCxMemberTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxMemberTabObj.rec_cre_date+"', ";
      if ( inCxMemberTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxMemberTabObj.rec_cre_time+"', ";
      if ( inCxMemberTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxMemberTabObj.rec_upd_date+"', ";
      if ( inCxMemberTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxMemberTabObj.rec_upd_time+"', ";
      if ( inCxMemberTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inCxMemberTabObj.address_1+"', ";
      if ( inCxMemberTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inCxMemberTabObj.address_2+"', ";
      if ( inCxMemberTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inCxMemberTabObj.city+"', ";
      if ( inCxMemberTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inCxMemberTabObj.state+"', ";
      if ( inCxMemberTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inCxMemberTabObj.zip+"', ";
      if ( inCxMemberTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inCxMemberTabObj.country+"', ";
      if ( inCxMemberTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inCxMemberTabObj.phone_list+"', ";
      if ( inCxMemberTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inCxMemberTabObj.email_list+"', ";
      if ( inCxMemberTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inCxMemberTabObj.fax_list+"', ";
      if ( inCxMemberTabObj.auth_rep_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_name = "+"'"+inCxMemberTabObj.auth_rep_name+"', ";
      if ( inCxMemberTabObj.auth_rep_father_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_father_name = "+"'"+inCxMemberTabObj.auth_rep_father_name+"', ";
      if ( inCxMemberTabObj.auth_rep_phone_list != null  )         lSqlStmt = lSqlStmt + "auth_rep_phone_list = "+"'"+inCxMemberTabObj.auth_rep_phone_list+"', ";
             lSqlStmt = lSqlStmt + "pd_bal = "+inCxMemberTabObj.pd_bal+", ";
             lSqlStmt = lSqlStmt + "cd_bal = "+inCxMemberTabObj.cd_bal+", ";
             lSqlStmt = lSqlStmt + "cd_dr = "+inCxMemberTabObj.cd_dr+", ";
             lSqlStmt = lSqlStmt + "cd_cr = "+inCxMemberTabObj.cd_cr+", ";
             lSqlStmt = lSqlStmt + "cr_limit = "+inCxMemberTabObj.cr_limit+", ";
             lSqlStmt = lSqlStmt + "num_client_limit = "+inCxMemberTabObj.num_client_limit+", ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxMemberRecByPkey
               ( CxMemberPkeyObj inCxMemberPkeyObj
               , CxMemberTabObj  inCxMemberTabObj
               )
  {
    int lUpdateCount;
    sop("updCxMemberRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxMemberRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxMemberTabObj.pswd_effective_date != null && inCxMemberTabObj.pswd_effective_date.length() > 0 ) 
            inCxMemberTabObj.pswd_effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.pswd_effective_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_cre_date != null && inCxMemberTabObj.rec_cre_date.length() > 0 ) 
            inCxMemberTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxMemberTabObj.rec_upd_date != null && inCxMemberTabObj.rec_upd_date.length() > 0 ) 
            inCxMemberTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxMemberTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_MEMBER ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxMemberTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxMemberTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = ? , ";
        if ( inCxMemberTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = ? , ";
        if ( inCxMemberTabObj.link_member_id != null  )         lSqlStmt = lSqlStmt + "link_member_id = ? , ";
        if ( inCxMemberTabObj.member_type != null  )         lSqlStmt = lSqlStmt + "member_type = ? , ";
        if ( inCxMemberTabObj.role_type != null  )         lSqlStmt = lSqlStmt + "role_type = ? , ";
        if ( inCxMemberTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
               lSqlStmt = lSqlStmt + "pswd_change_cnt = ? , ";
        if ( inCxMemberTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = ? , ";
        if ( inCxMemberTabObj.pswd_1 != null  )         lSqlStmt = lSqlStmt + "pswd_1 = ? , ";
        if ( inCxMemberTabObj.pswd_2 != null  )         lSqlStmt = lSqlStmt + "pswd_2 = ? , ";
        if ( inCxMemberTabObj.pswd_3 != null  )         lSqlStmt = lSqlStmt + "pswd_3 = ? , ";
        if ( inCxMemberTabObj.pswd_4 != null  )         lSqlStmt = lSqlStmt + "pswd_4 = ? , ";
        if ( inCxMemberTabObj.pswd_5 != null  )         lSqlStmt = lSqlStmt + "pswd_5 = ? , ";
        if ( inCxMemberTabObj.pswd_6 != null  )         lSqlStmt = lSqlStmt + "pswd_6 = ? , ";
        if ( inCxMemberTabObj.pswd_7 != null  )         lSqlStmt = lSqlStmt + "pswd_7 = ? , ";
        if ( inCxMemberTabObj.pswd_8 != null  )         lSqlStmt = lSqlStmt + "pswd_8 = ? , ";
        if ( inCxMemberTabObj.pswd_9 != null  )         lSqlStmt = lSqlStmt + "pswd_9 = ? , ";
        if ( inCxMemberTabObj.pswd_10 != null  )         lSqlStmt = lSqlStmt + "pswd_10 = ? , ";
        if ( inCxMemberTabObj.pswd_11 != null  )         lSqlStmt = lSqlStmt + "pswd_11 = ? , ";
        if ( inCxMemberTabObj.pswd_12 != null  )         lSqlStmt = lSqlStmt + "pswd_12 = ? , ";
        if ( inCxMemberTabObj.pswd_effective_date != null  )         lSqlStmt = lSqlStmt + "pswd_effective_date = ? , ";
               lSqlStmt = lSqlStmt + "expiry_period = ? , ";
        if ( inCxMemberTabObj.hint != null  )         lSqlStmt = lSqlStmt + "hint = ? , ";
        if ( inCxMemberTabObj.hint_ans != null  )         lSqlStmt = lSqlStmt + "hint_ans = ? , ";
        if ( inCxMemberTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxMemberTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxMemberTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxMemberTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxMemberTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inCxMemberTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = ? , ";
        if ( inCxMemberTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = ? , ";
        if ( inCxMemberTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = ? , ";
        if ( inCxMemberTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = ? , ";
        if ( inCxMemberTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = ? , ";
        if ( inCxMemberTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = ? , ";
        if ( inCxMemberTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = ? , ";
        if ( inCxMemberTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = ? , ";
        if ( inCxMemberTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = ? , ";
        if ( inCxMemberTabObj.auth_rep_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_name = ? , ";
        if ( inCxMemberTabObj.auth_rep_father_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_father_name = ? , ";
        if ( inCxMemberTabObj.auth_rep_phone_list != null  )         lSqlStmt = lSqlStmt + "auth_rep_phone_list = ? , ";
               lSqlStmt = lSqlStmt + "pd_bal = ? , ";
               lSqlStmt = lSqlStmt + "cd_bal = ? , ";
               lSqlStmt = lSqlStmt + "cd_dr = ? , ";
               lSqlStmt = lSqlStmt + "cd_cr = ? , ";
               lSqlStmt = lSqlStmt + "cr_limit = ? , ";
               lSqlStmt = lSqlStmt + "num_client_limit = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxMemberTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxMemberTabObj.org_id+"', ";
        if ( inCxMemberTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxMemberTabObj.member_id+"', ";
        if ( inCxMemberTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxMemberTabObj.member_name+"', ";
        if ( inCxMemberTabObj.link_member_id != null  )         lSqlStmt = lSqlStmt + "link_member_id = "+"'"+inCxMemberTabObj.link_member_id+"', ";
        if ( inCxMemberTabObj.member_type != null  )         lSqlStmt = lSqlStmt + "member_type = "+"'"+inCxMemberTabObj.member_type+"', ";
        if ( inCxMemberTabObj.role_type != null  )         lSqlStmt = lSqlStmt + "role_type = "+"'"+inCxMemberTabObj.role_type+"', ";
        if ( inCxMemberTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inCxMemberTabObj.remark+"', ";
               lSqlStmt = lSqlStmt + "pswd_change_cnt = "+inCxMemberTabObj.pswd_change_cnt+", ";
        if ( inCxMemberTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inCxMemberTabObj.pswd_0+"', ";
        if ( inCxMemberTabObj.pswd_1 != null  )         lSqlStmt = lSqlStmt + "pswd_1 = "+"'"+inCxMemberTabObj.pswd_1+"', ";
        if ( inCxMemberTabObj.pswd_2 != null  )         lSqlStmt = lSqlStmt + "pswd_2 = "+"'"+inCxMemberTabObj.pswd_2+"', ";
        if ( inCxMemberTabObj.pswd_3 != null  )         lSqlStmt = lSqlStmt + "pswd_3 = "+"'"+inCxMemberTabObj.pswd_3+"', ";
        if ( inCxMemberTabObj.pswd_4 != null  )         lSqlStmt = lSqlStmt + "pswd_4 = "+"'"+inCxMemberTabObj.pswd_4+"', ";
        if ( inCxMemberTabObj.pswd_5 != null  )         lSqlStmt = lSqlStmt + "pswd_5 = "+"'"+inCxMemberTabObj.pswd_5+"', ";
        if ( inCxMemberTabObj.pswd_6 != null  )         lSqlStmt = lSqlStmt + "pswd_6 = "+"'"+inCxMemberTabObj.pswd_6+"', ";
        if ( inCxMemberTabObj.pswd_7 != null  )         lSqlStmt = lSqlStmt + "pswd_7 = "+"'"+inCxMemberTabObj.pswd_7+"', ";
        if ( inCxMemberTabObj.pswd_8 != null  )         lSqlStmt = lSqlStmt + "pswd_8 = "+"'"+inCxMemberTabObj.pswd_8+"', ";
        if ( inCxMemberTabObj.pswd_9 != null  )         lSqlStmt = lSqlStmt + "pswd_9 = "+"'"+inCxMemberTabObj.pswd_9+"', ";
        if ( inCxMemberTabObj.pswd_10 != null  )         lSqlStmt = lSqlStmt + "pswd_10 = "+"'"+inCxMemberTabObj.pswd_10+"', ";
        if ( inCxMemberTabObj.pswd_11 != null  )         lSqlStmt = lSqlStmt + "pswd_11 = "+"'"+inCxMemberTabObj.pswd_11+"', ";
        if ( inCxMemberTabObj.pswd_12 != null  )         lSqlStmt = lSqlStmt + "pswd_12 = "+"'"+inCxMemberTabObj.pswd_12+"', ";
        if ( inCxMemberTabObj.pswd_effective_date != null  )         lSqlStmt = lSqlStmt + "pswd_effective_date = "+"'"+inCxMemberTabObj.pswd_effective_date+"', ";
               lSqlStmt = lSqlStmt + "expiry_period = "+inCxMemberTabObj.expiry_period+", ";
        if ( inCxMemberTabObj.hint != null  )         lSqlStmt = lSqlStmt + "hint = "+"'"+inCxMemberTabObj.hint+"', ";
        if ( inCxMemberTabObj.hint_ans != null  )         lSqlStmt = lSqlStmt + "hint_ans = "+"'"+inCxMemberTabObj.hint_ans+"', ";
        if ( inCxMemberTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxMemberTabObj.status+"', ";
        if ( inCxMemberTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxMemberTabObj.rec_cre_date+"', ";
        if ( inCxMemberTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxMemberTabObj.rec_cre_time+"', ";
        if ( inCxMemberTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxMemberTabObj.rec_upd_date+"', ";
        if ( inCxMemberTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxMemberTabObj.rec_upd_time+"', ";
        if ( inCxMemberTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inCxMemberTabObj.address_1+"', ";
        if ( inCxMemberTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inCxMemberTabObj.address_2+"', ";
        if ( inCxMemberTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inCxMemberTabObj.city+"', ";
        if ( inCxMemberTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inCxMemberTabObj.state+"', ";
        if ( inCxMemberTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inCxMemberTabObj.zip+"', ";
        if ( inCxMemberTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inCxMemberTabObj.country+"', ";
        if ( inCxMemberTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inCxMemberTabObj.phone_list+"', ";
        if ( inCxMemberTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inCxMemberTabObj.email_list+"', ";
        if ( inCxMemberTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inCxMemberTabObj.fax_list+"', ";
        if ( inCxMemberTabObj.auth_rep_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_name = "+"'"+inCxMemberTabObj.auth_rep_name+"', ";
        if ( inCxMemberTabObj.auth_rep_father_name != null  )         lSqlStmt = lSqlStmt + "auth_rep_father_name = "+"'"+inCxMemberTabObj.auth_rep_father_name+"', ";
        if ( inCxMemberTabObj.auth_rep_phone_list != null  )         lSqlStmt = lSqlStmt + "auth_rep_phone_list = "+"'"+inCxMemberTabObj.auth_rep_phone_list+"', ";
               lSqlStmt = lSqlStmt + "pd_bal = "+inCxMemberTabObj.pd_bal+", ";
               lSqlStmt = lSqlStmt + "cd_bal = "+inCxMemberTabObj.cd_bal+", ";
               lSqlStmt = lSqlStmt + "cd_dr = "+inCxMemberTabObj.cd_dr+", ";
               lSqlStmt = lSqlStmt + "cd_cr = "+inCxMemberTabObj.cd_cr+", ";
               lSqlStmt = lSqlStmt + "cr_limit = "+inCxMemberTabObj.cr_limit+", ";
               lSqlStmt = lSqlStmt + "num_client_limit = "+inCxMemberTabObj.num_client_limit+", ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxMemberPkeyObj.org_id+"' and "+
                              "member_id = "+"'"+inCxMemberPkeyObj.member_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxMemberTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.org_id); } 
         if ( inCxMemberTabObj.member_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.member_id); } 
         if ( inCxMemberTabObj.member_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.member_name); } 
         if ( inCxMemberTabObj.link_member_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.link_member_id); } 
         if ( inCxMemberTabObj.member_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.member_type); } 
         if ( inCxMemberTabObj.role_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.role_type); } 
         if ( inCxMemberTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.remark); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(8, inCxMemberTabObj.pswd_change_cnt);
         if ( inCxMemberTabObj.pswd_0 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_0); } 
         if ( inCxMemberTabObj.pswd_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_1); } 
         if ( inCxMemberTabObj.pswd_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_2); } 
         if ( inCxMemberTabObj.pswd_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_3); } 
         if ( inCxMemberTabObj.pswd_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_4); } 
         if ( inCxMemberTabObj.pswd_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_5); } 
         if ( inCxMemberTabObj.pswd_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_6); } 
         if ( inCxMemberTabObj.pswd_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_7); } 
         if ( inCxMemberTabObj.pswd_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_8); } 
         if ( inCxMemberTabObj.pswd_9 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_9); } 
         if ( inCxMemberTabObj.pswd_10 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_10); } 
         if ( inCxMemberTabObj.pswd_11 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_11); } 
         if ( inCxMemberTabObj.pswd_12 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_12); } 
         if ( inCxMemberTabObj.pswd_effective_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.pswd_effective_date); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(23, inCxMemberTabObj.expiry_period);
         if ( inCxMemberTabObj.hint != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.hint); } 
         if ( inCxMemberTabObj.hint_ans != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.hint_ans); } 
         if ( inCxMemberTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.status); } 
         if ( inCxMemberTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.rec_cre_date); } 
         if ( inCxMemberTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.rec_cre_time); } 
         if ( inCxMemberTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.rec_upd_date); } 
         if ( inCxMemberTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.rec_upd_time); } 
         if ( inCxMemberTabObj.address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.address_1); } 
         if ( inCxMemberTabObj.address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.address_2); } 
         if ( inCxMemberTabObj.city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.city); } 
         if ( inCxMemberTabObj.state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.state); } 
         if ( inCxMemberTabObj.zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.zip); } 
         if ( inCxMemberTabObj.country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.country); } 
         if ( inCxMemberTabObj.phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.phone_list); } 
         if ( inCxMemberTabObj.email_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.email_list); } 
         if ( inCxMemberTabObj.fax_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.fax_list); } 
         if ( inCxMemberTabObj.auth_rep_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.auth_rep_name); } 
         if ( inCxMemberTabObj.auth_rep_father_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.auth_rep_father_name); } 
         if ( inCxMemberTabObj.auth_rep_phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxMemberTabObj.auth_rep_phone_list); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(43, inCxMemberTabObj.pd_bal);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(44, inCxMemberTabObj.cd_bal);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(45, inCxMemberTabObj.cd_dr);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(46, inCxMemberTabObj.cd_cr);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(47, inCxMemberTabObj.cr_limit);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(48, inCxMemberTabObj.num_client_limit);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxMemberRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxMemberRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxMemberRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_MEMBER "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxMemberRecByPkeyWithSet
               ( CxMemberPkeyObj inCxMemberPkeyObj
               , String  inCxMemberSetlist
               )
  {
    int lUpdateCount;
    sop("updCxMemberRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxMemberRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_MEMBER ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxMemberSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxMemberPkeyObj.org_id+"' and "+
                              "member_id = "+"'"+inCxMemberPkeyObj.member_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxMemberRecByRowidWithSet
               ( String inRowId
               , String  inCxMemberSetlist
               )
  {
    int lUpdateCount;
    sop("updCxMemberRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxMemberRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_MEMBER ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxMemberSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxMemberRecByWhereWithSet
               ( String inCxMemberWhereText
               , String  inCxMemberSetlist
               )
  {
    int lUpdateCount;
    sop("updCxMemberRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxMemberRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_MEMBER ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxMemberSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxMemberRecByPkey
               ( CxMemberPkeyObj  inCxMemberPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxMemberRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxMemberRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_MEMBER " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxMemberPkeyObj.org_id+"' and "+
                              "member_id = "+"'"+inCxMemberPkeyObj.member_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxMemberByWhere
               ( String inCxMemberWhereText
               )
  {
    int lUpdateCount;
    sop("delCxMemberByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxMemberByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxMemberWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxMemberWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_MEMBER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
