package sstdb.cx.CxMemberSymbol;


public class CxMemberSymbolPkeyObj
{
  public String                                 org_id;
  public String                                 member_id;
  public String                                 contract_id;
}