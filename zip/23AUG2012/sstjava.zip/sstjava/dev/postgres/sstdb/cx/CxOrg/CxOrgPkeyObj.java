package sstdb.cx.CxOrg;


public class CxOrgPkeyObj
{
  public String                                 org_id;
}