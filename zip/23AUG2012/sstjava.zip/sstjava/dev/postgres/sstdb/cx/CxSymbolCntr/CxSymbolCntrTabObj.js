{


   function vldDBSizeEnvCxSymbolCntr
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeContractId ( inTableName, inFieldName );
      vldFieldDBSizeSymbolCd ( inTableName, inFieldName );
      vldFieldDBSizeSymbolName ( inTableName, inFieldName );
      vldFieldDBSizeEffDate ( inTableName, inFieldName );
      vldFieldDBSizeEffTime ( inTableName, inFieldName );
      vldFieldDBSizeExpDate ( inTableName, inFieldName );
      vldFieldDBSizeExpTime ( inTableName, inFieldName );
      vldFieldDBSizeDdr ( inTableName, inFieldName );
      vldFieldDBSizeExpRate ( inTableName, inFieldName );
      vldFieldDBSizeRateCurrency ( inTableName, inFieldName );
      vldFieldDBSizeRatePerUom ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPur1 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPurRt1 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPur2 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPurRt2 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPur3 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPurRt3 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPur4 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnPurRt4 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSal1 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSalRt1 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSal2 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSalRt2 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSal3 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSalRt3 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSal4 ( inTableName, inFieldName );
      vldFieldDBSizeSplMrgnSalRt4 ( inTableName, inFieldName );
      vldFieldDBSizeStatus ( inTableName, inFieldName );
      vldFieldDBSizeRecCreDate ( inTableName, inFieldName );
      vldFieldDBSizeRecCreTime ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdDate ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdTime ( inTableName, inFieldName );
   }



   function constructorCxSymbolCntr
   (
      org_id,
      contract_id,
      symbol_cd,
      symbol_name,
      eff_date,
      eff_time,
      exp_date,
      exp_time,
      ddr,
      exp_rate,
      rate_currency,
      rate_per_uom,
      spl_mrgn_pur_1,
      spl_mrgn_pur_rt_1,
      spl_mrgn_pur_2,
      spl_mrgn_pur_rt_2,
      spl_mrgn_pur_3,
      spl_mrgn_pur_rt_3,
      spl_mrgn_pur_4,
      spl_mrgn_pur_rt_4,
      spl_mrgn_sal_1,
      spl_mrgn_sal_rt_1,
      spl_mrgn_sal_2,
      spl_mrgn_sal_rt_2,
      spl_mrgn_sal_3,
      spl_mrgn_sal_rt_3,
      spl_mrgn_sal_4,
      spl_mrgn_sal_rt_4,
      status,
      rec_cre_date,
      rec_cre_time,
      rec_upd_date,
      rec_upd_time
   )
   {
      this.org_id = org_id;
      this.contract_id = contract_id;
      this.symbol_cd = symbol_cd;
      this.symbol_name = symbol_name;
      this.eff_date = eff_date;
      this.eff_time = eff_time;
      this.exp_date = exp_date;
      this.exp_time = exp_time;
      this.ddr = ddr;
      this.exp_rate = exp_rate;
      this.rate_currency = rate_currency;
      this.rate_per_uom = rate_per_uom;
      this.spl_mrgn_pur_1 = spl_mrgn_pur_1;
      this.spl_mrgn_pur_rt_1 = spl_mrgn_pur_rt_1;
      this.spl_mrgn_pur_2 = spl_mrgn_pur_2;
      this.spl_mrgn_pur_rt_2 = spl_mrgn_pur_rt_2;
      this.spl_mrgn_pur_3 = spl_mrgn_pur_3;
      this.spl_mrgn_pur_rt_3 = spl_mrgn_pur_rt_3;
      this.spl_mrgn_pur_4 = spl_mrgn_pur_4;
      this.spl_mrgn_pur_rt_4 = spl_mrgn_pur_rt_4;
      this.spl_mrgn_sal_1 = spl_mrgn_sal_1;
      this.spl_mrgn_sal_rt_1 = spl_mrgn_sal_rt_1;
      this.spl_mrgn_sal_2 = spl_mrgn_sal_2;
      this.spl_mrgn_sal_rt_2 = spl_mrgn_sal_rt_2;
      this.spl_mrgn_sal_3 = spl_mrgn_sal_3;
      this.spl_mrgn_sal_rt_3 = spl_mrgn_sal_rt_3;
      this.spl_mrgn_sal_4 = spl_mrgn_sal_4;
      this.spl_mrgn_sal_rt_4 = spl_mrgn_sal_rt_4;
      this.status = status;
      this.rec_cre_date = rec_cre_date;
      this.rec_cre_time = rec_cre_time;
      this.rec_upd_date = rec_upd_date;
      this.rec_upd_time = rec_upd_time;
   }



   function CxSymbolCntrFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lCxSymbolCntrTabObjJSArr.length )
      {
         if
         ( 
           ( lCxSymbolCntrTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lCxSymbolCntrTabObjJSArr[lRecNum].contract_id != document.form.contract_id.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeCxSymbolCntrTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjContractId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSymbolName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjEffDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjEffTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjExpDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjExpTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjDdr
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjExpRate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRateCurrency
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRatePerUom
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPur1
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPurRt1
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPur2
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPurRt2
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPur3
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPurRt3
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPur4
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnPurRt4
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSal1
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSalRt1
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSal2
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSalRt2
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSal3
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSalRt3
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSal4
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjSplMrgnSalRt4
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolCntrTabObjRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisContractId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSymbolName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisEffDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisEffTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisExpDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisExpTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDdr
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisExpRate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRateCurrency
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRatePerUom
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPur1
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPurRt1
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPur2
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPurRt2
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPur3
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPurRt3
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPur4
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnPurRt4
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSal1
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSalRt1
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSal2
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSalRt2
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSal3
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSalRt3
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSal4
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSplMrgnSalRt4
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



}