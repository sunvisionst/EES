CREATE TABLE CX_DTXN_CF_EXT
(
  org_id                                                                                              VARCHAR(10),
  txn_num                                                                                             VARCHAR(20),
  txn_date                                                                                            VARCHAR(8),
  txn_time                                                                                            VARCHAR(6),
  txn_type                                                                                            VARCHAR(1),
  link_txn_num                                                                                        VARCHAR(20),
  link_txn_date                                                                                       VARCHAR(8),
  link_txn_time                                                                                       VARCHAR(6),
  member_id                                                                                           VARCHAR(20),
  member_name                                                                                         VARCHAR(100),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  qty                                                                                                 NUMERIC(9),
  rate                                                                                                NUMERIC(13,2),
  status                                                                                              VARCHAR(10),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       TXN_NUM                                                                                             CHAR(20),
       TXN_DATE                                                                                            CHAR(8),
       TXN_TIME                                                                                            CHAR(6),
       TXN_TYPE                                                                                            CHAR(1),
       LINK_TXN_NUM                                                                                        CHAR(20),
       LINK_TXN_DATE                                                                                       CHAR(8),
       LINK_TXN_TIME                                                                                       CHAR(6),
       MEMBER_ID                                                                                           CHAR(20),
       MEMBER_NAME                                                                                         CHAR(100),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       QTY                                                                                                 CHAR(9),
       RATE                                                                                                CHAR(13),
       STATUS                                                                                              CHAR(10),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_dtxn_cf_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
