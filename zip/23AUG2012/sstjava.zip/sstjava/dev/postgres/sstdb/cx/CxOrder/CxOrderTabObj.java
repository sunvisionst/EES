package sstdb.cx.CxOrder;


public class CxOrderTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 ord_num;
  public int                                  ord_seq_num;
  public String                                 ord_date;
  public String                                 ord_time;
  public String                                 txn_type;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public String                                 buyer;
  public String                                 seller;
  public int                                  buy_qty;
  public int                                  sale_qty;
  public int                                  bal_qty;
  public double                                 rate;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  ord_num_ind;
  public short                                  ord_seq_num_ind;
  public short                                  ord_date_ind;
  public short                                  ord_time_ind;
  public short                                  txn_type_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  buyer_ind;
  public short                                  seller_ind;
  public short                                  buy_qty_ind;
  public short                                  sale_qty_ind;
  public short                                  bal_qty_ind;
  public short                                  rate_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxOrderTabObj(){}


  public CxOrderTabObj
  (
    String org_id,
    String ord_num,
    int ord_seq_num,
    String ord_date,
    String ord_time,
    String txn_type,
    String contract_id,
    String symbol_cd,
    String buyer,
    String seller,
    int buy_qty,
    int sale_qty,
    int bal_qty,
    double rate,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.ord_num = ord_num;
     this.ord_seq_num = ord_seq_num;
     this.ord_date = ord_date;
     this.ord_time = ord_time;
     this.txn_type = txn_type;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.buyer = buyer;
     this.seller = seller;
     this.buy_qty = buy_qty;
     this.sale_qty = sale_qty;
     this.bal_qty = bal_qty;
     this.rate = rate;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getord_num()                          { return ord_num; }
  public int getord_seq_num()                          { return ord_seq_num; }
  public String getord_date()                          { return ord_date; }
  public String getord_time()                          { return ord_time; }
  public String gettxn_type()                          { return txn_type; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public String getbuyer()                           { return buyer; }
  public String getseller()                           { return seller; }
  public int getbuy_qty()                            { return buy_qty; }
  public int getsale_qty()                           { return sale_qty; }
  public int getbal_qty()                            { return bal_qty; }
  public double getrate()                            { return rate; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setord_num(String ord_num )                   { this.ord_num = ord_num; }
  public void  setord_seq_num(int ord_seq_num )                 { this.ord_seq_num = ord_seq_num; }
  public void  setord_date(String ord_date )                  { this.ord_date = ord_date; }
  public void  setord_time(String ord_time )                  { this.ord_time = ord_time; }
  public void  settxn_type(String txn_type )                  { this.txn_type = txn_type; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setbuyer(String buyer )                     { this.buyer = buyer; }
  public void  setseller(String seller )                    { this.seller = seller; }
  public void  setbuy_qty(int buy_qty )                     { this.buy_qty = buy_qty; }
  public void  setsale_qty(int sale_qty )                    { this.sale_qty = sale_qty; }
  public void  setbal_qty(int bal_qty )                     { this.bal_qty = bal_qty; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}