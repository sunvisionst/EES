package sstdb.cx.CxSymbolDaily;


public class CxSymbolDailyTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 curr_date;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public String                                 symbol_name;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 eff_date;
  public String                                 eff_time;
  public String                                 exp_date;
  public String                                 exp_time;
  public double                                 exp_rate;
  public double                                 fwd_rate;
  public double                                 fut_rate;
  public double                                 spot_rate;
  public double                                 ltp;
  public String                                 ltp_date;
  public String                                 ltp_time;
  public String                                 rate_currency;
  public String                                 rate_per_uom;
  public double                                 net_change;
  public float                                 percent_change;
  public double                                 high;
  public double                                 low;
  public double                                 bbr;
  public int                                  bbq;
  public double                                 bsr;
  public int                                  bsq;
  public double                                 open_rate;
  public double                                 close_rate;





  public short                                  org_id_ind;
  public short                                  curr_date_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  symbol_name_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  eff_date_ind;
  public short                                  eff_time_ind;
  public short                                  exp_date_ind;
  public short                                  exp_time_ind;
  public short                                  exp_rate_ind;
  public short                                  fwd_rate_ind;
  public short                                  fut_rate_ind;
  public short                                  spot_rate_ind;
  public short                                  ltp_ind;
  public short                                  ltp_date_ind;
  public short                                  ltp_time_ind;
  public short                                  rate_currency_ind;
  public short                                  rate_per_uom_ind;
  public short                                  net_change_ind;
  public short                                  percent_change_ind;
  public short                                  high_ind;
  public short                                  low_ind;
  public short                                  bbr_ind;
  public short                                  bbq_ind;
  public short                                  bsr_ind;
  public short                                  bsq_ind;
  public short                                  open_rate_ind;
  public short                                  close_rate_ind;


  public CxSymbolDailyTabObj(){}


  public CxSymbolDailyTabObj
  (
    String org_id,
    String curr_date,
    String contract_id,
    String symbol_cd,
    String symbol_name,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String eff_date,
    String eff_time,
    String exp_date,
    String exp_time,
    double exp_rate,
    double fwd_rate,
    double fut_rate,
    double spot_rate,
    double ltp,
    String ltp_date,
    String ltp_time,
    String rate_currency,
    String rate_per_uom,
    double net_change,
    float percent_change,
    double high,
    double low,
    double bbr,
    int bbq,
    double bsr,
    int bsq,
    double open_rate,
    double close_rate
  )
  {
     this.org_id = org_id;
     this.curr_date = curr_date;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.symbol_name = symbol_name;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.eff_date = eff_date;
     this.eff_time = eff_time;
     this.exp_date = exp_date;
     this.exp_time = exp_time;
     this.exp_rate = exp_rate;
     this.fwd_rate = fwd_rate;
     this.fut_rate = fut_rate;
     this.spot_rate = spot_rate;
     this.ltp = ltp;
     this.ltp_date = ltp_date;
     this.ltp_time = ltp_time;
     this.rate_currency = rate_currency;
     this.rate_per_uom = rate_per_uom;
     this.net_change = net_change;
     this.percent_change = percent_change;
     this.high = high;
     this.low = low;
     this.bbr = bbr;
     this.bbq = bbq;
     this.bsr = bsr;
     this.bsq = bsq;
     this.open_rate = open_rate;
     this.close_rate = close_rate;
  }

  public String getorg_id()                           { return org_id; }
  public String getcurr_date()                         { return curr_date; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public String getsymbol_name()                        { return symbol_name; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String geteff_date()                          { return eff_date; }
  public String geteff_time()                          { return eff_time; }
  public String getexp_date()                          { return exp_date; }
  public String getexp_time()                          { return exp_time; }
  public double getexp_rate()                          { return exp_rate; }
  public double getfwd_rate()                          { return fwd_rate; }
  public double getfut_rate()                          { return fut_rate; }
  public double getspot_rate()                         { return spot_rate; }
  public double getltp()                            { return ltp; }
  public String getltp_date()                          { return ltp_date; }
  public String getltp_time()                          { return ltp_time; }
  public String getrate_currency()                       { return rate_currency; }
  public String getrate_per_uom()                        { return rate_per_uom; }
  public double getnet_change()                         { return net_change; }
  public float getpercent_change()                       { return percent_change; }
  public double gethigh()                            { return high; }
  public double getlow()                            { return low; }
  public double getbbr()                            { return bbr; }
  public int getbbq()                              { return bbq; }
  public double getbsr()                            { return bsr; }
  public int getbsq()                              { return bsq; }
  public double getopen_rate()                         { return open_rate; }
  public double getclose_rate()                         { return close_rate; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcurr_date(String curr_date )                 { this.curr_date = curr_date; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setsymbol_name(String symbol_name )               { this.symbol_name = symbol_name; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  seteff_date(String eff_date )                  { this.eff_date = eff_date; }
  public void  seteff_time(String eff_time )                  { this.eff_time = eff_time; }
  public void  setexp_date(String exp_date )                  { this.exp_date = exp_date; }
  public void  setexp_time(String exp_time )                  { this.exp_time = exp_time; }
  public void  setexp_rate(double exp_rate )                  { this.exp_rate = exp_rate; }
  public void  setfwd_rate(double fwd_rate )                  { this.fwd_rate = fwd_rate; }
  public void  setfut_rate(double fut_rate )                  { this.fut_rate = fut_rate; }
  public void  setspot_rate(double spot_rate )                 { this.spot_rate = spot_rate; }
  public void  setltp(double ltp )                       { this.ltp = ltp; }
  public void  setltp_date(String ltp_date )                  { this.ltp_date = ltp_date; }
  public void  setltp_time(String ltp_time )                  { this.ltp_time = ltp_time; }
  public void  setrate_currency(String rate_currency )             { this.rate_currency = rate_currency; }
  public void  setrate_per_uom(String rate_per_uom )              { this.rate_per_uom = rate_per_uom; }
  public void  setnet_change(double net_change )                { this.net_change = net_change; }
  public void  setpercent_change(float percent_change )             { this.percent_change = percent_change; }
  public void  sethigh(double high )                      { this.high = high; }
  public void  setlow(double low )                       { this.low = low; }
  public void  setbbr(double bbr )                       { this.bbr = bbr; }
  public void  setbbq(int bbq )                         { this.bbq = bbq; }
  public void  setbsr(double bsr )                       { this.bsr = bsr; }
  public void  setbsq(int bsq )                         { this.bsq = bsq; }
  public void  setopen_rate(double open_rate )                 { this.open_rate = open_rate; }
  public void  setclose_rate(double close_rate )                { this.close_rate = close_rate; }
}