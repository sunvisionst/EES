
var lCxDtxnCfTabObjJSArr = new Array();
<%
{
   if ( lCxDtxnCfTabObjArrCache != null && lCxDtxnCfTabObjArrCache.size() > 0 )
   {
%>
       lCxDtxnCfTabObjJSArr = new Array(<%=lCxDtxnCfTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxDtxnCfTabObjArrCache.size(); lRecNum++ )
       {
          CxDtxnCfTabObj lCxDtxnCfTabObj    =    new CxDtxnCfTabObj();
          lCxDtxnCfTabObj = (CxDtxnCfTabObj)lCxDtxnCfTabObjArrCache.get(lRecNum);
%>
          lCxDtxnCfTabObjJSArr[<%=lRecNum%>] = new constructorCxDtxnCf
          (
          "<%=lCxDtxnCfTabObj.org_id%>",
          "<%=lCxDtxnCfTabObj.txn_num%>",
          "<%=lCxDtxnCfTabObj.txn_date%>",
          "<%=lCxDtxnCfTabObj.txn_time%>",
          "<%=lCxDtxnCfTabObj.txn_type%>",
          "<%=lCxDtxnCfTabObj.link_txn_num%>",
          "<%=lCxDtxnCfTabObj.link_txn_date%>",
          "<%=lCxDtxnCfTabObj.link_txn_time%>",
          "<%=lCxDtxnCfTabObj.member_id%>",
          "<%=lCxDtxnCfTabObj.member_name%>",
          "<%=lCxDtxnCfTabObj.contract_id%>",
          "<%=lCxDtxnCfTabObj.symbol_cd%>",
          "<%=lCxDtxnCfTabObj.qty%>",
          "<%=lCxDtxnCfTabObj.rate%>",
          "<%=lCxDtxnCfTabObj.status%>",
          "<%=lCxDtxnCfTabObj.rec_cre_date%>",
          "<%=lCxDtxnCfTabObj.rec_cre_time%>",
          "<%=lCxDtxnCfTabObj.rec_upd_date%>",
          "<%=lCxDtxnCfTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


