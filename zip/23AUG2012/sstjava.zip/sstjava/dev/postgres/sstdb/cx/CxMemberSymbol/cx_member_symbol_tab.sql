CREATE TABLE CX_MEMBER_SYMBOL
(
  ORG_ID                                                                                              VARCHAR(10),
  MEMBER_ID                                                                                           VARCHAR(20),
  CONTRACT_ID                                                                                         VARCHAR(20),
  SYMBOL_CD                                                                                           VARCHAR(20),
  SYMBOL_NAME                                                                                         VARCHAR(50),
  LINK_MEMBER_ID                                                                                      VARCHAR(20),
  STATUS                                                                                              VARCHAR(5),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
