package sstdb.cx.CxDtxn;

import sstdb.cx.CxDtxn.CxDtxnTabObj;
import sstdb.cx.CxDtxn.CxDtxnPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxDtxnMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxDtxnMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxDtxnMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxDtxnTabObj
               ( 
                 CxDtxnTabObj  outCxDtxnTabObj
               )
  {
  
     outCxDtxnTabObj.org_id = ""; 
     outCxDtxnTabObj.txn_num = ""; 
     outCxDtxnTabObj.txn_date = ""; 
     outCxDtxnTabObj.txn_time = ""; 
     outCxDtxnTabObj.txn_type = ""; 
     outCxDtxnTabObj.member_id = ""; 
     outCxDtxnTabObj.member_name = ""; 
     outCxDtxnTabObj.contract_id = ""; 
     outCxDtxnTabObj.symbol_cd = ""; 
     outCxDtxnTabObj.qty = (int)0; 
     outCxDtxnTabObj.mature_qty = (int)0; 
     outCxDtxnTabObj.rate = (double)0.00; 
     outCxDtxnTabObj.cf_txn_num = ""; 
     outCxDtxnTabObj.cf_rate = (double)0.00; 
     outCxDtxnTabObj.cf_date = ""; 
     outCxDtxnTabObj.cf_time = ""; 
     outCxDtxnTabObj.status = ""; 
     outCxDtxnTabObj.reg_ind = ""; 
     outCxDtxnTabObj.reg_limit = (double)0.00; 
     outCxDtxnTabObj.slr_ind = ""; 
     outCxDtxnTabObj.slr_limit = (double)0.00; 
     outCxDtxnTabObj.rec_cre_date = ""; 
     outCxDtxnTabObj.rec_cre_time = ""; 
     outCxDtxnTabObj.rec_upd_date = ""; 
     outCxDtxnTabObj.rec_upd_time = ""; 
  }





  public void guiDateConvCxDtxnTabObj
               ( 
                 CxDtxnTabObj  inCxDtxnTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxDtxnTabObj.txn_date != null && inCxDtxnTabObj.txn_date.length() > 0 ) 
            inCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnTabObj.txn_date, lDateTimeTrgFmt);

          if ( inCxDtxnTabObj.cf_date != null && inCxDtxnTabObj.cf_date.length() > 0 ) 
            inCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnTabObj.cf_date, lDateTimeTrgFmt);

          if ( inCxDtxnTabObj.rec_cre_date != null && inCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxDtxnTabObj.rec_upd_date != null && inCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxDtxnByTabObj
               ( 
                 CxDtxnTabObj  inCxDtxnTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxDtxnTabObjArrCtx  = new ArrayList(); 
    lCxDtxnTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxDtxnTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxDtxnTabObjArrCtx.add(inCxDtxnTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxDtxnTabObjArrCtx.size();  lRecNum++ )
      {
        CxDtxnTabObj lCxDtxnTabObj = new CxDtxnTabObj();
        lCxDtxnTabObj = (CxDtxnTabObj)lCxDtxnTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxDtxnTabObj.org_id.equals(lCxDtxnTabObj.org_id) &&
              lCxDtxnTabObj.txn_num.equals(lCxDtxnTabObj.txn_num) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxDtxnTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxDtxnTabObjArrCtx.set(lRecNum, inCxDtxnTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxDtxnTabObjArrCtx",lCxDtxnTabObjArrCtx);
  }





  public void sortCxDtxnTabObjArr
               ( 
                 ArrayList  inCxDtxnTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxDtxnTabObjArr  = new ArrayList(); 
     lCxDtxnTabObjArr = inCxDtxnTabObjArr; 
     List lCxDtxnTabObjList  = new ArrayList(lCxDtxnTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxDtxnTabObjArr.size();  lRecNum++ )
     {
       CxDtxnTabObj  lCxDtxnTabObj = new CxDtxnTabObj(); 
       lCxDtxnTabObj = (CxDtxnTabObj)lCxDtxnTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxDtxnTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnTabObj.txn_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.txn_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnTabObj.txn_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.txn_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnTabObj.txn_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.txn_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxDtxnTabObj.txn_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.txn_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnTabObj.member_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.member_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxDtxnTabObj.member_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.member_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("contract_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnTabObj.contract_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.contract_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_cd") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnTabObj.symbol_cd.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.symbol_cd+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxDtxnTabObj.qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mature_qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxDtxnTabObj.mature_qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.mature_qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxDtxnTabObj.rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cf_txn_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnTabObj.cf_txn_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.cf_txn_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cf_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxDtxnTabObj.cf_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.cf_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cf_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnTabObj.cf_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.cf_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cf_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnTabObj.cf_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.cf_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxDtxnTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reg_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxDtxnTabObj.reg_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.reg_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reg_limit") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxDtxnTabObj.reg_limit).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.reg_limit+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("slr_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxDtxnTabObj.slr_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.slr_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("slr_limit") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxDtxnTabObj.slr_limit).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.slr_limit+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnTabObj.rec_upd_time+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxDtxnTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxDtxnTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxDtxnTabObjList ); 
     ArrayList lCxDtxnTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxDtxnTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxDtxnTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxDtxnTabObjArrSorted.add( (CxDtxnTabObj)lCxDtxnTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxDtxnTabObjArr.size();  lRecNum++ )
     {
       inCxDtxnTabObjArr.set( lRecNum, (CxDtxnTabObj)lCxDtxnTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxDtxnTabObj
               ( 
                 CxDtxnTabObj  inCxDtxnTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxDtxnTabObj.txn_date != null && inCxDtxnTabObj.txn_date.length() > 0 ) 
            inCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.cf_date != null && inCxDtxnTabObj.cf_date.length() > 0 ) 
            inCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.cf_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_cre_date != null && inCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_upd_date != null && inCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_TYPE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeContractId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CONTRACT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolCd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_CD";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMatureQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MATURE_QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCfTxnNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CF_TXN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCfRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CF_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCfDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CF_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCfTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CF_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRegInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REG_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRegLimit
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REG_LIMIT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSlrInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SLR_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSlrLimit
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SLR_LIMIT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxDtxnCount
               ( String inCxDtxnWhereText
               )
  {
    sop("gtCxDtxnCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCount
               ( String inCxDtxnWhereText
               , String inCxDtxnSelectFieldList
               )
  {
    sop("gtCxDtxnCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxDtxnSelectFieldList+" AS count "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnRecByPkey
               ( CxDtxnPkeyObj inCxDtxnPkeyObj
               , CxDtxnTabObj  outCxDtxnTabObj
               )
  {
    sop("gtCxDtxnRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "mature_qty, "+
                                 "rate, "+
                                 "cf_txn_num, "+
                                 "cf_rate, "+
                                 "cf_date, "+
                                 "cf_time, "+
                                 "status, "+
                                 "reg_ind, "+
                                 "reg_limit, "+
                                 "slr_ind, "+
                                 "slr_limit, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnPkeyObj.txn_num+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxDtxnTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxDtxnTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxDtxnTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          outCxDtxnTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( outCxDtxnTabObj.txn_date != null && outCxDtxnTabObj.txn_date.length() > 0 ) 
            outCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.txn_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          outCxDtxnTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          outCxDtxnTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxDtxnTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxDtxnTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxDtxnTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxDtxnTabObj.qty  =  lResultSet.getInt("QTY");
          outCxDtxnTabObj.mature_qty  =  lResultSet.getInt("MATURE_QTY");
          outCxDtxnTabObj.rate  =  lResultSet.getDouble("RATE");
          outCxDtxnTabObj.cf_txn_num  =  lResultSet.getString("CF_TXN_NUM");
          outCxDtxnTabObj.cf_rate  =  lResultSet.getDouble("CF_RATE");
          outCxDtxnTabObj.cf_date  =  lResultSet.getString("CF_DATE");

          if ( outCxDtxnTabObj.cf_date != null && outCxDtxnTabObj.cf_date.length() > 0 ) 
            outCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.cf_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.cf_time  =  lResultSet.getString("CF_TIME");
          outCxDtxnTabObj.status  =  lResultSet.getString("STATUS");
          outCxDtxnTabObj.reg_ind  =  lResultSet.getString("REG_IND");
          outCxDtxnTabObj.reg_limit  =  lResultSet.getDouble("REG_LIMIT");
          outCxDtxnTabObj.slr_ind  =  lResultSet.getString("SLR_IND");
          outCxDtxnTabObj.slr_limit  =  lResultSet.getDouble("SLR_LIMIT");
          outCxDtxnTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxDtxnTabObj.rec_cre_date != null && outCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            outCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxDtxnTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxDtxnTabObj.rec_upd_date != null && outCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            outCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxDtxnTabObj( outCxDtxnTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnArr
               ( CxDtxnPkeyObj inCxDtxnPkeyObj
               , ArrayList  outCxDtxnTabObjArr
               )
  {
    sop("gtCxDtxnArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "mature_qty, "+
                                 "rate, "+
                                 "cf_txn_num, "+
                                 "cf_rate, "+
                                 "cf_date, "+
                                 "cf_time, "+
                                 "status, "+
                                 "reg_ind, "+
                                 "reg_limit, "+
                                 "slr_ind, "+
                                 "slr_limit, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxDtxnTabObj  lCxDtxnTabObj = new CxDtxnTabObj();
          lCxDtxnTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxDtxnTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxDtxnTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          lCxDtxnTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( lCxDtxnTabObj.txn_date != null && lCxDtxnTabObj.txn_date.length() > 0 ) 
            lCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.txn_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          lCxDtxnTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          lCxDtxnTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxDtxnTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxDtxnTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxDtxnTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxDtxnTabObj.qty  =  lResultSet.getInt("QTY");
          lCxDtxnTabObj.mature_qty  =  lResultSet.getInt("MATURE_QTY");
          lCxDtxnTabObj.rate  =  lResultSet.getDouble("RATE");
          lCxDtxnTabObj.cf_txn_num  =  lResultSet.getString("CF_TXN_NUM");
          lCxDtxnTabObj.cf_rate  =  lResultSet.getDouble("CF_RATE");
          lCxDtxnTabObj.cf_date  =  lResultSet.getString("CF_DATE");

          if ( lCxDtxnTabObj.cf_date != null && lCxDtxnTabObj.cf_date.length() > 0 ) 
            lCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.cf_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.cf_time  =  lResultSet.getString("CF_TIME");
          lCxDtxnTabObj.status  =  lResultSet.getString("STATUS");
          lCxDtxnTabObj.reg_ind  =  lResultSet.getString("REG_IND");
          lCxDtxnTabObj.reg_limit  =  lResultSet.getDouble("REG_LIMIT");
          lCxDtxnTabObj.slr_ind  =  lResultSet.getString("SLR_IND");
          lCxDtxnTabObj.slr_limit  =  lResultSet.getDouble("SLR_LIMIT");
          lCxDtxnTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxDtxnTabObj.rec_cre_date != null && lCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxDtxnTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxDtxnTabObj.rec_upd_date != null && lCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxDtxnTabObj( lCxDtxnTabObj );

          outCxDtxnTabObjArr.add(  lCxDtxnTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnTabObjArr != null && outCxDtxnTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxDtxnArr2XML
               ( String inCxDtxnWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxDtxnArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxDtxn>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_num") )
              lXmlBuffer = lXmlBuffer +   "<TXN_NUM>" +  lResultSet.getString("TXN_NUM") +   "</TXN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_date") )
              lXmlBuffer = lXmlBuffer +   "<TXN_DATE>" +  lResultSet.getString("TXN_DATE") +   "</TXN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_time") )
              lXmlBuffer = lXmlBuffer +   "<TXN_TIME>" +  lResultSet.getString("TXN_TIME") +   "</TXN_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_type") )
              lXmlBuffer = lXmlBuffer +   "<TXN_TYPE>" +  lResultSet.getString("TXN_TYPE") +   "</TXN_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_id") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_ID>" +  lResultSet.getString("MEMBER_ID") +   "</MEMBER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_name") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_NAME>" +  lResultSet.getString("MEMBER_NAME") +   "</MEMBER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("contract_id") )
              lXmlBuffer = lXmlBuffer +   "<CONTRACT_ID>" +  lResultSet.getString("CONTRACT_ID") +   "</CONTRACT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_cd") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_CD>" +  lResultSet.getString("SYMBOL_CD") +   "</SYMBOL_CD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("qty") )
              lXmlBuffer = lXmlBuffer +   "<QTY>" +  lResultSet.getInt("QTY") +   "</QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mature_qty") )
              lXmlBuffer = lXmlBuffer +   "<MATURE_QTY>" +  lResultSet.getInt("MATURE_QTY") +   "</MATURE_QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate") )
              lXmlBuffer = lXmlBuffer +   "<RATE>" +  lResultSet.getDouble("RATE") +   "</RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cf_txn_num") )
              lXmlBuffer = lXmlBuffer +   "<CF_TXN_NUM>" +  lResultSet.getString("CF_TXN_NUM") +   "</CF_TXN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cf_rate") )
              lXmlBuffer = lXmlBuffer +   "<CF_RATE>" +  lResultSet.getDouble("CF_RATE") +   "</CF_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cf_date") )
              lXmlBuffer = lXmlBuffer +   "<CF_DATE>" +  lResultSet.getString("CF_DATE") +   "</CF_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cf_time") )
              lXmlBuffer = lXmlBuffer +   "<CF_TIME>" +  lResultSet.getString("CF_TIME") +   "</CF_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reg_ind") )
              lXmlBuffer = lXmlBuffer +   "<REG_IND>" +  lResultSet.getString("REG_IND") +   "</REG_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reg_limit") )
              lXmlBuffer = lXmlBuffer +   "<REG_LIMIT>" +  lResultSet.getDouble("REG_LIMIT") +   "</REG_LIMIT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("slr_ind") )
              lXmlBuffer = lXmlBuffer +   "<SLR_IND>" +  lResultSet.getString("SLR_IND") +   "</SLR_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("slr_limit") )
              lXmlBuffer = lXmlBuffer +   "<SLR_LIMIT>" +  lResultSet.getDouble("SLR_LIMIT") +   "</SLR_LIMIT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxDtxn>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxDtxnRecByRowid
               ( String inRowId
               , CxDtxnTabObj  outCxDtxnTabObj
               )
  {
    sop("gtCxDtxnRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "mature_qty, "+
                                 "rate, "+
                                 "cf_txn_num, "+
                                 "cf_rate, "+
                                 "cf_date, "+
                                 "cf_time, "+
                                 "status, "+
                                 "reg_ind, "+
                                 "reg_limit, "+
                                 "slr_ind, "+
                                 "slr_limit, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxDtxnTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxDtxnTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxDtxnTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          outCxDtxnTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( outCxDtxnTabObj.txn_date != null && outCxDtxnTabObj.txn_date.length() > 0 ) 
            outCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.txn_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          outCxDtxnTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          outCxDtxnTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxDtxnTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxDtxnTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxDtxnTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxDtxnTabObj.qty  =  lResultSet.getInt("QTY");
          outCxDtxnTabObj.mature_qty  =  lResultSet.getInt("MATURE_QTY");
          outCxDtxnTabObj.rate  =  lResultSet.getDouble("RATE");
          outCxDtxnTabObj.cf_txn_num  =  lResultSet.getString("CF_TXN_NUM");
          outCxDtxnTabObj.cf_rate  =  lResultSet.getDouble("CF_RATE");
          outCxDtxnTabObj.cf_date  =  lResultSet.getString("CF_DATE");

          if ( outCxDtxnTabObj.cf_date != null && outCxDtxnTabObj.cf_date.length() > 0 ) 
            outCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.cf_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.cf_time  =  lResultSet.getString("CF_TIME");
          outCxDtxnTabObj.status  =  lResultSet.getString("STATUS");
          outCxDtxnTabObj.reg_ind  =  lResultSet.getString("REG_IND");
          outCxDtxnTabObj.reg_limit  =  lResultSet.getDouble("REG_LIMIT");
          outCxDtxnTabObj.slr_ind  =  lResultSet.getString("SLR_IND");
          outCxDtxnTabObj.slr_limit  =  lResultSet.getDouble("SLR_LIMIT");
          outCxDtxnTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxDtxnTabObj.rec_cre_date != null && outCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            outCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxDtxnTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxDtxnTabObj.rec_upd_date != null && outCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            outCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxDtxnTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxDtxnTabObj( outCxDtxnTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnArr
               ( String inCxDtxnWhereText
               , ArrayList  outCxDtxnTabObjArr
               )
  {
    sop("gtCxDtxnArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "mature_qty, "+
                                 "rate, "+
                                 "cf_txn_num, "+
                                 "cf_rate, "+
                                 "cf_date, "+
                                 "cf_time, "+
                                 "status, "+
                                 "reg_ind, "+
                                 "reg_limit, "+
                                 "slr_ind, "+
                                 "slr_limit, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxDtxnTabObj  lCxDtxnTabObj = new CxDtxnTabObj();
          lCxDtxnTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxDtxnTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxDtxnTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          lCxDtxnTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( lCxDtxnTabObj.txn_date != null && lCxDtxnTabObj.txn_date.length() > 0 ) 
            lCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.txn_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          lCxDtxnTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          lCxDtxnTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxDtxnTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxDtxnTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxDtxnTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxDtxnTabObj.qty  =  lResultSet.getInt("QTY");
          lCxDtxnTabObj.mature_qty  =  lResultSet.getInt("MATURE_QTY");
          lCxDtxnTabObj.rate  =  lResultSet.getDouble("RATE");
          lCxDtxnTabObj.cf_txn_num  =  lResultSet.getString("CF_TXN_NUM");
          lCxDtxnTabObj.cf_rate  =  lResultSet.getDouble("CF_RATE");
          lCxDtxnTabObj.cf_date  =  lResultSet.getString("CF_DATE");

          if ( lCxDtxnTabObj.cf_date != null && lCxDtxnTabObj.cf_date.length() > 0 ) 
            lCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.cf_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.cf_time  =  lResultSet.getString("CF_TIME");
          lCxDtxnTabObj.status  =  lResultSet.getString("STATUS");
          lCxDtxnTabObj.reg_ind  =  lResultSet.getString("REG_IND");
          lCxDtxnTabObj.reg_limit  =  lResultSet.getDouble("REG_LIMIT");
          lCxDtxnTabObj.slr_ind  =  lResultSet.getString("SLR_IND");
          lCxDtxnTabObj.slr_limit  =  lResultSet.getDouble("SLR_LIMIT");
          lCxDtxnTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxDtxnTabObj.rec_cre_date != null && lCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxDtxnTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxDtxnTabObj.rec_upd_date != null && lCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxDtxnTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxDtxnTabObj( lCxDtxnTabObj );

          outCxDtxnTabObjArr.add(  lCxDtxnTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnTabObjArr != null && outCxDtxnTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnArrDist
               ( String inCxDtxnWhereText
               , String inDistCxDtxnField
               , ArrayList  outCxDtxnTabObjArr
               )
  {

    sop("gtCxDtxnArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";
  

       String lDistCxDtxnFieldQry = inDistCxDtxnField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxDtxnFieldQry+
                         " FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxDtxnField.substring(inDistCxDtxnField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxDtxnTabObj  lCxDtxnTabObj = new CxDtxnTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxDtxnTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_num") )
              lCxDtxnTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_date") )
              {
              lCxDtxnTabObj.txn_date  =  lResultSet.getString("TXN_DATE");
  
          if ( lCxDtxnTabObj.txn_date != null && lCxDtxnTabObj.txn_date.length() > 0 ) 
            lCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.txn_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_time") )
              lCxDtxnTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_type") )
              lCxDtxnTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_id") )
              lCxDtxnTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_name") )
              lCxDtxnTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("contract_id") )
              lCxDtxnTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_cd") )
              lCxDtxnTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("qty") )
              lCxDtxnTabObj.qty  =  lResultSet.getInt("QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mature_qty") )
              lCxDtxnTabObj.mature_qty  =  lResultSet.getInt("MATURE_QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate") )
              lCxDtxnTabObj.rate  =  lResultSet.getDouble("RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cf_txn_num") )
              lCxDtxnTabObj.cf_txn_num  =  lResultSet.getString("CF_TXN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cf_rate") )
              lCxDtxnTabObj.cf_rate  =  lResultSet.getDouble("CF_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cf_date") )
              {
              lCxDtxnTabObj.cf_date  =  lResultSet.getString("CF_DATE");
  
          if ( lCxDtxnTabObj.cf_date != null && lCxDtxnTabObj.cf_date.length() > 0 ) 
            lCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.cf_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cf_time") )
              lCxDtxnTabObj.cf_time  =  lResultSet.getString("CF_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxDtxnTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reg_ind") )
              lCxDtxnTabObj.reg_ind  =  lResultSet.getString("REG_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reg_limit") )
              lCxDtxnTabObj.reg_limit  =  lResultSet.getDouble("REG_LIMIT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("slr_ind") )
              lCxDtxnTabObj.slr_ind  =  lResultSet.getString("SLR_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("slr_limit") )
              lCxDtxnTabObj.slr_limit  =  lResultSet.getDouble("SLR_LIMIT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxDtxnTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxDtxnTabObj.rec_cre_date != null && lCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxDtxnTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxDtxnTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxDtxnTabObj.rec_upd_date != null && lCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxDtxnTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          }
          removeNullCxDtxnTabObj( lCxDtxnTabObj );

          outCxDtxnTabObjArr.add(  lCxDtxnTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnTabObjArr != null && outCxDtxnTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnStrArrDist
               ( String inCxDtxnWhereText
               , String inDistCxDtxnField
               , ArrayList  outCxDtxnTabObjArr
               )
  {

    sop("gtCxDtxnStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";
  

       String lDistCxDtxnFieldQry = inDistCxDtxnField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxDtxnFieldQry+
                         " FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxDtxnField.substring(inDistCxDtxnField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxDtxnTabObjStr = "";
       while(lResultSet.next())
       {
          lCxDtxnTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxDtxnTabObjStr =   lCxDtxnTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxDtxnTabObjArr.add(  lCxDtxnTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnTabObjArr != null && outCxDtxnTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxDtxn
               ( String inCxDtxnWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxDtxn - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxDtxn";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxDtxnTabObj
               ( 
                 CxDtxnTabObj  outCxDtxnTabObj
               )
  {
  
    if ( outCxDtxnTabObj.org_id == null ) 
     outCxDtxnTabObj.org_id = ""; 
    if ( outCxDtxnTabObj.txn_num == null ) 
     outCxDtxnTabObj.txn_num = ""; 
    if ( outCxDtxnTabObj.txn_date == null ) 
     outCxDtxnTabObj.txn_date = ""; 
    if ( outCxDtxnTabObj.txn_time == null ) 
     outCxDtxnTabObj.txn_time = ""; 
    if ( outCxDtxnTabObj.txn_type == null ) 
     outCxDtxnTabObj.txn_type = ""; 
    if ( outCxDtxnTabObj.member_id == null ) 
     outCxDtxnTabObj.member_id = ""; 
    if ( outCxDtxnTabObj.member_name == null ) 
     outCxDtxnTabObj.member_name = ""; 
    if ( outCxDtxnTabObj.contract_id == null ) 
     outCxDtxnTabObj.contract_id = ""; 
    if ( outCxDtxnTabObj.symbol_cd == null ) 
     outCxDtxnTabObj.symbol_cd = ""; 
    if ( outCxDtxnTabObj.qty == (int)0 ) 
     outCxDtxnTabObj.qty = (int)0; 
    if ( outCxDtxnTabObj.mature_qty == (int)0 ) 
     outCxDtxnTabObj.mature_qty = (int)0; 
    if ( outCxDtxnTabObj.rate == (double)0.00 ) 
     outCxDtxnTabObj.rate = (double)0.00; 
    if ( outCxDtxnTabObj.cf_txn_num == null ) 
     outCxDtxnTabObj.cf_txn_num = ""; 
    if ( outCxDtxnTabObj.cf_rate == (double)0.00 ) 
     outCxDtxnTabObj.cf_rate = (double)0.00; 
    if ( outCxDtxnTabObj.cf_date == null ) 
     outCxDtxnTabObj.cf_date = ""; 
    if ( outCxDtxnTabObj.cf_time == null ) 
     outCxDtxnTabObj.cf_time = ""; 
    if ( outCxDtxnTabObj.status == null ) 
     outCxDtxnTabObj.status = ""; 
    if ( outCxDtxnTabObj.reg_ind == null ) 
     outCxDtxnTabObj.reg_ind = ""; 
    if ( outCxDtxnTabObj.reg_limit == (double)0.00 ) 
     outCxDtxnTabObj.reg_limit = (double)0.00; 
    if ( outCxDtxnTabObj.slr_ind == null ) 
     outCxDtxnTabObj.slr_ind = ""; 
    if ( outCxDtxnTabObj.slr_limit == (double)0.00 ) 
     outCxDtxnTabObj.slr_limit = (double)0.00; 
    if ( outCxDtxnTabObj.rec_cre_date == null ) 
     outCxDtxnTabObj.rec_cre_date = ""; 
    if ( outCxDtxnTabObj.rec_cre_time == null ) 
     outCxDtxnTabObj.rec_cre_time = ""; 
    if ( outCxDtxnTabObj.rec_upd_date == null ) 
     outCxDtxnTabObj.rec_upd_date = ""; 
    if ( outCxDtxnTabObj.rec_upd_time == null ) 
     outCxDtxnTabObj.rec_upd_time = ""; 
  }





  public int insCxDtxnRec
               ( CxDtxnTabObj  inCxDtxnTabObj )
  {
    int lUpdateCount;
    sop("insCxDtxnRec - Started");
    gSSTErrorObj.sourceMethod = "insCxDtxnRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnTabObj.txn_date != null && inCxDtxnTabObj.txn_date.length() > 0 ) 
            inCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.cf_date != null && inCxDtxnTabObj.cf_date.length() > 0 ) 
            inCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.cf_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_cre_date != null && inCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_upd_date != null && inCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_DTXN"+
                        "("+
                                "org_id,"+
                                "txn_num,"+
                                "txn_date,"+
                                "txn_time,"+
                                "txn_type,"+
                                "member_id,"+
                                "member_name,"+
                                "contract_id,"+
                                "symbol_cd,"+
                                "qty,"+
                                "mature_qty,"+
                                "rate,"+
                                "cf_txn_num,"+
                                "cf_rate,"+
                                "cf_date,"+
                                "cf_time,"+
                                "status,"+
                                "reg_ind,"+
                                "reg_limit,"+
                                "slr_ind,"+
                                "slr_limit,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.txn_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.txn_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.txn_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.txn_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.member_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.member_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.contract_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.symbol_cd+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.mature_qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.cf_txn_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.cf_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.cf_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.cf_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.reg_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.reg_limit+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.slr_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnTabObj.slr_limit+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inCxDtxnTabObj.rec_upd_time+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxDtxnTabObj.org_id);
        lPreparedStatement.setString(2, inCxDtxnTabObj.txn_num);
        lPreparedStatement.setString(3, inCxDtxnTabObj.txn_date);
        lPreparedStatement.setString(4, inCxDtxnTabObj.txn_time);
        lPreparedStatement.setString(5, inCxDtxnTabObj.txn_type);
        lPreparedStatement.setString(6, inCxDtxnTabObj.member_id);
        lPreparedStatement.setString(7, inCxDtxnTabObj.member_name);
        lPreparedStatement.setString(8, inCxDtxnTabObj.contract_id);
        lPreparedStatement.setString(9, inCxDtxnTabObj.symbol_cd);
          lPreparedStatement.setInt(10, inCxDtxnTabObj.qty);
          lPreparedStatement.setInt(11, inCxDtxnTabObj.mature_qty);
          lPreparedStatement.setDouble(12, inCxDtxnTabObj.rate);
        lPreparedStatement.setString(13, inCxDtxnTabObj.cf_txn_num);
          lPreparedStatement.setDouble(14, inCxDtxnTabObj.cf_rate);
        lPreparedStatement.setString(15, inCxDtxnTabObj.cf_date);
        lPreparedStatement.setString(16, inCxDtxnTabObj.cf_time);
        lPreparedStatement.setString(17, inCxDtxnTabObj.status);
        lPreparedStatement.setString(18, inCxDtxnTabObj.reg_ind);
          lPreparedStatement.setDouble(19, inCxDtxnTabObj.reg_limit);
        lPreparedStatement.setString(20, inCxDtxnTabObj.slr_ind);
          lPreparedStatement.setDouble(21, inCxDtxnTabObj.slr_limit);
        lPreparedStatement.setString(22, inCxDtxnTabObj.rec_cre_date);
        lPreparedStatement.setString(23, inCxDtxnTabObj.rec_cre_time);
        lPreparedStatement.setString(24, inCxDtxnTabObj.rec_upd_date);
        lPreparedStatement.setString(25, inCxDtxnTabObj.rec_upd_time);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxDtxnArr
               ( ArrayList  inCxDtxnTabObjArr 
               , String  inRowidFlag )
  {
    CxDtxnTabObj  lCxDtxnTabObj = new CxDtxnTabObj();
    int lUpdateCount;
    sop("insCxDtxnArr - Started");
    gSSTErrorObj.sourceMethod = "insCxDtxnArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxDtxnTabObjArr.size(); lNumRec++ )
      {
        lCxDtxnTabObj = (CxDtxnTabObj)inCxDtxnTabObjArr.get(lNumRec);

          if ( lCxDtxnTabObj.txn_date != null && lCxDtxnTabObj.txn_date.length() > 0 ) 
            lCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnTabObj.txn_date, lDateTimeSrcFmt);

          if ( lCxDtxnTabObj.cf_date != null && lCxDtxnTabObj.cf_date.length() > 0 ) 
            lCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnTabObj.cf_date, lDateTimeSrcFmt);

          if ( lCxDtxnTabObj.rec_cre_date != null && lCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxDtxnTabObj.rec_upd_date != null && lCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_DTXN"+
                        "("+
                        "org_id,"+
                        "txn_num,"+
                        "txn_date,"+
                        "txn_time,"+
                        "txn_type,"+
                        "member_id,"+
                        "member_name,"+
                        "contract_id,"+
                        "symbol_cd,"+
                        "qty,"+
                        "mature_qty,"+
                        "rate,"+
                        "cf_txn_num,"+
                        "cf_rate,"+
                        "cf_date,"+
                        "cf_time,"+
                        "status,"+
                        "reg_ind,"+
                        "reg_limit,"+
                        "slr_ind,"+
                        "slr_limit,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.txn_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.txn_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.txn_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.txn_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.member_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.member_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.contract_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.symbol_cd+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.mature_qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.cf_txn_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.cf_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.cf_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.cf_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.reg_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.reg_limit+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.slr_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnTabObj.slr_limit+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lCxDtxnTabObj.rec_upd_time+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxDtxnTabObj.org_id);
            lPreparedStatement.setString(2, lCxDtxnTabObj.txn_num);
            lPreparedStatement.setString(3, lCxDtxnTabObj.txn_date);
            lPreparedStatement.setString(4, lCxDtxnTabObj.txn_time);
            lPreparedStatement.setString(5, lCxDtxnTabObj.txn_type);
            lPreparedStatement.setString(6, lCxDtxnTabObj.member_id);
            lPreparedStatement.setString(7, lCxDtxnTabObj.member_name);
            lPreparedStatement.setString(8, lCxDtxnTabObj.contract_id);
            lPreparedStatement.setString(9, lCxDtxnTabObj.symbol_cd);
              lPreparedStatement.setInt(10, lCxDtxnTabObj.qty);
              lPreparedStatement.setInt(11, lCxDtxnTabObj.mature_qty);
              lPreparedStatement.setDouble(12, lCxDtxnTabObj.rate);
            lPreparedStatement.setString(13, lCxDtxnTabObj.cf_txn_num);
              lPreparedStatement.setDouble(14, lCxDtxnTabObj.cf_rate);
            lPreparedStatement.setString(15, lCxDtxnTabObj.cf_date);
            lPreparedStatement.setString(16, lCxDtxnTabObj.cf_time);
            lPreparedStatement.setString(17, lCxDtxnTabObj.status);
            lPreparedStatement.setString(18, lCxDtxnTabObj.reg_ind);
              lPreparedStatement.setDouble(19, lCxDtxnTabObj.reg_limit);
            lPreparedStatement.setString(20, lCxDtxnTabObj.slr_ind);
              lPreparedStatement.setDouble(21, lCxDtxnTabObj.slr_limit);
            lPreparedStatement.setString(22, lCxDtxnTabObj.rec_cre_date);
            lPreparedStatement.setString(23, lCxDtxnTabObj.rec_cre_time);
            lPreparedStatement.setString(24, lCxDtxnTabObj.rec_upd_date);
            lPreparedStatement.setString(25, lCxDtxnTabObj.rec_upd_time);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxDtxnReq2Obj
               ( HttpServletRequest inRequest
               , CxDtxnTabObj  outCxDtxnTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxDtxnTabObj.tab_rowid = lTabRowidValue;

    outCxDtxnTabObj.org_id = inRequest.getParameter("org_id");
    outCxDtxnTabObj.txn_num = inRequest.getParameter("txn_num");
    outCxDtxnTabObj.txn_date = inRequest.getParameter("txn_date");
    outCxDtxnTabObj.txn_time = inRequest.getParameter("txn_time");
    outCxDtxnTabObj.txn_type = inRequest.getParameter("txn_type");
    outCxDtxnTabObj.member_id = inRequest.getParameter("member_id");
    outCxDtxnTabObj.member_name = inRequest.getParameter("member_name");
    outCxDtxnTabObj.contract_id = inRequest.getParameter("contract_id");
    outCxDtxnTabObj.symbol_cd = inRequest.getParameter("symbol_cd");
    if ( inRequest.getParameter("qty") == null )
      outCxDtxnTabObj.qty = 0;
    else
    if ( inRequest.getParameter("qty").trim().length() == 0 )
      outCxDtxnTabObj.qty = 0;
    else
      outCxDtxnTabObj.qty = Integer.parseInt( inRequest.getParameter("qty"));
    if ( inRequest.getParameter("mature_qty") == null )
      outCxDtxnTabObj.mature_qty = 0;
    else
    if ( inRequest.getParameter("mature_qty").trim().length() == 0 )
      outCxDtxnTabObj.mature_qty = 0;
    else
      outCxDtxnTabObj.mature_qty = Integer.parseInt( inRequest.getParameter("mature_qty"));
    if ( inRequest.getParameter("rate") == null )
      outCxDtxnTabObj.rate = 0;
    else
    if ( inRequest.getParameter("rate").trim().length() == 0 )
      outCxDtxnTabObj.rate = 0;
    else
      outCxDtxnTabObj.rate = Double.parseDouble( inRequest.getParameter("rate"));
    outCxDtxnTabObj.cf_txn_num = inRequest.getParameter("cf_txn_num");
    if ( inRequest.getParameter("cf_rate") == null )
      outCxDtxnTabObj.cf_rate = 0;
    else
    if ( inRequest.getParameter("cf_rate").trim().length() == 0 )
      outCxDtxnTabObj.cf_rate = 0;
    else
      outCxDtxnTabObj.cf_rate = Double.parseDouble( inRequest.getParameter("cf_rate"));
    outCxDtxnTabObj.cf_date = inRequest.getParameter("cf_date");
    outCxDtxnTabObj.cf_time = inRequest.getParameter("cf_time");
    outCxDtxnTabObj.status = inRequest.getParameter("status");
    outCxDtxnTabObj.reg_ind = inRequest.getParameter("reg_ind");
    if ( inRequest.getParameter("reg_limit") == null )
      outCxDtxnTabObj.reg_limit = 0;
    else
    if ( inRequest.getParameter("reg_limit").trim().length() == 0 )
      outCxDtxnTabObj.reg_limit = 0;
    else
      outCxDtxnTabObj.reg_limit = Double.parseDouble( inRequest.getParameter("reg_limit"));
    outCxDtxnTabObj.slr_ind = inRequest.getParameter("slr_ind");
    if ( inRequest.getParameter("slr_limit") == null )
      outCxDtxnTabObj.slr_limit = 0;
    else
    if ( inRequest.getParameter("slr_limit").trim().length() == 0 )
      outCxDtxnTabObj.slr_limit = 0;
    else
      outCxDtxnTabObj.slr_limit = Double.parseDouble( inRequest.getParameter("slr_limit"));
    outCxDtxnTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxDtxnTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxDtxnTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxDtxnTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    return lReturnValue;
  }


  public int popCxDtxnReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxDtxnTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxDtxnTabObj lCxDtxnTabObj= new CxDtxnTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxDtxnTabObj.tab_rowid = lTabRowidValue;

      lCxDtxnTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxDtxnTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
      lCxDtxnTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
      lCxDtxnTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
      lCxDtxnTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
      lCxDtxnTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
      lCxDtxnTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
      lCxDtxnTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
      lCxDtxnTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
      if ( inRequest.getParameter("qty_r"+lNumRec) == null )
        lCxDtxnTabObj.qty = 0;
      else
      if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.qty = 0;
      else
        lCxDtxnTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
      if ( inRequest.getParameter("mature_qty_r"+lNumRec) == null )
        lCxDtxnTabObj.mature_qty = 0;
      else
      if ( inRequest.getParameter("mature_qty_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.mature_qty = 0;
      else
        lCxDtxnTabObj.mature_qty = Integer.parseInt( inRequest.getParameter("mature_qty_r"+lNumRec));
      if ( inRequest.getParameter("rate_r"+lNumRec) == null )
        lCxDtxnTabObj.rate = 0;
      else
      if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.rate = 0;
      else
        lCxDtxnTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
      lCxDtxnTabObj.cf_txn_num = inRequest.getParameter("cf_txn_num_r"+lNumRec);
      if ( inRequest.getParameter("cf_rate_r"+lNumRec) == null )
        lCxDtxnTabObj.cf_rate = 0;
      else
      if ( inRequest.getParameter("cf_rate_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.cf_rate = 0;
      else
        lCxDtxnTabObj.cf_rate = Double.parseDouble( inRequest.getParameter("cf_rate_r"+lNumRec));
      lCxDtxnTabObj.cf_date = inRequest.getParameter("cf_date_r"+lNumRec);
      lCxDtxnTabObj.cf_time = inRequest.getParameter("cf_time_r"+lNumRec);
      lCxDtxnTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxDtxnTabObj.reg_ind = inRequest.getParameter("reg_ind_r"+lNumRec);
      if ( inRequest.getParameter("reg_limit_r"+lNumRec) == null )
        lCxDtxnTabObj.reg_limit = 0;
      else
      if ( inRequest.getParameter("reg_limit_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.reg_limit = 0;
      else
        lCxDtxnTabObj.reg_limit = Double.parseDouble( inRequest.getParameter("reg_limit_r"+lNumRec));
      lCxDtxnTabObj.slr_ind = inRequest.getParameter("slr_ind_r"+lNumRec);
      if ( inRequest.getParameter("slr_limit_r"+lNumRec) == null )
        lCxDtxnTabObj.slr_limit = 0;
      else
      if ( inRequest.getParameter("slr_limit_r"+lNumRec).trim().length() == 0 )
        lCxDtxnTabObj.slr_limit = 0;
      else
        lCxDtxnTabObj.slr_limit = Double.parseDouble( inRequest.getParameter("slr_limit_r"+lNumRec));
      lCxDtxnTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxDtxnTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxDtxnTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxDtxnTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      outCxDtxnTabObjArr.add( lCxDtxnTabObj);
    }
    return lReturnValue;
  }


  public int popCxDtxnReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxDtxnTabObj outCxDtxnTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_dtxn_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxDtxnTabObj.tab_rowid = lTabRowidValue;

        outCxDtxnTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxDtxnTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
        outCxDtxnTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
        outCxDtxnTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
        outCxDtxnTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
        outCxDtxnTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        outCxDtxnTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        outCxDtxnTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        outCxDtxnTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        if ( inRequest.getParameter("qty_r"+lNumRec) == null )
          outCxDtxnTabObj.qty = 0;
        else
        if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.qty = 0;
        else
          outCxDtxnTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
        if ( inRequest.getParameter("mature_qty_r"+lNumRec) == null )
          outCxDtxnTabObj.mature_qty = 0;
        else
        if ( inRequest.getParameter("mature_qty_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.mature_qty = 0;
        else
          outCxDtxnTabObj.mature_qty = Integer.parseInt( inRequest.getParameter("mature_qty_r"+lNumRec));
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          outCxDtxnTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.rate = 0;
        else
          outCxDtxnTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        outCxDtxnTabObj.cf_txn_num = inRequest.getParameter("cf_txn_num_r"+lNumRec);
        if ( inRequest.getParameter("cf_rate_r"+lNumRec) == null )
          outCxDtxnTabObj.cf_rate = 0;
        else
        if ( inRequest.getParameter("cf_rate_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.cf_rate = 0;
        else
          outCxDtxnTabObj.cf_rate = Double.parseDouble( inRequest.getParameter("cf_rate_r"+lNumRec));
        outCxDtxnTabObj.cf_date = inRequest.getParameter("cf_date_r"+lNumRec);
        outCxDtxnTabObj.cf_time = inRequest.getParameter("cf_time_r"+lNumRec);
        outCxDtxnTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxDtxnTabObj.reg_ind = inRequest.getParameter("reg_ind_r"+lNumRec);
        if ( inRequest.getParameter("reg_limit_r"+lNumRec) == null )
          outCxDtxnTabObj.reg_limit = 0;
        else
        if ( inRequest.getParameter("reg_limit_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.reg_limit = 0;
        else
          outCxDtxnTabObj.reg_limit = Double.parseDouble( inRequest.getParameter("reg_limit_r"+lNumRec));
        outCxDtxnTabObj.slr_ind = inRequest.getParameter("slr_ind_r"+lNumRec);
        if ( inRequest.getParameter("slr_limit_r"+lNumRec) == null )
          outCxDtxnTabObj.slr_limit = 0;
        else
        if ( inRequest.getParameter("slr_limit_r"+lNumRec).trim().length() == 0 )
          outCxDtxnTabObj.slr_limit = 0;
        else
          outCxDtxnTabObj.slr_limit = Double.parseDouble( inRequest.getParameter("slr_limit_r"+lNumRec));
        outCxDtxnTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxDtxnTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxDtxnTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxDtxnTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popCxDtxnReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxDtxnTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxDtxnTabObj lCxDtxnTabObj= new CxDtxnTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_dtxn_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxDtxnTabObj.tab_rowid = lTabRowidValue;

        lCxDtxnTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxDtxnTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
        lCxDtxnTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
        lCxDtxnTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
        lCxDtxnTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
        lCxDtxnTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        lCxDtxnTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        lCxDtxnTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        lCxDtxnTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        if ( inRequest.getParameter("qty_r"+lNumRec) == null )
          lCxDtxnTabObj.qty = 0;
        else
        if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.qty = 0;
        else
          lCxDtxnTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
        if ( inRequest.getParameter("mature_qty_r"+lNumRec) == null )
          lCxDtxnTabObj.mature_qty = 0;
        else
        if ( inRequest.getParameter("mature_qty_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.mature_qty = 0;
        else
          lCxDtxnTabObj.mature_qty = Integer.parseInt( inRequest.getParameter("mature_qty_r"+lNumRec));
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          lCxDtxnTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.rate = 0;
        else
            lCxDtxnTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        lCxDtxnTabObj.cf_txn_num = inRequest.getParameter("cf_txn_num_r"+lNumRec);
        if ( inRequest.getParameter("cf_rate_r"+lNumRec) == null )
          lCxDtxnTabObj.cf_rate = 0;
        else
        if ( inRequest.getParameter("cf_rate_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.cf_rate = 0;
        else
            lCxDtxnTabObj.cf_rate = Double.parseDouble( inRequest.getParameter("cf_rate_r"+lNumRec));
        lCxDtxnTabObj.cf_date = inRequest.getParameter("cf_date_r"+lNumRec);
        lCxDtxnTabObj.cf_time = inRequest.getParameter("cf_time_r"+lNumRec);
        lCxDtxnTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxDtxnTabObj.reg_ind = inRequest.getParameter("reg_ind_r"+lNumRec);
        if ( inRequest.getParameter("reg_limit_r"+lNumRec) == null )
          lCxDtxnTabObj.reg_limit = 0;
        else
        if ( inRequest.getParameter("reg_limit_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.reg_limit = 0;
        else
            lCxDtxnTabObj.reg_limit = Double.parseDouble( inRequest.getParameter("reg_limit_r"+lNumRec));
        lCxDtxnTabObj.slr_ind = inRequest.getParameter("slr_ind_r"+lNumRec);
        if ( inRequest.getParameter("slr_limit_r"+lNumRec) == null )
          lCxDtxnTabObj.slr_limit = 0;
        else
        if ( inRequest.getParameter("slr_limit_r"+lNumRec).trim().length() == 0 )
          lCxDtxnTabObj.slr_limit = 0;
        else
            lCxDtxnTabObj.slr_limit = Double.parseDouble( inRequest.getParameter("slr_limit_r"+lNumRec));
        lCxDtxnTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxDtxnTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxDtxnTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxDtxnTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxDtxnTabObjArr.add( lCxDtxnTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnRecByRowid
               ( String inRowId
               , CxDtxnTabObj  inCxDtxnTabObj
               )
  {
    int lUpdateCount;
    sop("updCxDtxnRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnTabObj.txn_date != null && inCxDtxnTabObj.txn_date.length() > 0 ) 
            inCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.cf_date != null && inCxDtxnTabObj.cf_date.length() > 0 ) 
            inCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.cf_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_cre_date != null && inCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_upd_date != null && inCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxDtxnTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxDtxnTabObj.org_id+"', ";
      if ( inCxDtxnTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = "+"'"+inCxDtxnTabObj.txn_num+"', ";
      if ( inCxDtxnTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = "+"'"+inCxDtxnTabObj.txn_date+"', ";
      if ( inCxDtxnTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = "+"'"+inCxDtxnTabObj.txn_time+"', ";
      if ( inCxDtxnTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = "+"'"+inCxDtxnTabObj.txn_type+"', ";
      if ( inCxDtxnTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxDtxnTabObj.member_id+"', ";
      if ( inCxDtxnTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxDtxnTabObj.member_name+"', ";
      if ( inCxDtxnTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxDtxnTabObj.contract_id+"', ";
      if ( inCxDtxnTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxDtxnTabObj.symbol_cd+"', ";
             lSqlStmt = lSqlStmt + "qty = "+inCxDtxnTabObj.qty+", ";
             lSqlStmt = lSqlStmt + "mature_qty = "+inCxDtxnTabObj.mature_qty+", ";
             lSqlStmt = lSqlStmt + "rate = "+inCxDtxnTabObj.rate+", ";
      if ( inCxDtxnTabObj.cf_txn_num != null  )         lSqlStmt = lSqlStmt + "cf_txn_num = "+"'"+inCxDtxnTabObj.cf_txn_num+"', ";
             lSqlStmt = lSqlStmt + "cf_rate = "+inCxDtxnTabObj.cf_rate+", ";
      if ( inCxDtxnTabObj.cf_date != null  )         lSqlStmt = lSqlStmt + "cf_date = "+"'"+inCxDtxnTabObj.cf_date+"', ";
      if ( inCxDtxnTabObj.cf_time != null  )         lSqlStmt = lSqlStmt + "cf_time = "+"'"+inCxDtxnTabObj.cf_time+"', ";
      if ( inCxDtxnTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxDtxnTabObj.status+"', ";
      if ( inCxDtxnTabObj.reg_ind != null  )         lSqlStmt = lSqlStmt + "reg_ind = "+"'"+inCxDtxnTabObj.reg_ind+"', ";
             lSqlStmt = lSqlStmt + "reg_limit = "+inCxDtxnTabObj.reg_limit+", ";
      if ( inCxDtxnTabObj.slr_ind != null  )         lSqlStmt = lSqlStmt + "slr_ind = "+"'"+inCxDtxnTabObj.slr_ind+"', ";
             lSqlStmt = lSqlStmt + "slr_limit = "+inCxDtxnTabObj.slr_limit+", ";
      if ( inCxDtxnTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxDtxnTabObj.rec_cre_date+"', ";
      if ( inCxDtxnTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxDtxnTabObj.rec_cre_time+"', ";
      if ( inCxDtxnTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxDtxnTabObj.rec_upd_date+"', ";
      if ( inCxDtxnTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxDtxnTabObj.rec_upd_time+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnRecByPkey
               ( CxDtxnPkeyObj inCxDtxnPkeyObj
               , CxDtxnTabObj  inCxDtxnTabObj
               )
  {
    int lUpdateCount;
    sop("updCxDtxnRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnTabObj.txn_date != null && inCxDtxnTabObj.txn_date.length() > 0 ) 
            inCxDtxnTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.cf_date != null && inCxDtxnTabObj.cf_date.length() > 0 ) 
            inCxDtxnTabObj.cf_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.cf_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_cre_date != null && inCxDtxnTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnTabObj.rec_upd_date != null && inCxDtxnTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxDtxnTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxDtxnTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = ? , ";
        if ( inCxDtxnTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = ? , ";
        if ( inCxDtxnTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = ? , ";
        if ( inCxDtxnTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = ? , ";
        if ( inCxDtxnTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = ? , ";
        if ( inCxDtxnTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = ? , ";
        if ( inCxDtxnTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = ? , ";
        if ( inCxDtxnTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = ? , ";
               lSqlStmt = lSqlStmt + "qty = ? , ";
               lSqlStmt = lSqlStmt + "mature_qty = ? , ";
               lSqlStmt = lSqlStmt + "rate = ? , ";
        if ( inCxDtxnTabObj.cf_txn_num != null  )         lSqlStmt = lSqlStmt + "cf_txn_num = ? , ";
               lSqlStmt = lSqlStmt + "cf_rate = ? , ";
        if ( inCxDtxnTabObj.cf_date != null  )         lSqlStmt = lSqlStmt + "cf_date = ? , ";
        if ( inCxDtxnTabObj.cf_time != null  )         lSqlStmt = lSqlStmt + "cf_time = ? , ";
        if ( inCxDtxnTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxDtxnTabObj.reg_ind != null  )         lSqlStmt = lSqlStmt + "reg_ind = ? , ";
               lSqlStmt = lSqlStmt + "reg_limit = ? , ";
        if ( inCxDtxnTabObj.slr_ind != null  )         lSqlStmt = lSqlStmt + "slr_ind = ? , ";
               lSqlStmt = lSqlStmt + "slr_limit = ? , ";
        if ( inCxDtxnTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxDtxnTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxDtxnTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxDtxnTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxDtxnTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxDtxnTabObj.org_id+"', ";
        if ( inCxDtxnTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = "+"'"+inCxDtxnTabObj.txn_num+"', ";
        if ( inCxDtxnTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = "+"'"+inCxDtxnTabObj.txn_date+"', ";
        if ( inCxDtxnTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = "+"'"+inCxDtxnTabObj.txn_time+"', ";
        if ( inCxDtxnTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = "+"'"+inCxDtxnTabObj.txn_type+"', ";
        if ( inCxDtxnTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxDtxnTabObj.member_id+"', ";
        if ( inCxDtxnTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxDtxnTabObj.member_name+"', ";
        if ( inCxDtxnTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxDtxnTabObj.contract_id+"', ";
        if ( inCxDtxnTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxDtxnTabObj.symbol_cd+"', ";
               lSqlStmt = lSqlStmt + "qty = "+inCxDtxnTabObj.qty+", ";
               lSqlStmt = lSqlStmt + "mature_qty = "+inCxDtxnTabObj.mature_qty+", ";
               lSqlStmt = lSqlStmt + "rate = "+inCxDtxnTabObj.rate+", ";
        if ( inCxDtxnTabObj.cf_txn_num != null  )         lSqlStmt = lSqlStmt + "cf_txn_num = "+"'"+inCxDtxnTabObj.cf_txn_num+"', ";
               lSqlStmt = lSqlStmt + "cf_rate = "+inCxDtxnTabObj.cf_rate+", ";
        if ( inCxDtxnTabObj.cf_date != null  )         lSqlStmt = lSqlStmt + "cf_date = "+"'"+inCxDtxnTabObj.cf_date+"', ";
        if ( inCxDtxnTabObj.cf_time != null  )         lSqlStmt = lSqlStmt + "cf_time = "+"'"+inCxDtxnTabObj.cf_time+"', ";
        if ( inCxDtxnTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxDtxnTabObj.status+"', ";
        if ( inCxDtxnTabObj.reg_ind != null  )         lSqlStmt = lSqlStmt + "reg_ind = "+"'"+inCxDtxnTabObj.reg_ind+"', ";
               lSqlStmt = lSqlStmt + "reg_limit = "+inCxDtxnTabObj.reg_limit+", ";
        if ( inCxDtxnTabObj.slr_ind != null  )         lSqlStmt = lSqlStmt + "slr_ind = "+"'"+inCxDtxnTabObj.slr_ind+"', ";
               lSqlStmt = lSqlStmt + "slr_limit = "+inCxDtxnTabObj.slr_limit+", ";
        if ( inCxDtxnTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxDtxnTabObj.rec_cre_date+"', ";
        if ( inCxDtxnTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxDtxnTabObj.rec_cre_time+"', ";
        if ( inCxDtxnTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxDtxnTabObj.rec_upd_date+"', ";
        if ( inCxDtxnTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxDtxnTabObj.rec_upd_time+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnPkeyObj.txn_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxDtxnTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.org_id); } 
         if ( inCxDtxnTabObj.txn_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.txn_num); } 
         if ( inCxDtxnTabObj.txn_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.txn_date); } 
         if ( inCxDtxnTabObj.txn_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.txn_time); } 
         if ( inCxDtxnTabObj.txn_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.txn_type); } 
         if ( inCxDtxnTabObj.member_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.member_id); } 
         if ( inCxDtxnTabObj.member_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.member_name); } 
         if ( inCxDtxnTabObj.contract_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.contract_id); } 
         if ( inCxDtxnTabObj.symbol_cd != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.symbol_cd); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(10, inCxDtxnTabObj.qty);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(11, inCxDtxnTabObj.mature_qty);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(12, inCxDtxnTabObj.rate);
         if ( inCxDtxnTabObj.cf_txn_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.cf_txn_num); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(14, inCxDtxnTabObj.cf_rate);
         if ( inCxDtxnTabObj.cf_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.cf_date); } 
         if ( inCxDtxnTabObj.cf_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.cf_time); } 
         if ( inCxDtxnTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.status); } 
         if ( inCxDtxnTabObj.reg_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.reg_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(19, inCxDtxnTabObj.reg_limit);
         if ( inCxDtxnTabObj.slr_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.slr_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(21, inCxDtxnTabObj.slr_limit);
         if ( inCxDtxnTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.rec_cre_date); } 
         if ( inCxDtxnTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.rec_cre_time); } 
         if ( inCxDtxnTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.rec_upd_date); } 
         if ( inCxDtxnTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnTabObj.rec_upd_time); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxDtxnRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_DTXN "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnRecByPkeyWithSet
               ( CxDtxnPkeyObj inCxDtxnPkeyObj
               , String  inCxDtxnSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxDtxnSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnPkeyObj.txn_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnRecByRowidWithSet
               ( String inRowId
               , String  inCxDtxnSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxDtxnSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnRecByWhereWithSet
               ( String inCxDtxnWhereText
               , String  inCxDtxnSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxDtxnSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnRecByPkey
               ( CxDtxnPkeyObj  inCxDtxnPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxDtxnRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_DTXN " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnPkeyObj.txn_num+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnByWhere
               ( String inCxDtxnWhereText
               )
  {
    int lUpdateCount;
    sop("delCxDtxnByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_DTXN "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
