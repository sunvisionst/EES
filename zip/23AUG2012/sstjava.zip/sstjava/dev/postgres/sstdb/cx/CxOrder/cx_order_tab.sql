CREATE TABLE CX_ORDER
(
  ORG_ID                                                                                              VARCHAR(10),
  ORD_NUM                                                                                             VARCHAR(20),
  ORD_SEQ_NUM                                                                                         NUMERIC(9),
  ORD_DATE                                                                                            VARCHAR(8),
  ORD_TIME                                                                                            VARCHAR(6),
  TXN_TYPE                                                                                            VARCHAR(1),
  CONTRACT_ID                                                                                         VARCHAR(20),
  SYMBOL_CD                                                                                           VARCHAR(20),
  BUYER                                                                                               VARCHAR(20),
  SELLER                                                                                              VARCHAR(20),
  BUY_QTY                                                                                             NUMERIC(9),
  SALE_QTY                                                                                            NUMERIC(9),
  BAL_QTY                                                                                             NUMERIC(9),
  RATE                                                                                                NUMERIC(13,2),
  STATUS                                                                                              VARCHAR(10),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
