{


   function vldDBSizeEnvCxCronJob
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeJobNum ( inTableName, inFieldName );
      vldFieldDBSizeSchDate ( inTableName, inFieldName );
      vldFieldDBSizeSchTime ( inTableName, inFieldName );
      vldFieldDBSizeAlertType ( inTableName, inFieldName );
      vldFieldDBSizeContactNum1 ( inTableName, inFieldName );
      vldFieldDBSizeEmailId ( inTableName, inFieldName );
      vldFieldDBSizeStatus ( inTableName, inFieldName );
      vldFieldDBSizeRecCreBy ( inTableName, inFieldName );
      vldFieldDBSizeRecCreDate ( inTableName, inFieldName );
      vldFieldDBSizeRecCreTime ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdBy ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdDate ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdTime ( inTableName, inFieldName );
   }



   function constructorCxCronJob
   (
      org_id,
      job_num,
      sch_date,
      sch_time,
      alert_type,
      contact_num_1,
      email_id,
      status,
      rec_cre_by,
      rec_cre_date,
      rec_cre_time,
      rec_upd_by,
      rec_upd_date,
      rec_upd_time
   )
   {
      this.org_id = org_id;
      this.job_num = job_num;
      this.sch_date = sch_date;
      this.sch_time = sch_time;
      this.alert_type = alert_type;
      this.contact_num_1 = contact_num_1;
      this.email_id = email_id;
      this.status = status;
      this.rec_cre_by = rec_cre_by;
      this.rec_cre_date = rec_cre_date;
      this.rec_cre_time = rec_cre_time;
      this.rec_upd_by = rec_upd_by;
      this.rec_upd_date = rec_upd_date;
      this.rec_upd_time = rec_upd_time;
   }



   function CxCronJobFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lCxCronJobTabObjJSArr.length )
      {
         if
         ( 
           ( lCxCronJobTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lCxCronJobTabObjJSArr[lRecNum].job_num != document.form.job_num.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeCxCronJobTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjJobNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjSchDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjSchTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjAlertType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjContactNum1
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjEmailId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecCreBy
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecUpdBy
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxCronJobTabObjRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisJobNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSchDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSchTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAlertType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisContactNum1
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisEmailId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreBy
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdBy
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



}