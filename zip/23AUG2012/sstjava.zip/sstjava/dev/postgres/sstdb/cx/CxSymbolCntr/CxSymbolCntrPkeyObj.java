package sstdb.cx.CxSymbolCntr;


public class CxSymbolCntrPkeyObj
{
  public String                                 org_id;
  public String                                 contract_id;
}