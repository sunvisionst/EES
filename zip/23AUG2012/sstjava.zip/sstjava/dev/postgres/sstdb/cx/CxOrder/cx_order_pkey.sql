ALTER TABLE           CX_ORDER
  ADD                 CONSTRAINT CX_ORDER_PK
  PRIMARY             KEY
  ( ORG_ID, ORD_NUM, ORD_SEQ_NUM )
;
