package sstdb.cx.CxSymbolDaily;

import sstdb.cx.CxSymbolDaily.CxSymbolDailyTabObj;
import sstdb.cx.CxSymbolDaily.CxSymbolDailyPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxSymbolDailyMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxSymbolDailyMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxSymbolDailyMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxSymbolDailyTabObj
               ( 
                 CxSymbolDailyTabObj  outCxSymbolDailyTabObj
               )
  {
  
     outCxSymbolDailyTabObj.org_id = ""; 
     outCxSymbolDailyTabObj.curr_date = ""; 
     outCxSymbolDailyTabObj.contract_id = ""; 
     outCxSymbolDailyTabObj.symbol_cd = ""; 
     outCxSymbolDailyTabObj.symbol_name = ""; 
     outCxSymbolDailyTabObj.status = ""; 
     outCxSymbolDailyTabObj.rec_cre_date = ""; 
     outCxSymbolDailyTabObj.rec_cre_time = ""; 
     outCxSymbolDailyTabObj.rec_upd_date = ""; 
     outCxSymbolDailyTabObj.rec_upd_time = ""; 
     outCxSymbolDailyTabObj.eff_date = ""; 
     outCxSymbolDailyTabObj.eff_time = ""; 
     outCxSymbolDailyTabObj.exp_date = ""; 
     outCxSymbolDailyTabObj.exp_time = ""; 
     outCxSymbolDailyTabObj.exp_rate = (double)0.00; 
     outCxSymbolDailyTabObj.fwd_rate = (double)0.00; 
     outCxSymbolDailyTabObj.fut_rate = (double)0.00; 
     outCxSymbolDailyTabObj.spot_rate = (double)0.00; 
     outCxSymbolDailyTabObj.ltp = (double)0.00; 
     outCxSymbolDailyTabObj.ltp_date = ""; 
     outCxSymbolDailyTabObj.ltp_time = ""; 
     outCxSymbolDailyTabObj.rate_currency = ""; 
     outCxSymbolDailyTabObj.rate_per_uom = ""; 
     outCxSymbolDailyTabObj.net_change = (double)0.00; 
     outCxSymbolDailyTabObj.percent_change = (float)0.00; 
     outCxSymbolDailyTabObj.high = (double)0.00; 
     outCxSymbolDailyTabObj.low = (double)0.00; 
     outCxSymbolDailyTabObj.bbr = (double)0.00; 
     outCxSymbolDailyTabObj.bbq = (int)0; 
     outCxSymbolDailyTabObj.bsr = (double)0.00; 
     outCxSymbolDailyTabObj.bsq = (int)0; 
     outCxSymbolDailyTabObj.open_rate = (double)0.00; 
     outCxSymbolDailyTabObj.close_rate = (double)0.00; 
  }





  public void guiDateConvCxSymbolDailyTabObj
               ( 
                 CxSymbolDailyTabObj  inCxSymbolDailyTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxSymbolDailyTabObj.curr_date != null && inCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            inCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);

          if ( inCxSymbolDailyTabObj.rec_cre_date != null && inCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxSymbolDailyTabObj.rec_upd_date != null && inCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);

          if ( inCxSymbolDailyTabObj.eff_date != null && inCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            inCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);

          if ( inCxSymbolDailyTabObj.exp_date != null && inCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);

          if ( inCxSymbolDailyTabObj.ltp_date != null && inCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxSymbolDailyByTabObj
               ( 
                 CxSymbolDailyTabObj  inCxSymbolDailyTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxSymbolDailyTabObjArrCtx  = new ArrayList(); 
    lCxSymbolDailyTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxSymbolDailyTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxSymbolDailyTabObjArrCtx.add(inCxSymbolDailyTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxSymbolDailyTabObjArrCtx.size();  lRecNum++ )
      {
        CxSymbolDailyTabObj lCxSymbolDailyTabObj = new CxSymbolDailyTabObj();
        lCxSymbolDailyTabObj = (CxSymbolDailyTabObj)lCxSymbolDailyTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxSymbolDailyTabObj.org_id.equals(lCxSymbolDailyTabObj.org_id) &&
              lCxSymbolDailyTabObj.curr_date.equals(lCxSymbolDailyTabObj.curr_date) &&
              lCxSymbolDailyTabObj.contract_id.equals(lCxSymbolDailyTabObj.contract_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxSymbolDailyTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxSymbolDailyTabObjArrCtx.set(lRecNum, inCxSymbolDailyTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxSymbolDailyTabObjArrCtx",lCxSymbolDailyTabObjArrCtx);
  }





  public void sortCxSymbolDailyTabObjArr
               ( 
                 ArrayList  inCxSymbolDailyTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxSymbolDailyTabObjArr  = new ArrayList(); 
     lCxSymbolDailyTabObjArr = inCxSymbolDailyTabObjArr; 
     List lCxSymbolDailyTabObjList  = new ArrayList(lCxSymbolDailyTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxSymbolDailyTabObjArr.size();  lRecNum++ )
     {
       CxSymbolDailyTabObj  lCxSymbolDailyTabObj = new CxSymbolDailyTabObj(); 
       lCxSymbolDailyTabObj = (CxSymbolDailyTabObj)lCxSymbolDailyTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxSymbolDailyTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("curr_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.curr_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.curr_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("contract_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxSymbolDailyTabObj.contract_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.contract_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_cd") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxSymbolDailyTabObj.symbol_cd.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.symbol_cd+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxSymbolDailyTabObj.symbol_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.symbol_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxSymbolDailyTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolDailyTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolDailyTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("eff_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.eff_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.eff_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("eff_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolDailyTabObj.eff_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.eff_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.exp_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.exp_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolDailyTabObj.exp_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.exp_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.exp_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.exp_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fwd_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.fwd_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.fwd_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fut_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.fut_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.fut_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spot_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.spot_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.spot_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ltp") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.ltp).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.ltp+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ltp_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolDailyTabObj.ltp_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.ltp_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ltp_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolDailyTabObj.ltp_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.ltp_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate_currency") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxSymbolDailyTabObj.rate_currency.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rate_currency+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate_per_uom") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxSymbolDailyTabObj.rate_per_uom.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.rate_per_uom+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("net_change") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.net_change).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.net_change+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("percent_change") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - Float.toString(lCxSymbolDailyTabObj.percent_change).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.percent_change+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("high") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.high).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.high+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("low") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.low).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.low+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bbr") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.bbr).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.bbr+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bbq") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxSymbolDailyTabObj.bbq).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.bbq+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bsr") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.bsr).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.bsr+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bsq") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxSymbolDailyTabObj.bsq).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.bsq+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("open_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.open_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.open_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("close_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolDailyTabObj.close_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolDailyTabObj.close_rate+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxSymbolDailyTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxSymbolDailyTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxSymbolDailyTabObjList ); 
     ArrayList lCxSymbolDailyTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxSymbolDailyTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxSymbolDailyTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxSymbolDailyTabObjArrSorted.add( (CxSymbolDailyTabObj)lCxSymbolDailyTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxSymbolDailyTabObjArr.size();  lRecNum++ )
     {
       inCxSymbolDailyTabObjArr.set( lRecNum, (CxSymbolDailyTabObj)lCxSymbolDailyTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxSymbolDailyTabObj
               ( 
                 CxSymbolDailyTabObj  inCxSymbolDailyTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxSymbolDailyTabObj.curr_date != null && inCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            inCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.curr_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_cre_date != null && inCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_upd_date != null && inCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.eff_date != null && inCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            inCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.exp_date != null && inCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.ltp_date != null && inCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.ltp_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCurrDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CURR_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeContractId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CONTRACT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolCd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_CD";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_NAME";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFF_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFF_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFwdRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FWD_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFutRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FUT_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpotRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPOT_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLtp
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LTP";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLtpDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LTP_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLtpTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LTP_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRateCurrency
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE_CURRENCY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRatePerUom
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE_PER_UOM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNetChange
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NET_CHANGE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePercentChange
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PERCENT_CHANGE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHigh
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HIGH";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLow
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LOW";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBbr
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BBR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBbq
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BBQ";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBsr
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BSR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBsq
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BSQ";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOpenRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OPEN_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCloseRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLOSE_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxSymbolDailyCount
               ( String inCxSymbolDailyWhereText
               )
  {
    sop("gtCxSymbolDailyCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyCount
               ( String inCxSymbolDailyWhereText
               , String inCxSymbolDailySelectFieldList
               )
  {
    sop("gtCxSymbolDailyCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxSymbolDailySelectFieldList+" AS count "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyRecByPkey
               ( CxSymbolDailyPkeyObj inCxSymbolDailyPkeyObj
               , CxSymbolDailyTabObj  outCxSymbolDailyTabObj
               )
  {
    sop("gtCxSymbolDailyRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "curr_date, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "exp_rate, "+
                                 "fwd_rate, "+
                                 "fut_rate, "+
                                 "spot_rate, "+
                                 "ltp, "+
                                 "ltp_date, "+
                                 "ltp_time, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "net_change, "+
                                 "percent_change, "+
                                 "high, "+
                                 "low, "+
                                 "bbr, "+
                                 "bbq, "+
                                 "bsr, "+
                                 "bsq, "+
                                 "open_rate, "+
                                 "close_rate "+
                         "FROM   CX_SYMBOL_DAILY " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolDailyPkeyObj.org_id+"' and "+
                              "curr_date = "+"'"+inCxSymbolDailyPkeyObj.curr_date+"' and "+
                              "contract_id = "+"'"+inCxSymbolDailyPkeyObj.contract_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxSymbolDailyTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxSymbolDailyTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxSymbolDailyTabObj.curr_date  =  lResultSet.getString("CURR_DATE");

          if ( outCxSymbolDailyTabObj.curr_date != null && outCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            outCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxSymbolDailyTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxSymbolDailyTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          outCxSymbolDailyTabObj.status  =  lResultSet.getString("STATUS");
          outCxSymbolDailyTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxSymbolDailyTabObj.rec_cre_date != null && outCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            outCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxSymbolDailyTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxSymbolDailyTabObj.rec_upd_date != null && outCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            outCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outCxSymbolDailyTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( outCxSymbolDailyTabObj.eff_date != null && outCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            outCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          outCxSymbolDailyTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( outCxSymbolDailyTabObj.exp_date != null && outCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            outCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          outCxSymbolDailyTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          outCxSymbolDailyTabObj.fwd_rate  =  lResultSet.getDouble("FWD_RATE");
          outCxSymbolDailyTabObj.fut_rate  =  lResultSet.getDouble("FUT_RATE");
          outCxSymbolDailyTabObj.spot_rate  =  lResultSet.getDouble("SPOT_RATE");
          outCxSymbolDailyTabObj.ltp  =  lResultSet.getDouble("LTP");
          outCxSymbolDailyTabObj.ltp_date  =  lResultSet.getString("LTP_DATE");

          if ( outCxSymbolDailyTabObj.ltp_date != null && outCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            outCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.ltp_time  =  lResultSet.getString("LTP_TIME");
          outCxSymbolDailyTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          outCxSymbolDailyTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          outCxSymbolDailyTabObj.net_change  =  lResultSet.getDouble("NET_CHANGE");
          outCxSymbolDailyTabObj.percent_change  =  lResultSet.getFloat("PERCENT_CHANGE");
          outCxSymbolDailyTabObj.high  =  lResultSet.getDouble("HIGH");
          outCxSymbolDailyTabObj.low  =  lResultSet.getDouble("LOW");
          outCxSymbolDailyTabObj.bbr  =  lResultSet.getDouble("BBR");
          outCxSymbolDailyTabObj.bbq  =  lResultSet.getInt("BBQ");
          outCxSymbolDailyTabObj.bsr  =  lResultSet.getDouble("BSR");
          outCxSymbolDailyTabObj.bsq  =  lResultSet.getInt("BSQ");
          outCxSymbolDailyTabObj.open_rate  =  lResultSet.getDouble("OPEN_RATE");
          outCxSymbolDailyTabObj.close_rate  =  lResultSet.getDouble("CLOSE_RATE");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxSymbolDailyTabObj( outCxSymbolDailyTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyArr
               ( CxSymbolDailyPkeyObj inCxSymbolDailyPkeyObj
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {
    sop("gtCxSymbolDailyArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "curr_date, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "exp_rate, "+
                                 "fwd_rate, "+
                                 "fut_rate, "+
                                 "spot_rate, "+
                                 "ltp, "+
                                 "ltp_date, "+
                                 "ltp_time, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "net_change, "+
                                 "percent_change, "+
                                 "high, "+
                                 "low, "+
                                 "bbr, "+
                                 "bbq, "+
                                 "bsr, "+
                                 "bsq, "+
                                 "open_rate, "+
                                 "close_rate "+
                         "FROM   CX_SYMBOL_DAILY";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxSymbolDailyTabObj  lCxSymbolDailyTabObj = new CxSymbolDailyTabObj();
          lCxSymbolDailyTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxSymbolDailyTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxSymbolDailyTabObj.curr_date  =  lResultSet.getString("CURR_DATE");

          if ( lCxSymbolDailyTabObj.curr_date != null && lCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            lCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxSymbolDailyTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxSymbolDailyTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          lCxSymbolDailyTabObj.status  =  lResultSet.getString("STATUS");
          lCxSymbolDailyTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxSymbolDailyTabObj.rec_cre_date != null && lCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxSymbolDailyTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxSymbolDailyTabObj.rec_upd_date != null && lCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lCxSymbolDailyTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( lCxSymbolDailyTabObj.eff_date != null && lCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            lCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          lCxSymbolDailyTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( lCxSymbolDailyTabObj.exp_date != null && lCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          lCxSymbolDailyTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          lCxSymbolDailyTabObj.fwd_rate  =  lResultSet.getDouble("FWD_RATE");
          lCxSymbolDailyTabObj.fut_rate  =  lResultSet.getDouble("FUT_RATE");
          lCxSymbolDailyTabObj.spot_rate  =  lResultSet.getDouble("SPOT_RATE");
          lCxSymbolDailyTabObj.ltp  =  lResultSet.getDouble("LTP");
          lCxSymbolDailyTabObj.ltp_date  =  lResultSet.getString("LTP_DATE");

          if ( lCxSymbolDailyTabObj.ltp_date != null && lCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.ltp_time  =  lResultSet.getString("LTP_TIME");
          lCxSymbolDailyTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          lCxSymbolDailyTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          lCxSymbolDailyTabObj.net_change  =  lResultSet.getDouble("NET_CHANGE");
          lCxSymbolDailyTabObj.percent_change  =  lResultSet.getFloat("PERCENT_CHANGE");
          lCxSymbolDailyTabObj.high  =  lResultSet.getDouble("HIGH");
          lCxSymbolDailyTabObj.low  =  lResultSet.getDouble("LOW");
          lCxSymbolDailyTabObj.bbr  =  lResultSet.getDouble("BBR");
          lCxSymbolDailyTabObj.bbq  =  lResultSet.getInt("BBQ");
          lCxSymbolDailyTabObj.bsr  =  lResultSet.getDouble("BSR");
          lCxSymbolDailyTabObj.bsq  =  lResultSet.getInt("BSQ");
          lCxSymbolDailyTabObj.open_rate  =  lResultSet.getDouble("OPEN_RATE");
          lCxSymbolDailyTabObj.close_rate  =  lResultSet.getDouble("CLOSE_RATE");

          removeNullCxSymbolDailyTabObj( lCxSymbolDailyTabObj );

          outCxSymbolDailyTabObjArr.add(  lCxSymbolDailyTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolDailyTabObjArr != null && outCxSymbolDailyTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxSymbolDailyArr2XML
               ( String inCxSymbolDailyWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxSymbolDailyArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxSymbolDaily>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("curr_date") )
              lXmlBuffer = lXmlBuffer +   "<CURR_DATE>" +  lResultSet.getString("CURR_DATE") +   "</CURR_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("contract_id") )
              lXmlBuffer = lXmlBuffer +   "<CONTRACT_ID>" +  lResultSet.getString("CONTRACT_ID") +   "</CONTRACT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_cd") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_CD>" +  lResultSet.getString("SYMBOL_CD") +   "</SYMBOL_CD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_name") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_NAME>" +  lResultSet.getString("SYMBOL_NAME") +   "</SYMBOL_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("eff_date") )
              lXmlBuffer = lXmlBuffer +   "<EFF_DATE>" +  lResultSet.getString("EFF_DATE") +   "</EFF_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("eff_time") )
              lXmlBuffer = lXmlBuffer +   "<EFF_TIME>" +  lResultSet.getString("EFF_TIME") +   "</EFF_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_date") )
              lXmlBuffer = lXmlBuffer +   "<EXP_DATE>" +  lResultSet.getString("EXP_DATE") +   "</EXP_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_time") )
              lXmlBuffer = lXmlBuffer +   "<EXP_TIME>" +  lResultSet.getString("EXP_TIME") +   "</EXP_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_rate") )
              lXmlBuffer = lXmlBuffer +   "<EXP_RATE>" +  lResultSet.getDouble("EXP_RATE") +   "</EXP_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fwd_rate") )
              lXmlBuffer = lXmlBuffer +   "<FWD_RATE>" +  lResultSet.getDouble("FWD_RATE") +   "</FWD_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fut_rate") )
              lXmlBuffer = lXmlBuffer +   "<FUT_RATE>" +  lResultSet.getDouble("FUT_RATE") +   "</FUT_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spot_rate") )
              lXmlBuffer = lXmlBuffer +   "<SPOT_RATE>" +  lResultSet.getDouble("SPOT_RATE") +   "</SPOT_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ltp") )
              lXmlBuffer = lXmlBuffer +   "<LTP>" +  lResultSet.getDouble("LTP") +   "</LTP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ltp_date") )
              lXmlBuffer = lXmlBuffer +   "<LTP_DATE>" +  lResultSet.getString("LTP_DATE") +   "</LTP_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ltp_time") )
              lXmlBuffer = lXmlBuffer +   "<LTP_TIME>" +  lResultSet.getString("LTP_TIME") +   "</LTP_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate_currency") )
              lXmlBuffer = lXmlBuffer +   "<RATE_CURRENCY>" +  lResultSet.getString("RATE_CURRENCY") +   "</RATE_CURRENCY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate_per_uom") )
              lXmlBuffer = lXmlBuffer +   "<RATE_PER_UOM>" +  lResultSet.getString("RATE_PER_UOM") +   "</RATE_PER_UOM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("net_change") )
              lXmlBuffer = lXmlBuffer +   "<NET_CHANGE>" +  lResultSet.getDouble("NET_CHANGE") +   "</NET_CHANGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("percent_change") )
              lXmlBuffer = lXmlBuffer +   "<PERCENT_CHANGE>" +  lResultSet.getFloat("PERCENT_CHANGE") +   "</PERCENT_CHANGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("high") )
              lXmlBuffer = lXmlBuffer +   "<HIGH>" +  lResultSet.getDouble("HIGH") +   "</HIGH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("low") )
              lXmlBuffer = lXmlBuffer +   "<LOW>" +  lResultSet.getDouble("LOW") +   "</LOW>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bbr") )
              lXmlBuffer = lXmlBuffer +   "<BBR>" +  lResultSet.getDouble("BBR") +   "</BBR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bbq") )
              lXmlBuffer = lXmlBuffer +   "<BBQ>" +  lResultSet.getInt("BBQ") +   "</BBQ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bsr") )
              lXmlBuffer = lXmlBuffer +   "<BSR>" +  lResultSet.getDouble("BSR") +   "</BSR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bsq") )
              lXmlBuffer = lXmlBuffer +   "<BSQ>" +  lResultSet.getInt("BSQ") +   "</BSQ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("open_rate") )
              lXmlBuffer = lXmlBuffer +   "<OPEN_RATE>" +  lResultSet.getDouble("OPEN_RATE") +   "</OPEN_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("close_rate") )
              lXmlBuffer = lXmlBuffer +   "<CLOSE_RATE>" +  lResultSet.getDouble("CLOSE_RATE") +   "</CLOSE_RATE>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxSymbolDaily>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxSymbolDailyRecByRowid
               ( String inRowId
               , CxSymbolDailyTabObj  outCxSymbolDailyTabObj
               )
  {
    sop("gtCxSymbolDailyRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "curr_date, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "exp_rate, "+
                                 "fwd_rate, "+
                                 "fut_rate, "+
                                 "spot_rate, "+
                                 "ltp, "+
                                 "ltp_date, "+
                                 "ltp_time, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "net_change, "+
                                 "percent_change, "+
                                 "high, "+
                                 "low, "+
                                 "bbr, "+
                                 "bbq, "+
                                 "bsr, "+
                                 "bsq, "+
                                 "open_rate, "+
                                 "close_rate "+
                         "FROM   CX_SYMBOL_DAILY "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxSymbolDailyTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxSymbolDailyTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxSymbolDailyTabObj.curr_date  =  lResultSet.getString("CURR_DATE");

          if ( outCxSymbolDailyTabObj.curr_date != null && outCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            outCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxSymbolDailyTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxSymbolDailyTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          outCxSymbolDailyTabObj.status  =  lResultSet.getString("STATUS");
          outCxSymbolDailyTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxSymbolDailyTabObj.rec_cre_date != null && outCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            outCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxSymbolDailyTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxSymbolDailyTabObj.rec_upd_date != null && outCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            outCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outCxSymbolDailyTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( outCxSymbolDailyTabObj.eff_date != null && outCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            outCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          outCxSymbolDailyTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( outCxSymbolDailyTabObj.exp_date != null && outCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            outCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          outCxSymbolDailyTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          outCxSymbolDailyTabObj.fwd_rate  =  lResultSet.getDouble("FWD_RATE");
          outCxSymbolDailyTabObj.fut_rate  =  lResultSet.getDouble("FUT_RATE");
          outCxSymbolDailyTabObj.spot_rate  =  lResultSet.getDouble("SPOT_RATE");
          outCxSymbolDailyTabObj.ltp  =  lResultSet.getDouble("LTP");
          outCxSymbolDailyTabObj.ltp_date  =  lResultSet.getString("LTP_DATE");

          if ( outCxSymbolDailyTabObj.ltp_date != null && outCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            outCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
          outCxSymbolDailyTabObj.ltp_time  =  lResultSet.getString("LTP_TIME");
          outCxSymbolDailyTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          outCxSymbolDailyTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          outCxSymbolDailyTabObj.net_change  =  lResultSet.getDouble("NET_CHANGE");
          outCxSymbolDailyTabObj.percent_change  =  lResultSet.getFloat("PERCENT_CHANGE");
          outCxSymbolDailyTabObj.high  =  lResultSet.getDouble("HIGH");
          outCxSymbolDailyTabObj.low  =  lResultSet.getDouble("LOW");
          outCxSymbolDailyTabObj.bbr  =  lResultSet.getDouble("BBR");
          outCxSymbolDailyTabObj.bbq  =  lResultSet.getInt("BBQ");
          outCxSymbolDailyTabObj.bsr  =  lResultSet.getDouble("BSR");
          outCxSymbolDailyTabObj.bsq  =  lResultSet.getInt("BSQ");
          outCxSymbolDailyTabObj.open_rate  =  lResultSet.getDouble("OPEN_RATE");
          outCxSymbolDailyTabObj.close_rate  =  lResultSet.getDouble("CLOSE_RATE");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxSymbolDailyTabObj( outCxSymbolDailyTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyArr
               ( String inCxSymbolDailyWhereText
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {
    sop("gtCxSymbolDailyArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "curr_date, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "exp_rate, "+
                                 "fwd_rate, "+
                                 "fut_rate, "+
                                 "spot_rate, "+
                                 "ltp, "+
                                 "ltp_date, "+
                                 "ltp_time, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "net_change, "+
                                 "percent_change, "+
                                 "high, "+
                                 "low, "+
                                 "bbr, "+
                                 "bbq, "+
                                 "bsr, "+
                                 "bsq, "+
                                 "open_rate, "+
                                 "close_rate "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxSymbolDailyTabObj  lCxSymbolDailyTabObj = new CxSymbolDailyTabObj();
          lCxSymbolDailyTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxSymbolDailyTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxSymbolDailyTabObj.curr_date  =  lResultSet.getString("CURR_DATE");

          if ( lCxSymbolDailyTabObj.curr_date != null && lCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            lCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxSymbolDailyTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxSymbolDailyTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          lCxSymbolDailyTabObj.status  =  lResultSet.getString("STATUS");
          lCxSymbolDailyTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxSymbolDailyTabObj.rec_cre_date != null && lCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxSymbolDailyTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxSymbolDailyTabObj.rec_upd_date != null && lCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lCxSymbolDailyTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( lCxSymbolDailyTabObj.eff_date != null && lCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            lCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          lCxSymbolDailyTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( lCxSymbolDailyTabObj.exp_date != null && lCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          lCxSymbolDailyTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          lCxSymbolDailyTabObj.fwd_rate  =  lResultSet.getDouble("FWD_RATE");
          lCxSymbolDailyTabObj.fut_rate  =  lResultSet.getDouble("FUT_RATE");
          lCxSymbolDailyTabObj.spot_rate  =  lResultSet.getDouble("SPOT_RATE");
          lCxSymbolDailyTabObj.ltp  =  lResultSet.getDouble("LTP");
          lCxSymbolDailyTabObj.ltp_date  =  lResultSet.getString("LTP_DATE");

          if ( lCxSymbolDailyTabObj.ltp_date != null && lCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
          lCxSymbolDailyTabObj.ltp_time  =  lResultSet.getString("LTP_TIME");
          lCxSymbolDailyTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          lCxSymbolDailyTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          lCxSymbolDailyTabObj.net_change  =  lResultSet.getDouble("NET_CHANGE");
          lCxSymbolDailyTabObj.percent_change  =  lResultSet.getFloat("PERCENT_CHANGE");
          lCxSymbolDailyTabObj.high  =  lResultSet.getDouble("HIGH");
          lCxSymbolDailyTabObj.low  =  lResultSet.getDouble("LOW");
          lCxSymbolDailyTabObj.bbr  =  lResultSet.getDouble("BBR");
          lCxSymbolDailyTabObj.bbq  =  lResultSet.getInt("BBQ");
          lCxSymbolDailyTabObj.bsr  =  lResultSet.getDouble("BSR");
          lCxSymbolDailyTabObj.bsq  =  lResultSet.getInt("BSQ");
          lCxSymbolDailyTabObj.open_rate  =  lResultSet.getDouble("OPEN_RATE");
          lCxSymbolDailyTabObj.close_rate  =  lResultSet.getDouble("CLOSE_RATE");

          removeNullCxSymbolDailyTabObj( lCxSymbolDailyTabObj );

          outCxSymbolDailyTabObjArr.add(  lCxSymbolDailyTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolDailyTabObjArr != null && outCxSymbolDailyTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyArrDist
               ( String inCxSymbolDailyWhereText
               , String inDistCxSymbolDailyField
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {

    sop("gtCxSymbolDailyArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";
  

       String lDistCxSymbolDailyFieldQry = inDistCxSymbolDailyField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxSymbolDailyFieldQry+
                         " FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxSymbolDailyField.substring(inDistCxSymbolDailyField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxSymbolDailyTabObj  lCxSymbolDailyTabObj = new CxSymbolDailyTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxSymbolDailyTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("curr_date") )
              {
              lCxSymbolDailyTabObj.curr_date  =  lResultSet.getString("CURR_DATE");
  
          if ( lCxSymbolDailyTabObj.curr_date != null && lCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            lCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.curr_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("contract_id") )
              lCxSymbolDailyTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_cd") )
              lCxSymbolDailyTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_name") )
              lCxSymbolDailyTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxSymbolDailyTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxSymbolDailyTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxSymbolDailyTabObj.rec_cre_date != null && lCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxSymbolDailyTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxSymbolDailyTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxSymbolDailyTabObj.rec_upd_date != null && lCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxSymbolDailyTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("eff_date") )
              {
              lCxSymbolDailyTabObj.eff_date  =  lResultSet.getString("EFF_DATE");
  
          if ( lCxSymbolDailyTabObj.eff_date != null && lCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            lCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.eff_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("eff_time") )
              lCxSymbolDailyTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_date") )
              {
              lCxSymbolDailyTabObj.exp_date  =  lResultSet.getString("EXP_DATE");
  
          if ( lCxSymbolDailyTabObj.exp_date != null && lCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.exp_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_time") )
              lCxSymbolDailyTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_rate") )
              lCxSymbolDailyTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fwd_rate") )
              lCxSymbolDailyTabObj.fwd_rate  =  lResultSet.getDouble("FWD_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fut_rate") )
              lCxSymbolDailyTabObj.fut_rate  =  lResultSet.getDouble("FUT_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spot_rate") )
              lCxSymbolDailyTabObj.spot_rate  =  lResultSet.getDouble("SPOT_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ltp") )
              lCxSymbolDailyTabObj.ltp  =  lResultSet.getDouble("LTP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ltp_date") )
              {
              lCxSymbolDailyTabObj.ltp_date  =  lResultSet.getString("LTP_DATE");
  
          if ( lCxSymbolDailyTabObj.ltp_date != null && lCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolDailyTabObj.ltp_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ltp_time") )
              lCxSymbolDailyTabObj.ltp_time  =  lResultSet.getString("LTP_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate_currency") )
              lCxSymbolDailyTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate_per_uom") )
              lCxSymbolDailyTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("net_change") )
              lCxSymbolDailyTabObj.net_change  =  lResultSet.getDouble("NET_CHANGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("percent_change") )
              lCxSymbolDailyTabObj.percent_change  =  lResultSet.getFloat("PERCENT_CHANGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("high") )
              lCxSymbolDailyTabObj.high  =  lResultSet.getDouble("HIGH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("low") )
              lCxSymbolDailyTabObj.low  =  lResultSet.getDouble("LOW");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bbr") )
              lCxSymbolDailyTabObj.bbr  =  lResultSet.getDouble("BBR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bbq") )
              lCxSymbolDailyTabObj.bbq  =  lResultSet.getInt("BBQ");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bsr") )
              lCxSymbolDailyTabObj.bsr  =  lResultSet.getDouble("BSR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bsq") )
              lCxSymbolDailyTabObj.bsq  =  lResultSet.getInt("BSQ");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("open_rate") )
              lCxSymbolDailyTabObj.open_rate  =  lResultSet.getDouble("OPEN_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("close_rate") )
              lCxSymbolDailyTabObj.close_rate  =  lResultSet.getDouble("CLOSE_RATE");

          }
          removeNullCxSymbolDailyTabObj( lCxSymbolDailyTabObj );

          outCxSymbolDailyTabObjArr.add(  lCxSymbolDailyTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolDailyTabObjArr != null && outCxSymbolDailyTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolDailyStrArrDist
               ( String inCxSymbolDailyWhereText
               , String inDistCxSymbolDailyField
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {

    sop("gtCxSymbolDailyStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolDailyStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";
  

       String lDistCxSymbolDailyFieldQry = inDistCxSymbolDailyField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxSymbolDailyFieldQry+
                         " FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxSymbolDailyField.substring(inDistCxSymbolDailyField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxSymbolDailyTabObjStr = "";
       while(lResultSet.next())
       {
          lCxSymbolDailyTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxSymbolDailyTabObjStr =   lCxSymbolDailyTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxSymbolDailyTabObjArr.add(  lCxSymbolDailyTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolDailyTabObjArr != null && outCxSymbolDailyTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxSymbolDaily
               ( String inCxSymbolDailyWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxSymbolDaily - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxSymbolDaily";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxSymbolDailyTabObj
               ( 
                 CxSymbolDailyTabObj  outCxSymbolDailyTabObj
               )
  {
  
    if ( outCxSymbolDailyTabObj.org_id == null ) 
     outCxSymbolDailyTabObj.org_id = ""; 
    if ( outCxSymbolDailyTabObj.curr_date == null ) 
     outCxSymbolDailyTabObj.curr_date = ""; 
    if ( outCxSymbolDailyTabObj.contract_id == null ) 
     outCxSymbolDailyTabObj.contract_id = ""; 
    if ( outCxSymbolDailyTabObj.symbol_cd == null ) 
     outCxSymbolDailyTabObj.symbol_cd = ""; 
    if ( outCxSymbolDailyTabObj.symbol_name == null ) 
     outCxSymbolDailyTabObj.symbol_name = ""; 
    if ( outCxSymbolDailyTabObj.status == null ) 
     outCxSymbolDailyTabObj.status = ""; 
    if ( outCxSymbolDailyTabObj.rec_cre_date == null ) 
     outCxSymbolDailyTabObj.rec_cre_date = ""; 
    if ( outCxSymbolDailyTabObj.rec_cre_time == null ) 
     outCxSymbolDailyTabObj.rec_cre_time = ""; 
    if ( outCxSymbolDailyTabObj.rec_upd_date == null ) 
     outCxSymbolDailyTabObj.rec_upd_date = ""; 
    if ( outCxSymbolDailyTabObj.rec_upd_time == null ) 
     outCxSymbolDailyTabObj.rec_upd_time = ""; 
    if ( outCxSymbolDailyTabObj.eff_date == null ) 
     outCxSymbolDailyTabObj.eff_date = ""; 
    if ( outCxSymbolDailyTabObj.eff_time == null ) 
     outCxSymbolDailyTabObj.eff_time = ""; 
    if ( outCxSymbolDailyTabObj.exp_date == null ) 
     outCxSymbolDailyTabObj.exp_date = ""; 
    if ( outCxSymbolDailyTabObj.exp_time == null ) 
     outCxSymbolDailyTabObj.exp_time = ""; 
    if ( outCxSymbolDailyTabObj.exp_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.exp_rate = (double)0.00; 
    if ( outCxSymbolDailyTabObj.fwd_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.fwd_rate = (double)0.00; 
    if ( outCxSymbolDailyTabObj.fut_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.fut_rate = (double)0.00; 
    if ( outCxSymbolDailyTabObj.spot_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.spot_rate = (double)0.00; 
    if ( outCxSymbolDailyTabObj.ltp == (double)0.00 ) 
     outCxSymbolDailyTabObj.ltp = (double)0.00; 
    if ( outCxSymbolDailyTabObj.ltp_date == null ) 
     outCxSymbolDailyTabObj.ltp_date = ""; 
    if ( outCxSymbolDailyTabObj.ltp_time == null ) 
     outCxSymbolDailyTabObj.ltp_time = ""; 
    if ( outCxSymbolDailyTabObj.rate_currency == null ) 
     outCxSymbolDailyTabObj.rate_currency = ""; 
    if ( outCxSymbolDailyTabObj.rate_per_uom == null ) 
     outCxSymbolDailyTabObj.rate_per_uom = ""; 
    if ( outCxSymbolDailyTabObj.net_change == (double)0.00 ) 
     outCxSymbolDailyTabObj.net_change = (double)0.00; 
    if ( outCxSymbolDailyTabObj.percent_change == (float)0.00 ) 
     outCxSymbolDailyTabObj.percent_change = (float)0.00; 
    if ( outCxSymbolDailyTabObj.high == (double)0.00 ) 
     outCxSymbolDailyTabObj.high = (double)0.00; 
    if ( outCxSymbolDailyTabObj.low == (double)0.00 ) 
     outCxSymbolDailyTabObj.low = (double)0.00; 
    if ( outCxSymbolDailyTabObj.bbr == (double)0.00 ) 
     outCxSymbolDailyTabObj.bbr = (double)0.00; 
    if ( outCxSymbolDailyTabObj.bbq == (int)0 ) 
     outCxSymbolDailyTabObj.bbq = (int)0; 
    if ( outCxSymbolDailyTabObj.bsr == (double)0.00 ) 
     outCxSymbolDailyTabObj.bsr = (double)0.00; 
    if ( outCxSymbolDailyTabObj.bsq == (int)0 ) 
     outCxSymbolDailyTabObj.bsq = (int)0; 
    if ( outCxSymbolDailyTabObj.open_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.open_rate = (double)0.00; 
    if ( outCxSymbolDailyTabObj.close_rate == (double)0.00 ) 
     outCxSymbolDailyTabObj.close_rate = (double)0.00; 
  }





  public int insCxSymbolDailyRec
               ( CxSymbolDailyTabObj  inCxSymbolDailyTabObj )
  {
    int lUpdateCount;
    sop("insCxSymbolDailyRec - Started");
    gSSTErrorObj.sourceMethod = "insCxSymbolDailyRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolDailyTabObj.curr_date != null && inCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            inCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.curr_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_cre_date != null && inCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_upd_date != null && inCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.eff_date != null && inCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            inCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.exp_date != null && inCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.ltp_date != null && inCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.ltp_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_SYMBOL_DAILY"+
                        "("+
                                "org_id,"+
                                "curr_date,"+
                                "contract_id,"+
                                "symbol_cd,"+
                                "symbol_name,"+
                                "status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "eff_date,"+
                                "eff_time,"+
                                "exp_date,"+
                                "exp_time,"+
                                "exp_rate,"+
                                "fwd_rate,"+
                                "fut_rate,"+
                                "spot_rate,"+
                                "ltp,"+
                                "ltp_date,"+
                                "ltp_time,"+
                                "rate_currency,"+
                                "rate_per_uom,"+
                                "net_change,"+
                                "percent_change,"+
                                "high,"+
                                "low,"+
                                "bbr,"+
                                "bbq,"+
                                "bsr,"+
                                "bsq,"+
                                "open_rate,"+
                                "close_rate"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.curr_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.contract_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.symbol_cd+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.symbol_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.eff_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.eff_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.exp_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.exp_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.exp_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.fwd_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.fut_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.spot_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.ltp+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.ltp_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.ltp_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rate_currency+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolDailyTabObj.rate_per_uom+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.net_change+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.percent_change+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.high+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.low+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.bbr+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.bbq+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.bsr+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.bsq+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolDailyTabObj.open_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += inCxSymbolDailyTabObj.close_rate+"";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxSymbolDailyTabObj.org_id);
        lPreparedStatement.setString(2, inCxSymbolDailyTabObj.curr_date);
        lPreparedStatement.setString(3, inCxSymbolDailyTabObj.contract_id);
        lPreparedStatement.setString(4, inCxSymbolDailyTabObj.symbol_cd);
        lPreparedStatement.setString(5, inCxSymbolDailyTabObj.symbol_name);
        lPreparedStatement.setString(6, inCxSymbolDailyTabObj.status);
        lPreparedStatement.setString(7, inCxSymbolDailyTabObj.rec_cre_date);
        lPreparedStatement.setString(8, inCxSymbolDailyTabObj.rec_cre_time);
        lPreparedStatement.setString(9, inCxSymbolDailyTabObj.rec_upd_date);
        lPreparedStatement.setString(10, inCxSymbolDailyTabObj.rec_upd_time);
        lPreparedStatement.setString(11, inCxSymbolDailyTabObj.eff_date);
        lPreparedStatement.setString(12, inCxSymbolDailyTabObj.eff_time);
        lPreparedStatement.setString(13, inCxSymbolDailyTabObj.exp_date);
        lPreparedStatement.setString(14, inCxSymbolDailyTabObj.exp_time);
          lPreparedStatement.setDouble(15, inCxSymbolDailyTabObj.exp_rate);
          lPreparedStatement.setDouble(16, inCxSymbolDailyTabObj.fwd_rate);
          lPreparedStatement.setDouble(17, inCxSymbolDailyTabObj.fut_rate);
          lPreparedStatement.setDouble(18, inCxSymbolDailyTabObj.spot_rate);
          lPreparedStatement.setDouble(19, inCxSymbolDailyTabObj.ltp);
        lPreparedStatement.setString(20, inCxSymbolDailyTabObj.ltp_date);
        lPreparedStatement.setString(21, inCxSymbolDailyTabObj.ltp_time);
        lPreparedStatement.setString(22, inCxSymbolDailyTabObj.rate_currency);
        lPreparedStatement.setString(23, inCxSymbolDailyTabObj.rate_per_uom);
          lPreparedStatement.setDouble(24, inCxSymbolDailyTabObj.net_change);
          lPreparedStatement.setFloat(25, inCxSymbolDailyTabObj.percent_change);
          lPreparedStatement.setDouble(26, inCxSymbolDailyTabObj.high);
          lPreparedStatement.setDouble(27, inCxSymbolDailyTabObj.low);
          lPreparedStatement.setDouble(28, inCxSymbolDailyTabObj.bbr);
          lPreparedStatement.setInt(29, inCxSymbolDailyTabObj.bbq);
          lPreparedStatement.setDouble(30, inCxSymbolDailyTabObj.bsr);
          lPreparedStatement.setInt(31, inCxSymbolDailyTabObj.bsq);
          lPreparedStatement.setDouble(32, inCxSymbolDailyTabObj.open_rate);
          lPreparedStatement.setDouble(33, inCxSymbolDailyTabObj.close_rate);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxSymbolDailyArr
               ( ArrayList  inCxSymbolDailyTabObjArr 
               , String  inRowidFlag )
  {
    CxSymbolDailyTabObj  lCxSymbolDailyTabObj = new CxSymbolDailyTabObj();
    int lUpdateCount;
    sop("insCxSymbolDailyArr - Started");
    gSSTErrorObj.sourceMethod = "insCxSymbolDailyArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxSymbolDailyTabObjArr.size(); lNumRec++ )
      {
        lCxSymbolDailyTabObj = (CxSymbolDailyTabObj)inCxSymbolDailyTabObjArr.get(lNumRec);

          if ( lCxSymbolDailyTabObj.curr_date != null && lCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            lCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.curr_date, lDateTimeSrcFmt);

          if ( lCxSymbolDailyTabObj.rec_cre_date != null && lCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxSymbolDailyTabObj.rec_upd_date != null && lCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( lCxSymbolDailyTabObj.eff_date != null && lCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            lCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.eff_date, lDateTimeSrcFmt);

          if ( lCxSymbolDailyTabObj.exp_date != null && lCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.exp_date, lDateTimeSrcFmt);

          if ( lCxSymbolDailyTabObj.ltp_date != null && lCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            lCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolDailyTabObj.ltp_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_SYMBOL_DAILY"+
                        "("+
                        "org_id,"+
                        "curr_date,"+
                        "contract_id,"+
                        "symbol_cd,"+
                        "symbol_name,"+
                        "status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "eff_date,"+
                        "eff_time,"+
                        "exp_date,"+
                        "exp_time,"+
                        "exp_rate,"+
                        "fwd_rate,"+
                        "fut_rate,"+
                        "spot_rate,"+
                        "ltp,"+
                        "ltp_date,"+
                        "ltp_time,"+
                        "rate_currency,"+
                        "rate_per_uom,"+
                        "net_change,"+
                        "percent_change,"+
                        "high,"+
                        "low,"+
                        "bbr,"+
                        "bbq,"+
                        "bsr,"+
                        "bsq,"+
                        "open_rate,"+
                        "close_rate"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.curr_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.contract_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.symbol_cd+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.symbol_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.eff_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.eff_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.exp_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.exp_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.exp_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.fwd_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.fut_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.spot_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.ltp+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.ltp_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.ltp_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rate_currency+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolDailyTabObj.rate_per_uom+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.net_change+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.percent_change+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.high+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.low+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.bbr+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.bbq+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.bsr+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.bsq+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolDailyTabObj.open_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += lCxSymbolDailyTabObj.close_rate+"";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxSymbolDailyTabObj.org_id);
            lPreparedStatement.setString(2, lCxSymbolDailyTabObj.curr_date);
            lPreparedStatement.setString(3, lCxSymbolDailyTabObj.contract_id);
            lPreparedStatement.setString(4, lCxSymbolDailyTabObj.symbol_cd);
            lPreparedStatement.setString(5, lCxSymbolDailyTabObj.symbol_name);
            lPreparedStatement.setString(6, lCxSymbolDailyTabObj.status);
            lPreparedStatement.setString(7, lCxSymbolDailyTabObj.rec_cre_date);
            lPreparedStatement.setString(8, lCxSymbolDailyTabObj.rec_cre_time);
            lPreparedStatement.setString(9, lCxSymbolDailyTabObj.rec_upd_date);
            lPreparedStatement.setString(10, lCxSymbolDailyTabObj.rec_upd_time);
            lPreparedStatement.setString(11, lCxSymbolDailyTabObj.eff_date);
            lPreparedStatement.setString(12, lCxSymbolDailyTabObj.eff_time);
            lPreparedStatement.setString(13, lCxSymbolDailyTabObj.exp_date);
            lPreparedStatement.setString(14, lCxSymbolDailyTabObj.exp_time);
              lPreparedStatement.setDouble(15, lCxSymbolDailyTabObj.exp_rate);
              lPreparedStatement.setDouble(16, lCxSymbolDailyTabObj.fwd_rate);
              lPreparedStatement.setDouble(17, lCxSymbolDailyTabObj.fut_rate);
              lPreparedStatement.setDouble(18, lCxSymbolDailyTabObj.spot_rate);
              lPreparedStatement.setDouble(19, lCxSymbolDailyTabObj.ltp);
            lPreparedStatement.setString(20, lCxSymbolDailyTabObj.ltp_date);
            lPreparedStatement.setString(21, lCxSymbolDailyTabObj.ltp_time);
            lPreparedStatement.setString(22, lCxSymbolDailyTabObj.rate_currency);
            lPreparedStatement.setString(23, lCxSymbolDailyTabObj.rate_per_uom);
              lPreparedStatement.setDouble(24, lCxSymbolDailyTabObj.net_change);
              lPreparedStatement.setFloat(25, lCxSymbolDailyTabObj.percent_change);
              lPreparedStatement.setDouble(26, lCxSymbolDailyTabObj.high);
              lPreparedStatement.setDouble(27, lCxSymbolDailyTabObj.low);
              lPreparedStatement.setDouble(28, lCxSymbolDailyTabObj.bbr);
              lPreparedStatement.setInt(29, lCxSymbolDailyTabObj.bbq);
              lPreparedStatement.setDouble(30, lCxSymbolDailyTabObj.bsr);
              lPreparedStatement.setInt(31, lCxSymbolDailyTabObj.bsq);
              lPreparedStatement.setDouble(32, lCxSymbolDailyTabObj.open_rate);
              lPreparedStatement.setDouble(33, lCxSymbolDailyTabObj.close_rate);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxSymbolDailyReq2Obj
               ( HttpServletRequest inRequest
               , CxSymbolDailyTabObj  outCxSymbolDailyTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxSymbolDailyTabObj.tab_rowid = lTabRowidValue;

    outCxSymbolDailyTabObj.org_id = inRequest.getParameter("org_id");
    outCxSymbolDailyTabObj.curr_date = inRequest.getParameter("curr_date");
    outCxSymbolDailyTabObj.contract_id = inRequest.getParameter("contract_id");
    outCxSymbolDailyTabObj.symbol_cd = inRequest.getParameter("symbol_cd");
    outCxSymbolDailyTabObj.symbol_name = inRequest.getParameter("symbol_name");
    outCxSymbolDailyTabObj.status = inRequest.getParameter("status");
    outCxSymbolDailyTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxSymbolDailyTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxSymbolDailyTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxSymbolDailyTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outCxSymbolDailyTabObj.eff_date = inRequest.getParameter("eff_date");
    outCxSymbolDailyTabObj.eff_time = inRequest.getParameter("eff_time");
    outCxSymbolDailyTabObj.exp_date = inRequest.getParameter("exp_date");
    outCxSymbolDailyTabObj.exp_time = inRequest.getParameter("exp_time");
    if ( inRequest.getParameter("exp_rate") == null )
      outCxSymbolDailyTabObj.exp_rate = 0;
    else
    if ( inRequest.getParameter("exp_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.exp_rate = 0;
    else
      outCxSymbolDailyTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate"));
    if ( inRequest.getParameter("fwd_rate") == null )
      outCxSymbolDailyTabObj.fwd_rate = 0;
    else
    if ( inRequest.getParameter("fwd_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.fwd_rate = 0;
    else
      outCxSymbolDailyTabObj.fwd_rate = Double.parseDouble( inRequest.getParameter("fwd_rate"));
    if ( inRequest.getParameter("fut_rate") == null )
      outCxSymbolDailyTabObj.fut_rate = 0;
    else
    if ( inRequest.getParameter("fut_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.fut_rate = 0;
    else
      outCxSymbolDailyTabObj.fut_rate = Double.parseDouble( inRequest.getParameter("fut_rate"));
    if ( inRequest.getParameter("spot_rate") == null )
      outCxSymbolDailyTabObj.spot_rate = 0;
    else
    if ( inRequest.getParameter("spot_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.spot_rate = 0;
    else
      outCxSymbolDailyTabObj.spot_rate = Double.parseDouble( inRequest.getParameter("spot_rate"));
    if ( inRequest.getParameter("ltp") == null )
      outCxSymbolDailyTabObj.ltp = 0;
    else
    if ( inRequest.getParameter("ltp").trim().length() == 0 )
      outCxSymbolDailyTabObj.ltp = 0;
    else
      outCxSymbolDailyTabObj.ltp = Double.parseDouble( inRequest.getParameter("ltp"));
    outCxSymbolDailyTabObj.ltp_date = inRequest.getParameter("ltp_date");
    outCxSymbolDailyTabObj.ltp_time = inRequest.getParameter("ltp_time");
    outCxSymbolDailyTabObj.rate_currency = inRequest.getParameter("rate_currency");
    outCxSymbolDailyTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom");
    if ( inRequest.getParameter("net_change") == null )
      outCxSymbolDailyTabObj.net_change = 0;
    else
    if ( inRequest.getParameter("net_change").trim().length() == 0 )
      outCxSymbolDailyTabObj.net_change = 0;
    else
      outCxSymbolDailyTabObj.net_change = Double.parseDouble( inRequest.getParameter("net_change"));
    if ( inRequest.getParameter("percent_change") == null )
      outCxSymbolDailyTabObj.percent_change = 0;
    else
    if ( inRequest.getParameter("percent_change").trim().length() == 0 )
      outCxSymbolDailyTabObj.percent_change = 0;
    else
      outCxSymbolDailyTabObj.percent_change = Float.parseFloat( inRequest.getParameter("percent_change"));
    if ( inRequest.getParameter("high") == null )
      outCxSymbolDailyTabObj.high = 0;
    else
    if ( inRequest.getParameter("high").trim().length() == 0 )
      outCxSymbolDailyTabObj.high = 0;
    else
      outCxSymbolDailyTabObj.high = Double.parseDouble( inRequest.getParameter("high"));
    if ( inRequest.getParameter("low") == null )
      outCxSymbolDailyTabObj.low = 0;
    else
    if ( inRequest.getParameter("low").trim().length() == 0 )
      outCxSymbolDailyTabObj.low = 0;
    else
      outCxSymbolDailyTabObj.low = Double.parseDouble( inRequest.getParameter("low"));
    if ( inRequest.getParameter("bbr") == null )
      outCxSymbolDailyTabObj.bbr = 0;
    else
    if ( inRequest.getParameter("bbr").trim().length() == 0 )
      outCxSymbolDailyTabObj.bbr = 0;
    else
      outCxSymbolDailyTabObj.bbr = Double.parseDouble( inRequest.getParameter("bbr"));
    if ( inRequest.getParameter("bbq") == null )
      outCxSymbolDailyTabObj.bbq = 0;
    else
    if ( inRequest.getParameter("bbq").trim().length() == 0 )
      outCxSymbolDailyTabObj.bbq = 0;
    else
      outCxSymbolDailyTabObj.bbq = Integer.parseInt( inRequest.getParameter("bbq"));
    if ( inRequest.getParameter("bsr") == null )
      outCxSymbolDailyTabObj.bsr = 0;
    else
    if ( inRequest.getParameter("bsr").trim().length() == 0 )
      outCxSymbolDailyTabObj.bsr = 0;
    else
      outCxSymbolDailyTabObj.bsr = Double.parseDouble( inRequest.getParameter("bsr"));
    if ( inRequest.getParameter("bsq") == null )
      outCxSymbolDailyTabObj.bsq = 0;
    else
    if ( inRequest.getParameter("bsq").trim().length() == 0 )
      outCxSymbolDailyTabObj.bsq = 0;
    else
      outCxSymbolDailyTabObj.bsq = Integer.parseInt( inRequest.getParameter("bsq"));
    if ( inRequest.getParameter("open_rate") == null )
      outCxSymbolDailyTabObj.open_rate = 0;
    else
    if ( inRequest.getParameter("open_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.open_rate = 0;
    else
      outCxSymbolDailyTabObj.open_rate = Double.parseDouble( inRequest.getParameter("open_rate"));
    if ( inRequest.getParameter("close_rate") == null )
      outCxSymbolDailyTabObj.close_rate = 0;
    else
    if ( inRequest.getParameter("close_rate").trim().length() == 0 )
      outCxSymbolDailyTabObj.close_rate = 0;
    else
      outCxSymbolDailyTabObj.close_rate = Double.parseDouble( inRequest.getParameter("close_rate"));
    return lReturnValue;
  }


  public int popCxSymbolDailyReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxSymbolDailyTabObj lCxSymbolDailyTabObj= new CxSymbolDailyTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxSymbolDailyTabObj.tab_rowid = lTabRowidValue;

      lCxSymbolDailyTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxSymbolDailyTabObj.curr_date = inRequest.getParameter("curr_date_r"+lNumRec);
      lCxSymbolDailyTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
      lCxSymbolDailyTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
      lCxSymbolDailyTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
      lCxSymbolDailyTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxSymbolDailyTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxSymbolDailyTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxSymbolDailyTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxSymbolDailyTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lCxSymbolDailyTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
      lCxSymbolDailyTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
      lCxSymbolDailyTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
      lCxSymbolDailyTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
      if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.exp_rate = 0;
      else
      if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.exp_rate = 0;
      else
        lCxSymbolDailyTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
      if ( inRequest.getParameter("fwd_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.fwd_rate = 0;
      else
      if ( inRequest.getParameter("fwd_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.fwd_rate = 0;
      else
        lCxSymbolDailyTabObj.fwd_rate = Double.parseDouble( inRequest.getParameter("fwd_rate_r"+lNumRec));
      if ( inRequest.getParameter("fut_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.fut_rate = 0;
      else
      if ( inRequest.getParameter("fut_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.fut_rate = 0;
      else
        lCxSymbolDailyTabObj.fut_rate = Double.parseDouble( inRequest.getParameter("fut_rate_r"+lNumRec));
      if ( inRequest.getParameter("spot_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.spot_rate = 0;
      else
      if ( inRequest.getParameter("spot_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.spot_rate = 0;
      else
        lCxSymbolDailyTabObj.spot_rate = Double.parseDouble( inRequest.getParameter("spot_rate_r"+lNumRec));
      if ( inRequest.getParameter("ltp_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.ltp = 0;
      else
      if ( inRequest.getParameter("ltp_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.ltp = 0;
      else
        lCxSymbolDailyTabObj.ltp = Double.parseDouble( inRequest.getParameter("ltp_r"+lNumRec));
      lCxSymbolDailyTabObj.ltp_date = inRequest.getParameter("ltp_date_r"+lNumRec);
      lCxSymbolDailyTabObj.ltp_time = inRequest.getParameter("ltp_time_r"+lNumRec);
      lCxSymbolDailyTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
      lCxSymbolDailyTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
      if ( inRequest.getParameter("net_change_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.net_change = 0;
      else
      if ( inRequest.getParameter("net_change_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.net_change = 0;
      else
        lCxSymbolDailyTabObj.net_change = Double.parseDouble( inRequest.getParameter("net_change_r"+lNumRec));
      if ( inRequest.getParameter("percent_change_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.percent_change = 0;
      else
      if ( inRequest.getParameter("percent_change_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.percent_change = 0;
      else
        lCxSymbolDailyTabObj.percent_change = Float.parseFloat( inRequest.getParameter("percent_change_r"+lNumRec));
      if ( inRequest.getParameter("high_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.high = 0;
      else
      if ( inRequest.getParameter("high_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.high = 0;
      else
        lCxSymbolDailyTabObj.high = Double.parseDouble( inRequest.getParameter("high_r"+lNumRec));
      if ( inRequest.getParameter("low_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.low = 0;
      else
      if ( inRequest.getParameter("low_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.low = 0;
      else
        lCxSymbolDailyTabObj.low = Double.parseDouble( inRequest.getParameter("low_r"+lNumRec));
      if ( inRequest.getParameter("bbr_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.bbr = 0;
      else
      if ( inRequest.getParameter("bbr_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.bbr = 0;
      else
        lCxSymbolDailyTabObj.bbr = Double.parseDouble( inRequest.getParameter("bbr_r"+lNumRec));
      if ( inRequest.getParameter("bbq_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.bbq = 0;
      else
      if ( inRequest.getParameter("bbq_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.bbq = 0;
      else
        lCxSymbolDailyTabObj.bbq = Integer.parseInt( inRequest.getParameter("bbq_r"+lNumRec));
      if ( inRequest.getParameter("bsr_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.bsr = 0;
      else
      if ( inRequest.getParameter("bsr_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.bsr = 0;
      else
        lCxSymbolDailyTabObj.bsr = Double.parseDouble( inRequest.getParameter("bsr_r"+lNumRec));
      if ( inRequest.getParameter("bsq_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.bsq = 0;
      else
      if ( inRequest.getParameter("bsq_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.bsq = 0;
      else
        lCxSymbolDailyTabObj.bsq = Integer.parseInt( inRequest.getParameter("bsq_r"+lNumRec));
      if ( inRequest.getParameter("open_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.open_rate = 0;
      else
      if ( inRequest.getParameter("open_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.open_rate = 0;
      else
        lCxSymbolDailyTabObj.open_rate = Double.parseDouble( inRequest.getParameter("open_rate_r"+lNumRec));
      if ( inRequest.getParameter("close_rate_r"+lNumRec) == null )
        lCxSymbolDailyTabObj.close_rate = 0;
      else
      if ( inRequest.getParameter("close_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolDailyTabObj.close_rate = 0;
      else
        lCxSymbolDailyTabObj.close_rate = Double.parseDouble( inRequest.getParameter("close_rate_r"+lNumRec));
      outCxSymbolDailyTabObjArr.add( lCxSymbolDailyTabObj);
    }
    return lReturnValue;
  }


  public int popCxSymbolDailyReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxSymbolDailyTabObj outCxSymbolDailyTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_symbol_daily_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxSymbolDailyTabObj.tab_rowid = lTabRowidValue;

        outCxSymbolDailyTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxSymbolDailyTabObj.curr_date = inRequest.getParameter("curr_date_r"+lNumRec);
        outCxSymbolDailyTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        outCxSymbolDailyTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        outCxSymbolDailyTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
        outCxSymbolDailyTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxSymbolDailyTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxSymbolDailyTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxSymbolDailyTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxSymbolDailyTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxSymbolDailyTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
        outCxSymbolDailyTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
        outCxSymbolDailyTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
        outCxSymbolDailyTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
        if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.exp_rate = 0;
        else
        if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.exp_rate = 0;
        else
          outCxSymbolDailyTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
        if ( inRequest.getParameter("fwd_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.fwd_rate = 0;
        else
        if ( inRequest.getParameter("fwd_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.fwd_rate = 0;
        else
          outCxSymbolDailyTabObj.fwd_rate = Double.parseDouble( inRequest.getParameter("fwd_rate_r"+lNumRec));
        if ( inRequest.getParameter("fut_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.fut_rate = 0;
        else
        if ( inRequest.getParameter("fut_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.fut_rate = 0;
        else
          outCxSymbolDailyTabObj.fut_rate = Double.parseDouble( inRequest.getParameter("fut_rate_r"+lNumRec));
        if ( inRequest.getParameter("spot_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.spot_rate = 0;
        else
        if ( inRequest.getParameter("spot_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.spot_rate = 0;
        else
          outCxSymbolDailyTabObj.spot_rate = Double.parseDouble( inRequest.getParameter("spot_rate_r"+lNumRec));
        if ( inRequest.getParameter("ltp_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.ltp = 0;
        else
        if ( inRequest.getParameter("ltp_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.ltp = 0;
        else
          outCxSymbolDailyTabObj.ltp = Double.parseDouble( inRequest.getParameter("ltp_r"+lNumRec));
        outCxSymbolDailyTabObj.ltp_date = inRequest.getParameter("ltp_date_r"+lNumRec);
        outCxSymbolDailyTabObj.ltp_time = inRequest.getParameter("ltp_time_r"+lNumRec);
        outCxSymbolDailyTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
        outCxSymbolDailyTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
        if ( inRequest.getParameter("net_change_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.net_change = 0;
        else
        if ( inRequest.getParameter("net_change_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.net_change = 0;
        else
          outCxSymbolDailyTabObj.net_change = Double.parseDouble( inRequest.getParameter("net_change_r"+lNumRec));
        if ( inRequest.getParameter("percent_change_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.percent_change = 0;
        else
        if ( inRequest.getParameter("percent_change_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.percent_change = 0;
        else
          outCxSymbolDailyTabObj.percent_change = Float.parseFloat( inRequest.getParameter("percent_change_r"+lNumRec));
        if ( inRequest.getParameter("high_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.high = 0;
        else
        if ( inRequest.getParameter("high_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.high = 0;
        else
          outCxSymbolDailyTabObj.high = Double.parseDouble( inRequest.getParameter("high_r"+lNumRec));
        if ( inRequest.getParameter("low_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.low = 0;
        else
        if ( inRequest.getParameter("low_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.low = 0;
        else
          outCxSymbolDailyTabObj.low = Double.parseDouble( inRequest.getParameter("low_r"+lNumRec));
        if ( inRequest.getParameter("bbr_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.bbr = 0;
        else
        if ( inRequest.getParameter("bbr_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.bbr = 0;
        else
          outCxSymbolDailyTabObj.bbr = Double.parseDouble( inRequest.getParameter("bbr_r"+lNumRec));
        if ( inRequest.getParameter("bbq_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.bbq = 0;
        else
        if ( inRequest.getParameter("bbq_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.bbq = 0;
        else
          outCxSymbolDailyTabObj.bbq = Integer.parseInt( inRequest.getParameter("bbq_r"+lNumRec));
        if ( inRequest.getParameter("bsr_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.bsr = 0;
        else
        if ( inRequest.getParameter("bsr_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.bsr = 0;
        else
          outCxSymbolDailyTabObj.bsr = Double.parseDouble( inRequest.getParameter("bsr_r"+lNumRec));
        if ( inRequest.getParameter("bsq_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.bsq = 0;
        else
        if ( inRequest.getParameter("bsq_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.bsq = 0;
        else
          outCxSymbolDailyTabObj.bsq = Integer.parseInt( inRequest.getParameter("bsq_r"+lNumRec));
        if ( inRequest.getParameter("open_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.open_rate = 0;
        else
        if ( inRequest.getParameter("open_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.open_rate = 0;
        else
          outCxSymbolDailyTabObj.open_rate = Double.parseDouble( inRequest.getParameter("open_rate_r"+lNumRec));
        if ( inRequest.getParameter("close_rate_r"+lNumRec) == null )
          outCxSymbolDailyTabObj.close_rate = 0;
        else
        if ( inRequest.getParameter("close_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolDailyTabObj.close_rate = 0;
        else
          outCxSymbolDailyTabObj.close_rate = Double.parseDouble( inRequest.getParameter("close_rate_r"+lNumRec));
      }
    }
    return lReturnValue;
  }


  public int popCxSymbolDailyReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxSymbolDailyTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxSymbolDailyTabObj lCxSymbolDailyTabObj= new CxSymbolDailyTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_symbol_daily_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxSymbolDailyTabObj.tab_rowid = lTabRowidValue;

        lCxSymbolDailyTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxSymbolDailyTabObj.curr_date = inRequest.getParameter("curr_date_r"+lNumRec);
        lCxSymbolDailyTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        lCxSymbolDailyTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        lCxSymbolDailyTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
        lCxSymbolDailyTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxSymbolDailyTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxSymbolDailyTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxSymbolDailyTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxSymbolDailyTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lCxSymbolDailyTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
        lCxSymbolDailyTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
        lCxSymbolDailyTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
        lCxSymbolDailyTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
        if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.exp_rate = 0;
        else
        if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.exp_rate = 0;
        else
            lCxSymbolDailyTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
        if ( inRequest.getParameter("fwd_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.fwd_rate = 0;
        else
        if ( inRequest.getParameter("fwd_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.fwd_rate = 0;
        else
            lCxSymbolDailyTabObj.fwd_rate = Double.parseDouble( inRequest.getParameter("fwd_rate_r"+lNumRec));
        if ( inRequest.getParameter("fut_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.fut_rate = 0;
        else
        if ( inRequest.getParameter("fut_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.fut_rate = 0;
        else
            lCxSymbolDailyTabObj.fut_rate = Double.parseDouble( inRequest.getParameter("fut_rate_r"+lNumRec));
        if ( inRequest.getParameter("spot_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.spot_rate = 0;
        else
        if ( inRequest.getParameter("spot_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.spot_rate = 0;
        else
            lCxSymbolDailyTabObj.spot_rate = Double.parseDouble( inRequest.getParameter("spot_rate_r"+lNumRec));
        if ( inRequest.getParameter("ltp_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.ltp = 0;
        else
        if ( inRequest.getParameter("ltp_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.ltp = 0;
        else
            lCxSymbolDailyTabObj.ltp = Double.parseDouble( inRequest.getParameter("ltp_r"+lNumRec));
        lCxSymbolDailyTabObj.ltp_date = inRequest.getParameter("ltp_date_r"+lNumRec);
        lCxSymbolDailyTabObj.ltp_time = inRequest.getParameter("ltp_time_r"+lNumRec);
        lCxSymbolDailyTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
        lCxSymbolDailyTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
        if ( inRequest.getParameter("net_change_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.net_change = 0;
        else
        if ( inRequest.getParameter("net_change_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.net_change = 0;
        else
            lCxSymbolDailyTabObj.net_change = Double.parseDouble( inRequest.getParameter("net_change_r"+lNumRec));
        if ( inRequest.getParameter("percent_change_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.percent_change = 0;
        else
        if ( inRequest.getParameter("percent_change_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.percent_change = 0;
        else
            lCxSymbolDailyTabObj.percent_change = Float.parseFloat( inRequest.getParameter("percent_change_r"+lNumRec));
        if ( inRequest.getParameter("high_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.high = 0;
        else
        if ( inRequest.getParameter("high_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.high = 0;
        else
            lCxSymbolDailyTabObj.high = Double.parseDouble( inRequest.getParameter("high_r"+lNumRec));
        if ( inRequest.getParameter("low_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.low = 0;
        else
        if ( inRequest.getParameter("low_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.low = 0;
        else
            lCxSymbolDailyTabObj.low = Double.parseDouble( inRequest.getParameter("low_r"+lNumRec));
        if ( inRequest.getParameter("bbr_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.bbr = 0;
        else
        if ( inRequest.getParameter("bbr_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.bbr = 0;
        else
            lCxSymbolDailyTabObj.bbr = Double.parseDouble( inRequest.getParameter("bbr_r"+lNumRec));
        if ( inRequest.getParameter("bbq_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.bbq = 0;
        else
        if ( inRequest.getParameter("bbq_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.bbq = 0;
        else
          lCxSymbolDailyTabObj.bbq = Integer.parseInt( inRequest.getParameter("bbq_r"+lNumRec));
        if ( inRequest.getParameter("bsr_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.bsr = 0;
        else
        if ( inRequest.getParameter("bsr_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.bsr = 0;
        else
            lCxSymbolDailyTabObj.bsr = Double.parseDouble( inRequest.getParameter("bsr_r"+lNumRec));
        if ( inRequest.getParameter("bsq_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.bsq = 0;
        else
        if ( inRequest.getParameter("bsq_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.bsq = 0;
        else
          lCxSymbolDailyTabObj.bsq = Integer.parseInt( inRequest.getParameter("bsq_r"+lNumRec));
        if ( inRequest.getParameter("open_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.open_rate = 0;
        else
        if ( inRequest.getParameter("open_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.open_rate = 0;
        else
            lCxSymbolDailyTabObj.open_rate = Double.parseDouble( inRequest.getParameter("open_rate_r"+lNumRec));
        if ( inRequest.getParameter("close_rate_r"+lNumRec) == null )
          lCxSymbolDailyTabObj.close_rate = 0;
        else
        if ( inRequest.getParameter("close_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolDailyTabObj.close_rate = 0;
        else
            lCxSymbolDailyTabObj.close_rate = Double.parseDouble( inRequest.getParameter("close_rate_r"+lNumRec));
        outCxSymbolDailyTabObjArr.add( lCxSymbolDailyTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolDailyRecByRowid
               ( String inRowId
               , CxSymbolDailyTabObj  inCxSymbolDailyTabObj
               )
  {
    int lUpdateCount;
    sop("updCxSymbolDailyRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolDailyRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolDailyTabObj.curr_date != null && inCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            inCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.curr_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_cre_date != null && inCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_upd_date != null && inCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.eff_date != null && inCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            inCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.exp_date != null && inCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.ltp_date != null && inCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.ltp_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_DAILY ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxSymbolDailyTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxSymbolDailyTabObj.org_id+"', ";
      if ( inCxSymbolDailyTabObj.curr_date != null  )         lSqlStmt = lSqlStmt + "curr_date = "+"'"+inCxSymbolDailyTabObj.curr_date+"', ";
      if ( inCxSymbolDailyTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxSymbolDailyTabObj.contract_id+"', ";
      if ( inCxSymbolDailyTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxSymbolDailyTabObj.symbol_cd+"', ";
      if ( inCxSymbolDailyTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = "+"'"+inCxSymbolDailyTabObj.symbol_name+"', ";
      if ( inCxSymbolDailyTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxSymbolDailyTabObj.status+"', ";
      if ( inCxSymbolDailyTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxSymbolDailyTabObj.rec_cre_date+"', ";
      if ( inCxSymbolDailyTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxSymbolDailyTabObj.rec_cre_time+"', ";
      if ( inCxSymbolDailyTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxSymbolDailyTabObj.rec_upd_date+"', ";
      if ( inCxSymbolDailyTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxSymbolDailyTabObj.rec_upd_time+"', ";
      if ( inCxSymbolDailyTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = "+"'"+inCxSymbolDailyTabObj.eff_date+"', ";
      if ( inCxSymbolDailyTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = "+"'"+inCxSymbolDailyTabObj.eff_time+"', ";
      if ( inCxSymbolDailyTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = "+"'"+inCxSymbolDailyTabObj.exp_date+"', ";
      if ( inCxSymbolDailyTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = "+"'"+inCxSymbolDailyTabObj.exp_time+"', ";
             lSqlStmt = lSqlStmt + "exp_rate = "+inCxSymbolDailyTabObj.exp_rate+", ";
             lSqlStmt = lSqlStmt + "fwd_rate = "+inCxSymbolDailyTabObj.fwd_rate+", ";
             lSqlStmt = lSqlStmt + "fut_rate = "+inCxSymbolDailyTabObj.fut_rate+", ";
             lSqlStmt = lSqlStmt + "spot_rate = "+inCxSymbolDailyTabObj.spot_rate+", ";
             lSqlStmt = lSqlStmt + "ltp = "+inCxSymbolDailyTabObj.ltp+", ";
      if ( inCxSymbolDailyTabObj.ltp_date != null  )         lSqlStmt = lSqlStmt + "ltp_date = "+"'"+inCxSymbolDailyTabObj.ltp_date+"', ";
      if ( inCxSymbolDailyTabObj.ltp_time != null  )         lSqlStmt = lSqlStmt + "ltp_time = "+"'"+inCxSymbolDailyTabObj.ltp_time+"', ";
      if ( inCxSymbolDailyTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = "+"'"+inCxSymbolDailyTabObj.rate_currency+"', ";
      if ( inCxSymbolDailyTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = "+"'"+inCxSymbolDailyTabObj.rate_per_uom+"', ";
             lSqlStmt = lSqlStmt + "net_change = "+inCxSymbolDailyTabObj.net_change+", ";
             lSqlStmt = lSqlStmt + "percent_change = "+inCxSymbolDailyTabObj.percent_change+", ";
             lSqlStmt = lSqlStmt + "high = "+inCxSymbolDailyTabObj.high+", ";
             lSqlStmt = lSqlStmt + "low = "+inCxSymbolDailyTabObj.low+", ";
             lSqlStmt = lSqlStmt + "bbr = "+inCxSymbolDailyTabObj.bbr+", ";
             lSqlStmt = lSqlStmt + "bbq = "+inCxSymbolDailyTabObj.bbq+", ";
             lSqlStmt = lSqlStmt + "bsr = "+inCxSymbolDailyTabObj.bsr+", ";
             lSqlStmt = lSqlStmt + "bsq = "+inCxSymbolDailyTabObj.bsq+", ";
             lSqlStmt = lSqlStmt + "open_rate = "+inCxSymbolDailyTabObj.open_rate+", ";
             lSqlStmt = lSqlStmt + "close_rate = "+inCxSymbolDailyTabObj.close_rate+", ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolDailyRecByPkey
               ( CxSymbolDailyPkeyObj inCxSymbolDailyPkeyObj
               , CxSymbolDailyTabObj  inCxSymbolDailyTabObj
               )
  {
    int lUpdateCount;
    sop("updCxSymbolDailyRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolDailyRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolDailyTabObj.curr_date != null && inCxSymbolDailyTabObj.curr_date.length() > 0 ) 
            inCxSymbolDailyTabObj.curr_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.curr_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_cre_date != null && inCxSymbolDailyTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.rec_upd_date != null && inCxSymbolDailyTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolDailyTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.eff_date != null && inCxSymbolDailyTabObj.eff_date.length() > 0 ) 
            inCxSymbolDailyTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.exp_date != null && inCxSymbolDailyTabObj.exp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolDailyTabObj.ltp_date != null && inCxSymbolDailyTabObj.ltp_date.length() > 0 ) 
            inCxSymbolDailyTabObj.ltp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolDailyTabObj.ltp_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_DAILY ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxSymbolDailyTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxSymbolDailyTabObj.curr_date != null  )         lSqlStmt = lSqlStmt + "curr_date = ? , ";
        if ( inCxSymbolDailyTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = ? , ";
        if ( inCxSymbolDailyTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = ? , ";
        if ( inCxSymbolDailyTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = ? , ";
        if ( inCxSymbolDailyTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxSymbolDailyTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxSymbolDailyTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxSymbolDailyTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxSymbolDailyTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inCxSymbolDailyTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = ? , ";
        if ( inCxSymbolDailyTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = ? , ";
        if ( inCxSymbolDailyTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = ? , ";
        if ( inCxSymbolDailyTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = ? , ";
               lSqlStmt = lSqlStmt + "exp_rate = ? , ";
               lSqlStmt = lSqlStmt + "fwd_rate = ? , ";
               lSqlStmt = lSqlStmt + "fut_rate = ? , ";
               lSqlStmt = lSqlStmt + "spot_rate = ? , ";
               lSqlStmt = lSqlStmt + "ltp = ? , ";
        if ( inCxSymbolDailyTabObj.ltp_date != null  )         lSqlStmt = lSqlStmt + "ltp_date = ? , ";
        if ( inCxSymbolDailyTabObj.ltp_time != null  )         lSqlStmt = lSqlStmt + "ltp_time = ? , ";
        if ( inCxSymbolDailyTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = ? , ";
        if ( inCxSymbolDailyTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = ? , ";
               lSqlStmt = lSqlStmt + "net_change = ? , ";
               lSqlStmt = lSqlStmt + "percent_change = ? , ";
               lSqlStmt = lSqlStmt + "high = ? , ";
               lSqlStmt = lSqlStmt + "low = ? , ";
               lSqlStmt = lSqlStmt + "bbr = ? , ";
               lSqlStmt = lSqlStmt + "bbq = ? , ";
               lSqlStmt = lSqlStmt + "bsr = ? , ";
               lSqlStmt = lSqlStmt + "bsq = ? , ";
               lSqlStmt = lSqlStmt + "open_rate = ? , ";
               lSqlStmt = lSqlStmt + "close_rate = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxSymbolDailyTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxSymbolDailyTabObj.org_id+"', ";
        if ( inCxSymbolDailyTabObj.curr_date != null  )         lSqlStmt = lSqlStmt + "curr_date = "+"'"+inCxSymbolDailyTabObj.curr_date+"', ";
        if ( inCxSymbolDailyTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxSymbolDailyTabObj.contract_id+"', ";
        if ( inCxSymbolDailyTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxSymbolDailyTabObj.symbol_cd+"', ";
        if ( inCxSymbolDailyTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = "+"'"+inCxSymbolDailyTabObj.symbol_name+"', ";
        if ( inCxSymbolDailyTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxSymbolDailyTabObj.status+"', ";
        if ( inCxSymbolDailyTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxSymbolDailyTabObj.rec_cre_date+"', ";
        if ( inCxSymbolDailyTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxSymbolDailyTabObj.rec_cre_time+"', ";
        if ( inCxSymbolDailyTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxSymbolDailyTabObj.rec_upd_date+"', ";
        if ( inCxSymbolDailyTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxSymbolDailyTabObj.rec_upd_time+"', ";
        if ( inCxSymbolDailyTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = "+"'"+inCxSymbolDailyTabObj.eff_date+"', ";
        if ( inCxSymbolDailyTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = "+"'"+inCxSymbolDailyTabObj.eff_time+"', ";
        if ( inCxSymbolDailyTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = "+"'"+inCxSymbolDailyTabObj.exp_date+"', ";
        if ( inCxSymbolDailyTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = "+"'"+inCxSymbolDailyTabObj.exp_time+"', ";
               lSqlStmt = lSqlStmt + "exp_rate = "+inCxSymbolDailyTabObj.exp_rate+", ";
               lSqlStmt = lSqlStmt + "fwd_rate = "+inCxSymbolDailyTabObj.fwd_rate+", ";
               lSqlStmt = lSqlStmt + "fut_rate = "+inCxSymbolDailyTabObj.fut_rate+", ";
               lSqlStmt = lSqlStmt + "spot_rate = "+inCxSymbolDailyTabObj.spot_rate+", ";
               lSqlStmt = lSqlStmt + "ltp = "+inCxSymbolDailyTabObj.ltp+", ";
        if ( inCxSymbolDailyTabObj.ltp_date != null  )         lSqlStmt = lSqlStmt + "ltp_date = "+"'"+inCxSymbolDailyTabObj.ltp_date+"', ";
        if ( inCxSymbolDailyTabObj.ltp_time != null  )         lSqlStmt = lSqlStmt + "ltp_time = "+"'"+inCxSymbolDailyTabObj.ltp_time+"', ";
        if ( inCxSymbolDailyTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = "+"'"+inCxSymbolDailyTabObj.rate_currency+"', ";
        if ( inCxSymbolDailyTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = "+"'"+inCxSymbolDailyTabObj.rate_per_uom+"', ";
               lSqlStmt = lSqlStmt + "net_change = "+inCxSymbolDailyTabObj.net_change+", ";
               lSqlStmt = lSqlStmt + "percent_change = "+inCxSymbolDailyTabObj.percent_change+", ";
               lSqlStmt = lSqlStmt + "high = "+inCxSymbolDailyTabObj.high+", ";
               lSqlStmt = lSqlStmt + "low = "+inCxSymbolDailyTabObj.low+", ";
               lSqlStmt = lSqlStmt + "bbr = "+inCxSymbolDailyTabObj.bbr+", ";
               lSqlStmt = lSqlStmt + "bbq = "+inCxSymbolDailyTabObj.bbq+", ";
               lSqlStmt = lSqlStmt + "bsr = "+inCxSymbolDailyTabObj.bsr+", ";
               lSqlStmt = lSqlStmt + "bsq = "+inCxSymbolDailyTabObj.bsq+", ";
               lSqlStmt = lSqlStmt + "open_rate = "+inCxSymbolDailyTabObj.open_rate+", ";
               lSqlStmt = lSqlStmt + "close_rate = "+inCxSymbolDailyTabObj.close_rate+", ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolDailyPkeyObj.org_id+"' and "+
                              "curr_date = "+"'"+inCxSymbolDailyPkeyObj.curr_date+"' and "+
                              "contract_id = "+"'"+inCxSymbolDailyPkeyObj.contract_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxSymbolDailyTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.org_id); } 
         if ( inCxSymbolDailyTabObj.curr_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.curr_date); } 
         if ( inCxSymbolDailyTabObj.contract_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.contract_id); } 
         if ( inCxSymbolDailyTabObj.symbol_cd != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.symbol_cd); } 
         if ( inCxSymbolDailyTabObj.symbol_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.symbol_name); } 
         if ( inCxSymbolDailyTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.status); } 
         if ( inCxSymbolDailyTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rec_cre_date); } 
         if ( inCxSymbolDailyTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rec_cre_time); } 
         if ( inCxSymbolDailyTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rec_upd_date); } 
         if ( inCxSymbolDailyTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rec_upd_time); } 
         if ( inCxSymbolDailyTabObj.eff_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.eff_date); } 
         if ( inCxSymbolDailyTabObj.eff_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.eff_time); } 
         if ( inCxSymbolDailyTabObj.exp_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.exp_date); } 
         if ( inCxSymbolDailyTabObj.exp_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.exp_time); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(15, inCxSymbolDailyTabObj.exp_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(16, inCxSymbolDailyTabObj.fwd_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(17, inCxSymbolDailyTabObj.fut_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(18, inCxSymbolDailyTabObj.spot_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(19, inCxSymbolDailyTabObj.ltp);
         if ( inCxSymbolDailyTabObj.ltp_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.ltp_date); } 
         if ( inCxSymbolDailyTabObj.ltp_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.ltp_time); } 
         if ( inCxSymbolDailyTabObj.rate_currency != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rate_currency); } 
         if ( inCxSymbolDailyTabObj.rate_per_uom != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolDailyTabObj.rate_per_uom); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(24, inCxSymbolDailyTabObj.net_change);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(25, inCxSymbolDailyTabObj.percent_change);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(26, inCxSymbolDailyTabObj.high);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(27, inCxSymbolDailyTabObj.low);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(28, inCxSymbolDailyTabObj.bbr);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(29, inCxSymbolDailyTabObj.bbq);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(30, inCxSymbolDailyTabObj.bsr);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(31, inCxSymbolDailyTabObj.bsq);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(32, inCxSymbolDailyTabObj.open_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(33, inCxSymbolDailyTabObj.close_rate);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolDailyRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxSymbolDailyRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolDailyRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_SYMBOL_DAILY "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolDailyRecByPkeyWithSet
               ( CxSymbolDailyPkeyObj inCxSymbolDailyPkeyObj
               , String  inCxSymbolDailySetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolDailyRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolDailyRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_DAILY ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxSymbolDailySetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolDailyPkeyObj.org_id+"' and "+
                              "curr_date = "+"'"+inCxSymbolDailyPkeyObj.curr_date+"' and "+
                              "contract_id = "+"'"+inCxSymbolDailyPkeyObj.contract_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolDailyRecByRowidWithSet
               ( String inRowId
               , String  inCxSymbolDailySetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolDailyRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolDailyRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_DAILY ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxSymbolDailySetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolDailyRecByWhereWithSet
               ( String inCxSymbolDailyWhereText
               , String  inCxSymbolDailySetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolDailyRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolDailyRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_DAILY ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxSymbolDailySetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolDailyRecByPkey
               ( CxSymbolDailyPkeyObj  inCxSymbolDailyPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxSymbolDailyRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolDailyRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_SYMBOL_DAILY " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolDailyPkeyObj.org_id+"' and "+
                              "curr_date = "+"'"+inCxSymbolDailyPkeyObj.curr_date+"' and "+
                              "contract_id = "+"'"+inCxSymbolDailyPkeyObj.contract_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolDailyByWhere
               ( String inCxSymbolDailyWhereText
               )
  {
    int lUpdateCount;
    sop("delCxSymbolDailyByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolDailyByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolDailyWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolDailyWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_SYMBOL_DAILY "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
