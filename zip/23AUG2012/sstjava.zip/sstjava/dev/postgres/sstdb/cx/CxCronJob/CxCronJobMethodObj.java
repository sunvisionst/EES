package sstdb.cx.CxCronJob;

import sstdb.cx.CxCronJob.CxCronJobTabObj;
import sstdb.cx.CxCronJob.CxCronJobPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxCronJobMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxCronJobMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxCronJobMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxCronJobTabObj
               ( 
                 CxCronJobTabObj  outCxCronJobTabObj
               )
  {
  
     outCxCronJobTabObj.org_id = ""; 
     outCxCronJobTabObj.job_num = ""; 
     outCxCronJobTabObj.sch_date = ""; 
     outCxCronJobTabObj.sch_time = ""; 
     outCxCronJobTabObj.alert_type = ""; 
     outCxCronJobTabObj.contact_num_1 = ""; 
     outCxCronJobTabObj.email_id = ""; 
     outCxCronJobTabObj.status = ""; 
     outCxCronJobTabObj.rec_cre_by = ""; 
     outCxCronJobTabObj.rec_cre_date = ""; 
     outCxCronJobTabObj.rec_cre_time = ""; 
     outCxCronJobTabObj.rec_upd_by = ""; 
     outCxCronJobTabObj.rec_upd_date = ""; 
     outCxCronJobTabObj.rec_upd_time = ""; 
  }





  public void guiDateConvCxCronJobTabObj
               ( 
                 CxCronJobTabObj  inCxCronJobTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxCronJobTabObj.sch_date != null && inCxCronJobTabObj.sch_date.length() > 0 ) 
            inCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxCronJobTabObj.sch_date, lDateTimeTrgFmt);

          if ( inCxCronJobTabObj.rec_cre_date != null && inCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            inCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxCronJobTabObj.rec_upd_date != null && inCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            inCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxCronJobByTabObj
               ( 
                 CxCronJobTabObj  inCxCronJobTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxCronJobTabObjArrCtx  = new ArrayList(); 
    lCxCronJobTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxCronJobTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxCronJobTabObjArrCtx.add(inCxCronJobTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxCronJobTabObjArrCtx.size();  lRecNum++ )
      {
        CxCronJobTabObj lCxCronJobTabObj = new CxCronJobTabObj();
        lCxCronJobTabObj = (CxCronJobTabObj)lCxCronJobTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxCronJobTabObj.org_id.equals(lCxCronJobTabObj.org_id) &&
              lCxCronJobTabObj.job_num.equals(lCxCronJobTabObj.job_num) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxCronJobTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxCronJobTabObjArrCtx.set(lRecNum, inCxCronJobTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxCronJobTabObjArrCtx",lCxCronJobTabObjArrCtx);
  }





  public void sortCxCronJobTabObjArr
               ( 
                 ArrayList  inCxCronJobTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxCronJobTabObjArr  = new ArrayList(); 
     lCxCronJobTabObjArr = inCxCronJobTabObjArr; 
     List lCxCronJobTabObjList  = new ArrayList(lCxCronJobTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxCronJobTabObjArr.size();  lRecNum++ )
     {
       CxCronJobTabObj  lCxCronJobTabObj = new CxCronJobTabObj(); 
       lCxCronJobTabObj = (CxCronJobTabObj)lCxCronJobTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxCronJobTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("job_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxCronJobTabObj.job_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.job_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sch_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxCronJobTabObj.sch_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.sch_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sch_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxCronJobTabObj.sch_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.sch_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("alert_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxCronJobTabObj.alert_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.alert_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("contact_num_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lCxCronJobTabObj.contact_num_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.contact_num_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxCronJobTabObj.email_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.email_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxCronJobTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxCronJobTabObj.rec_cre_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_cre_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxCronJobTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxCronJobTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxCronJobTabObj.rec_upd_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_upd_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxCronJobTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxCronJobTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxCronJobTabObj.rec_upd_time+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxCronJobTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxCronJobTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxCronJobTabObjList ); 
     ArrayList lCxCronJobTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxCronJobTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxCronJobTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxCronJobTabObjArrSorted.add( (CxCronJobTabObj)lCxCronJobTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxCronJobTabObjArr.size();  lRecNum++ )
     {
       inCxCronJobTabObjArr.set( lRecNum, (CxCronJobTabObj)lCxCronJobTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxCronJobTabObj
               ( 
                 CxCronJobTabObj  inCxCronJobTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxCronJobTabObj.sch_date != null && inCxCronJobTabObj.sch_date.length() > 0 ) 
            inCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.sch_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_cre_date != null && inCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            inCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_upd_date != null && inCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            inCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeJobNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "JOB_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSchDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SCH_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSchTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SCH_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAlertType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALERT_TYPE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeContactNum1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CONTACT_NUM_1";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_BY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_BY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxCronJobCount
               ( String inCxCronJobWhereText
               )
  {
    sop("gtCxCronJobCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobCount
               ( String inCxCronJobWhereText
               , String inCxCronJobSelectFieldList
               )
  {
    sop("gtCxCronJobCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxCronJobSelectFieldList+" AS count "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobRecByPkey
               ( CxCronJobPkeyObj inCxCronJobPkeyObj
               , CxCronJobTabObj  outCxCronJobTabObj
               )
  {
    sop("gtCxCronJobRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "job_num, "+
                                 "sch_date, "+
                                 "sch_time, "+
                                 "alert_type, "+
                                 "contact_num_1, "+
                                 "email_id, "+
                                 "status, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_CRON_JOB " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxCronJobPkeyObj.org_id+"' and "+
                              "job_num = "+"'"+inCxCronJobPkeyObj.job_num+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxCronJobTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxCronJobTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxCronJobTabObj.job_num  =  lResultSet.getString("JOB_NUM");
          outCxCronJobTabObj.sch_date  =  lResultSet.getString("SCH_DATE");

          if ( outCxCronJobTabObj.sch_date != null && outCxCronJobTabObj.sch_date.length() > 0 ) 
            outCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.sch_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.sch_time  =  lResultSet.getString("SCH_TIME");
          outCxCronJobTabObj.alert_type  =  lResultSet.getString("ALERT_TYPE");
          outCxCronJobTabObj.contact_num_1  =  lResultSet.getString("CONTACT_NUM_1");
          outCxCronJobTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outCxCronJobTabObj.status  =  lResultSet.getString("STATUS");
          outCxCronJobTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          outCxCronJobTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxCronJobTabObj.rec_cre_date != null && outCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            outCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxCronJobTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          outCxCronJobTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxCronJobTabObj.rec_upd_date != null && outCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            outCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxCronJobTabObj( outCxCronJobTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobArr
               ( CxCronJobPkeyObj inCxCronJobPkeyObj
               , ArrayList  outCxCronJobTabObjArr
               )
  {
    sop("gtCxCronJobArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "job_num, "+
                                 "sch_date, "+
                                 "sch_time, "+
                                 "alert_type, "+
                                 "contact_num_1, "+
                                 "email_id, "+
                                 "status, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_CRON_JOB";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxCronJobTabObj  lCxCronJobTabObj = new CxCronJobTabObj();
          lCxCronJobTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxCronJobTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxCronJobTabObj.job_num  =  lResultSet.getString("JOB_NUM");
          lCxCronJobTabObj.sch_date  =  lResultSet.getString("SCH_DATE");

          if ( lCxCronJobTabObj.sch_date != null && lCxCronJobTabObj.sch_date.length() > 0 ) 
            lCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.sch_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.sch_time  =  lResultSet.getString("SCH_TIME");
          lCxCronJobTabObj.alert_type  =  lResultSet.getString("ALERT_TYPE");
          lCxCronJobTabObj.contact_num_1  =  lResultSet.getString("CONTACT_NUM_1");
          lCxCronJobTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lCxCronJobTabObj.status  =  lResultSet.getString("STATUS");
          lCxCronJobTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          lCxCronJobTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxCronJobTabObj.rec_cre_date != null && lCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            lCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxCronJobTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          lCxCronJobTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxCronJobTabObj.rec_upd_date != null && lCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            lCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxCronJobTabObj( lCxCronJobTabObj );

          outCxCronJobTabObjArr.add(  lCxCronJobTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxCronJobTabObjArr != null && outCxCronJobTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxCronJobArr2XML
               ( String inCxCronJobWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxCronJobArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxCronJob>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("job_num") )
              lXmlBuffer = lXmlBuffer +   "<JOB_NUM>" +  lResultSet.getString("JOB_NUM") +   "</JOB_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sch_date") )
              lXmlBuffer = lXmlBuffer +   "<SCH_DATE>" +  lResultSet.getString("SCH_DATE") +   "</SCH_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sch_time") )
              lXmlBuffer = lXmlBuffer +   "<SCH_TIME>" +  lResultSet.getString("SCH_TIME") +   "</SCH_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("alert_type") )
              lXmlBuffer = lXmlBuffer +   "<ALERT_TYPE>" +  lResultSet.getString("ALERT_TYPE") +   "</ALERT_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("contact_num_1") )
              lXmlBuffer = lXmlBuffer +   "<CONTACT_NUM_1>" +  lResultSet.getString("CONTACT_NUM_1") +   "</CONTACT_NUM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_id") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_ID>" +  lResultSet.getString("EMAIL_ID") +   "</EMAIL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_by") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_BY>" +  lResultSet.getString("REC_CRE_BY") +   "</REC_CRE_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_by") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_BY>" +  lResultSet.getString("REC_UPD_BY") +   "</REC_UPD_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxCronJob>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxCronJobRecByRowid
               ( String inRowId
               , CxCronJobTabObj  outCxCronJobTabObj
               )
  {
    sop("gtCxCronJobRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "job_num, "+
                                 "sch_date, "+
                                 "sch_time, "+
                                 "alert_type, "+
                                 "contact_num_1, "+
                                 "email_id, "+
                                 "status, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_CRON_JOB "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxCronJobTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxCronJobTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxCronJobTabObj.job_num  =  lResultSet.getString("JOB_NUM");
          outCxCronJobTabObj.sch_date  =  lResultSet.getString("SCH_DATE");

          if ( outCxCronJobTabObj.sch_date != null && outCxCronJobTabObj.sch_date.length() > 0 ) 
            outCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.sch_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.sch_time  =  lResultSet.getString("SCH_TIME");
          outCxCronJobTabObj.alert_type  =  lResultSet.getString("ALERT_TYPE");
          outCxCronJobTabObj.contact_num_1  =  lResultSet.getString("CONTACT_NUM_1");
          outCxCronJobTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outCxCronJobTabObj.status  =  lResultSet.getString("STATUS");
          outCxCronJobTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          outCxCronJobTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxCronJobTabObj.rec_cre_date != null && outCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            outCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxCronJobTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          outCxCronJobTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxCronJobTabObj.rec_upd_date != null && outCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            outCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxCronJobTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxCronJobTabObj( outCxCronJobTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobArr
               ( String inCxCronJobWhereText
               , ArrayList  outCxCronJobTabObjArr
               )
  {
    sop("gtCxCronJobArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "job_num, "+
                                 "sch_date, "+
                                 "sch_time, "+
                                 "alert_type, "+
                                 "contact_num_1, "+
                                 "email_id, "+
                                 "status, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxCronJobTabObj  lCxCronJobTabObj = new CxCronJobTabObj();
          lCxCronJobTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxCronJobTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxCronJobTabObj.job_num  =  lResultSet.getString("JOB_NUM");
          lCxCronJobTabObj.sch_date  =  lResultSet.getString("SCH_DATE");

          if ( lCxCronJobTabObj.sch_date != null && lCxCronJobTabObj.sch_date.length() > 0 ) 
            lCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.sch_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.sch_time  =  lResultSet.getString("SCH_TIME");
          lCxCronJobTabObj.alert_type  =  lResultSet.getString("ALERT_TYPE");
          lCxCronJobTabObj.contact_num_1  =  lResultSet.getString("CONTACT_NUM_1");
          lCxCronJobTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lCxCronJobTabObj.status  =  lResultSet.getString("STATUS");
          lCxCronJobTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          lCxCronJobTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxCronJobTabObj.rec_cre_date != null && lCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            lCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxCronJobTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          lCxCronJobTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxCronJobTabObj.rec_upd_date != null && lCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            lCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxCronJobTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxCronJobTabObj( lCxCronJobTabObj );

          outCxCronJobTabObjArr.add(  lCxCronJobTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxCronJobTabObjArr != null && outCxCronJobTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobArrDist
               ( String inCxCronJobWhereText
               , String inDistCxCronJobField
               , ArrayList  outCxCronJobTabObjArr
               )
  {

    sop("gtCxCronJobArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";
  

       String lDistCxCronJobFieldQry = inDistCxCronJobField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxCronJobFieldQry+
                         " FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxCronJobField.substring(inDistCxCronJobField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxCronJobTabObj  lCxCronJobTabObj = new CxCronJobTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxCronJobTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("job_num") )
              lCxCronJobTabObj.job_num  =  lResultSet.getString("JOB_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sch_date") )
              {
              lCxCronJobTabObj.sch_date  =  lResultSet.getString("SCH_DATE");
  
          if ( lCxCronJobTabObj.sch_date != null && lCxCronJobTabObj.sch_date.length() > 0 ) 
            lCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.sch_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sch_time") )
              lCxCronJobTabObj.sch_time  =  lResultSet.getString("SCH_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("alert_type") )
              lCxCronJobTabObj.alert_type  =  lResultSet.getString("ALERT_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("contact_num_1") )
              lCxCronJobTabObj.contact_num_1  =  lResultSet.getString("CONTACT_NUM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_id") )
              lCxCronJobTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxCronJobTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_by") )
              lCxCronJobTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxCronJobTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxCronJobTabObj.rec_cre_date != null && lCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            lCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxCronJobTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_by") )
              lCxCronJobTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxCronJobTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxCronJobTabObj.rec_upd_date != null && lCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            lCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxCronJobTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxCronJobTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          }
          removeNullCxCronJobTabObj( lCxCronJobTabObj );

          outCxCronJobTabObjArr.add(  lCxCronJobTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxCronJobTabObjArr != null && outCxCronJobTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxCronJobStrArrDist
               ( String inCxCronJobWhereText
               , String inDistCxCronJobField
               , ArrayList  outCxCronJobTabObjArr
               )
  {

    sop("gtCxCronJobStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxCronJobStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";
  

       String lDistCxCronJobFieldQry = inDistCxCronJobField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxCronJobFieldQry+
                         " FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxCronJobField.substring(inDistCxCronJobField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxCronJobTabObjStr = "";
       while(lResultSet.next())
       {
          lCxCronJobTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxCronJobTabObjStr =   lCxCronJobTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxCronJobTabObjArr.add(  lCxCronJobTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxCronJobTabObjArr != null && outCxCronJobTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxCronJob
               ( String inCxCronJobWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxCronJob - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxCronJob";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxCronJobTabObj
               ( 
                 CxCronJobTabObj  outCxCronJobTabObj
               )
  {
  
    if ( outCxCronJobTabObj.org_id == null ) 
     outCxCronJobTabObj.org_id = ""; 
    if ( outCxCronJobTabObj.job_num == null ) 
     outCxCronJobTabObj.job_num = ""; 
    if ( outCxCronJobTabObj.sch_date == null ) 
     outCxCronJobTabObj.sch_date = ""; 
    if ( outCxCronJobTabObj.sch_time == null ) 
     outCxCronJobTabObj.sch_time = ""; 
    if ( outCxCronJobTabObj.alert_type == null ) 
     outCxCronJobTabObj.alert_type = ""; 
    if ( outCxCronJobTabObj.contact_num_1 == null ) 
     outCxCronJobTabObj.contact_num_1 = ""; 
    if ( outCxCronJobTabObj.email_id == null ) 
     outCxCronJobTabObj.email_id = ""; 
    if ( outCxCronJobTabObj.status == null ) 
     outCxCronJobTabObj.status = ""; 
    if ( outCxCronJobTabObj.rec_cre_by == null ) 
     outCxCronJobTabObj.rec_cre_by = ""; 
    if ( outCxCronJobTabObj.rec_cre_date == null ) 
     outCxCronJobTabObj.rec_cre_date = ""; 
    if ( outCxCronJobTabObj.rec_cre_time == null ) 
     outCxCronJobTabObj.rec_cre_time = ""; 
    if ( outCxCronJobTabObj.rec_upd_by == null ) 
     outCxCronJobTabObj.rec_upd_by = ""; 
    if ( outCxCronJobTabObj.rec_upd_date == null ) 
     outCxCronJobTabObj.rec_upd_date = ""; 
    if ( outCxCronJobTabObj.rec_upd_time == null ) 
     outCxCronJobTabObj.rec_upd_time = ""; 
  }





  public int insCxCronJobRec
               ( CxCronJobTabObj  inCxCronJobTabObj )
  {
    int lUpdateCount;
    sop("insCxCronJobRec - Started");
    gSSTErrorObj.sourceMethod = "insCxCronJobRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxCronJobTabObj.sch_date != null && inCxCronJobTabObj.sch_date.length() > 0 ) 
            inCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.sch_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_cre_date != null && inCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            inCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_upd_date != null && inCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            inCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_CRON_JOB"+
                        "("+
                                "org_id,"+
                                "job_num,"+
                                "sch_date,"+
                                "sch_time,"+
                                "alert_type,"+
                                "contact_num_1,"+
                                "email_id,"+
                                "status,"+
                                "rec_cre_by,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_by,"+
                                "rec_upd_date,"+
                                "rec_upd_time"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.job_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.sch_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.sch_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.alert_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.contact_num_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.email_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_cre_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_upd_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inCxCronJobTabObj.rec_upd_time+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxCronJobTabObj.org_id);
        lPreparedStatement.setString(2, inCxCronJobTabObj.job_num);
        lPreparedStatement.setString(3, inCxCronJobTabObj.sch_date);
        lPreparedStatement.setString(4, inCxCronJobTabObj.sch_time);
        lPreparedStatement.setString(5, inCxCronJobTabObj.alert_type);
        lPreparedStatement.setString(6, inCxCronJobTabObj.contact_num_1);
        lPreparedStatement.setString(7, inCxCronJobTabObj.email_id);
        lPreparedStatement.setString(8, inCxCronJobTabObj.status);
        lPreparedStatement.setString(9, inCxCronJobTabObj.rec_cre_by);
        lPreparedStatement.setString(10, inCxCronJobTabObj.rec_cre_date);
        lPreparedStatement.setString(11, inCxCronJobTabObj.rec_cre_time);
        lPreparedStatement.setString(12, inCxCronJobTabObj.rec_upd_by);
        lPreparedStatement.setString(13, inCxCronJobTabObj.rec_upd_date);
        lPreparedStatement.setString(14, inCxCronJobTabObj.rec_upd_time);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxCronJobArr
               ( ArrayList  inCxCronJobTabObjArr 
               , String  inRowidFlag )
  {
    CxCronJobTabObj  lCxCronJobTabObj = new CxCronJobTabObj();
    int lUpdateCount;
    sop("insCxCronJobArr - Started");
    gSSTErrorObj.sourceMethod = "insCxCronJobArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxCronJobTabObjArr.size(); lNumRec++ )
      {
        lCxCronJobTabObj = (CxCronJobTabObj)inCxCronJobTabObjArr.get(lNumRec);

          if ( lCxCronJobTabObj.sch_date != null && lCxCronJobTabObj.sch_date.length() > 0 ) 
            lCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxCronJobTabObj.sch_date, lDateTimeSrcFmt);

          if ( lCxCronJobTabObj.rec_cre_date != null && lCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            lCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxCronJobTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxCronJobTabObj.rec_upd_date != null && lCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            lCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxCronJobTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_CRON_JOB"+
                        "("+
                        "org_id,"+
                        "job_num,"+
                        "sch_date,"+
                        "sch_time,"+
                        "alert_type,"+
                        "contact_num_1,"+
                        "email_id,"+
                        "status,"+
                        "rec_cre_by,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_by,"+
                        "rec_upd_date,"+
                        "rec_upd_time"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.job_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.sch_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.sch_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.alert_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.contact_num_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.email_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_cre_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_upd_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lCxCronJobTabObj.rec_upd_time+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxCronJobTabObj.org_id);
            lPreparedStatement.setString(2, lCxCronJobTabObj.job_num);
            lPreparedStatement.setString(3, lCxCronJobTabObj.sch_date);
            lPreparedStatement.setString(4, lCxCronJobTabObj.sch_time);
            lPreparedStatement.setString(5, lCxCronJobTabObj.alert_type);
            lPreparedStatement.setString(6, lCxCronJobTabObj.contact_num_1);
            lPreparedStatement.setString(7, lCxCronJobTabObj.email_id);
            lPreparedStatement.setString(8, lCxCronJobTabObj.status);
            lPreparedStatement.setString(9, lCxCronJobTabObj.rec_cre_by);
            lPreparedStatement.setString(10, lCxCronJobTabObj.rec_cre_date);
            lPreparedStatement.setString(11, lCxCronJobTabObj.rec_cre_time);
            lPreparedStatement.setString(12, lCxCronJobTabObj.rec_upd_by);
            lPreparedStatement.setString(13, lCxCronJobTabObj.rec_upd_date);
            lPreparedStatement.setString(14, lCxCronJobTabObj.rec_upd_time);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxCronJobReq2Obj
               ( HttpServletRequest inRequest
               , CxCronJobTabObj  outCxCronJobTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxCronJobTabObj.tab_rowid = lTabRowidValue;

    outCxCronJobTabObj.org_id = inRequest.getParameter("org_id");
    outCxCronJobTabObj.job_num = inRequest.getParameter("job_num");
    outCxCronJobTabObj.sch_date = inRequest.getParameter("sch_date");
    outCxCronJobTabObj.sch_time = inRequest.getParameter("sch_time");
    outCxCronJobTabObj.alert_type = inRequest.getParameter("alert_type");
    outCxCronJobTabObj.contact_num_1 = inRequest.getParameter("contact_num_1");
    outCxCronJobTabObj.email_id = inRequest.getParameter("email_id");
    outCxCronJobTabObj.status = inRequest.getParameter("status");
    outCxCronJobTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by");
    outCxCronJobTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxCronJobTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxCronJobTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by");
    outCxCronJobTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxCronJobTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    return lReturnValue;
  }


  public int popCxCronJobReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxCronJobTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxCronJobTabObj lCxCronJobTabObj= new CxCronJobTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxCronJobTabObj.tab_rowid = lTabRowidValue;

      lCxCronJobTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxCronJobTabObj.job_num = inRequest.getParameter("job_num_r"+lNumRec);
      lCxCronJobTabObj.sch_date = inRequest.getParameter("sch_date_r"+lNumRec);
      lCxCronJobTabObj.sch_time = inRequest.getParameter("sch_time_r"+lNumRec);
      lCxCronJobTabObj.alert_type = inRequest.getParameter("alert_type_r"+lNumRec);
      lCxCronJobTabObj.contact_num_1 = inRequest.getParameter("contact_num_1_r"+lNumRec);
      lCxCronJobTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
      lCxCronJobTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxCronJobTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
      lCxCronJobTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxCronJobTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxCronJobTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
      lCxCronJobTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxCronJobTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      outCxCronJobTabObjArr.add( lCxCronJobTabObj);
    }
    return lReturnValue;
  }


  public int popCxCronJobReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxCronJobTabObj outCxCronJobTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_cron_job_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxCronJobTabObj.tab_rowid = lTabRowidValue;

        outCxCronJobTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxCronJobTabObj.job_num = inRequest.getParameter("job_num_r"+lNumRec);
        outCxCronJobTabObj.sch_date = inRequest.getParameter("sch_date_r"+lNumRec);
        outCxCronJobTabObj.sch_time = inRequest.getParameter("sch_time_r"+lNumRec);
        outCxCronJobTabObj.alert_type = inRequest.getParameter("alert_type_r"+lNumRec);
        outCxCronJobTabObj.contact_num_1 = inRequest.getParameter("contact_num_1_r"+lNumRec);
        outCxCronJobTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        outCxCronJobTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxCronJobTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
        outCxCronJobTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxCronJobTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxCronJobTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
        outCxCronJobTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxCronJobTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popCxCronJobReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxCronJobTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxCronJobTabObj lCxCronJobTabObj= new CxCronJobTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_cron_job_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxCronJobTabObj.tab_rowid = lTabRowidValue;

        lCxCronJobTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxCronJobTabObj.job_num = inRequest.getParameter("job_num_r"+lNumRec);
        lCxCronJobTabObj.sch_date = inRequest.getParameter("sch_date_r"+lNumRec);
        lCxCronJobTabObj.sch_time = inRequest.getParameter("sch_time_r"+lNumRec);
        lCxCronJobTabObj.alert_type = inRequest.getParameter("alert_type_r"+lNumRec);
        lCxCronJobTabObj.contact_num_1 = inRequest.getParameter("contact_num_1_r"+lNumRec);
        lCxCronJobTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        lCxCronJobTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxCronJobTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
        lCxCronJobTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxCronJobTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxCronJobTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
        lCxCronJobTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxCronJobTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxCronJobTabObjArr.add( lCxCronJobTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxCronJobRecByRowid
               ( String inRowId
               , CxCronJobTabObj  inCxCronJobTabObj
               )
  {
    int lUpdateCount;
    sop("updCxCronJobRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxCronJobRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxCronJobTabObj.sch_date != null && inCxCronJobTabObj.sch_date.length() > 0 ) 
            inCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.sch_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_cre_date != null && inCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            inCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_upd_date != null && inCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            inCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_CRON_JOB ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxCronJobTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxCronJobTabObj.org_id+"', ";
      if ( inCxCronJobTabObj.job_num != null  )         lSqlStmt = lSqlStmt + "job_num = "+"'"+inCxCronJobTabObj.job_num+"', ";
      if ( inCxCronJobTabObj.sch_date != null  )         lSqlStmt = lSqlStmt + "sch_date = "+"'"+inCxCronJobTabObj.sch_date+"', ";
      if ( inCxCronJobTabObj.sch_time != null  )         lSqlStmt = lSqlStmt + "sch_time = "+"'"+inCxCronJobTabObj.sch_time+"', ";
      if ( inCxCronJobTabObj.alert_type != null  )         lSqlStmt = lSqlStmt + "alert_type = "+"'"+inCxCronJobTabObj.alert_type+"', ";
      if ( inCxCronJobTabObj.contact_num_1 != null  )         lSqlStmt = lSqlStmt + "contact_num_1 = "+"'"+inCxCronJobTabObj.contact_num_1+"', ";
      if ( inCxCronJobTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inCxCronJobTabObj.email_id+"', ";
      if ( inCxCronJobTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxCronJobTabObj.status+"', ";
      if ( inCxCronJobTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = "+"'"+inCxCronJobTabObj.rec_cre_by+"', ";
      if ( inCxCronJobTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxCronJobTabObj.rec_cre_date+"', ";
      if ( inCxCronJobTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxCronJobTabObj.rec_cre_time+"', ";
      if ( inCxCronJobTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = "+"'"+inCxCronJobTabObj.rec_upd_by+"', ";
      if ( inCxCronJobTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxCronJobTabObj.rec_upd_date+"', ";
      if ( inCxCronJobTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxCronJobTabObj.rec_upd_time+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxCronJobRecByPkey
               ( CxCronJobPkeyObj inCxCronJobPkeyObj
               , CxCronJobTabObj  inCxCronJobTabObj
               )
  {
    int lUpdateCount;
    sop("updCxCronJobRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxCronJobRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxCronJobTabObj.sch_date != null && inCxCronJobTabObj.sch_date.length() > 0 ) 
            inCxCronJobTabObj.sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.sch_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_cre_date != null && inCxCronJobTabObj.rec_cre_date.length() > 0 ) 
            inCxCronJobTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxCronJobTabObj.rec_upd_date != null && inCxCronJobTabObj.rec_upd_date.length() > 0 ) 
            inCxCronJobTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxCronJobTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_CRON_JOB ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxCronJobTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxCronJobTabObj.job_num != null  )         lSqlStmt = lSqlStmt + "job_num = ? , ";
        if ( inCxCronJobTabObj.sch_date != null  )         lSqlStmt = lSqlStmt + "sch_date = ? , ";
        if ( inCxCronJobTabObj.sch_time != null  )         lSqlStmt = lSqlStmt + "sch_time = ? , ";
        if ( inCxCronJobTabObj.alert_type != null  )         lSqlStmt = lSqlStmt + "alert_type = ? , ";
        if ( inCxCronJobTabObj.contact_num_1 != null  )         lSqlStmt = lSqlStmt + "contact_num_1 = ? , ";
        if ( inCxCronJobTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = ? , ";
        if ( inCxCronJobTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxCronJobTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = ? , ";
        if ( inCxCronJobTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxCronJobTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxCronJobTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = ? , ";
        if ( inCxCronJobTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxCronJobTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxCronJobTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxCronJobTabObj.org_id+"', ";
        if ( inCxCronJobTabObj.job_num != null  )         lSqlStmt = lSqlStmt + "job_num = "+"'"+inCxCronJobTabObj.job_num+"', ";
        if ( inCxCronJobTabObj.sch_date != null  )         lSqlStmt = lSqlStmt + "sch_date = "+"'"+inCxCronJobTabObj.sch_date+"', ";
        if ( inCxCronJobTabObj.sch_time != null  )         lSqlStmt = lSqlStmt + "sch_time = "+"'"+inCxCronJobTabObj.sch_time+"', ";
        if ( inCxCronJobTabObj.alert_type != null  )         lSqlStmt = lSqlStmt + "alert_type = "+"'"+inCxCronJobTabObj.alert_type+"', ";
        if ( inCxCronJobTabObj.contact_num_1 != null  )         lSqlStmt = lSqlStmt + "contact_num_1 = "+"'"+inCxCronJobTabObj.contact_num_1+"', ";
        if ( inCxCronJobTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inCxCronJobTabObj.email_id+"', ";
        if ( inCxCronJobTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxCronJobTabObj.status+"', ";
        if ( inCxCronJobTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = "+"'"+inCxCronJobTabObj.rec_cre_by+"', ";
        if ( inCxCronJobTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxCronJobTabObj.rec_cre_date+"', ";
        if ( inCxCronJobTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxCronJobTabObj.rec_cre_time+"', ";
        if ( inCxCronJobTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = "+"'"+inCxCronJobTabObj.rec_upd_by+"', ";
        if ( inCxCronJobTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxCronJobTabObj.rec_upd_date+"', ";
        if ( inCxCronJobTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxCronJobTabObj.rec_upd_time+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxCronJobPkeyObj.org_id+"' and "+
                              "job_num = "+"'"+inCxCronJobPkeyObj.job_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxCronJobTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.org_id); } 
         if ( inCxCronJobTabObj.job_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.job_num); } 
         if ( inCxCronJobTabObj.sch_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.sch_date); } 
         if ( inCxCronJobTabObj.sch_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.sch_time); } 
         if ( inCxCronJobTabObj.alert_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.alert_type); } 
         if ( inCxCronJobTabObj.contact_num_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.contact_num_1); } 
         if ( inCxCronJobTabObj.email_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.email_id); } 
         if ( inCxCronJobTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.status); } 
         if ( inCxCronJobTabObj.rec_cre_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_cre_by); } 
         if ( inCxCronJobTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_cre_date); } 
         if ( inCxCronJobTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_cre_time); } 
         if ( inCxCronJobTabObj.rec_upd_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_upd_by); } 
         if ( inCxCronJobTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_upd_date); } 
         if ( inCxCronJobTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxCronJobTabObj.rec_upd_time); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxCronJobRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxCronJobRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxCronJobRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_CRON_JOB "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxCronJobRecByPkeyWithSet
               ( CxCronJobPkeyObj inCxCronJobPkeyObj
               , String  inCxCronJobSetlist
               )
  {
    int lUpdateCount;
    sop("updCxCronJobRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxCronJobRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_CRON_JOB ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxCronJobSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxCronJobPkeyObj.org_id+"' and "+
                              "job_num = "+"'"+inCxCronJobPkeyObj.job_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxCronJobRecByRowidWithSet
               ( String inRowId
               , String  inCxCronJobSetlist
               )
  {
    int lUpdateCount;
    sop("updCxCronJobRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxCronJobRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_CRON_JOB ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxCronJobSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxCronJobRecByWhereWithSet
               ( String inCxCronJobWhereText
               , String  inCxCronJobSetlist
               )
  {
    int lUpdateCount;
    sop("updCxCronJobRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxCronJobRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_CRON_JOB ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxCronJobSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxCronJobRecByPkey
               ( CxCronJobPkeyObj  inCxCronJobPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxCronJobRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxCronJobRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_CRON_JOB " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxCronJobPkeyObj.org_id+"' and "+
                              "job_num = "+"'"+inCxCronJobPkeyObj.job_num+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxCronJobByWhere
               ( String inCxCronJobWhereText
               )
  {
    int lUpdateCount;
    sop("delCxCronJobByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxCronJobByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxCronJobWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxCronJobWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_CRON_JOB "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
