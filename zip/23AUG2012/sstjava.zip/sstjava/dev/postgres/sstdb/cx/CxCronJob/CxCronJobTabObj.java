package sstdb.cx.CxCronJob;


public class CxCronJobTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 job_num;
  public String                                 sch_date;
  public String                                 sch_time;
  public String                                 alert_type;
  public String                                 contact_num_1;
  public String                                 email_id;
  public String                                 status;
  public String                                 rec_cre_by;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_by;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  job_num_ind;
  public short                                  sch_date_ind;
  public short                                  sch_time_ind;
  public short                                  alert_type_ind;
  public short                                  contact_num_1_ind;
  public short                                  email_id_ind;
  public short                                  status_ind;
  public short                                  rec_cre_by_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_by_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxCronJobTabObj(){}


  public CxCronJobTabObj
  (
    String org_id,
    String job_num,
    String sch_date,
    String sch_time,
    String alert_type,
    String contact_num_1,
    String email_id,
    String status,
    String rec_cre_by,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_by,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.job_num = job_num;
     this.sch_date = sch_date;
     this.sch_time = sch_time;
     this.alert_type = alert_type;
     this.contact_num_1 = contact_num_1;
     this.email_id = email_id;
     this.status = status;
     this.rec_cre_by = rec_cre_by;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_by = rec_upd_by;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getjob_num()                          { return job_num; }
  public String getsch_date()                          { return sch_date; }
  public String getsch_time()                          { return sch_time; }
  public String getalert_type()                         { return alert_type; }
  public String getcontact_num_1()                       { return contact_num_1; }
  public String getemail_id()                          { return email_id; }
  public String getstatus()                           { return status; }
  public String getrec_cre_by()                         { return rec_cre_by; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_by()                         { return rec_upd_by; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setjob_num(String job_num )                   { this.job_num = job_num; }
  public void  setsch_date(String sch_date )                  { this.sch_date = sch_date; }
  public void  setsch_time(String sch_time )                  { this.sch_time = sch_time; }
  public void  setalert_type(String alert_type )                { this.alert_type = alert_type; }
  public void  setcontact_num_1(String contact_num_1 )             { this.contact_num_1 = contact_num_1; }
  public void  setemail_id(String email_id )                  { this.email_id = email_id; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_by(String rec_cre_by )                { this.rec_cre_by = rec_cre_by; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_by(String rec_upd_by )                { this.rec_upd_by = rec_upd_by; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}