CREATE TABLE CX_CRON_JOB
(
  ORG_ID                                                                                              VARCHAR(10),
  JOB_NUM                                                                                             VARCHAR(20),
  SCH_DATE                                                                                            VARCHAR(8),
  SCH_TIME                                                                                            VARCHAR(6),
  ALERT_TYPE                                                                                          VARCHAR(1),
  CONTACT_NUM_1                                                                                       VARCHAR(30),
  EMAIL_ID                                                                                            VARCHAR(50),
  STATUS                                                                                              VARCHAR(10),
  REC_CRE_BY                                                                                          VARCHAR(20),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_BY                                                                                          VARCHAR(20),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
