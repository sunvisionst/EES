package sstdb.cx.CxDtxnCf;


public class CxDtxnCfPkeyObj
{
  public String                                 org_id;
  public String                                 txn_num;
}