package sstdb.cx.CxSymbolCntr;


public class CxSymbolCntrTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public String                                 symbol_name;
  public String                                 eff_date;
  public String                                 eff_time;
  public String                                 exp_date;
  public String                                 exp_time;
  public double                                 ddr;
  public double                                 exp_rate;
  public String                                 rate_currency;
  public String                                 rate_per_uom;
  public double                                 spl_mrgn_pur_1;
  public double                                 spl_mrgn_pur_rt_1;
  public double                                 spl_mrgn_pur_2;
  public double                                 spl_mrgn_pur_rt_2;
  public double                                 spl_mrgn_pur_3;
  public double                                 spl_mrgn_pur_rt_3;
  public double                                 spl_mrgn_pur_4;
  public double                                 spl_mrgn_pur_rt_4;
  public double                                 spl_mrgn_sal_1;
  public double                                 spl_mrgn_sal_rt_1;
  public double                                 spl_mrgn_sal_2;
  public double                                 spl_mrgn_sal_rt_2;
  public double                                 spl_mrgn_sal_3;
  public double                                 spl_mrgn_sal_rt_3;
  public double                                 spl_mrgn_sal_4;
  public double                                 spl_mrgn_sal_rt_4;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  symbol_name_ind;
  public short                                  eff_date_ind;
  public short                                  eff_time_ind;
  public short                                  exp_date_ind;
  public short                                  exp_time_ind;
  public short                                  ddr_ind;
  public short                                  exp_rate_ind;
  public short                                  rate_currency_ind;
  public short                                  rate_per_uom_ind;
  public short                                  spl_mrgn_pur_1_ind;
  public short                                  spl_mrgn_pur_rt_1_ind;
  public short                                  spl_mrgn_pur_2_ind;
  public short                                  spl_mrgn_pur_rt_2_ind;
  public short                                  spl_mrgn_pur_3_ind;
  public short                                  spl_mrgn_pur_rt_3_ind;
  public short                                  spl_mrgn_pur_4_ind;
  public short                                  spl_mrgn_pur_rt_4_ind;
  public short                                  spl_mrgn_sal_1_ind;
  public short                                  spl_mrgn_sal_rt_1_ind;
  public short                                  spl_mrgn_sal_2_ind;
  public short                                  spl_mrgn_sal_rt_2_ind;
  public short                                  spl_mrgn_sal_3_ind;
  public short                                  spl_mrgn_sal_rt_3_ind;
  public short                                  spl_mrgn_sal_4_ind;
  public short                                  spl_mrgn_sal_rt_4_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxSymbolCntrTabObj(){}


  public CxSymbolCntrTabObj
  (
    String org_id,
    String contract_id,
    String symbol_cd,
    String symbol_name,
    String eff_date,
    String eff_time,
    String exp_date,
    String exp_time,
    double ddr,
    double exp_rate,
    String rate_currency,
    String rate_per_uom,
    double spl_mrgn_pur_1,
    double spl_mrgn_pur_rt_1,
    double spl_mrgn_pur_2,
    double spl_mrgn_pur_rt_2,
    double spl_mrgn_pur_3,
    double spl_mrgn_pur_rt_3,
    double spl_mrgn_pur_4,
    double spl_mrgn_pur_rt_4,
    double spl_mrgn_sal_1,
    double spl_mrgn_sal_rt_1,
    double spl_mrgn_sal_2,
    double spl_mrgn_sal_rt_2,
    double spl_mrgn_sal_3,
    double spl_mrgn_sal_rt_3,
    double spl_mrgn_sal_4,
    double spl_mrgn_sal_rt_4,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.symbol_name = symbol_name;
     this.eff_date = eff_date;
     this.eff_time = eff_time;
     this.exp_date = exp_date;
     this.exp_time = exp_time;
     this.ddr = ddr;
     this.exp_rate = exp_rate;
     this.rate_currency = rate_currency;
     this.rate_per_uom = rate_per_uom;
     this.spl_mrgn_pur_1 = spl_mrgn_pur_1;
     this.spl_mrgn_pur_rt_1 = spl_mrgn_pur_rt_1;
     this.spl_mrgn_pur_2 = spl_mrgn_pur_2;
     this.spl_mrgn_pur_rt_2 = spl_mrgn_pur_rt_2;
     this.spl_mrgn_pur_3 = spl_mrgn_pur_3;
     this.spl_mrgn_pur_rt_3 = spl_mrgn_pur_rt_3;
     this.spl_mrgn_pur_4 = spl_mrgn_pur_4;
     this.spl_mrgn_pur_rt_4 = spl_mrgn_pur_rt_4;
     this.spl_mrgn_sal_1 = spl_mrgn_sal_1;
     this.spl_mrgn_sal_rt_1 = spl_mrgn_sal_rt_1;
     this.spl_mrgn_sal_2 = spl_mrgn_sal_2;
     this.spl_mrgn_sal_rt_2 = spl_mrgn_sal_rt_2;
     this.spl_mrgn_sal_3 = spl_mrgn_sal_3;
     this.spl_mrgn_sal_rt_3 = spl_mrgn_sal_rt_3;
     this.spl_mrgn_sal_4 = spl_mrgn_sal_4;
     this.spl_mrgn_sal_rt_4 = spl_mrgn_sal_rt_4;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public String getsymbol_name()                        { return symbol_name; }
  public String geteff_date()                          { return eff_date; }
  public String geteff_time()                          { return eff_time; }
  public String getexp_date()                          { return exp_date; }
  public String getexp_time()                          { return exp_time; }
  public double getddr()                            { return ddr; }
  public double getexp_rate()                          { return exp_rate; }
  public String getrate_currency()                       { return rate_currency; }
  public String getrate_per_uom()                        { return rate_per_uom; }
  public double getspl_mrgn_pur_1()                       { return spl_mrgn_pur_1; }
  public double getspl_mrgn_pur_rt_1()                     { return spl_mrgn_pur_rt_1; }
  public double getspl_mrgn_pur_2()                       { return spl_mrgn_pur_2; }
  public double getspl_mrgn_pur_rt_2()                     { return spl_mrgn_pur_rt_2; }
  public double getspl_mrgn_pur_3()                       { return spl_mrgn_pur_3; }
  public double getspl_mrgn_pur_rt_3()                     { return spl_mrgn_pur_rt_3; }
  public double getspl_mrgn_pur_4()                       { return spl_mrgn_pur_4; }
  public double getspl_mrgn_pur_rt_4()                     { return spl_mrgn_pur_rt_4; }
  public double getspl_mrgn_sal_1()                       { return spl_mrgn_sal_1; }
  public double getspl_mrgn_sal_rt_1()                     { return spl_mrgn_sal_rt_1; }
  public double getspl_mrgn_sal_2()                       { return spl_mrgn_sal_2; }
  public double getspl_mrgn_sal_rt_2()                     { return spl_mrgn_sal_rt_2; }
  public double getspl_mrgn_sal_3()                       { return spl_mrgn_sal_3; }
  public double getspl_mrgn_sal_rt_3()                     { return spl_mrgn_sal_rt_3; }
  public double getspl_mrgn_sal_4()                       { return spl_mrgn_sal_4; }
  public double getspl_mrgn_sal_rt_4()                     { return spl_mrgn_sal_rt_4; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setsymbol_name(String symbol_name )               { this.symbol_name = symbol_name; }
  public void  seteff_date(String eff_date )                  { this.eff_date = eff_date; }
  public void  seteff_time(String eff_time )                  { this.eff_time = eff_time; }
  public void  setexp_date(String exp_date )                  { this.exp_date = exp_date; }
  public void  setexp_time(String exp_time )                  { this.exp_time = exp_time; }
  public void  setddr(double ddr )                       { this.ddr = ddr; }
  public void  setexp_rate(double exp_rate )                  { this.exp_rate = exp_rate; }
  public void  setrate_currency(String rate_currency )             { this.rate_currency = rate_currency; }
  public void  setrate_per_uom(String rate_per_uom )              { this.rate_per_uom = rate_per_uom; }
  public void  setspl_mrgn_pur_1(double spl_mrgn_pur_1 )            { this.spl_mrgn_pur_1 = spl_mrgn_pur_1; }
  public void  setspl_mrgn_pur_rt_1(double spl_mrgn_pur_rt_1 )         { this.spl_mrgn_pur_rt_1 = spl_mrgn_pur_rt_1; }
  public void  setspl_mrgn_pur_2(double spl_mrgn_pur_2 )            { this.spl_mrgn_pur_2 = spl_mrgn_pur_2; }
  public void  setspl_mrgn_pur_rt_2(double spl_mrgn_pur_rt_2 )         { this.spl_mrgn_pur_rt_2 = spl_mrgn_pur_rt_2; }
  public void  setspl_mrgn_pur_3(double spl_mrgn_pur_3 )            { this.spl_mrgn_pur_3 = spl_mrgn_pur_3; }
  public void  setspl_mrgn_pur_rt_3(double spl_mrgn_pur_rt_3 )         { this.spl_mrgn_pur_rt_3 = spl_mrgn_pur_rt_3; }
  public void  setspl_mrgn_pur_4(double spl_mrgn_pur_4 )            { this.spl_mrgn_pur_4 = spl_mrgn_pur_4; }
  public void  setspl_mrgn_pur_rt_4(double spl_mrgn_pur_rt_4 )         { this.spl_mrgn_pur_rt_4 = spl_mrgn_pur_rt_4; }
  public void  setspl_mrgn_sal_1(double spl_mrgn_sal_1 )            { this.spl_mrgn_sal_1 = spl_mrgn_sal_1; }
  public void  setspl_mrgn_sal_rt_1(double spl_mrgn_sal_rt_1 )         { this.spl_mrgn_sal_rt_1 = spl_mrgn_sal_rt_1; }
  public void  setspl_mrgn_sal_2(double spl_mrgn_sal_2 )            { this.spl_mrgn_sal_2 = spl_mrgn_sal_2; }
  public void  setspl_mrgn_sal_rt_2(double spl_mrgn_sal_rt_2 )         { this.spl_mrgn_sal_rt_2 = spl_mrgn_sal_rt_2; }
  public void  setspl_mrgn_sal_3(double spl_mrgn_sal_3 )            { this.spl_mrgn_sal_3 = spl_mrgn_sal_3; }
  public void  setspl_mrgn_sal_rt_3(double spl_mrgn_sal_rt_3 )         { this.spl_mrgn_sal_rt_3 = spl_mrgn_sal_rt_3; }
  public void  setspl_mrgn_sal_4(double spl_mrgn_sal_4 )            { this.spl_mrgn_sal_4 = spl_mrgn_sal_4; }
  public void  setspl_mrgn_sal_rt_4(double spl_mrgn_sal_rt_4 )         { this.spl_mrgn_sal_rt_4 = spl_mrgn_sal_rt_4; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}