CREATE TABLE CX_DTXN_EXT
(
  org_id                                                                                              VARCHAR(10),
  txn_num                                                                                             VARCHAR(20),
  txn_date                                                                                            VARCHAR(8),
  txn_time                                                                                            VARCHAR(6),
  txn_type                                                                                            VARCHAR(1),
  member_id                                                                                           VARCHAR(20),
  member_name                                                                                         VARCHAR(100),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  qty                                                                                                 NUMERIC(9),
  mature_qty                                                                                          NUMERIC(9),
  rate                                                                                                NUMERIC(13,2),
  cf_txn_num                                                                                          VARCHAR(20),
  cf_rate                                                                                             NUMERIC(13,2),
  cf_date                                                                                             VARCHAR(8),
  cf_time                                                                                             VARCHAR(6),
  status                                                                                              VARCHAR(10),
  reg_ind                                                                                             VARCHAR(1),
  reg_limit                                                                                           NUMERIC(13,2),
  slr_ind                                                                                             VARCHAR(1),
  slr_limit                                                                                           NUMERIC(13,2),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       TXN_NUM                                                                                             CHAR(20),
       TXN_DATE                                                                                            CHAR(8),
       TXN_TIME                                                                                            CHAR(6),
       TXN_TYPE                                                                                            CHAR(1),
       MEMBER_ID                                                                                           CHAR(20),
       MEMBER_NAME                                                                                         CHAR(100),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       QTY                                                                                                 CHAR(9),
       MATURE_QTY                                                                                          CHAR(9),
       RATE                                                                                                CHAR(13),
       CF_TXN_NUM                                                                                          CHAR(20),
       CF_RATE                                                                                             CHAR(13),
       CF_DATE                                                                                             CHAR(8),
       CF_TIME                                                                                             CHAR(6),
       STATUS                                                                                              CHAR(10),
       REG_IND                                                                                             CHAR(1),
       REG_LIMIT                                                                                           CHAR(13),
       SLR_IND                                                                                             CHAR(1),
       SLR_LIMIT                                                                                           CHAR(13),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_dtxn_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
