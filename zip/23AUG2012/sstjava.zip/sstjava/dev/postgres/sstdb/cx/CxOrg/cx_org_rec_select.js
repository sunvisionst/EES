function CxOrgRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("org_name").value  = document.getElementById("org_name"+"_r"+inRecNum).value;
    document.getElementById("related_org_id").value  = document.getElementById("related_org_id"+"_r"+inRecNum).value;
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value;
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value;
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value;
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value;
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
    document.getElementById("org_type").value  = document.getElementById("org_type"+"_r"+inRecNum).value;
    document.getElementById("org_ctg").value  = document.getElementById("org_ctg"+"_r"+inRecNum).value;
    document.getElementById("bus_type").value  = document.getElementById("bus_type"+"_r"+inRecNum).value;
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value;
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value;
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value;
    document.getElementById("business_currency").value  = document.getElementById("business_currency"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("org_url").value  = document.getElementById("org_url"+"_r"+inRecNum).value;
    document.getElementById("logo_file_name").value  = document.getElementById("logo_file_name"+"_r"+inRecNum).value;
    document.getElementById("employer_reg_num").value  = document.getElementById("employer_reg_num"+"_r"+inRecNum).value;
    document.getElementById("employer_reg_date").value  = document.getElementById("employer_reg_date"+"_r"+inRecNum).value;
    document.getElementById("epf_act_num").value  = document.getElementById("epf_act_num"+"_r"+inRecNum).value;
    document.getElementById("epf_act_open_dt").value  = document.getElementById("epf_act_open_dt"+"_r"+inRecNum).value;
    document.getElementById("esi_num").value  = document.getElementById("esi_num"+"_r"+inRecNum).value;
    document.getElementById("esi_act_open_dt").value  = document.getElementById("esi_act_open_dt"+"_r"+inRecNum).value;
    document.getElementById("pan_num").value  = document.getElementById("pan_num"+"_r"+inRecNum).value;
    document.getElementById("pan_create_date").value  = document.getElementById("pan_create_date"+"_r"+inRecNum).value;
    document.getElementById("nss_num").value  = document.getElementById("nss_num"+"_r"+inRecNum).value;
    document.getElementById("nss_create_date").value  = document.getElementById("nss_create_date"+"_r"+inRecNum).value;
    document.getElementById("key_1").value  = document.getElementById("key_1"+"_r"+inRecNum).value;
    document.getElementById("key_2").value  = document.getElementById("key_2"+"_r"+inRecNum).value;
    document.getElementById("mkey").value  = document.getElementById("mkey"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("org_name").value = '';
    document.getElementById("related_org_id").value = '';
    document.getElementById("address_1").value = '';
    document.getElementById("address_2").value = '';
    document.getElementById("city").value = '';
    document.getElementById("state").value = '';
    document.getElementById("zip").value = '';
    document.getElementById("country").value = '';
    document.getElementById("org_type").value = '';
    document.getElementById("org_ctg").value = '';
    document.getElementById("bus_type").value = '';
    document.getElementById("phone_list").value = '';
    document.getElementById("email_list").value = '';
    document.getElementById("fax_list").value = '';
    document.getElementById("business_currency").value = '';
    document.getElementById("effective_date").value = '';
    document.getElementById("expiration_date").value = '';
    document.getElementById("org_url").value = '';
    document.getElementById("logo_file_name").value = '';
    document.getElementById("employer_reg_num").value = '';
    document.getElementById("employer_reg_date").value = '';
    document.getElementById("epf_act_num").value = '';
    document.getElementById("epf_act_open_dt").value = '';
    document.getElementById("esi_num").value = '';
    document.getElementById("esi_act_open_dt").value = '';
    document.getElementById("pan_num").value = '';
    document.getElementById("pan_create_date").value = '';
    document.getElementById("nss_num").value = '';
    document.getElementById("nss_create_date").value = '';
    document.getElementById("key_1").value = '';
    document.getElementById("key_2").value = '';
    document.getElementById("mkey").value = '';
  }
}
