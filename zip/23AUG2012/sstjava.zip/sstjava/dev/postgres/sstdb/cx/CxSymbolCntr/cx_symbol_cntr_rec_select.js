function CxSymbolCntrRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("contract_id").value  = document.getElementById("contract_id"+"_r"+inRecNum).value;
    document.getElementById("contract_id").readOnly = true;
    document.getElementById("symbol_cd").value  = document.getElementById("symbol_cd"+"_r"+inRecNum).value;
    document.getElementById("symbol_name").value  = document.getElementById("symbol_name"+"_r"+inRecNum).value;
    document.getElementById("eff_date").value  = document.getElementById("eff_date"+"_r"+inRecNum).value;
    document.getElementById("eff_time").value  = document.getElementById("eff_time"+"_r"+inRecNum).value;
    document.getElementById("exp_date").value  = document.getElementById("exp_date"+"_r"+inRecNum).value;
    document.getElementById("exp_time").value  = document.getElementById("exp_time"+"_r"+inRecNum).value;
    document.getElementById("ddr").value  = document.getElementById("ddr"+"_r"+inRecNum).value;
    document.getElementById("exp_rate").value  = document.getElementById("exp_rate"+"_r"+inRecNum).value;
    document.getElementById("rate_currency").value  = document.getElementById("rate_currency"+"_r"+inRecNum).value;
    document.getElementById("rate_per_uom").value  = document.getElementById("rate_per_uom"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_1").value  = document.getElementById("spl_mrgn_pur_1"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_rt_1").value  = document.getElementById("spl_mrgn_pur_rt_1"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_2").value  = document.getElementById("spl_mrgn_pur_2"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_rt_2").value  = document.getElementById("spl_mrgn_pur_rt_2"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_3").value  = document.getElementById("spl_mrgn_pur_3"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_rt_3").value  = document.getElementById("spl_mrgn_pur_rt_3"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_4").value  = document.getElementById("spl_mrgn_pur_4"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_pur_rt_4").value  = document.getElementById("spl_mrgn_pur_rt_4"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_1").value  = document.getElementById("spl_mrgn_sal_1"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_rt_1").value  = document.getElementById("spl_mrgn_sal_rt_1"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_2").value  = document.getElementById("spl_mrgn_sal_2"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_rt_2").value  = document.getElementById("spl_mrgn_sal_rt_2"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_3").value  = document.getElementById("spl_mrgn_sal_3"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_rt_3").value  = document.getElementById("spl_mrgn_sal_rt_3"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_4").value  = document.getElementById("spl_mrgn_sal_4"+"_r"+inRecNum).value;
    document.getElementById("spl_mrgn_sal_rt_4").value  = document.getElementById("spl_mrgn_sal_rt_4"+"_r"+inRecNum).value;
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("contract_id").value = '';
    document.getElementById("contract_id").readOnly = false;
    document.getElementById("symbol_cd").value = '';
    document.getElementById("symbol_name").value = '';
    document.getElementById("eff_date").value = '';
    document.getElementById("eff_time").value = '';
    document.getElementById("exp_date").value = '';
    document.getElementById("exp_time").value = '';
    document.getElementById("ddr").value = '';
    document.getElementById("exp_rate").value = '';
    document.getElementById("rate_currency").value = '';
    document.getElementById("rate_per_uom").value = '';
    document.getElementById("spl_mrgn_pur_1").value = '';
    document.getElementById("spl_mrgn_pur_rt_1").value = '';
    document.getElementById("spl_mrgn_pur_2").value = '';
    document.getElementById("spl_mrgn_pur_rt_2").value = '';
    document.getElementById("spl_mrgn_pur_3").value = '';
    document.getElementById("spl_mrgn_pur_rt_3").value = '';
    document.getElementById("spl_mrgn_pur_4").value = '';
    document.getElementById("spl_mrgn_pur_rt_4").value = '';
    document.getElementById("spl_mrgn_sal_1").value = '';
    document.getElementById("spl_mrgn_sal_rt_1").value = '';
    document.getElementById("spl_mrgn_sal_2").value = '';
    document.getElementById("spl_mrgn_sal_rt_2").value = '';
    document.getElementById("spl_mrgn_sal_3").value = '';
    document.getElementById("spl_mrgn_sal_rt_3").value = '';
    document.getElementById("spl_mrgn_sal_4").value = '';
    document.getElementById("spl_mrgn_sal_rt_4").value = '';
    document.getElementById("status").value = '';
    document.getElementById("rec_cre_date").value = '';
    document.getElementById("rec_cre_time").value = '';
    document.getElementById("rec_upd_date").value = '';
    document.getElementById("rec_upd_time").value = '';
  }
}
