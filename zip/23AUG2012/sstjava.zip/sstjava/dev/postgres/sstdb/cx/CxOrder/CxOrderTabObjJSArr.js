
var lCxOrderTabObjJSArr = new Array();
<%
{
   if ( lCxOrderTabObjArrCache != null && lCxOrderTabObjArrCache.size() > 0 )
   {
%>
       lCxOrderTabObjJSArr = new Array(<%=lCxOrderTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxOrderTabObjArrCache.size(); lRecNum++ )
       {
          CxOrderTabObj lCxOrderTabObj    =    new CxOrderTabObj();
          lCxOrderTabObj = (CxOrderTabObj)lCxOrderTabObjArrCache.get(lRecNum);
%>
          lCxOrderTabObjJSArr[<%=lRecNum%>] = new constructorCxOrder
          (
          "<%=lCxOrderTabObj.org_id%>",
          "<%=lCxOrderTabObj.ord_num%>",
          "<%=lCxOrderTabObj.ord_seq_num%>",
          "<%=lCxOrderTabObj.ord_date%>",
          "<%=lCxOrderTabObj.ord_time%>",
          "<%=lCxOrderTabObj.txn_type%>",
          "<%=lCxOrderTabObj.contract_id%>",
          "<%=lCxOrderTabObj.symbol_cd%>",
          "<%=lCxOrderTabObj.buyer%>",
          "<%=lCxOrderTabObj.seller%>",
          "<%=lCxOrderTabObj.buy_qty%>",
          "<%=lCxOrderTabObj.sale_qty%>",
          "<%=lCxOrderTabObj.bal_qty%>",
          "<%=lCxOrderTabObj.rate%>",
          "<%=lCxOrderTabObj.status%>",
          "<%=lCxOrderTabObj.rec_cre_date%>",
          "<%=lCxOrderTabObj.rec_cre_time%>",
          "<%=lCxOrderTabObj.rec_upd_date%>",
          "<%=lCxOrderTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


