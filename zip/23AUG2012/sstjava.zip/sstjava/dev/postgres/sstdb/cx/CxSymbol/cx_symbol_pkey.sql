ALTER TABLE           CX_SYMBOL
  ADD                 CONSTRAINT CX_SYMBOL_PK
  PRIMARY             KEY
  ( ORG_ID, SYMBOL_CD )
;
