CREATE TABLE CX_CRON_JOB_EXT
(
  org_id                                                                                              VARCHAR(10),
  job_num                                                                                             VARCHAR(20),
  sch_date                                                                                            VARCHAR(8),
  sch_time                                                                                            VARCHAR(6),
  alert_type                                                                                          VARCHAR(1),
  contact_num_1                                                                                       VARCHAR(30),
  email_id                                                                                            VARCHAR(50),
  status                                                                                              VARCHAR(10),
  rec_cre_by                                                                                          VARCHAR(20),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_by                                                                                          VARCHAR(20),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       JOB_NUM                                                                                             CHAR(20),
       SCH_DATE                                                                                            CHAR(8),
       SCH_TIME                                                                                            CHAR(6),
       ALERT_TYPE                                                                                          CHAR(1),
       CONTACT_NUM_1                                                                                       CHAR(30),
       EMAIL_ID                                                                                            CHAR(50),
       STATUS                                                                                              CHAR(10),
       REC_CRE_BY                                                                                          CHAR(20),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_BY                                                                                          CHAR(20),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_cron_job_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
