
var lCxDtxnTabObjJSArr = new Array();
<%
{
   if ( lCxDtxnTabObjArrCache != null && lCxDtxnTabObjArrCache.size() > 0 )
   {
%>
       lCxDtxnTabObjJSArr = new Array(<%=lCxDtxnTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxDtxnTabObjArrCache.size(); lRecNum++ )
       {
          CxDtxnTabObj lCxDtxnTabObj    =    new CxDtxnTabObj();
          lCxDtxnTabObj = (CxDtxnTabObj)lCxDtxnTabObjArrCache.get(lRecNum);
%>
          lCxDtxnTabObjJSArr[<%=lRecNum%>] = new constructorCxDtxn
          (
          "<%=lCxDtxnTabObj.org_id%>",
          "<%=lCxDtxnTabObj.txn_num%>",
          "<%=lCxDtxnTabObj.txn_date%>",
          "<%=lCxDtxnTabObj.txn_time%>",
          "<%=lCxDtxnTabObj.txn_type%>",
          "<%=lCxDtxnTabObj.member_id%>",
          "<%=lCxDtxnTabObj.member_name%>",
          "<%=lCxDtxnTabObj.contract_id%>",
          "<%=lCxDtxnTabObj.symbol_cd%>",
          "<%=lCxDtxnTabObj.qty%>",
          "<%=lCxDtxnTabObj.mature_qty%>",
          "<%=lCxDtxnTabObj.rate%>",
          "<%=lCxDtxnTabObj.cf_txn_num%>",
          "<%=lCxDtxnTabObj.cf_rate%>",
          "<%=lCxDtxnTabObj.cf_date%>",
          "<%=lCxDtxnTabObj.cf_time%>",
          "<%=lCxDtxnTabObj.status%>",
          "<%=lCxDtxnTabObj.reg_ind%>",
          "<%=lCxDtxnTabObj.reg_limit%>",
          "<%=lCxDtxnTabObj.slr_ind%>",
          "<%=lCxDtxnTabObj.slr_limit%>",
          "<%=lCxDtxnTabObj.rec_cre_date%>",
          "<%=lCxDtxnTabObj.rec_cre_time%>",
          "<%=lCxDtxnTabObj.rec_upd_date%>",
          "<%=lCxDtxnTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


