
var lCxSymbolTabObjJSArr = new Array();
<%
{
   if ( lCxSymbolTabObjArrCache != null && lCxSymbolTabObjArrCache.size() > 0 )
   {
%>
       lCxSymbolTabObjJSArr = new Array(<%=lCxSymbolTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxSymbolTabObjArrCache.size(); lRecNum++ )
       {
          CxSymbolTabObj lCxSymbolTabObj    =    new CxSymbolTabObj();
          lCxSymbolTabObj = (CxSymbolTabObj)lCxSymbolTabObjArrCache.get(lRecNum);
%>
          lCxSymbolTabObjJSArr[<%=lRecNum%>] = new constructorCxSymbol
          (
          "<%=lCxSymbolTabObj.org_id%>",
          "<%=lCxSymbolTabObj.symbol_cd%>",
          "<%=lCxSymbolTabObj.symbol_name%>",
          "<%=lCxSymbolTabObj.status%>",
          "<%=lCxSymbolTabObj.rec_cre_date%>",
          "<%=lCxSymbolTabObj.rec_cre_time%>",
          "<%=lCxSymbolTabObj.rec_upd_date%>",
          "<%=lCxSymbolTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


