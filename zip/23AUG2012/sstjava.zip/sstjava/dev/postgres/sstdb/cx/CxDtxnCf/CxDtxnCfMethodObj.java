package sstdb.cx.CxDtxnCf;

import sstdb.cx.CxDtxnCf.CxDtxnCfTabObj;
import sstdb.cx.CxDtxnCf.CxDtxnCfPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxDtxnCfMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxDtxnCfMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxDtxnCfMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxDtxnCfTabObj
               ( 
                 CxDtxnCfTabObj  outCxDtxnCfTabObj
               )
  {
  
     outCxDtxnCfTabObj.org_id = ""; 
     outCxDtxnCfTabObj.txn_num = ""; 
     outCxDtxnCfTabObj.txn_date = ""; 
     outCxDtxnCfTabObj.txn_time = ""; 
     outCxDtxnCfTabObj.txn_type = ""; 
     outCxDtxnCfTabObj.link_txn_num = ""; 
     outCxDtxnCfTabObj.link_txn_date = ""; 
     outCxDtxnCfTabObj.link_txn_time = ""; 
     outCxDtxnCfTabObj.member_id = ""; 
     outCxDtxnCfTabObj.member_name = ""; 
     outCxDtxnCfTabObj.contract_id = ""; 
     outCxDtxnCfTabObj.symbol_cd = ""; 
     outCxDtxnCfTabObj.qty = (int)0; 
     outCxDtxnCfTabObj.rate = (double)0.00; 
     outCxDtxnCfTabObj.status = ""; 
     outCxDtxnCfTabObj.rec_cre_date = ""; 
     outCxDtxnCfTabObj.rec_cre_time = ""; 
     outCxDtxnCfTabObj.rec_upd_date = ""; 
     outCxDtxnCfTabObj.rec_upd_time = ""; 
  }





  public void guiDateConvCxDtxnCfTabObj
               ( 
                 CxDtxnCfTabObj  inCxDtxnCfTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxDtxnCfTabObj.txn_date != null && inCxDtxnCfTabObj.txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);

          if ( inCxDtxnCfTabObj.link_txn_date != null && inCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);

          if ( inCxDtxnCfTabObj.rec_cre_date != null && inCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxDtxnCfTabObj.rec_upd_date != null && inCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxDtxnCfByTabObj
               ( 
                 CxDtxnCfTabObj  inCxDtxnCfTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxDtxnCfTabObjArrCtx  = new ArrayList(); 
    lCxDtxnCfTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxDtxnCfTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxDtxnCfTabObjArrCtx.add(inCxDtxnCfTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxDtxnCfTabObjArrCtx.size();  lRecNum++ )
      {
        CxDtxnCfTabObj lCxDtxnCfTabObj = new CxDtxnCfTabObj();
        lCxDtxnCfTabObj = (CxDtxnCfTabObj)lCxDtxnCfTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxDtxnCfTabObj.org_id.equals(lCxDtxnCfTabObj.org_id) &&
              lCxDtxnCfTabObj.txn_num.equals(lCxDtxnCfTabObj.txn_num) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxDtxnCfTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxDtxnCfTabObjArrCtx.set(lRecNum, inCxDtxnCfTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxDtxnCfTabObjArrCtx",lCxDtxnCfTabObjArrCtx);
  }





  public void sortCxDtxnCfTabObjArr
               ( 
                 ArrayList  inCxDtxnCfTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxDtxnCfTabObjArr  = new ArrayList(); 
     lCxDtxnCfTabObjArr = inCxDtxnCfTabObjArr; 
     List lCxDtxnCfTabObjList  = new ArrayList(lCxDtxnCfTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxDtxnCfTabObjArr.size();  lRecNum++ )
     {
       CxDtxnCfTabObj  lCxDtxnCfTabObj = new CxDtxnCfTabObj(); 
       lCxDtxnCfTabObj = (CxDtxnCfTabObj)lCxDtxnCfTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxDtxnCfTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnCfTabObj.txn_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.txn_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnCfTabObj.txn_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.txn_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnCfTabObj.txn_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.txn_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("txn_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxDtxnCfTabObj.txn_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.txn_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("link_txn_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnCfTabObj.link_txn_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.link_txn_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("link_txn_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnCfTabObj.link_txn_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.link_txn_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("link_txn_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnCfTabObj.link_txn_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.link_txn_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnCfTabObj.member_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.member_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("member_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxDtxnCfTabObj.member_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.member_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("contract_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnCfTabObj.contract_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.contract_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_cd") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxDtxnCfTabObj.symbol_cd.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.symbol_cd+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lCxDtxnCfTabObj.qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxDtxnCfTabObj.rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxDtxnCfTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnCfTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnCfTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxDtxnCfTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxDtxnCfTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxDtxnCfTabObj.rec_upd_time+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxDtxnCfTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxDtxnCfTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxDtxnCfTabObjList ); 
     ArrayList lCxDtxnCfTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxDtxnCfTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxDtxnCfTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxDtxnCfTabObjArrSorted.add( (CxDtxnCfTabObj)lCxDtxnCfTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxDtxnCfTabObjArr.size();  lRecNum++ )
     {
       inCxDtxnCfTabObjArr.set( lRecNum, (CxDtxnCfTabObj)lCxDtxnCfTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxDtxnCfTabObj
               ( 
                 CxDtxnCfTabObj  inCxDtxnCfTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxDtxnCfTabObj.txn_date != null && inCxDtxnCfTabObj.txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.link_txn_date != null && inCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.link_txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_cre_date != null && inCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_upd_date != null && inCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTxnType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TXN_TYPE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLinkTxnNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LINK_TXN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLinkTxnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LINK_TXN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLinkTxnTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LINK_TXN_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMemberName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MEMBER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeContractId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CONTRACT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolCd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_CD";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxDtxnCfCount
               ( String inCxDtxnCfWhereText
               )
  {
    sop("gtCxDtxnCfCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfCount
               ( String inCxDtxnCfWhereText
               , String inCxDtxnCfSelectFieldList
               )
  {
    sop("gtCxDtxnCfCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxDtxnCfSelectFieldList+" AS count "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfRecByPkey
               ( CxDtxnCfPkeyObj inCxDtxnCfPkeyObj
               , CxDtxnCfTabObj  outCxDtxnCfTabObj
               )
  {
    sop("gtCxDtxnCfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "link_txn_num, "+
                                 "link_txn_date, "+
                                 "link_txn_time, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "rate, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN_CF " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnCfPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnCfPkeyObj.txn_num+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxDtxnCfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxDtxnCfTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxDtxnCfTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          outCxDtxnCfTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( outCxDtxnCfTabObj.txn_date != null && outCxDtxnCfTabObj.txn_date.length() > 0 ) 
            outCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          outCxDtxnCfTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          outCxDtxnCfTabObj.link_txn_num  =  lResultSet.getString("LINK_TXN_NUM");
          outCxDtxnCfTabObj.link_txn_date  =  lResultSet.getString("LINK_TXN_DATE");

          if ( outCxDtxnCfTabObj.link_txn_date != null && outCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            outCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.link_txn_time  =  lResultSet.getString("LINK_TXN_TIME");
          outCxDtxnCfTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxDtxnCfTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxDtxnCfTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxDtxnCfTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxDtxnCfTabObj.qty  =  lResultSet.getInt("QTY");
          outCxDtxnCfTabObj.rate  =  lResultSet.getDouble("RATE");
          outCxDtxnCfTabObj.status  =  lResultSet.getString("STATUS");
          outCxDtxnCfTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxDtxnCfTabObj.rec_cre_date != null && outCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            outCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxDtxnCfTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxDtxnCfTabObj.rec_upd_date != null && outCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            outCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxDtxnCfTabObj( outCxDtxnCfTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfArr
               ( CxDtxnCfPkeyObj inCxDtxnCfPkeyObj
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {
    sop("gtCxDtxnCfArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "link_txn_num, "+
                                 "link_txn_date, "+
                                 "link_txn_time, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "rate, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN_CF";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxDtxnCfTabObj  lCxDtxnCfTabObj = new CxDtxnCfTabObj();
          lCxDtxnCfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxDtxnCfTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxDtxnCfTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          lCxDtxnCfTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( lCxDtxnCfTabObj.txn_date != null && lCxDtxnCfTabObj.txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          lCxDtxnCfTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          lCxDtxnCfTabObj.link_txn_num  =  lResultSet.getString("LINK_TXN_NUM");
          lCxDtxnCfTabObj.link_txn_date  =  lResultSet.getString("LINK_TXN_DATE");

          if ( lCxDtxnCfTabObj.link_txn_date != null && lCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.link_txn_time  =  lResultSet.getString("LINK_TXN_TIME");
          lCxDtxnCfTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxDtxnCfTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxDtxnCfTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxDtxnCfTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxDtxnCfTabObj.qty  =  lResultSet.getInt("QTY");
          lCxDtxnCfTabObj.rate  =  lResultSet.getDouble("RATE");
          lCxDtxnCfTabObj.status  =  lResultSet.getString("STATUS");
          lCxDtxnCfTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxDtxnCfTabObj.rec_cre_date != null && lCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxDtxnCfTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxDtxnCfTabObj.rec_upd_date != null && lCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxDtxnCfTabObj( lCxDtxnCfTabObj );

          outCxDtxnCfTabObjArr.add(  lCxDtxnCfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnCfTabObjArr != null && outCxDtxnCfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxDtxnCfArr2XML
               ( String inCxDtxnCfWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxDtxnCfArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxDtxnCf>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_num") )
              lXmlBuffer = lXmlBuffer +   "<TXN_NUM>" +  lResultSet.getString("TXN_NUM") +   "</TXN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_date") )
              lXmlBuffer = lXmlBuffer +   "<TXN_DATE>" +  lResultSet.getString("TXN_DATE") +   "</TXN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_time") )
              lXmlBuffer = lXmlBuffer +   "<TXN_TIME>" +  lResultSet.getString("TXN_TIME") +   "</TXN_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("txn_type") )
              lXmlBuffer = lXmlBuffer +   "<TXN_TYPE>" +  lResultSet.getString("TXN_TYPE") +   "</TXN_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("link_txn_num") )
              lXmlBuffer = lXmlBuffer +   "<LINK_TXN_NUM>" +  lResultSet.getString("LINK_TXN_NUM") +   "</LINK_TXN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("link_txn_date") )
              lXmlBuffer = lXmlBuffer +   "<LINK_TXN_DATE>" +  lResultSet.getString("LINK_TXN_DATE") +   "</LINK_TXN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("link_txn_time") )
              lXmlBuffer = lXmlBuffer +   "<LINK_TXN_TIME>" +  lResultSet.getString("LINK_TXN_TIME") +   "</LINK_TXN_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_id") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_ID>" +  lResultSet.getString("MEMBER_ID") +   "</MEMBER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("member_name") )
              lXmlBuffer = lXmlBuffer +   "<MEMBER_NAME>" +  lResultSet.getString("MEMBER_NAME") +   "</MEMBER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("contract_id") )
              lXmlBuffer = lXmlBuffer +   "<CONTRACT_ID>" +  lResultSet.getString("CONTRACT_ID") +   "</CONTRACT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_cd") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_CD>" +  lResultSet.getString("SYMBOL_CD") +   "</SYMBOL_CD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("qty") )
              lXmlBuffer = lXmlBuffer +   "<QTY>" +  lResultSet.getInt("QTY") +   "</QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate") )
              lXmlBuffer = lXmlBuffer +   "<RATE>" +  lResultSet.getDouble("RATE") +   "</RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxDtxnCf>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxDtxnCfRecByRowid
               ( String inRowId
               , CxDtxnCfTabObj  outCxDtxnCfTabObj
               )
  {
    sop("gtCxDtxnCfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "link_txn_num, "+
                                 "link_txn_date, "+
                                 "link_txn_time, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "rate, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN_CF "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxDtxnCfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxDtxnCfTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxDtxnCfTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          outCxDtxnCfTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( outCxDtxnCfTabObj.txn_date != null && outCxDtxnCfTabObj.txn_date.length() > 0 ) 
            outCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          outCxDtxnCfTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          outCxDtxnCfTabObj.link_txn_num  =  lResultSet.getString("LINK_TXN_NUM");
          outCxDtxnCfTabObj.link_txn_date  =  lResultSet.getString("LINK_TXN_DATE");

          if ( outCxDtxnCfTabObj.link_txn_date != null && outCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            outCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.link_txn_time  =  lResultSet.getString("LINK_TXN_TIME");
          outCxDtxnCfTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          outCxDtxnCfTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          outCxDtxnCfTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxDtxnCfTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxDtxnCfTabObj.qty  =  lResultSet.getInt("QTY");
          outCxDtxnCfTabObj.rate  =  lResultSet.getDouble("RATE");
          outCxDtxnCfTabObj.status  =  lResultSet.getString("STATUS");
          outCxDtxnCfTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxDtxnCfTabObj.rec_cre_date != null && outCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            outCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxDtxnCfTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxDtxnCfTabObj.rec_upd_date != null && outCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            outCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxDtxnCfTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxDtxnCfTabObj( outCxDtxnCfTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfArr
               ( String inCxDtxnCfWhereText
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {
    sop("gtCxDtxnCfArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "txn_num, "+
                                 "txn_date, "+
                                 "txn_time, "+
                                 "txn_type, "+
                                 "link_txn_num, "+
                                 "link_txn_date, "+
                                 "link_txn_time, "+
                                 "member_id, "+
                                 "member_name, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "qty, "+
                                 "rate, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxDtxnCfTabObj  lCxDtxnCfTabObj = new CxDtxnCfTabObj();
          lCxDtxnCfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxDtxnCfTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxDtxnCfTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
          lCxDtxnCfTabObj.txn_date  =  lResultSet.getString("TXN_DATE");

          if ( lCxDtxnCfTabObj.txn_date != null && lCxDtxnCfTabObj.txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
          lCxDtxnCfTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
          lCxDtxnCfTabObj.link_txn_num  =  lResultSet.getString("LINK_TXN_NUM");
          lCxDtxnCfTabObj.link_txn_date  =  lResultSet.getString("LINK_TXN_DATE");

          if ( lCxDtxnCfTabObj.link_txn_date != null && lCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.link_txn_time  =  lResultSet.getString("LINK_TXN_TIME");
          lCxDtxnCfTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
          lCxDtxnCfTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
          lCxDtxnCfTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxDtxnCfTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxDtxnCfTabObj.qty  =  lResultSet.getInt("QTY");
          lCxDtxnCfTabObj.rate  =  lResultSet.getDouble("RATE");
          lCxDtxnCfTabObj.status  =  lResultSet.getString("STATUS");
          lCxDtxnCfTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxDtxnCfTabObj.rec_cre_date != null && lCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxDtxnCfTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxDtxnCfTabObj.rec_upd_date != null && lCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxDtxnCfTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxDtxnCfTabObj( lCxDtxnCfTabObj );

          outCxDtxnCfTabObjArr.add(  lCxDtxnCfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnCfTabObjArr != null && outCxDtxnCfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfArrDist
               ( String inCxDtxnCfWhereText
               , String inDistCxDtxnCfField
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {

    sop("gtCxDtxnCfArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";
  

       String lDistCxDtxnCfFieldQry = inDistCxDtxnCfField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxDtxnCfFieldQry+
                         " FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxDtxnCfField.substring(inDistCxDtxnCfField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxDtxnCfTabObj  lCxDtxnCfTabObj = new CxDtxnCfTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxDtxnCfTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_num") )
              lCxDtxnCfTabObj.txn_num  =  lResultSet.getString("TXN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_date") )
              {
              lCxDtxnCfTabObj.txn_date  =  lResultSet.getString("TXN_DATE");
  
          if ( lCxDtxnCfTabObj.txn_date != null && lCxDtxnCfTabObj.txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.txn_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_time") )
              lCxDtxnCfTabObj.txn_time  =  lResultSet.getString("TXN_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("txn_type") )
              lCxDtxnCfTabObj.txn_type  =  lResultSet.getString("TXN_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("link_txn_num") )
              lCxDtxnCfTabObj.link_txn_num  =  lResultSet.getString("LINK_TXN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("link_txn_date") )
              {
              lCxDtxnCfTabObj.link_txn_date  =  lResultSet.getString("LINK_TXN_DATE");
  
          if ( lCxDtxnCfTabObj.link_txn_date != null && lCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.link_txn_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("link_txn_time") )
              lCxDtxnCfTabObj.link_txn_time  =  lResultSet.getString("LINK_TXN_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_id") )
              lCxDtxnCfTabObj.member_id  =  lResultSet.getString("MEMBER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("member_name") )
              lCxDtxnCfTabObj.member_name  =  lResultSet.getString("MEMBER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("contract_id") )
              lCxDtxnCfTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_cd") )
              lCxDtxnCfTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("qty") )
              lCxDtxnCfTabObj.qty  =  lResultSet.getInt("QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate") )
              lCxDtxnCfTabObj.rate  =  lResultSet.getDouble("RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxDtxnCfTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxDtxnCfTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxDtxnCfTabObj.rec_cre_date != null && lCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxDtxnCfTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxDtxnCfTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxDtxnCfTabObj.rec_upd_date != null && lCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxDtxnCfTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxDtxnCfTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          }
          removeNullCxDtxnCfTabObj( lCxDtxnCfTabObj );

          outCxDtxnCfTabObjArr.add(  lCxDtxnCfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnCfTabObjArr != null && outCxDtxnCfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxDtxnCfStrArrDist
               ( String inCxDtxnCfWhereText
               , String inDistCxDtxnCfField
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {

    sop("gtCxDtxnCfStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxDtxnCfStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";
  

       String lDistCxDtxnCfFieldQry = inDistCxDtxnCfField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxDtxnCfFieldQry+
                         " FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxDtxnCfField.substring(inDistCxDtxnCfField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxDtxnCfTabObjStr = "";
       while(lResultSet.next())
       {
          lCxDtxnCfTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxDtxnCfTabObjStr =   lCxDtxnCfTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxDtxnCfTabObjArr.add(  lCxDtxnCfTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxDtxnCfTabObjArr != null && outCxDtxnCfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxDtxnCf
               ( String inCxDtxnCfWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxDtxnCf - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxDtxnCf";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxDtxnCfTabObj
               ( 
                 CxDtxnCfTabObj  outCxDtxnCfTabObj
               )
  {
  
    if ( outCxDtxnCfTabObj.org_id == null ) 
     outCxDtxnCfTabObj.org_id = ""; 
    if ( outCxDtxnCfTabObj.txn_num == null ) 
     outCxDtxnCfTabObj.txn_num = ""; 
    if ( outCxDtxnCfTabObj.txn_date == null ) 
     outCxDtxnCfTabObj.txn_date = ""; 
    if ( outCxDtxnCfTabObj.txn_time == null ) 
     outCxDtxnCfTabObj.txn_time = ""; 
    if ( outCxDtxnCfTabObj.txn_type == null ) 
     outCxDtxnCfTabObj.txn_type = ""; 
    if ( outCxDtxnCfTabObj.link_txn_num == null ) 
     outCxDtxnCfTabObj.link_txn_num = ""; 
    if ( outCxDtxnCfTabObj.link_txn_date == null ) 
     outCxDtxnCfTabObj.link_txn_date = ""; 
    if ( outCxDtxnCfTabObj.link_txn_time == null ) 
     outCxDtxnCfTabObj.link_txn_time = ""; 
    if ( outCxDtxnCfTabObj.member_id == null ) 
     outCxDtxnCfTabObj.member_id = ""; 
    if ( outCxDtxnCfTabObj.member_name == null ) 
     outCxDtxnCfTabObj.member_name = ""; 
    if ( outCxDtxnCfTabObj.contract_id == null ) 
     outCxDtxnCfTabObj.contract_id = ""; 
    if ( outCxDtxnCfTabObj.symbol_cd == null ) 
     outCxDtxnCfTabObj.symbol_cd = ""; 
    if ( outCxDtxnCfTabObj.qty == (int)0 ) 
     outCxDtxnCfTabObj.qty = (int)0; 
    if ( outCxDtxnCfTabObj.rate == (double)0.00 ) 
     outCxDtxnCfTabObj.rate = (double)0.00; 
    if ( outCxDtxnCfTabObj.status == null ) 
     outCxDtxnCfTabObj.status = ""; 
    if ( outCxDtxnCfTabObj.rec_cre_date == null ) 
     outCxDtxnCfTabObj.rec_cre_date = ""; 
    if ( outCxDtxnCfTabObj.rec_cre_time == null ) 
     outCxDtxnCfTabObj.rec_cre_time = ""; 
    if ( outCxDtxnCfTabObj.rec_upd_date == null ) 
     outCxDtxnCfTabObj.rec_upd_date = ""; 
    if ( outCxDtxnCfTabObj.rec_upd_time == null ) 
     outCxDtxnCfTabObj.rec_upd_time = ""; 
  }





  public int insCxDtxnCfRec
               ( CxDtxnCfTabObj  inCxDtxnCfTabObj )
  {
    int lUpdateCount;
    sop("insCxDtxnCfRec - Started");
    gSSTErrorObj.sourceMethod = "insCxDtxnCfRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnCfTabObj.txn_date != null && inCxDtxnCfTabObj.txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.link_txn_date != null && inCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.link_txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_cre_date != null && inCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_upd_date != null && inCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_DTXN_CF"+
                        "("+
                                "org_id,"+
                                "txn_num,"+
                                "txn_date,"+
                                "txn_time,"+
                                "txn_type,"+
                                "link_txn_num,"+
                                "link_txn_date,"+
                                "link_txn_time,"+
                                "member_id,"+
                                "member_name,"+
                                "contract_id,"+
                                "symbol_cd,"+
                                "qty,"+
                                "rate,"+
                                "status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.txn_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.txn_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.txn_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.txn_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.link_txn_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.link_txn_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.link_txn_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.member_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.member_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.contract_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.symbol_cd+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnCfTabObj.qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxDtxnCfTabObj.rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxDtxnCfTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inCxDtxnCfTabObj.rec_upd_time+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxDtxnCfTabObj.org_id);
        lPreparedStatement.setString(2, inCxDtxnCfTabObj.txn_num);
        lPreparedStatement.setString(3, inCxDtxnCfTabObj.txn_date);
        lPreparedStatement.setString(4, inCxDtxnCfTabObj.txn_time);
        lPreparedStatement.setString(5, inCxDtxnCfTabObj.txn_type);
        lPreparedStatement.setString(6, inCxDtxnCfTabObj.link_txn_num);
        lPreparedStatement.setString(7, inCxDtxnCfTabObj.link_txn_date);
        lPreparedStatement.setString(8, inCxDtxnCfTabObj.link_txn_time);
        lPreparedStatement.setString(9, inCxDtxnCfTabObj.member_id);
        lPreparedStatement.setString(10, inCxDtxnCfTabObj.member_name);
        lPreparedStatement.setString(11, inCxDtxnCfTabObj.contract_id);
        lPreparedStatement.setString(12, inCxDtxnCfTabObj.symbol_cd);
          lPreparedStatement.setInt(13, inCxDtxnCfTabObj.qty);
          lPreparedStatement.setDouble(14, inCxDtxnCfTabObj.rate);
        lPreparedStatement.setString(15, inCxDtxnCfTabObj.status);
        lPreparedStatement.setString(16, inCxDtxnCfTabObj.rec_cre_date);
        lPreparedStatement.setString(17, inCxDtxnCfTabObj.rec_cre_time);
        lPreparedStatement.setString(18, inCxDtxnCfTabObj.rec_upd_date);
        lPreparedStatement.setString(19, inCxDtxnCfTabObj.rec_upd_time);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxDtxnCfArr
               ( ArrayList  inCxDtxnCfTabObjArr 
               , String  inRowidFlag )
  {
    CxDtxnCfTabObj  lCxDtxnCfTabObj = new CxDtxnCfTabObj();
    int lUpdateCount;
    sop("insCxDtxnCfArr - Started");
    gSSTErrorObj.sourceMethod = "insCxDtxnCfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxDtxnCfTabObjArr.size(); lNumRec++ )
      {
        lCxDtxnCfTabObj = (CxDtxnCfTabObj)inCxDtxnCfTabObjArr.get(lNumRec);

          if ( lCxDtxnCfTabObj.txn_date != null && lCxDtxnCfTabObj.txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnCfTabObj.txn_date, lDateTimeSrcFmt);

          if ( lCxDtxnCfTabObj.link_txn_date != null && lCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            lCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnCfTabObj.link_txn_date, lDateTimeSrcFmt);

          if ( lCxDtxnCfTabObj.rec_cre_date != null && lCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnCfTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxDtxnCfTabObj.rec_upd_date != null && lCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            lCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxDtxnCfTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_DTXN_CF"+
                        "("+
                        "org_id,"+
                        "txn_num,"+
                        "txn_date,"+
                        "txn_time,"+
                        "txn_type,"+
                        "link_txn_num,"+
                        "link_txn_date,"+
                        "link_txn_time,"+
                        "member_id,"+
                        "member_name,"+
                        "contract_id,"+
                        "symbol_cd,"+
                        "qty,"+
                        "rate,"+
                        "status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.txn_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.txn_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.txn_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.txn_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.link_txn_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.link_txn_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.link_txn_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.member_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.member_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.contract_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.symbol_cd+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnCfTabObj.qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxDtxnCfTabObj.rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxDtxnCfTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lCxDtxnCfTabObj.rec_upd_time+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxDtxnCfTabObj.org_id);
            lPreparedStatement.setString(2, lCxDtxnCfTabObj.txn_num);
            lPreparedStatement.setString(3, lCxDtxnCfTabObj.txn_date);
            lPreparedStatement.setString(4, lCxDtxnCfTabObj.txn_time);
            lPreparedStatement.setString(5, lCxDtxnCfTabObj.txn_type);
            lPreparedStatement.setString(6, lCxDtxnCfTabObj.link_txn_num);
            lPreparedStatement.setString(7, lCxDtxnCfTabObj.link_txn_date);
            lPreparedStatement.setString(8, lCxDtxnCfTabObj.link_txn_time);
            lPreparedStatement.setString(9, lCxDtxnCfTabObj.member_id);
            lPreparedStatement.setString(10, lCxDtxnCfTabObj.member_name);
            lPreparedStatement.setString(11, lCxDtxnCfTabObj.contract_id);
            lPreparedStatement.setString(12, lCxDtxnCfTabObj.symbol_cd);
              lPreparedStatement.setInt(13, lCxDtxnCfTabObj.qty);
              lPreparedStatement.setDouble(14, lCxDtxnCfTabObj.rate);
            lPreparedStatement.setString(15, lCxDtxnCfTabObj.status);
            lPreparedStatement.setString(16, lCxDtxnCfTabObj.rec_cre_date);
            lPreparedStatement.setString(17, lCxDtxnCfTabObj.rec_cre_time);
            lPreparedStatement.setString(18, lCxDtxnCfTabObj.rec_upd_date);
            lPreparedStatement.setString(19, lCxDtxnCfTabObj.rec_upd_time);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxDtxnCfReq2Obj
               ( HttpServletRequest inRequest
               , CxDtxnCfTabObj  outCxDtxnCfTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxDtxnCfTabObj.tab_rowid = lTabRowidValue;

    outCxDtxnCfTabObj.org_id = inRequest.getParameter("org_id");
    outCxDtxnCfTabObj.txn_num = inRequest.getParameter("txn_num");
    outCxDtxnCfTabObj.txn_date = inRequest.getParameter("txn_date");
    outCxDtxnCfTabObj.txn_time = inRequest.getParameter("txn_time");
    outCxDtxnCfTabObj.txn_type = inRequest.getParameter("txn_type");
    outCxDtxnCfTabObj.link_txn_num = inRequest.getParameter("link_txn_num");
    outCxDtxnCfTabObj.link_txn_date = inRequest.getParameter("link_txn_date");
    outCxDtxnCfTabObj.link_txn_time = inRequest.getParameter("link_txn_time");
    outCxDtxnCfTabObj.member_id = inRequest.getParameter("member_id");
    outCxDtxnCfTabObj.member_name = inRequest.getParameter("member_name");
    outCxDtxnCfTabObj.contract_id = inRequest.getParameter("contract_id");
    outCxDtxnCfTabObj.symbol_cd = inRequest.getParameter("symbol_cd");
    if ( inRequest.getParameter("qty") == null )
      outCxDtxnCfTabObj.qty = 0;
    else
    if ( inRequest.getParameter("qty").trim().length() == 0 )
      outCxDtxnCfTabObj.qty = 0;
    else
      outCxDtxnCfTabObj.qty = Integer.parseInt( inRequest.getParameter("qty"));
    if ( inRequest.getParameter("rate") == null )
      outCxDtxnCfTabObj.rate = 0;
    else
    if ( inRequest.getParameter("rate").trim().length() == 0 )
      outCxDtxnCfTabObj.rate = 0;
    else
      outCxDtxnCfTabObj.rate = Double.parseDouble( inRequest.getParameter("rate"));
    outCxDtxnCfTabObj.status = inRequest.getParameter("status");
    outCxDtxnCfTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxDtxnCfTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxDtxnCfTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxDtxnCfTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    return lReturnValue;
  }


  public int popCxDtxnCfReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxDtxnCfTabObj lCxDtxnCfTabObj= new CxDtxnCfTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxDtxnCfTabObj.tab_rowid = lTabRowidValue;

      lCxDtxnCfTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxDtxnCfTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
      lCxDtxnCfTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
      lCxDtxnCfTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
      lCxDtxnCfTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
      lCxDtxnCfTabObj.link_txn_num = inRequest.getParameter("link_txn_num_r"+lNumRec);
      lCxDtxnCfTabObj.link_txn_date = inRequest.getParameter("link_txn_date_r"+lNumRec);
      lCxDtxnCfTabObj.link_txn_time = inRequest.getParameter("link_txn_time_r"+lNumRec);
      lCxDtxnCfTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
      lCxDtxnCfTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
      lCxDtxnCfTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
      lCxDtxnCfTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
      if ( inRequest.getParameter("qty_r"+lNumRec) == null )
        lCxDtxnCfTabObj.qty = 0;
      else
      if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
        lCxDtxnCfTabObj.qty = 0;
      else
        lCxDtxnCfTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
      if ( inRequest.getParameter("rate_r"+lNumRec) == null )
        lCxDtxnCfTabObj.rate = 0;
      else
      if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
        lCxDtxnCfTabObj.rate = 0;
      else
        lCxDtxnCfTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
      lCxDtxnCfTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxDtxnCfTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxDtxnCfTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxDtxnCfTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxDtxnCfTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      outCxDtxnCfTabObjArr.add( lCxDtxnCfTabObj);
    }
    return lReturnValue;
  }


  public int popCxDtxnCfReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxDtxnCfTabObj outCxDtxnCfTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_dtxn_cf_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxDtxnCfTabObj.tab_rowid = lTabRowidValue;

        outCxDtxnCfTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxDtxnCfTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
        outCxDtxnCfTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
        outCxDtxnCfTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
        outCxDtxnCfTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
        outCxDtxnCfTabObj.link_txn_num = inRequest.getParameter("link_txn_num_r"+lNumRec);
        outCxDtxnCfTabObj.link_txn_date = inRequest.getParameter("link_txn_date_r"+lNumRec);
        outCxDtxnCfTabObj.link_txn_time = inRequest.getParameter("link_txn_time_r"+lNumRec);
        outCxDtxnCfTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        outCxDtxnCfTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        outCxDtxnCfTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        outCxDtxnCfTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        if ( inRequest.getParameter("qty_r"+lNumRec) == null )
          outCxDtxnCfTabObj.qty = 0;
        else
        if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
          outCxDtxnCfTabObj.qty = 0;
        else
          outCxDtxnCfTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          outCxDtxnCfTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          outCxDtxnCfTabObj.rate = 0;
        else
          outCxDtxnCfTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        outCxDtxnCfTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxDtxnCfTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxDtxnCfTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxDtxnCfTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxDtxnCfTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popCxDtxnCfReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxDtxnCfTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxDtxnCfTabObj lCxDtxnCfTabObj= new CxDtxnCfTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_dtxn_cf_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxDtxnCfTabObj.tab_rowid = lTabRowidValue;

        lCxDtxnCfTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxDtxnCfTabObj.txn_num = inRequest.getParameter("txn_num_r"+lNumRec);
        lCxDtxnCfTabObj.txn_date = inRequest.getParameter("txn_date_r"+lNumRec);
        lCxDtxnCfTabObj.txn_time = inRequest.getParameter("txn_time_r"+lNumRec);
        lCxDtxnCfTabObj.txn_type = inRequest.getParameter("txn_type_r"+lNumRec);
        lCxDtxnCfTabObj.link_txn_num = inRequest.getParameter("link_txn_num_r"+lNumRec);
        lCxDtxnCfTabObj.link_txn_date = inRequest.getParameter("link_txn_date_r"+lNumRec);
        lCxDtxnCfTabObj.link_txn_time = inRequest.getParameter("link_txn_time_r"+lNumRec);
        lCxDtxnCfTabObj.member_id = inRequest.getParameter("member_id_r"+lNumRec);
        lCxDtxnCfTabObj.member_name = inRequest.getParameter("member_name_r"+lNumRec);
        lCxDtxnCfTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        lCxDtxnCfTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        if ( inRequest.getParameter("qty_r"+lNumRec) == null )
          lCxDtxnCfTabObj.qty = 0;
        else
        if ( inRequest.getParameter("qty_r"+lNumRec).trim().length() == 0 )
          lCxDtxnCfTabObj.qty = 0;
        else
          lCxDtxnCfTabObj.qty = Integer.parseInt( inRequest.getParameter("qty_r"+lNumRec));
        if ( inRequest.getParameter("rate_r"+lNumRec) == null )
          lCxDtxnCfTabObj.rate = 0;
        else
        if ( inRequest.getParameter("rate_r"+lNumRec).trim().length() == 0 )
          lCxDtxnCfTabObj.rate = 0;
        else
            lCxDtxnCfTabObj.rate = Double.parseDouble( inRequest.getParameter("rate_r"+lNumRec));
        lCxDtxnCfTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxDtxnCfTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxDtxnCfTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxDtxnCfTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxDtxnCfTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxDtxnCfTabObjArr.add( lCxDtxnCfTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnCfRecByRowid
               ( String inRowId
               , CxDtxnCfTabObj  inCxDtxnCfTabObj
               )
  {
    int lUpdateCount;
    sop("updCxDtxnCfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnCfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnCfTabObj.txn_date != null && inCxDtxnCfTabObj.txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.link_txn_date != null && inCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.link_txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_cre_date != null && inCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_upd_date != null && inCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN_CF ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxDtxnCfTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxDtxnCfTabObj.org_id+"', ";
      if ( inCxDtxnCfTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = "+"'"+inCxDtxnCfTabObj.txn_num+"', ";
      if ( inCxDtxnCfTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = "+"'"+inCxDtxnCfTabObj.txn_date+"', ";
      if ( inCxDtxnCfTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = "+"'"+inCxDtxnCfTabObj.txn_time+"', ";
      if ( inCxDtxnCfTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = "+"'"+inCxDtxnCfTabObj.txn_type+"', ";
      if ( inCxDtxnCfTabObj.link_txn_num != null  )         lSqlStmt = lSqlStmt + "link_txn_num = "+"'"+inCxDtxnCfTabObj.link_txn_num+"', ";
      if ( inCxDtxnCfTabObj.link_txn_date != null  )         lSqlStmt = lSqlStmt + "link_txn_date = "+"'"+inCxDtxnCfTabObj.link_txn_date+"', ";
      if ( inCxDtxnCfTabObj.link_txn_time != null  )         lSqlStmt = lSqlStmt + "link_txn_time = "+"'"+inCxDtxnCfTabObj.link_txn_time+"', ";
      if ( inCxDtxnCfTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxDtxnCfTabObj.member_id+"', ";
      if ( inCxDtxnCfTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxDtxnCfTabObj.member_name+"', ";
      if ( inCxDtxnCfTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxDtxnCfTabObj.contract_id+"', ";
      if ( inCxDtxnCfTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxDtxnCfTabObj.symbol_cd+"', ";
             lSqlStmt = lSqlStmt + "qty = "+inCxDtxnCfTabObj.qty+", ";
             lSqlStmt = lSqlStmt + "rate = "+inCxDtxnCfTabObj.rate+", ";
      if ( inCxDtxnCfTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxDtxnCfTabObj.status+"', ";
      if ( inCxDtxnCfTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxDtxnCfTabObj.rec_cre_date+"', ";
      if ( inCxDtxnCfTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxDtxnCfTabObj.rec_cre_time+"', ";
      if ( inCxDtxnCfTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxDtxnCfTabObj.rec_upd_date+"', ";
      if ( inCxDtxnCfTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxDtxnCfTabObj.rec_upd_time+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnCfRecByPkey
               ( CxDtxnCfPkeyObj inCxDtxnCfPkeyObj
               , CxDtxnCfTabObj  inCxDtxnCfTabObj
               )
  {
    int lUpdateCount;
    sop("updCxDtxnCfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnCfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxDtxnCfTabObj.txn_date != null && inCxDtxnCfTabObj.txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.link_txn_date != null && inCxDtxnCfTabObj.link_txn_date.length() > 0 ) 
            inCxDtxnCfTabObj.link_txn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.link_txn_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_cre_date != null && inCxDtxnCfTabObj.rec_cre_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxDtxnCfTabObj.rec_upd_date != null && inCxDtxnCfTabObj.rec_upd_date.length() > 0 ) 
            inCxDtxnCfTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxDtxnCfTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN_CF ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxDtxnCfTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxDtxnCfTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = ? , ";
        if ( inCxDtxnCfTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = ? , ";
        if ( inCxDtxnCfTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = ? , ";
        if ( inCxDtxnCfTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = ? , ";
        if ( inCxDtxnCfTabObj.link_txn_num != null  )         lSqlStmt = lSqlStmt + "link_txn_num = ? , ";
        if ( inCxDtxnCfTabObj.link_txn_date != null  )         lSqlStmt = lSqlStmt + "link_txn_date = ? , ";
        if ( inCxDtxnCfTabObj.link_txn_time != null  )         lSqlStmt = lSqlStmt + "link_txn_time = ? , ";
        if ( inCxDtxnCfTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = ? , ";
        if ( inCxDtxnCfTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = ? , ";
        if ( inCxDtxnCfTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = ? , ";
        if ( inCxDtxnCfTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = ? , ";
               lSqlStmt = lSqlStmt + "qty = ? , ";
               lSqlStmt = lSqlStmt + "rate = ? , ";
        if ( inCxDtxnCfTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxDtxnCfTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxDtxnCfTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxDtxnCfTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxDtxnCfTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxDtxnCfTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxDtxnCfTabObj.org_id+"', ";
        if ( inCxDtxnCfTabObj.txn_num != null  )         lSqlStmt = lSqlStmt + "txn_num = "+"'"+inCxDtxnCfTabObj.txn_num+"', ";
        if ( inCxDtxnCfTabObj.txn_date != null  )         lSqlStmt = lSqlStmt + "txn_date = "+"'"+inCxDtxnCfTabObj.txn_date+"', ";
        if ( inCxDtxnCfTabObj.txn_time != null  )         lSqlStmt = lSqlStmt + "txn_time = "+"'"+inCxDtxnCfTabObj.txn_time+"', ";
        if ( inCxDtxnCfTabObj.txn_type != null  )         lSqlStmt = lSqlStmt + "txn_type = "+"'"+inCxDtxnCfTabObj.txn_type+"', ";
        if ( inCxDtxnCfTabObj.link_txn_num != null  )         lSqlStmt = lSqlStmt + "link_txn_num = "+"'"+inCxDtxnCfTabObj.link_txn_num+"', ";
        if ( inCxDtxnCfTabObj.link_txn_date != null  )         lSqlStmt = lSqlStmt + "link_txn_date = "+"'"+inCxDtxnCfTabObj.link_txn_date+"', ";
        if ( inCxDtxnCfTabObj.link_txn_time != null  )         lSqlStmt = lSqlStmt + "link_txn_time = "+"'"+inCxDtxnCfTabObj.link_txn_time+"', ";
        if ( inCxDtxnCfTabObj.member_id != null  )         lSqlStmt = lSqlStmt + "member_id = "+"'"+inCxDtxnCfTabObj.member_id+"', ";
        if ( inCxDtxnCfTabObj.member_name != null  )         lSqlStmt = lSqlStmt + "member_name = "+"'"+inCxDtxnCfTabObj.member_name+"', ";
        if ( inCxDtxnCfTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxDtxnCfTabObj.contract_id+"', ";
        if ( inCxDtxnCfTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxDtxnCfTabObj.symbol_cd+"', ";
               lSqlStmt = lSqlStmt + "qty = "+inCxDtxnCfTabObj.qty+", ";
               lSqlStmt = lSqlStmt + "rate = "+inCxDtxnCfTabObj.rate+", ";
        if ( inCxDtxnCfTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxDtxnCfTabObj.status+"', ";
        if ( inCxDtxnCfTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxDtxnCfTabObj.rec_cre_date+"', ";
        if ( inCxDtxnCfTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxDtxnCfTabObj.rec_cre_time+"', ";
        if ( inCxDtxnCfTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxDtxnCfTabObj.rec_upd_date+"', ";
        if ( inCxDtxnCfTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxDtxnCfTabObj.rec_upd_time+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnCfPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnCfPkeyObj.txn_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxDtxnCfTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.org_id); } 
         if ( inCxDtxnCfTabObj.txn_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.txn_num); } 
         if ( inCxDtxnCfTabObj.txn_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.txn_date); } 
         if ( inCxDtxnCfTabObj.txn_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.txn_time); } 
         if ( inCxDtxnCfTabObj.txn_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.txn_type); } 
         if ( inCxDtxnCfTabObj.link_txn_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.link_txn_num); } 
         if ( inCxDtxnCfTabObj.link_txn_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.link_txn_date); } 
         if ( inCxDtxnCfTabObj.link_txn_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.link_txn_time); } 
         if ( inCxDtxnCfTabObj.member_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.member_id); } 
         if ( inCxDtxnCfTabObj.member_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.member_name); } 
         if ( inCxDtxnCfTabObj.contract_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.contract_id); } 
         if ( inCxDtxnCfTabObj.symbol_cd != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.symbol_cd); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(13, inCxDtxnCfTabObj.qty);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(14, inCxDtxnCfTabObj.rate);
         if ( inCxDtxnCfTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.status); } 
         if ( inCxDtxnCfTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.rec_cre_date); } 
         if ( inCxDtxnCfTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.rec_cre_time); } 
         if ( inCxDtxnCfTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.rec_upd_date); } 
         if ( inCxDtxnCfTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxDtxnCfTabObj.rec_upd_time); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnCfRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxDtxnCfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnCfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_DTXN_CF "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnCfRecByPkeyWithSet
               ( CxDtxnCfPkeyObj inCxDtxnCfPkeyObj
               , String  inCxDtxnCfSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnCfRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnCfRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN_CF ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxDtxnCfSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnCfPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnCfPkeyObj.txn_num+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnCfRecByRowidWithSet
               ( String inRowId
               , String  inCxDtxnCfSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnCfRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnCfRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN_CF ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxDtxnCfSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxDtxnCfRecByWhereWithSet
               ( String inCxDtxnCfWhereText
               , String  inCxDtxnCfSetlist
               )
  {
    int lUpdateCount;
    sop("updCxDtxnCfRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxDtxnCfRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_DTXN_CF ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxDtxnCfSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnCfRecByPkey
               ( CxDtxnCfPkeyObj  inCxDtxnCfPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxDtxnCfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnCfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_DTXN_CF " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxDtxnCfPkeyObj.org_id+"' and "+
                              "txn_num = "+"'"+inCxDtxnCfPkeyObj.txn_num+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxDtxnCfByWhere
               ( String inCxDtxnCfWhereText
               )
  {
    int lUpdateCount;
    sop("delCxDtxnCfByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxDtxnCfByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxDtxnCfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxDtxnCfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_DTXN_CF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
