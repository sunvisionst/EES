
var lCxMemberTabObjJSArr = new Array();
<%
{
   if ( lCxMemberTabObjArrCache != null && lCxMemberTabObjArrCache.size() > 0 )
   {
%>
       lCxMemberTabObjJSArr = new Array(<%=lCxMemberTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxMemberTabObjArrCache.size(); lRecNum++ )
       {
          CxMemberTabObj lCxMemberTabObj    =    new CxMemberTabObj();
          lCxMemberTabObj = (CxMemberTabObj)lCxMemberTabObjArrCache.get(lRecNum);
%>
          lCxMemberTabObjJSArr[<%=lRecNum%>] = new constructorCxMember
          (
          "<%=lCxMemberTabObj.org_id%>",
          "<%=lCxMemberTabObj.member_id%>",
          "<%=lCxMemberTabObj.member_name%>",
          "<%=lCxMemberTabObj.link_member_id%>",
          "<%=lCxMemberTabObj.member_type%>",
          "<%=lCxMemberTabObj.role_type%>",
          "<%=lCxMemberTabObj.remark%>",
          "<%=lCxMemberTabObj.pswd_change_cnt%>",
          "<%=lCxMemberTabObj.pswd_0%>",
          "<%=lCxMemberTabObj.pswd_1%>",
          "<%=lCxMemberTabObj.pswd_2%>",
          "<%=lCxMemberTabObj.pswd_3%>",
          "<%=lCxMemberTabObj.pswd_4%>",
          "<%=lCxMemberTabObj.pswd_5%>",
          "<%=lCxMemberTabObj.pswd_6%>",
          "<%=lCxMemberTabObj.pswd_7%>",
          "<%=lCxMemberTabObj.pswd_8%>",
          "<%=lCxMemberTabObj.pswd_9%>",
          "<%=lCxMemberTabObj.pswd_10%>",
          "<%=lCxMemberTabObj.pswd_11%>",
          "<%=lCxMemberTabObj.pswd_12%>",
          "<%=lCxMemberTabObj.pswd_effective_date%>",
          "<%=lCxMemberTabObj.expiry_period%>",
          "<%=lCxMemberTabObj.hint%>",
          "<%=lCxMemberTabObj.hint_ans%>",
          "<%=lCxMemberTabObj.status%>",
          "<%=lCxMemberTabObj.rec_cre_date%>",
          "<%=lCxMemberTabObj.rec_cre_time%>",
          "<%=lCxMemberTabObj.rec_upd_date%>",
          "<%=lCxMemberTabObj.rec_upd_time%>",
          "<%=lCxMemberTabObj.address_1%>",
          "<%=lCxMemberTabObj.address_2%>",
          "<%=lCxMemberTabObj.city%>",
          "<%=lCxMemberTabObj.state%>",
          "<%=lCxMemberTabObj.zip%>",
          "<%=lCxMemberTabObj.country%>",
          "<%=lCxMemberTabObj.phone_list%>",
          "<%=lCxMemberTabObj.email_list%>",
          "<%=lCxMemberTabObj.fax_list%>",
          "<%=lCxMemberTabObj.auth_rep_name%>",
          "<%=lCxMemberTabObj.auth_rep_father_name%>",
          "<%=lCxMemberTabObj.auth_rep_phone_list%>",
          "<%=lCxMemberTabObj.pd_bal%>",
          "<%=lCxMemberTabObj.cd_bal%>",
          "<%=lCxMemberTabObj.cd_dr%>",
          "<%=lCxMemberTabObj.cd_cr%>",
          "<%=lCxMemberTabObj.cr_limit%>",
          "<%=lCxMemberTabObj.num_client_limit%>"
          );
<%
       }
   }
}
%>


