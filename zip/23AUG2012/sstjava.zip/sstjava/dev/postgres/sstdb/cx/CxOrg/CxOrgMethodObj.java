package sstdb.cx.CxOrg;

import sstdb.cx.CxOrg.CxOrgTabObj;
import sstdb.cx.CxOrg.CxOrgPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxOrgMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxOrgMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxOrgMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxOrgTabObj
               ( 
                 CxOrgTabObj  outCxOrgTabObj
               )
  {
  
     outCxOrgTabObj.org_id = ""; 
     outCxOrgTabObj.org_name = ""; 
     outCxOrgTabObj.related_org_id = ""; 
     outCxOrgTabObj.address_1 = ""; 
     outCxOrgTabObj.address_2 = ""; 
     outCxOrgTabObj.city = ""; 
     outCxOrgTabObj.state = ""; 
     outCxOrgTabObj.zip = ""; 
     outCxOrgTabObj.country = ""; 
     outCxOrgTabObj.org_type = ""; 
     outCxOrgTabObj.org_ctg = ""; 
     outCxOrgTabObj.bus_type = ""; 
     outCxOrgTabObj.phone_list = ""; 
     outCxOrgTabObj.email_list = ""; 
     outCxOrgTabObj.fax_list = ""; 
     outCxOrgTabObj.business_currency = ""; 
     outCxOrgTabObj.effective_date = ""; 
     outCxOrgTabObj.expiration_date = ""; 
     outCxOrgTabObj.org_url = ""; 
     outCxOrgTabObj.logo_file_name = ""; 
     outCxOrgTabObj.employer_reg_num = ""; 
     outCxOrgTabObj.employer_reg_date = ""; 
     outCxOrgTabObj.epf_act_num = ""; 
     outCxOrgTabObj.epf_act_open_dt = ""; 
     outCxOrgTabObj.esi_num = ""; 
     outCxOrgTabObj.esi_act_open_dt = ""; 
     outCxOrgTabObj.pan_num = ""; 
     outCxOrgTabObj.pan_create_date = ""; 
     outCxOrgTabObj.nss_num = ""; 
     outCxOrgTabObj.nss_create_date = ""; 
     outCxOrgTabObj.key_1 = ""; 
     outCxOrgTabObj.key_2 = ""; 
     outCxOrgTabObj.mkey = ""; 
  }





  public void guiDateConvCxOrgTabObj
               ( 
                 CxOrgTabObj  inCxOrgTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxOrgTabObj.effective_date != null && inCxOrgTabObj.effective_date.length() > 0 ) 
            inCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.effective_date, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.expiration_date != null && inCxOrgTabObj.expiration_date.length() > 0 ) 
            inCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.expiration_date, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.employer_reg_date != null && inCxOrgTabObj.employer_reg_date.length() > 0 ) 
            inCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.epf_act_open_dt != null && inCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.esi_act_open_dt != null && inCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.pan_create_date != null && inCxOrgTabObj.pan_create_date.length() > 0 ) 
            inCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);

          if ( inCxOrgTabObj.nss_create_date != null && inCxOrgTabObj.nss_create_date.length() > 0 ) 
            inCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxOrgByTabObj
               ( 
                 CxOrgTabObj  inCxOrgTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxOrgTabObjArrCtx  = new ArrayList(); 
    lCxOrgTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxOrgTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxOrgTabObjArrCtx.add(inCxOrgTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxOrgTabObjArrCtx.size();  lRecNum++ )
      {
        CxOrgTabObj lCxOrgTabObj = new CxOrgTabObj();
        lCxOrgTabObj = (CxOrgTabObj)lCxOrgTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxOrgTabObj.org_id.equals(lCxOrgTabObj.org_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxOrgTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxOrgTabObjArrCtx.set(lRecNum, inCxOrgTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxOrgTabObjArrCtx",lCxOrgTabObjArrCtx);
  }





  public void sortCxOrgTabObjArr
               ( 
                 ArrayList  inCxOrgTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxOrgTabObjArr  = new ArrayList(); 
     lCxOrgTabObjArr = inCxOrgTabObjArr; 
     List lCxOrgTabObjList  = new ArrayList(lCxOrgTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxOrgTabObjArr.size();  lRecNum++ )
     {
       CxOrgTabObj  lCxOrgTabObj = new CxOrgTabObj(); 
       lCxOrgTabObj = (CxOrgTabObj)lCxOrgTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxOrgTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.org_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.org_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("related_org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxOrgTabObj.related_org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.related_org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxOrgTabObj.city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxOrgTabObj.state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxOrgTabObj.zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxOrgTabObj.country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxOrgTabObj.org_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.org_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lCxOrgTabObj.org_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.org_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bus_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxOrgTabObj.bus_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.bus_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.email_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.email_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fax_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.fax_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.fax_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("business_currency") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxOrgTabObj.business_currency.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.business_currency+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("effective_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.effective_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.effective_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("expiration_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.expiration_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.expiration_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_url") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (200 - lCxOrgTabObj.org_url.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.org_url+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("logo_file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lCxOrgTabObj.logo_file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.logo_file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employer_reg_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxOrgTabObj.employer_reg_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.employer_reg_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employer_reg_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.employer_reg_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.employer_reg_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("epf_act_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxOrgTabObj.epf_act_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.epf_act_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("epf_act_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.epf_act_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.epf_act_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxOrgTabObj.esi_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.esi_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_act_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.esi_act_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.esi_act_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxOrgTabObj.pan_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.pan_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_create_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.pan_create_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.pan_create_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("nss_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxOrgTabObj.nss_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.nss_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("nss_create_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxOrgTabObj.nss_create_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.nss_create_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("key_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.key_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.key_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("key_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lCxOrgTabObj.key_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.key_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mkey") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (200 - lCxOrgTabObj.mkey.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxOrgTabObj.mkey+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxOrgTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxOrgTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxOrgTabObjList ); 
     ArrayList lCxOrgTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxOrgTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxOrgTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxOrgTabObjArrSorted.add( (CxOrgTabObj)lCxOrgTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxOrgTabObjArr.size();  lRecNum++ )
     {
       inCxOrgTabObjArr.set( lRecNum, (CxOrgTabObj)lCxOrgTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxOrgTabObj
               ( 
                 CxOrgTabObj  inCxOrgTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxOrgTabObj.effective_date != null && inCxOrgTabObj.effective_date.length() > 0 ) 
            inCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.effective_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.expiration_date != null && inCxOrgTabObj.expiration_date.length() > 0 ) 
            inCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.employer_reg_date != null && inCxOrgTabObj.employer_reg_date.length() > 0 ) 
            inCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.employer_reg_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.epf_act_open_dt != null && inCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.esi_act_open_dt != null && inCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.pan_create_date != null && inCxOrgTabObj.pan_create_date.length() > 0 ) 
            inCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.nss_create_date != null && inCxOrgTabObj.nss_create_date.length() > 0 ) 
            inCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.nss_create_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRelatedOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELATED_ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCity
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeState
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeZip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_TYPE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_CTG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUS_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFaxList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FAX_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusinessCurrency
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUSINESS_CURRENCY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffectiveDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFFECTIVE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpirationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXPIRATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgUrl
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 200 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_URL";
      String lErrorReason = "Size Greater Than 200";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLogoFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LOGO_FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployerRegNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYER_REG_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployerRegDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYER_REG_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEpfActNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EPF_ACT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEpfActOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EPF_ACT_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiActOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_ACT_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanCreateDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_CREATE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNssNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NSS_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNssCreateDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NSS_CREATE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeKey1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "KEY_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeKey2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "KEY_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMkey
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 200 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MKEY";
      String lErrorReason = "Size Greater Than 200";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxOrgCount
               ( String inCxOrgWhereText
               )
  {
    sop("gtCxOrgCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgCount
               ( String inCxOrgWhereText
               , String inCxOrgSelectFieldList
               )
  {
    sop("gtCxOrgCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxOrgSelectFieldList+" AS count "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgRecByPkey
               ( CxOrgPkeyObj inCxOrgPkeyObj
               , CxOrgTabObj  outCxOrgTabObj
               )
  {
    sop("gtCxOrgRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "org_name, "+
                                 "related_org_id, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "org_type, "+
                                 "org_ctg, "+
                                 "bus_type, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "business_currency, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "org_url, "+
                                 "logo_file_name, "+
                                 "employer_reg_num, "+
                                 "employer_reg_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "key_1, "+
                                 "key_2, "+
                                 "mkey "+
                         "FROM   CX_ORG " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxOrgPkeyObj.org_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxOrgTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxOrgTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxOrgTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          outCxOrgTabObj.related_org_id  =  lResultSet.getString("RELATED_ORG_ID");
          outCxOrgTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outCxOrgTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outCxOrgTabObj.city  =  lResultSet.getString("CITY");
          outCxOrgTabObj.state  =  lResultSet.getString("STATE");
          outCxOrgTabObj.zip  =  lResultSet.getString("ZIP");
          outCxOrgTabObj.country  =  lResultSet.getString("COUNTRY");
          outCxOrgTabObj.org_type  =  lResultSet.getString("ORG_TYPE");
          outCxOrgTabObj.org_ctg  =  lResultSet.getString("ORG_CTG");
          outCxOrgTabObj.bus_type  =  lResultSet.getString("BUS_TYPE");
          outCxOrgTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outCxOrgTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outCxOrgTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outCxOrgTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          outCxOrgTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outCxOrgTabObj.effective_date != null && outCxOrgTabObj.effective_date.length() > 0 ) 
            outCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.effective_date, lDateTimeTrgFmt);
          outCxOrgTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outCxOrgTabObj.expiration_date != null && outCxOrgTabObj.expiration_date.length() > 0 ) 
            outCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.expiration_date, lDateTimeTrgFmt);
          outCxOrgTabObj.org_url  =  lResultSet.getString("ORG_URL");
          outCxOrgTabObj.logo_file_name  =  lResultSet.getString("LOGO_FILE_NAME");
          outCxOrgTabObj.employer_reg_num  =  lResultSet.getString("EMPLOYER_REG_NUM");
          outCxOrgTabObj.employer_reg_date  =  lResultSet.getString("EMPLOYER_REG_DATE");

          if ( outCxOrgTabObj.employer_reg_date != null && outCxOrgTabObj.employer_reg_date.length() > 0 ) 
            outCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);
          outCxOrgTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          outCxOrgTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( outCxOrgTabObj.epf_act_open_dt != null && outCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            outCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          outCxOrgTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          outCxOrgTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( outCxOrgTabObj.esi_act_open_dt != null && outCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            outCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          outCxOrgTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outCxOrgTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( outCxOrgTabObj.pan_create_date != null && outCxOrgTabObj.pan_create_date.length() > 0 ) 
            outCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);
          outCxOrgTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          outCxOrgTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( outCxOrgTabObj.nss_create_date != null && outCxOrgTabObj.nss_create_date.length() > 0 ) 
            outCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
          outCxOrgTabObj.key_1  =  lResultSet.getString("KEY_1");
          outCxOrgTabObj.key_2  =  lResultSet.getString("KEY_2");
          outCxOrgTabObj.mkey  =  lResultSet.getString("MKEY");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxOrgTabObj( outCxOrgTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgArr
               ( CxOrgPkeyObj inCxOrgPkeyObj
               , ArrayList  outCxOrgTabObjArr
               )
  {
    sop("gtCxOrgArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "org_name, "+
                                 "related_org_id, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "org_type, "+
                                 "org_ctg, "+
                                 "bus_type, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "business_currency, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "org_url, "+
                                 "logo_file_name, "+
                                 "employer_reg_num, "+
                                 "employer_reg_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "key_1, "+
                                 "key_2, "+
                                 "mkey "+
                         "FROM   CX_ORG";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxOrgTabObj  lCxOrgTabObj = new CxOrgTabObj();
          lCxOrgTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxOrgTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxOrgTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          lCxOrgTabObj.related_org_id  =  lResultSet.getString("RELATED_ORG_ID");
          lCxOrgTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lCxOrgTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lCxOrgTabObj.city  =  lResultSet.getString("CITY");
          lCxOrgTabObj.state  =  lResultSet.getString("STATE");
          lCxOrgTabObj.zip  =  lResultSet.getString("ZIP");
          lCxOrgTabObj.country  =  lResultSet.getString("COUNTRY");
          lCxOrgTabObj.org_type  =  lResultSet.getString("ORG_TYPE");
          lCxOrgTabObj.org_ctg  =  lResultSet.getString("ORG_CTG");
          lCxOrgTabObj.bus_type  =  lResultSet.getString("BUS_TYPE");
          lCxOrgTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lCxOrgTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lCxOrgTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lCxOrgTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          lCxOrgTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lCxOrgTabObj.effective_date != null && lCxOrgTabObj.effective_date.length() > 0 ) 
            lCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.effective_date, lDateTimeTrgFmt);
          lCxOrgTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lCxOrgTabObj.expiration_date != null && lCxOrgTabObj.expiration_date.length() > 0 ) 
            lCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.expiration_date, lDateTimeTrgFmt);
          lCxOrgTabObj.org_url  =  lResultSet.getString("ORG_URL");
          lCxOrgTabObj.logo_file_name  =  lResultSet.getString("LOGO_FILE_NAME");
          lCxOrgTabObj.employer_reg_num  =  lResultSet.getString("EMPLOYER_REG_NUM");
          lCxOrgTabObj.employer_reg_date  =  lResultSet.getString("EMPLOYER_REG_DATE");

          if ( lCxOrgTabObj.employer_reg_date != null && lCxOrgTabObj.employer_reg_date.length() > 0 ) 
            lCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);
          lCxOrgTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          lCxOrgTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( lCxOrgTabObj.epf_act_open_dt != null && lCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          lCxOrgTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          lCxOrgTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( lCxOrgTabObj.esi_act_open_dt != null && lCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          lCxOrgTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lCxOrgTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( lCxOrgTabObj.pan_create_date != null && lCxOrgTabObj.pan_create_date.length() > 0 ) 
            lCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);
          lCxOrgTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          lCxOrgTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( lCxOrgTabObj.nss_create_date != null && lCxOrgTabObj.nss_create_date.length() > 0 ) 
            lCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
          lCxOrgTabObj.key_1  =  lResultSet.getString("KEY_1");
          lCxOrgTabObj.key_2  =  lResultSet.getString("KEY_2");
          lCxOrgTabObj.mkey  =  lResultSet.getString("MKEY");

          removeNullCxOrgTabObj( lCxOrgTabObj );

          outCxOrgTabObjArr.add(  lCxOrgTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxOrgTabObjArr != null && outCxOrgTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxOrgArr2XML
               ( String inCxOrgWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxOrgArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxOrg>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_name") )
              lXmlBuffer = lXmlBuffer +   "<ORG_NAME>" +  lResultSet.getString("ORG_NAME") +   "</ORG_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("related_org_id") )
              lXmlBuffer = lXmlBuffer +   "<RELATED_ORG_ID>" +  lResultSet.getString("RELATED_ORG_ID") +   "</RELATED_ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_1") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_1>" +  lResultSet.getString("ADDRESS_1") +   "</ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_2") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_2>" +  lResultSet.getString("ADDRESS_2") +   "</ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("city") )
              lXmlBuffer = lXmlBuffer +   "<CITY>" +  lResultSet.getString("CITY") +   "</CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("state") )
              lXmlBuffer = lXmlBuffer +   "<STATE>" +  lResultSet.getString("STATE") +   "</STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("zip") )
              lXmlBuffer = lXmlBuffer +   "<ZIP>" +  lResultSet.getString("ZIP") +   "</ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY>" +  lResultSet.getString("COUNTRY") +   "</COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_type") )
              lXmlBuffer = lXmlBuffer +   "<ORG_TYPE>" +  lResultSet.getString("ORG_TYPE") +   "</ORG_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_ctg") )
              lXmlBuffer = lXmlBuffer +   "<ORG_CTG>" +  lResultSet.getString("ORG_CTG") +   "</ORG_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bus_type") )
              lXmlBuffer = lXmlBuffer +   "<BUS_TYPE>" +  lResultSet.getString("BUS_TYPE") +   "</BUS_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone_list") )
              lXmlBuffer = lXmlBuffer +   "<PHONE_LIST>" +  lResultSet.getString("PHONE_LIST") +   "</PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_list") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_LIST>" +  lResultSet.getString("EMAIL_LIST") +   "</EMAIL_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fax_list") )
              lXmlBuffer = lXmlBuffer +   "<FAX_LIST>" +  lResultSet.getString("FAX_LIST") +   "</FAX_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("business_currency") )
              lXmlBuffer = lXmlBuffer +   "<BUSINESS_CURRENCY>" +  lResultSet.getString("BUSINESS_CURRENCY") +   "</BUSINESS_CURRENCY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("effective_date") )
              lXmlBuffer = lXmlBuffer +   "<EFFECTIVE_DATE>" +  lResultSet.getString("EFFECTIVE_DATE") +   "</EFFECTIVE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("expiration_date") )
              lXmlBuffer = lXmlBuffer +   "<EXPIRATION_DATE>" +  lResultSet.getString("EXPIRATION_DATE") +   "</EXPIRATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_url") )
              lXmlBuffer = lXmlBuffer +   "<ORG_URL>" +  lResultSet.getString("ORG_URL") +   "</ORG_URL>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("logo_file_name") )
              lXmlBuffer = lXmlBuffer +   "<LOGO_FILE_NAME>" +  lResultSet.getString("LOGO_FILE_NAME") +   "</LOGO_FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employer_reg_num") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYER_REG_NUM>" +  lResultSet.getString("EMPLOYER_REG_NUM") +   "</EMPLOYER_REG_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employer_reg_date") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYER_REG_DATE>" +  lResultSet.getString("EMPLOYER_REG_DATE") +   "</EMPLOYER_REG_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("epf_act_num") )
              lXmlBuffer = lXmlBuffer +   "<EPF_ACT_NUM>" +  lResultSet.getString("EPF_ACT_NUM") +   "</EPF_ACT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("epf_act_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<EPF_ACT_OPEN_DT>" +  lResultSet.getString("EPF_ACT_OPEN_DT") +   "</EPF_ACT_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_num") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NUM>" +  lResultSet.getString("ESI_NUM") +   "</ESI_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_act_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<ESI_ACT_OPEN_DT>" +  lResultSet.getString("ESI_ACT_OPEN_DT") +   "</ESI_ACT_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_num") )
              lXmlBuffer = lXmlBuffer +   "<PAN_NUM>" +  lResultSet.getString("PAN_NUM") +   "</PAN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_create_date") )
              lXmlBuffer = lXmlBuffer +   "<PAN_CREATE_DATE>" +  lResultSet.getString("PAN_CREATE_DATE") +   "</PAN_CREATE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("nss_num") )
              lXmlBuffer = lXmlBuffer +   "<NSS_NUM>" +  lResultSet.getString("NSS_NUM") +   "</NSS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("nss_create_date") )
              lXmlBuffer = lXmlBuffer +   "<NSS_CREATE_DATE>" +  lResultSet.getString("NSS_CREATE_DATE") +   "</NSS_CREATE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("key_1") )
              lXmlBuffer = lXmlBuffer +   "<KEY_1>" +  lResultSet.getString("KEY_1") +   "</KEY_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("key_2") )
              lXmlBuffer = lXmlBuffer +   "<KEY_2>" +  lResultSet.getString("KEY_2") +   "</KEY_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mkey") )
              lXmlBuffer = lXmlBuffer +   "<MKEY>" +  lResultSet.getString("MKEY") +   "</MKEY>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxOrg>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxOrgRecByRowid
               ( String inRowId
               , CxOrgTabObj  outCxOrgTabObj
               )
  {
    sop("gtCxOrgRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "org_name, "+
                                 "related_org_id, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "org_type, "+
                                 "org_ctg, "+
                                 "bus_type, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "business_currency, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "org_url, "+
                                 "logo_file_name, "+
                                 "employer_reg_num, "+
                                 "employer_reg_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "key_1, "+
                                 "key_2, "+
                                 "mkey "+
                         "FROM   CX_ORG "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxOrgTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxOrgTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxOrgTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          outCxOrgTabObj.related_org_id  =  lResultSet.getString("RELATED_ORG_ID");
          outCxOrgTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outCxOrgTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outCxOrgTabObj.city  =  lResultSet.getString("CITY");
          outCxOrgTabObj.state  =  lResultSet.getString("STATE");
          outCxOrgTabObj.zip  =  lResultSet.getString("ZIP");
          outCxOrgTabObj.country  =  lResultSet.getString("COUNTRY");
          outCxOrgTabObj.org_type  =  lResultSet.getString("ORG_TYPE");
          outCxOrgTabObj.org_ctg  =  lResultSet.getString("ORG_CTG");
          outCxOrgTabObj.bus_type  =  lResultSet.getString("BUS_TYPE");
          outCxOrgTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outCxOrgTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outCxOrgTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outCxOrgTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          outCxOrgTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outCxOrgTabObj.effective_date != null && outCxOrgTabObj.effective_date.length() > 0 ) 
            outCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.effective_date, lDateTimeTrgFmt);
          outCxOrgTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outCxOrgTabObj.expiration_date != null && outCxOrgTabObj.expiration_date.length() > 0 ) 
            outCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.expiration_date, lDateTimeTrgFmt);
          outCxOrgTabObj.org_url  =  lResultSet.getString("ORG_URL");
          outCxOrgTabObj.logo_file_name  =  lResultSet.getString("LOGO_FILE_NAME");
          outCxOrgTabObj.employer_reg_num  =  lResultSet.getString("EMPLOYER_REG_NUM");
          outCxOrgTabObj.employer_reg_date  =  lResultSet.getString("EMPLOYER_REG_DATE");

          if ( outCxOrgTabObj.employer_reg_date != null && outCxOrgTabObj.employer_reg_date.length() > 0 ) 
            outCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);
          outCxOrgTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          outCxOrgTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( outCxOrgTabObj.epf_act_open_dt != null && outCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            outCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          outCxOrgTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          outCxOrgTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( outCxOrgTabObj.esi_act_open_dt != null && outCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            outCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          outCxOrgTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outCxOrgTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( outCxOrgTabObj.pan_create_date != null && outCxOrgTabObj.pan_create_date.length() > 0 ) 
            outCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);
          outCxOrgTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          outCxOrgTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( outCxOrgTabObj.nss_create_date != null && outCxOrgTabObj.nss_create_date.length() > 0 ) 
            outCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
          outCxOrgTabObj.key_1  =  lResultSet.getString("KEY_1");
          outCxOrgTabObj.key_2  =  lResultSet.getString("KEY_2");
          outCxOrgTabObj.mkey  =  lResultSet.getString("MKEY");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxOrgTabObj( outCxOrgTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgArr
               ( String inCxOrgWhereText
               , ArrayList  outCxOrgTabObjArr
               )
  {
    sop("gtCxOrgArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "org_name, "+
                                 "related_org_id, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "org_type, "+
                                 "org_ctg, "+
                                 "bus_type, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "business_currency, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "org_url, "+
                                 "logo_file_name, "+
                                 "employer_reg_num, "+
                                 "employer_reg_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "key_1, "+
                                 "key_2, "+
                                 "mkey "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxOrgTabObj  lCxOrgTabObj = new CxOrgTabObj();
          lCxOrgTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxOrgTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxOrgTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          lCxOrgTabObj.related_org_id  =  lResultSet.getString("RELATED_ORG_ID");
          lCxOrgTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lCxOrgTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lCxOrgTabObj.city  =  lResultSet.getString("CITY");
          lCxOrgTabObj.state  =  lResultSet.getString("STATE");
          lCxOrgTabObj.zip  =  lResultSet.getString("ZIP");
          lCxOrgTabObj.country  =  lResultSet.getString("COUNTRY");
          lCxOrgTabObj.org_type  =  lResultSet.getString("ORG_TYPE");
          lCxOrgTabObj.org_ctg  =  lResultSet.getString("ORG_CTG");
          lCxOrgTabObj.bus_type  =  lResultSet.getString("BUS_TYPE");
          lCxOrgTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lCxOrgTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lCxOrgTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lCxOrgTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          lCxOrgTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lCxOrgTabObj.effective_date != null && lCxOrgTabObj.effective_date.length() > 0 ) 
            lCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.effective_date, lDateTimeTrgFmt);
          lCxOrgTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lCxOrgTabObj.expiration_date != null && lCxOrgTabObj.expiration_date.length() > 0 ) 
            lCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.expiration_date, lDateTimeTrgFmt);
          lCxOrgTabObj.org_url  =  lResultSet.getString("ORG_URL");
          lCxOrgTabObj.logo_file_name  =  lResultSet.getString("LOGO_FILE_NAME");
          lCxOrgTabObj.employer_reg_num  =  lResultSet.getString("EMPLOYER_REG_NUM");
          lCxOrgTabObj.employer_reg_date  =  lResultSet.getString("EMPLOYER_REG_DATE");

          if ( lCxOrgTabObj.employer_reg_date != null && lCxOrgTabObj.employer_reg_date.length() > 0 ) 
            lCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);
          lCxOrgTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          lCxOrgTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( lCxOrgTabObj.epf_act_open_dt != null && lCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          lCxOrgTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          lCxOrgTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( lCxOrgTabObj.esi_act_open_dt != null && lCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          lCxOrgTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lCxOrgTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( lCxOrgTabObj.pan_create_date != null && lCxOrgTabObj.pan_create_date.length() > 0 ) 
            lCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);
          lCxOrgTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          lCxOrgTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( lCxOrgTabObj.nss_create_date != null && lCxOrgTabObj.nss_create_date.length() > 0 ) 
            lCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
          lCxOrgTabObj.key_1  =  lResultSet.getString("KEY_1");
          lCxOrgTabObj.key_2  =  lResultSet.getString("KEY_2");
          lCxOrgTabObj.mkey  =  lResultSet.getString("MKEY");

          removeNullCxOrgTabObj( lCxOrgTabObj );

          outCxOrgTabObjArr.add(  lCxOrgTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxOrgTabObjArr != null && outCxOrgTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgArrDist
               ( String inCxOrgWhereText
               , String inDistCxOrgField
               , ArrayList  outCxOrgTabObjArr
               )
  {

    sop("gtCxOrgArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";
  

       String lDistCxOrgFieldQry = inDistCxOrgField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxOrgFieldQry+
                         " FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxOrgField.substring(inDistCxOrgField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxOrgTabObj  lCxOrgTabObj = new CxOrgTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxOrgTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_name") )
              lCxOrgTabObj.org_name  =  lResultSet.getString("ORG_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("related_org_id") )
              lCxOrgTabObj.related_org_id  =  lResultSet.getString("RELATED_ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_1") )
              lCxOrgTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_2") )
              lCxOrgTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("city") )
              lCxOrgTabObj.city  =  lResultSet.getString("CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("state") )
              lCxOrgTabObj.state  =  lResultSet.getString("STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("zip") )
              lCxOrgTabObj.zip  =  lResultSet.getString("ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country") )
              lCxOrgTabObj.country  =  lResultSet.getString("COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_type") )
              lCxOrgTabObj.org_type  =  lResultSet.getString("ORG_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_ctg") )
              lCxOrgTabObj.org_ctg  =  lResultSet.getString("ORG_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bus_type") )
              lCxOrgTabObj.bus_type  =  lResultSet.getString("BUS_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone_list") )
              lCxOrgTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_list") )
              lCxOrgTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fax_list") )
              lCxOrgTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("business_currency") )
              lCxOrgTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("effective_date") )
              {
              lCxOrgTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
  
          if ( lCxOrgTabObj.effective_date != null && lCxOrgTabObj.effective_date.length() > 0 ) 
            lCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.effective_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("expiration_date") )
              {
              lCxOrgTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
  
          if ( lCxOrgTabObj.expiration_date != null && lCxOrgTabObj.expiration_date.length() > 0 ) 
            lCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.expiration_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_url") )
              lCxOrgTabObj.org_url  =  lResultSet.getString("ORG_URL");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("logo_file_name") )
              lCxOrgTabObj.logo_file_name  =  lResultSet.getString("LOGO_FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employer_reg_num") )
              lCxOrgTabObj.employer_reg_num  =  lResultSet.getString("EMPLOYER_REG_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employer_reg_date") )
              {
              lCxOrgTabObj.employer_reg_date  =  lResultSet.getString("EMPLOYER_REG_DATE");
  
          if ( lCxOrgTabObj.employer_reg_date != null && lCxOrgTabObj.employer_reg_date.length() > 0 ) 
            lCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.employer_reg_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("epf_act_num") )
              lCxOrgTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("epf_act_open_dt") )
              {
              lCxOrgTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");
  
          if ( lCxOrgTabObj.epf_act_open_dt != null && lCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.epf_act_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_num") )
              lCxOrgTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_act_open_dt") )
              {
              lCxOrgTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");
  
          if ( lCxOrgTabObj.esi_act_open_dt != null && lCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.esi_act_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_num") )
              lCxOrgTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_create_date") )
              {
              lCxOrgTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");
  
          if ( lCxOrgTabObj.pan_create_date != null && lCxOrgTabObj.pan_create_date.length() > 0 ) 
            lCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.pan_create_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("nss_num") )
              lCxOrgTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("nss_create_date") )
              {
              lCxOrgTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");
  
          if ( lCxOrgTabObj.nss_create_date != null && lCxOrgTabObj.nss_create_date.length() > 0 ) 
            lCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxOrgTabObj.nss_create_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("key_1") )
              lCxOrgTabObj.key_1  =  lResultSet.getString("KEY_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("key_2") )
              lCxOrgTabObj.key_2  =  lResultSet.getString("KEY_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mkey") )
              lCxOrgTabObj.mkey  =  lResultSet.getString("MKEY");

          }
          removeNullCxOrgTabObj( lCxOrgTabObj );

          outCxOrgTabObjArr.add(  lCxOrgTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxOrgTabObjArr != null && outCxOrgTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxOrgStrArrDist
               ( String inCxOrgWhereText
               , String inDistCxOrgField
               , ArrayList  outCxOrgTabObjArr
               )
  {

    sop("gtCxOrgStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxOrgStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";
  

       String lDistCxOrgFieldQry = inDistCxOrgField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxOrgFieldQry+
                         " FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxOrgField.substring(inDistCxOrgField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxOrgTabObjStr = "";
       while(lResultSet.next())
       {
          lCxOrgTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxOrgTabObjStr =   lCxOrgTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxOrgTabObjArr.add(  lCxOrgTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxOrgTabObjArr != null && outCxOrgTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxOrg
               ( String inCxOrgWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxOrg - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxOrg";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxOrgTabObj
               ( 
                 CxOrgTabObj  outCxOrgTabObj
               )
  {
  
    if ( outCxOrgTabObj.org_id == null ) 
     outCxOrgTabObj.org_id = ""; 
    if ( outCxOrgTabObj.org_name == null ) 
     outCxOrgTabObj.org_name = ""; 
    if ( outCxOrgTabObj.related_org_id == null ) 
     outCxOrgTabObj.related_org_id = ""; 
    if ( outCxOrgTabObj.address_1 == null ) 
     outCxOrgTabObj.address_1 = ""; 
    if ( outCxOrgTabObj.address_2 == null ) 
     outCxOrgTabObj.address_2 = ""; 
    if ( outCxOrgTabObj.city == null ) 
     outCxOrgTabObj.city = ""; 
    if ( outCxOrgTabObj.state == null ) 
     outCxOrgTabObj.state = ""; 
    if ( outCxOrgTabObj.zip == null ) 
     outCxOrgTabObj.zip = ""; 
    if ( outCxOrgTabObj.country == null ) 
     outCxOrgTabObj.country = ""; 
    if ( outCxOrgTabObj.org_type == null ) 
     outCxOrgTabObj.org_type = ""; 
    if ( outCxOrgTabObj.org_ctg == null ) 
     outCxOrgTabObj.org_ctg = ""; 
    if ( outCxOrgTabObj.bus_type == null ) 
     outCxOrgTabObj.bus_type = ""; 
    if ( outCxOrgTabObj.phone_list == null ) 
     outCxOrgTabObj.phone_list = ""; 
    if ( outCxOrgTabObj.email_list == null ) 
     outCxOrgTabObj.email_list = ""; 
    if ( outCxOrgTabObj.fax_list == null ) 
     outCxOrgTabObj.fax_list = ""; 
    if ( outCxOrgTabObj.business_currency == null ) 
     outCxOrgTabObj.business_currency = ""; 
    if ( outCxOrgTabObj.effective_date == null ) 
     outCxOrgTabObj.effective_date = ""; 
    if ( outCxOrgTabObj.expiration_date == null ) 
     outCxOrgTabObj.expiration_date = ""; 
    if ( outCxOrgTabObj.org_url == null ) 
     outCxOrgTabObj.org_url = ""; 
    if ( outCxOrgTabObj.logo_file_name == null ) 
     outCxOrgTabObj.logo_file_name = ""; 
    if ( outCxOrgTabObj.employer_reg_num == null ) 
     outCxOrgTabObj.employer_reg_num = ""; 
    if ( outCxOrgTabObj.employer_reg_date == null ) 
     outCxOrgTabObj.employer_reg_date = ""; 
    if ( outCxOrgTabObj.epf_act_num == null ) 
     outCxOrgTabObj.epf_act_num = ""; 
    if ( outCxOrgTabObj.epf_act_open_dt == null ) 
     outCxOrgTabObj.epf_act_open_dt = ""; 
    if ( outCxOrgTabObj.esi_num == null ) 
     outCxOrgTabObj.esi_num = ""; 
    if ( outCxOrgTabObj.esi_act_open_dt == null ) 
     outCxOrgTabObj.esi_act_open_dt = ""; 
    if ( outCxOrgTabObj.pan_num == null ) 
     outCxOrgTabObj.pan_num = ""; 
    if ( outCxOrgTabObj.pan_create_date == null ) 
     outCxOrgTabObj.pan_create_date = ""; 
    if ( outCxOrgTabObj.nss_num == null ) 
     outCxOrgTabObj.nss_num = ""; 
    if ( outCxOrgTabObj.nss_create_date == null ) 
     outCxOrgTabObj.nss_create_date = ""; 
    if ( outCxOrgTabObj.key_1 == null ) 
     outCxOrgTabObj.key_1 = ""; 
    if ( outCxOrgTabObj.key_2 == null ) 
     outCxOrgTabObj.key_2 = ""; 
    if ( outCxOrgTabObj.mkey == null ) 
     outCxOrgTabObj.mkey = ""; 
  }





  public int insCxOrgRec
               ( CxOrgTabObj  inCxOrgTabObj )
  {
    int lUpdateCount;
    sop("insCxOrgRec - Started");
    gSSTErrorObj.sourceMethod = "insCxOrgRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxOrgTabObj.effective_date != null && inCxOrgTabObj.effective_date.length() > 0 ) 
            inCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.effective_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.expiration_date != null && inCxOrgTabObj.expiration_date.length() > 0 ) 
            inCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.employer_reg_date != null && inCxOrgTabObj.employer_reg_date.length() > 0 ) 
            inCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.employer_reg_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.epf_act_open_dt != null && inCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.esi_act_open_dt != null && inCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.pan_create_date != null && inCxOrgTabObj.pan_create_date.length() > 0 ) 
            inCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.nss_create_date != null && inCxOrgTabObj.nss_create_date.length() > 0 ) 
            inCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.nss_create_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_ORG"+
                        "("+
                                "org_id,"+
                                "org_name,"+
                                "related_org_id,"+
                                "address_1,"+
                                "address_2,"+
                                "city,"+
                                "state,"+
                                "zip,"+
                                "country,"+
                                "org_type,"+
                                "org_ctg,"+
                                "bus_type,"+
                                "phone_list,"+
                                "email_list,"+
                                "fax_list,"+
                                "business_currency,"+
                                "effective_date,"+
                                "expiration_date,"+
                                "org_url,"+
                                "logo_file_name,"+
                                "employer_reg_num,"+
                                "employer_reg_date,"+
                                "epf_act_num,"+
                                "epf_act_open_dt,"+
                                "esi_num,"+
                                "esi_act_open_dt,"+
                                "pan_num,"+
                                "pan_create_date,"+
                                "nss_num,"+
                                "nss_create_date,"+
                                "key_1,"+
                                "key_2,"+
                                "mkey"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.org_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.related_org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.org_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.org_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.bus_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.email_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.fax_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.business_currency+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.effective_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.expiration_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.org_url+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.logo_file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.employer_reg_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.employer_reg_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.epf_act_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.epf_act_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.esi_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.esi_act_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.pan_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.pan_create_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.nss_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.nss_create_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.key_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxOrgTabObj.key_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inCxOrgTabObj.mkey+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxOrgTabObj.org_id);
        lPreparedStatement.setString(2, inCxOrgTabObj.org_name);
        lPreparedStatement.setString(3, inCxOrgTabObj.related_org_id);
        lPreparedStatement.setString(4, inCxOrgTabObj.address_1);
        lPreparedStatement.setString(5, inCxOrgTabObj.address_2);
        lPreparedStatement.setString(6, inCxOrgTabObj.city);
        lPreparedStatement.setString(7, inCxOrgTabObj.state);
        lPreparedStatement.setString(8, inCxOrgTabObj.zip);
        lPreparedStatement.setString(9, inCxOrgTabObj.country);
        lPreparedStatement.setString(10, inCxOrgTabObj.org_type);
        lPreparedStatement.setString(11, inCxOrgTabObj.org_ctg);
        lPreparedStatement.setString(12, inCxOrgTabObj.bus_type);
        lPreparedStatement.setString(13, inCxOrgTabObj.phone_list);
        lPreparedStatement.setString(14, inCxOrgTabObj.email_list);
        lPreparedStatement.setString(15, inCxOrgTabObj.fax_list);
        lPreparedStatement.setString(16, inCxOrgTabObj.business_currency);
        lPreparedStatement.setString(17, inCxOrgTabObj.effective_date);
        lPreparedStatement.setString(18, inCxOrgTabObj.expiration_date);
        lPreparedStatement.setString(19, inCxOrgTabObj.org_url);
        lPreparedStatement.setString(20, inCxOrgTabObj.logo_file_name);
        lPreparedStatement.setString(21, inCxOrgTabObj.employer_reg_num);
        lPreparedStatement.setString(22, inCxOrgTabObj.employer_reg_date);
        lPreparedStatement.setString(23, inCxOrgTabObj.epf_act_num);
        lPreparedStatement.setString(24, inCxOrgTabObj.epf_act_open_dt);
        lPreparedStatement.setString(25, inCxOrgTabObj.esi_num);
        lPreparedStatement.setString(26, inCxOrgTabObj.esi_act_open_dt);
        lPreparedStatement.setString(27, inCxOrgTabObj.pan_num);
        lPreparedStatement.setString(28, inCxOrgTabObj.pan_create_date);
        lPreparedStatement.setString(29, inCxOrgTabObj.nss_num);
        lPreparedStatement.setString(30, inCxOrgTabObj.nss_create_date);
        lPreparedStatement.setString(31, inCxOrgTabObj.key_1);
        lPreparedStatement.setString(32, inCxOrgTabObj.key_2);
        lPreparedStatement.setString(33, inCxOrgTabObj.mkey);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxOrgArr
               ( ArrayList  inCxOrgTabObjArr 
               , String  inRowidFlag )
  {
    CxOrgTabObj  lCxOrgTabObj = new CxOrgTabObj();
    int lUpdateCount;
    sop("insCxOrgArr - Started");
    gSSTErrorObj.sourceMethod = "insCxOrgArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxOrgTabObjArr.size(); lNumRec++ )
      {
        lCxOrgTabObj = (CxOrgTabObj)inCxOrgTabObjArr.get(lNumRec);

          if ( lCxOrgTabObj.effective_date != null && lCxOrgTabObj.effective_date.length() > 0 ) 
            lCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.effective_date, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.expiration_date != null && lCxOrgTabObj.expiration_date.length() > 0 ) 
            lCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.expiration_date, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.employer_reg_date != null && lCxOrgTabObj.employer_reg_date.length() > 0 ) 
            lCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.employer_reg_date, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.epf_act_open_dt != null && lCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.esi_act_open_dt != null && lCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            lCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.pan_create_date != null && lCxOrgTabObj.pan_create_date.length() > 0 ) 
            lCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( lCxOrgTabObj.nss_create_date != null && lCxOrgTabObj.nss_create_date.length() > 0 ) 
            lCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxOrgTabObj.nss_create_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_ORG"+
                        "("+
                        "org_id,"+
                        "org_name,"+
                        "related_org_id,"+
                        "address_1,"+
                        "address_2,"+
                        "city,"+
                        "state,"+
                        "zip,"+
                        "country,"+
                        "org_type,"+
                        "org_ctg,"+
                        "bus_type,"+
                        "phone_list,"+
                        "email_list,"+
                        "fax_list,"+
                        "business_currency,"+
                        "effective_date,"+
                        "expiration_date,"+
                        "org_url,"+
                        "logo_file_name,"+
                        "employer_reg_num,"+
                        "employer_reg_date,"+
                        "epf_act_num,"+
                        "epf_act_open_dt,"+
                        "esi_num,"+
                        "esi_act_open_dt,"+
                        "pan_num,"+
                        "pan_create_date,"+
                        "nss_num,"+
                        "nss_create_date,"+
                        "key_1,"+
                        "key_2,"+
                        "mkey"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.org_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.related_org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.org_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.org_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.bus_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.email_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.fax_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.business_currency+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.effective_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.expiration_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.org_url+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.logo_file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.employer_reg_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.employer_reg_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.epf_act_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.epf_act_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.esi_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.esi_act_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.pan_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.pan_create_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.nss_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.nss_create_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.key_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxOrgTabObj.key_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lCxOrgTabObj.mkey+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxOrgTabObj.org_id);
            lPreparedStatement.setString(2, lCxOrgTabObj.org_name);
            lPreparedStatement.setString(3, lCxOrgTabObj.related_org_id);
            lPreparedStatement.setString(4, lCxOrgTabObj.address_1);
            lPreparedStatement.setString(5, lCxOrgTabObj.address_2);
            lPreparedStatement.setString(6, lCxOrgTabObj.city);
            lPreparedStatement.setString(7, lCxOrgTabObj.state);
            lPreparedStatement.setString(8, lCxOrgTabObj.zip);
            lPreparedStatement.setString(9, lCxOrgTabObj.country);
            lPreparedStatement.setString(10, lCxOrgTabObj.org_type);
            lPreparedStatement.setString(11, lCxOrgTabObj.org_ctg);
            lPreparedStatement.setString(12, lCxOrgTabObj.bus_type);
            lPreparedStatement.setString(13, lCxOrgTabObj.phone_list);
            lPreparedStatement.setString(14, lCxOrgTabObj.email_list);
            lPreparedStatement.setString(15, lCxOrgTabObj.fax_list);
            lPreparedStatement.setString(16, lCxOrgTabObj.business_currency);
            lPreparedStatement.setString(17, lCxOrgTabObj.effective_date);
            lPreparedStatement.setString(18, lCxOrgTabObj.expiration_date);
            lPreparedStatement.setString(19, lCxOrgTabObj.org_url);
            lPreparedStatement.setString(20, lCxOrgTabObj.logo_file_name);
            lPreparedStatement.setString(21, lCxOrgTabObj.employer_reg_num);
            lPreparedStatement.setString(22, lCxOrgTabObj.employer_reg_date);
            lPreparedStatement.setString(23, lCxOrgTabObj.epf_act_num);
            lPreparedStatement.setString(24, lCxOrgTabObj.epf_act_open_dt);
            lPreparedStatement.setString(25, lCxOrgTabObj.esi_num);
            lPreparedStatement.setString(26, lCxOrgTabObj.esi_act_open_dt);
            lPreparedStatement.setString(27, lCxOrgTabObj.pan_num);
            lPreparedStatement.setString(28, lCxOrgTabObj.pan_create_date);
            lPreparedStatement.setString(29, lCxOrgTabObj.nss_num);
            lPreparedStatement.setString(30, lCxOrgTabObj.nss_create_date);
            lPreparedStatement.setString(31, lCxOrgTabObj.key_1);
            lPreparedStatement.setString(32, lCxOrgTabObj.key_2);
            lPreparedStatement.setString(33, lCxOrgTabObj.mkey);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxOrgReq2Obj
               ( HttpServletRequest inRequest
               , CxOrgTabObj  outCxOrgTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxOrgTabObj.tab_rowid = lTabRowidValue;

    outCxOrgTabObj.org_id = inRequest.getParameter("org_id");
    outCxOrgTabObj.org_name = inRequest.getParameter("org_name");
    outCxOrgTabObj.related_org_id = inRequest.getParameter("related_org_id");
    outCxOrgTabObj.address_1 = inRequest.getParameter("address_1");
    outCxOrgTabObj.address_2 = inRequest.getParameter("address_2");
    outCxOrgTabObj.city = inRequest.getParameter("city");
    outCxOrgTabObj.state = inRequest.getParameter("state");
    outCxOrgTabObj.zip = inRequest.getParameter("zip");
    outCxOrgTabObj.country = inRequest.getParameter("country");
    outCxOrgTabObj.org_type = inRequest.getParameter("org_type");
    outCxOrgTabObj.org_ctg = inRequest.getParameter("org_ctg");
    outCxOrgTabObj.bus_type = inRequest.getParameter("bus_type");
    outCxOrgTabObj.phone_list = inRequest.getParameter("phone_list");
    outCxOrgTabObj.email_list = inRequest.getParameter("email_list");
    outCxOrgTabObj.fax_list = inRequest.getParameter("fax_list");
    outCxOrgTabObj.business_currency = inRequest.getParameter("business_currency");
    outCxOrgTabObj.effective_date = inRequest.getParameter("effective_date");
    outCxOrgTabObj.expiration_date = inRequest.getParameter("expiration_date");
    outCxOrgTabObj.org_url = inRequest.getParameter("org_url");
    outCxOrgTabObj.logo_file_name = inRequest.getParameter("logo_file_name");
    outCxOrgTabObj.employer_reg_num = inRequest.getParameter("employer_reg_num");
    outCxOrgTabObj.employer_reg_date = inRequest.getParameter("employer_reg_date");
    outCxOrgTabObj.epf_act_num = inRequest.getParameter("epf_act_num");
    outCxOrgTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt");
    outCxOrgTabObj.esi_num = inRequest.getParameter("esi_num");
    outCxOrgTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt");
    outCxOrgTabObj.pan_num = inRequest.getParameter("pan_num");
    outCxOrgTabObj.pan_create_date = inRequest.getParameter("pan_create_date");
    outCxOrgTabObj.nss_num = inRequest.getParameter("nss_num");
    outCxOrgTabObj.nss_create_date = inRequest.getParameter("nss_create_date");
    outCxOrgTabObj.key_1 = inRequest.getParameter("key_1");
    outCxOrgTabObj.key_2 = inRequest.getParameter("key_2");
    outCxOrgTabObj.mkey = inRequest.getParameter("mkey");
    return lReturnValue;
  }


  public int popCxOrgReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxOrgTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxOrgTabObj lCxOrgTabObj= new CxOrgTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxOrgTabObj.tab_rowid = lTabRowidValue;

      lCxOrgTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxOrgTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
      lCxOrgTabObj.related_org_id = inRequest.getParameter("related_org_id_r"+lNumRec);
      lCxOrgTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
      lCxOrgTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
      lCxOrgTabObj.city = inRequest.getParameter("city_r"+lNumRec);
      lCxOrgTabObj.state = inRequest.getParameter("state_r"+lNumRec);
      lCxOrgTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
      lCxOrgTabObj.country = inRequest.getParameter("country_r"+lNumRec);
      lCxOrgTabObj.org_type = inRequest.getParameter("org_type_r"+lNumRec);
      lCxOrgTabObj.org_ctg = inRequest.getParameter("org_ctg_r"+lNumRec);
      lCxOrgTabObj.bus_type = inRequest.getParameter("bus_type_r"+lNumRec);
      lCxOrgTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
      lCxOrgTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
      lCxOrgTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      lCxOrgTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
      lCxOrgTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
      lCxOrgTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
      lCxOrgTabObj.org_url = inRequest.getParameter("org_url_r"+lNumRec);
      lCxOrgTabObj.logo_file_name = inRequest.getParameter("logo_file_name_r"+lNumRec);
      lCxOrgTabObj.employer_reg_num = inRequest.getParameter("employer_reg_num_r"+lNumRec);
      lCxOrgTabObj.employer_reg_date = inRequest.getParameter("employer_reg_date_r"+lNumRec);
      lCxOrgTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
      lCxOrgTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
      lCxOrgTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
      lCxOrgTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
      lCxOrgTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
      lCxOrgTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
      lCxOrgTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
      lCxOrgTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
      lCxOrgTabObj.key_1 = inRequest.getParameter("key_1_r"+lNumRec);
      lCxOrgTabObj.key_2 = inRequest.getParameter("key_2_r"+lNumRec);
      lCxOrgTabObj.mkey = inRequest.getParameter("mkey_r"+lNumRec);
      outCxOrgTabObjArr.add( lCxOrgTabObj);
    }
    return lReturnValue;
  }


  public int popCxOrgReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxOrgTabObj outCxOrgTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_org_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxOrgTabObj.tab_rowid = lTabRowidValue;

        outCxOrgTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxOrgTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
        outCxOrgTabObj.related_org_id = inRequest.getParameter("related_org_id_r"+lNumRec);
        outCxOrgTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        outCxOrgTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        outCxOrgTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        outCxOrgTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        outCxOrgTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        outCxOrgTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        outCxOrgTabObj.org_type = inRequest.getParameter("org_type_r"+lNumRec);
        outCxOrgTabObj.org_ctg = inRequest.getParameter("org_ctg_r"+lNumRec);
        outCxOrgTabObj.bus_type = inRequest.getParameter("bus_type_r"+lNumRec);
        outCxOrgTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        outCxOrgTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        outCxOrgTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        outCxOrgTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
        outCxOrgTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        outCxOrgTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        outCxOrgTabObj.org_url = inRequest.getParameter("org_url_r"+lNumRec);
        outCxOrgTabObj.logo_file_name = inRequest.getParameter("logo_file_name_r"+lNumRec);
        outCxOrgTabObj.employer_reg_num = inRequest.getParameter("employer_reg_num_r"+lNumRec);
        outCxOrgTabObj.employer_reg_date = inRequest.getParameter("employer_reg_date_r"+lNumRec);
        outCxOrgTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
        outCxOrgTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
        outCxOrgTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
        outCxOrgTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
        outCxOrgTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        outCxOrgTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
        outCxOrgTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
        outCxOrgTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
        outCxOrgTabObj.key_1 = inRequest.getParameter("key_1_r"+lNumRec);
        outCxOrgTabObj.key_2 = inRequest.getParameter("key_2_r"+lNumRec);
        outCxOrgTabObj.mkey = inRequest.getParameter("mkey_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popCxOrgReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxOrgTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxOrgTabObj lCxOrgTabObj= new CxOrgTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_org_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxOrgTabObj.tab_rowid = lTabRowidValue;

        lCxOrgTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxOrgTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
        lCxOrgTabObj.related_org_id = inRequest.getParameter("related_org_id_r"+lNumRec);
        lCxOrgTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        lCxOrgTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        lCxOrgTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        lCxOrgTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        lCxOrgTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        lCxOrgTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        lCxOrgTabObj.org_type = inRequest.getParameter("org_type_r"+lNumRec);
        lCxOrgTabObj.org_ctg = inRequest.getParameter("org_ctg_r"+lNumRec);
        lCxOrgTabObj.bus_type = inRequest.getParameter("bus_type_r"+lNumRec);
        lCxOrgTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        lCxOrgTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        lCxOrgTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        lCxOrgTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
        lCxOrgTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        lCxOrgTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        lCxOrgTabObj.org_url = inRequest.getParameter("org_url_r"+lNumRec);
        lCxOrgTabObj.logo_file_name = inRequest.getParameter("logo_file_name_r"+lNumRec);
        lCxOrgTabObj.employer_reg_num = inRequest.getParameter("employer_reg_num_r"+lNumRec);
        lCxOrgTabObj.employer_reg_date = inRequest.getParameter("employer_reg_date_r"+lNumRec);
        lCxOrgTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
        lCxOrgTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
        lCxOrgTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
        lCxOrgTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
        lCxOrgTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        lCxOrgTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
        lCxOrgTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
        lCxOrgTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
        lCxOrgTabObj.key_1 = inRequest.getParameter("key_1_r"+lNumRec);
        lCxOrgTabObj.key_2 = inRequest.getParameter("key_2_r"+lNumRec);
        lCxOrgTabObj.mkey = inRequest.getParameter("mkey_r"+lNumRec);
        outCxOrgTabObjArr.add( lCxOrgTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxOrgRecByRowid
               ( String inRowId
               , CxOrgTabObj  inCxOrgTabObj
               )
  {
    int lUpdateCount;
    sop("updCxOrgRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxOrgRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxOrgTabObj.effective_date != null && inCxOrgTabObj.effective_date.length() > 0 ) 
            inCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.effective_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.expiration_date != null && inCxOrgTabObj.expiration_date.length() > 0 ) 
            inCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.employer_reg_date != null && inCxOrgTabObj.employer_reg_date.length() > 0 ) 
            inCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.employer_reg_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.epf_act_open_dt != null && inCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.esi_act_open_dt != null && inCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.pan_create_date != null && inCxOrgTabObj.pan_create_date.length() > 0 ) 
            inCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.nss_create_date != null && inCxOrgTabObj.nss_create_date.length() > 0 ) 
            inCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.nss_create_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_ORG ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxOrgTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxOrgTabObj.org_id+"', ";
      if ( inCxOrgTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = "+"'"+inCxOrgTabObj.org_name+"', ";
      if ( inCxOrgTabObj.related_org_id != null  )         lSqlStmt = lSqlStmt + "related_org_id = "+"'"+inCxOrgTabObj.related_org_id+"', ";
      if ( inCxOrgTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inCxOrgTabObj.address_1+"', ";
      if ( inCxOrgTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inCxOrgTabObj.address_2+"', ";
      if ( inCxOrgTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inCxOrgTabObj.city+"', ";
      if ( inCxOrgTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inCxOrgTabObj.state+"', ";
      if ( inCxOrgTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inCxOrgTabObj.zip+"', ";
      if ( inCxOrgTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inCxOrgTabObj.country+"', ";
      if ( inCxOrgTabObj.org_type != null  )         lSqlStmt = lSqlStmt + "org_type = "+"'"+inCxOrgTabObj.org_type+"', ";
      if ( inCxOrgTabObj.org_ctg != null  )         lSqlStmt = lSqlStmt + "org_ctg = "+"'"+inCxOrgTabObj.org_ctg+"', ";
      if ( inCxOrgTabObj.bus_type != null  )         lSqlStmt = lSqlStmt + "bus_type = "+"'"+inCxOrgTabObj.bus_type+"', ";
      if ( inCxOrgTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inCxOrgTabObj.phone_list+"', ";
      if ( inCxOrgTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inCxOrgTabObj.email_list+"', ";
      if ( inCxOrgTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inCxOrgTabObj.fax_list+"', ";
      if ( inCxOrgTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = "+"'"+inCxOrgTabObj.business_currency+"', ";
      if ( inCxOrgTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inCxOrgTabObj.effective_date+"', ";
      if ( inCxOrgTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inCxOrgTabObj.expiration_date+"', ";
      if ( inCxOrgTabObj.org_url != null  )         lSqlStmt = lSqlStmt + "org_url = "+"'"+inCxOrgTabObj.org_url+"', ";
      if ( inCxOrgTabObj.logo_file_name != null  )         lSqlStmt = lSqlStmt + "logo_file_name = "+"'"+inCxOrgTabObj.logo_file_name+"', ";
      if ( inCxOrgTabObj.employer_reg_num != null  )         lSqlStmt = lSqlStmt + "employer_reg_num = "+"'"+inCxOrgTabObj.employer_reg_num+"', ";
      if ( inCxOrgTabObj.employer_reg_date != null  )         lSqlStmt = lSqlStmt + "employer_reg_date = "+"'"+inCxOrgTabObj.employer_reg_date+"', ";
      if ( inCxOrgTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = "+"'"+inCxOrgTabObj.epf_act_num+"', ";
      if ( inCxOrgTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = "+"'"+inCxOrgTabObj.epf_act_open_dt+"', ";
      if ( inCxOrgTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = "+"'"+inCxOrgTabObj.esi_num+"', ";
      if ( inCxOrgTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = "+"'"+inCxOrgTabObj.esi_act_open_dt+"', ";
      if ( inCxOrgTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inCxOrgTabObj.pan_num+"', ";
      if ( inCxOrgTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = "+"'"+inCxOrgTabObj.pan_create_date+"', ";
      if ( inCxOrgTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = "+"'"+inCxOrgTabObj.nss_num+"', ";
      if ( inCxOrgTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = "+"'"+inCxOrgTabObj.nss_create_date+"', ";
      if ( inCxOrgTabObj.key_1 != null  )         lSqlStmt = lSqlStmt + "key_1 = "+"'"+inCxOrgTabObj.key_1+"', ";
      if ( inCxOrgTabObj.key_2 != null  )         lSqlStmt = lSqlStmt + "key_2 = "+"'"+inCxOrgTabObj.key_2+"', ";
      if ( inCxOrgTabObj.mkey != null  )         lSqlStmt = lSqlStmt + "mkey = "+"'"+inCxOrgTabObj.mkey+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxOrgRecByPkey
               ( CxOrgPkeyObj inCxOrgPkeyObj
               , CxOrgTabObj  inCxOrgTabObj
               )
  {
    int lUpdateCount;
    sop("updCxOrgRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxOrgRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxOrgTabObj.effective_date != null && inCxOrgTabObj.effective_date.length() > 0 ) 
            inCxOrgTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.effective_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.expiration_date != null && inCxOrgTabObj.expiration_date.length() > 0 ) 
            inCxOrgTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.employer_reg_date != null && inCxOrgTabObj.employer_reg_date.length() > 0 ) 
            inCxOrgTabObj.employer_reg_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.employer_reg_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.epf_act_open_dt != null && inCxOrgTabObj.epf_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.esi_act_open_dt != null && inCxOrgTabObj.esi_act_open_dt.length() > 0 ) 
            inCxOrgTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.pan_create_date != null && inCxOrgTabObj.pan_create_date.length() > 0 ) 
            inCxOrgTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inCxOrgTabObj.nss_create_date != null && inCxOrgTabObj.nss_create_date.length() > 0 ) 
            inCxOrgTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxOrgTabObj.nss_create_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_ORG ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxOrgTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxOrgTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = ? , ";
        if ( inCxOrgTabObj.related_org_id != null  )         lSqlStmt = lSqlStmt + "related_org_id = ? , ";
        if ( inCxOrgTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = ? , ";
        if ( inCxOrgTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = ? , ";
        if ( inCxOrgTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = ? , ";
        if ( inCxOrgTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = ? , ";
        if ( inCxOrgTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = ? , ";
        if ( inCxOrgTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = ? , ";
        if ( inCxOrgTabObj.org_type != null  )         lSqlStmt = lSqlStmt + "org_type = ? , ";
        if ( inCxOrgTabObj.org_ctg != null  )         lSqlStmt = lSqlStmt + "org_ctg = ? , ";
        if ( inCxOrgTabObj.bus_type != null  )         lSqlStmt = lSqlStmt + "bus_type = ? , ";
        if ( inCxOrgTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = ? , ";
        if ( inCxOrgTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = ? , ";
        if ( inCxOrgTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = ? , ";
        if ( inCxOrgTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = ? , ";
        if ( inCxOrgTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = ? , ";
        if ( inCxOrgTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = ? , ";
        if ( inCxOrgTabObj.org_url != null  )         lSqlStmt = lSqlStmt + "org_url = ? , ";
        if ( inCxOrgTabObj.logo_file_name != null  )         lSqlStmt = lSqlStmt + "logo_file_name = ? , ";
        if ( inCxOrgTabObj.employer_reg_num != null  )         lSqlStmt = lSqlStmt + "employer_reg_num = ? , ";
        if ( inCxOrgTabObj.employer_reg_date != null  )         lSqlStmt = lSqlStmt + "employer_reg_date = ? , ";
        if ( inCxOrgTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = ? , ";
        if ( inCxOrgTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = ? , ";
        if ( inCxOrgTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = ? , ";
        if ( inCxOrgTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = ? , ";
        if ( inCxOrgTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = ? , ";
        if ( inCxOrgTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = ? , ";
        if ( inCxOrgTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = ? , ";
        if ( inCxOrgTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = ? , ";
        if ( inCxOrgTabObj.key_1 != null  )         lSqlStmt = lSqlStmt + "key_1 = ? , ";
        if ( inCxOrgTabObj.key_2 != null  )         lSqlStmt = lSqlStmt + "key_2 = ? , ";
        if ( inCxOrgTabObj.mkey != null  )         lSqlStmt = lSqlStmt + "mkey = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxOrgTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxOrgTabObj.org_id+"', ";
        if ( inCxOrgTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = "+"'"+inCxOrgTabObj.org_name+"', ";
        if ( inCxOrgTabObj.related_org_id != null  )         lSqlStmt = lSqlStmt + "related_org_id = "+"'"+inCxOrgTabObj.related_org_id+"', ";
        if ( inCxOrgTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inCxOrgTabObj.address_1+"', ";
        if ( inCxOrgTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inCxOrgTabObj.address_2+"', ";
        if ( inCxOrgTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inCxOrgTabObj.city+"', ";
        if ( inCxOrgTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inCxOrgTabObj.state+"', ";
        if ( inCxOrgTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inCxOrgTabObj.zip+"', ";
        if ( inCxOrgTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inCxOrgTabObj.country+"', ";
        if ( inCxOrgTabObj.org_type != null  )         lSqlStmt = lSqlStmt + "org_type = "+"'"+inCxOrgTabObj.org_type+"', ";
        if ( inCxOrgTabObj.org_ctg != null  )         lSqlStmt = lSqlStmt + "org_ctg = "+"'"+inCxOrgTabObj.org_ctg+"', ";
        if ( inCxOrgTabObj.bus_type != null  )         lSqlStmt = lSqlStmt + "bus_type = "+"'"+inCxOrgTabObj.bus_type+"', ";
        if ( inCxOrgTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inCxOrgTabObj.phone_list+"', ";
        if ( inCxOrgTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inCxOrgTabObj.email_list+"', ";
        if ( inCxOrgTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inCxOrgTabObj.fax_list+"', ";
        if ( inCxOrgTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = "+"'"+inCxOrgTabObj.business_currency+"', ";
        if ( inCxOrgTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inCxOrgTabObj.effective_date+"', ";
        if ( inCxOrgTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inCxOrgTabObj.expiration_date+"', ";
        if ( inCxOrgTabObj.org_url != null  )         lSqlStmt = lSqlStmt + "org_url = "+"'"+inCxOrgTabObj.org_url+"', ";
        if ( inCxOrgTabObj.logo_file_name != null  )         lSqlStmt = lSqlStmt + "logo_file_name = "+"'"+inCxOrgTabObj.logo_file_name+"', ";
        if ( inCxOrgTabObj.employer_reg_num != null  )         lSqlStmt = lSqlStmt + "employer_reg_num = "+"'"+inCxOrgTabObj.employer_reg_num+"', ";
        if ( inCxOrgTabObj.employer_reg_date != null  )         lSqlStmt = lSqlStmt + "employer_reg_date = "+"'"+inCxOrgTabObj.employer_reg_date+"', ";
        if ( inCxOrgTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = "+"'"+inCxOrgTabObj.epf_act_num+"', ";
        if ( inCxOrgTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = "+"'"+inCxOrgTabObj.epf_act_open_dt+"', ";
        if ( inCxOrgTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = "+"'"+inCxOrgTabObj.esi_num+"', ";
        if ( inCxOrgTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = "+"'"+inCxOrgTabObj.esi_act_open_dt+"', ";
        if ( inCxOrgTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inCxOrgTabObj.pan_num+"', ";
        if ( inCxOrgTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = "+"'"+inCxOrgTabObj.pan_create_date+"', ";
        if ( inCxOrgTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = "+"'"+inCxOrgTabObj.nss_num+"', ";
        if ( inCxOrgTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = "+"'"+inCxOrgTabObj.nss_create_date+"', ";
        if ( inCxOrgTabObj.key_1 != null  )         lSqlStmt = lSqlStmt + "key_1 = "+"'"+inCxOrgTabObj.key_1+"', ";
        if ( inCxOrgTabObj.key_2 != null  )         lSqlStmt = lSqlStmt + "key_2 = "+"'"+inCxOrgTabObj.key_2+"', ";
        if ( inCxOrgTabObj.mkey != null  )         lSqlStmt = lSqlStmt + "mkey = "+"'"+inCxOrgTabObj.mkey+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxOrgPkeyObj.org_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxOrgTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.org_id); } 
         if ( inCxOrgTabObj.org_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.org_name); } 
         if ( inCxOrgTabObj.related_org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.related_org_id); } 
         if ( inCxOrgTabObj.address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.address_1); } 
         if ( inCxOrgTabObj.address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.address_2); } 
         if ( inCxOrgTabObj.city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.city); } 
         if ( inCxOrgTabObj.state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.state); } 
         if ( inCxOrgTabObj.zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.zip); } 
         if ( inCxOrgTabObj.country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.country); } 
         if ( inCxOrgTabObj.org_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.org_type); } 
         if ( inCxOrgTabObj.org_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.org_ctg); } 
         if ( inCxOrgTabObj.bus_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.bus_type); } 
         if ( inCxOrgTabObj.phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.phone_list); } 
         if ( inCxOrgTabObj.email_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.email_list); } 
         if ( inCxOrgTabObj.fax_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.fax_list); } 
         if ( inCxOrgTabObj.business_currency != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.business_currency); } 
         if ( inCxOrgTabObj.effective_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.effective_date); } 
         if ( inCxOrgTabObj.expiration_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.expiration_date); } 
         if ( inCxOrgTabObj.org_url != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.org_url); } 
         if ( inCxOrgTabObj.logo_file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.logo_file_name); } 
         if ( inCxOrgTabObj.employer_reg_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.employer_reg_num); } 
         if ( inCxOrgTabObj.employer_reg_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.employer_reg_date); } 
         if ( inCxOrgTabObj.epf_act_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.epf_act_num); } 
         if ( inCxOrgTabObj.epf_act_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.epf_act_open_dt); } 
         if ( inCxOrgTabObj.esi_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.esi_num); } 
         if ( inCxOrgTabObj.esi_act_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.esi_act_open_dt); } 
         if ( inCxOrgTabObj.pan_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.pan_num); } 
         if ( inCxOrgTabObj.pan_create_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.pan_create_date); } 
         if ( inCxOrgTabObj.nss_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.nss_num); } 
         if ( inCxOrgTabObj.nss_create_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.nss_create_date); } 
         if ( inCxOrgTabObj.key_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.key_1); } 
         if ( inCxOrgTabObj.key_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.key_2); } 
         if ( inCxOrgTabObj.mkey != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxOrgTabObj.mkey); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxOrgRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxOrgRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxOrgRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_ORG "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxOrgRecByPkeyWithSet
               ( CxOrgPkeyObj inCxOrgPkeyObj
               , String  inCxOrgSetlist
               )
  {
    int lUpdateCount;
    sop("updCxOrgRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxOrgRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_ORG ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxOrgSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxOrgPkeyObj.org_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxOrgRecByRowidWithSet
               ( String inRowId
               , String  inCxOrgSetlist
               )
  {
    int lUpdateCount;
    sop("updCxOrgRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxOrgRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_ORG ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxOrgSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxOrgRecByWhereWithSet
               ( String inCxOrgWhereText
               , String  inCxOrgSetlist
               )
  {
    int lUpdateCount;
    sop("updCxOrgRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxOrgRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_ORG ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxOrgSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxOrgRecByPkey
               ( CxOrgPkeyObj  inCxOrgPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxOrgRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxOrgRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_ORG " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxOrgPkeyObj.org_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxOrgByWhere
               ( String inCxOrgWhereText
               )
  {
    int lUpdateCount;
    sop("delCxOrgByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxOrgByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxOrgWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxOrgWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_ORG "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
