package sstdb.cx.CxCronJob;


public class CxCronJobPkeyObj
{
  public String                                 org_id;
  public String                                 job_num;
}