
var lCxSymbolDailyTabObjJSArr = new Array();
<%
{
   if ( lCxSymbolDailyTabObjArrCache != null && lCxSymbolDailyTabObjArrCache.size() > 0 )
   {
%>
       lCxSymbolDailyTabObjJSArr = new Array(<%=lCxSymbolDailyTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxSymbolDailyTabObjArrCache.size(); lRecNum++ )
       {
          CxSymbolDailyTabObj lCxSymbolDailyTabObj    =    new CxSymbolDailyTabObj();
          lCxSymbolDailyTabObj = (CxSymbolDailyTabObj)lCxSymbolDailyTabObjArrCache.get(lRecNum);
%>
          lCxSymbolDailyTabObjJSArr[<%=lRecNum%>] = new constructorCxSymbolDaily
          (
          "<%=lCxSymbolDailyTabObj.org_id%>",
          "<%=lCxSymbolDailyTabObj.curr_date%>",
          "<%=lCxSymbolDailyTabObj.contract_id%>",
          "<%=lCxSymbolDailyTabObj.symbol_cd%>",
          "<%=lCxSymbolDailyTabObj.symbol_name%>",
          "<%=lCxSymbolDailyTabObj.status%>",
          "<%=lCxSymbolDailyTabObj.rec_cre_date%>",
          "<%=lCxSymbolDailyTabObj.rec_cre_time%>",
          "<%=lCxSymbolDailyTabObj.rec_upd_date%>",
          "<%=lCxSymbolDailyTabObj.rec_upd_time%>",
          "<%=lCxSymbolDailyTabObj.eff_date%>",
          "<%=lCxSymbolDailyTabObj.eff_time%>",
          "<%=lCxSymbolDailyTabObj.exp_date%>",
          "<%=lCxSymbolDailyTabObj.exp_time%>",
          "<%=lCxSymbolDailyTabObj.exp_rate%>",
          "<%=lCxSymbolDailyTabObj.fwd_rate%>",
          "<%=lCxSymbolDailyTabObj.fut_rate%>",
          "<%=lCxSymbolDailyTabObj.spot_rate%>",
          "<%=lCxSymbolDailyTabObj.ltp%>",
          "<%=lCxSymbolDailyTabObj.ltp_date%>",
          "<%=lCxSymbolDailyTabObj.ltp_time%>",
          "<%=lCxSymbolDailyTabObj.rate_currency%>",
          "<%=lCxSymbolDailyTabObj.rate_per_uom%>",
          "<%=lCxSymbolDailyTabObj.net_change%>",
          "<%=lCxSymbolDailyTabObj.percent_change%>",
          "<%=lCxSymbolDailyTabObj.high%>",
          "<%=lCxSymbolDailyTabObj.low%>",
          "<%=lCxSymbolDailyTabObj.bbr%>",
          "<%=lCxSymbolDailyTabObj.bbq%>",
          "<%=lCxSymbolDailyTabObj.bsr%>",
          "<%=lCxSymbolDailyTabObj.bsq%>",
          "<%=lCxSymbolDailyTabObj.open_rate%>",
          "<%=lCxSymbolDailyTabObj.close_rate%>"
          );
<%
       }
   }
}
%>


