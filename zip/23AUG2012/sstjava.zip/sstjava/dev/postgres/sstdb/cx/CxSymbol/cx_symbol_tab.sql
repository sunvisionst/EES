CREATE TABLE CX_SYMBOL
(
  ORG_ID                                                                                              VARCHAR(10),
  SYMBOL_CD                                                                                           VARCHAR(20),
  SYMBOL_NAME                                                                                         VARCHAR(50),
  STATUS                                                                                              VARCHAR(5),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
