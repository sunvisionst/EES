
var lCxSymbolCntrTabObjJSArr = new Array();
<%
{
   if ( lCxSymbolCntrTabObjArrCache != null && lCxSymbolCntrTabObjArrCache.size() > 0 )
   {
%>
       lCxSymbolCntrTabObjJSArr = new Array(<%=lCxSymbolCntrTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxSymbolCntrTabObjArrCache.size(); lRecNum++ )
       {
          CxSymbolCntrTabObj lCxSymbolCntrTabObj    =    new CxSymbolCntrTabObj();
          lCxSymbolCntrTabObj = (CxSymbolCntrTabObj)lCxSymbolCntrTabObjArrCache.get(lRecNum);
%>
          lCxSymbolCntrTabObjJSArr[<%=lRecNum%>] = new constructorCxSymbolCntr
          (
          "<%=lCxSymbolCntrTabObj.org_id%>",
          "<%=lCxSymbolCntrTabObj.contract_id%>",
          "<%=lCxSymbolCntrTabObj.symbol_cd%>",
          "<%=lCxSymbolCntrTabObj.symbol_name%>",
          "<%=lCxSymbolCntrTabObj.eff_date%>",
          "<%=lCxSymbolCntrTabObj.eff_time%>",
          "<%=lCxSymbolCntrTabObj.exp_date%>",
          "<%=lCxSymbolCntrTabObj.exp_time%>",
          "<%=lCxSymbolCntrTabObj.ddr%>",
          "<%=lCxSymbolCntrTabObj.exp_rate%>",
          "<%=lCxSymbolCntrTabObj.rate_currency%>",
          "<%=lCxSymbolCntrTabObj.rate_per_uom%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_1%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_2%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_3%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_4%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_1%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_2%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_3%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_4%>",
          "<%=lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4%>",
          "<%=lCxSymbolCntrTabObj.status%>",
          "<%=lCxSymbolCntrTabObj.rec_cre_date%>",
          "<%=lCxSymbolCntrTabObj.rec_cre_time%>",
          "<%=lCxSymbolCntrTabObj.rec_upd_date%>",
          "<%=lCxSymbolCntrTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


