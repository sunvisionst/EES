CREATE TABLE CX_ORG_EXT
(
  org_id                                                                                              VARCHAR(10),
  org_name                                                                                            VARCHAR(100),
  related_org_id                                                                                      VARCHAR(10),
  address_1                                                                                           VARCHAR(100),
  address_2                                                                                           VARCHAR(100),
  city                                                                                                VARCHAR(50),
  state                                                                                               VARCHAR(50),
  zip                                                                                                 VARCHAR(10),
  country                                                                                             VARCHAR(10),
  org_type                                                                                            VARCHAR(1),
  org_ctg                                                                                             VARCHAR(1),
  bus_type                                                                                            VARCHAR(5),
  phone_list                                                                                          VARCHAR(100),
  email_list                                                                                          VARCHAR(100),
  fax_list                                                                                            VARCHAR(100),
  business_currency                                                                                   VARCHAR(10),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  org_url                                                                                             VARCHAR(200),
  logo_file_name                                                                                      VARCHAR(56),
  employer_reg_num                                                                                    VARCHAR(50),
  employer_reg_date                                                                                   VARCHAR(8),
  epf_act_num                                                                                         VARCHAR(20),
  epf_act_open_dt                                                                                     VARCHAR(8),
  esi_num                                                                                             VARCHAR(20),
  esi_act_open_dt                                                                                     VARCHAR(8),
  pan_num                                                                                             VARCHAR(20),
  pan_create_date                                                                                     VARCHAR(8),
  nss_num                                                                                             VARCHAR(20),
  nss_create_date                                                                                     VARCHAR(8),
  key_1                                                                                               VARCHAR(100),
  key_2                                                                                               VARCHAR(100),
  mkey                                                                                                VARCHAR(200)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ORG_NAME                                                                                            CHAR(100),
       RELATED_ORG_ID                                                                                      CHAR(10),
       ADDRESS_1                                                                                           CHAR(100),
       ADDRESS_2                                                                                           CHAR(100),
       CITY                                                                                                CHAR(50),
       STATE                                                                                               CHAR(50),
       ZIP                                                                                                 CHAR(10),
       COUNTRY                                                                                             CHAR(10),
       ORG_TYPE                                                                                            CHAR(1),
       ORG_CTG                                                                                             CHAR(1),
       BUS_TYPE                                                                                            CHAR(5),
       PHONE_LIST                                                                                          CHAR(100),
       EMAIL_LIST                                                                                          CHAR(100),
       FAX_LIST                                                                                            CHAR(100),
       BUSINESS_CURRENCY                                                                                   CHAR(10),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       ORG_URL                                                                                             CHAR(200),
       LOGO_FILE_NAME                                                                                      CHAR(56),
       EMPLOYER_REG_NUM                                                                                    CHAR(50),
       EMPLOYER_REG_DATE                                                                                   CHAR(8),
       EPF_ACT_NUM                                                                                         CHAR(20),
       EPF_ACT_OPEN_DT                                                                                     CHAR(8),
       ESI_NUM                                                                                             CHAR(20),
       ESI_ACT_OPEN_DT                                                                                     CHAR(8),
       PAN_NUM                                                                                             CHAR(20),
       PAN_CREATE_DATE                                                                                     CHAR(8),
       NSS_NUM                                                                                             CHAR(20),
       NSS_CREATE_DATE                                                                                     CHAR(8),
       KEY_1                                                                                               CHAR(100),
       KEY_2                                                                                               CHAR(100),
       MKEY                                                                                                CHAR(200)
    )
  )
  LOCATION ('cx_org_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
