
var lCxMemberSymbolTabObjJSArr = new Array();
<%
{
   if ( lCxMemberSymbolTabObjArrCache != null && lCxMemberSymbolTabObjArrCache.size() > 0 )
   {
%>
       lCxMemberSymbolTabObjJSArr = new Array(<%=lCxMemberSymbolTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxMemberSymbolTabObjArrCache.size(); lRecNum++ )
       {
          CxMemberSymbolTabObj lCxMemberSymbolTabObj    =    new CxMemberSymbolTabObj();
          lCxMemberSymbolTabObj = (CxMemberSymbolTabObj)lCxMemberSymbolTabObjArrCache.get(lRecNum);
%>
          lCxMemberSymbolTabObjJSArr[<%=lRecNum%>] = new constructorCxMemberSymbol
          (
          "<%=lCxMemberSymbolTabObj.org_id%>",
          "<%=lCxMemberSymbolTabObj.member_id%>",
          "<%=lCxMemberSymbolTabObj.contract_id%>",
          "<%=lCxMemberSymbolTabObj.symbol_cd%>",
          "<%=lCxMemberSymbolTabObj.symbol_name%>",
          "<%=lCxMemberSymbolTabObj.link_member_id%>",
          "<%=lCxMemberSymbolTabObj.status%>",
          "<%=lCxMemberSymbolTabObj.rec_cre_date%>",
          "<%=lCxMemberSymbolTabObj.rec_cre_time%>",
          "<%=lCxMemberSymbolTabObj.rec_upd_date%>",
          "<%=lCxMemberSymbolTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


