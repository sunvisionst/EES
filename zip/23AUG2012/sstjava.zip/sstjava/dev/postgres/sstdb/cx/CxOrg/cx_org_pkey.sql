ALTER TABLE           CX_ORG
  ADD                 CONSTRAINT CX_ORG_PK
  PRIMARY             KEY
  ( ORG_ID )
;
