package sstdb.cx.CxSymbol;


public class CxSymbolPkeyObj
{
  public String                                 org_id;
  public String                                 symbol_cd;
}