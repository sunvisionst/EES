{


   function vldDBSizeEnvCxSymbol
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeSymbolCd ( inTableName, inFieldName );
      vldFieldDBSizeSymbolName ( inTableName, inFieldName );
      vldFieldDBSizeStatus ( inTableName, inFieldName );
      vldFieldDBSizeRecCreDate ( inTableName, inFieldName );
      vldFieldDBSizeRecCreTime ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdDate ( inTableName, inFieldName );
      vldFieldDBSizeRecUpdTime ( inTableName, inFieldName );
   }



   function constructorCxSymbol
   (
      org_id,
      symbol_cd,
      symbol_name,
      status,
      rec_cre_date,
      rec_cre_time,
      rec_upd_date,
      rec_upd_time
   )
   {
      this.org_id = org_id;
      this.symbol_cd = symbol_cd;
      this.symbol_name = symbol_name;
      this.status = status;
      this.rec_cre_date = rec_cre_date;
      this.rec_cre_time = rec_cre_time;
      this.rec_upd_date = rec_upd_date;
      this.rec_upd_time = rec_upd_time;
   }



   function CxSymbolFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lCxSymbolTabObjJSArr.length )
      {
         if
         ( 
           ( lCxSymbolTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lCxSymbolTabObjJSArr[lRecNum].symbol_cd != document.form.symbol_cd.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeCxSymbolTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjSymbolName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjStatus
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeCxSymbolTabObjRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSymbolCd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSymbolName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisStatus
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecCreTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisRecUpdTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >6 )
      {
         alert("Data base field size error. Size should be <= 6");
         inFieldName.focus();
      }
   }



}