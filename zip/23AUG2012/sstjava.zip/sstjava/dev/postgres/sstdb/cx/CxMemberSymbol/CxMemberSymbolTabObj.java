package sstdb.cx.CxMemberSymbol;


public class CxMemberSymbolTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 member_id;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public String                                 symbol_name;
  public String                                 link_member_id;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  member_id_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  symbol_name_ind;
  public short                                  link_member_id_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxMemberSymbolTabObj(){}


  public CxMemberSymbolTabObj
  (
    String org_id,
    String member_id,
    String contract_id,
    String symbol_cd,
    String symbol_name,
    String link_member_id,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.member_id = member_id;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.symbol_name = symbol_name;
     this.link_member_id = link_member_id;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getmember_id()                         { return member_id; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public String getsymbol_name()                        { return symbol_name; }
  public String getlink_member_id()                       { return link_member_id; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setmember_id(String member_id )                 { this.member_id = member_id; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setsymbol_name(String symbol_name )               { this.symbol_name = symbol_name; }
  public void  setlink_member_id(String link_member_id )            { this.link_member_id = link_member_id; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}