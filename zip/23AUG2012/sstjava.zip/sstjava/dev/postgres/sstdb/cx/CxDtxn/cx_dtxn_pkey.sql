ALTER TABLE           CX_DTXN
  ADD                 CONSTRAINT CX_DTXN_PK
  PRIMARY             KEY
  ( ORG_ID, TXN_NUM )
;
