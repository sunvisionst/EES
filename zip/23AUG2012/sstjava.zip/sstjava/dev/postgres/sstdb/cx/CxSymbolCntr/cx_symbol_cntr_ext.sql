CREATE TABLE CX_SYMBOL_CNTR_EXT
(
  org_id                                                                                              VARCHAR(10),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  symbol_name                                                                                         VARCHAR(50),
  eff_date                                                                                            VARCHAR(8),
  eff_time                                                                                            VARCHAR(6),
  exp_date                                                                                            VARCHAR(8),
  exp_time                                                                                            VARCHAR(6),
  ddr                                                                                                 NUMERIC(13,2),
  exp_rate                                                                                            NUMERIC(13,2),
  rate_currency                                                                                       VARCHAR(10),
  rate_per_uom                                                                                        VARCHAR(5),
  spl_mrgn_pur_1                                                                                      NUMERIC(13,2),
  spl_mrgn_pur_rt_1                                                                                   NUMERIC(13,2),
  spl_mrgn_pur_2                                                                                      NUMERIC(13,2),
  spl_mrgn_pur_rt_2                                                                                   NUMERIC(13,2),
  spl_mrgn_pur_3                                                                                      NUMERIC(13,2),
  spl_mrgn_pur_rt_3                                                                                   NUMERIC(13,2),
  spl_mrgn_pur_4                                                                                      NUMERIC(13,2),
  spl_mrgn_pur_rt_4                                                                                   NUMERIC(13,2),
  spl_mrgn_sal_1                                                                                      NUMERIC(13,2),
  spl_mrgn_sal_rt_1                                                                                   NUMERIC(13,2),
  spl_mrgn_sal_2                                                                                      NUMERIC(13,2),
  spl_mrgn_sal_rt_2                                                                                   NUMERIC(13,2),
  spl_mrgn_sal_3                                                                                      NUMERIC(13,2),
  spl_mrgn_sal_rt_3                                                                                   NUMERIC(13,2),
  spl_mrgn_sal_4                                                                                      NUMERIC(13,2),
  spl_mrgn_sal_rt_4                                                                                   NUMERIC(13,2),
  status                                                                                              VARCHAR(5),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       SYMBOL_NAME                                                                                         CHAR(50),
       EFF_DATE                                                                                            CHAR(8),
       EFF_TIME                                                                                            CHAR(6),
       EXP_DATE                                                                                            CHAR(8),
       EXP_TIME                                                                                            CHAR(6),
       DDR                                                                                                 CHAR(13),
       EXP_RATE                                                                                            CHAR(13),
       RATE_CURRENCY                                                                                       CHAR(10),
       RATE_PER_UOM                                                                                        CHAR(5),
       SPL_MRGN_PUR_1                                                                                      CHAR(13),
       SPL_MRGN_PUR_RT_1                                                                                   CHAR(13),
       SPL_MRGN_PUR_2                                                                                      CHAR(13),
       SPL_MRGN_PUR_RT_2                                                                                   CHAR(13),
       SPL_MRGN_PUR_3                                                                                      CHAR(13),
       SPL_MRGN_PUR_RT_3                                                                                   CHAR(13),
       SPL_MRGN_PUR_4                                                                                      CHAR(13),
       SPL_MRGN_PUR_RT_4                                                                                   CHAR(13),
       SPL_MRGN_SAL_1                                                                                      CHAR(13),
       SPL_MRGN_SAL_RT_1                                                                                   CHAR(13),
       SPL_MRGN_SAL_2                                                                                      CHAR(13),
       SPL_MRGN_SAL_RT_2                                                                                   CHAR(13),
       SPL_MRGN_SAL_3                                                                                      CHAR(13),
       SPL_MRGN_SAL_RT_3                                                                                   CHAR(13),
       SPL_MRGN_SAL_4                                                                                      CHAR(13),
       SPL_MRGN_SAL_RT_4                                                                                   CHAR(13),
       STATUS                                                                                              CHAR(5),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_symbol_cntr_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
