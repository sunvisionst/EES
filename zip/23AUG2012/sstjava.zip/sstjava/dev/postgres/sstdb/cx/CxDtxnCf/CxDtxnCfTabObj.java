package sstdb.cx.CxDtxnCf;


public class CxDtxnCfTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 txn_num;
  public String                                 txn_date;
  public String                                 txn_time;
  public String                                 txn_type;
  public String                                 link_txn_num;
  public String                                 link_txn_date;
  public String                                 link_txn_time;
  public String                                 member_id;
  public String                                 member_name;
  public String                                 contract_id;
  public String                                 symbol_cd;
  public int                                  qty;
  public double                                 rate;
  public String                                 status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  txn_num_ind;
  public short                                  txn_date_ind;
  public short                                  txn_time_ind;
  public short                                  txn_type_ind;
  public short                                  link_txn_num_ind;
  public short                                  link_txn_date_ind;
  public short                                  link_txn_time_ind;
  public short                                  member_id_ind;
  public short                                  member_name_ind;
  public short                                  contract_id_ind;
  public short                                  symbol_cd_ind;
  public short                                  qty_ind;
  public short                                  rate_ind;
  public short                                  status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public CxDtxnCfTabObj(){}


  public CxDtxnCfTabObj
  (
    String org_id,
    String txn_num,
    String txn_date,
    String txn_time,
    String txn_type,
    String link_txn_num,
    String link_txn_date,
    String link_txn_time,
    String member_id,
    String member_name,
    String contract_id,
    String symbol_cd,
    int qty,
    double rate,
    String status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.txn_num = txn_num;
     this.txn_date = txn_date;
     this.txn_time = txn_time;
     this.txn_type = txn_type;
     this.link_txn_num = link_txn_num;
     this.link_txn_date = link_txn_date;
     this.link_txn_time = link_txn_time;
     this.member_id = member_id;
     this.member_name = member_name;
     this.contract_id = contract_id;
     this.symbol_cd = symbol_cd;
     this.qty = qty;
     this.rate = rate;
     this.status = status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String gettxn_num()                          { return txn_num; }
  public String gettxn_date()                          { return txn_date; }
  public String gettxn_time()                          { return txn_time; }
  public String gettxn_type()                          { return txn_type; }
  public String getlink_txn_num()                        { return link_txn_num; }
  public String getlink_txn_date()                       { return link_txn_date; }
  public String getlink_txn_time()                       { return link_txn_time; }
  public String getmember_id()                         { return member_id; }
  public String getmember_name()                        { return member_name; }
  public String getcontract_id()                        { return contract_id; }
  public String getsymbol_cd()                         { return symbol_cd; }
  public int getqty()                              { return qty; }
  public double getrate()                            { return rate; }
  public String getstatus()                           { return status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  settxn_num(String txn_num )                   { this.txn_num = txn_num; }
  public void  settxn_date(String txn_date )                  { this.txn_date = txn_date; }
  public void  settxn_time(String txn_time )                  { this.txn_time = txn_time; }
  public void  settxn_type(String txn_type )                  { this.txn_type = txn_type; }
  public void  setlink_txn_num(String link_txn_num )              { this.link_txn_num = link_txn_num; }
  public void  setlink_txn_date(String link_txn_date )             { this.link_txn_date = link_txn_date; }
  public void  setlink_txn_time(String link_txn_time )             { this.link_txn_time = link_txn_time; }
  public void  setmember_id(String member_id )                 { this.member_id = member_id; }
  public void  setmember_name(String member_name )               { this.member_name = member_name; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setsymbol_cd(String symbol_cd )                 { this.symbol_cd = symbol_cd; }
  public void  setqty(int qty )                         { this.qty = qty; }
  public void  setrate(double rate )                      { this.rate = rate; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}