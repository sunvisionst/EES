
var lCxCronJobTabObjJSArr = new Array();
<%
{
   if ( lCxCronJobTabObjArrCache != null && lCxCronJobTabObjArrCache.size() > 0 )
   {
%>
       lCxCronJobTabObjJSArr = new Array(<%=lCxCronJobTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxCronJobTabObjArrCache.size(); lRecNum++ )
       {
          CxCronJobTabObj lCxCronJobTabObj    =    new CxCronJobTabObj();
          lCxCronJobTabObj = (CxCronJobTabObj)lCxCronJobTabObjArrCache.get(lRecNum);
%>
          lCxCronJobTabObjJSArr[<%=lRecNum%>] = new constructorCxCronJob
          (
          "<%=lCxCronJobTabObj.org_id%>",
          "<%=lCxCronJobTabObj.job_num%>",
          "<%=lCxCronJobTabObj.sch_date%>",
          "<%=lCxCronJobTabObj.sch_time%>",
          "<%=lCxCronJobTabObj.alert_type%>",
          "<%=lCxCronJobTabObj.contact_num_1%>",
          "<%=lCxCronJobTabObj.email_id%>",
          "<%=lCxCronJobTabObj.status%>",
          "<%=lCxCronJobTabObj.rec_cre_by%>",
          "<%=lCxCronJobTabObj.rec_cre_date%>",
          "<%=lCxCronJobTabObj.rec_cre_time%>",
          "<%=lCxCronJobTabObj.rec_upd_by%>",
          "<%=lCxCronJobTabObj.rec_upd_date%>",
          "<%=lCxCronJobTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


