CREATE TABLE CX_ORDER_EXT
(
  org_id                                                                                              VARCHAR(10),
  ord_num                                                                                             VARCHAR(20),
  ord_seq_num                                                                                         NUMERIC(9),
  ord_date                                                                                            VARCHAR(8),
  ord_time                                                                                            VARCHAR(6),
  txn_type                                                                                            VARCHAR(1),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  buyer                                                                                               VARCHAR(20),
  seller                                                                                              VARCHAR(20),
  buy_qty                                                                                             NUMERIC(9),
  sale_qty                                                                                            NUMERIC(9),
  bal_qty                                                                                             NUMERIC(9),
  rate                                                                                                NUMERIC(13,2),
  status                                                                                              VARCHAR(10),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ORD_NUM                                                                                             CHAR(20),
       ORD_SEQ_NUM                                                                                         CHAR(9),
       ORD_DATE                                                                                            CHAR(8),
       ORD_TIME                                                                                            CHAR(6),
       TXN_TYPE                                                                                            CHAR(1),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       BUYER                                                                                               CHAR(20),
       SELLER                                                                                              CHAR(20),
       BUY_QTY                                                                                             CHAR(9),
       SALE_QTY                                                                                            CHAR(9),
       BAL_QTY                                                                                             CHAR(9),
       RATE                                                                                                CHAR(13),
       STATUS                                                                                              CHAR(10),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_order_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
