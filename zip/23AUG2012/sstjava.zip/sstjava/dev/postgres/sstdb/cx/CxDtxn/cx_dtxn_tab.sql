CREATE TABLE CX_DTXN
(
  ORG_ID                                                                                              VARCHAR(10),
  TXN_NUM                                                                                             VARCHAR(20),
  TXN_DATE                                                                                            VARCHAR(8),
  TXN_TIME                                                                                            VARCHAR(6),
  TXN_TYPE                                                                                            VARCHAR(1),
  MEMBER_ID                                                                                           VARCHAR(20),
  MEMBER_NAME                                                                                         VARCHAR(100),
  CONTRACT_ID                                                                                         VARCHAR(20),
  SYMBOL_CD                                                                                           VARCHAR(20),
  QTY                                                                                                 NUMERIC(9),
  MATURE_QTY                                                                                          NUMERIC(9),
  RATE                                                                                                NUMERIC(13,2),
  CF_TXN_NUM                                                                                          VARCHAR(20),
  CF_RATE                                                                                             NUMERIC(13,2),
  CF_DATE                                                                                             VARCHAR(8),
  CF_TIME                                                                                             VARCHAR(6),
  STATUS                                                                                              VARCHAR(10),
  REG_IND                                                                                             VARCHAR(1),
  REG_LIMIT                                                                                           NUMERIC(13,2),
  SLR_IND                                                                                             VARCHAR(1),
  SLR_LIMIT                                                                                           NUMERIC(13,2),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
