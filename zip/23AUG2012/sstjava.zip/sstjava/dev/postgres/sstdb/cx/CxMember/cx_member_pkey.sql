ALTER TABLE           CX_MEMBER
  ADD                 CONSTRAINT CX_MEMBER_PK
  PRIMARY             KEY
  ( ORG_ID, MEMBER_ID )
;
