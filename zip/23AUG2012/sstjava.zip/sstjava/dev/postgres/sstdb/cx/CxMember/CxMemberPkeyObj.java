package sstdb.cx.CxMember;


public class CxMemberPkeyObj
{
  public String                                 org_id;
  public String                                 member_id;
}