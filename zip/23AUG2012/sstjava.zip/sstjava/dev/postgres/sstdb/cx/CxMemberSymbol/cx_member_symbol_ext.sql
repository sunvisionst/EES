CREATE TABLE CX_MEMBER_SYMBOL_EXT
(
  org_id                                                                                              VARCHAR(10),
  member_id                                                                                           VARCHAR(20),
  contract_id                                                                                         VARCHAR(20),
  symbol_cd                                                                                           VARCHAR(20),
  symbol_name                                                                                         VARCHAR(50),
  link_member_id                                                                                      VARCHAR(20),
  status                                                                                              VARCHAR(5),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       MEMBER_ID                                                                                           CHAR(20),
       CONTRACT_ID                                                                                         CHAR(20),
       SYMBOL_CD                                                                                           CHAR(20),
       SYMBOL_NAME                                                                                         CHAR(50),
       LINK_MEMBER_ID                                                                                      CHAR(20),
       STATUS                                                                                              CHAR(5),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('cx_member_symbol_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
