function CxCronJobRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("job_num").value  = document.getElementById("job_num"+"_r"+inRecNum).value;
    document.getElementById("job_num").readOnly = true;
    document.getElementById("sch_date").value  = document.getElementById("sch_date"+"_r"+inRecNum).value;
    document.getElementById("sch_time").value  = document.getElementById("sch_time"+"_r"+inRecNum).value;
    document.getElementById("alert_type").value  = document.getElementById("alert_type"+"_r"+inRecNum).value;
    document.getElementById("contact_num_1").value  = document.getElementById("contact_num_1"+"_r"+inRecNum).value;
    document.getElementById("email_id").value  = document.getElementById("email_id"+"_r"+inRecNum).value;
    document.getElementById("status").value  = document.getElementById("status"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_by").value  = document.getElementById("rec_cre_by"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_by").value  = document.getElementById("rec_upd_by"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("job_num").value = '';
    document.getElementById("job_num").readOnly = false;
    document.getElementById("sch_date").value = '';
    document.getElementById("sch_time").value = '';
    document.getElementById("alert_type").value = '';
    document.getElementById("contact_num_1").value = '';
    document.getElementById("email_id").value = '';
    document.getElementById("status").value = '';
    document.getElementById("rec_cre_by").value = '';
    document.getElementById("rec_cre_date").value = '';
    document.getElementById("rec_cre_time").value = '';
    document.getElementById("rec_upd_by").value = '';
    document.getElementById("rec_upd_date").value = '';
    document.getElementById("rec_upd_time").value = '';
  }
}
