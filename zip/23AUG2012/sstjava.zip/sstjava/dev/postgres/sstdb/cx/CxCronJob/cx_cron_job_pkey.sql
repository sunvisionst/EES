ALTER TABLE           CX_CRON_JOB
  ADD                 CONSTRAINT CX_CRON_JOB_PK
  PRIMARY             KEY
  ( ORG_ID, JOB_NUM )
;
