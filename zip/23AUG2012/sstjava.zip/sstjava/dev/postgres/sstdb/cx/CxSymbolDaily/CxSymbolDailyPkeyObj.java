package sstdb.cx.CxSymbolDaily;


public class CxSymbolDailyPkeyObj
{
  public String                                 org_id;
  public String                                 curr_date;
  public String                                 contract_id;
}