CREATE TABLE CX_DTXN_CF
(
  ORG_ID                                                                                              VARCHAR(10),
  TXN_NUM                                                                                             VARCHAR(20),
  TXN_DATE                                                                                            VARCHAR(8),
  TXN_TIME                                                                                            VARCHAR(6),
  TXN_TYPE                                                                                            VARCHAR(1),
  LINK_TXN_NUM                                                                                        VARCHAR(20),
  LINK_TXN_DATE                                                                                       VARCHAR(8),
  LINK_TXN_TIME                                                                                       VARCHAR(6),
  MEMBER_ID                                                                                           VARCHAR(20),
  MEMBER_NAME                                                                                         VARCHAR(100),
  CONTRACT_ID                                                                                         VARCHAR(20),
  SYMBOL_CD                                                                                           VARCHAR(20),
  QTY                                                                                                 NUMERIC(9),
  RATE                                                                                                NUMERIC(13,2),
  STATUS                                                                                              VARCHAR(10),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
