
var lCxOrgTabObjJSArr = new Array();
<%
{
   if ( lCxOrgTabObjArrCache != null && lCxOrgTabObjArrCache.size() > 0 )
   {
%>
       lCxOrgTabObjJSArr = new Array(<%=lCxOrgTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lCxOrgTabObjArrCache.size(); lRecNum++ )
       {
          CxOrgTabObj lCxOrgTabObj    =    new CxOrgTabObj();
          lCxOrgTabObj = (CxOrgTabObj)lCxOrgTabObjArrCache.get(lRecNum);
%>
          lCxOrgTabObjJSArr[<%=lRecNum%>] = new constructorCxOrg
          (
          "<%=lCxOrgTabObj.org_id%>",
          "<%=lCxOrgTabObj.org_name%>",
          "<%=lCxOrgTabObj.related_org_id%>",
          "<%=lCxOrgTabObj.address_1%>",
          "<%=lCxOrgTabObj.address_2%>",
          "<%=lCxOrgTabObj.city%>",
          "<%=lCxOrgTabObj.state%>",
          "<%=lCxOrgTabObj.zip%>",
          "<%=lCxOrgTabObj.country%>",
          "<%=lCxOrgTabObj.org_type%>",
          "<%=lCxOrgTabObj.org_ctg%>",
          "<%=lCxOrgTabObj.bus_type%>",
          "<%=lCxOrgTabObj.phone_list%>",
          "<%=lCxOrgTabObj.email_list%>",
          "<%=lCxOrgTabObj.fax_list%>",
          "<%=lCxOrgTabObj.business_currency%>",
          "<%=lCxOrgTabObj.effective_date%>",
          "<%=lCxOrgTabObj.expiration_date%>",
          "<%=lCxOrgTabObj.org_url%>",
          "<%=lCxOrgTabObj.logo_file_name%>",
          "<%=lCxOrgTabObj.employer_reg_num%>",
          "<%=lCxOrgTabObj.employer_reg_date%>",
          "<%=lCxOrgTabObj.epf_act_num%>",
          "<%=lCxOrgTabObj.epf_act_open_dt%>",
          "<%=lCxOrgTabObj.esi_num%>",
          "<%=lCxOrgTabObj.esi_act_open_dt%>",
          "<%=lCxOrgTabObj.pan_num%>",
          "<%=lCxOrgTabObj.pan_create_date%>",
          "<%=lCxOrgTabObj.nss_num%>",
          "<%=lCxOrgTabObj.nss_create_date%>",
          "<%=lCxOrgTabObj.key_1%>",
          "<%=lCxOrgTabObj.key_2%>",
          "<%=lCxOrgTabObj.mkey%>"
          );
<%
       }
   }
}
%>


