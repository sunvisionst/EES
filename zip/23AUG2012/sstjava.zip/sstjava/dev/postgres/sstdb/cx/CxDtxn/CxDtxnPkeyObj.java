package sstdb.cx.CxDtxn;


public class CxDtxnPkeyObj
{
  public String                                 org_id;
  public String                                 txn_num;
}