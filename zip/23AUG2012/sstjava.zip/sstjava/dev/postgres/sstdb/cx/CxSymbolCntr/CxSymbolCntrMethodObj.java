package sstdb.cx.CxSymbolCntr;

import sstdb.cx.CxSymbolCntr.CxSymbolCntrTabObj;
import sstdb.cx.CxSymbolCntr.CxSymbolCntrPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class CxSymbolCntrMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public CxSymbolCntrMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "CxSymbolCntrMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initCxSymbolCntrTabObj
               ( 
                 CxSymbolCntrTabObj  outCxSymbolCntrTabObj
               )
  {
  
     outCxSymbolCntrTabObj.org_id = ""; 
     outCxSymbolCntrTabObj.contract_id = ""; 
     outCxSymbolCntrTabObj.symbol_cd = ""; 
     outCxSymbolCntrTabObj.symbol_name = ""; 
     outCxSymbolCntrTabObj.eff_date = ""; 
     outCxSymbolCntrTabObj.eff_time = ""; 
     outCxSymbolCntrTabObj.exp_date = ""; 
     outCxSymbolCntrTabObj.exp_time = ""; 
     outCxSymbolCntrTabObj.ddr = (double)0.00; 
     outCxSymbolCntrTabObj.exp_rate = (double)0.00; 
     outCxSymbolCntrTabObj.rate_currency = ""; 
     outCxSymbolCntrTabObj.rate_per_uom = ""; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_1 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_2 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_3 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_4 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_1 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_2 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_3 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_4 = (double)0.00; 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = (double)0.00; 
     outCxSymbolCntrTabObj.status = ""; 
     outCxSymbolCntrTabObj.rec_cre_date = ""; 
     outCxSymbolCntrTabObj.rec_cre_time = ""; 
     outCxSymbolCntrTabObj.rec_upd_date = ""; 
     outCxSymbolCntrTabObj.rec_upd_time = ""; 
  }





  public void guiDateConvCxSymbolCntrTabObj
               ( 
                 CxSymbolCntrTabObj  inCxSymbolCntrTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inCxSymbolCntrTabObj.eff_date != null && inCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            inCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);

          if ( inCxSymbolCntrTabObj.exp_date != null && inCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            inCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);

          if ( inCxSymbolCntrTabObj.rec_cre_date != null && inCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inCxSymbolCntrTabObj.rec_upd_date != null && inCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxCxSymbolCntrByTabObj
               ( 
                 CxSymbolCntrTabObj  inCxSymbolCntrTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lCxSymbolCntrTabObjArrCtx  = new ArrayList(); 
    lCxSymbolCntrTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lCxSymbolCntrTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lCxSymbolCntrTabObjArrCtx.add(inCxSymbolCntrTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lCxSymbolCntrTabObjArrCtx.size();  lRecNum++ )
      {
        CxSymbolCntrTabObj lCxSymbolCntrTabObj = new CxSymbolCntrTabObj();
        lCxSymbolCntrTabObj = (CxSymbolCntrTabObj)lCxSymbolCntrTabObjArrCtx.get(lRecNum);
    
        if ( 
              lCxSymbolCntrTabObj.org_id.equals(lCxSymbolCntrTabObj.org_id) &&
              lCxSymbolCntrTabObj.contract_id.equals(lCxSymbolCntrTabObj.contract_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lCxSymbolCntrTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lCxSymbolCntrTabObjArrCtx.set(lRecNum, inCxSymbolCntrTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lCxSymbolCntrTabObjArrCtx",lCxSymbolCntrTabObjArrCtx);
  }





  public void sortCxSymbolCntrTabObjArr
               ( 
                 ArrayList  inCxSymbolCntrTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lCxSymbolCntrTabObjArr  = new ArrayList(); 
     lCxSymbolCntrTabObjArr = inCxSymbolCntrTabObjArr; 
     List lCxSymbolCntrTabObjList  = new ArrayList(lCxSymbolCntrTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lCxSymbolCntrTabObjArr.size();  lRecNum++ )
     {
       CxSymbolCntrTabObj  lCxSymbolCntrTabObj = new CxSymbolCntrTabObj(); 
       lCxSymbolCntrTabObj = (CxSymbolCntrTabObj)lCxSymbolCntrTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxSymbolCntrTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("contract_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxSymbolCntrTabObj.contract_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.contract_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_cd") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lCxSymbolCntrTabObj.symbol_cd.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.symbol_cd+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("symbol_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lCxSymbolCntrTabObj.symbol_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.symbol_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("eff_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolCntrTabObj.eff_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.eff_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("eff_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolCntrTabObj.eff_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.eff_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolCntrTabObj.exp_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.exp_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolCntrTabObj.exp_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.exp_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ddr") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.ddr).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.ddr+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exp_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.exp_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.exp_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate_currency") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lCxSymbolCntrTabObj.rate_currency.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rate_currency+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rate_per_uom") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxSymbolCntrTabObj.rate_per_uom.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rate_per_uom+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_rt_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_rt_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_rt_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_pur_rt_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_rt_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_rt_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_rt_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_mrgn_sal_rt_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lCxSymbolCntrTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolCntrTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolCntrTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lCxSymbolCntrTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lCxSymbolCntrTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lCxSymbolCntrTabObj.rec_upd_time+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lCxSymbolCntrTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lCxSymbolCntrTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lCxSymbolCntrTabObjList ); 
     ArrayList lCxSymbolCntrTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lCxSymbolCntrTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lCxSymbolCntrTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lCxSymbolCntrTabObjArrSorted.add( (CxSymbolCntrTabObj)lCxSymbolCntrTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lCxSymbolCntrTabObjArr.size();  lRecNum++ )
     {
       inCxSymbolCntrTabObjArr.set( lRecNum, (CxSymbolCntrTabObj)lCxSymbolCntrTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvCxSymbolCntrTabObj
               ( 
                 CxSymbolCntrTabObj  inCxSymbolCntrTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inCxSymbolCntrTabObj.eff_date != null && inCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            inCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.exp_date != null && inCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            inCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_cre_date != null && inCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_upd_date != null && inCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeContractId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CONTRACT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolCd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_CD";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSymbolName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SYMBOL_NAME";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFF_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFF_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDdr
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DDR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXP_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRateCurrency
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE_CURRENCY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRatePerUom
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RATE_PER_UOM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPur1
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_1";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPurRt1
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_RT_1";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPur2
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_2";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPurRt2
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_RT_2";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPur3
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_3";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPurRt3
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_RT_3";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPur4
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_4";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnPurRt4
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_PUR_RT_4";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSal1
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_1";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSalRt1
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_RT_1";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSal2
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_2";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSalRt2
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_RT_2";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSal3
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_3";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSalRt3
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_RT_3";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSal4
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_4";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplMrgnSalRt4
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_MRGN_SAL_RT_4";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtCxSymbolCntrCount
               ( String inCxSymbolCntrWhereText
               )
  {
    sop("gtCxSymbolCntrCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrCount
               ( String inCxSymbolCntrWhereText
               , String inCxSymbolCntrSelectFieldList
               )
  {
    sop("gtCxSymbolCntrCount - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inCxSymbolCntrSelectFieldList+" AS count "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrRecByPkey
               ( CxSymbolCntrPkeyObj inCxSymbolCntrPkeyObj
               , CxSymbolCntrTabObj  outCxSymbolCntrTabObj
               )
  {
    sop("gtCxSymbolCntrRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "ddr, "+
                                 "exp_rate, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "spl_mrgn_pur_1, "+
                                 "spl_mrgn_pur_rt_1, "+
                                 "spl_mrgn_pur_2, "+
                                 "spl_mrgn_pur_rt_2, "+
                                 "spl_mrgn_pur_3, "+
                                 "spl_mrgn_pur_rt_3, "+
                                 "spl_mrgn_pur_4, "+
                                 "spl_mrgn_pur_rt_4, "+
                                 "spl_mrgn_sal_1, "+
                                 "spl_mrgn_sal_rt_1, "+
                                 "spl_mrgn_sal_2, "+
                                 "spl_mrgn_sal_rt_2, "+
                                 "spl_mrgn_sal_3, "+
                                 "spl_mrgn_sal_rt_3, "+
                                 "spl_mrgn_sal_4, "+
                                 "spl_mrgn_sal_rt_4, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_SYMBOL_CNTR " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolCntrPkeyObj.org_id+"' and "+
                              "contract_id = "+"'"+inCxSymbolCntrPkeyObj.contract_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outCxSymbolCntrTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxSymbolCntrTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxSymbolCntrTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxSymbolCntrTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxSymbolCntrTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          outCxSymbolCntrTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( outCxSymbolCntrTabObj.eff_date != null && outCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            outCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          outCxSymbolCntrTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( outCxSymbolCntrTabObj.exp_date != null && outCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            outCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          outCxSymbolCntrTabObj.ddr  =  lResultSet.getDouble("DDR");
          outCxSymbolCntrTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          outCxSymbolCntrTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          outCxSymbolCntrTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          outCxSymbolCntrTabObj.spl_mrgn_pur_1  =  lResultSet.getDouble("SPL_MRGN_PUR_1");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_1");
          outCxSymbolCntrTabObj.spl_mrgn_pur_2  =  lResultSet.getDouble("SPL_MRGN_PUR_2");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_2");
          outCxSymbolCntrTabObj.spl_mrgn_pur_3  =  lResultSet.getDouble("SPL_MRGN_PUR_3");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_3");
          outCxSymbolCntrTabObj.spl_mrgn_pur_4  =  lResultSet.getDouble("SPL_MRGN_PUR_4");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_4");
          outCxSymbolCntrTabObj.spl_mrgn_sal_1  =  lResultSet.getDouble("SPL_MRGN_SAL_1");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_1");
          outCxSymbolCntrTabObj.spl_mrgn_sal_2  =  lResultSet.getDouble("SPL_MRGN_SAL_2");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_2");
          outCxSymbolCntrTabObj.spl_mrgn_sal_3  =  lResultSet.getDouble("SPL_MRGN_SAL_3");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_3");
          outCxSymbolCntrTabObj.spl_mrgn_sal_4  =  lResultSet.getDouble("SPL_MRGN_SAL_4");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_4");
          outCxSymbolCntrTabObj.status  =  lResultSet.getString("STATUS");
          outCxSymbolCntrTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxSymbolCntrTabObj.rec_cre_date != null && outCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            outCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxSymbolCntrTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxSymbolCntrTabObj.rec_upd_date != null && outCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            outCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxSymbolCntrTabObj( outCxSymbolCntrTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrArr
               ( CxSymbolCntrPkeyObj inCxSymbolCntrPkeyObj
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {
    sop("gtCxSymbolCntrArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "ddr, "+
                                 "exp_rate, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "spl_mrgn_pur_1, "+
                                 "spl_mrgn_pur_rt_1, "+
                                 "spl_mrgn_pur_2, "+
                                 "spl_mrgn_pur_rt_2, "+
                                 "spl_mrgn_pur_3, "+
                                 "spl_mrgn_pur_rt_3, "+
                                 "spl_mrgn_pur_4, "+
                                 "spl_mrgn_pur_rt_4, "+
                                 "spl_mrgn_sal_1, "+
                                 "spl_mrgn_sal_rt_1, "+
                                 "spl_mrgn_sal_2, "+
                                 "spl_mrgn_sal_rt_2, "+
                                 "spl_mrgn_sal_3, "+
                                 "spl_mrgn_sal_rt_3, "+
                                 "spl_mrgn_sal_4, "+
                                 "spl_mrgn_sal_rt_4, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_SYMBOL_CNTR";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxSymbolCntrTabObj  lCxSymbolCntrTabObj = new CxSymbolCntrTabObj();
          lCxSymbolCntrTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lCxSymbolCntrTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxSymbolCntrTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxSymbolCntrTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxSymbolCntrTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          lCxSymbolCntrTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( lCxSymbolCntrTabObj.eff_date != null && lCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            lCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          lCxSymbolCntrTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( lCxSymbolCntrTabObj.exp_date != null && lCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            lCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          lCxSymbolCntrTabObj.ddr  =  lResultSet.getDouble("DDR");
          lCxSymbolCntrTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          lCxSymbolCntrTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          lCxSymbolCntrTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          lCxSymbolCntrTabObj.spl_mrgn_pur_1  =  lResultSet.getDouble("SPL_MRGN_PUR_1");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_1");
          lCxSymbolCntrTabObj.spl_mrgn_pur_2  =  lResultSet.getDouble("SPL_MRGN_PUR_2");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_2");
          lCxSymbolCntrTabObj.spl_mrgn_pur_3  =  lResultSet.getDouble("SPL_MRGN_PUR_3");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_3");
          lCxSymbolCntrTabObj.spl_mrgn_pur_4  =  lResultSet.getDouble("SPL_MRGN_PUR_4");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_4");
          lCxSymbolCntrTabObj.spl_mrgn_sal_1  =  lResultSet.getDouble("SPL_MRGN_SAL_1");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_1");
          lCxSymbolCntrTabObj.spl_mrgn_sal_2  =  lResultSet.getDouble("SPL_MRGN_SAL_2");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_2");
          lCxSymbolCntrTabObj.spl_mrgn_sal_3  =  lResultSet.getDouble("SPL_MRGN_SAL_3");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_3");
          lCxSymbolCntrTabObj.spl_mrgn_sal_4  =  lResultSet.getDouble("SPL_MRGN_SAL_4");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_4");
          lCxSymbolCntrTabObj.status  =  lResultSet.getString("STATUS");
          lCxSymbolCntrTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxSymbolCntrTabObj.rec_cre_date != null && lCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxSymbolCntrTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxSymbolCntrTabObj.rec_upd_date != null && lCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxSymbolCntrTabObj( lCxSymbolCntrTabObj );

          outCxSymbolCntrTabObjArr.add(  lCxSymbolCntrTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolCntrTabObjArr != null && outCxSymbolCntrTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtCxSymbolCntrArr2XML
               ( String inCxSymbolCntrWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtCxSymbolCntrArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<CxSymbolCntr>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("contract_id") )
              lXmlBuffer = lXmlBuffer +   "<CONTRACT_ID>" +  lResultSet.getString("CONTRACT_ID") +   "</CONTRACT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_cd") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_CD>" +  lResultSet.getString("SYMBOL_CD") +   "</SYMBOL_CD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("symbol_name") )
              lXmlBuffer = lXmlBuffer +   "<SYMBOL_NAME>" +  lResultSet.getString("SYMBOL_NAME") +   "</SYMBOL_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("eff_date") )
              lXmlBuffer = lXmlBuffer +   "<EFF_DATE>" +  lResultSet.getString("EFF_DATE") +   "</EFF_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("eff_time") )
              lXmlBuffer = lXmlBuffer +   "<EFF_TIME>" +  lResultSet.getString("EFF_TIME") +   "</EFF_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_date") )
              lXmlBuffer = lXmlBuffer +   "<EXP_DATE>" +  lResultSet.getString("EXP_DATE") +   "</EXP_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_time") )
              lXmlBuffer = lXmlBuffer +   "<EXP_TIME>" +  lResultSet.getString("EXP_TIME") +   "</EXP_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ddr") )
              lXmlBuffer = lXmlBuffer +   "<DDR>" +  lResultSet.getDouble("DDR") +   "</DDR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exp_rate") )
              lXmlBuffer = lXmlBuffer +   "<EXP_RATE>" +  lResultSet.getDouble("EXP_RATE") +   "</EXP_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate_currency") )
              lXmlBuffer = lXmlBuffer +   "<RATE_CURRENCY>" +  lResultSet.getString("RATE_CURRENCY") +   "</RATE_CURRENCY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rate_per_uom") )
              lXmlBuffer = lXmlBuffer +   "<RATE_PER_UOM>" +  lResultSet.getString("RATE_PER_UOM") +   "</RATE_PER_UOM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_1") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_1>" +  lResultSet.getDouble("SPL_MRGN_PUR_1") +   "</SPL_MRGN_PUR_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_rt_1") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_RT_1>" +  lResultSet.getDouble("SPL_MRGN_PUR_RT_1") +   "</SPL_MRGN_PUR_RT_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_2") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_2>" +  lResultSet.getDouble("SPL_MRGN_PUR_2") +   "</SPL_MRGN_PUR_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_rt_2") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_RT_2>" +  lResultSet.getDouble("SPL_MRGN_PUR_RT_2") +   "</SPL_MRGN_PUR_RT_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_3") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_3>" +  lResultSet.getDouble("SPL_MRGN_PUR_3") +   "</SPL_MRGN_PUR_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_rt_3") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_RT_3>" +  lResultSet.getDouble("SPL_MRGN_PUR_RT_3") +   "</SPL_MRGN_PUR_RT_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_4") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_4>" +  lResultSet.getDouble("SPL_MRGN_PUR_4") +   "</SPL_MRGN_PUR_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_pur_rt_4") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_PUR_RT_4>" +  lResultSet.getDouble("SPL_MRGN_PUR_RT_4") +   "</SPL_MRGN_PUR_RT_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_1") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_1>" +  lResultSet.getDouble("SPL_MRGN_SAL_1") +   "</SPL_MRGN_SAL_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_rt_1") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_RT_1>" +  lResultSet.getDouble("SPL_MRGN_SAL_RT_1") +   "</SPL_MRGN_SAL_RT_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_2") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_2>" +  lResultSet.getDouble("SPL_MRGN_SAL_2") +   "</SPL_MRGN_SAL_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_rt_2") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_RT_2>" +  lResultSet.getDouble("SPL_MRGN_SAL_RT_2") +   "</SPL_MRGN_SAL_RT_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_3") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_3>" +  lResultSet.getDouble("SPL_MRGN_SAL_3") +   "</SPL_MRGN_SAL_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_rt_3") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_RT_3>" +  lResultSet.getDouble("SPL_MRGN_SAL_RT_3") +   "</SPL_MRGN_SAL_RT_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_4") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_4>" +  lResultSet.getDouble("SPL_MRGN_SAL_4") +   "</SPL_MRGN_SAL_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_mrgn_sal_rt_4") )
              lXmlBuffer = lXmlBuffer +   "<SPL_MRGN_SAL_RT_4>" +  lResultSet.getDouble("SPL_MRGN_SAL_RT_4") +   "</SPL_MRGN_SAL_RT_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</CxSymbolCntr>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtCxSymbolCntrRecByRowid
               ( String inRowId
               , CxSymbolCntrTabObj  outCxSymbolCntrTabObj
               )
  {
    sop("gtCxSymbolCntrRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "ddr, "+
                                 "exp_rate, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "spl_mrgn_pur_1, "+
                                 "spl_mrgn_pur_rt_1, "+
                                 "spl_mrgn_pur_2, "+
                                 "spl_mrgn_pur_rt_2, "+
                                 "spl_mrgn_pur_3, "+
                                 "spl_mrgn_pur_rt_3, "+
                                 "spl_mrgn_pur_4, "+
                                 "spl_mrgn_pur_rt_4, "+
                                 "spl_mrgn_sal_1, "+
                                 "spl_mrgn_sal_rt_1, "+
                                 "spl_mrgn_sal_2, "+
                                 "spl_mrgn_sal_rt_2, "+
                                 "spl_mrgn_sal_3, "+
                                 "spl_mrgn_sal_rt_3, "+
                                 "spl_mrgn_sal_4, "+
                                 "spl_mrgn_sal_rt_4, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_SYMBOL_CNTR "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outCxSymbolCntrTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outCxSymbolCntrTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outCxSymbolCntrTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          outCxSymbolCntrTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          outCxSymbolCntrTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          outCxSymbolCntrTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( outCxSymbolCntrTabObj.eff_date != null && outCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            outCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          outCxSymbolCntrTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( outCxSymbolCntrTabObj.exp_date != null && outCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            outCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          outCxSymbolCntrTabObj.ddr  =  lResultSet.getDouble("DDR");
          outCxSymbolCntrTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          outCxSymbolCntrTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          outCxSymbolCntrTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          outCxSymbolCntrTabObj.spl_mrgn_pur_1  =  lResultSet.getDouble("SPL_MRGN_PUR_1");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_1");
          outCxSymbolCntrTabObj.spl_mrgn_pur_2  =  lResultSet.getDouble("SPL_MRGN_PUR_2");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_2");
          outCxSymbolCntrTabObj.spl_mrgn_pur_3  =  lResultSet.getDouble("SPL_MRGN_PUR_3");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_3");
          outCxSymbolCntrTabObj.spl_mrgn_pur_4  =  lResultSet.getDouble("SPL_MRGN_PUR_4");
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_4");
          outCxSymbolCntrTabObj.spl_mrgn_sal_1  =  lResultSet.getDouble("SPL_MRGN_SAL_1");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_1");
          outCxSymbolCntrTabObj.spl_mrgn_sal_2  =  lResultSet.getDouble("SPL_MRGN_SAL_2");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_2");
          outCxSymbolCntrTabObj.spl_mrgn_sal_3  =  lResultSet.getDouble("SPL_MRGN_SAL_3");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_3");
          outCxSymbolCntrTabObj.spl_mrgn_sal_4  =  lResultSet.getDouble("SPL_MRGN_SAL_4");
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_4");
          outCxSymbolCntrTabObj.status  =  lResultSet.getString("STATUS");
          outCxSymbolCntrTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outCxSymbolCntrTabObj.rec_cre_date != null && outCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            outCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outCxSymbolCntrTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outCxSymbolCntrTabObj.rec_upd_date != null && outCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            outCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
          outCxSymbolCntrTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullCxSymbolCntrTabObj( outCxSymbolCntrTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrArr
               ( String inCxSymbolCntrWhereText
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {
    sop("gtCxSymbolCntrArr - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "contract_id, "+
                                 "symbol_cd, "+
                                 "symbol_name, "+
                                 "eff_date, "+
                                 "eff_time, "+
                                 "exp_date, "+
                                 "exp_time, "+
                                 "ddr, "+
                                 "exp_rate, "+
                                 "rate_currency, "+
                                 "rate_per_uom, "+
                                 "spl_mrgn_pur_1, "+
                                 "spl_mrgn_pur_rt_1, "+
                                 "spl_mrgn_pur_2, "+
                                 "spl_mrgn_pur_rt_2, "+
                                 "spl_mrgn_pur_3, "+
                                 "spl_mrgn_pur_rt_3, "+
                                 "spl_mrgn_pur_4, "+
                                 "spl_mrgn_pur_rt_4, "+
                                 "spl_mrgn_sal_1, "+
                                 "spl_mrgn_sal_rt_1, "+
                                 "spl_mrgn_sal_2, "+
                                 "spl_mrgn_sal_rt_2, "+
                                 "spl_mrgn_sal_3, "+
                                 "spl_mrgn_sal_rt_3, "+
                                 "spl_mrgn_sal_4, "+
                                 "spl_mrgn_sal_rt_4, "+
                                 "status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          CxSymbolCntrTabObj  lCxSymbolCntrTabObj = new CxSymbolCntrTabObj();
          lCxSymbolCntrTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lCxSymbolCntrTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lCxSymbolCntrTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
          lCxSymbolCntrTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
          lCxSymbolCntrTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
          lCxSymbolCntrTabObj.eff_date  =  lResultSet.getString("EFF_DATE");

          if ( lCxSymbolCntrTabObj.eff_date != null && lCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            lCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
          lCxSymbolCntrTabObj.exp_date  =  lResultSet.getString("EXP_DATE");

          if ( lCxSymbolCntrTabObj.exp_date != null && lCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            lCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
          lCxSymbolCntrTabObj.ddr  =  lResultSet.getDouble("DDR");
          lCxSymbolCntrTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
          lCxSymbolCntrTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
          lCxSymbolCntrTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
          lCxSymbolCntrTabObj.spl_mrgn_pur_1  =  lResultSet.getDouble("SPL_MRGN_PUR_1");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_1");
          lCxSymbolCntrTabObj.spl_mrgn_pur_2  =  lResultSet.getDouble("SPL_MRGN_PUR_2");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_2");
          lCxSymbolCntrTabObj.spl_mrgn_pur_3  =  lResultSet.getDouble("SPL_MRGN_PUR_3");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_3");
          lCxSymbolCntrTabObj.spl_mrgn_pur_4  =  lResultSet.getDouble("SPL_MRGN_PUR_4");
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_4");
          lCxSymbolCntrTabObj.spl_mrgn_sal_1  =  lResultSet.getDouble("SPL_MRGN_SAL_1");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_1");
          lCxSymbolCntrTabObj.spl_mrgn_sal_2  =  lResultSet.getDouble("SPL_MRGN_SAL_2");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_2");
          lCxSymbolCntrTabObj.spl_mrgn_sal_3  =  lResultSet.getDouble("SPL_MRGN_SAL_3");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_3");
          lCxSymbolCntrTabObj.spl_mrgn_sal_4  =  lResultSet.getDouble("SPL_MRGN_SAL_4");
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_4");
          lCxSymbolCntrTabObj.status  =  lResultSet.getString("STATUS");
          lCxSymbolCntrTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lCxSymbolCntrTabObj.rec_cre_date != null && lCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lCxSymbolCntrTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lCxSymbolCntrTabObj.rec_upd_date != null && lCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
          lCxSymbolCntrTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullCxSymbolCntrTabObj( lCxSymbolCntrTabObj );

          outCxSymbolCntrTabObjArr.add(  lCxSymbolCntrTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolCntrTabObjArr != null && outCxSymbolCntrTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrArrDist
               ( String inCxSymbolCntrWhereText
               , String inDistCxSymbolCntrField
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {

    sop("gtCxSymbolCntrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";
  

       String lDistCxSymbolCntrFieldQry = inDistCxSymbolCntrField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxSymbolCntrFieldQry+
                         " FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxSymbolCntrField.substring(inDistCxSymbolCntrField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          CxSymbolCntrTabObj  lCxSymbolCntrTabObj = new CxSymbolCntrTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lCxSymbolCntrTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("contract_id") )
              lCxSymbolCntrTabObj.contract_id  =  lResultSet.getString("CONTRACT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_cd") )
              lCxSymbolCntrTabObj.symbol_cd  =  lResultSet.getString("SYMBOL_CD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("symbol_name") )
              lCxSymbolCntrTabObj.symbol_name  =  lResultSet.getString("SYMBOL_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("eff_date") )
              {
              lCxSymbolCntrTabObj.eff_date  =  lResultSet.getString("EFF_DATE");
  
          if ( lCxSymbolCntrTabObj.eff_date != null && lCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            lCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.eff_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("eff_time") )
              lCxSymbolCntrTabObj.eff_time  =  lResultSet.getString("EFF_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_date") )
              {
              lCxSymbolCntrTabObj.exp_date  =  lResultSet.getString("EXP_DATE");
  
          if ( lCxSymbolCntrTabObj.exp_date != null && lCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            lCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.exp_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_time") )
              lCxSymbolCntrTabObj.exp_time  =  lResultSet.getString("EXP_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ddr") )
              lCxSymbolCntrTabObj.ddr  =  lResultSet.getDouble("DDR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exp_rate") )
              lCxSymbolCntrTabObj.exp_rate  =  lResultSet.getDouble("EXP_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate_currency") )
              lCxSymbolCntrTabObj.rate_currency  =  lResultSet.getString("RATE_CURRENCY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rate_per_uom") )
              lCxSymbolCntrTabObj.rate_per_uom  =  lResultSet.getString("RATE_PER_UOM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_1") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_1  =  lResultSet.getDouble("SPL_MRGN_PUR_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_rt_1") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_2") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_2  =  lResultSet.getDouble("SPL_MRGN_PUR_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_rt_2") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_3") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_3  =  lResultSet.getDouble("SPL_MRGN_PUR_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_rt_3") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_4") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_4  =  lResultSet.getDouble("SPL_MRGN_PUR_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_pur_rt_4") )
              lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4  =  lResultSet.getDouble("SPL_MRGN_PUR_RT_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_1") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_1  =  lResultSet.getDouble("SPL_MRGN_SAL_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_rt_1") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_2") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_2  =  lResultSet.getDouble("SPL_MRGN_SAL_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_rt_2") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_3") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_3  =  lResultSet.getDouble("SPL_MRGN_SAL_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_rt_3") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_4") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_4  =  lResultSet.getDouble("SPL_MRGN_SAL_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_mrgn_sal_rt_4") )
              lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4  =  lResultSet.getDouble("SPL_MRGN_SAL_RT_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lCxSymbolCntrTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lCxSymbolCntrTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lCxSymbolCntrTabObj.rec_cre_date != null && lCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lCxSymbolCntrTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lCxSymbolCntrTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lCxSymbolCntrTabObj.rec_upd_date != null && lCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lCxSymbolCntrTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lCxSymbolCntrTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          }
          removeNullCxSymbolCntrTabObj( lCxSymbolCntrTabObj );

          outCxSymbolCntrTabObjArr.add(  lCxSymbolCntrTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolCntrTabObjArr != null && outCxSymbolCntrTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtCxSymbolCntrStrArrDist
               ( String inCxSymbolCntrWhereText
               , String inDistCxSymbolCntrField
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {

    sop("gtCxSymbolCntrStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtCxSymbolCntrStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";
  

       String lDistCxSymbolCntrFieldQry = inDistCxSymbolCntrField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistCxSymbolCntrFieldQry+
                         " FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistCxSymbolCntrField.substring(inDistCxSymbolCntrField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lCxSymbolCntrTabObjStr = "";
       while(lResultSet.next())
       {
          lCxSymbolCntrTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lCxSymbolCntrTabObjStr =   lCxSymbolCntrTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outCxSymbolCntrTabObjArr.add(  lCxSymbolCntrTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outCxSymbolCntrTabObjArr != null && outCxSymbolCntrTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValCxSymbolCntr
               ( String inCxSymbolCntrWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValCxSymbolCntr - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValCxSymbolCntr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullCxSymbolCntrTabObj
               ( 
                 CxSymbolCntrTabObj  outCxSymbolCntrTabObj
               )
  {
  
    if ( outCxSymbolCntrTabObj.org_id == null ) 
     outCxSymbolCntrTabObj.org_id = ""; 
    if ( outCxSymbolCntrTabObj.contract_id == null ) 
     outCxSymbolCntrTabObj.contract_id = ""; 
    if ( outCxSymbolCntrTabObj.symbol_cd == null ) 
     outCxSymbolCntrTabObj.symbol_cd = ""; 
    if ( outCxSymbolCntrTabObj.symbol_name == null ) 
     outCxSymbolCntrTabObj.symbol_name = ""; 
    if ( outCxSymbolCntrTabObj.eff_date == null ) 
     outCxSymbolCntrTabObj.eff_date = ""; 
    if ( outCxSymbolCntrTabObj.eff_time == null ) 
     outCxSymbolCntrTabObj.eff_time = ""; 
    if ( outCxSymbolCntrTabObj.exp_date == null ) 
     outCxSymbolCntrTabObj.exp_date = ""; 
    if ( outCxSymbolCntrTabObj.exp_time == null ) 
     outCxSymbolCntrTabObj.exp_time = ""; 
    if ( outCxSymbolCntrTabObj.ddr == (double)0.00 ) 
     outCxSymbolCntrTabObj.ddr = (double)0.00; 
    if ( outCxSymbolCntrTabObj.exp_rate == (double)0.00 ) 
     outCxSymbolCntrTabObj.exp_rate = (double)0.00; 
    if ( outCxSymbolCntrTabObj.rate_currency == null ) 
     outCxSymbolCntrTabObj.rate_currency = ""; 
    if ( outCxSymbolCntrTabObj.rate_per_uom == null ) 
     outCxSymbolCntrTabObj.rate_per_uom = ""; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_1 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_1 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_2 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_2 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_3 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_3 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_4 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_4 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_1 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_1 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_2 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_2 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_3 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_3 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_4 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_4 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 == (double)0.00 ) 
     outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = (double)0.00; 
    if ( outCxSymbolCntrTabObj.status == null ) 
     outCxSymbolCntrTabObj.status = ""; 
    if ( outCxSymbolCntrTabObj.rec_cre_date == null ) 
     outCxSymbolCntrTabObj.rec_cre_date = ""; 
    if ( outCxSymbolCntrTabObj.rec_cre_time == null ) 
     outCxSymbolCntrTabObj.rec_cre_time = ""; 
    if ( outCxSymbolCntrTabObj.rec_upd_date == null ) 
     outCxSymbolCntrTabObj.rec_upd_date = ""; 
    if ( outCxSymbolCntrTabObj.rec_upd_time == null ) 
     outCxSymbolCntrTabObj.rec_upd_time = ""; 
  }





  public int insCxSymbolCntrRec
               ( CxSymbolCntrTabObj  inCxSymbolCntrTabObj )
  {
    int lUpdateCount;
    sop("insCxSymbolCntrRec - Started");
    gSSTErrorObj.sourceMethod = "insCxSymbolCntrRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolCntrTabObj.eff_date != null && inCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            inCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.exp_date != null && inCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            inCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_cre_date != null && inCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_upd_date != null && inCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_SYMBOL_CNTR"+
                        "("+
                                "org_id,"+
                                "contract_id,"+
                                "symbol_cd,"+
                                "symbol_name,"+
                                "eff_date,"+
                                "eff_time,"+
                                "exp_date,"+
                                "exp_time,"+
                                "ddr,"+
                                "exp_rate,"+
                                "rate_currency,"+
                                "rate_per_uom,"+
                                "spl_mrgn_pur_1,"+
                                "spl_mrgn_pur_rt_1,"+
                                "spl_mrgn_pur_2,"+
                                "spl_mrgn_pur_rt_2,"+
                                "spl_mrgn_pur_3,"+
                                "spl_mrgn_pur_rt_3,"+
                                "spl_mrgn_pur_4,"+
                                "spl_mrgn_pur_rt_4,"+
                                "spl_mrgn_sal_1,"+
                                "spl_mrgn_sal_rt_1,"+
                                "spl_mrgn_sal_2,"+
                                "spl_mrgn_sal_rt_2,"+
                                "spl_mrgn_sal_3,"+
                                "spl_mrgn_sal_rt_3,"+
                                "spl_mrgn_sal_4,"+
                                "spl_mrgn_sal_rt_4,"+
                                "status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.contract_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.symbol_cd+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.symbol_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.eff_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.eff_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.exp_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.exp_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.ddr+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.exp_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rate_currency+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rate_per_uom+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_rt_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_rt_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_rt_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_pur_rt_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_rt_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_rt_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_rt_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inCxSymbolCntrTabObj.spl_mrgn_sal_rt_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inCxSymbolCntrTabObj.rec_upd_time+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inCxSymbolCntrTabObj.org_id);
        lPreparedStatement.setString(2, inCxSymbolCntrTabObj.contract_id);
        lPreparedStatement.setString(3, inCxSymbolCntrTabObj.symbol_cd);
        lPreparedStatement.setString(4, inCxSymbolCntrTabObj.symbol_name);
        lPreparedStatement.setString(5, inCxSymbolCntrTabObj.eff_date);
        lPreparedStatement.setString(6, inCxSymbolCntrTabObj.eff_time);
        lPreparedStatement.setString(7, inCxSymbolCntrTabObj.exp_date);
        lPreparedStatement.setString(8, inCxSymbolCntrTabObj.exp_time);
          lPreparedStatement.setDouble(9, inCxSymbolCntrTabObj.ddr);
          lPreparedStatement.setDouble(10, inCxSymbolCntrTabObj.exp_rate);
        lPreparedStatement.setString(11, inCxSymbolCntrTabObj.rate_currency);
        lPreparedStatement.setString(12, inCxSymbolCntrTabObj.rate_per_uom);
          lPreparedStatement.setDouble(13, inCxSymbolCntrTabObj.spl_mrgn_pur_1);
          lPreparedStatement.setDouble(14, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_1);
          lPreparedStatement.setDouble(15, inCxSymbolCntrTabObj.spl_mrgn_pur_2);
          lPreparedStatement.setDouble(16, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_2);
          lPreparedStatement.setDouble(17, inCxSymbolCntrTabObj.spl_mrgn_pur_3);
          lPreparedStatement.setDouble(18, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_3);
          lPreparedStatement.setDouble(19, inCxSymbolCntrTabObj.spl_mrgn_pur_4);
          lPreparedStatement.setDouble(20, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_4);
          lPreparedStatement.setDouble(21, inCxSymbolCntrTabObj.spl_mrgn_sal_1);
          lPreparedStatement.setDouble(22, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_1);
          lPreparedStatement.setDouble(23, inCxSymbolCntrTabObj.spl_mrgn_sal_2);
          lPreparedStatement.setDouble(24, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_2);
          lPreparedStatement.setDouble(25, inCxSymbolCntrTabObj.spl_mrgn_sal_3);
          lPreparedStatement.setDouble(26, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_3);
          lPreparedStatement.setDouble(27, inCxSymbolCntrTabObj.spl_mrgn_sal_4);
          lPreparedStatement.setDouble(28, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_4);
        lPreparedStatement.setString(29, inCxSymbolCntrTabObj.status);
        lPreparedStatement.setString(30, inCxSymbolCntrTabObj.rec_cre_date);
        lPreparedStatement.setString(31, inCxSymbolCntrTabObj.rec_cre_time);
        lPreparedStatement.setString(32, inCxSymbolCntrTabObj.rec_upd_date);
        lPreparedStatement.setString(33, inCxSymbolCntrTabObj.rec_upd_time);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insCxSymbolCntrArr
               ( ArrayList  inCxSymbolCntrTabObjArr 
               , String  inRowidFlag )
  {
    CxSymbolCntrTabObj  lCxSymbolCntrTabObj = new CxSymbolCntrTabObj();
    int lUpdateCount;
    sop("insCxSymbolCntrArr - Started");
    gSSTErrorObj.sourceMethod = "insCxSymbolCntrArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inCxSymbolCntrTabObjArr.size(); lNumRec++ )
      {
        lCxSymbolCntrTabObj = (CxSymbolCntrTabObj)inCxSymbolCntrTabObjArr.get(lNumRec);

          if ( lCxSymbolCntrTabObj.eff_date != null && lCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            lCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolCntrTabObj.eff_date, lDateTimeSrcFmt);

          if ( lCxSymbolCntrTabObj.exp_date != null && lCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            lCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolCntrTabObj.exp_date, lDateTimeSrcFmt);

          if ( lCxSymbolCntrTabObj.rec_cre_date != null && lCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolCntrTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lCxSymbolCntrTabObj.rec_upd_date != null && lCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            lCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lCxSymbolCntrTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO CX_SYMBOL_CNTR"+
                        "("+
                        "org_id,"+
                        "contract_id,"+
                        "symbol_cd,"+
                        "symbol_name,"+
                        "eff_date,"+
                        "eff_time,"+
                        "exp_date,"+
                        "exp_time,"+
                        "ddr,"+
                        "exp_rate,"+
                        "rate_currency,"+
                        "rate_per_uom,"+
                        "spl_mrgn_pur_1,"+
                        "spl_mrgn_pur_rt_1,"+
                        "spl_mrgn_pur_2,"+
                        "spl_mrgn_pur_rt_2,"+
                        "spl_mrgn_pur_3,"+
                        "spl_mrgn_pur_rt_3,"+
                        "spl_mrgn_pur_4,"+
                        "spl_mrgn_pur_rt_4,"+
                        "spl_mrgn_sal_1,"+
                        "spl_mrgn_sal_rt_1,"+
                        "spl_mrgn_sal_2,"+
                        "spl_mrgn_sal_rt_2,"+
                        "spl_mrgn_sal_3,"+
                        "spl_mrgn_sal_rt_3,"+
                        "spl_mrgn_sal_4,"+
                        "spl_mrgn_sal_rt_4,"+
                        "status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.contract_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.symbol_cd+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.symbol_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.eff_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.eff_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.exp_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.exp_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.ddr+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.exp_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rate_currency+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rate_per_uom+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lCxSymbolCntrTabObj.rec_upd_time+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lCxSymbolCntrTabObj.org_id);
            lPreparedStatement.setString(2, lCxSymbolCntrTabObj.contract_id);
            lPreparedStatement.setString(3, lCxSymbolCntrTabObj.symbol_cd);
            lPreparedStatement.setString(4, lCxSymbolCntrTabObj.symbol_name);
            lPreparedStatement.setString(5, lCxSymbolCntrTabObj.eff_date);
            lPreparedStatement.setString(6, lCxSymbolCntrTabObj.eff_time);
            lPreparedStatement.setString(7, lCxSymbolCntrTabObj.exp_date);
            lPreparedStatement.setString(8, lCxSymbolCntrTabObj.exp_time);
              lPreparedStatement.setDouble(9, lCxSymbolCntrTabObj.ddr);
              lPreparedStatement.setDouble(10, lCxSymbolCntrTabObj.exp_rate);
            lPreparedStatement.setString(11, lCxSymbolCntrTabObj.rate_currency);
            lPreparedStatement.setString(12, lCxSymbolCntrTabObj.rate_per_uom);
              lPreparedStatement.setDouble(13, lCxSymbolCntrTabObj.spl_mrgn_pur_1);
              lPreparedStatement.setDouble(14, lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1);
              lPreparedStatement.setDouble(15, lCxSymbolCntrTabObj.spl_mrgn_pur_2);
              lPreparedStatement.setDouble(16, lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2);
              lPreparedStatement.setDouble(17, lCxSymbolCntrTabObj.spl_mrgn_pur_3);
              lPreparedStatement.setDouble(18, lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3);
              lPreparedStatement.setDouble(19, lCxSymbolCntrTabObj.spl_mrgn_pur_4);
              lPreparedStatement.setDouble(20, lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4);
              lPreparedStatement.setDouble(21, lCxSymbolCntrTabObj.spl_mrgn_sal_1);
              lPreparedStatement.setDouble(22, lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1);
              lPreparedStatement.setDouble(23, lCxSymbolCntrTabObj.spl_mrgn_sal_2);
              lPreparedStatement.setDouble(24, lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2);
              lPreparedStatement.setDouble(25, lCxSymbolCntrTabObj.spl_mrgn_sal_3);
              lPreparedStatement.setDouble(26, lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3);
              lPreparedStatement.setDouble(27, lCxSymbolCntrTabObj.spl_mrgn_sal_4);
              lPreparedStatement.setDouble(28, lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4);
            lPreparedStatement.setString(29, lCxSymbolCntrTabObj.status);
            lPreparedStatement.setString(30, lCxSymbolCntrTabObj.rec_cre_date);
            lPreparedStatement.setString(31, lCxSymbolCntrTabObj.rec_cre_time);
            lPreparedStatement.setString(32, lCxSymbolCntrTabObj.rec_upd_date);
            lPreparedStatement.setString(33, lCxSymbolCntrTabObj.rec_upd_time);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popCxSymbolCntrReq2Obj
               ( HttpServletRequest inRequest
               , CxSymbolCntrTabObj  outCxSymbolCntrTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outCxSymbolCntrTabObj.tab_rowid = lTabRowidValue;

    outCxSymbolCntrTabObj.org_id = inRequest.getParameter("org_id");
    outCxSymbolCntrTabObj.contract_id = inRequest.getParameter("contract_id");
    outCxSymbolCntrTabObj.symbol_cd = inRequest.getParameter("symbol_cd");
    outCxSymbolCntrTabObj.symbol_name = inRequest.getParameter("symbol_name");
    outCxSymbolCntrTabObj.eff_date = inRequest.getParameter("eff_date");
    outCxSymbolCntrTabObj.eff_time = inRequest.getParameter("eff_time");
    outCxSymbolCntrTabObj.exp_date = inRequest.getParameter("exp_date");
    outCxSymbolCntrTabObj.exp_time = inRequest.getParameter("exp_time");
    if ( inRequest.getParameter("ddr") == null )
      outCxSymbolCntrTabObj.ddr = 0;
    else
    if ( inRequest.getParameter("ddr").trim().length() == 0 )
      outCxSymbolCntrTabObj.ddr = 0;
    else
      outCxSymbolCntrTabObj.ddr = Double.parseDouble( inRequest.getParameter("ddr"));
    if ( inRequest.getParameter("exp_rate") == null )
      outCxSymbolCntrTabObj.exp_rate = 0;
    else
    if ( inRequest.getParameter("exp_rate").trim().length() == 0 )
      outCxSymbolCntrTabObj.exp_rate = 0;
    else
      outCxSymbolCntrTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate"));
    outCxSymbolCntrTabObj.rate_currency = inRequest.getParameter("rate_currency");
    outCxSymbolCntrTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom");
    if ( inRequest.getParameter("spl_mrgn_pur_1") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_1").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_1"));
    if ( inRequest.getParameter("spl_mrgn_pur_rt_1") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_rt_1").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_1"));
    if ( inRequest.getParameter("spl_mrgn_pur_2") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_2").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_2"));
    if ( inRequest.getParameter("spl_mrgn_pur_rt_2") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_rt_2").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_2"));
    if ( inRequest.getParameter("spl_mrgn_pur_3") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_3").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_3"));
    if ( inRequest.getParameter("spl_mrgn_pur_rt_3") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_rt_3").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_3"));
    if ( inRequest.getParameter("spl_mrgn_pur_4") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_4").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_4"));
    if ( inRequest.getParameter("spl_mrgn_pur_rt_4") == null )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_pur_rt_4").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_4"));
    if ( inRequest.getParameter("spl_mrgn_sal_1") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_1").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_1"));
    if ( inRequest.getParameter("spl_mrgn_sal_rt_1") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_rt_1").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_1"));
    if ( inRequest.getParameter("spl_mrgn_sal_2") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_2").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_2"));
    if ( inRequest.getParameter("spl_mrgn_sal_rt_2") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_rt_2").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_2"));
    if ( inRequest.getParameter("spl_mrgn_sal_3") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_3").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_3"));
    if ( inRequest.getParameter("spl_mrgn_sal_rt_3") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_rt_3").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_3"));
    if ( inRequest.getParameter("spl_mrgn_sal_4") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_4").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_4"));
    if ( inRequest.getParameter("spl_mrgn_sal_rt_4") == null )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
    else
    if ( inRequest.getParameter("spl_mrgn_sal_rt_4").trim().length() == 0 )
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
    else
      outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_4"));
    outCxSymbolCntrTabObj.status = inRequest.getParameter("status");
    outCxSymbolCntrTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outCxSymbolCntrTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outCxSymbolCntrTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outCxSymbolCntrTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    return lReturnValue;
  }


  public int popCxSymbolCntrReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxSymbolCntrTabObj lCxSymbolCntrTabObj= new CxSymbolCntrTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxSymbolCntrTabObj.tab_rowid = lTabRowidValue;

      lCxSymbolCntrTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lCxSymbolCntrTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
      lCxSymbolCntrTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
      lCxSymbolCntrTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
      lCxSymbolCntrTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
      lCxSymbolCntrTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
      lCxSymbolCntrTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
      lCxSymbolCntrTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
      if ( inRequest.getParameter("ddr_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.ddr = 0;
      else
      if ( inRequest.getParameter("ddr_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.ddr = 0;
      else
        lCxSymbolCntrTabObj.ddr = Double.parseDouble( inRequest.getParameter("ddr_r"+lNumRec));
      if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.exp_rate = 0;
      else
      if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.exp_rate = 0;
      else
        lCxSymbolCntrTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
      lCxSymbolCntrTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
      lCxSymbolCntrTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
      if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec));
      if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec) == null )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
      else
      if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec).trim().length() == 0 )
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
      else
        lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec));
      lCxSymbolCntrTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lCxSymbolCntrTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lCxSymbolCntrTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lCxSymbolCntrTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lCxSymbolCntrTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      outCxSymbolCntrTabObjArr.add( lCxSymbolCntrTabObj);
    }
    return lReturnValue;
  }


  public int popCxSymbolCntrReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , CxSymbolCntrTabObj outCxSymbolCntrTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_symbol_cntr_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outCxSymbolCntrTabObj.tab_rowid = lTabRowidValue;

        outCxSymbolCntrTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outCxSymbolCntrTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        outCxSymbolCntrTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        outCxSymbolCntrTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
        outCxSymbolCntrTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
        outCxSymbolCntrTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
        outCxSymbolCntrTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
        outCxSymbolCntrTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
        if ( inRequest.getParameter("ddr_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.ddr = 0;
        else
        if ( inRequest.getParameter("ddr_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.ddr = 0;
        else
          outCxSymbolCntrTabObj.ddr = Double.parseDouble( inRequest.getParameter("ddr_r"+lNumRec));
        if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.exp_rate = 0;
        else
        if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.exp_rate = 0;
        else
          outCxSymbolCntrTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
        outCxSymbolCntrTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
        outCxSymbolCntrTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
        if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec) == null )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec).trim().length() == 0 )
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
        else
          outCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec));
        outCxSymbolCntrTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outCxSymbolCntrTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outCxSymbolCntrTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outCxSymbolCntrTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outCxSymbolCntrTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popCxSymbolCntrReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outCxSymbolCntrTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      CxSymbolCntrTabObj lCxSymbolCntrTabObj= new CxSymbolCntrTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("cx_symbol_cntr_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lCxSymbolCntrTabObj.tab_rowid = lTabRowidValue;

        lCxSymbolCntrTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lCxSymbolCntrTabObj.contract_id = inRequest.getParameter("contract_id_r"+lNumRec);
        lCxSymbolCntrTabObj.symbol_cd = inRequest.getParameter("symbol_cd_r"+lNumRec);
        lCxSymbolCntrTabObj.symbol_name = inRequest.getParameter("symbol_name_r"+lNumRec);
        lCxSymbolCntrTabObj.eff_date = inRequest.getParameter("eff_date_r"+lNumRec);
        lCxSymbolCntrTabObj.eff_time = inRequest.getParameter("eff_time_r"+lNumRec);
        lCxSymbolCntrTabObj.exp_date = inRequest.getParameter("exp_date_r"+lNumRec);
        lCxSymbolCntrTabObj.exp_time = inRequest.getParameter("exp_time_r"+lNumRec);
        if ( inRequest.getParameter("ddr_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.ddr = 0;
        else
        if ( inRequest.getParameter("ddr_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.ddr = 0;
        else
            lCxSymbolCntrTabObj.ddr = Double.parseDouble( inRequest.getParameter("ddr_r"+lNumRec));
        if ( inRequest.getParameter("exp_rate_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.exp_rate = 0;
        else
        if ( inRequest.getParameter("exp_rate_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.exp_rate = 0;
        else
            lCxSymbolCntrTabObj.exp_rate = Double.parseDouble( inRequest.getParameter("exp_rate_r"+lNumRec));
        lCxSymbolCntrTabObj.rate_currency = inRequest.getParameter("rate_currency_r"+lNumRec);
        lCxSymbolCntrTabObj.rate_per_uom = inRequest.getParameter("rate_per_uom_r"+lNumRec);
        if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_1 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_2 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_3 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_4 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_pur_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_pur_rt_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_1 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_rt_1 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_1_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_2 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_rt_2 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_2_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_3 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_rt_3 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_3_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_4 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_4_r"+lNumRec));
        if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec) == null )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
        else
        if ( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec).trim().length() == 0 )
          lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = 0;
        else
            lCxSymbolCntrTabObj.spl_mrgn_sal_rt_4 = Double.parseDouble( inRequest.getParameter("spl_mrgn_sal_rt_4_r"+lNumRec));
        lCxSymbolCntrTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lCxSymbolCntrTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lCxSymbolCntrTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lCxSymbolCntrTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lCxSymbolCntrTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outCxSymbolCntrTabObjArr.add( lCxSymbolCntrTabObj);
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolCntrRecByRowid
               ( String inRowId
               , CxSymbolCntrTabObj  inCxSymbolCntrTabObj
               )
  {
    int lUpdateCount;
    sop("updCxSymbolCntrRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolCntrRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolCntrTabObj.eff_date != null && inCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            inCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.exp_date != null && inCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            inCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_cre_date != null && inCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_upd_date != null && inCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_CNTR ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inCxSymbolCntrTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxSymbolCntrTabObj.org_id+"', ";
      if ( inCxSymbolCntrTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxSymbolCntrTabObj.contract_id+"', ";
      if ( inCxSymbolCntrTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxSymbolCntrTabObj.symbol_cd+"', ";
      if ( inCxSymbolCntrTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = "+"'"+inCxSymbolCntrTabObj.symbol_name+"', ";
      if ( inCxSymbolCntrTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = "+"'"+inCxSymbolCntrTabObj.eff_date+"', ";
      if ( inCxSymbolCntrTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = "+"'"+inCxSymbolCntrTabObj.eff_time+"', ";
      if ( inCxSymbolCntrTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = "+"'"+inCxSymbolCntrTabObj.exp_date+"', ";
      if ( inCxSymbolCntrTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = "+"'"+inCxSymbolCntrTabObj.exp_time+"', ";
             lSqlStmt = lSqlStmt + "ddr = "+inCxSymbolCntrTabObj.ddr+", ";
             lSqlStmt = lSqlStmt + "exp_rate = "+inCxSymbolCntrTabObj.exp_rate+", ";
      if ( inCxSymbolCntrTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = "+"'"+inCxSymbolCntrTabObj.rate_currency+"', ";
      if ( inCxSymbolCntrTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = "+"'"+inCxSymbolCntrTabObj.rate_per_uom+"', ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_1 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_1+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_1 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_1+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_2 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_2+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_2 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_2+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_3 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_3+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_3 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_3+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_4 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_4+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_4 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_4+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_1 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_1+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_1 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_1+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_2 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_2+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_2 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_2+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_3 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_3+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_3 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_3+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_4 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_4+", ";
             lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_4 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_4+", ";
      if ( inCxSymbolCntrTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxSymbolCntrTabObj.status+"', ";
      if ( inCxSymbolCntrTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxSymbolCntrTabObj.rec_cre_date+"', ";
      if ( inCxSymbolCntrTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxSymbolCntrTabObj.rec_cre_time+"', ";
      if ( inCxSymbolCntrTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxSymbolCntrTabObj.rec_upd_date+"', ";
      if ( inCxSymbolCntrTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxSymbolCntrTabObj.rec_upd_time+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolCntrRecByPkey
               ( CxSymbolCntrPkeyObj inCxSymbolCntrPkeyObj
               , CxSymbolCntrTabObj  inCxSymbolCntrTabObj
               )
  {
    int lUpdateCount;
    sop("updCxSymbolCntrRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolCntrRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inCxSymbolCntrTabObj.eff_date != null && inCxSymbolCntrTabObj.eff_date.length() > 0 ) 
            inCxSymbolCntrTabObj.eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.eff_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.exp_date != null && inCxSymbolCntrTabObj.exp_date.length() > 0 ) 
            inCxSymbolCntrTabObj.exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.exp_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_cre_date != null && inCxSymbolCntrTabObj.rec_cre_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inCxSymbolCntrTabObj.rec_upd_date != null && inCxSymbolCntrTabObj.rec_upd_date.length() > 0 ) 
            inCxSymbolCntrTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inCxSymbolCntrTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_CNTR ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inCxSymbolCntrTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inCxSymbolCntrTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = ? , ";
        if ( inCxSymbolCntrTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = ? , ";
        if ( inCxSymbolCntrTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = ? , ";
        if ( inCxSymbolCntrTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = ? , ";
        if ( inCxSymbolCntrTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = ? , ";
        if ( inCxSymbolCntrTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = ? , ";
        if ( inCxSymbolCntrTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = ? , ";
               lSqlStmt = lSqlStmt + "ddr = ? , ";
               lSqlStmt = lSqlStmt + "exp_rate = ? , ";
        if ( inCxSymbolCntrTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = ? , ";
        if ( inCxSymbolCntrTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_1 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_1 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_2 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_2 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_3 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_3 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_4 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_4 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_1 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_1 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_2 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_2 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_3 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_3 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_4 = ? , ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_4 = ? , ";
        if ( inCxSymbolCntrTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inCxSymbolCntrTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inCxSymbolCntrTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inCxSymbolCntrTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inCxSymbolCntrTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inCxSymbolCntrTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inCxSymbolCntrTabObj.org_id+"', ";
        if ( inCxSymbolCntrTabObj.contract_id != null  )         lSqlStmt = lSqlStmt + "contract_id = "+"'"+inCxSymbolCntrTabObj.contract_id+"', ";
        if ( inCxSymbolCntrTabObj.symbol_cd != null  )         lSqlStmt = lSqlStmt + "symbol_cd = "+"'"+inCxSymbolCntrTabObj.symbol_cd+"', ";
        if ( inCxSymbolCntrTabObj.symbol_name != null  )         lSqlStmt = lSqlStmt + "symbol_name = "+"'"+inCxSymbolCntrTabObj.symbol_name+"', ";
        if ( inCxSymbolCntrTabObj.eff_date != null  )         lSqlStmt = lSqlStmt + "eff_date = "+"'"+inCxSymbolCntrTabObj.eff_date+"', ";
        if ( inCxSymbolCntrTabObj.eff_time != null  )         lSqlStmt = lSqlStmt + "eff_time = "+"'"+inCxSymbolCntrTabObj.eff_time+"', ";
        if ( inCxSymbolCntrTabObj.exp_date != null  )         lSqlStmt = lSqlStmt + "exp_date = "+"'"+inCxSymbolCntrTabObj.exp_date+"', ";
        if ( inCxSymbolCntrTabObj.exp_time != null  )         lSqlStmt = lSqlStmt + "exp_time = "+"'"+inCxSymbolCntrTabObj.exp_time+"', ";
               lSqlStmt = lSqlStmt + "ddr = "+inCxSymbolCntrTabObj.ddr+", ";
               lSqlStmt = lSqlStmt + "exp_rate = "+inCxSymbolCntrTabObj.exp_rate+", ";
        if ( inCxSymbolCntrTabObj.rate_currency != null  )         lSqlStmt = lSqlStmt + "rate_currency = "+"'"+inCxSymbolCntrTabObj.rate_currency+"', ";
        if ( inCxSymbolCntrTabObj.rate_per_uom != null  )         lSqlStmt = lSqlStmt + "rate_per_uom = "+"'"+inCxSymbolCntrTabObj.rate_per_uom+"', ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_1 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_1+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_1 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_1+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_2 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_2+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_2 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_2+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_3 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_3+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_3 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_3+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_4 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_4+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_pur_rt_4 = "+inCxSymbolCntrTabObj.spl_mrgn_pur_rt_4+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_1 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_1+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_1 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_1+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_2 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_2+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_2 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_2+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_3 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_3+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_3 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_3+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_4 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_4+", ";
               lSqlStmt = lSqlStmt + "spl_mrgn_sal_rt_4 = "+inCxSymbolCntrTabObj.spl_mrgn_sal_rt_4+", ";
        if ( inCxSymbolCntrTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inCxSymbolCntrTabObj.status+"', ";
        if ( inCxSymbolCntrTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inCxSymbolCntrTabObj.rec_cre_date+"', ";
        if ( inCxSymbolCntrTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inCxSymbolCntrTabObj.rec_cre_time+"', ";
        if ( inCxSymbolCntrTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inCxSymbolCntrTabObj.rec_upd_date+"', ";
        if ( inCxSymbolCntrTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inCxSymbolCntrTabObj.rec_upd_time+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolCntrPkeyObj.org_id+"' and "+
                              "contract_id = "+"'"+inCxSymbolCntrPkeyObj.contract_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inCxSymbolCntrTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.org_id); } 
         if ( inCxSymbolCntrTabObj.contract_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.contract_id); } 
         if ( inCxSymbolCntrTabObj.symbol_cd != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.symbol_cd); } 
         if ( inCxSymbolCntrTabObj.symbol_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.symbol_name); } 
         if ( inCxSymbolCntrTabObj.eff_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.eff_date); } 
         if ( inCxSymbolCntrTabObj.eff_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.eff_time); } 
         if ( inCxSymbolCntrTabObj.exp_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.exp_date); } 
         if ( inCxSymbolCntrTabObj.exp_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.exp_time); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(9, inCxSymbolCntrTabObj.ddr);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(10, inCxSymbolCntrTabObj.exp_rate);
         if ( inCxSymbolCntrTabObj.rate_currency != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rate_currency); } 
         if ( inCxSymbolCntrTabObj.rate_per_uom != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rate_per_uom); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(13, inCxSymbolCntrTabObj.spl_mrgn_pur_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(14, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(15, inCxSymbolCntrTabObj.spl_mrgn_pur_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(16, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(17, inCxSymbolCntrTabObj.spl_mrgn_pur_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(18, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(19, inCxSymbolCntrTabObj.spl_mrgn_pur_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(20, inCxSymbolCntrTabObj.spl_mrgn_pur_rt_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(21, inCxSymbolCntrTabObj.spl_mrgn_sal_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(22, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(23, inCxSymbolCntrTabObj.spl_mrgn_sal_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(24, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(25, inCxSymbolCntrTabObj.spl_mrgn_sal_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(26, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(27, inCxSymbolCntrTabObj.spl_mrgn_sal_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(28, inCxSymbolCntrTabObj.spl_mrgn_sal_rt_4);
         if ( inCxSymbolCntrTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.status); } 
         if ( inCxSymbolCntrTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rec_cre_date); } 
         if ( inCxSymbolCntrTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rec_cre_time); } 
         if ( inCxSymbolCntrTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rec_upd_date); } 
         if ( inCxSymbolCntrTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inCxSymbolCntrTabObj.rec_upd_time); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolCntrRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delCxSymbolCntrRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolCntrRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   CX_SYMBOL_CNTR "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolCntrRecByPkeyWithSet
               ( CxSymbolCntrPkeyObj inCxSymbolCntrPkeyObj
               , String  inCxSymbolCntrSetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolCntrRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolCntrRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_CNTR ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxSymbolCntrSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolCntrPkeyObj.org_id+"' and "+
                              "contract_id = "+"'"+inCxSymbolCntrPkeyObj.contract_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolCntrRecByRowidWithSet
               ( String inRowId
               , String  inCxSymbolCntrSetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolCntrRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolCntrRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_CNTR ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inCxSymbolCntrSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updCxSymbolCntrRecByWhereWithSet
               ( String inCxSymbolCntrWhereText
               , String  inCxSymbolCntrSetlist
               )
  {
    int lUpdateCount;
    sop("updCxSymbolCntrRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updCxSymbolCntrRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE CX_SYMBOL_CNTR ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inCxSymbolCntrSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolCntrRecByPkey
               ( CxSymbolCntrPkeyObj  inCxSymbolCntrPkeyObj
               )
  {
    int lUpdateCount;
    sop("delCxSymbolCntrRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolCntrRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   CX_SYMBOL_CNTR " + 
                         "WHERE "+
                              "org_id = "+"'"+inCxSymbolCntrPkeyObj.org_id+"' and "+
                              "contract_id = "+"'"+inCxSymbolCntrPkeyObj.contract_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delCxSymbolCntrByWhere
               ( String inCxSymbolCntrWhereText
               )
  {
    int lUpdateCount;
    sop("delCxSymbolCntrByWhere - Started");
    gSSTErrorObj.sourceMethod = "delCxSymbolCntrByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inCxSymbolCntrWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inCxSymbolCntrWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   CX_SYMBOL_CNTR "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
