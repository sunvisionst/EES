ALTER TABLE           CX_DTXN_CF
  ADD                 CONSTRAINT CX_DTXN_CF_PK
  PRIMARY             KEY
  ( ORG_ID, TXN_NUM )
;
