package sstdb.dm.DmCustAgreement;


public class DmCustAgreementTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 rp_id;
  public String                                 allowance_id;
  public String                                 dept_id;
  public String                                 position_id;
  public String                                 level_id;
  public int                                  seq_num;
  public String                                 benefit_flag;
  public String                                 allowance_type;
  public String                                 amount_flag;
  public double                                 default_amount;
  public double                                 billing_charge;
  public double                                 paying_charge;
  public String                                 vacation_code;
  public int                                  leave_quota;
  public String                                 salary_flag;
  public String                                 active_flag;
  public String                                 tax_flag;
  public float                                 tax_percent;
  public String                                 sal_deduction_flag;
  public String                                 remark;
  public String                                 agreement_sts;
  public String                                 agreement_sts_date;
  public String                                 effective_date;
  public String                                 expiration_date;
  public String                                 wages_print_ind;
  public String                                 wages_tot_calc_ind;
  public String                                 rec_status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 file_name;
  public String                                 file_cre_date;
  public String                                 file_cre_time;
  public String                                 file_status;





  public short                                  org_id_ind;
  public short                                  customer_id_ind;
  public short                                  rp_id_ind;
  public short                                  allowance_id_ind;
  public short                                  dept_id_ind;
  public short                                  position_id_ind;
  public short                                  level_id_ind;
  public short                                  seq_num_ind;
  public short                                  benefit_flag_ind;
  public short                                  allowance_type_ind;
  public short                                  amount_flag_ind;
  public short                                  default_amount_ind;
  public short                                  billing_charge_ind;
  public short                                  paying_charge_ind;
  public short                                  vacation_code_ind;
  public short                                  leave_quota_ind;
  public short                                  salary_flag_ind;
  public short                                  active_flag_ind;
  public short                                  tax_flag_ind;
  public short                                  tax_percent_ind;
  public short                                  sal_deduction_flag_ind;
  public short                                  remark_ind;
  public short                                  agreement_sts_ind;
  public short                                  agreement_sts_date_ind;
  public short                                  effective_date_ind;
  public short                                  expiration_date_ind;
  public short                                  wages_print_ind_ind;
  public short                                  wages_tot_calc_ind_ind;
  public short                                  rec_status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  file_name_ind;
  public short                                  file_cre_date_ind;
  public short                                  file_cre_time_ind;
  public short                                  file_status_ind;


  public DmCustAgreementTabObj(){}


  public DmCustAgreementTabObj
  (
    String org_id,
    String customer_id,
    String rp_id,
    String allowance_id,
    String dept_id,
    String position_id,
    String level_id,
    int seq_num,
    String benefit_flag,
    String allowance_type,
    String amount_flag,
    double default_amount,
    double billing_charge,
    double paying_charge,
    String vacation_code,
    int leave_quota,
    String salary_flag,
    String active_flag,
    String tax_flag,
    float tax_percent,
    String sal_deduction_flag,
    String remark,
    String agreement_sts,
    String agreement_sts_date,
    String effective_date,
    String expiration_date,
    String wages_print_ind,
    String wages_tot_calc_ind,
    String rec_status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String file_name,
    String file_cre_date,
    String file_cre_time,
    String file_status
  )
  {
     this.org_id = org_id;
     this.customer_id = customer_id;
     this.rp_id = rp_id;
     this.allowance_id = allowance_id;
     this.dept_id = dept_id;
     this.position_id = position_id;
     this.level_id = level_id;
     this.seq_num = seq_num;
     this.benefit_flag = benefit_flag;
     this.allowance_type = allowance_type;
     this.amount_flag = amount_flag;
     this.default_amount = default_amount;
     this.billing_charge = billing_charge;
     this.paying_charge = paying_charge;
     this.vacation_code = vacation_code;
     this.leave_quota = leave_quota;
     this.salary_flag = salary_flag;
     this.active_flag = active_flag;
     this.tax_flag = tax_flag;
     this.tax_percent = tax_percent;
     this.sal_deduction_flag = sal_deduction_flag;
     this.remark = remark;
     this.agreement_sts = agreement_sts;
     this.agreement_sts_date = agreement_sts_date;
     this.effective_date = effective_date;
     this.expiration_date = expiration_date;
     this.wages_print_ind = wages_print_ind;
     this.wages_tot_calc_ind = wages_tot_calc_ind;
     this.rec_status = rec_status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.file_name = file_name;
     this.file_cre_date = file_cre_date;
     this.file_cre_time = file_cre_time;
     this.file_status = file_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getcustomer_id()                        { return customer_id; }
  public String getrp_id()                           { return rp_id; }
  public String getallowance_id()                        { return allowance_id; }
  public String getdept_id()                          { return dept_id; }
  public String getposition_id()                        { return position_id; }
  public String getlevel_id()                          { return level_id; }
  public int getseq_num()                            { return seq_num; }
  public String getbenefit_flag()                        { return benefit_flag; }
  public String getallowance_type()                       { return allowance_type; }
  public String getamount_flag()                        { return amount_flag; }
  public double getdefault_amount()                       { return default_amount; }
  public double getbilling_charge()                       { return billing_charge; }
  public double getpaying_charge()                       { return paying_charge; }
  public String getvacation_code()                       { return vacation_code; }
  public int getleave_quota()                          { return leave_quota; }
  public String getsalary_flag()                        { return salary_flag; }
  public String getactive_flag()                        { return active_flag; }
  public String gettax_flag()                          { return tax_flag; }
  public float gettax_percent()                         { return tax_percent; }
  public String getsal_deduction_flag()                     { return sal_deduction_flag; }
  public String getremark()                           { return remark; }
  public String getagreement_sts()                       { return agreement_sts; }
  public String getagreement_sts_date()                     { return agreement_sts_date; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiration_date()                      { return expiration_date; }
  public String getwages_print_ind()                      { return wages_print_ind; }
  public String getwages_tot_calc_ind()                     { return wages_tot_calc_ind; }
  public String getrec_status()                         { return rec_status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String getfile_name()                         { return file_name; }
  public String getfile_cre_date()                       { return file_cre_date; }
  public String getfile_cre_time()                       { return file_cre_time; }
  public String getfile_status()                        { return file_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setrp_id(String rp_id )                     { this.rp_id = rp_id; }
  public void  setallowance_id(String allowance_id )              { this.allowance_id = allowance_id; }
  public void  setdept_id(String dept_id )                   { this.dept_id = dept_id; }
  public void  setposition_id(String position_id )               { this.position_id = position_id; }
  public void  setlevel_id(String level_id )                  { this.level_id = level_id; }
  public void  setseq_num(int seq_num )                     { this.seq_num = seq_num; }
  public void  setbenefit_flag(String benefit_flag )              { this.benefit_flag = benefit_flag; }
  public void  setallowance_type(String allowance_type )            { this.allowance_type = allowance_type; }
  public void  setamount_flag(String amount_flag )               { this.amount_flag = amount_flag; }
  public void  setdefault_amount(double default_amount )            { this.default_amount = default_amount; }
  public void  setbilling_charge(double billing_charge )            { this.billing_charge = billing_charge; }
  public void  setpaying_charge(double paying_charge )             { this.paying_charge = paying_charge; }
  public void  setvacation_code(String vacation_code )             { this.vacation_code = vacation_code; }
  public void  setleave_quota(int leave_quota )                 { this.leave_quota = leave_quota; }
  public void  setsalary_flag(String salary_flag )               { this.salary_flag = salary_flag; }
  public void  setactive_flag(String active_flag )               { this.active_flag = active_flag; }
  public void  settax_flag(String tax_flag )                  { this.tax_flag = tax_flag; }
  public void  settax_percent(float tax_percent )                { this.tax_percent = tax_percent; }
  public void  setsal_deduction_flag(String sal_deduction_flag )        { this.sal_deduction_flag = sal_deduction_flag; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setagreement_sts(String agreement_sts )             { this.agreement_sts = agreement_sts; }
  public void  setagreement_sts_date(String agreement_sts_date )        { this.agreement_sts_date = agreement_sts_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  setwages_print_ind(String wages_print_ind )           { this.wages_print_ind = wages_print_ind; }
  public void  setwages_tot_calc_ind(String wages_tot_calc_ind )        { this.wages_tot_calc_ind = wages_tot_calc_ind; }
  public void  setrec_status(String rec_status )                { this.rec_status = rec_status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  setfile_name(String file_name )                 { this.file_name = file_name; }
  public void  setfile_cre_date(String file_cre_date )             { this.file_cre_date = file_cre_date; }
  public void  setfile_cre_time(String file_cre_time )             { this.file_cre_time = file_cre_time; }
  public void  setfile_status(String file_status )               { this.file_status = file_status; }
}