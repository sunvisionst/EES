package sstdb.dm.DmSrcFile;


public class DmSrcFileTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 file_id;
  public String                                 file_type;
  public String                                 new_file_name;
  public String                                 new_file_cre_date;
  public String                                 new_file_cre_time;
  public String                                 file_status;
  public String                                 orig_file_name;
  public String                                 orig_file_cre_date;
  public String                                 orig_file_cre_time;





  public short                                  org_id_ind;
  public short                                  file_id_ind;
  public short                                  file_type_ind;
  public short                                  new_file_name_ind;
  public short                                  new_file_cre_date_ind;
  public short                                  new_file_cre_time_ind;
  public short                                  file_status_ind;
  public short                                  orig_file_name_ind;
  public short                                  orig_file_cre_date_ind;
  public short                                  orig_file_cre_time_ind;


  public DmSrcFileTabObj(){}


  public DmSrcFileTabObj
  (
    String org_id,
    String file_id,
    String file_type,
    String new_file_name,
    String new_file_cre_date,
    String new_file_cre_time,
    String file_status,
    String orig_file_name,
    String orig_file_cre_date,
    String orig_file_cre_time
  )
  {
     this.org_id = org_id;
     this.file_id = file_id;
     this.file_type = file_type;
     this.new_file_name = new_file_name;
     this.new_file_cre_date = new_file_cre_date;
     this.new_file_cre_time = new_file_cre_time;
     this.file_status = file_status;
     this.orig_file_name = orig_file_name;
     this.orig_file_cre_date = orig_file_cre_date;
     this.orig_file_cre_time = orig_file_cre_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getfile_id()                          { return file_id; }
  public String getfile_type()                         { return file_type; }
  public String getnew_file_name()                       { return new_file_name; }
  public String getnew_file_cre_date()                     { return new_file_cre_date; }
  public String getnew_file_cre_time()                     { return new_file_cre_time; }
  public String getfile_status()                        { return file_status; }
  public String getorig_file_name()                       { return orig_file_name; }
  public String getorig_file_cre_date()                     { return orig_file_cre_date; }
  public String getorig_file_cre_time()                     { return orig_file_cre_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setfile_id(String file_id )                   { this.file_id = file_id; }
  public void  setfile_type(String file_type )                 { this.file_type = file_type; }
  public void  setnew_file_name(String new_file_name )             { this.new_file_name = new_file_name; }
  public void  setnew_file_cre_date(String new_file_cre_date )         { this.new_file_cre_date = new_file_cre_date; }
  public void  setnew_file_cre_time(String new_file_cre_time )         { this.new_file_cre_time = new_file_cre_time; }
  public void  setfile_status(String file_status )               { this.file_status = file_status; }
  public void  setorig_file_name(String orig_file_name )            { this.orig_file_name = orig_file_name; }
  public void  setorig_file_cre_date(String orig_file_cre_date )        { this.orig_file_cre_date = orig_file_cre_date; }
  public void  setorig_file_cre_time(String orig_file_cre_time )        { this.orig_file_cre_time = orig_file_cre_time; }
}