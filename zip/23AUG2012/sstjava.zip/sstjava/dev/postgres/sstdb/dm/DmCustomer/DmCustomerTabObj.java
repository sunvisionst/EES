package sstdb.dm.DmCustomer;


public class DmCustomerTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 customer_type;
  public String                                 customer_ctg;
  public String                                 customer_name;
  public String                                 customer_group;
  public String                                 referred_by;
  public double                                 turn_over;
  public String                                 business_area_cd;
  public String                                 state_code;
  public String                                 region_id;
  public String                                 country_code;
  public String                                 status;
  public String                                 expiration_date;
  public String                                 effective_date;
  public String                                 business_type;
  public String                                 business_est_date;
  public int                                  employee_strength;
  public String                                 business_currency;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 address_3;
  public String                                 cst_form_num;
  public String                                 cst_form_date;
  public String                                 lst_form_num;
  public String                                 lst_form_date;
  public String                                 tin_num;
  public String                                 tin_date;
  public String                                 pan_num;
  public String                                 pan_date;
  public String                                 tan_num;
  public String                                 tan_date;
  public String                                 strn_num;
  public String                                 strn_date;
  public String                                 account_num;
  public double                                 bal_close;
  public double                                 bal_open;
  public double                                 dr_amt;
  public double                                 cr_amt;
  public double                                 ar_bal;
  public String                                 sal_cycle_code;
  public String                                 bill_cycle_code;
  public String                                 agreement_id;
  public String                                 agreement_eff_date;
  public String                                 agreement_exp_date;
  public String                                 agreement_cre_date;
  public String                                 agreement_sts;
  public String                                 agreement_sts_date;
  public String                                 prev_agreement_id;
  public String                                 renew_ind;
  public String                                 cycle_id;
  public String                                 spl_training_ind;
  public String                                 spl_uniform_ind;
  public byte                                  pay_day;
  public double                                 basic;
  public String                                 pf_ind;
  public double                                 pf_rate;
  public String                                 esi_ind;
  public double                                 esi_rate;
  public String                                 da_ind;
  public double                                 da_rate;
  public String                                 ta_ind;
  public double                                 ta_rate;
  public String                                 hra_ind;
  public double                                 hra_rate;
  public String                                 staff_wf_ind;
  public double                                 staff_wf_rate;
  public String                                 lunch_ind;
  public double                                 lunch_rate;
  public String                                 jurisdiction;
  public String                                 remark;
  public String                                 cacnel_remark;
  public double                                 service_charge;
  public double                                 service_tax;
  public String                                 weeken_off_ind;
  public int                                  working_days;
  public int                                  manpower_qty;
  public int                                  work_hour_qty;
  public int                                  ot_hour_qty;
  public String                                 labour_licence_ind;
  public String                                 labour_licence_num;
  public String                                 labour_licence_date;
  public String                                 labour_licence_exp_date;
  public String                                 rec_status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 file_name;
  public String                                 file_cre_date;
  public String                                 file_cre_time;
  public String                                 file_status;





  public short                                  org_id_ind;
  public short                                  customer_id_ind;
  public short                                  customer_type_ind;
  public short                                  customer_ctg_ind;
  public short                                  customer_name_ind;
  public short                                  customer_group_ind;
  public short                                  referred_by_ind;
  public short                                  turn_over_ind;
  public short                                  business_area_cd_ind;
  public short                                  state_code_ind;
  public short                                  region_id_ind;
  public short                                  country_code_ind;
  public short                                  status_ind;
  public short                                  expiration_date_ind;
  public short                                  effective_date_ind;
  public short                                  business_type_ind;
  public short                                  business_est_date_ind;
  public short                                  employee_strength_ind;
  public short                                  business_currency_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  address_3_ind;
  public short                                  cst_form_num_ind;
  public short                                  cst_form_date_ind;
  public short                                  lst_form_num_ind;
  public short                                  lst_form_date_ind;
  public short                                  tin_num_ind;
  public short                                  tin_date_ind;
  public short                                  pan_num_ind;
  public short                                  pan_date_ind;
  public short                                  tan_num_ind;
  public short                                  tan_date_ind;
  public short                                  strn_num_ind;
  public short                                  strn_date_ind;
  public short                                  account_num_ind;
  public short                                  bal_close_ind;
  public short                                  bal_open_ind;
  public short                                  dr_amt_ind;
  public short                                  cr_amt_ind;
  public short                                  ar_bal_ind;
  public short                                  sal_cycle_code_ind;
  public short                                  bill_cycle_code_ind;
  public short                                  agreement_id_ind;
  public short                                  agreement_eff_date_ind;
  public short                                  agreement_exp_date_ind;
  public short                                  agreement_cre_date_ind;
  public short                                  agreement_sts_ind;
  public short                                  agreement_sts_date_ind;
  public short                                  prev_agreement_id_ind;
  public short                                  renew_ind_ind;
  public short                                  cycle_id_ind;
  public short                                  spl_training_ind_ind;
  public short                                  spl_uniform_ind_ind;
  public short                                  pay_day_ind;
  public short                                  basic_ind;
  public short                                  pf_ind_ind;
  public short                                  pf_rate_ind;
  public short                                  esi_ind_ind;
  public short                                  esi_rate_ind;
  public short                                  da_ind_ind;
  public short                                  da_rate_ind;
  public short                                  ta_ind_ind;
  public short                                  ta_rate_ind;
  public short                                  hra_ind_ind;
  public short                                  hra_rate_ind;
  public short                                  staff_wf_ind_ind;
  public short                                  staff_wf_rate_ind;
  public short                                  lunch_ind_ind;
  public short                                  lunch_rate_ind;
  public short                                  jurisdiction_ind;
  public short                                  remark_ind;
  public short                                  cacnel_remark_ind;
  public short                                  service_charge_ind;
  public short                                  service_tax_ind;
  public short                                  weeken_off_ind_ind;
  public short                                  working_days_ind;
  public short                                  manpower_qty_ind;
  public short                                  work_hour_qty_ind;
  public short                                  ot_hour_qty_ind;
  public short                                  labour_licence_ind_ind;
  public short                                  labour_licence_num_ind;
  public short                                  labour_licence_date_ind;
  public short                                  labour_licence_exp_date_ind;
  public short                                  rec_status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  file_name_ind;
  public short                                  file_cre_date_ind;
  public short                                  file_cre_time_ind;
  public short                                  file_status_ind;


  public DmCustomerTabObj(){}


  public DmCustomerTabObj
  (
    String org_id,
    String customer_id,
    String customer_type,
    String customer_ctg,
    String customer_name,
    String customer_group,
    String referred_by,
    double turn_over,
    String business_area_cd,
    String state_code,
    String region_id,
    String country_code,
    String status,
    String expiration_date,
    String effective_date,
    String business_type,
    String business_est_date,
    int employee_strength,
    String business_currency,
    String address_1,
    String address_2,
    String address_3,
    String cst_form_num,
    String cst_form_date,
    String lst_form_num,
    String lst_form_date,
    String tin_num,
    String tin_date,
    String pan_num,
    String pan_date,
    String tan_num,
    String tan_date,
    String strn_num,
    String strn_date,
    String account_num,
    double bal_close,
    double bal_open,
    double dr_amt,
    double cr_amt,
    double ar_bal,
    String sal_cycle_code,
    String bill_cycle_code,
    String agreement_id,
    String agreement_eff_date,
    String agreement_exp_date,
    String agreement_cre_date,
    String agreement_sts,
    String agreement_sts_date,
    String prev_agreement_id,
    String renew_ind,
    String cycle_id,
    String spl_training_ind,
    String spl_uniform_ind,
    byte pay_day,
    double basic,
    String pf_ind,
    double pf_rate,
    String esi_ind,
    double esi_rate,
    String da_ind,
    double da_rate,
    String ta_ind,
    double ta_rate,
    String hra_ind,
    double hra_rate,
    String staff_wf_ind,
    double staff_wf_rate,
    String lunch_ind,
    double lunch_rate,
    String jurisdiction,
    String remark,
    String cacnel_remark,
    double service_charge,
    double service_tax,
    String weeken_off_ind,
    int working_days,
    int manpower_qty,
    int work_hour_qty,
    int ot_hour_qty,
    String labour_licence_ind,
    String labour_licence_num,
    String labour_licence_date,
    String labour_licence_exp_date,
    String rec_status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String file_name,
    String file_cre_date,
    String file_cre_time,
    String file_status
  )
  {
     this.org_id = org_id;
     this.customer_id = customer_id;
     this.customer_type = customer_type;
     this.customer_ctg = customer_ctg;
     this.customer_name = customer_name;
     this.customer_group = customer_group;
     this.referred_by = referred_by;
     this.turn_over = turn_over;
     this.business_area_cd = business_area_cd;
     this.state_code = state_code;
     this.region_id = region_id;
     this.country_code = country_code;
     this.status = status;
     this.expiration_date = expiration_date;
     this.effective_date = effective_date;
     this.business_type = business_type;
     this.business_est_date = business_est_date;
     this.employee_strength = employee_strength;
     this.business_currency = business_currency;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.address_3 = address_3;
     this.cst_form_num = cst_form_num;
     this.cst_form_date = cst_form_date;
     this.lst_form_num = lst_form_num;
     this.lst_form_date = lst_form_date;
     this.tin_num = tin_num;
     this.tin_date = tin_date;
     this.pan_num = pan_num;
     this.pan_date = pan_date;
     this.tan_num = tan_num;
     this.tan_date = tan_date;
     this.strn_num = strn_num;
     this.strn_date = strn_date;
     this.account_num = account_num;
     this.bal_close = bal_close;
     this.bal_open = bal_open;
     this.dr_amt = dr_amt;
     this.cr_amt = cr_amt;
     this.ar_bal = ar_bal;
     this.sal_cycle_code = sal_cycle_code;
     this.bill_cycle_code = bill_cycle_code;
     this.agreement_id = agreement_id;
     this.agreement_eff_date = agreement_eff_date;
     this.agreement_exp_date = agreement_exp_date;
     this.agreement_cre_date = agreement_cre_date;
     this.agreement_sts = agreement_sts;
     this.agreement_sts_date = agreement_sts_date;
     this.prev_agreement_id = prev_agreement_id;
     this.renew_ind = renew_ind;
     this.cycle_id = cycle_id;
     this.spl_training_ind = spl_training_ind;
     this.spl_uniform_ind = spl_uniform_ind;
     this.pay_day = pay_day;
     this.basic = basic;
     this.pf_ind = pf_ind;
     this.pf_rate = pf_rate;
     this.esi_ind = esi_ind;
     this.esi_rate = esi_rate;
     this.da_ind = da_ind;
     this.da_rate = da_rate;
     this.ta_ind = ta_ind;
     this.ta_rate = ta_rate;
     this.hra_ind = hra_ind;
     this.hra_rate = hra_rate;
     this.staff_wf_ind = staff_wf_ind;
     this.staff_wf_rate = staff_wf_rate;
     this.lunch_ind = lunch_ind;
     this.lunch_rate = lunch_rate;
     this.jurisdiction = jurisdiction;
     this.remark = remark;
     this.cacnel_remark = cacnel_remark;
     this.service_charge = service_charge;
     this.service_tax = service_tax;
     this.weeken_off_ind = weeken_off_ind;
     this.working_days = working_days;
     this.manpower_qty = manpower_qty;
     this.work_hour_qty = work_hour_qty;
     this.ot_hour_qty = ot_hour_qty;
     this.labour_licence_ind = labour_licence_ind;
     this.labour_licence_num = labour_licence_num;
     this.labour_licence_date = labour_licence_date;
     this.labour_licence_exp_date = labour_licence_exp_date;
     this.rec_status = rec_status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.file_name = file_name;
     this.file_cre_date = file_cre_date;
     this.file_cre_time = file_cre_time;
     this.file_status = file_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getcustomer_id()                        { return customer_id; }
  public String getcustomer_type()                       { return customer_type; }
  public String getcustomer_ctg()                        { return customer_ctg; }
  public String getcustomer_name()                       { return customer_name; }
  public String getcustomer_group()                       { return customer_group; }
  public String getreferred_by()                        { return referred_by; }
  public double getturn_over()                         { return turn_over; }
  public String getbusiness_area_cd()                      { return business_area_cd; }
  public String getstate_code()                         { return state_code; }
  public String getregion_id()                         { return region_id; }
  public String getcountry_code()                        { return country_code; }
  public String getstatus()                           { return status; }
  public String getexpiration_date()                      { return expiration_date; }
  public String geteffective_date()                       { return effective_date; }
  public String getbusiness_type()                       { return business_type; }
  public String getbusiness_est_date()                     { return business_est_date; }
  public int getemployee_strength()                       { return employee_strength; }
  public String getbusiness_currency()                     { return business_currency; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getaddress_3()                         { return address_3; }
  public String getcst_form_num()                        { return cst_form_num; }
  public String getcst_form_date()                       { return cst_form_date; }
  public String getlst_form_num()                        { return lst_form_num; }
  public String getlst_form_date()                       { return lst_form_date; }
  public String gettin_num()                          { return tin_num; }
  public String gettin_date()                          { return tin_date; }
  public String getpan_num()                          { return pan_num; }
  public String getpan_date()                          { return pan_date; }
  public String gettan_num()                          { return tan_num; }
  public String gettan_date()                          { return tan_date; }
  public String getstrn_num()                          { return strn_num; }
  public String getstrn_date()                         { return strn_date; }
  public String getaccount_num()                        { return account_num; }
  public double getbal_close()                         { return bal_close; }
  public double getbal_open()                          { return bal_open; }
  public double getdr_amt()                           { return dr_amt; }
  public double getcr_amt()                           { return cr_amt; }
  public double getar_bal()                           { return ar_bal; }
  public String getsal_cycle_code()                       { return sal_cycle_code; }
  public String getbill_cycle_code()                      { return bill_cycle_code; }
  public String getagreement_id()                        { return agreement_id; }
  public String getagreement_eff_date()                     { return agreement_eff_date; }
  public String getagreement_exp_date()                     { return agreement_exp_date; }
  public String getagreement_cre_date()                     { return agreement_cre_date; }
  public String getagreement_sts()                       { return agreement_sts; }
  public String getagreement_sts_date()                     { return agreement_sts_date; }
  public String getprev_agreement_id()                     { return prev_agreement_id; }
  public String getrenew_ind()                         { return renew_ind; }
  public String getcycle_id()                          { return cycle_id; }
  public String getspl_training_ind()                      { return spl_training_ind; }
  public String getspl_uniform_ind()                      { return spl_uniform_ind; }
  public byte getpay_day()                           { return pay_day; }
  public double getbasic()                           { return basic; }
  public String getpf_ind()                           { return pf_ind; }
  public double getpf_rate()                          { return pf_rate; }
  public String getesi_ind()                          { return esi_ind; }
  public double getesi_rate()                          { return esi_rate; }
  public String getda_ind()                           { return da_ind; }
  public double getda_rate()                          { return da_rate; }
  public String getta_ind()                           { return ta_ind; }
  public double getta_rate()                          { return ta_rate; }
  public String gethra_ind()                          { return hra_ind; }
  public double gethra_rate()                          { return hra_rate; }
  public String getstaff_wf_ind()                        { return staff_wf_ind; }
  public double getstaff_wf_rate()                       { return staff_wf_rate; }
  public String getlunch_ind()                         { return lunch_ind; }
  public double getlunch_rate()                         { return lunch_rate; }
  public String getjurisdiction()                        { return jurisdiction; }
  public String getremark()                           { return remark; }
  public String getcacnel_remark()                       { return cacnel_remark; }
  public double getservice_charge()                       { return service_charge; }
  public double getservice_tax()                        { return service_tax; }
  public String getweeken_off_ind()                       { return weeken_off_ind; }
  public int getworking_days()                         { return working_days; }
  public int getmanpower_qty()                         { return manpower_qty; }
  public int getwork_hour_qty()                         { return work_hour_qty; }
  public int getot_hour_qty()                          { return ot_hour_qty; }
  public String getlabour_licence_ind()                     { return labour_licence_ind; }
  public String getlabour_licence_num()                     { return labour_licence_num; }
  public String getlabour_licence_date()                    { return labour_licence_date; }
  public String getlabour_licence_exp_date()                  { return labour_licence_exp_date; }
  public String getrec_status()                         { return rec_status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String getfile_name()                         { return file_name; }
  public String getfile_cre_date()                       { return file_cre_date; }
  public String getfile_cre_time()                       { return file_cre_time; }
  public String getfile_status()                        { return file_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setcustomer_type(String customer_type )             { this.customer_type = customer_type; }
  public void  setcustomer_ctg(String customer_ctg )              { this.customer_ctg = customer_ctg; }
  public void  setcustomer_name(String customer_name )             { this.customer_name = customer_name; }
  public void  setcustomer_group(String customer_group )            { this.customer_group = customer_group; }
  public void  setreferred_by(String referred_by )               { this.referred_by = referred_by; }
  public void  setturn_over(double turn_over )                 { this.turn_over = turn_over; }
  public void  setbusiness_area_cd(String business_area_cd )          { this.business_area_cd = business_area_cd; }
  public void  setstate_code(String state_code )                { this.state_code = state_code; }
  public void  setregion_id(String region_id )                 { this.region_id = region_id; }
  public void  setcountry_code(String country_code )              { this.country_code = country_code; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setexpiration_date(String expiration_date )           { this.expiration_date = expiration_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setbusiness_type(String business_type )             { this.business_type = business_type; }
  public void  setbusiness_est_date(String business_est_date )         { this.business_est_date = business_est_date; }
  public void  setemployee_strength(int employee_strength )           { this.employee_strength = employee_strength; }
  public void  setbusiness_currency(String business_currency )         { this.business_currency = business_currency; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setaddress_3(String address_3 )                 { this.address_3 = address_3; }
  public void  setcst_form_num(String cst_form_num )              { this.cst_form_num = cst_form_num; }
  public void  setcst_form_date(String cst_form_date )             { this.cst_form_date = cst_form_date; }
  public void  setlst_form_num(String lst_form_num )              { this.lst_form_num = lst_form_num; }
  public void  setlst_form_date(String lst_form_date )             { this.lst_form_date = lst_form_date; }
  public void  settin_num(String tin_num )                   { this.tin_num = tin_num; }
  public void  settin_date(String tin_date )                  { this.tin_date = tin_date; }
  public void  setpan_num(String pan_num )                   { this.pan_num = pan_num; }
  public void  setpan_date(String pan_date )                  { this.pan_date = pan_date; }
  public void  settan_num(String tan_num )                   { this.tan_num = tan_num; }
  public void  settan_date(String tan_date )                  { this.tan_date = tan_date; }
  public void  setstrn_num(String strn_num )                  { this.strn_num = strn_num; }
  public void  setstrn_date(String strn_date )                 { this.strn_date = strn_date; }
  public void  setaccount_num(String account_num )               { this.account_num = account_num; }
  public void  setbal_close(double bal_close )                 { this.bal_close = bal_close; }
  public void  setbal_open(double bal_open )                  { this.bal_open = bal_open; }
  public void  setdr_amt(double dr_amt )                    { this.dr_amt = dr_amt; }
  public void  setcr_amt(double cr_amt )                    { this.cr_amt = cr_amt; }
  public void  setar_bal(double ar_bal )                    { this.ar_bal = ar_bal; }
  public void  setsal_cycle_code(String sal_cycle_code )            { this.sal_cycle_code = sal_cycle_code; }
  public void  setbill_cycle_code(String bill_cycle_code )           { this.bill_cycle_code = bill_cycle_code; }
  public void  setagreement_id(String agreement_id )              { this.agreement_id = agreement_id; }
  public void  setagreement_eff_date(String agreement_eff_date )        { this.agreement_eff_date = agreement_eff_date; }
  public void  setagreement_exp_date(String agreement_exp_date )        { this.agreement_exp_date = agreement_exp_date; }
  public void  setagreement_cre_date(String agreement_cre_date )        { this.agreement_cre_date = agreement_cre_date; }
  public void  setagreement_sts(String agreement_sts )             { this.agreement_sts = agreement_sts; }
  public void  setagreement_sts_date(String agreement_sts_date )        { this.agreement_sts_date = agreement_sts_date; }
  public void  setprev_agreement_id(String prev_agreement_id )         { this.prev_agreement_id = prev_agreement_id; }
  public void  setrenew_ind(String renew_ind )                 { this.renew_ind = renew_ind; }
  public void  setcycle_id(String cycle_id )                  { this.cycle_id = cycle_id; }
  public void  setspl_training_ind(String spl_training_ind )          { this.spl_training_ind = spl_training_ind; }
  public void  setspl_uniform_ind(String spl_uniform_ind )           { this.spl_uniform_ind = spl_uniform_ind; }
  public void  setpay_day(byte pay_day )                    { this.pay_day = pay_day; }
  public void  setbasic(double basic )                     { this.basic = basic; }
  public void  setpf_ind(String pf_ind )                    { this.pf_ind = pf_ind; }
  public void  setpf_rate(double pf_rate )                   { this.pf_rate = pf_rate; }
  public void  setesi_ind(String esi_ind )                   { this.esi_ind = esi_ind; }
  public void  setesi_rate(double esi_rate )                  { this.esi_rate = esi_rate; }
  public void  setda_ind(String da_ind )                    { this.da_ind = da_ind; }
  public void  setda_rate(double da_rate )                   { this.da_rate = da_rate; }
  public void  setta_ind(String ta_ind )                    { this.ta_ind = ta_ind; }
  public void  setta_rate(double ta_rate )                   { this.ta_rate = ta_rate; }
  public void  sethra_ind(String hra_ind )                   { this.hra_ind = hra_ind; }
  public void  sethra_rate(double hra_rate )                  { this.hra_rate = hra_rate; }
  public void  setstaff_wf_ind(String staff_wf_ind )              { this.staff_wf_ind = staff_wf_ind; }
  public void  setstaff_wf_rate(double staff_wf_rate )             { this.staff_wf_rate = staff_wf_rate; }
  public void  setlunch_ind(String lunch_ind )                 { this.lunch_ind = lunch_ind; }
  public void  setlunch_rate(double lunch_rate )                { this.lunch_rate = lunch_rate; }
  public void  setjurisdiction(String jurisdiction )              { this.jurisdiction = jurisdiction; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setcacnel_remark(String cacnel_remark )             { this.cacnel_remark = cacnel_remark; }
  public void  setservice_charge(double service_charge )            { this.service_charge = service_charge; }
  public void  setservice_tax(double service_tax )               { this.service_tax = service_tax; }
  public void  setweeken_off_ind(String weeken_off_ind )            { this.weeken_off_ind = weeken_off_ind; }
  public void  setworking_days(int working_days )                { this.working_days = working_days; }
  public void  setmanpower_qty(int manpower_qty )                { this.manpower_qty = manpower_qty; }
  public void  setwork_hour_qty(int work_hour_qty )               { this.work_hour_qty = work_hour_qty; }
  public void  setot_hour_qty(int ot_hour_qty )                 { this.ot_hour_qty = ot_hour_qty; }
  public void  setlabour_licence_ind(String labour_licence_ind )        { this.labour_licence_ind = labour_licence_ind; }
  public void  setlabour_licence_num(String labour_licence_num )        { this.labour_licence_num = labour_licence_num; }
  public void  setlabour_licence_date(String labour_licence_date )       { this.labour_licence_date = labour_licence_date; }
  public void  setlabour_licence_exp_date(String labour_licence_exp_date )   { this.labour_licence_exp_date = labour_licence_exp_date; }
  public void  setrec_status(String rec_status )                { this.rec_status = rec_status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  setfile_name(String file_name )                 { this.file_name = file_name; }
  public void  setfile_cre_date(String file_cre_date )             { this.file_cre_date = file_cre_date; }
  public void  setfile_cre_time(String file_cre_time )             { this.file_cre_time = file_cre_time; }
  public void  setfile_status(String file_status )               { this.file_status = file_status; }
}