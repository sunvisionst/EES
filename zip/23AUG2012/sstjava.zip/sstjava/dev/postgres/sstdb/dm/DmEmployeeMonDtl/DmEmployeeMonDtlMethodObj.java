package sstdb.dm.DmEmployeeMonDtl;

import sstdb.dm.DmEmployeeMonDtl.DmEmployeeMonDtlTabObj;
import sstdb.dm.DmEmployeeMonDtl.DmEmployeeMonDtlPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class DmEmployeeMonDtlMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public DmEmployeeMonDtlMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "DmEmployeeMonDtlMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initDmEmployeeMonDtlTabObj
               ( 
                 DmEmployeeMonDtlTabObj  outDmEmployeeMonDtlTabObj
               )
  {
  
     outDmEmployeeMonDtlTabObj.org_id = ""; 
     outDmEmployeeMonDtlTabObj.customer_id = ""; 
     outDmEmployeeMonDtlTabObj.employee_id = ""; 
     outDmEmployeeMonDtlTabObj.allocation_date = ""; 
     outDmEmployeeMonDtlTabObj.dept_id = ""; 
     outDmEmployeeMonDtlTabObj.position_id = ""; 
     outDmEmployeeMonDtlTabObj.level_id = ""; 
     outDmEmployeeMonDtlTabObj.name_initials = ""; 
     outDmEmployeeMonDtlTabObj.employee_name = ""; 
     outDmEmployeeMonDtlTabObj.emp_track_id = ""; 
     outDmEmployeeMonDtlTabObj.month_num = (int)0; 
     outDmEmployeeMonDtlTabObj.working_days = (float)0.00; 
     outDmEmployeeMonDtlTabObj.absent_days = (float)0.00; 
     outDmEmployeeMonDtlTabObj.wages_rate = (double)0.00; 
     outDmEmployeeMonDtlTabObj.gross_mon_wages = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_bas = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_da = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_hra = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_conv = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_woff = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_pf = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_esi = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.ot_hour = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_ot = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_oth_inc = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_adv = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_hra = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_weekoff = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_washing = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_areer = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_shift_alw = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_medi_alw = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_convy = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_insur = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_dress = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_swf_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_gen_fine = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_pc = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_sec_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_oth_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.act_amt_adv_ded = (double)0.00; 
     outDmEmployeeMonDtlTabObj.rec_status = ""; 
     outDmEmployeeMonDtlTabObj.rec_cre_date = ""; 
     outDmEmployeeMonDtlTabObj.rec_cre_time = ""; 
     outDmEmployeeMonDtlTabObj.rec_upd_date = ""; 
     outDmEmployeeMonDtlTabObj.rec_upd_time = ""; 
     outDmEmployeeMonDtlTabObj.file_name = ""; 
     outDmEmployeeMonDtlTabObj.file_cre_date = ""; 
     outDmEmployeeMonDtlTabObj.file_cre_time = ""; 
     outDmEmployeeMonDtlTabObj.file_status = ""; 
  }





  public void guiDateConvDmEmployeeMonDtlTabObj
               ( 
                 DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inDmEmployeeMonDtlTabObj.allocation_date != null && inDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null && inDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null && inDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);

          if ( inDmEmployeeMonDtlTabObj.file_cre_date != null && inDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
  }





  public void refreshCtxDmEmployeeMonDtlByTabObj
               ( 
                 DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lDmEmployeeMonDtlTabObjArrCtx  = new ArrayList(); 
    lDmEmployeeMonDtlTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lDmEmployeeMonDtlTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lDmEmployeeMonDtlTabObjArrCtx.add(inDmEmployeeMonDtlTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lDmEmployeeMonDtlTabObjArrCtx.size();  lRecNum++ )
      {
        DmEmployeeMonDtlTabObj lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj();
        lDmEmployeeMonDtlTabObj = (DmEmployeeMonDtlTabObj)lDmEmployeeMonDtlTabObjArrCtx.get(lRecNum);
    
        if ( 
              lDmEmployeeMonDtlTabObj.org_id.equals(lDmEmployeeMonDtlTabObj.org_id) &&
              lDmEmployeeMonDtlTabObj.customer_id.equals(lDmEmployeeMonDtlTabObj.customer_id) &&
              lDmEmployeeMonDtlTabObj.employee_id.equals(lDmEmployeeMonDtlTabObj.employee_id) &&
              lDmEmployeeMonDtlTabObj.allocation_date.equals(lDmEmployeeMonDtlTabObj.allocation_date) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lDmEmployeeMonDtlTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lDmEmployeeMonDtlTabObjArrCtx.set(lRecNum, inDmEmployeeMonDtlTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lDmEmployeeMonDtlTabObjArrCtx",lDmEmployeeMonDtlTabObjArrCtx);
  }





  public void sortDmEmployeeMonDtlTabObjArr
               ( 
                 ArrayList  inDmEmployeeMonDtlTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lDmEmployeeMonDtlTabObjArr  = new ArrayList(); 
     lDmEmployeeMonDtlTabObjArr = inDmEmployeeMonDtlTabObjArr; 
     List lDmEmployeeMonDtlTabObjList  = new ArrayList(lDmEmployeeMonDtlTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lDmEmployeeMonDtlTabObjArr.size();  lRecNum++ )
     {
       DmEmployeeMonDtlTabObj  lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj(); 
       lDmEmployeeMonDtlTabObj = (DmEmployeeMonDtlTabObj)lDmEmployeeMonDtlTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.customer_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.customer_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeMonDtlTabObj.employee_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.employee_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allocation_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeMonDtlTabObj.allocation_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.allocation_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dept_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.dept_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.dept_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("position_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.position_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.position_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("level_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.level_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.level_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("name_initials") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeMonDtlTabObj.name_initials.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.name_initials+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeMonDtlTabObj.employee_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.employee_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_track_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeMonDtlTabObj.emp_track_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.emp_track_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("month_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lDmEmployeeMonDtlTabObj.month_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.month_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("working_days") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lDmEmployeeMonDtlTabObj.working_days).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.working_days+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("absent_days") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lDmEmployeeMonDtlTabObj.absent_days).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.absent_days+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("wages_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.wages_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.wages_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gross_mon_wages") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.gross_mon_wages).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.gross_mon_wages+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_bas") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_bas).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_bas+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_da") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_da).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_da+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_hra") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_hra).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_hra+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_conv") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_conv).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_conv+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_woff") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_woff).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_woff+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_shift_alw") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_shift_alw).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_shift_alw+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_wash_alw") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_wash_alw).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_wash_alw+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_oth_inc") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_oth_inc).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_oth_inc+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_pf") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_pf).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_pf+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_esi") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_esi).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_esi+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_swf_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_swf_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_swf_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sh_amt_oth_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.sh_amt_oth_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.sh_amt_oth_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ot_hour") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.ot_hour).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.ot_hour+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_ot") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_ot).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_ot+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_oth_inc") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_oth_inc).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_oth_inc+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_adv") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_adv).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_adv+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_hra") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_hra).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_hra+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_weekoff") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_weekoff).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_weekoff+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_washing") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_washing).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_washing+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_areer") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_areer).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_areer+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_shift_alw") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_shift_alw).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_shift_alw+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_medi_alw") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_medi_alw).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_medi_alw+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_convy") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_convy).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_convy+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_insur") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_insur).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_insur+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_dress") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_dress).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_dress+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_swf_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_swf_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_swf_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_gen_fine") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_gen_fine).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_gen_fine+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_pc") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_pc).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_pc+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_sec_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_sec_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_sec_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_oth_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_oth_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_oth_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("act_amt_adv_ded") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeMonDtlTabObj.act_amt_adv_ded).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.act_amt_adv_ded+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeMonDtlTabObj.rec_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.rec_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeMonDtlTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeMonDtlTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeMonDtlTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeMonDtlTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lDmEmployeeMonDtlTabObj.file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeMonDtlTabObj.file_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.file_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeMonDtlTabObj.file_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.file_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeMonDtlTabObj.file_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeMonDtlTabObj.file_status+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lDmEmployeeMonDtlTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lDmEmployeeMonDtlTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lDmEmployeeMonDtlTabObjList ); 
     ArrayList lDmEmployeeMonDtlTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lDmEmployeeMonDtlTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lDmEmployeeMonDtlTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lDmEmployeeMonDtlTabObjArrSorted.add( (DmEmployeeMonDtlTabObj)lDmEmployeeMonDtlTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lDmEmployeeMonDtlTabObjArr.size();  lRecNum++ )
     {
       inDmEmployeeMonDtlTabObjArr.set( lRecNum, (DmEmployeeMonDtlTabObj)lDmEmployeeMonDtlTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvDmEmployeeMonDtlTabObj
               ( 
                 DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inDmEmployeeMonDtlTabObj.allocation_date != null && inDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null && inDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null && inDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.file_cre_date != null && inDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllocationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLOCATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDeptId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DEPT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePositionId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "POSITION_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLevelId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LEVEL_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNameInitials
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NAME_INITIALS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpTrackId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_TRACK_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMonthNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MONTH_NUM";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWorkingDays
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WORKING_DAYS";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAbsentDays
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ABSENT_DAYS";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWagesRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WAGES_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGrossMonWages
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GROSS_MON_WAGES";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtBas
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_BAS";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtDa
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_DA";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtHra
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_HRA";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtConv
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_CONV";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtWoff
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_WOFF";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtShiftAlw
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_SHIFT_ALW";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtWashAlw
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_WASH_ALW";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtOthInc
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_OTH_INC";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtPf
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_PF";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtEsi
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_ESI";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtSwfDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_SWF_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShAmtOthDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SH_AMT_OTH_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOtHour
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OT_HOUR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtOt
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_OT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtOthInc
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_OTH_INC";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtAdv
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_ADV";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtHra
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_HRA";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtWeekoff
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_WEEKOFF";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtWashing
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_WASHING";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtAreer
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_AREER";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtShiftAlw
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_SHIFT_ALW";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtMediAlw
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_MEDI_ALW";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtConvy
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_CONVY";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtInsur
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_INSUR";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtDress
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_DRESS";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtSwfDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_SWF_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtGenFine
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_GEN_FINE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtPc
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_PC";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtSecDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_SEC_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtOthDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_OTH_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActAmtAdvDed
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACT_AMT_ADV_DED";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtDmEmployeeMonDtlCount
               ( String inDmEmployeeMonDtlWhereText
               )
  {
    sop("gtDmEmployeeMonDtlCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlCount
               ( String inDmEmployeeMonDtlWhereText
               , String inDmEmployeeMonDtlSelectFieldList
               )
  {
    sop("gtDmEmployeeMonDtlCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inDmEmployeeMonDtlSelectFieldList+" AS count "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlRecByPkey
               ( DmEmployeeMonDtlPkeyObj inDmEmployeeMonDtlPkeyObj
               , DmEmployeeMonDtlTabObj  outDmEmployeeMonDtlTabObj
               )
  {
    sop("gtDmEmployeeMonDtlRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "name_initials, "+
                                 "employee_name, "+
                                 "emp_track_id, "+
                                 "month_num, "+
                                 "working_days, "+
                                 "absent_days, "+
                                 "wages_rate, "+
                                 "gross_mon_wages, "+
                                 "sh_amt_bas, "+
                                 "sh_amt_da, "+
                                 "sh_amt_hra, "+
                                 "sh_amt_conv, "+
                                 "sh_amt_woff, "+
                                 "sh_amt_shift_alw, "+
                                 "sh_amt_wash_alw, "+
                                 "sh_amt_oth_inc, "+
                                 "sh_amt_pf, "+
                                 "sh_amt_esi, "+
                                 "sh_amt_swf_ded, "+
                                 "sh_amt_oth_ded, "+
                                 "ot_hour, "+
                                 "act_amt_ot, "+
                                 "act_amt_oth_inc, "+
                                 "act_amt_adv, "+
                                 "act_amt_hra, "+
                                 "act_amt_weekoff, "+
                                 "act_amt_washing, "+
                                 "act_amt_areer, "+
                                 "act_amt_shift_alw, "+
                                 "act_amt_medi_alw, "+
                                 "act_amt_convy, "+
                                 "act_amt_insur, "+
                                 "act_amt_dress, "+
                                 "act_amt_swf_ded, "+
                                 "act_amt_gen_fine, "+
                                 "act_amt_pc, "+
                                 "act_amt_sec_ded, "+
                                 "act_amt_oth_ded, "+
                                 "act_amt_adv_ded, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE_MON_DTL " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeeMonDtlPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeeMonDtlPkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeeMonDtlPkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeeMonDtlPkeyObj.allocation_date+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outDmEmployeeMonDtlTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmEmployeeMonDtlTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmEmployeeMonDtlTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmEmployeeMonDtlTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          outDmEmployeeMonDtlTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( outDmEmployeeMonDtlTabObj.allocation_date != null && outDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmEmployeeMonDtlTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmEmployeeMonDtlTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmEmployeeMonDtlTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outDmEmployeeMonDtlTabObj.employee_name  =  lResultSet.getString("EMPLOYEE_NAME");
          outDmEmployeeMonDtlTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          outDmEmployeeMonDtlTabObj.month_num  =  lResultSet.getByte("MONTH_NUM");
          outDmEmployeeMonDtlTabObj.working_days  =  lResultSet.getFloat("WORKING_DAYS");
          outDmEmployeeMonDtlTabObj.absent_days  =  lResultSet.getFloat("ABSENT_DAYS");
          outDmEmployeeMonDtlTabObj.wages_rate  =  lResultSet.getDouble("WAGES_RATE");
          outDmEmployeeMonDtlTabObj.gross_mon_wages  =  lResultSet.getDouble("GROSS_MON_WAGES");
          outDmEmployeeMonDtlTabObj.sh_amt_bas  =  lResultSet.getDouble("SH_AMT_BAS");
          outDmEmployeeMonDtlTabObj.sh_amt_da  =  lResultSet.getDouble("SH_AMT_DA");
          outDmEmployeeMonDtlTabObj.sh_amt_hra  =  lResultSet.getDouble("SH_AMT_HRA");
          outDmEmployeeMonDtlTabObj.sh_amt_conv  =  lResultSet.getDouble("SH_AMT_CONV");
          outDmEmployeeMonDtlTabObj.sh_amt_woff  =  lResultSet.getDouble("SH_AMT_WOFF");
          outDmEmployeeMonDtlTabObj.sh_amt_shift_alw  =  lResultSet.getDouble("SH_AMT_SHIFT_ALW");
          outDmEmployeeMonDtlTabObj.sh_amt_wash_alw  =  lResultSet.getDouble("SH_AMT_WASH_ALW");
          outDmEmployeeMonDtlTabObj.sh_amt_oth_inc  =  lResultSet.getDouble("SH_AMT_OTH_INC");
          outDmEmployeeMonDtlTabObj.sh_amt_pf  =  lResultSet.getDouble("SH_AMT_PF");
          outDmEmployeeMonDtlTabObj.sh_amt_esi  =  lResultSet.getDouble("SH_AMT_ESI");
          outDmEmployeeMonDtlTabObj.sh_amt_swf_ded  =  lResultSet.getDouble("SH_AMT_SWF_DED");
          outDmEmployeeMonDtlTabObj.sh_amt_oth_ded  =  lResultSet.getDouble("SH_AMT_OTH_DED");
          outDmEmployeeMonDtlTabObj.ot_hour  =  lResultSet.getDouble("OT_HOUR");
          outDmEmployeeMonDtlTabObj.act_amt_ot  =  lResultSet.getDouble("ACT_AMT_OT");
          outDmEmployeeMonDtlTabObj.act_amt_oth_inc  =  lResultSet.getDouble("ACT_AMT_OTH_INC");
          outDmEmployeeMonDtlTabObj.act_amt_adv  =  lResultSet.getDouble("ACT_AMT_ADV");
          outDmEmployeeMonDtlTabObj.act_amt_hra  =  lResultSet.getDouble("ACT_AMT_HRA");
          outDmEmployeeMonDtlTabObj.act_amt_weekoff  =  lResultSet.getDouble("ACT_AMT_WEEKOFF");
          outDmEmployeeMonDtlTabObj.act_amt_washing  =  lResultSet.getDouble("ACT_AMT_WASHING");
          outDmEmployeeMonDtlTabObj.act_amt_areer  =  lResultSet.getDouble("ACT_AMT_AREER");
          outDmEmployeeMonDtlTabObj.act_amt_shift_alw  =  lResultSet.getDouble("ACT_AMT_SHIFT_ALW");
          outDmEmployeeMonDtlTabObj.act_amt_medi_alw  =  lResultSet.getDouble("ACT_AMT_MEDI_ALW");
          outDmEmployeeMonDtlTabObj.act_amt_convy  =  lResultSet.getDouble("ACT_AMT_CONVY");
          outDmEmployeeMonDtlTabObj.act_amt_insur  =  lResultSet.getDouble("ACT_AMT_INSUR");
          outDmEmployeeMonDtlTabObj.act_amt_dress  =  lResultSet.getDouble("ACT_AMT_DRESS");
          outDmEmployeeMonDtlTabObj.act_amt_swf_ded  =  lResultSet.getDouble("ACT_AMT_SWF_DED");
          outDmEmployeeMonDtlTabObj.act_amt_gen_fine  =  lResultSet.getDouble("ACT_AMT_GEN_FINE");
          outDmEmployeeMonDtlTabObj.act_amt_pc  =  lResultSet.getDouble("ACT_AMT_PC");
          outDmEmployeeMonDtlTabObj.act_amt_sec_ded  =  lResultSet.getDouble("ACT_AMT_SEC_DED");
          outDmEmployeeMonDtlTabObj.act_amt_oth_ded  =  lResultSet.getDouble("ACT_AMT_OTH_DED");
          outDmEmployeeMonDtlTabObj.act_amt_adv_ded  =  lResultSet.getDouble("ACT_AMT_ADV_DED");
          outDmEmployeeMonDtlTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmEmployeeMonDtlTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmEmployeeMonDtlTabObj.rec_cre_date != null && outDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmEmployeeMonDtlTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmEmployeeMonDtlTabObj.rec_upd_date != null && outDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmEmployeeMonDtlTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmEmployeeMonDtlTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmEmployeeMonDtlTabObj.file_cre_date != null && outDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmEmployeeMonDtlTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmEmployeeMonDtlTabObj( outDmEmployeeMonDtlTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlArr
               ( DmEmployeeMonDtlPkeyObj inDmEmployeeMonDtlPkeyObj
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {
    sop("gtDmEmployeeMonDtlArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "name_initials, "+
                                 "employee_name, "+
                                 "emp_track_id, "+
                                 "month_num, "+
                                 "working_days, "+
                                 "absent_days, "+
                                 "wages_rate, "+
                                 "gross_mon_wages, "+
                                 "sh_amt_bas, "+
                                 "sh_amt_da, "+
                                 "sh_amt_hra, "+
                                 "sh_amt_conv, "+
                                 "sh_amt_woff, "+
                                 "sh_amt_shift_alw, "+
                                 "sh_amt_wash_alw, "+
                                 "sh_amt_oth_inc, "+
                                 "sh_amt_pf, "+
                                 "sh_amt_esi, "+
                                 "sh_amt_swf_ded, "+
                                 "sh_amt_oth_ded, "+
                                 "ot_hour, "+
                                 "act_amt_ot, "+
                                 "act_amt_oth_inc, "+
                                 "act_amt_adv, "+
                                 "act_amt_hra, "+
                                 "act_amt_weekoff, "+
                                 "act_amt_washing, "+
                                 "act_amt_areer, "+
                                 "act_amt_shift_alw, "+
                                 "act_amt_medi_alw, "+
                                 "act_amt_convy, "+
                                 "act_amt_insur, "+
                                 "act_amt_dress, "+
                                 "act_amt_swf_ded, "+
                                 "act_amt_gen_fine, "+
                                 "act_amt_pc, "+
                                 "act_amt_sec_ded, "+
                                 "act_amt_oth_ded, "+
                                 "act_amt_adv_ded, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE_MON_DTL";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmEmployeeMonDtlTabObj  lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj();
          lDmEmployeeMonDtlTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lDmEmployeeMonDtlTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmEmployeeMonDtlTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmEmployeeMonDtlTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          lDmEmployeeMonDtlTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( lDmEmployeeMonDtlTabObj.allocation_date != null && lDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmEmployeeMonDtlTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmEmployeeMonDtlTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmEmployeeMonDtlTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lDmEmployeeMonDtlTabObj.employee_name  =  lResultSet.getString("EMPLOYEE_NAME");
          lDmEmployeeMonDtlTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          lDmEmployeeMonDtlTabObj.month_num  =  lResultSet.getByte("MONTH_NUM");
          lDmEmployeeMonDtlTabObj.working_days  =  lResultSet.getFloat("WORKING_DAYS");
          lDmEmployeeMonDtlTabObj.absent_days  =  lResultSet.getFloat("ABSENT_DAYS");
          lDmEmployeeMonDtlTabObj.wages_rate  =  lResultSet.getDouble("WAGES_RATE");
          lDmEmployeeMonDtlTabObj.gross_mon_wages  =  lResultSet.getDouble("GROSS_MON_WAGES");
          lDmEmployeeMonDtlTabObj.sh_amt_bas  =  lResultSet.getDouble("SH_AMT_BAS");
          lDmEmployeeMonDtlTabObj.sh_amt_da  =  lResultSet.getDouble("SH_AMT_DA");
          lDmEmployeeMonDtlTabObj.sh_amt_hra  =  lResultSet.getDouble("SH_AMT_HRA");
          lDmEmployeeMonDtlTabObj.sh_amt_conv  =  lResultSet.getDouble("SH_AMT_CONV");
          lDmEmployeeMonDtlTabObj.sh_amt_woff  =  lResultSet.getDouble("SH_AMT_WOFF");
          lDmEmployeeMonDtlTabObj.sh_amt_shift_alw  =  lResultSet.getDouble("SH_AMT_SHIFT_ALW");
          lDmEmployeeMonDtlTabObj.sh_amt_wash_alw  =  lResultSet.getDouble("SH_AMT_WASH_ALW");
          lDmEmployeeMonDtlTabObj.sh_amt_oth_inc  =  lResultSet.getDouble("SH_AMT_OTH_INC");
          lDmEmployeeMonDtlTabObj.sh_amt_pf  =  lResultSet.getDouble("SH_AMT_PF");
          lDmEmployeeMonDtlTabObj.sh_amt_esi  =  lResultSet.getDouble("SH_AMT_ESI");
          lDmEmployeeMonDtlTabObj.sh_amt_swf_ded  =  lResultSet.getDouble("SH_AMT_SWF_DED");
          lDmEmployeeMonDtlTabObj.sh_amt_oth_ded  =  lResultSet.getDouble("SH_AMT_OTH_DED");
          lDmEmployeeMonDtlTabObj.ot_hour  =  lResultSet.getDouble("OT_HOUR");
          lDmEmployeeMonDtlTabObj.act_amt_ot  =  lResultSet.getDouble("ACT_AMT_OT");
          lDmEmployeeMonDtlTabObj.act_amt_oth_inc  =  lResultSet.getDouble("ACT_AMT_OTH_INC");
          lDmEmployeeMonDtlTabObj.act_amt_adv  =  lResultSet.getDouble("ACT_AMT_ADV");
          lDmEmployeeMonDtlTabObj.act_amt_hra  =  lResultSet.getDouble("ACT_AMT_HRA");
          lDmEmployeeMonDtlTabObj.act_amt_weekoff  =  lResultSet.getDouble("ACT_AMT_WEEKOFF");
          lDmEmployeeMonDtlTabObj.act_amt_washing  =  lResultSet.getDouble("ACT_AMT_WASHING");
          lDmEmployeeMonDtlTabObj.act_amt_areer  =  lResultSet.getDouble("ACT_AMT_AREER");
          lDmEmployeeMonDtlTabObj.act_amt_shift_alw  =  lResultSet.getDouble("ACT_AMT_SHIFT_ALW");
          lDmEmployeeMonDtlTabObj.act_amt_medi_alw  =  lResultSet.getDouble("ACT_AMT_MEDI_ALW");
          lDmEmployeeMonDtlTabObj.act_amt_convy  =  lResultSet.getDouble("ACT_AMT_CONVY");
          lDmEmployeeMonDtlTabObj.act_amt_insur  =  lResultSet.getDouble("ACT_AMT_INSUR");
          lDmEmployeeMonDtlTabObj.act_amt_dress  =  lResultSet.getDouble("ACT_AMT_DRESS");
          lDmEmployeeMonDtlTabObj.act_amt_swf_ded  =  lResultSet.getDouble("ACT_AMT_SWF_DED");
          lDmEmployeeMonDtlTabObj.act_amt_gen_fine  =  lResultSet.getDouble("ACT_AMT_GEN_FINE");
          lDmEmployeeMonDtlTabObj.act_amt_pc  =  lResultSet.getDouble("ACT_AMT_PC");
          lDmEmployeeMonDtlTabObj.act_amt_sec_ded  =  lResultSet.getDouble("ACT_AMT_SEC_DED");
          lDmEmployeeMonDtlTabObj.act_amt_oth_ded  =  lResultSet.getDouble("ACT_AMT_OTH_DED");
          lDmEmployeeMonDtlTabObj.act_amt_adv_ded  =  lResultSet.getDouble("ACT_AMT_ADV_DED");
          lDmEmployeeMonDtlTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmEmployeeMonDtlTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmEmployeeMonDtlTabObj.rec_cre_date != null && lDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmEmployeeMonDtlTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmEmployeeMonDtlTabObj.rec_upd_date != null && lDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmEmployeeMonDtlTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmEmployeeMonDtlTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmEmployeeMonDtlTabObj.file_cre_date != null && lDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmEmployeeMonDtlTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmEmployeeMonDtlTabObj( lDmEmployeeMonDtlTabObj );

          outDmEmployeeMonDtlTabObjArr.add(  lDmEmployeeMonDtlTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeMonDtlTabObjArr != null && outDmEmployeeMonDtlTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtDmEmployeeMonDtlArr2XML
               ( String inDmEmployeeMonDtlWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtDmEmployeeMonDtlArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<DmEmployeeMonDtl>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_id") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_ID>" +  lResultSet.getString("CUSTOMER_ID") +   "</CUSTOMER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_id") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_ID>" +  lResultSet.getString("EMPLOYEE_ID") +   "</EMPLOYEE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allocation_date") )
              lXmlBuffer = lXmlBuffer +   "<ALLOCATION_DATE>" +  lResultSet.getString("ALLOCATION_DATE") +   "</ALLOCATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dept_id") )
              lXmlBuffer = lXmlBuffer +   "<DEPT_ID>" +  lResultSet.getString("DEPT_ID") +   "</DEPT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("position_id") )
              lXmlBuffer = lXmlBuffer +   "<POSITION_ID>" +  lResultSet.getString("POSITION_ID") +   "</POSITION_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("level_id") )
              lXmlBuffer = lXmlBuffer +   "<LEVEL_ID>" +  lResultSet.getString("LEVEL_ID") +   "</LEVEL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("name_initials") )
              lXmlBuffer = lXmlBuffer +   "<NAME_INITIALS>" +  lResultSet.getString("NAME_INITIALS") +   "</NAME_INITIALS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_name") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_NAME>" +  lResultSet.getString("EMPLOYEE_NAME") +   "</EMPLOYEE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_track_id") )
              lXmlBuffer = lXmlBuffer +   "<EMP_TRACK_ID>" +  lResultSet.getString("EMP_TRACK_ID") +   "</EMP_TRACK_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("month_num") )
              lXmlBuffer = lXmlBuffer +   "<MONTH_NUM>" +  lResultSet.getByte("MONTH_NUM") +   "</MONTH_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("working_days") )
              lXmlBuffer = lXmlBuffer +   "<WORKING_DAYS>" +  lResultSet.getFloat("WORKING_DAYS") +   "</WORKING_DAYS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("absent_days") )
              lXmlBuffer = lXmlBuffer +   "<ABSENT_DAYS>" +  lResultSet.getFloat("ABSENT_DAYS") +   "</ABSENT_DAYS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("wages_rate") )
              lXmlBuffer = lXmlBuffer +   "<WAGES_RATE>" +  lResultSet.getDouble("WAGES_RATE") +   "</WAGES_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gross_mon_wages") )
              lXmlBuffer = lXmlBuffer +   "<GROSS_MON_WAGES>" +  lResultSet.getDouble("GROSS_MON_WAGES") +   "</GROSS_MON_WAGES>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_bas") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_BAS>" +  lResultSet.getDouble("SH_AMT_BAS") +   "</SH_AMT_BAS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_da") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_DA>" +  lResultSet.getDouble("SH_AMT_DA") +   "</SH_AMT_DA>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_hra") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_HRA>" +  lResultSet.getDouble("SH_AMT_HRA") +   "</SH_AMT_HRA>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_conv") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_CONV>" +  lResultSet.getDouble("SH_AMT_CONV") +   "</SH_AMT_CONV>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_woff") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_WOFF>" +  lResultSet.getDouble("SH_AMT_WOFF") +   "</SH_AMT_WOFF>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_shift_alw") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_SHIFT_ALW>" +  lResultSet.getDouble("SH_AMT_SHIFT_ALW") +   "</SH_AMT_SHIFT_ALW>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_wash_alw") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_WASH_ALW>" +  lResultSet.getDouble("SH_AMT_WASH_ALW") +   "</SH_AMT_WASH_ALW>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_oth_inc") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_OTH_INC>" +  lResultSet.getDouble("SH_AMT_OTH_INC") +   "</SH_AMT_OTH_INC>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_pf") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_PF>" +  lResultSet.getDouble("SH_AMT_PF") +   "</SH_AMT_PF>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_esi") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_ESI>" +  lResultSet.getDouble("SH_AMT_ESI") +   "</SH_AMT_ESI>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_swf_ded") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_SWF_DED>" +  lResultSet.getDouble("SH_AMT_SWF_DED") +   "</SH_AMT_SWF_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sh_amt_oth_ded") )
              lXmlBuffer = lXmlBuffer +   "<SH_AMT_OTH_DED>" +  lResultSet.getDouble("SH_AMT_OTH_DED") +   "</SH_AMT_OTH_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ot_hour") )
              lXmlBuffer = lXmlBuffer +   "<OT_HOUR>" +  lResultSet.getDouble("OT_HOUR") +   "</OT_HOUR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_ot") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_OT>" +  lResultSet.getDouble("ACT_AMT_OT") +   "</ACT_AMT_OT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_oth_inc") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_OTH_INC>" +  lResultSet.getDouble("ACT_AMT_OTH_INC") +   "</ACT_AMT_OTH_INC>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_adv") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_ADV>" +  lResultSet.getDouble("ACT_AMT_ADV") +   "</ACT_AMT_ADV>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_hra") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_HRA>" +  lResultSet.getDouble("ACT_AMT_HRA") +   "</ACT_AMT_HRA>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_weekoff") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_WEEKOFF>" +  lResultSet.getDouble("ACT_AMT_WEEKOFF") +   "</ACT_AMT_WEEKOFF>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_washing") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_WASHING>" +  lResultSet.getDouble("ACT_AMT_WASHING") +   "</ACT_AMT_WASHING>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_areer") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_AREER>" +  lResultSet.getDouble("ACT_AMT_AREER") +   "</ACT_AMT_AREER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_shift_alw") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_SHIFT_ALW>" +  lResultSet.getDouble("ACT_AMT_SHIFT_ALW") +   "</ACT_AMT_SHIFT_ALW>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_medi_alw") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_MEDI_ALW>" +  lResultSet.getDouble("ACT_AMT_MEDI_ALW") +   "</ACT_AMT_MEDI_ALW>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_convy") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_CONVY>" +  lResultSet.getDouble("ACT_AMT_CONVY") +   "</ACT_AMT_CONVY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_insur") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_INSUR>" +  lResultSet.getDouble("ACT_AMT_INSUR") +   "</ACT_AMT_INSUR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_dress") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_DRESS>" +  lResultSet.getDouble("ACT_AMT_DRESS") +   "</ACT_AMT_DRESS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_swf_ded") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_SWF_DED>" +  lResultSet.getDouble("ACT_AMT_SWF_DED") +   "</ACT_AMT_SWF_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_gen_fine") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_GEN_FINE>" +  lResultSet.getDouble("ACT_AMT_GEN_FINE") +   "</ACT_AMT_GEN_FINE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_pc") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_PC>" +  lResultSet.getDouble("ACT_AMT_PC") +   "</ACT_AMT_PC>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_sec_ded") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_SEC_DED>" +  lResultSet.getDouble("ACT_AMT_SEC_DED") +   "</ACT_AMT_SEC_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_oth_ded") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_OTH_DED>" +  lResultSet.getDouble("ACT_AMT_OTH_DED") +   "</ACT_AMT_OTH_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("act_amt_adv_ded") )
              lXmlBuffer = lXmlBuffer +   "<ACT_AMT_ADV_DED>" +  lResultSet.getDouble("ACT_AMT_ADV_DED") +   "</ACT_AMT_ADV_DED>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_status") )
              lXmlBuffer = lXmlBuffer +   "<REC_STATUS>" +  lResultSet.getString("REC_STATUS") +   "</REC_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_name") )
              lXmlBuffer = lXmlBuffer +   "<FILE_NAME>" +  lResultSet.getString("FILE_NAME") +   "</FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_DATE>" +  lResultSet.getString("FILE_CRE_DATE") +   "</FILE_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_TIME>" +  lResultSet.getString("FILE_CRE_TIME") +   "</FILE_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_status") )
              lXmlBuffer = lXmlBuffer +   "<FILE_STATUS>" +  lResultSet.getString("FILE_STATUS") +   "</FILE_STATUS>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</DmEmployeeMonDtl>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtDmEmployeeMonDtlRecByRowid
               ( String inRowId
               , DmEmployeeMonDtlTabObj  outDmEmployeeMonDtlTabObj
               )
  {
    sop("gtDmEmployeeMonDtlRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "name_initials, "+
                                 "employee_name, "+
                                 "emp_track_id, "+
                                 "month_num, "+
                                 "working_days, "+
                                 "absent_days, "+
                                 "wages_rate, "+
                                 "gross_mon_wages, "+
                                 "sh_amt_bas, "+
                                 "sh_amt_da, "+
                                 "sh_amt_hra, "+
                                 "sh_amt_conv, "+
                                 "sh_amt_woff, "+
                                 "sh_amt_shift_alw, "+
                                 "sh_amt_wash_alw, "+
                                 "sh_amt_oth_inc, "+
                                 "sh_amt_pf, "+
                                 "sh_amt_esi, "+
                                 "sh_amt_swf_ded, "+
                                 "sh_amt_oth_ded, "+
                                 "ot_hour, "+
                                 "act_amt_ot, "+
                                 "act_amt_oth_inc, "+
                                 "act_amt_adv, "+
                                 "act_amt_hra, "+
                                 "act_amt_weekoff, "+
                                 "act_amt_washing, "+
                                 "act_amt_areer, "+
                                 "act_amt_shift_alw, "+
                                 "act_amt_medi_alw, "+
                                 "act_amt_convy, "+
                                 "act_amt_insur, "+
                                 "act_amt_dress, "+
                                 "act_amt_swf_ded, "+
                                 "act_amt_gen_fine, "+
                                 "act_amt_pc, "+
                                 "act_amt_sec_ded, "+
                                 "act_amt_oth_ded, "+
                                 "act_amt_adv_ded, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outDmEmployeeMonDtlTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmEmployeeMonDtlTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmEmployeeMonDtlTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmEmployeeMonDtlTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          outDmEmployeeMonDtlTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( outDmEmployeeMonDtlTabObj.allocation_date != null && outDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmEmployeeMonDtlTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmEmployeeMonDtlTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmEmployeeMonDtlTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outDmEmployeeMonDtlTabObj.employee_name  =  lResultSet.getString("EMPLOYEE_NAME");
          outDmEmployeeMonDtlTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          outDmEmployeeMonDtlTabObj.month_num  =  lResultSet.getByte("MONTH_NUM");
          outDmEmployeeMonDtlTabObj.working_days  =  lResultSet.getFloat("WORKING_DAYS");
          outDmEmployeeMonDtlTabObj.absent_days  =  lResultSet.getFloat("ABSENT_DAYS");
          outDmEmployeeMonDtlTabObj.wages_rate  =  lResultSet.getDouble("WAGES_RATE");
          outDmEmployeeMonDtlTabObj.gross_mon_wages  =  lResultSet.getDouble("GROSS_MON_WAGES");
          outDmEmployeeMonDtlTabObj.sh_amt_bas  =  lResultSet.getDouble("SH_AMT_BAS");
          outDmEmployeeMonDtlTabObj.sh_amt_da  =  lResultSet.getDouble("SH_AMT_DA");
          outDmEmployeeMonDtlTabObj.sh_amt_hra  =  lResultSet.getDouble("SH_AMT_HRA");
          outDmEmployeeMonDtlTabObj.sh_amt_conv  =  lResultSet.getDouble("SH_AMT_CONV");
          outDmEmployeeMonDtlTabObj.sh_amt_woff  =  lResultSet.getDouble("SH_AMT_WOFF");
          outDmEmployeeMonDtlTabObj.sh_amt_shift_alw  =  lResultSet.getDouble("SH_AMT_SHIFT_ALW");
          outDmEmployeeMonDtlTabObj.sh_amt_wash_alw  =  lResultSet.getDouble("SH_AMT_WASH_ALW");
          outDmEmployeeMonDtlTabObj.sh_amt_oth_inc  =  lResultSet.getDouble("SH_AMT_OTH_INC");
          outDmEmployeeMonDtlTabObj.sh_amt_pf  =  lResultSet.getDouble("SH_AMT_PF");
          outDmEmployeeMonDtlTabObj.sh_amt_esi  =  lResultSet.getDouble("SH_AMT_ESI");
          outDmEmployeeMonDtlTabObj.sh_amt_swf_ded  =  lResultSet.getDouble("SH_AMT_SWF_DED");
          outDmEmployeeMonDtlTabObj.sh_amt_oth_ded  =  lResultSet.getDouble("SH_AMT_OTH_DED");
          outDmEmployeeMonDtlTabObj.ot_hour  =  lResultSet.getDouble("OT_HOUR");
          outDmEmployeeMonDtlTabObj.act_amt_ot  =  lResultSet.getDouble("ACT_AMT_OT");
          outDmEmployeeMonDtlTabObj.act_amt_oth_inc  =  lResultSet.getDouble("ACT_AMT_OTH_INC");
          outDmEmployeeMonDtlTabObj.act_amt_adv  =  lResultSet.getDouble("ACT_AMT_ADV");
          outDmEmployeeMonDtlTabObj.act_amt_hra  =  lResultSet.getDouble("ACT_AMT_HRA");
          outDmEmployeeMonDtlTabObj.act_amt_weekoff  =  lResultSet.getDouble("ACT_AMT_WEEKOFF");
          outDmEmployeeMonDtlTabObj.act_amt_washing  =  lResultSet.getDouble("ACT_AMT_WASHING");
          outDmEmployeeMonDtlTabObj.act_amt_areer  =  lResultSet.getDouble("ACT_AMT_AREER");
          outDmEmployeeMonDtlTabObj.act_amt_shift_alw  =  lResultSet.getDouble("ACT_AMT_SHIFT_ALW");
          outDmEmployeeMonDtlTabObj.act_amt_medi_alw  =  lResultSet.getDouble("ACT_AMT_MEDI_ALW");
          outDmEmployeeMonDtlTabObj.act_amt_convy  =  lResultSet.getDouble("ACT_AMT_CONVY");
          outDmEmployeeMonDtlTabObj.act_amt_insur  =  lResultSet.getDouble("ACT_AMT_INSUR");
          outDmEmployeeMonDtlTabObj.act_amt_dress  =  lResultSet.getDouble("ACT_AMT_DRESS");
          outDmEmployeeMonDtlTabObj.act_amt_swf_ded  =  lResultSet.getDouble("ACT_AMT_SWF_DED");
          outDmEmployeeMonDtlTabObj.act_amt_gen_fine  =  lResultSet.getDouble("ACT_AMT_GEN_FINE");
          outDmEmployeeMonDtlTabObj.act_amt_pc  =  lResultSet.getDouble("ACT_AMT_PC");
          outDmEmployeeMonDtlTabObj.act_amt_sec_ded  =  lResultSet.getDouble("ACT_AMT_SEC_DED");
          outDmEmployeeMonDtlTabObj.act_amt_oth_ded  =  lResultSet.getDouble("ACT_AMT_OTH_DED");
          outDmEmployeeMonDtlTabObj.act_amt_adv_ded  =  lResultSet.getDouble("ACT_AMT_ADV_DED");
          outDmEmployeeMonDtlTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmEmployeeMonDtlTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmEmployeeMonDtlTabObj.rec_cre_date != null && outDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmEmployeeMonDtlTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmEmployeeMonDtlTabObj.rec_upd_date != null && outDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmEmployeeMonDtlTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmEmployeeMonDtlTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmEmployeeMonDtlTabObj.file_cre_date != null && outDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            outDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmEmployeeMonDtlTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmEmployeeMonDtlTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmEmployeeMonDtlTabObj( outDmEmployeeMonDtlTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlArr
               ( String inDmEmployeeMonDtlWhereText
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {
    sop("gtDmEmployeeMonDtlArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "name_initials, "+
                                 "employee_name, "+
                                 "emp_track_id, "+
                                 "month_num, "+
                                 "working_days, "+
                                 "absent_days, "+
                                 "wages_rate, "+
                                 "gross_mon_wages, "+
                                 "sh_amt_bas, "+
                                 "sh_amt_da, "+
                                 "sh_amt_hra, "+
                                 "sh_amt_conv, "+
                                 "sh_amt_woff, "+
                                 "sh_amt_shift_alw, "+
                                 "sh_amt_wash_alw, "+
                                 "sh_amt_oth_inc, "+
                                 "sh_amt_pf, "+
                                 "sh_amt_esi, "+
                                 "sh_amt_swf_ded, "+
                                 "sh_amt_oth_ded, "+
                                 "ot_hour, "+
                                 "act_amt_ot, "+
                                 "act_amt_oth_inc, "+
                                 "act_amt_adv, "+
                                 "act_amt_hra, "+
                                 "act_amt_weekoff, "+
                                 "act_amt_washing, "+
                                 "act_amt_areer, "+
                                 "act_amt_shift_alw, "+
                                 "act_amt_medi_alw, "+
                                 "act_amt_convy, "+
                                 "act_amt_insur, "+
                                 "act_amt_dress, "+
                                 "act_amt_swf_ded, "+
                                 "act_amt_gen_fine, "+
                                 "act_amt_pc, "+
                                 "act_amt_sec_ded, "+
                                 "act_amt_oth_ded, "+
                                 "act_amt_adv_ded, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmEmployeeMonDtlTabObj  lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj();
          lDmEmployeeMonDtlTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lDmEmployeeMonDtlTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmEmployeeMonDtlTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmEmployeeMonDtlTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          lDmEmployeeMonDtlTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( lDmEmployeeMonDtlTabObj.allocation_date != null && lDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmEmployeeMonDtlTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmEmployeeMonDtlTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmEmployeeMonDtlTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lDmEmployeeMonDtlTabObj.employee_name  =  lResultSet.getString("EMPLOYEE_NAME");
          lDmEmployeeMonDtlTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          lDmEmployeeMonDtlTabObj.month_num  =  lResultSet.getByte("MONTH_NUM");
          lDmEmployeeMonDtlTabObj.working_days  =  lResultSet.getFloat("WORKING_DAYS");
          lDmEmployeeMonDtlTabObj.absent_days  =  lResultSet.getFloat("ABSENT_DAYS");
          lDmEmployeeMonDtlTabObj.wages_rate  =  lResultSet.getDouble("WAGES_RATE");
          lDmEmployeeMonDtlTabObj.gross_mon_wages  =  lResultSet.getDouble("GROSS_MON_WAGES");
          lDmEmployeeMonDtlTabObj.sh_amt_bas  =  lResultSet.getDouble("SH_AMT_BAS");
          lDmEmployeeMonDtlTabObj.sh_amt_da  =  lResultSet.getDouble("SH_AMT_DA");
          lDmEmployeeMonDtlTabObj.sh_amt_hra  =  lResultSet.getDouble("SH_AMT_HRA");
          lDmEmployeeMonDtlTabObj.sh_amt_conv  =  lResultSet.getDouble("SH_AMT_CONV");
          lDmEmployeeMonDtlTabObj.sh_amt_woff  =  lResultSet.getDouble("SH_AMT_WOFF");
          lDmEmployeeMonDtlTabObj.sh_amt_shift_alw  =  lResultSet.getDouble("SH_AMT_SHIFT_ALW");
          lDmEmployeeMonDtlTabObj.sh_amt_wash_alw  =  lResultSet.getDouble("SH_AMT_WASH_ALW");
          lDmEmployeeMonDtlTabObj.sh_amt_oth_inc  =  lResultSet.getDouble("SH_AMT_OTH_INC");
          lDmEmployeeMonDtlTabObj.sh_amt_pf  =  lResultSet.getDouble("SH_AMT_PF");
          lDmEmployeeMonDtlTabObj.sh_amt_esi  =  lResultSet.getDouble("SH_AMT_ESI");
          lDmEmployeeMonDtlTabObj.sh_amt_swf_ded  =  lResultSet.getDouble("SH_AMT_SWF_DED");
          lDmEmployeeMonDtlTabObj.sh_amt_oth_ded  =  lResultSet.getDouble("SH_AMT_OTH_DED");
          lDmEmployeeMonDtlTabObj.ot_hour  =  lResultSet.getDouble("OT_HOUR");
          lDmEmployeeMonDtlTabObj.act_amt_ot  =  lResultSet.getDouble("ACT_AMT_OT");
          lDmEmployeeMonDtlTabObj.act_amt_oth_inc  =  lResultSet.getDouble("ACT_AMT_OTH_INC");
          lDmEmployeeMonDtlTabObj.act_amt_adv  =  lResultSet.getDouble("ACT_AMT_ADV");
          lDmEmployeeMonDtlTabObj.act_amt_hra  =  lResultSet.getDouble("ACT_AMT_HRA");
          lDmEmployeeMonDtlTabObj.act_amt_weekoff  =  lResultSet.getDouble("ACT_AMT_WEEKOFF");
          lDmEmployeeMonDtlTabObj.act_amt_washing  =  lResultSet.getDouble("ACT_AMT_WASHING");
          lDmEmployeeMonDtlTabObj.act_amt_areer  =  lResultSet.getDouble("ACT_AMT_AREER");
          lDmEmployeeMonDtlTabObj.act_amt_shift_alw  =  lResultSet.getDouble("ACT_AMT_SHIFT_ALW");
          lDmEmployeeMonDtlTabObj.act_amt_medi_alw  =  lResultSet.getDouble("ACT_AMT_MEDI_ALW");
          lDmEmployeeMonDtlTabObj.act_amt_convy  =  lResultSet.getDouble("ACT_AMT_CONVY");
          lDmEmployeeMonDtlTabObj.act_amt_insur  =  lResultSet.getDouble("ACT_AMT_INSUR");
          lDmEmployeeMonDtlTabObj.act_amt_dress  =  lResultSet.getDouble("ACT_AMT_DRESS");
          lDmEmployeeMonDtlTabObj.act_amt_swf_ded  =  lResultSet.getDouble("ACT_AMT_SWF_DED");
          lDmEmployeeMonDtlTabObj.act_amt_gen_fine  =  lResultSet.getDouble("ACT_AMT_GEN_FINE");
          lDmEmployeeMonDtlTabObj.act_amt_pc  =  lResultSet.getDouble("ACT_AMT_PC");
          lDmEmployeeMonDtlTabObj.act_amt_sec_ded  =  lResultSet.getDouble("ACT_AMT_SEC_DED");
          lDmEmployeeMonDtlTabObj.act_amt_oth_ded  =  lResultSet.getDouble("ACT_AMT_OTH_DED");
          lDmEmployeeMonDtlTabObj.act_amt_adv_ded  =  lResultSet.getDouble("ACT_AMT_ADV_DED");
          lDmEmployeeMonDtlTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmEmployeeMonDtlTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmEmployeeMonDtlTabObj.rec_cre_date != null && lDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmEmployeeMonDtlTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmEmployeeMonDtlTabObj.rec_upd_date != null && lDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmEmployeeMonDtlTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmEmployeeMonDtlTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmEmployeeMonDtlTabObj.file_cre_date != null && lDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmEmployeeMonDtlTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmEmployeeMonDtlTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmEmployeeMonDtlTabObj( lDmEmployeeMonDtlTabObj );

          outDmEmployeeMonDtlTabObjArr.add(  lDmEmployeeMonDtlTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeMonDtlTabObjArr != null && outDmEmployeeMonDtlTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlArrDist
               ( String inDmEmployeeMonDtlWhereText
               , String inDistDmEmployeeMonDtlField
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {

    sop("gtDmEmployeeMonDtlArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";
  

       String lDistDmEmployeeMonDtlFieldQry = inDistDmEmployeeMonDtlField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmEmployeeMonDtlFieldQry+
                         " FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmEmployeeMonDtlField.substring(inDistDmEmployeeMonDtlField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          DmEmployeeMonDtlTabObj  lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lDmEmployeeMonDtlTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_id") )
              lDmEmployeeMonDtlTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_id") )
              lDmEmployeeMonDtlTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allocation_date") )
              {
              lDmEmployeeMonDtlTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");
  
          if ( lDmEmployeeMonDtlTabObj.allocation_date != null && lDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.allocation_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dept_id") )
              lDmEmployeeMonDtlTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("position_id") )
              lDmEmployeeMonDtlTabObj.position_id  =  lResultSet.getString("POSITION_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("level_id") )
              lDmEmployeeMonDtlTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("name_initials") )
              lDmEmployeeMonDtlTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_name") )
              lDmEmployeeMonDtlTabObj.employee_name  =  lResultSet.getString("EMPLOYEE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_track_id") )
              lDmEmployeeMonDtlTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("month_num") )
              lDmEmployeeMonDtlTabObj.month_num  =  lResultSet.getByte("MONTH_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("working_days") )
              lDmEmployeeMonDtlTabObj.working_days  =  lResultSet.getFloat("WORKING_DAYS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("absent_days") )
              lDmEmployeeMonDtlTabObj.absent_days  =  lResultSet.getFloat("ABSENT_DAYS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("wages_rate") )
              lDmEmployeeMonDtlTabObj.wages_rate  =  lResultSet.getDouble("WAGES_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gross_mon_wages") )
              lDmEmployeeMonDtlTabObj.gross_mon_wages  =  lResultSet.getDouble("GROSS_MON_WAGES");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_bas") )
              lDmEmployeeMonDtlTabObj.sh_amt_bas  =  lResultSet.getDouble("SH_AMT_BAS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_da") )
              lDmEmployeeMonDtlTabObj.sh_amt_da  =  lResultSet.getDouble("SH_AMT_DA");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_hra") )
              lDmEmployeeMonDtlTabObj.sh_amt_hra  =  lResultSet.getDouble("SH_AMT_HRA");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_conv") )
              lDmEmployeeMonDtlTabObj.sh_amt_conv  =  lResultSet.getDouble("SH_AMT_CONV");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_woff") )
              lDmEmployeeMonDtlTabObj.sh_amt_woff  =  lResultSet.getDouble("SH_AMT_WOFF");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_shift_alw") )
              lDmEmployeeMonDtlTabObj.sh_amt_shift_alw  =  lResultSet.getDouble("SH_AMT_SHIFT_ALW");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_wash_alw") )
              lDmEmployeeMonDtlTabObj.sh_amt_wash_alw  =  lResultSet.getDouble("SH_AMT_WASH_ALW");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_oth_inc") )
              lDmEmployeeMonDtlTabObj.sh_amt_oth_inc  =  lResultSet.getDouble("SH_AMT_OTH_INC");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_pf") )
              lDmEmployeeMonDtlTabObj.sh_amt_pf  =  lResultSet.getDouble("SH_AMT_PF");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_esi") )
              lDmEmployeeMonDtlTabObj.sh_amt_esi  =  lResultSet.getDouble("SH_AMT_ESI");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_swf_ded") )
              lDmEmployeeMonDtlTabObj.sh_amt_swf_ded  =  lResultSet.getDouble("SH_AMT_SWF_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sh_amt_oth_ded") )
              lDmEmployeeMonDtlTabObj.sh_amt_oth_ded  =  lResultSet.getDouble("SH_AMT_OTH_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ot_hour") )
              lDmEmployeeMonDtlTabObj.ot_hour  =  lResultSet.getDouble("OT_HOUR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_ot") )
              lDmEmployeeMonDtlTabObj.act_amt_ot  =  lResultSet.getDouble("ACT_AMT_OT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_oth_inc") )
              lDmEmployeeMonDtlTabObj.act_amt_oth_inc  =  lResultSet.getDouble("ACT_AMT_OTH_INC");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_adv") )
              lDmEmployeeMonDtlTabObj.act_amt_adv  =  lResultSet.getDouble("ACT_AMT_ADV");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_hra") )
              lDmEmployeeMonDtlTabObj.act_amt_hra  =  lResultSet.getDouble("ACT_AMT_HRA");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_weekoff") )
              lDmEmployeeMonDtlTabObj.act_amt_weekoff  =  lResultSet.getDouble("ACT_AMT_WEEKOFF");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_washing") )
              lDmEmployeeMonDtlTabObj.act_amt_washing  =  lResultSet.getDouble("ACT_AMT_WASHING");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_areer") )
              lDmEmployeeMonDtlTabObj.act_amt_areer  =  lResultSet.getDouble("ACT_AMT_AREER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_shift_alw") )
              lDmEmployeeMonDtlTabObj.act_amt_shift_alw  =  lResultSet.getDouble("ACT_AMT_SHIFT_ALW");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_medi_alw") )
              lDmEmployeeMonDtlTabObj.act_amt_medi_alw  =  lResultSet.getDouble("ACT_AMT_MEDI_ALW");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_convy") )
              lDmEmployeeMonDtlTabObj.act_amt_convy  =  lResultSet.getDouble("ACT_AMT_CONVY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_insur") )
              lDmEmployeeMonDtlTabObj.act_amt_insur  =  lResultSet.getDouble("ACT_AMT_INSUR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_dress") )
              lDmEmployeeMonDtlTabObj.act_amt_dress  =  lResultSet.getDouble("ACT_AMT_DRESS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_swf_ded") )
              lDmEmployeeMonDtlTabObj.act_amt_swf_ded  =  lResultSet.getDouble("ACT_AMT_SWF_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_gen_fine") )
              lDmEmployeeMonDtlTabObj.act_amt_gen_fine  =  lResultSet.getDouble("ACT_AMT_GEN_FINE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_pc") )
              lDmEmployeeMonDtlTabObj.act_amt_pc  =  lResultSet.getDouble("ACT_AMT_PC");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_sec_ded") )
              lDmEmployeeMonDtlTabObj.act_amt_sec_ded  =  lResultSet.getDouble("ACT_AMT_SEC_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_oth_ded") )
              lDmEmployeeMonDtlTabObj.act_amt_oth_ded  =  lResultSet.getDouble("ACT_AMT_OTH_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("act_amt_adv_ded") )
              lDmEmployeeMonDtlTabObj.act_amt_adv_ded  =  lResultSet.getDouble("ACT_AMT_ADV_DED");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_status") )
              lDmEmployeeMonDtlTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lDmEmployeeMonDtlTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lDmEmployeeMonDtlTabObj.rec_cre_date != null && lDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lDmEmployeeMonDtlTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lDmEmployeeMonDtlTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lDmEmployeeMonDtlTabObj.rec_upd_date != null && lDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lDmEmployeeMonDtlTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_name") )
              lDmEmployeeMonDtlTabObj.file_name  =  lResultSet.getString("FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_date") )
              {
              lDmEmployeeMonDtlTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");
  
          if ( lDmEmployeeMonDtlTabObj.file_cre_date != null && lDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_time") )
              lDmEmployeeMonDtlTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_status") )
              lDmEmployeeMonDtlTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          }
          removeNullDmEmployeeMonDtlTabObj( lDmEmployeeMonDtlTabObj );

          outDmEmployeeMonDtlTabObjArr.add(  lDmEmployeeMonDtlTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeMonDtlTabObjArr != null && outDmEmployeeMonDtlTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeMonDtlStrArrDist
               ( String inDmEmployeeMonDtlWhereText
               , String inDistDmEmployeeMonDtlField
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {

    sop("gtDmEmployeeMonDtlStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeMonDtlStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";
  

       String lDistDmEmployeeMonDtlFieldQry = inDistDmEmployeeMonDtlField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmEmployeeMonDtlFieldQry+
                         " FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmEmployeeMonDtlField.substring(inDistDmEmployeeMonDtlField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lDmEmployeeMonDtlTabObjStr = "";
       while(lResultSet.next())
       {
          lDmEmployeeMonDtlTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lDmEmployeeMonDtlTabObjStr =   lDmEmployeeMonDtlTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outDmEmployeeMonDtlTabObjArr.add(  lDmEmployeeMonDtlTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeMonDtlTabObjArr != null && outDmEmployeeMonDtlTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValDmEmployeeMonDtl
               ( String inDmEmployeeMonDtlWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValDmEmployeeMonDtl - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValDmEmployeeMonDtl";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullDmEmployeeMonDtlTabObj
               ( 
                 DmEmployeeMonDtlTabObj  outDmEmployeeMonDtlTabObj
               )
  {
  
    if ( outDmEmployeeMonDtlTabObj.org_id == null ) 
     outDmEmployeeMonDtlTabObj.org_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.customer_id == null ) 
     outDmEmployeeMonDtlTabObj.customer_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.employee_id == null ) 
     outDmEmployeeMonDtlTabObj.employee_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.allocation_date == null ) 
     outDmEmployeeMonDtlTabObj.allocation_date = ""; 
    if ( outDmEmployeeMonDtlTabObj.dept_id == null ) 
     outDmEmployeeMonDtlTabObj.dept_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.position_id == null ) 
     outDmEmployeeMonDtlTabObj.position_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.level_id == null ) 
     outDmEmployeeMonDtlTabObj.level_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.name_initials == null ) 
     outDmEmployeeMonDtlTabObj.name_initials = ""; 
    if ( outDmEmployeeMonDtlTabObj.employee_name == null ) 
     outDmEmployeeMonDtlTabObj.employee_name = ""; 
    if ( outDmEmployeeMonDtlTabObj.emp_track_id == null ) 
     outDmEmployeeMonDtlTabObj.emp_track_id = ""; 
    if ( outDmEmployeeMonDtlTabObj.month_num == (int)0 ) 
     outDmEmployeeMonDtlTabObj.month_num = (int)0; 
    if ( outDmEmployeeMonDtlTabObj.working_days == (float)0.00 ) 
     outDmEmployeeMonDtlTabObj.working_days = (float)0.00; 
    if ( outDmEmployeeMonDtlTabObj.absent_days == (float)0.00 ) 
     outDmEmployeeMonDtlTabObj.absent_days = (float)0.00; 
    if ( outDmEmployeeMonDtlTabObj.wages_rate == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.wages_rate = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.gross_mon_wages == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.gross_mon_wages = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_bas == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_bas = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_da == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_da = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_hra == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_hra = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_conv == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_conv = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_woff == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_woff = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_shift_alw == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_wash_alw == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_oth_inc == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_pf == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_pf = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_esi == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_esi = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_swf_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.sh_amt_oth_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.ot_hour == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.ot_hour = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_ot == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_ot = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_oth_inc == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_oth_inc = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_adv == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_adv = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_hra == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_hra = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_weekoff == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_weekoff = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_washing == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_washing = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_areer == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_areer = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_shift_alw == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_shift_alw = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_medi_alw == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_medi_alw = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_convy == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_convy = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_insur == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_insur = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_dress == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_dress = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_swf_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_swf_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_gen_fine == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_gen_fine = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_pc == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_pc = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_sec_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_sec_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_oth_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_oth_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.act_amt_adv_ded == (double)0.00 ) 
     outDmEmployeeMonDtlTabObj.act_amt_adv_ded = (double)0.00; 
    if ( outDmEmployeeMonDtlTabObj.rec_status == null ) 
     outDmEmployeeMonDtlTabObj.rec_status = ""; 
    if ( outDmEmployeeMonDtlTabObj.rec_cre_date == null ) 
     outDmEmployeeMonDtlTabObj.rec_cre_date = ""; 
    if ( outDmEmployeeMonDtlTabObj.rec_cre_time == null ) 
     outDmEmployeeMonDtlTabObj.rec_cre_time = ""; 
    if ( outDmEmployeeMonDtlTabObj.rec_upd_date == null ) 
     outDmEmployeeMonDtlTabObj.rec_upd_date = ""; 
    if ( outDmEmployeeMonDtlTabObj.rec_upd_time == null ) 
     outDmEmployeeMonDtlTabObj.rec_upd_time = ""; 
    if ( outDmEmployeeMonDtlTabObj.file_name == null ) 
     outDmEmployeeMonDtlTabObj.file_name = ""; 
    if ( outDmEmployeeMonDtlTabObj.file_cre_date == null ) 
     outDmEmployeeMonDtlTabObj.file_cre_date = ""; 
    if ( outDmEmployeeMonDtlTabObj.file_cre_time == null ) 
     outDmEmployeeMonDtlTabObj.file_cre_time = ""; 
    if ( outDmEmployeeMonDtlTabObj.file_status == null ) 
     outDmEmployeeMonDtlTabObj.file_status = ""; 
  }





  public int insDmEmployeeMonDtlRec
               ( DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj )
  {
    int lUpdateCount;
    sop("insDmEmployeeMonDtlRec - Started");
    gSSTErrorObj.sourceMethod = "insDmEmployeeMonDtlRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeMonDtlTabObj.allocation_date != null && inDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null && inDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null && inDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.file_cre_date != null && inDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_EMPLOYEE_MON_DTL"+
                        "("+
                                "org_id,"+
                                "customer_id,"+
                                "employee_id,"+
                                "allocation_date,"+
                                "dept_id,"+
                                "position_id,"+
                                "level_id,"+
                                "name_initials,"+
                                "employee_name,"+
                                "emp_track_id,"+
                                "month_num,"+
                                "working_days,"+
                                "absent_days,"+
                                "wages_rate,"+
                                "gross_mon_wages,"+
                                "sh_amt_bas,"+
                                "sh_amt_da,"+
                                "sh_amt_hra,"+
                                "sh_amt_conv,"+
                                "sh_amt_woff,"+
                                "sh_amt_shift_alw,"+
                                "sh_amt_wash_alw,"+
                                "sh_amt_oth_inc,"+
                                "sh_amt_pf,"+
                                "sh_amt_esi,"+
                                "sh_amt_swf_ded,"+
                                "sh_amt_oth_ded,"+
                                "ot_hour,"+
                                "act_amt_ot,"+
                                "act_amt_oth_inc,"+
                                "act_amt_adv,"+
                                "act_amt_hra,"+
                                "act_amt_weekoff,"+
                                "act_amt_washing,"+
                                "act_amt_areer,"+
                                "act_amt_shift_alw,"+
                                "act_amt_medi_alw,"+
                                "act_amt_convy,"+
                                "act_amt_insur,"+
                                "act_amt_dress,"+
                                "act_amt_swf_ded,"+
                                "act_amt_gen_fine,"+
                                "act_amt_pc,"+
                                "act_amt_sec_ded,"+
                                "act_amt_oth_ded,"+
                                "act_amt_adv_ded,"+
                                "rec_status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "file_name,"+
                                "file_cre_date,"+
                                "file_cre_time,"+
                                "file_status"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.customer_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.employee_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.allocation_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.dept_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.position_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.level_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.name_initials+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.employee_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.emp_track_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.month_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.working_days+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.absent_days+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.wages_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.gross_mon_wages+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_bas+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_da+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_hra+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_conv+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_woff+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_shift_alw+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_wash_alw+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_oth_inc+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_pf+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_esi+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_swf_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.sh_amt_oth_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.ot_hour+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_ot+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_oth_inc+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_adv+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_hra+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_weekoff+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_washing+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_areer+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_shift_alw+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_medi_alw+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_convy+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_insur+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_dress+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_swf_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_gen_fine+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_pc+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_sec_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_oth_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeMonDtlTabObj.act_amt_adv_ded+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.rec_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.file_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.file_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inDmEmployeeMonDtlTabObj.file_status+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inDmEmployeeMonDtlTabObj.org_id);
        lPreparedStatement.setString(2, inDmEmployeeMonDtlTabObj.customer_id);
        lPreparedStatement.setString(3, inDmEmployeeMonDtlTabObj.employee_id);
        lPreparedStatement.setString(4, inDmEmployeeMonDtlTabObj.allocation_date);
        lPreparedStatement.setString(5, inDmEmployeeMonDtlTabObj.dept_id);
        lPreparedStatement.setString(6, inDmEmployeeMonDtlTabObj.position_id);
        lPreparedStatement.setString(7, inDmEmployeeMonDtlTabObj.level_id);
        lPreparedStatement.setString(8, inDmEmployeeMonDtlTabObj.name_initials);
        lPreparedStatement.setString(9, inDmEmployeeMonDtlTabObj.employee_name);
        lPreparedStatement.setString(10, inDmEmployeeMonDtlTabObj.emp_track_id);
          lPreparedStatement.setByte(11, inDmEmployeeMonDtlTabObj.month_num);
          lPreparedStatement.setFloat(12, inDmEmployeeMonDtlTabObj.working_days);
          lPreparedStatement.setFloat(13, inDmEmployeeMonDtlTabObj.absent_days);
          lPreparedStatement.setDouble(14, inDmEmployeeMonDtlTabObj.wages_rate);
          lPreparedStatement.setDouble(15, inDmEmployeeMonDtlTabObj.gross_mon_wages);
          lPreparedStatement.setDouble(16, inDmEmployeeMonDtlTabObj.sh_amt_bas);
          lPreparedStatement.setDouble(17, inDmEmployeeMonDtlTabObj.sh_amt_da);
          lPreparedStatement.setDouble(18, inDmEmployeeMonDtlTabObj.sh_amt_hra);
          lPreparedStatement.setDouble(19, inDmEmployeeMonDtlTabObj.sh_amt_conv);
          lPreparedStatement.setDouble(20, inDmEmployeeMonDtlTabObj.sh_amt_woff);
          lPreparedStatement.setDouble(21, inDmEmployeeMonDtlTabObj.sh_amt_shift_alw);
          lPreparedStatement.setDouble(22, inDmEmployeeMonDtlTabObj.sh_amt_wash_alw);
          lPreparedStatement.setDouble(23, inDmEmployeeMonDtlTabObj.sh_amt_oth_inc);
          lPreparedStatement.setDouble(24, inDmEmployeeMonDtlTabObj.sh_amt_pf);
          lPreparedStatement.setDouble(25, inDmEmployeeMonDtlTabObj.sh_amt_esi);
          lPreparedStatement.setDouble(26, inDmEmployeeMonDtlTabObj.sh_amt_swf_ded);
          lPreparedStatement.setDouble(27, inDmEmployeeMonDtlTabObj.sh_amt_oth_ded);
          lPreparedStatement.setDouble(28, inDmEmployeeMonDtlTabObj.ot_hour);
          lPreparedStatement.setDouble(29, inDmEmployeeMonDtlTabObj.act_amt_ot);
          lPreparedStatement.setDouble(30, inDmEmployeeMonDtlTabObj.act_amt_oth_inc);
          lPreparedStatement.setDouble(31, inDmEmployeeMonDtlTabObj.act_amt_adv);
          lPreparedStatement.setDouble(32, inDmEmployeeMonDtlTabObj.act_amt_hra);
          lPreparedStatement.setDouble(33, inDmEmployeeMonDtlTabObj.act_amt_weekoff);
          lPreparedStatement.setDouble(34, inDmEmployeeMonDtlTabObj.act_amt_washing);
          lPreparedStatement.setDouble(35, inDmEmployeeMonDtlTabObj.act_amt_areer);
          lPreparedStatement.setDouble(36, inDmEmployeeMonDtlTabObj.act_amt_shift_alw);
          lPreparedStatement.setDouble(37, inDmEmployeeMonDtlTabObj.act_amt_medi_alw);
          lPreparedStatement.setDouble(38, inDmEmployeeMonDtlTabObj.act_amt_convy);
          lPreparedStatement.setDouble(39, inDmEmployeeMonDtlTabObj.act_amt_insur);
          lPreparedStatement.setDouble(40, inDmEmployeeMonDtlTabObj.act_amt_dress);
          lPreparedStatement.setDouble(41, inDmEmployeeMonDtlTabObj.act_amt_swf_ded);
          lPreparedStatement.setDouble(42, inDmEmployeeMonDtlTabObj.act_amt_gen_fine);
          lPreparedStatement.setDouble(43, inDmEmployeeMonDtlTabObj.act_amt_pc);
          lPreparedStatement.setDouble(44, inDmEmployeeMonDtlTabObj.act_amt_sec_ded);
          lPreparedStatement.setDouble(45, inDmEmployeeMonDtlTabObj.act_amt_oth_ded);
          lPreparedStatement.setDouble(46, inDmEmployeeMonDtlTabObj.act_amt_adv_ded);
        lPreparedStatement.setString(47, inDmEmployeeMonDtlTabObj.rec_status);
        lPreparedStatement.setString(48, inDmEmployeeMonDtlTabObj.rec_cre_date);
        lPreparedStatement.setString(49, inDmEmployeeMonDtlTabObj.rec_cre_time);
        lPreparedStatement.setString(50, inDmEmployeeMonDtlTabObj.rec_upd_date);
        lPreparedStatement.setString(51, inDmEmployeeMonDtlTabObj.rec_upd_time);
        lPreparedStatement.setString(52, inDmEmployeeMonDtlTabObj.file_name);
        lPreparedStatement.setString(53, inDmEmployeeMonDtlTabObj.file_cre_date);
        lPreparedStatement.setString(54, inDmEmployeeMonDtlTabObj.file_cre_time);
        lPreparedStatement.setString(55, inDmEmployeeMonDtlTabObj.file_status);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insDmEmployeeMonDtlArr
               ( ArrayList  inDmEmployeeMonDtlTabObjArr 
               , String  inRowidFlag )
  {
    DmEmployeeMonDtlTabObj  lDmEmployeeMonDtlTabObj = new DmEmployeeMonDtlTabObj();
    int lUpdateCount;
    sop("insDmEmployeeMonDtlArr - Started");
    gSSTErrorObj.sourceMethod = "insDmEmployeeMonDtlArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inDmEmployeeMonDtlTabObjArr.size(); lNumRec++ )
      {
        lDmEmployeeMonDtlTabObj = (DmEmployeeMonDtlTabObj)inDmEmployeeMonDtlTabObjArr.get(lNumRec);

          if ( lDmEmployeeMonDtlTabObj.allocation_date != null && lDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeMonDtlTabObj.allocation_date, lDateTimeSrcFmt);

          if ( lDmEmployeeMonDtlTabObj.rec_cre_date != null && lDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lDmEmployeeMonDtlTabObj.rec_upd_date != null && lDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( lDmEmployeeMonDtlTabObj.file_cre_date != null && lDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_EMPLOYEE_MON_DTL"+
                        "("+
                        "org_id,"+
                        "customer_id,"+
                        "employee_id,"+
                        "allocation_date,"+
                        "dept_id,"+
                        "position_id,"+
                        "level_id,"+
                        "name_initials,"+
                        "employee_name,"+
                        "emp_track_id,"+
                        "month_num,"+
                        "working_days,"+
                        "absent_days,"+
                        "wages_rate,"+
                        "gross_mon_wages,"+
                        "sh_amt_bas,"+
                        "sh_amt_da,"+
                        "sh_amt_hra,"+
                        "sh_amt_conv,"+
                        "sh_amt_woff,"+
                        "sh_amt_shift_alw,"+
                        "sh_amt_wash_alw,"+
                        "sh_amt_oth_inc,"+
                        "sh_amt_pf,"+
                        "sh_amt_esi,"+
                        "sh_amt_swf_ded,"+
                        "sh_amt_oth_ded,"+
                        "ot_hour,"+
                        "act_amt_ot,"+
                        "act_amt_oth_inc,"+
                        "act_amt_adv,"+
                        "act_amt_hra,"+
                        "act_amt_weekoff,"+
                        "act_amt_washing,"+
                        "act_amt_areer,"+
                        "act_amt_shift_alw,"+
                        "act_amt_medi_alw,"+
                        "act_amt_convy,"+
                        "act_amt_insur,"+
                        "act_amt_dress,"+
                        "act_amt_swf_ded,"+
                        "act_amt_gen_fine,"+
                        "act_amt_pc,"+
                        "act_amt_sec_ded,"+
                        "act_amt_oth_ded,"+
                        "act_amt_adv_ded,"+
                        "rec_status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "file_name,"+
                        "file_cre_date,"+
                        "file_cre_time,"+
                        "file_status"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.customer_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.employee_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.allocation_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.dept_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.position_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.level_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.name_initials+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.employee_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.emp_track_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.month_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.working_days+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.absent_days+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.wages_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.gross_mon_wages+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_bas+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_da+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_hra+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_conv+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_woff+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_shift_alw+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_wash_alw+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_oth_inc+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_pf+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_esi+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_swf_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.sh_amt_oth_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.ot_hour+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_ot+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_oth_inc+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_adv+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_hra+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_weekoff+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_washing+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_areer+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_shift_alw+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_medi_alw+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_convy+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_insur+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_dress+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_swf_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_gen_fine+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_pc+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_sec_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_oth_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeMonDtlTabObj.act_amt_adv_ded+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.rec_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.file_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.file_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lDmEmployeeMonDtlTabObj.file_status+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lDmEmployeeMonDtlTabObj.org_id);
            lPreparedStatement.setString(2, lDmEmployeeMonDtlTabObj.customer_id);
            lPreparedStatement.setString(3, lDmEmployeeMonDtlTabObj.employee_id);
            lPreparedStatement.setString(4, lDmEmployeeMonDtlTabObj.allocation_date);
            lPreparedStatement.setString(5, lDmEmployeeMonDtlTabObj.dept_id);
            lPreparedStatement.setString(6, lDmEmployeeMonDtlTabObj.position_id);
            lPreparedStatement.setString(7, lDmEmployeeMonDtlTabObj.level_id);
            lPreparedStatement.setString(8, lDmEmployeeMonDtlTabObj.name_initials);
            lPreparedStatement.setString(9, lDmEmployeeMonDtlTabObj.employee_name);
            lPreparedStatement.setString(10, lDmEmployeeMonDtlTabObj.emp_track_id);
              lPreparedStatement.setByte(11, lDmEmployeeMonDtlTabObj.month_num);
              lPreparedStatement.setFloat(12, lDmEmployeeMonDtlTabObj.working_days);
              lPreparedStatement.setFloat(13, lDmEmployeeMonDtlTabObj.absent_days);
              lPreparedStatement.setDouble(14, lDmEmployeeMonDtlTabObj.wages_rate);
              lPreparedStatement.setDouble(15, lDmEmployeeMonDtlTabObj.gross_mon_wages);
              lPreparedStatement.setDouble(16, lDmEmployeeMonDtlTabObj.sh_amt_bas);
              lPreparedStatement.setDouble(17, lDmEmployeeMonDtlTabObj.sh_amt_da);
              lPreparedStatement.setDouble(18, lDmEmployeeMonDtlTabObj.sh_amt_hra);
              lPreparedStatement.setDouble(19, lDmEmployeeMonDtlTabObj.sh_amt_conv);
              lPreparedStatement.setDouble(20, lDmEmployeeMonDtlTabObj.sh_amt_woff);
              lPreparedStatement.setDouble(21, lDmEmployeeMonDtlTabObj.sh_amt_shift_alw);
              lPreparedStatement.setDouble(22, lDmEmployeeMonDtlTabObj.sh_amt_wash_alw);
              lPreparedStatement.setDouble(23, lDmEmployeeMonDtlTabObj.sh_amt_oth_inc);
              lPreparedStatement.setDouble(24, lDmEmployeeMonDtlTabObj.sh_amt_pf);
              lPreparedStatement.setDouble(25, lDmEmployeeMonDtlTabObj.sh_amt_esi);
              lPreparedStatement.setDouble(26, lDmEmployeeMonDtlTabObj.sh_amt_swf_ded);
              lPreparedStatement.setDouble(27, lDmEmployeeMonDtlTabObj.sh_amt_oth_ded);
              lPreparedStatement.setDouble(28, lDmEmployeeMonDtlTabObj.ot_hour);
              lPreparedStatement.setDouble(29, lDmEmployeeMonDtlTabObj.act_amt_ot);
              lPreparedStatement.setDouble(30, lDmEmployeeMonDtlTabObj.act_amt_oth_inc);
              lPreparedStatement.setDouble(31, lDmEmployeeMonDtlTabObj.act_amt_adv);
              lPreparedStatement.setDouble(32, lDmEmployeeMonDtlTabObj.act_amt_hra);
              lPreparedStatement.setDouble(33, lDmEmployeeMonDtlTabObj.act_amt_weekoff);
              lPreparedStatement.setDouble(34, lDmEmployeeMonDtlTabObj.act_amt_washing);
              lPreparedStatement.setDouble(35, lDmEmployeeMonDtlTabObj.act_amt_areer);
              lPreparedStatement.setDouble(36, lDmEmployeeMonDtlTabObj.act_amt_shift_alw);
              lPreparedStatement.setDouble(37, lDmEmployeeMonDtlTabObj.act_amt_medi_alw);
              lPreparedStatement.setDouble(38, lDmEmployeeMonDtlTabObj.act_amt_convy);
              lPreparedStatement.setDouble(39, lDmEmployeeMonDtlTabObj.act_amt_insur);
              lPreparedStatement.setDouble(40, lDmEmployeeMonDtlTabObj.act_amt_dress);
              lPreparedStatement.setDouble(41, lDmEmployeeMonDtlTabObj.act_amt_swf_ded);
              lPreparedStatement.setDouble(42, lDmEmployeeMonDtlTabObj.act_amt_gen_fine);
              lPreparedStatement.setDouble(43, lDmEmployeeMonDtlTabObj.act_amt_pc);
              lPreparedStatement.setDouble(44, lDmEmployeeMonDtlTabObj.act_amt_sec_ded);
              lPreparedStatement.setDouble(45, lDmEmployeeMonDtlTabObj.act_amt_oth_ded);
              lPreparedStatement.setDouble(46, lDmEmployeeMonDtlTabObj.act_amt_adv_ded);
            lPreparedStatement.setString(47, lDmEmployeeMonDtlTabObj.rec_status);
            lPreparedStatement.setString(48, lDmEmployeeMonDtlTabObj.rec_cre_date);
            lPreparedStatement.setString(49, lDmEmployeeMonDtlTabObj.rec_cre_time);
            lPreparedStatement.setString(50, lDmEmployeeMonDtlTabObj.rec_upd_date);
            lPreparedStatement.setString(51, lDmEmployeeMonDtlTabObj.rec_upd_time);
            lPreparedStatement.setString(52, lDmEmployeeMonDtlTabObj.file_name);
            lPreparedStatement.setString(53, lDmEmployeeMonDtlTabObj.file_cre_date);
            lPreparedStatement.setString(54, lDmEmployeeMonDtlTabObj.file_cre_time);
            lPreparedStatement.setString(55, lDmEmployeeMonDtlTabObj.file_status);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popDmEmployeeMonDtlReq2Obj
               ( HttpServletRequest inRequest
               , DmEmployeeMonDtlTabObj  outDmEmployeeMonDtlTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outDmEmployeeMonDtlTabObj.tab_rowid = lTabRowidValue;

    outDmEmployeeMonDtlTabObj.org_id = inRequest.getParameter("org_id");
    outDmEmployeeMonDtlTabObj.customer_id = inRequest.getParameter("customer_id");
    outDmEmployeeMonDtlTabObj.employee_id = inRequest.getParameter("employee_id");
    outDmEmployeeMonDtlTabObj.allocation_date = inRequest.getParameter("allocation_date");
    outDmEmployeeMonDtlTabObj.dept_id = inRequest.getParameter("dept_id");
    outDmEmployeeMonDtlTabObj.position_id = inRequest.getParameter("position_id");
    outDmEmployeeMonDtlTabObj.level_id = inRequest.getParameter("level_id");
    outDmEmployeeMonDtlTabObj.name_initials = inRequest.getParameter("name_initials");
    outDmEmployeeMonDtlTabObj.employee_name = inRequest.getParameter("employee_name");
    outDmEmployeeMonDtlTabObj.emp_track_id = inRequest.getParameter("emp_track_id");
    if ( inRequest.getParameter("month_num") == null )
      outDmEmployeeMonDtlTabObj.month_num = 0;
    else
    if ( inRequest.getParameter("month_num").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.month_num = 0;
    else
      outDmEmployeeMonDtlTabObj.month_num = Byte.parseByte( inRequest.getParameter("month_num"));
    if ( inRequest.getParameter("working_days") == null )
      outDmEmployeeMonDtlTabObj.working_days = 0;
    else
    if ( inRequest.getParameter("working_days").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.working_days = 0;
    else
      outDmEmployeeMonDtlTabObj.working_days = Float.parseFloat( inRequest.getParameter("working_days"));
    if ( inRequest.getParameter("absent_days") == null )
      outDmEmployeeMonDtlTabObj.absent_days = 0;
    else
    if ( inRequest.getParameter("absent_days").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.absent_days = 0;
    else
      outDmEmployeeMonDtlTabObj.absent_days = Float.parseFloat( inRequest.getParameter("absent_days"));
    if ( inRequest.getParameter("wages_rate") == null )
      outDmEmployeeMonDtlTabObj.wages_rate = 0;
    else
    if ( inRequest.getParameter("wages_rate").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.wages_rate = 0;
    else
      outDmEmployeeMonDtlTabObj.wages_rate = Double.parseDouble( inRequest.getParameter("wages_rate"));
    if ( inRequest.getParameter("gross_mon_wages") == null )
      outDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
    else
    if ( inRequest.getParameter("gross_mon_wages").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
    else
      outDmEmployeeMonDtlTabObj.gross_mon_wages = Double.parseDouble( inRequest.getParameter("gross_mon_wages"));
    if ( inRequest.getParameter("sh_amt_bas") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
    else
    if ( inRequest.getParameter("sh_amt_bas").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_bas = Double.parseDouble( inRequest.getParameter("sh_amt_bas"));
    if ( inRequest.getParameter("sh_amt_da") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_da = 0;
    else
    if ( inRequest.getParameter("sh_amt_da").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_da = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_da = Double.parseDouble( inRequest.getParameter("sh_amt_da"));
    if ( inRequest.getParameter("sh_amt_hra") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
    else
    if ( inRequest.getParameter("sh_amt_hra").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_hra = Double.parseDouble( inRequest.getParameter("sh_amt_hra"));
    if ( inRequest.getParameter("sh_amt_conv") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
    else
    if ( inRequest.getParameter("sh_amt_conv").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_conv = Double.parseDouble( inRequest.getParameter("sh_amt_conv"));
    if ( inRequest.getParameter("sh_amt_woff") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
    else
    if ( inRequest.getParameter("sh_amt_woff").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_woff = Double.parseDouble( inRequest.getParameter("sh_amt_woff"));
    if ( inRequest.getParameter("sh_amt_shift_alw") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
    else
    if ( inRequest.getParameter("sh_amt_shift_alw").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = Double.parseDouble( inRequest.getParameter("sh_amt_shift_alw"));
    if ( inRequest.getParameter("sh_amt_wash_alw") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
    else
    if ( inRequest.getParameter("sh_amt_wash_alw").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = Double.parseDouble( inRequest.getParameter("sh_amt_wash_alw"));
    if ( inRequest.getParameter("sh_amt_oth_inc") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
    else
    if ( inRequest.getParameter("sh_amt_oth_inc").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = Double.parseDouble( inRequest.getParameter("sh_amt_oth_inc"));
    if ( inRequest.getParameter("sh_amt_pf") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
    else
    if ( inRequest.getParameter("sh_amt_pf").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_pf = Double.parseDouble( inRequest.getParameter("sh_amt_pf"));
    if ( inRequest.getParameter("sh_amt_esi") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
    else
    if ( inRequest.getParameter("sh_amt_esi").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_esi = Double.parseDouble( inRequest.getParameter("sh_amt_esi"));
    if ( inRequest.getParameter("sh_amt_swf_ded") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
    else
    if ( inRequest.getParameter("sh_amt_swf_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = Double.parseDouble( inRequest.getParameter("sh_amt_swf_ded"));
    if ( inRequest.getParameter("sh_amt_oth_ded") == null )
      outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
    else
    if ( inRequest.getParameter("sh_amt_oth_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = Double.parseDouble( inRequest.getParameter("sh_amt_oth_ded"));
    if ( inRequest.getParameter("ot_hour") == null )
      outDmEmployeeMonDtlTabObj.ot_hour = 0;
    else
    if ( inRequest.getParameter("ot_hour").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.ot_hour = 0;
    else
      outDmEmployeeMonDtlTabObj.ot_hour = Double.parseDouble( inRequest.getParameter("ot_hour"));
    if ( inRequest.getParameter("act_amt_ot") == null )
      outDmEmployeeMonDtlTabObj.act_amt_ot = 0;
    else
    if ( inRequest.getParameter("act_amt_ot").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_ot = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_ot = Double.parseDouble( inRequest.getParameter("act_amt_ot"));
    if ( inRequest.getParameter("act_amt_oth_inc") == null )
      outDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
    else
    if ( inRequest.getParameter("act_amt_oth_inc").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_oth_inc = Double.parseDouble( inRequest.getParameter("act_amt_oth_inc"));
    if ( inRequest.getParameter("act_amt_adv") == null )
      outDmEmployeeMonDtlTabObj.act_amt_adv = 0;
    else
    if ( inRequest.getParameter("act_amt_adv").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_adv = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_adv = Double.parseDouble( inRequest.getParameter("act_amt_adv"));
    if ( inRequest.getParameter("act_amt_hra") == null )
      outDmEmployeeMonDtlTabObj.act_amt_hra = 0;
    else
    if ( inRequest.getParameter("act_amt_hra").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_hra = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_hra = Double.parseDouble( inRequest.getParameter("act_amt_hra"));
    if ( inRequest.getParameter("act_amt_weekoff") == null )
      outDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
    else
    if ( inRequest.getParameter("act_amt_weekoff").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_weekoff = Double.parseDouble( inRequest.getParameter("act_amt_weekoff"));
    if ( inRequest.getParameter("act_amt_washing") == null )
      outDmEmployeeMonDtlTabObj.act_amt_washing = 0;
    else
    if ( inRequest.getParameter("act_amt_washing").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_washing = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_washing = Double.parseDouble( inRequest.getParameter("act_amt_washing"));
    if ( inRequest.getParameter("act_amt_areer") == null )
      outDmEmployeeMonDtlTabObj.act_amt_areer = 0;
    else
    if ( inRequest.getParameter("act_amt_areer").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_areer = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_areer = Double.parseDouble( inRequest.getParameter("act_amt_areer"));
    if ( inRequest.getParameter("act_amt_shift_alw") == null )
      outDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
    else
    if ( inRequest.getParameter("act_amt_shift_alw").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_shift_alw = Double.parseDouble( inRequest.getParameter("act_amt_shift_alw"));
    if ( inRequest.getParameter("act_amt_medi_alw") == null )
      outDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
    else
    if ( inRequest.getParameter("act_amt_medi_alw").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_medi_alw = Double.parseDouble( inRequest.getParameter("act_amt_medi_alw"));
    if ( inRequest.getParameter("act_amt_convy") == null )
      outDmEmployeeMonDtlTabObj.act_amt_convy = 0;
    else
    if ( inRequest.getParameter("act_amt_convy").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_convy = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_convy = Double.parseDouble( inRequest.getParameter("act_amt_convy"));
    if ( inRequest.getParameter("act_amt_insur") == null )
      outDmEmployeeMonDtlTabObj.act_amt_insur = 0;
    else
    if ( inRequest.getParameter("act_amt_insur").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_insur = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_insur = Double.parseDouble( inRequest.getParameter("act_amt_insur"));
    if ( inRequest.getParameter("act_amt_dress") == null )
      outDmEmployeeMonDtlTabObj.act_amt_dress = 0;
    else
    if ( inRequest.getParameter("act_amt_dress").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_dress = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_dress = Double.parseDouble( inRequest.getParameter("act_amt_dress"));
    if ( inRequest.getParameter("act_amt_swf_ded") == null )
      outDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
    else
    if ( inRequest.getParameter("act_amt_swf_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_swf_ded = Double.parseDouble( inRequest.getParameter("act_amt_swf_ded"));
    if ( inRequest.getParameter("act_amt_gen_fine") == null )
      outDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
    else
    if ( inRequest.getParameter("act_amt_gen_fine").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_gen_fine = Double.parseDouble( inRequest.getParameter("act_amt_gen_fine"));
    if ( inRequest.getParameter("act_amt_pc") == null )
      outDmEmployeeMonDtlTabObj.act_amt_pc = 0;
    else
    if ( inRequest.getParameter("act_amt_pc").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_pc = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_pc = Double.parseDouble( inRequest.getParameter("act_amt_pc"));
    if ( inRequest.getParameter("act_amt_sec_ded") == null )
      outDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
    else
    if ( inRequest.getParameter("act_amt_sec_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_sec_ded = Double.parseDouble( inRequest.getParameter("act_amt_sec_ded"));
    if ( inRequest.getParameter("act_amt_oth_ded") == null )
      outDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
    else
    if ( inRequest.getParameter("act_amt_oth_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_oth_ded = Double.parseDouble( inRequest.getParameter("act_amt_oth_ded"));
    if ( inRequest.getParameter("act_amt_adv_ded") == null )
      outDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
    else
    if ( inRequest.getParameter("act_amt_adv_ded").trim().length() == 0 )
      outDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
    else
      outDmEmployeeMonDtlTabObj.act_amt_adv_ded = Double.parseDouble( inRequest.getParameter("act_amt_adv_ded"));
    outDmEmployeeMonDtlTabObj.rec_status = inRequest.getParameter("rec_status");
    outDmEmployeeMonDtlTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outDmEmployeeMonDtlTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outDmEmployeeMonDtlTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outDmEmployeeMonDtlTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outDmEmployeeMonDtlTabObj.file_name = inRequest.getParameter("file_name");
    outDmEmployeeMonDtlTabObj.file_cre_date = inRequest.getParameter("file_cre_date");
    outDmEmployeeMonDtlTabObj.file_cre_time = inRequest.getParameter("file_cre_time");
    outDmEmployeeMonDtlTabObj.file_status = inRequest.getParameter("file_status");
    return lReturnValue;
  }


  public int popDmEmployeeMonDtlReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmEmployeeMonDtlTabObj lDmEmployeeMonDtlTabObj= new DmEmployeeMonDtlTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.tab_rowid = lTabRowidValue;

      lDmEmployeeMonDtlTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.employee_name = inRequest.getParameter("employee_name_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
      if ( inRequest.getParameter("month_num_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.month_num = 0;
      else
      if ( inRequest.getParameter("month_num_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.month_num = 0;
      else
        lDmEmployeeMonDtlTabObj.month_num = Byte.parseByte( inRequest.getParameter("month_num_r"+lNumRec));
      if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.working_days = 0;
      else
      if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.working_days = 0;
      else
        lDmEmployeeMonDtlTabObj.working_days = Float.parseFloat( inRequest.getParameter("working_days_r"+lNumRec));
      if ( inRequest.getParameter("absent_days_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.absent_days = 0;
      else
      if ( inRequest.getParameter("absent_days_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.absent_days = 0;
      else
        lDmEmployeeMonDtlTabObj.absent_days = Float.parseFloat( inRequest.getParameter("absent_days_r"+lNumRec));
      if ( inRequest.getParameter("wages_rate_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.wages_rate = 0;
      else
      if ( inRequest.getParameter("wages_rate_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.wages_rate = 0;
      else
        lDmEmployeeMonDtlTabObj.wages_rate = Double.parseDouble( inRequest.getParameter("wages_rate_r"+lNumRec));
      if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
      else
      if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
      else
        lDmEmployeeMonDtlTabObj.gross_mon_wages = Double.parseDouble( inRequest.getParameter("gross_mon_wages_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
      else
      if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_bas = Double.parseDouble( inRequest.getParameter("sh_amt_bas_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_da_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_da = 0;
      else
      if ( inRequest.getParameter("sh_amt_da_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_da = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_da = Double.parseDouble( inRequest.getParameter("sh_amt_da_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
      else
      if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_hra = Double.parseDouble( inRequest.getParameter("sh_amt_hra_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
      else
      if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_conv = Double.parseDouble( inRequest.getParameter("sh_amt_conv_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
      else
      if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_woff = Double.parseDouble( inRequest.getParameter("sh_amt_woff_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
      else
      if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = Double.parseDouble( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
      else
      if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = Double.parseDouble( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
      else
      if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = Double.parseDouble( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
      else
      if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_pf = Double.parseDouble( inRequest.getParameter("sh_amt_pf_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
      else
      if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_esi = Double.parseDouble( inRequest.getParameter("sh_amt_esi_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
      else
      if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = Double.parseDouble( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec));
      if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
      else
      if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = Double.parseDouble( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec));
      if ( inRequest.getParameter("ot_hour_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.ot_hour = 0;
      else
      if ( inRequest.getParameter("ot_hour_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.ot_hour = 0;
      else
        lDmEmployeeMonDtlTabObj.ot_hour = Double.parseDouble( inRequest.getParameter("ot_hour_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_ot_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_ot = 0;
      else
      if ( inRequest.getParameter("act_amt_ot_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_ot = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_ot = Double.parseDouble( inRequest.getParameter("act_amt_ot_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
      else
      if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_oth_inc = Double.parseDouble( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_adv_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_adv = 0;
      else
      if ( inRequest.getParameter("act_amt_adv_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_adv = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_adv = Double.parseDouble( inRequest.getParameter("act_amt_adv_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_hra_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_hra = 0;
      else
      if ( inRequest.getParameter("act_amt_hra_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_hra = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_hra = Double.parseDouble( inRequest.getParameter("act_amt_hra_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
      else
      if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_weekoff = Double.parseDouble( inRequest.getParameter("act_amt_weekoff_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_washing_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_washing = 0;
      else
      if ( inRequest.getParameter("act_amt_washing_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_washing = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_washing = Double.parseDouble( inRequest.getParameter("act_amt_washing_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_areer_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_areer = 0;
      else
      if ( inRequest.getParameter("act_amt_areer_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_areer = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_areer = Double.parseDouble( inRequest.getParameter("act_amt_areer_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
      else
      if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_shift_alw = Double.parseDouble( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
      else
      if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_medi_alw = Double.parseDouble( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_convy_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_convy = 0;
      else
      if ( inRequest.getParameter("act_amt_convy_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_convy = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_convy = Double.parseDouble( inRequest.getParameter("act_amt_convy_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_insur_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_insur = 0;
      else
      if ( inRequest.getParameter("act_amt_insur_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_insur = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_insur = Double.parseDouble( inRequest.getParameter("act_amt_insur_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_dress_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_dress = 0;
      else
      if ( inRequest.getParameter("act_amt_dress_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_dress = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_dress = Double.parseDouble( inRequest.getParameter("act_amt_dress_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
      else
      if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_swf_ded = Double.parseDouble( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
      else
      if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_gen_fine = Double.parseDouble( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_pc_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_pc = 0;
      else
      if ( inRequest.getParameter("act_amt_pc_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_pc = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_pc = Double.parseDouble( inRequest.getParameter("act_amt_pc_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
      else
      if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_sec_ded = Double.parseDouble( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
      else
      if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_oth_ded = Double.parseDouble( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec));
      if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec) == null )
        lDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
      else
      if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
      else
        lDmEmployeeMonDtlTabObj.act_amt_adv_ded = Double.parseDouble( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec));
      lDmEmployeeMonDtlTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      outDmEmployeeMonDtlTabObjArr.add( lDmEmployeeMonDtlTabObj);
    }
    return lReturnValue;
  }


  public int popDmEmployeeMonDtlReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , DmEmployeeMonDtlTabObj outDmEmployeeMonDtlTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_employee_mon_dtl_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.tab_rowid = lTabRowidValue;

        outDmEmployeeMonDtlTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.employee_name = inRequest.getParameter("employee_name_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
        if ( inRequest.getParameter("month_num_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.month_num = 0;
        else
        if ( inRequest.getParameter("month_num_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.month_num = 0;
        else
          outDmEmployeeMonDtlTabObj.month_num = Byte.parseByte( inRequest.getParameter("month_num_r"+lNumRec));
        if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.working_days = 0;
        else
        if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.working_days = 0;
        else
          outDmEmployeeMonDtlTabObj.working_days = Float.parseFloat( inRequest.getParameter("working_days_r"+lNumRec));
        if ( inRequest.getParameter("absent_days_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.absent_days = 0;
        else
        if ( inRequest.getParameter("absent_days_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.absent_days = 0;
        else
          outDmEmployeeMonDtlTabObj.absent_days = Float.parseFloat( inRequest.getParameter("absent_days_r"+lNumRec));
        if ( inRequest.getParameter("wages_rate_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.wages_rate = 0;
        else
        if ( inRequest.getParameter("wages_rate_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.wages_rate = 0;
        else
          outDmEmployeeMonDtlTabObj.wages_rate = Double.parseDouble( inRequest.getParameter("wages_rate_r"+lNumRec));
        if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
        else
        if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
        else
          outDmEmployeeMonDtlTabObj.gross_mon_wages = Double.parseDouble( inRequest.getParameter("gross_mon_wages_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
        else
        if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_bas = Double.parseDouble( inRequest.getParameter("sh_amt_bas_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_da_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_da = 0;
        else
        if ( inRequest.getParameter("sh_amt_da_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_da = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_da = Double.parseDouble( inRequest.getParameter("sh_amt_da_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
        else
        if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_hra = Double.parseDouble( inRequest.getParameter("sh_amt_hra_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
        else
        if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_conv = Double.parseDouble( inRequest.getParameter("sh_amt_conv_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
        else
        if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_woff = Double.parseDouble( inRequest.getParameter("sh_amt_woff_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
        else
        if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_shift_alw = Double.parseDouble( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
        else
        if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_wash_alw = Double.parseDouble( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
        else
        if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_oth_inc = Double.parseDouble( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
        else
        if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_pf = Double.parseDouble( inRequest.getParameter("sh_amt_pf_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
        else
        if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_esi = Double.parseDouble( inRequest.getParameter("sh_amt_esi_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
        else
        if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_swf_ded = Double.parseDouble( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
        else
        if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.sh_amt_oth_ded = Double.parseDouble( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec));
        if ( inRequest.getParameter("ot_hour_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.ot_hour = 0;
        else
        if ( inRequest.getParameter("ot_hour_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.ot_hour = 0;
        else
          outDmEmployeeMonDtlTabObj.ot_hour = Double.parseDouble( inRequest.getParameter("ot_hour_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_ot_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_ot = 0;
        else
        if ( inRequest.getParameter("act_amt_ot_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_ot = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_ot = Double.parseDouble( inRequest.getParameter("act_amt_ot_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
        else
        if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_oth_inc = Double.parseDouble( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_adv_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_adv = 0;
        else
        if ( inRequest.getParameter("act_amt_adv_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_adv = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_adv = Double.parseDouble( inRequest.getParameter("act_amt_adv_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_hra_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_hra = 0;
        else
        if ( inRequest.getParameter("act_amt_hra_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_hra = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_hra = Double.parseDouble( inRequest.getParameter("act_amt_hra_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
        else
        if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_weekoff = Double.parseDouble( inRequest.getParameter("act_amt_weekoff_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_washing_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_washing = 0;
        else
        if ( inRequest.getParameter("act_amt_washing_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_washing = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_washing = Double.parseDouble( inRequest.getParameter("act_amt_washing_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_areer_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_areer = 0;
        else
        if ( inRequest.getParameter("act_amt_areer_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_areer = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_areer = Double.parseDouble( inRequest.getParameter("act_amt_areer_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
        else
        if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_shift_alw = Double.parseDouble( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
        else
        if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_medi_alw = Double.parseDouble( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_convy_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_convy = 0;
        else
        if ( inRequest.getParameter("act_amt_convy_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_convy = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_convy = Double.parseDouble( inRequest.getParameter("act_amt_convy_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_insur_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_insur = 0;
        else
        if ( inRequest.getParameter("act_amt_insur_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_insur = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_insur = Double.parseDouble( inRequest.getParameter("act_amt_insur_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_dress_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_dress = 0;
        else
        if ( inRequest.getParameter("act_amt_dress_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_dress = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_dress = Double.parseDouble( inRequest.getParameter("act_amt_dress_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_swf_ded = Double.parseDouble( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
        else
        if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_gen_fine = Double.parseDouble( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_pc_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_pc = 0;
        else
        if ( inRequest.getParameter("act_amt_pc_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_pc = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_pc = Double.parseDouble( inRequest.getParameter("act_amt_pc_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_sec_ded = Double.parseDouble( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_oth_ded = Double.parseDouble( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec) == null )
          outDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
        else
          outDmEmployeeMonDtlTabObj.act_amt_adv_ded = Double.parseDouble( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec));
        outDmEmployeeMonDtlTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        outDmEmployeeMonDtlTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popDmEmployeeMonDtlReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmEmployeeMonDtlTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmEmployeeMonDtlTabObj lDmEmployeeMonDtlTabObj= new DmEmployeeMonDtlTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_employee_mon_dtl_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmEmployeeMonDtlTabObj.tab_rowid = lTabRowidValue;

        lDmEmployeeMonDtlTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.employee_name = inRequest.getParameter("employee_name_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
        if ( inRequest.getParameter("month_num_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.month_num = 0;
        else
        if ( inRequest.getParameter("month_num_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.month_num = 0;
        else
          lDmEmployeeMonDtlTabObj.month_num = Byte.parseByte( inRequest.getParameter("month_num_r"+lNumRec));
        if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.working_days = 0;
        else
        if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.working_days = 0;
        else
            lDmEmployeeMonDtlTabObj.working_days = Float.parseFloat( inRequest.getParameter("working_days_r"+lNumRec));
        if ( inRequest.getParameter("absent_days_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.absent_days = 0;
        else
        if ( inRequest.getParameter("absent_days_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.absent_days = 0;
        else
            lDmEmployeeMonDtlTabObj.absent_days = Float.parseFloat( inRequest.getParameter("absent_days_r"+lNumRec));
        if ( inRequest.getParameter("wages_rate_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.wages_rate = 0;
        else
        if ( inRequest.getParameter("wages_rate_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.wages_rate = 0;
        else
            lDmEmployeeMonDtlTabObj.wages_rate = Double.parseDouble( inRequest.getParameter("wages_rate_r"+lNumRec));
        if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
        else
        if ( inRequest.getParameter("gross_mon_wages_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.gross_mon_wages = 0;
        else
            lDmEmployeeMonDtlTabObj.gross_mon_wages = Double.parseDouble( inRequest.getParameter("gross_mon_wages_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
        else
        if ( inRequest.getParameter("sh_amt_bas_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_bas = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_bas = Double.parseDouble( inRequest.getParameter("sh_amt_bas_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_da_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_da = 0;
        else
        if ( inRequest.getParameter("sh_amt_da_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_da = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_da = Double.parseDouble( inRequest.getParameter("sh_amt_da_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
        else
        if ( inRequest.getParameter("sh_amt_hra_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_hra = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_hra = Double.parseDouble( inRequest.getParameter("sh_amt_hra_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
        else
        if ( inRequest.getParameter("sh_amt_conv_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_conv = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_conv = Double.parseDouble( inRequest.getParameter("sh_amt_conv_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
        else
        if ( inRequest.getParameter("sh_amt_woff_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_woff = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_woff = Double.parseDouble( inRequest.getParameter("sh_amt_woff_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
        else
        if ( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_shift_alw = Double.parseDouble( inRequest.getParameter("sh_amt_shift_alw_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
        else
        if ( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_wash_alw = Double.parseDouble( inRequest.getParameter("sh_amt_wash_alw_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
        else
        if ( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_oth_inc = Double.parseDouble( inRequest.getParameter("sh_amt_oth_inc_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
        else
        if ( inRequest.getParameter("sh_amt_pf_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_pf = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_pf = Double.parseDouble( inRequest.getParameter("sh_amt_pf_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
        else
        if ( inRequest.getParameter("sh_amt_esi_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_esi = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_esi = Double.parseDouble( inRequest.getParameter("sh_amt_esi_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
        else
        if ( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_swf_ded = Double.parseDouble( inRequest.getParameter("sh_amt_swf_ded_r"+lNumRec));
        if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
        else
        if ( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.sh_amt_oth_ded = Double.parseDouble( inRequest.getParameter("sh_amt_oth_ded_r"+lNumRec));
        if ( inRequest.getParameter("ot_hour_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.ot_hour = 0;
        else
        if ( inRequest.getParameter("ot_hour_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.ot_hour = 0;
        else
            lDmEmployeeMonDtlTabObj.ot_hour = Double.parseDouble( inRequest.getParameter("ot_hour_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_ot_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_ot = 0;
        else
        if ( inRequest.getParameter("act_amt_ot_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_ot = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_ot = Double.parseDouble( inRequest.getParameter("act_amt_ot_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
        else
        if ( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_oth_inc = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_oth_inc = Double.parseDouble( inRequest.getParameter("act_amt_oth_inc_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_adv_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_adv = 0;
        else
        if ( inRequest.getParameter("act_amt_adv_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_adv = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_adv = Double.parseDouble( inRequest.getParameter("act_amt_adv_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_hra_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_hra = 0;
        else
        if ( inRequest.getParameter("act_amt_hra_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_hra = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_hra = Double.parseDouble( inRequest.getParameter("act_amt_hra_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
        else
        if ( inRequest.getParameter("act_amt_weekoff_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_weekoff = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_weekoff = Double.parseDouble( inRequest.getParameter("act_amt_weekoff_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_washing_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_washing = 0;
        else
        if ( inRequest.getParameter("act_amt_washing_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_washing = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_washing = Double.parseDouble( inRequest.getParameter("act_amt_washing_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_areer_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_areer = 0;
        else
        if ( inRequest.getParameter("act_amt_areer_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_areer = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_areer = Double.parseDouble( inRequest.getParameter("act_amt_areer_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
        else
        if ( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_shift_alw = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_shift_alw = Double.parseDouble( inRequest.getParameter("act_amt_shift_alw_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
        else
        if ( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_medi_alw = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_medi_alw = Double.parseDouble( inRequest.getParameter("act_amt_medi_alw_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_convy_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_convy = 0;
        else
        if ( inRequest.getParameter("act_amt_convy_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_convy = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_convy = Double.parseDouble( inRequest.getParameter("act_amt_convy_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_insur_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_insur = 0;
        else
        if ( inRequest.getParameter("act_amt_insur_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_insur = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_insur = Double.parseDouble( inRequest.getParameter("act_amt_insur_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_dress_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_dress = 0;
        else
        if ( inRequest.getParameter("act_amt_dress_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_dress = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_dress = Double.parseDouble( inRequest.getParameter("act_amt_dress_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_swf_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_swf_ded = Double.parseDouble( inRequest.getParameter("act_amt_swf_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
        else
        if ( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_gen_fine = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_gen_fine = Double.parseDouble( inRequest.getParameter("act_amt_gen_fine_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_pc_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_pc = 0;
        else
        if ( inRequest.getParameter("act_amt_pc_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_pc = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_pc = Double.parseDouble( inRequest.getParameter("act_amt_pc_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_sec_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_sec_ded = Double.parseDouble( inRequest.getParameter("act_amt_sec_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_oth_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_oth_ded = Double.parseDouble( inRequest.getParameter("act_amt_oth_ded_r"+lNumRec));
        if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec) == null )
          lDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
        else
        if ( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeMonDtlTabObj.act_amt_adv_ded = 0;
        else
            lDmEmployeeMonDtlTabObj.act_amt_adv_ded = Double.parseDouble( inRequest.getParameter("act_amt_adv_ded_r"+lNumRec));
        lDmEmployeeMonDtlTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        lDmEmployeeMonDtlTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
        outDmEmployeeMonDtlTabObjArr.add( lDmEmployeeMonDtlTabObj);
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeMonDtlRecByRowid
               ( String inRowId
               , DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeMonDtlRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeMonDtlRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeMonDtlTabObj.allocation_date != null && inDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null && inDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null && inDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.file_cre_date != null && inDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE_MON_DTL ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inDmEmployeeMonDtlTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmEmployeeMonDtlTabObj.org_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmEmployeeMonDtlTabObj.customer_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = "+"'"+inDmEmployeeMonDtlTabObj.employee_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = "+"'"+inDmEmployeeMonDtlTabObj.allocation_date+"', ";
      if ( inDmEmployeeMonDtlTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmEmployeeMonDtlTabObj.dept_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmEmployeeMonDtlTabObj.position_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmEmployeeMonDtlTabObj.level_id+"', ";
      if ( inDmEmployeeMonDtlTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inDmEmployeeMonDtlTabObj.name_initials+"', ";
      if ( inDmEmployeeMonDtlTabObj.employee_name != null  )         lSqlStmt = lSqlStmt + "employee_name = "+"'"+inDmEmployeeMonDtlTabObj.employee_name+"', ";
      if ( inDmEmployeeMonDtlTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = "+"'"+inDmEmployeeMonDtlTabObj.emp_track_id+"', ";
             lSqlStmt = lSqlStmt + "month_num = "+inDmEmployeeMonDtlTabObj.month_num+", ";
             lSqlStmt = lSqlStmt + "working_days = "+inDmEmployeeMonDtlTabObj.working_days+", ";
             lSqlStmt = lSqlStmt + "absent_days = "+inDmEmployeeMonDtlTabObj.absent_days+", ";
             lSqlStmt = lSqlStmt + "wages_rate = "+inDmEmployeeMonDtlTabObj.wages_rate+", ";
             lSqlStmt = lSqlStmt + "gross_mon_wages = "+inDmEmployeeMonDtlTabObj.gross_mon_wages+", ";
             lSqlStmt = lSqlStmt + "sh_amt_bas = "+inDmEmployeeMonDtlTabObj.sh_amt_bas+", ";
             lSqlStmt = lSqlStmt + "sh_amt_da = "+inDmEmployeeMonDtlTabObj.sh_amt_da+", ";
             lSqlStmt = lSqlStmt + "sh_amt_hra = "+inDmEmployeeMonDtlTabObj.sh_amt_hra+", ";
             lSqlStmt = lSqlStmt + "sh_amt_conv = "+inDmEmployeeMonDtlTabObj.sh_amt_conv+", ";
             lSqlStmt = lSqlStmt + "sh_amt_woff = "+inDmEmployeeMonDtlTabObj.sh_amt_woff+", ";
             lSqlStmt = lSqlStmt + "sh_amt_shift_alw = "+inDmEmployeeMonDtlTabObj.sh_amt_shift_alw+", ";
             lSqlStmt = lSqlStmt + "sh_amt_wash_alw = "+inDmEmployeeMonDtlTabObj.sh_amt_wash_alw+", ";
             lSqlStmt = lSqlStmt + "sh_amt_oth_inc = "+inDmEmployeeMonDtlTabObj.sh_amt_oth_inc+", ";
             lSqlStmt = lSqlStmt + "sh_amt_pf = "+inDmEmployeeMonDtlTabObj.sh_amt_pf+", ";
             lSqlStmt = lSqlStmt + "sh_amt_esi = "+inDmEmployeeMonDtlTabObj.sh_amt_esi+", ";
             lSqlStmt = lSqlStmt + "sh_amt_swf_ded = "+inDmEmployeeMonDtlTabObj.sh_amt_swf_ded+", ";
             lSqlStmt = lSqlStmt + "sh_amt_oth_ded = "+inDmEmployeeMonDtlTabObj.sh_amt_oth_ded+", ";
             lSqlStmt = lSqlStmt + "ot_hour = "+inDmEmployeeMonDtlTabObj.ot_hour+", ";
             lSqlStmt = lSqlStmt + "act_amt_ot = "+inDmEmployeeMonDtlTabObj.act_amt_ot+", ";
             lSqlStmt = lSqlStmt + "act_amt_oth_inc = "+inDmEmployeeMonDtlTabObj.act_amt_oth_inc+", ";
             lSqlStmt = lSqlStmt + "act_amt_adv = "+inDmEmployeeMonDtlTabObj.act_amt_adv+", ";
             lSqlStmt = lSqlStmt + "act_amt_hra = "+inDmEmployeeMonDtlTabObj.act_amt_hra+", ";
             lSqlStmt = lSqlStmt + "act_amt_weekoff = "+inDmEmployeeMonDtlTabObj.act_amt_weekoff+", ";
             lSqlStmt = lSqlStmt + "act_amt_washing = "+inDmEmployeeMonDtlTabObj.act_amt_washing+", ";
             lSqlStmt = lSqlStmt + "act_amt_areer = "+inDmEmployeeMonDtlTabObj.act_amt_areer+", ";
             lSqlStmt = lSqlStmt + "act_amt_shift_alw = "+inDmEmployeeMonDtlTabObj.act_amt_shift_alw+", ";
             lSqlStmt = lSqlStmt + "act_amt_medi_alw = "+inDmEmployeeMonDtlTabObj.act_amt_medi_alw+", ";
             lSqlStmt = lSqlStmt + "act_amt_convy = "+inDmEmployeeMonDtlTabObj.act_amt_convy+", ";
             lSqlStmt = lSqlStmt + "act_amt_insur = "+inDmEmployeeMonDtlTabObj.act_amt_insur+", ";
             lSqlStmt = lSqlStmt + "act_amt_dress = "+inDmEmployeeMonDtlTabObj.act_amt_dress+", ";
             lSqlStmt = lSqlStmt + "act_amt_swf_ded = "+inDmEmployeeMonDtlTabObj.act_amt_swf_ded+", ";
             lSqlStmt = lSqlStmt + "act_amt_gen_fine = "+inDmEmployeeMonDtlTabObj.act_amt_gen_fine+", ";
             lSqlStmt = lSqlStmt + "act_amt_pc = "+inDmEmployeeMonDtlTabObj.act_amt_pc+", ";
             lSqlStmt = lSqlStmt + "act_amt_sec_ded = "+inDmEmployeeMonDtlTabObj.act_amt_sec_ded+", ";
             lSqlStmt = lSqlStmt + "act_amt_oth_ded = "+inDmEmployeeMonDtlTabObj.act_amt_oth_ded+", ";
             lSqlStmt = lSqlStmt + "act_amt_adv_ded = "+inDmEmployeeMonDtlTabObj.act_amt_adv_ded+", ";
      if ( inDmEmployeeMonDtlTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmEmployeeMonDtlTabObj.rec_status+"', ";
      if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmEmployeeMonDtlTabObj.rec_cre_date+"', ";
      if ( inDmEmployeeMonDtlTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmEmployeeMonDtlTabObj.rec_cre_time+"', ";
      if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmEmployeeMonDtlTabObj.rec_upd_date+"', ";
      if ( inDmEmployeeMonDtlTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmEmployeeMonDtlTabObj.rec_upd_time+"', ";
      if ( inDmEmployeeMonDtlTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmEmployeeMonDtlTabObj.file_name+"', ";
      if ( inDmEmployeeMonDtlTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmEmployeeMonDtlTabObj.file_cre_date+"', ";
      if ( inDmEmployeeMonDtlTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmEmployeeMonDtlTabObj.file_cre_time+"', ";
      if ( inDmEmployeeMonDtlTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmEmployeeMonDtlTabObj.file_status+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeMonDtlRecByPkey
               ( DmEmployeeMonDtlPkeyObj inDmEmployeeMonDtlPkeyObj
               , DmEmployeeMonDtlTabObj  inDmEmployeeMonDtlTabObj
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeMonDtlRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeMonDtlRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeMonDtlTabObj.allocation_date != null && inDmEmployeeMonDtlTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null && inDmEmployeeMonDtlTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null && inDmEmployeeMonDtlTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeMonDtlTabObj.file_cre_date != null && inDmEmployeeMonDtlTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeMonDtlTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeMonDtlTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE_MON_DTL ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inDmEmployeeMonDtlTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = ? , ";
        if ( inDmEmployeeMonDtlTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = ? , ";
        if ( inDmEmployeeMonDtlTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = ? , ";
        if ( inDmEmployeeMonDtlTabObj.employee_name != null  )         lSqlStmt = lSqlStmt + "employee_name = ? , ";
        if ( inDmEmployeeMonDtlTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = ? , ";
               lSqlStmt = lSqlStmt + "month_num = ? , ";
               lSqlStmt = lSqlStmt + "working_days = ? , ";
               lSqlStmt = lSqlStmt + "absent_days = ? , ";
               lSqlStmt = lSqlStmt + "wages_rate = ? , ";
               lSqlStmt = lSqlStmt + "gross_mon_wages = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_bas = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_da = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_hra = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_conv = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_woff = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_shift_alw = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_wash_alw = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_oth_inc = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_pf = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_esi = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_swf_ded = ? , ";
               lSqlStmt = lSqlStmt + "sh_amt_oth_ded = ? , ";
               lSqlStmt = lSqlStmt + "ot_hour = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_ot = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_oth_inc = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_adv = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_hra = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_weekoff = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_washing = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_areer = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_shift_alw = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_medi_alw = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_convy = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_insur = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_dress = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_swf_ded = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_gen_fine = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_pc = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_sec_ded = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_oth_ded = ? , ";
               lSqlStmt = lSqlStmt + "act_amt_adv_ded = ? , ";
        if ( inDmEmployeeMonDtlTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = ? , ";
        if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inDmEmployeeMonDtlTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inDmEmployeeMonDtlTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inDmEmployeeMonDtlTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = ? , ";
        if ( inDmEmployeeMonDtlTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = ? , ";
        if ( inDmEmployeeMonDtlTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = ? , ";
        if ( inDmEmployeeMonDtlTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inDmEmployeeMonDtlTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmEmployeeMonDtlTabObj.org_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmEmployeeMonDtlTabObj.customer_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = "+"'"+inDmEmployeeMonDtlTabObj.employee_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = "+"'"+inDmEmployeeMonDtlTabObj.allocation_date+"', ";
        if ( inDmEmployeeMonDtlTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmEmployeeMonDtlTabObj.dept_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmEmployeeMonDtlTabObj.position_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmEmployeeMonDtlTabObj.level_id+"', ";
        if ( inDmEmployeeMonDtlTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inDmEmployeeMonDtlTabObj.name_initials+"', ";
        if ( inDmEmployeeMonDtlTabObj.employee_name != null  )         lSqlStmt = lSqlStmt + "employee_name = "+"'"+inDmEmployeeMonDtlTabObj.employee_name+"', ";
        if ( inDmEmployeeMonDtlTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = "+"'"+inDmEmployeeMonDtlTabObj.emp_track_id+"', ";
               lSqlStmt = lSqlStmt + "month_num = "+inDmEmployeeMonDtlTabObj.month_num+", ";
               lSqlStmt = lSqlStmt + "working_days = "+inDmEmployeeMonDtlTabObj.working_days+", ";
               lSqlStmt = lSqlStmt + "absent_days = "+inDmEmployeeMonDtlTabObj.absent_days+", ";
               lSqlStmt = lSqlStmt + "wages_rate = "+inDmEmployeeMonDtlTabObj.wages_rate+", ";
               lSqlStmt = lSqlStmt + "gross_mon_wages = "+inDmEmployeeMonDtlTabObj.gross_mon_wages+", ";
               lSqlStmt = lSqlStmt + "sh_amt_bas = "+inDmEmployeeMonDtlTabObj.sh_amt_bas+", ";
               lSqlStmt = lSqlStmt + "sh_amt_da = "+inDmEmployeeMonDtlTabObj.sh_amt_da+", ";
               lSqlStmt = lSqlStmt + "sh_amt_hra = "+inDmEmployeeMonDtlTabObj.sh_amt_hra+", ";
               lSqlStmt = lSqlStmt + "sh_amt_conv = "+inDmEmployeeMonDtlTabObj.sh_amt_conv+", ";
               lSqlStmt = lSqlStmt + "sh_amt_woff = "+inDmEmployeeMonDtlTabObj.sh_amt_woff+", ";
               lSqlStmt = lSqlStmt + "sh_amt_shift_alw = "+inDmEmployeeMonDtlTabObj.sh_amt_shift_alw+", ";
               lSqlStmt = lSqlStmt + "sh_amt_wash_alw = "+inDmEmployeeMonDtlTabObj.sh_amt_wash_alw+", ";
               lSqlStmt = lSqlStmt + "sh_amt_oth_inc = "+inDmEmployeeMonDtlTabObj.sh_amt_oth_inc+", ";
               lSqlStmt = lSqlStmt + "sh_amt_pf = "+inDmEmployeeMonDtlTabObj.sh_amt_pf+", ";
               lSqlStmt = lSqlStmt + "sh_amt_esi = "+inDmEmployeeMonDtlTabObj.sh_amt_esi+", ";
               lSqlStmt = lSqlStmt + "sh_amt_swf_ded = "+inDmEmployeeMonDtlTabObj.sh_amt_swf_ded+", ";
               lSqlStmt = lSqlStmt + "sh_amt_oth_ded = "+inDmEmployeeMonDtlTabObj.sh_amt_oth_ded+", ";
               lSqlStmt = lSqlStmt + "ot_hour = "+inDmEmployeeMonDtlTabObj.ot_hour+", ";
               lSqlStmt = lSqlStmt + "act_amt_ot = "+inDmEmployeeMonDtlTabObj.act_amt_ot+", ";
               lSqlStmt = lSqlStmt + "act_amt_oth_inc = "+inDmEmployeeMonDtlTabObj.act_amt_oth_inc+", ";
               lSqlStmt = lSqlStmt + "act_amt_adv = "+inDmEmployeeMonDtlTabObj.act_amt_adv+", ";
               lSqlStmt = lSqlStmt + "act_amt_hra = "+inDmEmployeeMonDtlTabObj.act_amt_hra+", ";
               lSqlStmt = lSqlStmt + "act_amt_weekoff = "+inDmEmployeeMonDtlTabObj.act_amt_weekoff+", ";
               lSqlStmt = lSqlStmt + "act_amt_washing = "+inDmEmployeeMonDtlTabObj.act_amt_washing+", ";
               lSqlStmt = lSqlStmt + "act_amt_areer = "+inDmEmployeeMonDtlTabObj.act_amt_areer+", ";
               lSqlStmt = lSqlStmt + "act_amt_shift_alw = "+inDmEmployeeMonDtlTabObj.act_amt_shift_alw+", ";
               lSqlStmt = lSqlStmt + "act_amt_medi_alw = "+inDmEmployeeMonDtlTabObj.act_amt_medi_alw+", ";
               lSqlStmt = lSqlStmt + "act_amt_convy = "+inDmEmployeeMonDtlTabObj.act_amt_convy+", ";
               lSqlStmt = lSqlStmt + "act_amt_insur = "+inDmEmployeeMonDtlTabObj.act_amt_insur+", ";
               lSqlStmt = lSqlStmt + "act_amt_dress = "+inDmEmployeeMonDtlTabObj.act_amt_dress+", ";
               lSqlStmt = lSqlStmt + "act_amt_swf_ded = "+inDmEmployeeMonDtlTabObj.act_amt_swf_ded+", ";
               lSqlStmt = lSqlStmt + "act_amt_gen_fine = "+inDmEmployeeMonDtlTabObj.act_amt_gen_fine+", ";
               lSqlStmt = lSqlStmt + "act_amt_pc = "+inDmEmployeeMonDtlTabObj.act_amt_pc+", ";
               lSqlStmt = lSqlStmt + "act_amt_sec_ded = "+inDmEmployeeMonDtlTabObj.act_amt_sec_ded+", ";
               lSqlStmt = lSqlStmt + "act_amt_oth_ded = "+inDmEmployeeMonDtlTabObj.act_amt_oth_ded+", ";
               lSqlStmt = lSqlStmt + "act_amt_adv_ded = "+inDmEmployeeMonDtlTabObj.act_amt_adv_ded+", ";
        if ( inDmEmployeeMonDtlTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmEmployeeMonDtlTabObj.rec_status+"', ";
        if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmEmployeeMonDtlTabObj.rec_cre_date+"', ";
        if ( inDmEmployeeMonDtlTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmEmployeeMonDtlTabObj.rec_cre_time+"', ";
        if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmEmployeeMonDtlTabObj.rec_upd_date+"', ";
        if ( inDmEmployeeMonDtlTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmEmployeeMonDtlTabObj.rec_upd_time+"', ";
        if ( inDmEmployeeMonDtlTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmEmployeeMonDtlTabObj.file_name+"', ";
        if ( inDmEmployeeMonDtlTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmEmployeeMonDtlTabObj.file_cre_date+"', ";
        if ( inDmEmployeeMonDtlTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmEmployeeMonDtlTabObj.file_cre_time+"', ";
        if ( inDmEmployeeMonDtlTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmEmployeeMonDtlTabObj.file_status+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeeMonDtlPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeeMonDtlPkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeeMonDtlPkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeeMonDtlPkeyObj.allocation_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inDmEmployeeMonDtlTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.org_id); } 
         if ( inDmEmployeeMonDtlTabObj.customer_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.customer_id); } 
         if ( inDmEmployeeMonDtlTabObj.employee_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.employee_id); } 
         if ( inDmEmployeeMonDtlTabObj.allocation_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.allocation_date); } 
         if ( inDmEmployeeMonDtlTabObj.dept_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.dept_id); } 
         if ( inDmEmployeeMonDtlTabObj.position_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.position_id); } 
         if ( inDmEmployeeMonDtlTabObj.level_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.level_id); } 
         if ( inDmEmployeeMonDtlTabObj.name_initials != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.name_initials); } 
         if ( inDmEmployeeMonDtlTabObj.employee_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.employee_name); } 
         if ( inDmEmployeeMonDtlTabObj.emp_track_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.emp_track_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(11, inDmEmployeeMonDtlTabObj.month_num);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(12, inDmEmployeeMonDtlTabObj.working_days);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(13, inDmEmployeeMonDtlTabObj.absent_days);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(14, inDmEmployeeMonDtlTabObj.wages_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(15, inDmEmployeeMonDtlTabObj.gross_mon_wages);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(16, inDmEmployeeMonDtlTabObj.sh_amt_bas);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(17, inDmEmployeeMonDtlTabObj.sh_amt_da);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(18, inDmEmployeeMonDtlTabObj.sh_amt_hra);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(19, inDmEmployeeMonDtlTabObj.sh_amt_conv);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(20, inDmEmployeeMonDtlTabObj.sh_amt_woff);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(21, inDmEmployeeMonDtlTabObj.sh_amt_shift_alw);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(22, inDmEmployeeMonDtlTabObj.sh_amt_wash_alw);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(23, inDmEmployeeMonDtlTabObj.sh_amt_oth_inc);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(24, inDmEmployeeMonDtlTabObj.sh_amt_pf);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(25, inDmEmployeeMonDtlTabObj.sh_amt_esi);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(26, inDmEmployeeMonDtlTabObj.sh_amt_swf_ded);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(27, inDmEmployeeMonDtlTabObj.sh_amt_oth_ded);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(28, inDmEmployeeMonDtlTabObj.ot_hour);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(29, inDmEmployeeMonDtlTabObj.act_amt_ot);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(30, inDmEmployeeMonDtlTabObj.act_amt_oth_inc);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(31, inDmEmployeeMonDtlTabObj.act_amt_adv);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(32, inDmEmployeeMonDtlTabObj.act_amt_hra);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(33, inDmEmployeeMonDtlTabObj.act_amt_weekoff);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(34, inDmEmployeeMonDtlTabObj.act_amt_washing);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(35, inDmEmployeeMonDtlTabObj.act_amt_areer);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(36, inDmEmployeeMonDtlTabObj.act_amt_shift_alw);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(37, inDmEmployeeMonDtlTabObj.act_amt_medi_alw);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(38, inDmEmployeeMonDtlTabObj.act_amt_convy);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(39, inDmEmployeeMonDtlTabObj.act_amt_insur);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(40, inDmEmployeeMonDtlTabObj.act_amt_dress);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(41, inDmEmployeeMonDtlTabObj.act_amt_swf_ded);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(42, inDmEmployeeMonDtlTabObj.act_amt_gen_fine);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(43, inDmEmployeeMonDtlTabObj.act_amt_pc);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(44, inDmEmployeeMonDtlTabObj.act_amt_sec_ded);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(45, inDmEmployeeMonDtlTabObj.act_amt_oth_ded);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(46, inDmEmployeeMonDtlTabObj.act_amt_adv_ded);
         if ( inDmEmployeeMonDtlTabObj.rec_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.rec_status); } 
         if ( inDmEmployeeMonDtlTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.rec_cre_date); } 
         if ( inDmEmployeeMonDtlTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.rec_cre_time); } 
         if ( inDmEmployeeMonDtlTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.rec_upd_date); } 
         if ( inDmEmployeeMonDtlTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.rec_upd_time); } 
         if ( inDmEmployeeMonDtlTabObj.file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.file_name); } 
         if ( inDmEmployeeMonDtlTabObj.file_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.file_cre_date); } 
         if ( inDmEmployeeMonDtlTabObj.file_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.file_cre_time); } 
         if ( inDmEmployeeMonDtlTabObj.file_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeMonDtlTabObj.file_status); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeMonDtlRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeMonDtlRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeMonDtlRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   DM_EMPLOYEE_MON_DTL "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeMonDtlRecByPkeyWithSet
               ( DmEmployeeMonDtlPkeyObj inDmEmployeeMonDtlPkeyObj
               , String  inDmEmployeeMonDtlSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeMonDtlRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeMonDtlRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE_MON_DTL ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmEmployeeMonDtlSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeeMonDtlPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeeMonDtlPkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeeMonDtlPkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeeMonDtlPkeyObj.allocation_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeMonDtlRecByRowidWithSet
               ( String inRowId
               , String  inDmEmployeeMonDtlSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeMonDtlRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeMonDtlRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE_MON_DTL ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmEmployeeMonDtlSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeMonDtlRecByWhereWithSet
               ( String inDmEmployeeMonDtlWhereText
               , String  inDmEmployeeMonDtlSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeMonDtlRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeMonDtlRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE_MON_DTL ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inDmEmployeeMonDtlSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeMonDtlRecByPkey
               ( DmEmployeeMonDtlPkeyObj  inDmEmployeeMonDtlPkeyObj
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeMonDtlRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeMonDtlRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   DM_EMPLOYEE_MON_DTL " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeeMonDtlPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeeMonDtlPkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeeMonDtlPkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeeMonDtlPkeyObj.allocation_date+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeMonDtlByWhere
               ( String inDmEmployeeMonDtlWhereText
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeMonDtlByWhere - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeMonDtlByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeMonDtlWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeMonDtlWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   DM_EMPLOYEE_MON_DTL "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
