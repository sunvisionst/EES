package sstdb.dm.DmEmployee;

import sstdb.dm.DmEmployee.DmEmployeeTabObj;
import sstdb.dm.DmEmployee.DmEmployeePkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class DmEmployeeMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public DmEmployeeMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "DmEmployeeMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initDmEmployeeTabObj
               ( 
                 DmEmployeeTabObj  outDmEmployeeTabObj
               )
  {
  
     outDmEmployeeTabObj.org_id = ""; 
     outDmEmployeeTabObj.customer_id = ""; 
     outDmEmployeeTabObj.employee_id = ""; 
     outDmEmployeeTabObj.allocation_date = ""; 
     outDmEmployeeTabObj.name_initials = ""; 
     outDmEmployeeTabObj.employee_f_name = ""; 
     outDmEmployeeTabObj.employee_m_name = ""; 
     outDmEmployeeTabObj.employee_l_name = ""; 
     outDmEmployeeTabObj.employee_short_name = ""; 
     outDmEmployeeTabObj.emp_type = ""; 
     outDmEmployeeTabObj.emp_ctg = ""; 
     outDmEmployeeTabObj.reporting_head_id = ""; 
     outDmEmployeeTabObj.dept_id = ""; 
     outDmEmployeeTabObj.logical_group_id = ""; 
     outDmEmployeeTabObj.position_id = ""; 
     outDmEmployeeTabObj.level_id = ""; 
     outDmEmployeeTabObj.designation = ""; 
     outDmEmployeeTabObj.doj = ""; 
     outDmEmployeeTabObj.dot = ""; 
     outDmEmployeeTabObj.project_id = ""; 
     outDmEmployeeTabObj.shift_code = ""; 
     outDmEmployeeTabObj.cycle_code = ""; 
     outDmEmployeeTabObj.phone = ""; 
     outDmEmployeeTabObj.ext = ""; 
     outDmEmployeeTabObj.email_id = ""; 
     outDmEmployeeTabObj.building_id = ""; 
     outDmEmployeeTabObj.floor_num = ""; 
     outDmEmployeeTabObj.room_num = ""; 
     outDmEmployeeTabObj.cubical_num = ""; 
     outDmEmployeeTabObj.emp_status = ""; 
     outDmEmployeeTabObj.emp_status_date = ""; 
     outDmEmployeeTabObj.emp_agreement_sts = ""; 
     outDmEmployeeTabObj.emp_agreement_sts_date = ""; 
     outDmEmployeeTabObj.country = ""; 
     outDmEmployeeTabObj.recruit_req_id = ""; 
     outDmEmployeeTabObj.work_org_id = ""; 
     outDmEmployeeTabObj.marital_status = ""; 
     outDmEmployeeTabObj.pan_ind = ""; 
     outDmEmployeeTabObj.pf_ind = ""; 
     outDmEmployeeTabObj.esi_ind = ""; 
     outDmEmployeeTabObj.pan_num = ""; 
     outDmEmployeeTabObj.pan_create_date = ""; 
     outDmEmployeeTabObj.epf_act_num = ""; 
     outDmEmployeeTabObj.epf_act_open_dt = ""; 
     outDmEmployeeTabObj.epf_act_close_dt = ""; 
     outDmEmployeeTabObj.prev_epf_act_num = ""; 
     outDmEmployeeTabObj.prev_epf_act_open_dt = ""; 
     outDmEmployeeTabObj.prev_epf_act_close_dt = ""; 
     outDmEmployeeTabObj.esi_num = ""; 
     outDmEmployeeTabObj.esi_act_open_dt = ""; 
     outDmEmployeeTabObj.esi_act_close_dt = ""; 
     outDmEmployeeTabObj.prev_esi_num = ""; 
     outDmEmployeeTabObj.prev_esi_num_open_dt = ""; 
     outDmEmployeeTabObj.prev_esi_num_close_dt = ""; 
     outDmEmployeeTabObj.nss_num = ""; 
     outDmEmployeeTabObj.nss_create_date = ""; 
     outDmEmployeeTabObj.gender = ""; 
     outDmEmployeeTabObj.dob = ""; 
     outDmEmployeeTabObj.birth_city = ""; 
     outDmEmployeeTabObj.birth_country = ""; 
     outDmEmployeeTabObj.barcode = ""; 
     outDmEmployeeTabObj.user_id = ""; 
     outDmEmployeeTabObj.pswd_0 = ""; 
     outDmEmployeeTabObj.relation_type = ""; 
     outDmEmployeeTabObj.relative_name = ""; 
     outDmEmployeeTabObj.applicant_id = ""; 
     outDmEmployeeTabObj.emp_card_id = (int)0; 
     outDmEmployeeTabObj.banker_code = ""; 
     outDmEmployeeTabObj.banker_name = ""; 
     outDmEmployeeTabObj.salary_mode = ""; 
     outDmEmployeeTabObj.pay_card_num = ""; 
     outDmEmployeeTabObj.bank_act_num = ""; 
     outDmEmployeeTabObj.father_name = ""; 
     outDmEmployeeTabObj.mother_name = ""; 
     outDmEmployeeTabObj.spouse_name = ""; 
     outDmEmployeeTabObj.p_address_1 = ""; 
     outDmEmployeeTabObj.p_address_2 = ""; 
     outDmEmployeeTabObj.p_city = ""; 
     outDmEmployeeTabObj.p_state = ""; 
     outDmEmployeeTabObj.p_zip = ""; 
     outDmEmployeeTabObj.p_country = ""; 
     outDmEmployeeTabObj.m_address_1 = ""; 
     outDmEmployeeTabObj.m_address_2 = ""; 
     outDmEmployeeTabObj.m_city = ""; 
     outDmEmployeeTabObj.m_state = ""; 
     outDmEmployeeTabObj.m_zip = ""; 
     outDmEmployeeTabObj.m_country = ""; 
     outDmEmployeeTabObj.hospital_id = ""; 
     outDmEmployeeTabObj.course_id = ""; 
     outDmEmployeeTabObj.course_stream = ""; 
     outDmEmployeeTabObj.emp_track_id = ""; 
     outDmEmployeeTabObj.allocation_sts = ""; 
     outDmEmployeeTabObj.release_date = ""; 
     outDmEmployeeTabObj.rp_id = ""; 
     outDmEmployeeTabObj.billing_rate = (double)0.00; 
     outDmEmployeeTabObj.paying_rate = (double)0.00; 
     outDmEmployeeTabObj.pf_nominee_1 = ""; 
     outDmEmployeeTabObj.pf_nominee_2 = ""; 
     outDmEmployeeTabObj.esi_nominee_1 = ""; 
     outDmEmployeeTabObj.esi_nominee_2 = ""; 
     outDmEmployeeTabObj.pf_nominee_1_percent = (double)0.00; 
     outDmEmployeeTabObj.pf_nominee_2_percent = (double)0.00; 
     outDmEmployeeTabObj.esi_nominee_1_percent = (double)0.00; 
     outDmEmployeeTabObj.esi_nominee_2_percent = (double)0.00; 
     outDmEmployeeTabObj.rec_status = ""; 
     outDmEmployeeTabObj.rec_cre_date = ""; 
     outDmEmployeeTabObj.rec_cre_time = ""; 
     outDmEmployeeTabObj.rec_upd_date = ""; 
     outDmEmployeeTabObj.rec_upd_time = ""; 
     outDmEmployeeTabObj.file_name = ""; 
     outDmEmployeeTabObj.file_cre_date = ""; 
     outDmEmployeeTabObj.file_cre_time = ""; 
     outDmEmployeeTabObj.file_status = ""; 
  }





  public void guiDateConvDmEmployeeTabObj
               ( 
                 DmEmployeeTabObj  inDmEmployeeTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inDmEmployeeTabObj.allocation_date != null && inDmEmployeeTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.doj != null && inDmEmployeeTabObj.doj.length() > 0 ) 
            inDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.doj, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.dot != null && inDmEmployeeTabObj.dot.length() > 0 ) 
            inDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.dot, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.emp_status_date != null && inDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.emp_agreement_sts_date != null && inDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.pan_create_date != null && inDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            inDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.epf_act_open_dt != null && inDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.epf_act_close_dt != null && inDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null && inDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null && inDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.esi_act_open_dt != null && inDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.esi_act_close_dt != null && inDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null && inDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null && inDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.nss_create_date != null && inDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            inDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.dob != null && inDmEmployeeTabObj.dob.length() > 0 ) 
            inDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.dob, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.release_date != null && inDmEmployeeTabObj.release_date.length() > 0 ) 
            inDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.release_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.rec_cre_date != null && inDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.rec_upd_date != null && inDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);

          if ( inDmEmployeeTabObj.file_cre_date != null && inDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
  }





  public void refreshCtxDmEmployeeByTabObj
               ( 
                 DmEmployeeTabObj  inDmEmployeeTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lDmEmployeeTabObjArrCtx  = new ArrayList(); 
    lDmEmployeeTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lDmEmployeeTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lDmEmployeeTabObjArrCtx.add(inDmEmployeeTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lDmEmployeeTabObjArrCtx.size();  lRecNum++ )
      {
        DmEmployeeTabObj lDmEmployeeTabObj = new DmEmployeeTabObj();
        lDmEmployeeTabObj = (DmEmployeeTabObj)lDmEmployeeTabObjArrCtx.get(lRecNum);
    
        if ( 
              lDmEmployeeTabObj.org_id.equals(lDmEmployeeTabObj.org_id) &&
              lDmEmployeeTabObj.customer_id.equals(lDmEmployeeTabObj.customer_id) &&
              lDmEmployeeTabObj.employee_id.equals(lDmEmployeeTabObj.employee_id) &&
              lDmEmployeeTabObj.allocation_date.equals(lDmEmployeeTabObj.allocation_date) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lDmEmployeeTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lDmEmployeeTabObjArrCtx.set(lRecNum, inDmEmployeeTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lDmEmployeeTabObjArrCtx",lDmEmployeeTabObjArrCtx);
  }





  public void sortDmEmployeeTabObjArr
               ( 
                 ArrayList  inDmEmployeeTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lDmEmployeeTabObjArr  = new ArrayList(); 
     lDmEmployeeTabObjArr = inDmEmployeeTabObjArr; 
     List lDmEmployeeTabObjList  = new ArrayList(lDmEmployeeTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lDmEmployeeTabObjArr.size();  lRecNum++ )
     {
       DmEmployeeTabObj  lDmEmployeeTabObj = new DmEmployeeTabObj(); 
       lDmEmployeeTabObj = (DmEmployeeTabObj)lDmEmployeeTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.customer_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.customer_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.employee_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.employee_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allocation_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.allocation_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.allocation_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("name_initials") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.name_initials.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.name_initials+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_f_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lDmEmployeeTabObj.employee_f_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.employee_f_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_m_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lDmEmployeeTabObj.employee_m_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.employee_m_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_l_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lDmEmployeeTabObj.employee_l_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.employee_l_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_short_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.employee_short_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.employee_short_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.emp_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.emp_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reporting_head_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.reporting_head_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.reporting_head_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dept_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.dept_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.dept_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("logical_group_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.logical_group_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.logical_group_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("position_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.position_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.position_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("level_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.level_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.level_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("doj") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.doj.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.doj+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dot") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.dot.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.dot+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("project_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.project_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.project_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("shift_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.shift_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.shift_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cycle_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - lDmEmployeeTabObj.cycle_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.cycle_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lDmEmployeeTabObj.phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ext") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.ext.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.ext+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.email_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.email_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("building_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.building_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.building_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("floor_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.floor_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.floor_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("room_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.room_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.room_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cubical_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.cubical_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.cubical_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.emp_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_status_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.emp_status_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_status_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_agreement_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.emp_agreement_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_agreement_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_agreement_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.emp_agreement_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_agreement_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("recruit_req_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (15 - lDmEmployeeTabObj.recruit_req_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.recruit_req_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("work_org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.work_org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.work_org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("marital_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmEmployeeTabObj.marital_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.marital_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.pan_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pan_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.pf_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pf_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.esi_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.pan_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pan_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_create_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.pan_create_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pan_create_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("epf_act_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.epf_act_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.epf_act_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("epf_act_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.epf_act_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.epf_act_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("epf_act_close_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.epf_act_close_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.epf_act_close_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_epf_act_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.prev_epf_act_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_epf_act_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_epf_act_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.prev_epf_act_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_epf_act_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_epf_act_close_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.prev_epf_act_close_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_epf_act_close_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.esi_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_act_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.esi_act_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_act_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_act_close_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.esi_act_close_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_act_close_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_esi_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.prev_esi_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_esi_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_esi_num_open_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.prev_esi_num_open_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_esi_num_open_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_esi_num_close_dt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.prev_esi_num_close_dt.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.prev_esi_num_close_dt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("nss_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.nss_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.nss_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("nss_create_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.nss_create_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.nss_create_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gender") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmEmployeeTabObj.gender.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.gender+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dob") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.dob.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.dob+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("birth_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lDmEmployeeTabObj.birth_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.birth_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("birth_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.birth_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.birth_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("barcode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.barcode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.barcode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("user_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.user_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.user_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_0") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (12 - lDmEmployeeTabObj.pswd_0.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pswd_0+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("relation_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmEmployeeTabObj.relation_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.relation_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("relative_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.relative_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.relative_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("applicant_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.applicant_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.applicant_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_card_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmEmployeeTabObj.emp_card_id).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_card_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("banker_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.banker_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.banker_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("banker_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.banker_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.banker_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("salary_mode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.salary_mode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.salary_mode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pay_card_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.pay_card_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pay_card_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bank_act_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.bank_act_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.bank_act_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.father_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.father_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.mother_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.mother_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spouse_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.spouse_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.spouse_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.p_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.p_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.p_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.p_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.p_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.p_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.p_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.m_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmEmployeeTabObj.m_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.m_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.m_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.m_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmEmployeeTabObj.m_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.m_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("hospital_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.hospital_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.hospital_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("emp_track_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmEmployeeTabObj.emp_track_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.emp_track_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allocation_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.allocation_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.allocation_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("release_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.release_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.release_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rp_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.rp_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rp_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("billing_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.billing_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.billing_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("paying_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.paying_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.paying_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_nominee_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.pf_nominee_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pf_nominee_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_nominee_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.pf_nominee_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pf_nominee_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_nominee_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.esi_nominee_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_nominee_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_nominee_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmEmployeeTabObj.esi_nominee_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_nominee_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_nominee_1_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.pf_nominee_1_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pf_nominee_1_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_nominee_2_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.pf_nominee_2_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.pf_nominee_2_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_nominee_1_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.esi_nominee_1_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_nominee_1_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_nominee_2_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmEmployeeTabObj.esi_nominee_2_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.esi_nominee_2_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmEmployeeTabObj.rec_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rec_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lDmEmployeeTabObj.file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmEmployeeTabObj.file_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.file_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmEmployeeTabObj.file_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.file_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmEmployeeTabObj.file_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmEmployeeTabObj.file_status+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lDmEmployeeTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lDmEmployeeTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lDmEmployeeTabObjList ); 
     ArrayList lDmEmployeeTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lDmEmployeeTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lDmEmployeeTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lDmEmployeeTabObjArrSorted.add( (DmEmployeeTabObj)lDmEmployeeTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lDmEmployeeTabObjArr.size();  lRecNum++ )
     {
       inDmEmployeeTabObjArr.set( lRecNum, (DmEmployeeTabObj)lDmEmployeeTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvDmEmployeeTabObj
               ( 
                 DmEmployeeTabObj  inDmEmployeeTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inDmEmployeeTabObj.allocation_date != null && inDmEmployeeTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.doj != null && inDmEmployeeTabObj.doj.length() > 0 ) 
            inDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.doj, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dot != null && inDmEmployeeTabObj.dot.length() > 0 ) 
            inDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dot, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_status_date != null && inDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_status_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_agreement_sts_date != null && inDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.pan_create_date != null && inDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            inDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_open_dt != null && inDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_close_dt != null && inDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null && inDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null && inDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_open_dt != null && inDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_close_dt != null && inDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null && inDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null && inDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.nss_create_date != null && inDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            inDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.nss_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dob != null && inDmEmployeeTabObj.dob.length() > 0 ) 
            inDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dob, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.release_date != null && inDmEmployeeTabObj.release_date.length() > 0 ) 
            inDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.release_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_cre_date != null && inDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_upd_date != null && inDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.file_cre_date != null && inDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.file_cre_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllocationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLOCATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNameInitials
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NAME_INITIALS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeFName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_F_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeMName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_M_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeLName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_L_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeShortName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_SHORT_NAME";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_CTG";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReportingHeadId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REPORTING_HEAD_ID";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDeptId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DEPT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLogicalGroupId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LOGICAL_GROUP_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePositionId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "POSITION_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLevelId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LEVEL_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDoj
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOJ";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDot
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOT";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProjectId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROJECT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShiftCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SHIFT_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCycleCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CYCLE_CODE";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXT";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBuildingId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUILDING_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFloorNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FLOOR_NUM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRoomNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROOM_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCubicalNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUBICAL_NUM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpStatusDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_STATUS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpAgreementSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_AGREEMENT_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpAgreementStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_AGREEMENT_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecruitReqId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 15 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RECRUIT_REQ_ID";
      String lErrorReason = "Size Greater Than 15";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWorkOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WORK_ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMaritalStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MARITAL_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_IND";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_IND";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_IND";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanCreateDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_CREATE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEpfActNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EPF_ACT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEpfActOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EPF_ACT_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEpfActCloseDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EPF_ACT_CLOSE_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEpfActNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_EPF_ACT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEpfActOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_EPF_ACT_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEpfActCloseDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_EPF_ACT_CLOSE_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiActOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_ACT_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiActCloseDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_ACT_CLOSE_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEsiNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ESI_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEsiNumOpenDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ESI_NUM_OPEN_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevEsiNumCloseDt
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ESI_NUM_CLOSE_DT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNssNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NSS_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNssCreateDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NSS_CREATE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGender
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GENDER";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDob
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOB";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBirthCity
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BIRTH_CITY";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBirthCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BIRTH_COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBarcode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BARCODE";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUserId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "USER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd0
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 12 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_0";
      String lErrorReason = "Size Greater Than 12";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRelationType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELATION_TYPE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRelativeName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELATIVE_NAME";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicantId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICANT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpCardId
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_CARD_ID";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankerCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANKER_CODE";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankerName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANKER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSalaryMode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SALARY_MODE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePayCardNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAY_CARD_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankActNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANK_ACT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpouseName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPOUSE_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_COUNTRY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_COUNTRY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHospitalId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HOSPITAL_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmpTrackId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMP_TRACK_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllocationSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLOCATION_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReleaseDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELEASE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRpId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RP_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBillingRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BILLING_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePayingRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAYING_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfNominee1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_NOMINEE_1";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfNominee2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_NOMINEE_2";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNominee1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NOMINEE_1";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNominee2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NOMINEE_2";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfNominee1Percent
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_NOMINEE_1_PERCENT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfNominee2Percent
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_NOMINEE_2_PERCENT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNominee1Percent
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NOMINEE_1_PERCENT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiNominee2Percent
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_NOMINEE_2_PERCENT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtDmEmployeeCount
               ( String inDmEmployeeWhereText
               )
  {
    sop("gtDmEmployeeCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeCount
               ( String inDmEmployeeWhereText
               , String inDmEmployeeSelectFieldList
               )
  {
    sop("gtDmEmployeeCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inDmEmployeeSelectFieldList+" AS count "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeRecByPkey
               ( DmEmployeePkeyObj inDmEmployeePkeyObj
               , DmEmployeeTabObj  outDmEmployeeTabObj
               )
  {
    sop("gtDmEmployeeRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "name_initials, "+
                                 "employee_f_name, "+
                                 "employee_m_name, "+
                                 "employee_l_name, "+
                                 "employee_short_name, "+
                                 "emp_type, "+
                                 "emp_ctg, "+
                                 "reporting_head_id, "+
                                 "dept_id, "+
                                 "logical_group_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "designation, "+
                                 "doj, "+
                                 "dot, "+
                                 "project_id, "+
                                 "shift_code, "+
                                 "cycle_code, "+
                                 "phone, "+
                                 "ext, "+
                                 "email_id, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "cubical_num, "+
                                 "emp_status, "+
                                 "emp_status_date, "+
                                 "emp_agreement_sts, "+
                                 "emp_agreement_sts_date, "+
                                 "country, "+
                                 "recruit_req_id, "+
                                 "work_org_id, "+
                                 "marital_status, "+
                                 "pan_ind, "+
                                 "pf_ind, "+
                                 "esi_ind, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "epf_act_close_dt, "+
                                 "prev_epf_act_num, "+
                                 "prev_epf_act_open_dt, "+
                                 "prev_epf_act_close_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "esi_act_close_dt, "+
                                 "prev_esi_num, "+
                                 "prev_esi_num_open_dt, "+
                                 "prev_esi_num_close_dt, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "gender, "+
                                 "dob, "+
                                 "birth_city, "+
                                 "birth_country, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "relation_type, "+
                                 "relative_name, "+
                                 "applicant_id, "+
                                 "emp_card_id, "+
                                 "banker_code, "+
                                 "banker_name, "+
                                 "salary_mode, "+
                                 "pay_card_num, "+
                                 "bank_act_num, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "spouse_name, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_city, "+
                                 "p_state, "+
                                 "p_zip, "+
                                 "p_country, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_city, "+
                                 "m_state, "+
                                 "m_zip, "+
                                 "m_country, "+
                                 "hospital_id, "+
                                 "course_id, "+
                                 "course_stream, "+
                                 "emp_track_id, "+
                                 "allocation_sts, "+
                                 "release_date, "+
                                 "rp_id, "+
                                 "billing_rate, "+
                                 "paying_rate, "+
                                 "pf_nominee_1, "+
                                 "pf_nominee_2, "+
                                 "esi_nominee_1, "+
                                 "esi_nominee_2, "+
                                 "pf_nominee_1_percent, "+
                                 "pf_nominee_2_percent, "+
                                 "esi_nominee_1_percent, "+
                                 "esi_nominee_2_percent, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeePkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeePkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeePkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeePkeyObj.allocation_date+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outDmEmployeeTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmEmployeeTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmEmployeeTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmEmployeeTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          outDmEmployeeTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( outDmEmployeeTabObj.allocation_date != null && outDmEmployeeTabObj.allocation_date.length() > 0 ) 
            outDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outDmEmployeeTabObj.employee_f_name  =  lResultSet.getString("EMPLOYEE_F_NAME");
          outDmEmployeeTabObj.employee_m_name  =  lResultSet.getString("EMPLOYEE_M_NAME");
          outDmEmployeeTabObj.employee_l_name  =  lResultSet.getString("EMPLOYEE_L_NAME");
          outDmEmployeeTabObj.employee_short_name  =  lResultSet.getString("EMPLOYEE_SHORT_NAME");
          outDmEmployeeTabObj.emp_type  =  lResultSet.getString("EMP_TYPE");
          outDmEmployeeTabObj.emp_ctg  =  lResultSet.getString("EMP_CTG");
          outDmEmployeeTabObj.reporting_head_id  =  lResultSet.getString("REPORTING_HEAD_ID");
          outDmEmployeeTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmEmployeeTabObj.logical_group_id  =  lResultSet.getString("LOGICAL_GROUP_ID");
          outDmEmployeeTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmEmployeeTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmEmployeeTabObj.designation  =  lResultSet.getString("DESIGNATION");
          outDmEmployeeTabObj.doj  =  lResultSet.getString("DOJ");

          if ( outDmEmployeeTabObj.doj != null && outDmEmployeeTabObj.doj.length() > 0 ) 
            outDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.doj, lDateTimeTrgFmt);
          outDmEmployeeTabObj.dot  =  lResultSet.getString("DOT");

          if ( outDmEmployeeTabObj.dot != null && outDmEmployeeTabObj.dot.length() > 0 ) 
            outDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.dot, lDateTimeTrgFmt);
          outDmEmployeeTabObj.project_id  =  lResultSet.getString("PROJECT_ID");
          outDmEmployeeTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          outDmEmployeeTabObj.cycle_code  =  lResultSet.getString("CYCLE_CODE");
          outDmEmployeeTabObj.phone  =  lResultSet.getString("PHONE");
          outDmEmployeeTabObj.ext  =  lResultSet.getString("EXT");
          outDmEmployeeTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outDmEmployeeTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outDmEmployeeTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outDmEmployeeTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outDmEmployeeTabObj.cubical_num  =  lResultSet.getString("CUBICAL_NUM");
          outDmEmployeeTabObj.emp_status  =  lResultSet.getString("EMP_STATUS");
          outDmEmployeeTabObj.emp_status_date  =  lResultSet.getString("EMP_STATUS_DATE");

          if ( outDmEmployeeTabObj.emp_status_date != null && outDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            outDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.emp_agreement_sts  =  lResultSet.getString("EMP_AGREEMENT_STS");
          outDmEmployeeTabObj.emp_agreement_sts_date  =  lResultSet.getString("EMP_AGREEMENT_STS_DATE");

          if ( outDmEmployeeTabObj.emp_agreement_sts_date != null && outDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            outDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.country  =  lResultSet.getString("COUNTRY");
          outDmEmployeeTabObj.recruit_req_id  =  lResultSet.getString("RECRUIT_REQ_ID");
          outDmEmployeeTabObj.work_org_id  =  lResultSet.getString("WORK_ORG_ID");
          outDmEmployeeTabObj.marital_status  =  lResultSet.getString("MARITAL_STATUS");
          outDmEmployeeTabObj.pan_ind  =  lResultSet.getString("PAN_IND");
          outDmEmployeeTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          outDmEmployeeTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          outDmEmployeeTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outDmEmployeeTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( outDmEmployeeTabObj.pan_create_date != null && outDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            outDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          outDmEmployeeTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.epf_act_open_dt != null && outDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.epf_act_close_dt  =  lResultSet.getString("EPF_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.epf_act_close_dt != null && outDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_epf_act_num  =  lResultSet.getString("PREV_EPF_ACT_NUM");
          outDmEmployeeTabObj.prev_epf_act_open_dt  =  lResultSet.getString("PREV_EPF_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.prev_epf_act_open_dt != null && outDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_epf_act_close_dt  =  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.prev_epf_act_close_dt != null && outDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          outDmEmployeeTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.esi_act_open_dt != null && outDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.esi_act_close_dt  =  lResultSet.getString("ESI_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.esi_act_close_dt != null && outDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_esi_num  =  lResultSet.getString("PREV_ESI_NUM");
          outDmEmployeeTabObj.prev_esi_num_open_dt  =  lResultSet.getString("PREV_ESI_NUM_OPEN_DT");

          if ( outDmEmployeeTabObj.prev_esi_num_open_dt != null && outDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_esi_num_close_dt  =  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT");

          if ( outDmEmployeeTabObj.prev_esi_num_close_dt != null && outDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          outDmEmployeeTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( outDmEmployeeTabObj.nss_create_date != null && outDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            outDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.gender  =  lResultSet.getString("GENDER");
          outDmEmployeeTabObj.dob  =  lResultSet.getString("DOB");

          if ( outDmEmployeeTabObj.dob != null && outDmEmployeeTabObj.dob.length() > 0 ) 
            outDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.dob, lDateTimeTrgFmt);
          outDmEmployeeTabObj.birth_city  =  lResultSet.getString("BIRTH_CITY");
          outDmEmployeeTabObj.birth_country  =  lResultSet.getString("BIRTH_COUNTRY");
          outDmEmployeeTabObj.barcode  =  lResultSet.getString("BARCODE");
          outDmEmployeeTabObj.user_id  =  lResultSet.getString("USER_ID");
          outDmEmployeeTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outDmEmployeeTabObj.relation_type  =  lResultSet.getString("RELATION_TYPE");
          outDmEmployeeTabObj.relative_name  =  lResultSet.getString("RELATIVE_NAME");
          outDmEmployeeTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outDmEmployeeTabObj.emp_card_id  =  lResultSet.getInt("EMP_CARD_ID");
          outDmEmployeeTabObj.banker_code  =  lResultSet.getString("BANKER_CODE");
          outDmEmployeeTabObj.banker_name  =  lResultSet.getString("BANKER_NAME");
          outDmEmployeeTabObj.salary_mode  =  lResultSet.getString("SALARY_MODE");
          outDmEmployeeTabObj.pay_card_num  =  lResultSet.getString("PAY_CARD_NUM");
          outDmEmployeeTabObj.bank_act_num  =  lResultSet.getString("BANK_ACT_NUM");
          outDmEmployeeTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outDmEmployeeTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outDmEmployeeTabObj.spouse_name  =  lResultSet.getString("SPOUSE_NAME");
          outDmEmployeeTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outDmEmployeeTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outDmEmployeeTabObj.p_city  =  lResultSet.getString("P_CITY");
          outDmEmployeeTabObj.p_state  =  lResultSet.getString("P_STATE");
          outDmEmployeeTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outDmEmployeeTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outDmEmployeeTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outDmEmployeeTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outDmEmployeeTabObj.m_city  =  lResultSet.getString("M_CITY");
          outDmEmployeeTabObj.m_state  =  lResultSet.getString("M_STATE");
          outDmEmployeeTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outDmEmployeeTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outDmEmployeeTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          outDmEmployeeTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outDmEmployeeTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outDmEmployeeTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          outDmEmployeeTabObj.allocation_sts  =  lResultSet.getString("ALLOCATION_STS");
          outDmEmployeeTabObj.release_date  =  lResultSet.getString("RELEASE_DATE");

          if ( outDmEmployeeTabObj.release_date != null && outDmEmployeeTabObj.release_date.length() > 0 ) 
            outDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.release_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rp_id  =  lResultSet.getString("RP_ID");
          outDmEmployeeTabObj.billing_rate  =  lResultSet.getDouble("BILLING_RATE");
          outDmEmployeeTabObj.paying_rate  =  lResultSet.getDouble("PAYING_RATE");
          outDmEmployeeTabObj.pf_nominee_1  =  lResultSet.getString("PF_NOMINEE_1");
          outDmEmployeeTabObj.pf_nominee_2  =  lResultSet.getString("PF_NOMINEE_2");
          outDmEmployeeTabObj.esi_nominee_1  =  lResultSet.getString("ESI_NOMINEE_1");
          outDmEmployeeTabObj.esi_nominee_2  =  lResultSet.getString("ESI_NOMINEE_2");
          outDmEmployeeTabObj.pf_nominee_1_percent  =  lResultSet.getDouble("PF_NOMINEE_1_PERCENT");
          outDmEmployeeTabObj.pf_nominee_2_percent  =  lResultSet.getDouble("PF_NOMINEE_2_PERCENT");
          outDmEmployeeTabObj.esi_nominee_1_percent  =  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT");
          outDmEmployeeTabObj.esi_nominee_2_percent  =  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT");
          outDmEmployeeTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmEmployeeTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmEmployeeTabObj.rec_cre_date != null && outDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            outDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmEmployeeTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmEmployeeTabObj.rec_upd_date != null && outDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            outDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmEmployeeTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmEmployeeTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmEmployeeTabObj.file_cre_date != null && outDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            outDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmEmployeeTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmEmployeeTabObj( outDmEmployeeTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeArr
               ( DmEmployeePkeyObj inDmEmployeePkeyObj
               , ArrayList  outDmEmployeeTabObjArr
               )
  {
    sop("gtDmEmployeeArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "name_initials, "+
                                 "employee_f_name, "+
                                 "employee_m_name, "+
                                 "employee_l_name, "+
                                 "employee_short_name, "+
                                 "emp_type, "+
                                 "emp_ctg, "+
                                 "reporting_head_id, "+
                                 "dept_id, "+
                                 "logical_group_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "designation, "+
                                 "doj, "+
                                 "dot, "+
                                 "project_id, "+
                                 "shift_code, "+
                                 "cycle_code, "+
                                 "phone, "+
                                 "ext, "+
                                 "email_id, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "cubical_num, "+
                                 "emp_status, "+
                                 "emp_status_date, "+
                                 "emp_agreement_sts, "+
                                 "emp_agreement_sts_date, "+
                                 "country, "+
                                 "recruit_req_id, "+
                                 "work_org_id, "+
                                 "marital_status, "+
                                 "pan_ind, "+
                                 "pf_ind, "+
                                 "esi_ind, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "epf_act_close_dt, "+
                                 "prev_epf_act_num, "+
                                 "prev_epf_act_open_dt, "+
                                 "prev_epf_act_close_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "esi_act_close_dt, "+
                                 "prev_esi_num, "+
                                 "prev_esi_num_open_dt, "+
                                 "prev_esi_num_close_dt, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "gender, "+
                                 "dob, "+
                                 "birth_city, "+
                                 "birth_country, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "relation_type, "+
                                 "relative_name, "+
                                 "applicant_id, "+
                                 "emp_card_id, "+
                                 "banker_code, "+
                                 "banker_name, "+
                                 "salary_mode, "+
                                 "pay_card_num, "+
                                 "bank_act_num, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "spouse_name, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_city, "+
                                 "p_state, "+
                                 "p_zip, "+
                                 "p_country, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_city, "+
                                 "m_state, "+
                                 "m_zip, "+
                                 "m_country, "+
                                 "hospital_id, "+
                                 "course_id, "+
                                 "course_stream, "+
                                 "emp_track_id, "+
                                 "allocation_sts, "+
                                 "release_date, "+
                                 "rp_id, "+
                                 "billing_rate, "+
                                 "paying_rate, "+
                                 "pf_nominee_1, "+
                                 "pf_nominee_2, "+
                                 "esi_nominee_1, "+
                                 "esi_nominee_2, "+
                                 "pf_nominee_1_percent, "+
                                 "pf_nominee_2_percent, "+
                                 "esi_nominee_1_percent, "+
                                 "esi_nominee_2_percent, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmEmployeeTabObj  lDmEmployeeTabObj = new DmEmployeeTabObj();
          lDmEmployeeTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lDmEmployeeTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmEmployeeTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmEmployeeTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          lDmEmployeeTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( lDmEmployeeTabObj.allocation_date != null && lDmEmployeeTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lDmEmployeeTabObj.employee_f_name  =  lResultSet.getString("EMPLOYEE_F_NAME");
          lDmEmployeeTabObj.employee_m_name  =  lResultSet.getString("EMPLOYEE_M_NAME");
          lDmEmployeeTabObj.employee_l_name  =  lResultSet.getString("EMPLOYEE_L_NAME");
          lDmEmployeeTabObj.employee_short_name  =  lResultSet.getString("EMPLOYEE_SHORT_NAME");
          lDmEmployeeTabObj.emp_type  =  lResultSet.getString("EMP_TYPE");
          lDmEmployeeTabObj.emp_ctg  =  lResultSet.getString("EMP_CTG");
          lDmEmployeeTabObj.reporting_head_id  =  lResultSet.getString("REPORTING_HEAD_ID");
          lDmEmployeeTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmEmployeeTabObj.logical_group_id  =  lResultSet.getString("LOGICAL_GROUP_ID");
          lDmEmployeeTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmEmployeeTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmEmployeeTabObj.designation  =  lResultSet.getString("DESIGNATION");
          lDmEmployeeTabObj.doj  =  lResultSet.getString("DOJ");

          if ( lDmEmployeeTabObj.doj != null && lDmEmployeeTabObj.doj.length() > 0 ) 
            lDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.doj, lDateTimeTrgFmt);
          lDmEmployeeTabObj.dot  =  lResultSet.getString("DOT");

          if ( lDmEmployeeTabObj.dot != null && lDmEmployeeTabObj.dot.length() > 0 ) 
            lDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dot, lDateTimeTrgFmt);
          lDmEmployeeTabObj.project_id  =  lResultSet.getString("PROJECT_ID");
          lDmEmployeeTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          lDmEmployeeTabObj.cycle_code  =  lResultSet.getString("CYCLE_CODE");
          lDmEmployeeTabObj.phone  =  lResultSet.getString("PHONE");
          lDmEmployeeTabObj.ext  =  lResultSet.getString("EXT");
          lDmEmployeeTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lDmEmployeeTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lDmEmployeeTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lDmEmployeeTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lDmEmployeeTabObj.cubical_num  =  lResultSet.getString("CUBICAL_NUM");
          lDmEmployeeTabObj.emp_status  =  lResultSet.getString("EMP_STATUS");
          lDmEmployeeTabObj.emp_status_date  =  lResultSet.getString("EMP_STATUS_DATE");

          if ( lDmEmployeeTabObj.emp_status_date != null && lDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.emp_agreement_sts  =  lResultSet.getString("EMP_AGREEMENT_STS");
          lDmEmployeeTabObj.emp_agreement_sts_date  =  lResultSet.getString("EMP_AGREEMENT_STS_DATE");

          if ( lDmEmployeeTabObj.emp_agreement_sts_date != null && lDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.country  =  lResultSet.getString("COUNTRY");
          lDmEmployeeTabObj.recruit_req_id  =  lResultSet.getString("RECRUIT_REQ_ID");
          lDmEmployeeTabObj.work_org_id  =  lResultSet.getString("WORK_ORG_ID");
          lDmEmployeeTabObj.marital_status  =  lResultSet.getString("MARITAL_STATUS");
          lDmEmployeeTabObj.pan_ind  =  lResultSet.getString("PAN_IND");
          lDmEmployeeTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          lDmEmployeeTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          lDmEmployeeTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lDmEmployeeTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( lDmEmployeeTabObj.pan_create_date != null && lDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            lDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          lDmEmployeeTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.epf_act_open_dt != null && lDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.epf_act_close_dt  =  lResultSet.getString("EPF_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.epf_act_close_dt != null && lDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_epf_act_num  =  lResultSet.getString("PREV_EPF_ACT_NUM");
          lDmEmployeeTabObj.prev_epf_act_open_dt  =  lResultSet.getString("PREV_EPF_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.prev_epf_act_open_dt != null && lDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_epf_act_close_dt  =  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.prev_epf_act_close_dt != null && lDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          lDmEmployeeTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.esi_act_open_dt != null && lDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.esi_act_close_dt  =  lResultSet.getString("ESI_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.esi_act_close_dt != null && lDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_esi_num  =  lResultSet.getString("PREV_ESI_NUM");
          lDmEmployeeTabObj.prev_esi_num_open_dt  =  lResultSet.getString("PREV_ESI_NUM_OPEN_DT");

          if ( lDmEmployeeTabObj.prev_esi_num_open_dt != null && lDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_esi_num_close_dt  =  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT");

          if ( lDmEmployeeTabObj.prev_esi_num_close_dt != null && lDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          lDmEmployeeTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( lDmEmployeeTabObj.nss_create_date != null && lDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            lDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.gender  =  lResultSet.getString("GENDER");
          lDmEmployeeTabObj.dob  =  lResultSet.getString("DOB");

          if ( lDmEmployeeTabObj.dob != null && lDmEmployeeTabObj.dob.length() > 0 ) 
            lDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dob, lDateTimeTrgFmt);
          lDmEmployeeTabObj.birth_city  =  lResultSet.getString("BIRTH_CITY");
          lDmEmployeeTabObj.birth_country  =  lResultSet.getString("BIRTH_COUNTRY");
          lDmEmployeeTabObj.barcode  =  lResultSet.getString("BARCODE");
          lDmEmployeeTabObj.user_id  =  lResultSet.getString("USER_ID");
          lDmEmployeeTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lDmEmployeeTabObj.relation_type  =  lResultSet.getString("RELATION_TYPE");
          lDmEmployeeTabObj.relative_name  =  lResultSet.getString("RELATIVE_NAME");
          lDmEmployeeTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lDmEmployeeTabObj.emp_card_id  =  lResultSet.getInt("EMP_CARD_ID");
          lDmEmployeeTabObj.banker_code  =  lResultSet.getString("BANKER_CODE");
          lDmEmployeeTabObj.banker_name  =  lResultSet.getString("BANKER_NAME");
          lDmEmployeeTabObj.salary_mode  =  lResultSet.getString("SALARY_MODE");
          lDmEmployeeTabObj.pay_card_num  =  lResultSet.getString("PAY_CARD_NUM");
          lDmEmployeeTabObj.bank_act_num  =  lResultSet.getString("BANK_ACT_NUM");
          lDmEmployeeTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lDmEmployeeTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lDmEmployeeTabObj.spouse_name  =  lResultSet.getString("SPOUSE_NAME");
          lDmEmployeeTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lDmEmployeeTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lDmEmployeeTabObj.p_city  =  lResultSet.getString("P_CITY");
          lDmEmployeeTabObj.p_state  =  lResultSet.getString("P_STATE");
          lDmEmployeeTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lDmEmployeeTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lDmEmployeeTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lDmEmployeeTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lDmEmployeeTabObj.m_city  =  lResultSet.getString("M_CITY");
          lDmEmployeeTabObj.m_state  =  lResultSet.getString("M_STATE");
          lDmEmployeeTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lDmEmployeeTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lDmEmployeeTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          lDmEmployeeTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lDmEmployeeTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lDmEmployeeTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          lDmEmployeeTabObj.allocation_sts  =  lResultSet.getString("ALLOCATION_STS");
          lDmEmployeeTabObj.release_date  =  lResultSet.getString("RELEASE_DATE");

          if ( lDmEmployeeTabObj.release_date != null && lDmEmployeeTabObj.release_date.length() > 0 ) 
            lDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.release_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rp_id  =  lResultSet.getString("RP_ID");
          lDmEmployeeTabObj.billing_rate  =  lResultSet.getDouble("BILLING_RATE");
          lDmEmployeeTabObj.paying_rate  =  lResultSet.getDouble("PAYING_RATE");
          lDmEmployeeTabObj.pf_nominee_1  =  lResultSet.getString("PF_NOMINEE_1");
          lDmEmployeeTabObj.pf_nominee_2  =  lResultSet.getString("PF_NOMINEE_2");
          lDmEmployeeTabObj.esi_nominee_1  =  lResultSet.getString("ESI_NOMINEE_1");
          lDmEmployeeTabObj.esi_nominee_2  =  lResultSet.getString("ESI_NOMINEE_2");
          lDmEmployeeTabObj.pf_nominee_1_percent  =  lResultSet.getDouble("PF_NOMINEE_1_PERCENT");
          lDmEmployeeTabObj.pf_nominee_2_percent  =  lResultSet.getDouble("PF_NOMINEE_2_PERCENT");
          lDmEmployeeTabObj.esi_nominee_1_percent  =  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT");
          lDmEmployeeTabObj.esi_nominee_2_percent  =  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT");
          lDmEmployeeTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmEmployeeTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmEmployeeTabObj.rec_cre_date != null && lDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmEmployeeTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmEmployeeTabObj.rec_upd_date != null && lDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmEmployeeTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmEmployeeTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmEmployeeTabObj.file_cre_date != null && lDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmEmployeeTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmEmployeeTabObj( lDmEmployeeTabObj );

          outDmEmployeeTabObjArr.add(  lDmEmployeeTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeTabObjArr != null && outDmEmployeeTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtDmEmployeeArr2XML
               ( String inDmEmployeeWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtDmEmployeeArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<DmEmployee>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_id") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_ID>" +  lResultSet.getString("CUSTOMER_ID") +   "</CUSTOMER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_id") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_ID>" +  lResultSet.getString("EMPLOYEE_ID") +   "</EMPLOYEE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allocation_date") )
              lXmlBuffer = lXmlBuffer +   "<ALLOCATION_DATE>" +  lResultSet.getString("ALLOCATION_DATE") +   "</ALLOCATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("name_initials") )
              lXmlBuffer = lXmlBuffer +   "<NAME_INITIALS>" +  lResultSet.getString("NAME_INITIALS") +   "</NAME_INITIALS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_f_name") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_F_NAME>" +  lResultSet.getString("EMPLOYEE_F_NAME") +   "</EMPLOYEE_F_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_m_name") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_M_NAME>" +  lResultSet.getString("EMPLOYEE_M_NAME") +   "</EMPLOYEE_M_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_l_name") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_L_NAME>" +  lResultSet.getString("EMPLOYEE_L_NAME") +   "</EMPLOYEE_L_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_short_name") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_SHORT_NAME>" +  lResultSet.getString("EMPLOYEE_SHORT_NAME") +   "</EMPLOYEE_SHORT_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_type") )
              lXmlBuffer = lXmlBuffer +   "<EMP_TYPE>" +  lResultSet.getString("EMP_TYPE") +   "</EMP_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_ctg") )
              lXmlBuffer = lXmlBuffer +   "<EMP_CTG>" +  lResultSet.getString("EMP_CTG") +   "</EMP_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reporting_head_id") )
              lXmlBuffer = lXmlBuffer +   "<REPORTING_HEAD_ID>" +  lResultSet.getString("REPORTING_HEAD_ID") +   "</REPORTING_HEAD_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dept_id") )
              lXmlBuffer = lXmlBuffer +   "<DEPT_ID>" +  lResultSet.getString("DEPT_ID") +   "</DEPT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("logical_group_id") )
              lXmlBuffer = lXmlBuffer +   "<LOGICAL_GROUP_ID>" +  lResultSet.getString("LOGICAL_GROUP_ID") +   "</LOGICAL_GROUP_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("position_id") )
              lXmlBuffer = lXmlBuffer +   "<POSITION_ID>" +  lResultSet.getString("POSITION_ID") +   "</POSITION_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("level_id") )
              lXmlBuffer = lXmlBuffer +   "<LEVEL_ID>" +  lResultSet.getString("LEVEL_ID") +   "</LEVEL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("designation") )
              lXmlBuffer = lXmlBuffer +   "<DESIGNATION>" +  lResultSet.getString("DESIGNATION") +   "</DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("doj") )
              lXmlBuffer = lXmlBuffer +   "<DOJ>" +  lResultSet.getString("DOJ") +   "</DOJ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dot") )
              lXmlBuffer = lXmlBuffer +   "<DOT>" +  lResultSet.getString("DOT") +   "</DOT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("project_id") )
              lXmlBuffer = lXmlBuffer +   "<PROJECT_ID>" +  lResultSet.getString("PROJECT_ID") +   "</PROJECT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("shift_code") )
              lXmlBuffer = lXmlBuffer +   "<SHIFT_CODE>" +  lResultSet.getString("SHIFT_CODE") +   "</SHIFT_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cycle_code") )
              lXmlBuffer = lXmlBuffer +   "<CYCLE_CODE>" +  lResultSet.getString("CYCLE_CODE") +   "</CYCLE_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone") )
              lXmlBuffer = lXmlBuffer +   "<PHONE>" +  lResultSet.getString("PHONE") +   "</PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ext") )
              lXmlBuffer = lXmlBuffer +   "<EXT>" +  lResultSet.getString("EXT") +   "</EXT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_id") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_ID>" +  lResultSet.getString("EMAIL_ID") +   "</EMAIL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("building_id") )
              lXmlBuffer = lXmlBuffer +   "<BUILDING_ID>" +  lResultSet.getString("BUILDING_ID") +   "</BUILDING_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("floor_num") )
              lXmlBuffer = lXmlBuffer +   "<FLOOR_NUM>" +  lResultSet.getString("FLOOR_NUM") +   "</FLOOR_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("room_num") )
              lXmlBuffer = lXmlBuffer +   "<ROOM_NUM>" +  lResultSet.getString("ROOM_NUM") +   "</ROOM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cubical_num") )
              lXmlBuffer = lXmlBuffer +   "<CUBICAL_NUM>" +  lResultSet.getString("CUBICAL_NUM") +   "</CUBICAL_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_status") )
              lXmlBuffer = lXmlBuffer +   "<EMP_STATUS>" +  lResultSet.getString("EMP_STATUS") +   "</EMP_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_status_date") )
              lXmlBuffer = lXmlBuffer +   "<EMP_STATUS_DATE>" +  lResultSet.getString("EMP_STATUS_DATE") +   "</EMP_STATUS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_agreement_sts") )
              lXmlBuffer = lXmlBuffer +   "<EMP_AGREEMENT_STS>" +  lResultSet.getString("EMP_AGREEMENT_STS") +   "</EMP_AGREEMENT_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_agreement_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<EMP_AGREEMENT_STS_DATE>" +  lResultSet.getString("EMP_AGREEMENT_STS_DATE") +   "</EMP_AGREEMENT_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY>" +  lResultSet.getString("COUNTRY") +   "</COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("recruit_req_id") )
              lXmlBuffer = lXmlBuffer +   "<RECRUIT_REQ_ID>" +  lResultSet.getString("RECRUIT_REQ_ID") +   "</RECRUIT_REQ_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("work_org_id") )
              lXmlBuffer = lXmlBuffer +   "<WORK_ORG_ID>" +  lResultSet.getString("WORK_ORG_ID") +   "</WORK_ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("marital_status") )
              lXmlBuffer = lXmlBuffer +   "<MARITAL_STATUS>" +  lResultSet.getString("MARITAL_STATUS") +   "</MARITAL_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_ind") )
              lXmlBuffer = lXmlBuffer +   "<PAN_IND>" +  lResultSet.getString("PAN_IND") +   "</PAN_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_ind") )
              lXmlBuffer = lXmlBuffer +   "<PF_IND>" +  lResultSet.getString("PF_IND") +   "</PF_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_ind") )
              lXmlBuffer = lXmlBuffer +   "<ESI_IND>" +  lResultSet.getString("ESI_IND") +   "</ESI_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_num") )
              lXmlBuffer = lXmlBuffer +   "<PAN_NUM>" +  lResultSet.getString("PAN_NUM") +   "</PAN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_create_date") )
              lXmlBuffer = lXmlBuffer +   "<PAN_CREATE_DATE>" +  lResultSet.getString("PAN_CREATE_DATE") +   "</PAN_CREATE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("epf_act_num") )
              lXmlBuffer = lXmlBuffer +   "<EPF_ACT_NUM>" +  lResultSet.getString("EPF_ACT_NUM") +   "</EPF_ACT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("epf_act_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<EPF_ACT_OPEN_DT>" +  lResultSet.getString("EPF_ACT_OPEN_DT") +   "</EPF_ACT_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("epf_act_close_dt") )
              lXmlBuffer = lXmlBuffer +   "<EPF_ACT_CLOSE_DT>" +  lResultSet.getString("EPF_ACT_CLOSE_DT") +   "</EPF_ACT_CLOSE_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_epf_act_num") )
              lXmlBuffer = lXmlBuffer +   "<PREV_EPF_ACT_NUM>" +  lResultSet.getString("PREV_EPF_ACT_NUM") +   "</PREV_EPF_ACT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_epf_act_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<PREV_EPF_ACT_OPEN_DT>" +  lResultSet.getString("PREV_EPF_ACT_OPEN_DT") +   "</PREV_EPF_ACT_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_epf_act_close_dt") )
              lXmlBuffer = lXmlBuffer +   "<PREV_EPF_ACT_CLOSE_DT>" +  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT") +   "</PREV_EPF_ACT_CLOSE_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_num") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NUM>" +  lResultSet.getString("ESI_NUM") +   "</ESI_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_act_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<ESI_ACT_OPEN_DT>" +  lResultSet.getString("ESI_ACT_OPEN_DT") +   "</ESI_ACT_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_act_close_dt") )
              lXmlBuffer = lXmlBuffer +   "<ESI_ACT_CLOSE_DT>" +  lResultSet.getString("ESI_ACT_CLOSE_DT") +   "</ESI_ACT_CLOSE_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_esi_num") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ESI_NUM>" +  lResultSet.getString("PREV_ESI_NUM") +   "</PREV_ESI_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_esi_num_open_dt") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ESI_NUM_OPEN_DT>" +  lResultSet.getString("PREV_ESI_NUM_OPEN_DT") +   "</PREV_ESI_NUM_OPEN_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_esi_num_close_dt") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ESI_NUM_CLOSE_DT>" +  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT") +   "</PREV_ESI_NUM_CLOSE_DT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("nss_num") )
              lXmlBuffer = lXmlBuffer +   "<NSS_NUM>" +  lResultSet.getString("NSS_NUM") +   "</NSS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("nss_create_date") )
              lXmlBuffer = lXmlBuffer +   "<NSS_CREATE_DATE>" +  lResultSet.getString("NSS_CREATE_DATE") +   "</NSS_CREATE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gender") )
              lXmlBuffer = lXmlBuffer +   "<GENDER>" +  lResultSet.getString("GENDER") +   "</GENDER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dob") )
              lXmlBuffer = lXmlBuffer +   "<DOB>" +  lResultSet.getString("DOB") +   "</DOB>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("birth_city") )
              lXmlBuffer = lXmlBuffer +   "<BIRTH_CITY>" +  lResultSet.getString("BIRTH_CITY") +   "</BIRTH_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("birth_country") )
              lXmlBuffer = lXmlBuffer +   "<BIRTH_COUNTRY>" +  lResultSet.getString("BIRTH_COUNTRY") +   "</BIRTH_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("barcode") )
              lXmlBuffer = lXmlBuffer +   "<BARCODE>" +  lResultSet.getString("BARCODE") +   "</BARCODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("user_id") )
              lXmlBuffer = lXmlBuffer +   "<USER_ID>" +  lResultSet.getString("USER_ID") +   "</USER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_0") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_0>" +  lResultSet.getString("PSWD_0") +   "</PSWD_0>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("relation_type") )
              lXmlBuffer = lXmlBuffer +   "<RELATION_TYPE>" +  lResultSet.getString("RELATION_TYPE") +   "</RELATION_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("relative_name") )
              lXmlBuffer = lXmlBuffer +   "<RELATIVE_NAME>" +  lResultSet.getString("RELATIVE_NAME") +   "</RELATIVE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("applicant_id") )
              lXmlBuffer = lXmlBuffer +   "<APPLICANT_ID>" +  lResultSet.getString("APPLICANT_ID") +   "</APPLICANT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_card_id") )
              lXmlBuffer = lXmlBuffer +   "<EMP_CARD_ID>" +  lResultSet.getInt("EMP_CARD_ID") +   "</EMP_CARD_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("banker_code") )
              lXmlBuffer = lXmlBuffer +   "<BANKER_CODE>" +  lResultSet.getString("BANKER_CODE") +   "</BANKER_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("banker_name") )
              lXmlBuffer = lXmlBuffer +   "<BANKER_NAME>" +  lResultSet.getString("BANKER_NAME") +   "</BANKER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("salary_mode") )
              lXmlBuffer = lXmlBuffer +   "<SALARY_MODE>" +  lResultSet.getString("SALARY_MODE") +   "</SALARY_MODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pay_card_num") )
              lXmlBuffer = lXmlBuffer +   "<PAY_CARD_NUM>" +  lResultSet.getString("PAY_CARD_NUM") +   "</PAY_CARD_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bank_act_num") )
              lXmlBuffer = lXmlBuffer +   "<BANK_ACT_NUM>" +  lResultSet.getString("BANK_ACT_NUM") +   "</BANK_ACT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_name") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_NAME>" +  lResultSet.getString("FATHER_NAME") +   "</FATHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_name") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_NAME>" +  lResultSet.getString("MOTHER_NAME") +   "</MOTHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spouse_name") )
              lXmlBuffer = lXmlBuffer +   "<SPOUSE_NAME>" +  lResultSet.getString("SPOUSE_NAME") +   "</SPOUSE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_1") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_1>" +  lResultSet.getString("P_ADDRESS_1") +   "</P_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_2") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_2>" +  lResultSet.getString("P_ADDRESS_2") +   "</P_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_city") )
              lXmlBuffer = lXmlBuffer +   "<P_CITY>" +  lResultSet.getString("P_CITY") +   "</P_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_state") )
              lXmlBuffer = lXmlBuffer +   "<P_STATE>" +  lResultSet.getString("P_STATE") +   "</P_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_zip") )
              lXmlBuffer = lXmlBuffer +   "<P_ZIP>" +  lResultSet.getString("P_ZIP") +   "</P_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_country") )
              lXmlBuffer = lXmlBuffer +   "<P_COUNTRY>" +  lResultSet.getString("P_COUNTRY") +   "</P_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_1") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_1>" +  lResultSet.getString("M_ADDRESS_1") +   "</M_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_2") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_2>" +  lResultSet.getString("M_ADDRESS_2") +   "</M_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_city") )
              lXmlBuffer = lXmlBuffer +   "<M_CITY>" +  lResultSet.getString("M_CITY") +   "</M_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_state") )
              lXmlBuffer = lXmlBuffer +   "<M_STATE>" +  lResultSet.getString("M_STATE") +   "</M_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_zip") )
              lXmlBuffer = lXmlBuffer +   "<M_ZIP>" +  lResultSet.getString("M_ZIP") +   "</M_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_country") )
              lXmlBuffer = lXmlBuffer +   "<M_COUNTRY>" +  lResultSet.getString("M_COUNTRY") +   "</M_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hospital_id") )
              lXmlBuffer = lXmlBuffer +   "<HOSPITAL_ID>" +  lResultSet.getString("HOSPITAL_ID") +   "</HOSPITAL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_id") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_ID>" +  lResultSet.getString("COURSE_ID") +   "</COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM>" +  lResultSet.getString("COURSE_STREAM") +   "</COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("emp_track_id") )
              lXmlBuffer = lXmlBuffer +   "<EMP_TRACK_ID>" +  lResultSet.getString("EMP_TRACK_ID") +   "</EMP_TRACK_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allocation_sts") )
              lXmlBuffer = lXmlBuffer +   "<ALLOCATION_STS>" +  lResultSet.getString("ALLOCATION_STS") +   "</ALLOCATION_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("release_date") )
              lXmlBuffer = lXmlBuffer +   "<RELEASE_DATE>" +  lResultSet.getString("RELEASE_DATE") +   "</RELEASE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rp_id") )
              lXmlBuffer = lXmlBuffer +   "<RP_ID>" +  lResultSet.getString("RP_ID") +   "</RP_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("billing_rate") )
              lXmlBuffer = lXmlBuffer +   "<BILLING_RATE>" +  lResultSet.getDouble("BILLING_RATE") +   "</BILLING_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("paying_rate") )
              lXmlBuffer = lXmlBuffer +   "<PAYING_RATE>" +  lResultSet.getDouble("PAYING_RATE") +   "</PAYING_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_nominee_1") )
              lXmlBuffer = lXmlBuffer +   "<PF_NOMINEE_1>" +  lResultSet.getString("PF_NOMINEE_1") +   "</PF_NOMINEE_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_nominee_2") )
              lXmlBuffer = lXmlBuffer +   "<PF_NOMINEE_2>" +  lResultSet.getString("PF_NOMINEE_2") +   "</PF_NOMINEE_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_nominee_1") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NOMINEE_1>" +  lResultSet.getString("ESI_NOMINEE_1") +   "</ESI_NOMINEE_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_nominee_2") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NOMINEE_2>" +  lResultSet.getString("ESI_NOMINEE_2") +   "</ESI_NOMINEE_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_nominee_1_percent") )
              lXmlBuffer = lXmlBuffer +   "<PF_NOMINEE_1_PERCENT>" +  lResultSet.getDouble("PF_NOMINEE_1_PERCENT") +   "</PF_NOMINEE_1_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_nominee_2_percent") )
              lXmlBuffer = lXmlBuffer +   "<PF_NOMINEE_2_PERCENT>" +  lResultSet.getDouble("PF_NOMINEE_2_PERCENT") +   "</PF_NOMINEE_2_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_nominee_1_percent") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NOMINEE_1_PERCENT>" +  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT") +   "</ESI_NOMINEE_1_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_nominee_2_percent") )
              lXmlBuffer = lXmlBuffer +   "<ESI_NOMINEE_2_PERCENT>" +  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT") +   "</ESI_NOMINEE_2_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_status") )
              lXmlBuffer = lXmlBuffer +   "<REC_STATUS>" +  lResultSet.getString("REC_STATUS") +   "</REC_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_name") )
              lXmlBuffer = lXmlBuffer +   "<FILE_NAME>" +  lResultSet.getString("FILE_NAME") +   "</FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_DATE>" +  lResultSet.getString("FILE_CRE_DATE") +   "</FILE_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_TIME>" +  lResultSet.getString("FILE_CRE_TIME") +   "</FILE_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_status") )
              lXmlBuffer = lXmlBuffer +   "<FILE_STATUS>" +  lResultSet.getString("FILE_STATUS") +   "</FILE_STATUS>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</DmEmployee>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtDmEmployeeRecByRowid
               ( String inRowId
               , DmEmployeeTabObj  outDmEmployeeTabObj
               )
  {
    sop("gtDmEmployeeRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "name_initials, "+
                                 "employee_f_name, "+
                                 "employee_m_name, "+
                                 "employee_l_name, "+
                                 "employee_short_name, "+
                                 "emp_type, "+
                                 "emp_ctg, "+
                                 "reporting_head_id, "+
                                 "dept_id, "+
                                 "logical_group_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "designation, "+
                                 "doj, "+
                                 "dot, "+
                                 "project_id, "+
                                 "shift_code, "+
                                 "cycle_code, "+
                                 "phone, "+
                                 "ext, "+
                                 "email_id, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "cubical_num, "+
                                 "emp_status, "+
                                 "emp_status_date, "+
                                 "emp_agreement_sts, "+
                                 "emp_agreement_sts_date, "+
                                 "country, "+
                                 "recruit_req_id, "+
                                 "work_org_id, "+
                                 "marital_status, "+
                                 "pan_ind, "+
                                 "pf_ind, "+
                                 "esi_ind, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "epf_act_close_dt, "+
                                 "prev_epf_act_num, "+
                                 "prev_epf_act_open_dt, "+
                                 "prev_epf_act_close_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "esi_act_close_dt, "+
                                 "prev_esi_num, "+
                                 "prev_esi_num_open_dt, "+
                                 "prev_esi_num_close_dt, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "gender, "+
                                 "dob, "+
                                 "birth_city, "+
                                 "birth_country, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "relation_type, "+
                                 "relative_name, "+
                                 "applicant_id, "+
                                 "emp_card_id, "+
                                 "banker_code, "+
                                 "banker_name, "+
                                 "salary_mode, "+
                                 "pay_card_num, "+
                                 "bank_act_num, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "spouse_name, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_city, "+
                                 "p_state, "+
                                 "p_zip, "+
                                 "p_country, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_city, "+
                                 "m_state, "+
                                 "m_zip, "+
                                 "m_country, "+
                                 "hospital_id, "+
                                 "course_id, "+
                                 "course_stream, "+
                                 "emp_track_id, "+
                                 "allocation_sts, "+
                                 "release_date, "+
                                 "rp_id, "+
                                 "billing_rate, "+
                                 "paying_rate, "+
                                 "pf_nominee_1, "+
                                 "pf_nominee_2, "+
                                 "esi_nominee_1, "+
                                 "esi_nominee_2, "+
                                 "pf_nominee_1_percent, "+
                                 "pf_nominee_2_percent, "+
                                 "esi_nominee_1_percent, "+
                                 "esi_nominee_2_percent, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outDmEmployeeTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmEmployeeTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmEmployeeTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmEmployeeTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          outDmEmployeeTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( outDmEmployeeTabObj.allocation_date != null && outDmEmployeeTabObj.allocation_date.length() > 0 ) 
            outDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outDmEmployeeTabObj.employee_f_name  =  lResultSet.getString("EMPLOYEE_F_NAME");
          outDmEmployeeTabObj.employee_m_name  =  lResultSet.getString("EMPLOYEE_M_NAME");
          outDmEmployeeTabObj.employee_l_name  =  lResultSet.getString("EMPLOYEE_L_NAME");
          outDmEmployeeTabObj.employee_short_name  =  lResultSet.getString("EMPLOYEE_SHORT_NAME");
          outDmEmployeeTabObj.emp_type  =  lResultSet.getString("EMP_TYPE");
          outDmEmployeeTabObj.emp_ctg  =  lResultSet.getString("EMP_CTG");
          outDmEmployeeTabObj.reporting_head_id  =  lResultSet.getString("REPORTING_HEAD_ID");
          outDmEmployeeTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmEmployeeTabObj.logical_group_id  =  lResultSet.getString("LOGICAL_GROUP_ID");
          outDmEmployeeTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmEmployeeTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmEmployeeTabObj.designation  =  lResultSet.getString("DESIGNATION");
          outDmEmployeeTabObj.doj  =  lResultSet.getString("DOJ");

          if ( outDmEmployeeTabObj.doj != null && outDmEmployeeTabObj.doj.length() > 0 ) 
            outDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.doj, lDateTimeTrgFmt);
          outDmEmployeeTabObj.dot  =  lResultSet.getString("DOT");

          if ( outDmEmployeeTabObj.dot != null && outDmEmployeeTabObj.dot.length() > 0 ) 
            outDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.dot, lDateTimeTrgFmt);
          outDmEmployeeTabObj.project_id  =  lResultSet.getString("PROJECT_ID");
          outDmEmployeeTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          outDmEmployeeTabObj.cycle_code  =  lResultSet.getString("CYCLE_CODE");
          outDmEmployeeTabObj.phone  =  lResultSet.getString("PHONE");
          outDmEmployeeTabObj.ext  =  lResultSet.getString("EXT");
          outDmEmployeeTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outDmEmployeeTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outDmEmployeeTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outDmEmployeeTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outDmEmployeeTabObj.cubical_num  =  lResultSet.getString("CUBICAL_NUM");
          outDmEmployeeTabObj.emp_status  =  lResultSet.getString("EMP_STATUS");
          outDmEmployeeTabObj.emp_status_date  =  lResultSet.getString("EMP_STATUS_DATE");

          if ( outDmEmployeeTabObj.emp_status_date != null && outDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            outDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.emp_agreement_sts  =  lResultSet.getString("EMP_AGREEMENT_STS");
          outDmEmployeeTabObj.emp_agreement_sts_date  =  lResultSet.getString("EMP_AGREEMENT_STS_DATE");

          if ( outDmEmployeeTabObj.emp_agreement_sts_date != null && outDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            outDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.country  =  lResultSet.getString("COUNTRY");
          outDmEmployeeTabObj.recruit_req_id  =  lResultSet.getString("RECRUIT_REQ_ID");
          outDmEmployeeTabObj.work_org_id  =  lResultSet.getString("WORK_ORG_ID");
          outDmEmployeeTabObj.marital_status  =  lResultSet.getString("MARITAL_STATUS");
          outDmEmployeeTabObj.pan_ind  =  lResultSet.getString("PAN_IND");
          outDmEmployeeTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          outDmEmployeeTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          outDmEmployeeTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outDmEmployeeTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( outDmEmployeeTabObj.pan_create_date != null && outDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            outDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          outDmEmployeeTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.epf_act_open_dt != null && outDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.epf_act_close_dt  =  lResultSet.getString("EPF_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.epf_act_close_dt != null && outDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_epf_act_num  =  lResultSet.getString("PREV_EPF_ACT_NUM");
          outDmEmployeeTabObj.prev_epf_act_open_dt  =  lResultSet.getString("PREV_EPF_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.prev_epf_act_open_dt != null && outDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_epf_act_close_dt  =  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.prev_epf_act_close_dt != null && outDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          outDmEmployeeTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( outDmEmployeeTabObj.esi_act_open_dt != null && outDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.esi_act_close_dt  =  lResultSet.getString("ESI_ACT_CLOSE_DT");

          if ( outDmEmployeeTabObj.esi_act_close_dt != null && outDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_esi_num  =  lResultSet.getString("PREV_ESI_NUM");
          outDmEmployeeTabObj.prev_esi_num_open_dt  =  lResultSet.getString("PREV_ESI_NUM_OPEN_DT");

          if ( outDmEmployeeTabObj.prev_esi_num_open_dt != null && outDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.prev_esi_num_close_dt  =  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT");

          if ( outDmEmployeeTabObj.prev_esi_num_close_dt != null && outDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            outDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);
          outDmEmployeeTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          outDmEmployeeTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( outDmEmployeeTabObj.nss_create_date != null && outDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            outDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.gender  =  lResultSet.getString("GENDER");
          outDmEmployeeTabObj.dob  =  lResultSet.getString("DOB");

          if ( outDmEmployeeTabObj.dob != null && outDmEmployeeTabObj.dob.length() > 0 ) 
            outDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.dob, lDateTimeTrgFmt);
          outDmEmployeeTabObj.birth_city  =  lResultSet.getString("BIRTH_CITY");
          outDmEmployeeTabObj.birth_country  =  lResultSet.getString("BIRTH_COUNTRY");
          outDmEmployeeTabObj.barcode  =  lResultSet.getString("BARCODE");
          outDmEmployeeTabObj.user_id  =  lResultSet.getString("USER_ID");
          outDmEmployeeTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outDmEmployeeTabObj.relation_type  =  lResultSet.getString("RELATION_TYPE");
          outDmEmployeeTabObj.relative_name  =  lResultSet.getString("RELATIVE_NAME");
          outDmEmployeeTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outDmEmployeeTabObj.emp_card_id  =  lResultSet.getInt("EMP_CARD_ID");
          outDmEmployeeTabObj.banker_code  =  lResultSet.getString("BANKER_CODE");
          outDmEmployeeTabObj.banker_name  =  lResultSet.getString("BANKER_NAME");
          outDmEmployeeTabObj.salary_mode  =  lResultSet.getString("SALARY_MODE");
          outDmEmployeeTabObj.pay_card_num  =  lResultSet.getString("PAY_CARD_NUM");
          outDmEmployeeTabObj.bank_act_num  =  lResultSet.getString("BANK_ACT_NUM");
          outDmEmployeeTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outDmEmployeeTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outDmEmployeeTabObj.spouse_name  =  lResultSet.getString("SPOUSE_NAME");
          outDmEmployeeTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outDmEmployeeTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outDmEmployeeTabObj.p_city  =  lResultSet.getString("P_CITY");
          outDmEmployeeTabObj.p_state  =  lResultSet.getString("P_STATE");
          outDmEmployeeTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outDmEmployeeTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outDmEmployeeTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outDmEmployeeTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outDmEmployeeTabObj.m_city  =  lResultSet.getString("M_CITY");
          outDmEmployeeTabObj.m_state  =  lResultSet.getString("M_STATE");
          outDmEmployeeTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outDmEmployeeTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outDmEmployeeTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          outDmEmployeeTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outDmEmployeeTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outDmEmployeeTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          outDmEmployeeTabObj.allocation_sts  =  lResultSet.getString("ALLOCATION_STS");
          outDmEmployeeTabObj.release_date  =  lResultSet.getString("RELEASE_DATE");

          if ( outDmEmployeeTabObj.release_date != null && outDmEmployeeTabObj.release_date.length() > 0 ) 
            outDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.release_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rp_id  =  lResultSet.getString("RP_ID");
          outDmEmployeeTabObj.billing_rate  =  lResultSet.getDouble("BILLING_RATE");
          outDmEmployeeTabObj.paying_rate  =  lResultSet.getDouble("PAYING_RATE");
          outDmEmployeeTabObj.pf_nominee_1  =  lResultSet.getString("PF_NOMINEE_1");
          outDmEmployeeTabObj.pf_nominee_2  =  lResultSet.getString("PF_NOMINEE_2");
          outDmEmployeeTabObj.esi_nominee_1  =  lResultSet.getString("ESI_NOMINEE_1");
          outDmEmployeeTabObj.esi_nominee_2  =  lResultSet.getString("ESI_NOMINEE_2");
          outDmEmployeeTabObj.pf_nominee_1_percent  =  lResultSet.getDouble("PF_NOMINEE_1_PERCENT");
          outDmEmployeeTabObj.pf_nominee_2_percent  =  lResultSet.getDouble("PF_NOMINEE_2_PERCENT");
          outDmEmployeeTabObj.esi_nominee_1_percent  =  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT");
          outDmEmployeeTabObj.esi_nominee_2_percent  =  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT");
          outDmEmployeeTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmEmployeeTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmEmployeeTabObj.rec_cre_date != null && outDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            outDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmEmployeeTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmEmployeeTabObj.rec_upd_date != null && outDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            outDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmEmployeeTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmEmployeeTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmEmployeeTabObj.file_cre_date != null && outDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            outDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmEmployeeTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmEmployeeTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmEmployeeTabObj( outDmEmployeeTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeArr
               ( String inDmEmployeeWhereText
               , ArrayList  outDmEmployeeTabObjArr
               )
  {
    sop("gtDmEmployeeArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "employee_id, "+
                                 "allocation_date, "+
                                 "name_initials, "+
                                 "employee_f_name, "+
                                 "employee_m_name, "+
                                 "employee_l_name, "+
                                 "employee_short_name, "+
                                 "emp_type, "+
                                 "emp_ctg, "+
                                 "reporting_head_id, "+
                                 "dept_id, "+
                                 "logical_group_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "designation, "+
                                 "doj, "+
                                 "dot, "+
                                 "project_id, "+
                                 "shift_code, "+
                                 "cycle_code, "+
                                 "phone, "+
                                 "ext, "+
                                 "email_id, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "cubical_num, "+
                                 "emp_status, "+
                                 "emp_status_date, "+
                                 "emp_agreement_sts, "+
                                 "emp_agreement_sts_date, "+
                                 "country, "+
                                 "recruit_req_id, "+
                                 "work_org_id, "+
                                 "marital_status, "+
                                 "pan_ind, "+
                                 "pf_ind, "+
                                 "esi_ind, "+
                                 "pan_num, "+
                                 "pan_create_date, "+
                                 "epf_act_num, "+
                                 "epf_act_open_dt, "+
                                 "epf_act_close_dt, "+
                                 "prev_epf_act_num, "+
                                 "prev_epf_act_open_dt, "+
                                 "prev_epf_act_close_dt, "+
                                 "esi_num, "+
                                 "esi_act_open_dt, "+
                                 "esi_act_close_dt, "+
                                 "prev_esi_num, "+
                                 "prev_esi_num_open_dt, "+
                                 "prev_esi_num_close_dt, "+
                                 "nss_num, "+
                                 "nss_create_date, "+
                                 "gender, "+
                                 "dob, "+
                                 "birth_city, "+
                                 "birth_country, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "relation_type, "+
                                 "relative_name, "+
                                 "applicant_id, "+
                                 "emp_card_id, "+
                                 "banker_code, "+
                                 "banker_name, "+
                                 "salary_mode, "+
                                 "pay_card_num, "+
                                 "bank_act_num, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "spouse_name, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_city, "+
                                 "p_state, "+
                                 "p_zip, "+
                                 "p_country, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_city, "+
                                 "m_state, "+
                                 "m_zip, "+
                                 "m_country, "+
                                 "hospital_id, "+
                                 "course_id, "+
                                 "course_stream, "+
                                 "emp_track_id, "+
                                 "allocation_sts, "+
                                 "release_date, "+
                                 "rp_id, "+
                                 "billing_rate, "+
                                 "paying_rate, "+
                                 "pf_nominee_1, "+
                                 "pf_nominee_2, "+
                                 "esi_nominee_1, "+
                                 "esi_nominee_2, "+
                                 "pf_nominee_1_percent, "+
                                 "pf_nominee_2_percent, "+
                                 "esi_nominee_1_percent, "+
                                 "esi_nominee_2_percent, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmEmployeeTabObj  lDmEmployeeTabObj = new DmEmployeeTabObj();
          lDmEmployeeTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lDmEmployeeTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmEmployeeTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmEmployeeTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
          lDmEmployeeTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");

          if ( lDmEmployeeTabObj.allocation_date != null && lDmEmployeeTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lDmEmployeeTabObj.employee_f_name  =  lResultSet.getString("EMPLOYEE_F_NAME");
          lDmEmployeeTabObj.employee_m_name  =  lResultSet.getString("EMPLOYEE_M_NAME");
          lDmEmployeeTabObj.employee_l_name  =  lResultSet.getString("EMPLOYEE_L_NAME");
          lDmEmployeeTabObj.employee_short_name  =  lResultSet.getString("EMPLOYEE_SHORT_NAME");
          lDmEmployeeTabObj.emp_type  =  lResultSet.getString("EMP_TYPE");
          lDmEmployeeTabObj.emp_ctg  =  lResultSet.getString("EMP_CTG");
          lDmEmployeeTabObj.reporting_head_id  =  lResultSet.getString("REPORTING_HEAD_ID");
          lDmEmployeeTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmEmployeeTabObj.logical_group_id  =  lResultSet.getString("LOGICAL_GROUP_ID");
          lDmEmployeeTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmEmployeeTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmEmployeeTabObj.designation  =  lResultSet.getString("DESIGNATION");
          lDmEmployeeTabObj.doj  =  lResultSet.getString("DOJ");

          if ( lDmEmployeeTabObj.doj != null && lDmEmployeeTabObj.doj.length() > 0 ) 
            lDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.doj, lDateTimeTrgFmt);
          lDmEmployeeTabObj.dot  =  lResultSet.getString("DOT");

          if ( lDmEmployeeTabObj.dot != null && lDmEmployeeTabObj.dot.length() > 0 ) 
            lDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dot, lDateTimeTrgFmt);
          lDmEmployeeTabObj.project_id  =  lResultSet.getString("PROJECT_ID");
          lDmEmployeeTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          lDmEmployeeTabObj.cycle_code  =  lResultSet.getString("CYCLE_CODE");
          lDmEmployeeTabObj.phone  =  lResultSet.getString("PHONE");
          lDmEmployeeTabObj.ext  =  lResultSet.getString("EXT");
          lDmEmployeeTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lDmEmployeeTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lDmEmployeeTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lDmEmployeeTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lDmEmployeeTabObj.cubical_num  =  lResultSet.getString("CUBICAL_NUM");
          lDmEmployeeTabObj.emp_status  =  lResultSet.getString("EMP_STATUS");
          lDmEmployeeTabObj.emp_status_date  =  lResultSet.getString("EMP_STATUS_DATE");

          if ( lDmEmployeeTabObj.emp_status_date != null && lDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.emp_agreement_sts  =  lResultSet.getString("EMP_AGREEMENT_STS");
          lDmEmployeeTabObj.emp_agreement_sts_date  =  lResultSet.getString("EMP_AGREEMENT_STS_DATE");

          if ( lDmEmployeeTabObj.emp_agreement_sts_date != null && lDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.country  =  lResultSet.getString("COUNTRY");
          lDmEmployeeTabObj.recruit_req_id  =  lResultSet.getString("RECRUIT_REQ_ID");
          lDmEmployeeTabObj.work_org_id  =  lResultSet.getString("WORK_ORG_ID");
          lDmEmployeeTabObj.marital_status  =  lResultSet.getString("MARITAL_STATUS");
          lDmEmployeeTabObj.pan_ind  =  lResultSet.getString("PAN_IND");
          lDmEmployeeTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          lDmEmployeeTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          lDmEmployeeTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lDmEmployeeTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");

          if ( lDmEmployeeTabObj.pan_create_date != null && lDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            lDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
          lDmEmployeeTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.epf_act_open_dt != null && lDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.epf_act_close_dt  =  lResultSet.getString("EPF_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.epf_act_close_dt != null && lDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_epf_act_num  =  lResultSet.getString("PREV_EPF_ACT_NUM");
          lDmEmployeeTabObj.prev_epf_act_open_dt  =  lResultSet.getString("PREV_EPF_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.prev_epf_act_open_dt != null && lDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_epf_act_close_dt  =  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.prev_epf_act_close_dt != null && lDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
          lDmEmployeeTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");

          if ( lDmEmployeeTabObj.esi_act_open_dt != null && lDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.esi_act_close_dt  =  lResultSet.getString("ESI_ACT_CLOSE_DT");

          if ( lDmEmployeeTabObj.esi_act_close_dt != null && lDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_esi_num  =  lResultSet.getString("PREV_ESI_NUM");
          lDmEmployeeTabObj.prev_esi_num_open_dt  =  lResultSet.getString("PREV_ESI_NUM_OPEN_DT");

          if ( lDmEmployeeTabObj.prev_esi_num_open_dt != null && lDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.prev_esi_num_close_dt  =  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT");

          if ( lDmEmployeeTabObj.prev_esi_num_close_dt != null && lDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);
          lDmEmployeeTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
          lDmEmployeeTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");

          if ( lDmEmployeeTabObj.nss_create_date != null && lDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            lDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.gender  =  lResultSet.getString("GENDER");
          lDmEmployeeTabObj.dob  =  lResultSet.getString("DOB");

          if ( lDmEmployeeTabObj.dob != null && lDmEmployeeTabObj.dob.length() > 0 ) 
            lDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dob, lDateTimeTrgFmt);
          lDmEmployeeTabObj.birth_city  =  lResultSet.getString("BIRTH_CITY");
          lDmEmployeeTabObj.birth_country  =  lResultSet.getString("BIRTH_COUNTRY");
          lDmEmployeeTabObj.barcode  =  lResultSet.getString("BARCODE");
          lDmEmployeeTabObj.user_id  =  lResultSet.getString("USER_ID");
          lDmEmployeeTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lDmEmployeeTabObj.relation_type  =  lResultSet.getString("RELATION_TYPE");
          lDmEmployeeTabObj.relative_name  =  lResultSet.getString("RELATIVE_NAME");
          lDmEmployeeTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lDmEmployeeTabObj.emp_card_id  =  lResultSet.getInt("EMP_CARD_ID");
          lDmEmployeeTabObj.banker_code  =  lResultSet.getString("BANKER_CODE");
          lDmEmployeeTabObj.banker_name  =  lResultSet.getString("BANKER_NAME");
          lDmEmployeeTabObj.salary_mode  =  lResultSet.getString("SALARY_MODE");
          lDmEmployeeTabObj.pay_card_num  =  lResultSet.getString("PAY_CARD_NUM");
          lDmEmployeeTabObj.bank_act_num  =  lResultSet.getString("BANK_ACT_NUM");
          lDmEmployeeTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lDmEmployeeTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lDmEmployeeTabObj.spouse_name  =  lResultSet.getString("SPOUSE_NAME");
          lDmEmployeeTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lDmEmployeeTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lDmEmployeeTabObj.p_city  =  lResultSet.getString("P_CITY");
          lDmEmployeeTabObj.p_state  =  lResultSet.getString("P_STATE");
          lDmEmployeeTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lDmEmployeeTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lDmEmployeeTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lDmEmployeeTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lDmEmployeeTabObj.m_city  =  lResultSet.getString("M_CITY");
          lDmEmployeeTabObj.m_state  =  lResultSet.getString("M_STATE");
          lDmEmployeeTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lDmEmployeeTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lDmEmployeeTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
          lDmEmployeeTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lDmEmployeeTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lDmEmployeeTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
          lDmEmployeeTabObj.allocation_sts  =  lResultSet.getString("ALLOCATION_STS");
          lDmEmployeeTabObj.release_date  =  lResultSet.getString("RELEASE_DATE");

          if ( lDmEmployeeTabObj.release_date != null && lDmEmployeeTabObj.release_date.length() > 0 ) 
            lDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.release_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rp_id  =  lResultSet.getString("RP_ID");
          lDmEmployeeTabObj.billing_rate  =  lResultSet.getDouble("BILLING_RATE");
          lDmEmployeeTabObj.paying_rate  =  lResultSet.getDouble("PAYING_RATE");
          lDmEmployeeTabObj.pf_nominee_1  =  lResultSet.getString("PF_NOMINEE_1");
          lDmEmployeeTabObj.pf_nominee_2  =  lResultSet.getString("PF_NOMINEE_2");
          lDmEmployeeTabObj.esi_nominee_1  =  lResultSet.getString("ESI_NOMINEE_1");
          lDmEmployeeTabObj.esi_nominee_2  =  lResultSet.getString("ESI_NOMINEE_2");
          lDmEmployeeTabObj.pf_nominee_1_percent  =  lResultSet.getDouble("PF_NOMINEE_1_PERCENT");
          lDmEmployeeTabObj.pf_nominee_2_percent  =  lResultSet.getDouble("PF_NOMINEE_2_PERCENT");
          lDmEmployeeTabObj.esi_nominee_1_percent  =  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT");
          lDmEmployeeTabObj.esi_nominee_2_percent  =  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT");
          lDmEmployeeTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmEmployeeTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmEmployeeTabObj.rec_cre_date != null && lDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmEmployeeTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmEmployeeTabObj.rec_upd_date != null && lDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmEmployeeTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmEmployeeTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmEmployeeTabObj.file_cre_date != null && lDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmEmployeeTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmEmployeeTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmEmployeeTabObj( lDmEmployeeTabObj );

          outDmEmployeeTabObjArr.add(  lDmEmployeeTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeTabObjArr != null && outDmEmployeeTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeArrDist
               ( String inDmEmployeeWhereText
               , String inDistDmEmployeeField
               , ArrayList  outDmEmployeeTabObjArr
               )
  {

    sop("gtDmEmployeeArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";
  

       String lDistDmEmployeeFieldQry = inDistDmEmployeeField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmEmployeeFieldQry+
                         " FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmEmployeeField.substring(inDistDmEmployeeField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          DmEmployeeTabObj  lDmEmployeeTabObj = new DmEmployeeTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lDmEmployeeTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_id") )
              lDmEmployeeTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_id") )
              lDmEmployeeTabObj.employee_id  =  lResultSet.getString("EMPLOYEE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allocation_date") )
              {
              lDmEmployeeTabObj.allocation_date  =  lResultSet.getString("ALLOCATION_DATE");
  
          if ( lDmEmployeeTabObj.allocation_date != null && lDmEmployeeTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.allocation_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("name_initials") )
              lDmEmployeeTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_f_name") )
              lDmEmployeeTabObj.employee_f_name  =  lResultSet.getString("EMPLOYEE_F_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_m_name") )
              lDmEmployeeTabObj.employee_m_name  =  lResultSet.getString("EMPLOYEE_M_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_l_name") )
              lDmEmployeeTabObj.employee_l_name  =  lResultSet.getString("EMPLOYEE_L_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_short_name") )
              lDmEmployeeTabObj.employee_short_name  =  lResultSet.getString("EMPLOYEE_SHORT_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_type") )
              lDmEmployeeTabObj.emp_type  =  lResultSet.getString("EMP_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_ctg") )
              lDmEmployeeTabObj.emp_ctg  =  lResultSet.getString("EMP_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reporting_head_id") )
              lDmEmployeeTabObj.reporting_head_id  =  lResultSet.getString("REPORTING_HEAD_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dept_id") )
              lDmEmployeeTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("logical_group_id") )
              lDmEmployeeTabObj.logical_group_id  =  lResultSet.getString("LOGICAL_GROUP_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("position_id") )
              lDmEmployeeTabObj.position_id  =  lResultSet.getString("POSITION_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("level_id") )
              lDmEmployeeTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("designation") )
              lDmEmployeeTabObj.designation  =  lResultSet.getString("DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("doj") )
              {
              lDmEmployeeTabObj.doj  =  lResultSet.getString("DOJ");
  
          if ( lDmEmployeeTabObj.doj != null && lDmEmployeeTabObj.doj.length() > 0 ) 
            lDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.doj, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dot") )
              {
              lDmEmployeeTabObj.dot  =  lResultSet.getString("DOT");
  
          if ( lDmEmployeeTabObj.dot != null && lDmEmployeeTabObj.dot.length() > 0 ) 
            lDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dot, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("project_id") )
              lDmEmployeeTabObj.project_id  =  lResultSet.getString("PROJECT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("shift_code") )
              lDmEmployeeTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cycle_code") )
              lDmEmployeeTabObj.cycle_code  =  lResultSet.getString("CYCLE_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone") )
              lDmEmployeeTabObj.phone  =  lResultSet.getString("PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ext") )
              lDmEmployeeTabObj.ext  =  lResultSet.getString("EXT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_id") )
              lDmEmployeeTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("building_id") )
              lDmEmployeeTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("floor_num") )
              lDmEmployeeTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("room_num") )
              lDmEmployeeTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cubical_num") )
              lDmEmployeeTabObj.cubical_num  =  lResultSet.getString("CUBICAL_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_status") )
              lDmEmployeeTabObj.emp_status  =  lResultSet.getString("EMP_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_status_date") )
              {
              lDmEmployeeTabObj.emp_status_date  =  lResultSet.getString("EMP_STATUS_DATE");
  
          if ( lDmEmployeeTabObj.emp_status_date != null && lDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_status_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_agreement_sts") )
              lDmEmployeeTabObj.emp_agreement_sts  =  lResultSet.getString("EMP_AGREEMENT_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_agreement_sts_date") )
              {
              lDmEmployeeTabObj.emp_agreement_sts_date  =  lResultSet.getString("EMP_AGREEMENT_STS_DATE");
  
          if ( lDmEmployeeTabObj.emp_agreement_sts_date != null && lDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country") )
              lDmEmployeeTabObj.country  =  lResultSet.getString("COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("recruit_req_id") )
              lDmEmployeeTabObj.recruit_req_id  =  lResultSet.getString("RECRUIT_REQ_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("work_org_id") )
              lDmEmployeeTabObj.work_org_id  =  lResultSet.getString("WORK_ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("marital_status") )
              lDmEmployeeTabObj.marital_status  =  lResultSet.getString("MARITAL_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_ind") )
              lDmEmployeeTabObj.pan_ind  =  lResultSet.getString("PAN_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_ind") )
              lDmEmployeeTabObj.pf_ind  =  lResultSet.getString("PF_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_ind") )
              lDmEmployeeTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_num") )
              lDmEmployeeTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_create_date") )
              {
              lDmEmployeeTabObj.pan_create_date  =  lResultSet.getString("PAN_CREATE_DATE");
  
          if ( lDmEmployeeTabObj.pan_create_date != null && lDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            lDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.pan_create_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("epf_act_num") )
              lDmEmployeeTabObj.epf_act_num  =  lResultSet.getString("EPF_ACT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("epf_act_open_dt") )
              {
              lDmEmployeeTabObj.epf_act_open_dt  =  lResultSet.getString("EPF_ACT_OPEN_DT");
  
          if ( lDmEmployeeTabObj.epf_act_open_dt != null && lDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("epf_act_close_dt") )
              {
              lDmEmployeeTabObj.epf_act_close_dt  =  lResultSet.getString("EPF_ACT_CLOSE_DT");
  
          if ( lDmEmployeeTabObj.epf_act_close_dt != null && lDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.epf_act_close_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_epf_act_num") )
              lDmEmployeeTabObj.prev_epf_act_num  =  lResultSet.getString("PREV_EPF_ACT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_epf_act_open_dt") )
              {
              lDmEmployeeTabObj.prev_epf_act_open_dt  =  lResultSet.getString("PREV_EPF_ACT_OPEN_DT");
  
          if ( lDmEmployeeTabObj.prev_epf_act_open_dt != null && lDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_epf_act_close_dt") )
              {
              lDmEmployeeTabObj.prev_epf_act_close_dt  =  lResultSet.getString("PREV_EPF_ACT_CLOSE_DT");
  
          if ( lDmEmployeeTabObj.prev_epf_act_close_dt != null && lDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_num") )
              lDmEmployeeTabObj.esi_num  =  lResultSet.getString("ESI_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_act_open_dt") )
              {
              lDmEmployeeTabObj.esi_act_open_dt  =  lResultSet.getString("ESI_ACT_OPEN_DT");
  
          if ( lDmEmployeeTabObj.esi_act_open_dt != null && lDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_act_close_dt") )
              {
              lDmEmployeeTabObj.esi_act_close_dt  =  lResultSet.getString("ESI_ACT_CLOSE_DT");
  
          if ( lDmEmployeeTabObj.esi_act_close_dt != null && lDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.esi_act_close_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_esi_num") )
              lDmEmployeeTabObj.prev_esi_num  =  lResultSet.getString("PREV_ESI_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_esi_num_open_dt") )
              {
              lDmEmployeeTabObj.prev_esi_num_open_dt  =  lResultSet.getString("PREV_ESI_NUM_OPEN_DT");
  
          if ( lDmEmployeeTabObj.prev_esi_num_open_dt != null && lDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_esi_num_close_dt") )
              {
              lDmEmployeeTabObj.prev_esi_num_close_dt  =  lResultSet.getString("PREV_ESI_NUM_CLOSE_DT");
  
          if ( lDmEmployeeTabObj.prev_esi_num_close_dt != null && lDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("nss_num") )
              lDmEmployeeTabObj.nss_num  =  lResultSet.getString("NSS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("nss_create_date") )
              {
              lDmEmployeeTabObj.nss_create_date  =  lResultSet.getString("NSS_CREATE_DATE");
  
          if ( lDmEmployeeTabObj.nss_create_date != null && lDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            lDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.nss_create_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gender") )
              lDmEmployeeTabObj.gender  =  lResultSet.getString("GENDER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dob") )
              {
              lDmEmployeeTabObj.dob  =  lResultSet.getString("DOB");
  
          if ( lDmEmployeeTabObj.dob != null && lDmEmployeeTabObj.dob.length() > 0 ) 
            lDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.dob, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("birth_city") )
              lDmEmployeeTabObj.birth_city  =  lResultSet.getString("BIRTH_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("birth_country") )
              lDmEmployeeTabObj.birth_country  =  lResultSet.getString("BIRTH_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("barcode") )
              lDmEmployeeTabObj.barcode  =  lResultSet.getString("BARCODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("user_id") )
              lDmEmployeeTabObj.user_id  =  lResultSet.getString("USER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_0") )
              lDmEmployeeTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("relation_type") )
              lDmEmployeeTabObj.relation_type  =  lResultSet.getString("RELATION_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("relative_name") )
              lDmEmployeeTabObj.relative_name  =  lResultSet.getString("RELATIVE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("applicant_id") )
              lDmEmployeeTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_card_id") )
              lDmEmployeeTabObj.emp_card_id  =  lResultSet.getInt("EMP_CARD_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("banker_code") )
              lDmEmployeeTabObj.banker_code  =  lResultSet.getString("BANKER_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("banker_name") )
              lDmEmployeeTabObj.banker_name  =  lResultSet.getString("BANKER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("salary_mode") )
              lDmEmployeeTabObj.salary_mode  =  lResultSet.getString("SALARY_MODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pay_card_num") )
              lDmEmployeeTabObj.pay_card_num  =  lResultSet.getString("PAY_CARD_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bank_act_num") )
              lDmEmployeeTabObj.bank_act_num  =  lResultSet.getString("BANK_ACT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_name") )
              lDmEmployeeTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_name") )
              lDmEmployeeTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spouse_name") )
              lDmEmployeeTabObj.spouse_name  =  lResultSet.getString("SPOUSE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_1") )
              lDmEmployeeTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_2") )
              lDmEmployeeTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_city") )
              lDmEmployeeTabObj.p_city  =  lResultSet.getString("P_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_state") )
              lDmEmployeeTabObj.p_state  =  lResultSet.getString("P_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_zip") )
              lDmEmployeeTabObj.p_zip  =  lResultSet.getString("P_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_country") )
              lDmEmployeeTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_1") )
              lDmEmployeeTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_2") )
              lDmEmployeeTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_city") )
              lDmEmployeeTabObj.m_city  =  lResultSet.getString("M_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_state") )
              lDmEmployeeTabObj.m_state  =  lResultSet.getString("M_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_zip") )
              lDmEmployeeTabObj.m_zip  =  lResultSet.getString("M_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_country") )
              lDmEmployeeTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hospital_id") )
              lDmEmployeeTabObj.hospital_id  =  lResultSet.getString("HOSPITAL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_id") )
              lDmEmployeeTabObj.course_id  =  lResultSet.getString("COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream") )
              lDmEmployeeTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("emp_track_id") )
              lDmEmployeeTabObj.emp_track_id  =  lResultSet.getString("EMP_TRACK_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allocation_sts") )
              lDmEmployeeTabObj.allocation_sts  =  lResultSet.getString("ALLOCATION_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("release_date") )
              {
              lDmEmployeeTabObj.release_date  =  lResultSet.getString("RELEASE_DATE");
  
          if ( lDmEmployeeTabObj.release_date != null && lDmEmployeeTabObj.release_date.length() > 0 ) 
            lDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.release_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rp_id") )
              lDmEmployeeTabObj.rp_id  =  lResultSet.getString("RP_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("billing_rate") )
              lDmEmployeeTabObj.billing_rate  =  lResultSet.getDouble("BILLING_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("paying_rate") )
              lDmEmployeeTabObj.paying_rate  =  lResultSet.getDouble("PAYING_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_nominee_1") )
              lDmEmployeeTabObj.pf_nominee_1  =  lResultSet.getString("PF_NOMINEE_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_nominee_2") )
              lDmEmployeeTabObj.pf_nominee_2  =  lResultSet.getString("PF_NOMINEE_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_nominee_1") )
              lDmEmployeeTabObj.esi_nominee_1  =  lResultSet.getString("ESI_NOMINEE_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_nominee_2") )
              lDmEmployeeTabObj.esi_nominee_2  =  lResultSet.getString("ESI_NOMINEE_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_nominee_1_percent") )
              lDmEmployeeTabObj.pf_nominee_1_percent  =  lResultSet.getDouble("PF_NOMINEE_1_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_nominee_2_percent") )
              lDmEmployeeTabObj.pf_nominee_2_percent  =  lResultSet.getDouble("PF_NOMINEE_2_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_nominee_1_percent") )
              lDmEmployeeTabObj.esi_nominee_1_percent  =  lResultSet.getDouble("ESI_NOMINEE_1_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_nominee_2_percent") )
              lDmEmployeeTabObj.esi_nominee_2_percent  =  lResultSet.getDouble("ESI_NOMINEE_2_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_status") )
              lDmEmployeeTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lDmEmployeeTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lDmEmployeeTabObj.rec_cre_date != null && lDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lDmEmployeeTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lDmEmployeeTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lDmEmployeeTabObj.rec_upd_date != null && lDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lDmEmployeeTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_name") )
              lDmEmployeeTabObj.file_name  =  lResultSet.getString("FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_date") )
              {
              lDmEmployeeTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");
  
          if ( lDmEmployeeTabObj.file_cre_date != null && lDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmEmployeeTabObj.file_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_time") )
              lDmEmployeeTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_status") )
              lDmEmployeeTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          }
          removeNullDmEmployeeTabObj( lDmEmployeeTabObj );

          outDmEmployeeTabObjArr.add(  lDmEmployeeTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeTabObjArr != null && outDmEmployeeTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmEmployeeStrArrDist
               ( String inDmEmployeeWhereText
               , String inDistDmEmployeeField
               , ArrayList  outDmEmployeeTabObjArr
               )
  {

    sop("gtDmEmployeeStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmEmployeeStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";
  

       String lDistDmEmployeeFieldQry = inDistDmEmployeeField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmEmployeeFieldQry+
                         " FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmEmployeeField.substring(inDistDmEmployeeField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lDmEmployeeTabObjStr = "";
       while(lResultSet.next())
       {
          lDmEmployeeTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lDmEmployeeTabObjStr =   lDmEmployeeTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outDmEmployeeTabObjArr.add(  lDmEmployeeTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmEmployeeTabObjArr != null && outDmEmployeeTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValDmEmployee
               ( String inDmEmployeeWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValDmEmployee - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValDmEmployee";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullDmEmployeeTabObj
               ( 
                 DmEmployeeTabObj  outDmEmployeeTabObj
               )
  {
  
    if ( outDmEmployeeTabObj.org_id == null ) 
     outDmEmployeeTabObj.org_id = ""; 
    if ( outDmEmployeeTabObj.customer_id == null ) 
     outDmEmployeeTabObj.customer_id = ""; 
    if ( outDmEmployeeTabObj.employee_id == null ) 
     outDmEmployeeTabObj.employee_id = ""; 
    if ( outDmEmployeeTabObj.allocation_date == null ) 
     outDmEmployeeTabObj.allocation_date = ""; 
    if ( outDmEmployeeTabObj.name_initials == null ) 
     outDmEmployeeTabObj.name_initials = ""; 
    if ( outDmEmployeeTabObj.employee_f_name == null ) 
     outDmEmployeeTabObj.employee_f_name = ""; 
    if ( outDmEmployeeTabObj.employee_m_name == null ) 
     outDmEmployeeTabObj.employee_m_name = ""; 
    if ( outDmEmployeeTabObj.employee_l_name == null ) 
     outDmEmployeeTabObj.employee_l_name = ""; 
    if ( outDmEmployeeTabObj.employee_short_name == null ) 
     outDmEmployeeTabObj.employee_short_name = ""; 
    if ( outDmEmployeeTabObj.emp_type == null ) 
     outDmEmployeeTabObj.emp_type = ""; 
    if ( outDmEmployeeTabObj.emp_ctg == null ) 
     outDmEmployeeTabObj.emp_ctg = ""; 
    if ( outDmEmployeeTabObj.reporting_head_id == null ) 
     outDmEmployeeTabObj.reporting_head_id = ""; 
    if ( outDmEmployeeTabObj.dept_id == null ) 
     outDmEmployeeTabObj.dept_id = ""; 
    if ( outDmEmployeeTabObj.logical_group_id == null ) 
     outDmEmployeeTabObj.logical_group_id = ""; 
    if ( outDmEmployeeTabObj.position_id == null ) 
     outDmEmployeeTabObj.position_id = ""; 
    if ( outDmEmployeeTabObj.level_id == null ) 
     outDmEmployeeTabObj.level_id = ""; 
    if ( outDmEmployeeTabObj.designation == null ) 
     outDmEmployeeTabObj.designation = ""; 
    if ( outDmEmployeeTabObj.doj == null ) 
     outDmEmployeeTabObj.doj = ""; 
    if ( outDmEmployeeTabObj.dot == null ) 
     outDmEmployeeTabObj.dot = ""; 
    if ( outDmEmployeeTabObj.project_id == null ) 
     outDmEmployeeTabObj.project_id = ""; 
    if ( outDmEmployeeTabObj.shift_code == null ) 
     outDmEmployeeTabObj.shift_code = ""; 
    if ( outDmEmployeeTabObj.cycle_code == null ) 
     outDmEmployeeTabObj.cycle_code = ""; 
    if ( outDmEmployeeTabObj.phone == null ) 
     outDmEmployeeTabObj.phone = ""; 
    if ( outDmEmployeeTabObj.ext == null ) 
     outDmEmployeeTabObj.ext = ""; 
    if ( outDmEmployeeTabObj.email_id == null ) 
     outDmEmployeeTabObj.email_id = ""; 
    if ( outDmEmployeeTabObj.building_id == null ) 
     outDmEmployeeTabObj.building_id = ""; 
    if ( outDmEmployeeTabObj.floor_num == null ) 
     outDmEmployeeTabObj.floor_num = ""; 
    if ( outDmEmployeeTabObj.room_num == null ) 
     outDmEmployeeTabObj.room_num = ""; 
    if ( outDmEmployeeTabObj.cubical_num == null ) 
     outDmEmployeeTabObj.cubical_num = ""; 
    if ( outDmEmployeeTabObj.emp_status == null ) 
     outDmEmployeeTabObj.emp_status = ""; 
    if ( outDmEmployeeTabObj.emp_status_date == null ) 
     outDmEmployeeTabObj.emp_status_date = ""; 
    if ( outDmEmployeeTabObj.emp_agreement_sts == null ) 
     outDmEmployeeTabObj.emp_agreement_sts = ""; 
    if ( outDmEmployeeTabObj.emp_agreement_sts_date == null ) 
     outDmEmployeeTabObj.emp_agreement_sts_date = ""; 
    if ( outDmEmployeeTabObj.country == null ) 
     outDmEmployeeTabObj.country = ""; 
    if ( outDmEmployeeTabObj.recruit_req_id == null ) 
     outDmEmployeeTabObj.recruit_req_id = ""; 
    if ( outDmEmployeeTabObj.work_org_id == null ) 
     outDmEmployeeTabObj.work_org_id = ""; 
    if ( outDmEmployeeTabObj.marital_status == null ) 
     outDmEmployeeTabObj.marital_status = ""; 
    if ( outDmEmployeeTabObj.pan_ind == null ) 
     outDmEmployeeTabObj.pan_ind = ""; 
    if ( outDmEmployeeTabObj.pf_ind == null ) 
     outDmEmployeeTabObj.pf_ind = ""; 
    if ( outDmEmployeeTabObj.esi_ind == null ) 
     outDmEmployeeTabObj.esi_ind = ""; 
    if ( outDmEmployeeTabObj.pan_num == null ) 
     outDmEmployeeTabObj.pan_num = ""; 
    if ( outDmEmployeeTabObj.pan_create_date == null ) 
     outDmEmployeeTabObj.pan_create_date = ""; 
    if ( outDmEmployeeTabObj.epf_act_num == null ) 
     outDmEmployeeTabObj.epf_act_num = ""; 
    if ( outDmEmployeeTabObj.epf_act_open_dt == null ) 
     outDmEmployeeTabObj.epf_act_open_dt = ""; 
    if ( outDmEmployeeTabObj.epf_act_close_dt == null ) 
     outDmEmployeeTabObj.epf_act_close_dt = ""; 
    if ( outDmEmployeeTabObj.prev_epf_act_num == null ) 
     outDmEmployeeTabObj.prev_epf_act_num = ""; 
    if ( outDmEmployeeTabObj.prev_epf_act_open_dt == null ) 
     outDmEmployeeTabObj.prev_epf_act_open_dt = ""; 
    if ( outDmEmployeeTabObj.prev_epf_act_close_dt == null ) 
     outDmEmployeeTabObj.prev_epf_act_close_dt = ""; 
    if ( outDmEmployeeTabObj.esi_num == null ) 
     outDmEmployeeTabObj.esi_num = ""; 
    if ( outDmEmployeeTabObj.esi_act_open_dt == null ) 
     outDmEmployeeTabObj.esi_act_open_dt = ""; 
    if ( outDmEmployeeTabObj.esi_act_close_dt == null ) 
     outDmEmployeeTabObj.esi_act_close_dt = ""; 
    if ( outDmEmployeeTabObj.prev_esi_num == null ) 
     outDmEmployeeTabObj.prev_esi_num = ""; 
    if ( outDmEmployeeTabObj.prev_esi_num_open_dt == null ) 
     outDmEmployeeTabObj.prev_esi_num_open_dt = ""; 
    if ( outDmEmployeeTabObj.prev_esi_num_close_dt == null ) 
     outDmEmployeeTabObj.prev_esi_num_close_dt = ""; 
    if ( outDmEmployeeTabObj.nss_num == null ) 
     outDmEmployeeTabObj.nss_num = ""; 
    if ( outDmEmployeeTabObj.nss_create_date == null ) 
     outDmEmployeeTabObj.nss_create_date = ""; 
    if ( outDmEmployeeTabObj.gender == null ) 
     outDmEmployeeTabObj.gender = ""; 
    if ( outDmEmployeeTabObj.dob == null ) 
     outDmEmployeeTabObj.dob = ""; 
    if ( outDmEmployeeTabObj.birth_city == null ) 
     outDmEmployeeTabObj.birth_city = ""; 
    if ( outDmEmployeeTabObj.birth_country == null ) 
     outDmEmployeeTabObj.birth_country = ""; 
    if ( outDmEmployeeTabObj.barcode == null ) 
     outDmEmployeeTabObj.barcode = ""; 
    if ( outDmEmployeeTabObj.user_id == null ) 
     outDmEmployeeTabObj.user_id = ""; 
    if ( outDmEmployeeTabObj.pswd_0 == null ) 
     outDmEmployeeTabObj.pswd_0 = ""; 
    if ( outDmEmployeeTabObj.relation_type == null ) 
     outDmEmployeeTabObj.relation_type = ""; 
    if ( outDmEmployeeTabObj.relative_name == null ) 
     outDmEmployeeTabObj.relative_name = ""; 
    if ( outDmEmployeeTabObj.applicant_id == null ) 
     outDmEmployeeTabObj.applicant_id = ""; 
    if ( outDmEmployeeTabObj.emp_card_id == (int)0 ) 
     outDmEmployeeTabObj.emp_card_id = (int)0; 
    if ( outDmEmployeeTabObj.banker_code == null ) 
     outDmEmployeeTabObj.banker_code = ""; 
    if ( outDmEmployeeTabObj.banker_name == null ) 
     outDmEmployeeTabObj.banker_name = ""; 
    if ( outDmEmployeeTabObj.salary_mode == null ) 
     outDmEmployeeTabObj.salary_mode = ""; 
    if ( outDmEmployeeTabObj.pay_card_num == null ) 
     outDmEmployeeTabObj.pay_card_num = ""; 
    if ( outDmEmployeeTabObj.bank_act_num == null ) 
     outDmEmployeeTabObj.bank_act_num = ""; 
    if ( outDmEmployeeTabObj.father_name == null ) 
     outDmEmployeeTabObj.father_name = ""; 
    if ( outDmEmployeeTabObj.mother_name == null ) 
     outDmEmployeeTabObj.mother_name = ""; 
    if ( outDmEmployeeTabObj.spouse_name == null ) 
     outDmEmployeeTabObj.spouse_name = ""; 
    if ( outDmEmployeeTabObj.p_address_1 == null ) 
     outDmEmployeeTabObj.p_address_1 = ""; 
    if ( outDmEmployeeTabObj.p_address_2 == null ) 
     outDmEmployeeTabObj.p_address_2 = ""; 
    if ( outDmEmployeeTabObj.p_city == null ) 
     outDmEmployeeTabObj.p_city = ""; 
    if ( outDmEmployeeTabObj.p_state == null ) 
     outDmEmployeeTabObj.p_state = ""; 
    if ( outDmEmployeeTabObj.p_zip == null ) 
     outDmEmployeeTabObj.p_zip = ""; 
    if ( outDmEmployeeTabObj.p_country == null ) 
     outDmEmployeeTabObj.p_country = ""; 
    if ( outDmEmployeeTabObj.m_address_1 == null ) 
     outDmEmployeeTabObj.m_address_1 = ""; 
    if ( outDmEmployeeTabObj.m_address_2 == null ) 
     outDmEmployeeTabObj.m_address_2 = ""; 
    if ( outDmEmployeeTabObj.m_city == null ) 
     outDmEmployeeTabObj.m_city = ""; 
    if ( outDmEmployeeTabObj.m_state == null ) 
     outDmEmployeeTabObj.m_state = ""; 
    if ( outDmEmployeeTabObj.m_zip == null ) 
     outDmEmployeeTabObj.m_zip = ""; 
    if ( outDmEmployeeTabObj.m_country == null ) 
     outDmEmployeeTabObj.m_country = ""; 
    if ( outDmEmployeeTabObj.hospital_id == null ) 
     outDmEmployeeTabObj.hospital_id = ""; 
    if ( outDmEmployeeTabObj.course_id == null ) 
     outDmEmployeeTabObj.course_id = ""; 
    if ( outDmEmployeeTabObj.course_stream == null ) 
     outDmEmployeeTabObj.course_stream = ""; 
    if ( outDmEmployeeTabObj.emp_track_id == null ) 
     outDmEmployeeTabObj.emp_track_id = ""; 
    if ( outDmEmployeeTabObj.allocation_sts == null ) 
     outDmEmployeeTabObj.allocation_sts = ""; 
    if ( outDmEmployeeTabObj.release_date == null ) 
     outDmEmployeeTabObj.release_date = ""; 
    if ( outDmEmployeeTabObj.rp_id == null ) 
     outDmEmployeeTabObj.rp_id = ""; 
    if ( outDmEmployeeTabObj.billing_rate == (double)0.00 ) 
     outDmEmployeeTabObj.billing_rate = (double)0.00; 
    if ( outDmEmployeeTabObj.paying_rate == (double)0.00 ) 
     outDmEmployeeTabObj.paying_rate = (double)0.00; 
    if ( outDmEmployeeTabObj.pf_nominee_1 == null ) 
     outDmEmployeeTabObj.pf_nominee_1 = ""; 
    if ( outDmEmployeeTabObj.pf_nominee_2 == null ) 
     outDmEmployeeTabObj.pf_nominee_2 = ""; 
    if ( outDmEmployeeTabObj.esi_nominee_1 == null ) 
     outDmEmployeeTabObj.esi_nominee_1 = ""; 
    if ( outDmEmployeeTabObj.esi_nominee_2 == null ) 
     outDmEmployeeTabObj.esi_nominee_2 = ""; 
    if ( outDmEmployeeTabObj.pf_nominee_1_percent == (double)0.00 ) 
     outDmEmployeeTabObj.pf_nominee_1_percent = (double)0.00; 
    if ( outDmEmployeeTabObj.pf_nominee_2_percent == (double)0.00 ) 
     outDmEmployeeTabObj.pf_nominee_2_percent = (double)0.00; 
    if ( outDmEmployeeTabObj.esi_nominee_1_percent == (double)0.00 ) 
     outDmEmployeeTabObj.esi_nominee_1_percent = (double)0.00; 
    if ( outDmEmployeeTabObj.esi_nominee_2_percent == (double)0.00 ) 
     outDmEmployeeTabObj.esi_nominee_2_percent = (double)0.00; 
    if ( outDmEmployeeTabObj.rec_status == null ) 
     outDmEmployeeTabObj.rec_status = ""; 
    if ( outDmEmployeeTabObj.rec_cre_date == null ) 
     outDmEmployeeTabObj.rec_cre_date = ""; 
    if ( outDmEmployeeTabObj.rec_cre_time == null ) 
     outDmEmployeeTabObj.rec_cre_time = ""; 
    if ( outDmEmployeeTabObj.rec_upd_date == null ) 
     outDmEmployeeTabObj.rec_upd_date = ""; 
    if ( outDmEmployeeTabObj.rec_upd_time == null ) 
     outDmEmployeeTabObj.rec_upd_time = ""; 
    if ( outDmEmployeeTabObj.file_name == null ) 
     outDmEmployeeTabObj.file_name = ""; 
    if ( outDmEmployeeTabObj.file_cre_date == null ) 
     outDmEmployeeTabObj.file_cre_date = ""; 
    if ( outDmEmployeeTabObj.file_cre_time == null ) 
     outDmEmployeeTabObj.file_cre_time = ""; 
    if ( outDmEmployeeTabObj.file_status == null ) 
     outDmEmployeeTabObj.file_status = ""; 
  }





  public int insDmEmployeeRec
               ( DmEmployeeTabObj  inDmEmployeeTabObj )
  {
    int lUpdateCount;
    sop("insDmEmployeeRec - Started");
    gSSTErrorObj.sourceMethod = "insDmEmployeeRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeTabObj.allocation_date != null && inDmEmployeeTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.doj != null && inDmEmployeeTabObj.doj.length() > 0 ) 
            inDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.doj, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dot != null && inDmEmployeeTabObj.dot.length() > 0 ) 
            inDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dot, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_status_date != null && inDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_status_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_agreement_sts_date != null && inDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.pan_create_date != null && inDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            inDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_open_dt != null && inDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_close_dt != null && inDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null && inDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null && inDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_open_dt != null && inDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_close_dt != null && inDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null && inDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null && inDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.nss_create_date != null && inDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            inDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.nss_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dob != null && inDmEmployeeTabObj.dob.length() > 0 ) 
            inDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dob, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.release_date != null && inDmEmployeeTabObj.release_date.length() > 0 ) 
            inDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.release_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_cre_date != null && inDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_upd_date != null && inDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.file_cre_date != null && inDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_EMPLOYEE"+
                        "("+
                                "org_id,"+
                                "customer_id,"+
                                "employee_id,"+
                                "allocation_date,"+
                                "name_initials,"+
                                "employee_f_name,"+
                                "employee_m_name,"+
                                "employee_l_name,"+
                                "employee_short_name,"+
                                "emp_type,"+
                                "emp_ctg,"+
                                "reporting_head_id,"+
                                "dept_id,"+
                                "logical_group_id,"+
                                "position_id,"+
                                "level_id,"+
                                "designation,"+
                                "doj,"+
                                "dot,"+
                                "project_id,"+
                                "shift_code,"+
                                "cycle_code,"+
                                "phone,"+
                                "ext,"+
                                "email_id,"+
                                "building_id,"+
                                "floor_num,"+
                                "room_num,"+
                                "cubical_num,"+
                                "emp_status,"+
                                "emp_status_date,"+
                                "emp_agreement_sts,"+
                                "emp_agreement_sts_date,"+
                                "country,"+
                                "recruit_req_id,"+
                                "work_org_id,"+
                                "marital_status,"+
                                "pan_ind,"+
                                "pf_ind,"+
                                "esi_ind,"+
                                "pan_num,"+
                                "pan_create_date,"+
                                "epf_act_num,"+
                                "epf_act_open_dt,"+
                                "epf_act_close_dt,"+
                                "prev_epf_act_num,"+
                                "prev_epf_act_open_dt,"+
                                "prev_epf_act_close_dt,"+
                                "esi_num,"+
                                "esi_act_open_dt,"+
                                "esi_act_close_dt,"+
                                "prev_esi_num,"+
                                "prev_esi_num_open_dt,"+
                                "prev_esi_num_close_dt,"+
                                "nss_num,"+
                                "nss_create_date,"+
                                "gender,"+
                                "dob,"+
                                "birth_city,"+
                                "birth_country,"+
                                "barcode,"+
                                "user_id,"+
                                "pswd_0,"+
                                "relation_type,"+
                                "relative_name,"+
                                "applicant_id,"+
                                "emp_card_id,"+
                                "banker_code,"+
                                "banker_name,"+
                                "salary_mode,"+
                                "pay_card_num,"+
                                "bank_act_num,"+
                                "father_name,"+
                                "mother_name,"+
                                "spouse_name,"+
                                "p_address_1,"+
                                "p_address_2,"+
                                "p_city,"+
                                "p_state,"+
                                "p_zip,"+
                                "p_country,"+
                                "m_address_1,"+
                                "m_address_2,"+
                                "m_city,"+
                                "m_state,"+
                                "m_zip,"+
                                "m_country,"+
                                "hospital_id,"+
                                "course_id,"+
                                "course_stream,"+
                                "emp_track_id,"+
                                "allocation_sts,"+
                                "release_date,"+
                                "rp_id,"+
                                "billing_rate,"+
                                "paying_rate,"+
                                "pf_nominee_1,"+
                                "pf_nominee_2,"+
                                "esi_nominee_1,"+
                                "esi_nominee_2,"+
                                "pf_nominee_1_percent,"+
                                "pf_nominee_2_percent,"+
                                "esi_nominee_1_percent,"+
                                "esi_nominee_2_percent,"+
                                "rec_status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "file_name,"+
                                "file_cre_date,"+
                                "file_cre_time,"+
                                "file_status"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.customer_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.employee_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.allocation_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.name_initials+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.employee_f_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.employee_m_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.employee_l_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.employee_short_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.reporting_head_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.dept_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.logical_group_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.position_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.level_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.doj+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.dot+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.project_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.shift_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.cycle_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.ext+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.email_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.building_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.floor_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.room_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.cubical_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_status_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_agreement_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_agreement_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.recruit_req_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.work_org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.marital_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pan_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pf_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pan_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pan_create_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.epf_act_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.epf_act_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.epf_act_close_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_epf_act_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_epf_act_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_epf_act_close_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_act_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_act_close_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_esi_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_esi_num_open_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.prev_esi_num_close_dt+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.nss_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.nss_create_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.gender+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.dob+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.birth_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.birth_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.barcode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.user_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pswd_0+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.relation_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.relative_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.applicant_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.emp_card_id+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.banker_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.banker_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.salary_mode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pay_card_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.bank_act_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.father_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.mother_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.spouse_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.p_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.m_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.hospital_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.emp_track_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.allocation_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.release_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rp_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.billing_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.paying_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pf_nominee_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.pf_nominee_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_nominee_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.esi_nominee_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.pf_nominee_1_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.pf_nominee_2_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.esi_nominee_1_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmEmployeeTabObj.esi_nominee_2_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rec_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.file_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmEmployeeTabObj.file_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inDmEmployeeTabObj.file_status+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inDmEmployeeTabObj.org_id);
        lPreparedStatement.setString(2, inDmEmployeeTabObj.customer_id);
        lPreparedStatement.setString(3, inDmEmployeeTabObj.employee_id);
        lPreparedStatement.setString(4, inDmEmployeeTabObj.allocation_date);
        lPreparedStatement.setString(5, inDmEmployeeTabObj.name_initials);
        lPreparedStatement.setString(6, inDmEmployeeTabObj.employee_f_name);
        lPreparedStatement.setString(7, inDmEmployeeTabObj.employee_m_name);
        lPreparedStatement.setString(8, inDmEmployeeTabObj.employee_l_name);
        lPreparedStatement.setString(9, inDmEmployeeTabObj.employee_short_name);
        lPreparedStatement.setString(10, inDmEmployeeTabObj.emp_type);
        lPreparedStatement.setString(11, inDmEmployeeTabObj.emp_ctg);
        lPreparedStatement.setString(12, inDmEmployeeTabObj.reporting_head_id);
        lPreparedStatement.setString(13, inDmEmployeeTabObj.dept_id);
        lPreparedStatement.setString(14, inDmEmployeeTabObj.logical_group_id);
        lPreparedStatement.setString(15, inDmEmployeeTabObj.position_id);
        lPreparedStatement.setString(16, inDmEmployeeTabObj.level_id);
        lPreparedStatement.setString(17, inDmEmployeeTabObj.designation);
        lPreparedStatement.setString(18, inDmEmployeeTabObj.doj);
        lPreparedStatement.setString(19, inDmEmployeeTabObj.dot);
        lPreparedStatement.setString(20, inDmEmployeeTabObj.project_id);
        lPreparedStatement.setString(21, inDmEmployeeTabObj.shift_code);
        lPreparedStatement.setString(22, inDmEmployeeTabObj.cycle_code);
        lPreparedStatement.setString(23, inDmEmployeeTabObj.phone);
        lPreparedStatement.setString(24, inDmEmployeeTabObj.ext);
        lPreparedStatement.setString(25, inDmEmployeeTabObj.email_id);
        lPreparedStatement.setString(26, inDmEmployeeTabObj.building_id);
        lPreparedStatement.setString(27, inDmEmployeeTabObj.floor_num);
        lPreparedStatement.setString(28, inDmEmployeeTabObj.room_num);
        lPreparedStatement.setString(29, inDmEmployeeTabObj.cubical_num);
        lPreparedStatement.setString(30, inDmEmployeeTabObj.emp_status);
        lPreparedStatement.setString(31, inDmEmployeeTabObj.emp_status_date);
        lPreparedStatement.setString(32, inDmEmployeeTabObj.emp_agreement_sts);
        lPreparedStatement.setString(33, inDmEmployeeTabObj.emp_agreement_sts_date);
        lPreparedStatement.setString(34, inDmEmployeeTabObj.country);
        lPreparedStatement.setString(35, inDmEmployeeTabObj.recruit_req_id);
        lPreparedStatement.setString(36, inDmEmployeeTabObj.work_org_id);
        lPreparedStatement.setString(37, inDmEmployeeTabObj.marital_status);
        lPreparedStatement.setString(38, inDmEmployeeTabObj.pan_ind);
        lPreparedStatement.setString(39, inDmEmployeeTabObj.pf_ind);
        lPreparedStatement.setString(40, inDmEmployeeTabObj.esi_ind);
        lPreparedStatement.setString(41, inDmEmployeeTabObj.pan_num);
        lPreparedStatement.setString(42, inDmEmployeeTabObj.pan_create_date);
        lPreparedStatement.setString(43, inDmEmployeeTabObj.epf_act_num);
        lPreparedStatement.setString(44, inDmEmployeeTabObj.epf_act_open_dt);
        lPreparedStatement.setString(45, inDmEmployeeTabObj.epf_act_close_dt);
        lPreparedStatement.setString(46, inDmEmployeeTabObj.prev_epf_act_num);
        lPreparedStatement.setString(47, inDmEmployeeTabObj.prev_epf_act_open_dt);
        lPreparedStatement.setString(48, inDmEmployeeTabObj.prev_epf_act_close_dt);
        lPreparedStatement.setString(49, inDmEmployeeTabObj.esi_num);
        lPreparedStatement.setString(50, inDmEmployeeTabObj.esi_act_open_dt);
        lPreparedStatement.setString(51, inDmEmployeeTabObj.esi_act_close_dt);
        lPreparedStatement.setString(52, inDmEmployeeTabObj.prev_esi_num);
        lPreparedStatement.setString(53, inDmEmployeeTabObj.prev_esi_num_open_dt);
        lPreparedStatement.setString(54, inDmEmployeeTabObj.prev_esi_num_close_dt);
        lPreparedStatement.setString(55, inDmEmployeeTabObj.nss_num);
        lPreparedStatement.setString(56, inDmEmployeeTabObj.nss_create_date);
        lPreparedStatement.setString(57, inDmEmployeeTabObj.gender);
        lPreparedStatement.setString(58, inDmEmployeeTabObj.dob);
        lPreparedStatement.setString(59, inDmEmployeeTabObj.birth_city);
        lPreparedStatement.setString(60, inDmEmployeeTabObj.birth_country);
        lPreparedStatement.setString(61, inDmEmployeeTabObj.barcode);
        lPreparedStatement.setString(62, inDmEmployeeTabObj.user_id);
        lPreparedStatement.setString(63, inDmEmployeeTabObj.pswd_0);
        lPreparedStatement.setString(64, inDmEmployeeTabObj.relation_type);
        lPreparedStatement.setString(65, inDmEmployeeTabObj.relative_name);
        lPreparedStatement.setString(66, inDmEmployeeTabObj.applicant_id);
          lPreparedStatement.setInt(67, inDmEmployeeTabObj.emp_card_id);
        lPreparedStatement.setString(68, inDmEmployeeTabObj.banker_code);
        lPreparedStatement.setString(69, inDmEmployeeTabObj.banker_name);
        lPreparedStatement.setString(70, inDmEmployeeTabObj.salary_mode);
        lPreparedStatement.setString(71, inDmEmployeeTabObj.pay_card_num);
        lPreparedStatement.setString(72, inDmEmployeeTabObj.bank_act_num);
        lPreparedStatement.setString(73, inDmEmployeeTabObj.father_name);
        lPreparedStatement.setString(74, inDmEmployeeTabObj.mother_name);
        lPreparedStatement.setString(75, inDmEmployeeTabObj.spouse_name);
        lPreparedStatement.setString(76, inDmEmployeeTabObj.p_address_1);
        lPreparedStatement.setString(77, inDmEmployeeTabObj.p_address_2);
        lPreparedStatement.setString(78, inDmEmployeeTabObj.p_city);
        lPreparedStatement.setString(79, inDmEmployeeTabObj.p_state);
        lPreparedStatement.setString(80, inDmEmployeeTabObj.p_zip);
        lPreparedStatement.setString(81, inDmEmployeeTabObj.p_country);
        lPreparedStatement.setString(82, inDmEmployeeTabObj.m_address_1);
        lPreparedStatement.setString(83, inDmEmployeeTabObj.m_address_2);
        lPreparedStatement.setString(84, inDmEmployeeTabObj.m_city);
        lPreparedStatement.setString(85, inDmEmployeeTabObj.m_state);
        lPreparedStatement.setString(86, inDmEmployeeTabObj.m_zip);
        lPreparedStatement.setString(87, inDmEmployeeTabObj.m_country);
        lPreparedStatement.setString(88, inDmEmployeeTabObj.hospital_id);
        lPreparedStatement.setString(89, inDmEmployeeTabObj.course_id);
        lPreparedStatement.setString(90, inDmEmployeeTabObj.course_stream);
        lPreparedStatement.setString(91, inDmEmployeeTabObj.emp_track_id);
        lPreparedStatement.setString(92, inDmEmployeeTabObj.allocation_sts);
        lPreparedStatement.setString(93, inDmEmployeeTabObj.release_date);
        lPreparedStatement.setString(94, inDmEmployeeTabObj.rp_id);
          lPreparedStatement.setDouble(95, inDmEmployeeTabObj.billing_rate);
          lPreparedStatement.setDouble(96, inDmEmployeeTabObj.paying_rate);
        lPreparedStatement.setString(97, inDmEmployeeTabObj.pf_nominee_1);
        lPreparedStatement.setString(98, inDmEmployeeTabObj.pf_nominee_2);
        lPreparedStatement.setString(99, inDmEmployeeTabObj.esi_nominee_1);
        lPreparedStatement.setString(100, inDmEmployeeTabObj.esi_nominee_2);
          lPreparedStatement.setDouble(101, inDmEmployeeTabObj.pf_nominee_1_percent);
          lPreparedStatement.setDouble(102, inDmEmployeeTabObj.pf_nominee_2_percent);
          lPreparedStatement.setDouble(103, inDmEmployeeTabObj.esi_nominee_1_percent);
          lPreparedStatement.setDouble(104, inDmEmployeeTabObj.esi_nominee_2_percent);
        lPreparedStatement.setString(105, inDmEmployeeTabObj.rec_status);
        lPreparedStatement.setString(106, inDmEmployeeTabObj.rec_cre_date);
        lPreparedStatement.setString(107, inDmEmployeeTabObj.rec_cre_time);
        lPreparedStatement.setString(108, inDmEmployeeTabObj.rec_upd_date);
        lPreparedStatement.setString(109, inDmEmployeeTabObj.rec_upd_time);
        lPreparedStatement.setString(110, inDmEmployeeTabObj.file_name);
        lPreparedStatement.setString(111, inDmEmployeeTabObj.file_cre_date);
        lPreparedStatement.setString(112, inDmEmployeeTabObj.file_cre_time);
        lPreparedStatement.setString(113, inDmEmployeeTabObj.file_status);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insDmEmployeeArr
               ( ArrayList  inDmEmployeeTabObjArr 
               , String  inRowidFlag )
  {
    DmEmployeeTabObj  lDmEmployeeTabObj = new DmEmployeeTabObj();
    int lUpdateCount;
    sop("insDmEmployeeArr - Started");
    gSSTErrorObj.sourceMethod = "insDmEmployeeArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inDmEmployeeTabObjArr.size(); lNumRec++ )
      {
        lDmEmployeeTabObj = (DmEmployeeTabObj)inDmEmployeeTabObjArr.get(lNumRec);

          if ( lDmEmployeeTabObj.allocation_date != null && lDmEmployeeTabObj.allocation_date.length() > 0 ) 
            lDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.allocation_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.doj != null && lDmEmployeeTabObj.doj.length() > 0 ) 
            lDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.doj, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.dot != null && lDmEmployeeTabObj.dot.length() > 0 ) 
            lDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.dot, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.emp_status_date != null && lDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.emp_status_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.emp_agreement_sts_date != null && lDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            lDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.pan_create_date != null && lDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            lDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.epf_act_open_dt != null && lDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.epf_act_close_dt != null && lDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.epf_act_close_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.prev_epf_act_open_dt != null && lDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.prev_epf_act_close_dt != null && lDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.esi_act_open_dt != null && lDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.esi_act_close_dt != null && lDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.esi_act_close_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.prev_esi_num_open_dt != null && lDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.prev_esi_num_close_dt != null && lDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            lDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.nss_create_date != null && lDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            lDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.nss_create_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.dob != null && lDmEmployeeTabObj.dob.length() > 0 ) 
            lDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.dob, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.release_date != null && lDmEmployeeTabObj.release_date.length() > 0 ) 
            lDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.release_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.rec_cre_date != null && lDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.rec_upd_date != null && lDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            lDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( lDmEmployeeTabObj.file_cre_date != null && lDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            lDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmEmployeeTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_EMPLOYEE"+
                        "("+
                        "org_id,"+
                        "customer_id,"+
                        "employee_id,"+
                        "allocation_date,"+
                        "name_initials,"+
                        "employee_f_name,"+
                        "employee_m_name,"+
                        "employee_l_name,"+
                        "employee_short_name,"+
                        "emp_type,"+
                        "emp_ctg,"+
                        "reporting_head_id,"+
                        "dept_id,"+
                        "logical_group_id,"+
                        "position_id,"+
                        "level_id,"+
                        "designation,"+
                        "doj,"+
                        "dot,"+
                        "project_id,"+
                        "shift_code,"+
                        "cycle_code,"+
                        "phone,"+
                        "ext,"+
                        "email_id,"+
                        "building_id,"+
                        "floor_num,"+
                        "room_num,"+
                        "cubical_num,"+
                        "emp_status,"+
                        "emp_status_date,"+
                        "emp_agreement_sts,"+
                        "emp_agreement_sts_date,"+
                        "country,"+
                        "recruit_req_id,"+
                        "work_org_id,"+
                        "marital_status,"+
                        "pan_ind,"+
                        "pf_ind,"+
                        "esi_ind,"+
                        "pan_num,"+
                        "pan_create_date,"+
                        "epf_act_num,"+
                        "epf_act_open_dt,"+
                        "epf_act_close_dt,"+
                        "prev_epf_act_num,"+
                        "prev_epf_act_open_dt,"+
                        "prev_epf_act_close_dt,"+
                        "esi_num,"+
                        "esi_act_open_dt,"+
                        "esi_act_close_dt,"+
                        "prev_esi_num,"+
                        "prev_esi_num_open_dt,"+
                        "prev_esi_num_close_dt,"+
                        "nss_num,"+
                        "nss_create_date,"+
                        "gender,"+
                        "dob,"+
                        "birth_city,"+
                        "birth_country,"+
                        "barcode,"+
                        "user_id,"+
                        "pswd_0,"+
                        "relation_type,"+
                        "relative_name,"+
                        "applicant_id,"+
                        "emp_card_id,"+
                        "banker_code,"+
                        "banker_name,"+
                        "salary_mode,"+
                        "pay_card_num,"+
                        "bank_act_num,"+
                        "father_name,"+
                        "mother_name,"+
                        "spouse_name,"+
                        "p_address_1,"+
                        "p_address_2,"+
                        "p_city,"+
                        "p_state,"+
                        "p_zip,"+
                        "p_country,"+
                        "m_address_1,"+
                        "m_address_2,"+
                        "m_city,"+
                        "m_state,"+
                        "m_zip,"+
                        "m_country,"+
                        "hospital_id,"+
                        "course_id,"+
                        "course_stream,"+
                        "emp_track_id,"+
                        "allocation_sts,"+
                        "release_date,"+
                        "rp_id,"+
                        "billing_rate,"+
                        "paying_rate,"+
                        "pf_nominee_1,"+
                        "pf_nominee_2,"+
                        "esi_nominee_1,"+
                        "esi_nominee_2,"+
                        "pf_nominee_1_percent,"+
                        "pf_nominee_2_percent,"+
                        "esi_nominee_1_percent,"+
                        "esi_nominee_2_percent,"+
                        "rec_status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "file_name,"+
                        "file_cre_date,"+
                        "file_cre_time,"+
                        "file_status"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.customer_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.employee_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.allocation_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.name_initials+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.employee_f_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.employee_m_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.employee_l_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.employee_short_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.reporting_head_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.dept_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.logical_group_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.position_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.level_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.doj+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.dot+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.project_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.shift_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.cycle_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.ext+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.email_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.building_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.floor_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.room_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.cubical_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_status_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_agreement_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_agreement_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.recruit_req_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.work_org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.marital_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pan_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pf_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pan_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pan_create_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.epf_act_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.epf_act_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.epf_act_close_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_epf_act_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_epf_act_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_epf_act_close_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_act_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_act_close_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_esi_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_esi_num_open_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.prev_esi_num_close_dt+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.nss_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.nss_create_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.gender+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.dob+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.birth_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.birth_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.barcode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.user_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pswd_0+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.relation_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.relative_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.applicant_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.emp_card_id+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.banker_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.banker_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.salary_mode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pay_card_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.bank_act_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.father_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.mother_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.spouse_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.p_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.m_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.hospital_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.emp_track_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.allocation_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.release_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rp_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.billing_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.paying_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pf_nominee_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.pf_nominee_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_nominee_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.esi_nominee_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.pf_nominee_1_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.pf_nominee_2_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.esi_nominee_1_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmEmployeeTabObj.esi_nominee_2_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rec_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.file_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmEmployeeTabObj.file_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lDmEmployeeTabObj.file_status+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lDmEmployeeTabObj.org_id);
            lPreparedStatement.setString(2, lDmEmployeeTabObj.customer_id);
            lPreparedStatement.setString(3, lDmEmployeeTabObj.employee_id);
            lPreparedStatement.setString(4, lDmEmployeeTabObj.allocation_date);
            lPreparedStatement.setString(5, lDmEmployeeTabObj.name_initials);
            lPreparedStatement.setString(6, lDmEmployeeTabObj.employee_f_name);
            lPreparedStatement.setString(7, lDmEmployeeTabObj.employee_m_name);
            lPreparedStatement.setString(8, lDmEmployeeTabObj.employee_l_name);
            lPreparedStatement.setString(9, lDmEmployeeTabObj.employee_short_name);
            lPreparedStatement.setString(10, lDmEmployeeTabObj.emp_type);
            lPreparedStatement.setString(11, lDmEmployeeTabObj.emp_ctg);
            lPreparedStatement.setString(12, lDmEmployeeTabObj.reporting_head_id);
            lPreparedStatement.setString(13, lDmEmployeeTabObj.dept_id);
            lPreparedStatement.setString(14, lDmEmployeeTabObj.logical_group_id);
            lPreparedStatement.setString(15, lDmEmployeeTabObj.position_id);
            lPreparedStatement.setString(16, lDmEmployeeTabObj.level_id);
            lPreparedStatement.setString(17, lDmEmployeeTabObj.designation);
            lPreparedStatement.setString(18, lDmEmployeeTabObj.doj);
            lPreparedStatement.setString(19, lDmEmployeeTabObj.dot);
            lPreparedStatement.setString(20, lDmEmployeeTabObj.project_id);
            lPreparedStatement.setString(21, lDmEmployeeTabObj.shift_code);
            lPreparedStatement.setString(22, lDmEmployeeTabObj.cycle_code);
            lPreparedStatement.setString(23, lDmEmployeeTabObj.phone);
            lPreparedStatement.setString(24, lDmEmployeeTabObj.ext);
            lPreparedStatement.setString(25, lDmEmployeeTabObj.email_id);
            lPreparedStatement.setString(26, lDmEmployeeTabObj.building_id);
            lPreparedStatement.setString(27, lDmEmployeeTabObj.floor_num);
            lPreparedStatement.setString(28, lDmEmployeeTabObj.room_num);
            lPreparedStatement.setString(29, lDmEmployeeTabObj.cubical_num);
            lPreparedStatement.setString(30, lDmEmployeeTabObj.emp_status);
            lPreparedStatement.setString(31, lDmEmployeeTabObj.emp_status_date);
            lPreparedStatement.setString(32, lDmEmployeeTabObj.emp_agreement_sts);
            lPreparedStatement.setString(33, lDmEmployeeTabObj.emp_agreement_sts_date);
            lPreparedStatement.setString(34, lDmEmployeeTabObj.country);
            lPreparedStatement.setString(35, lDmEmployeeTabObj.recruit_req_id);
            lPreparedStatement.setString(36, lDmEmployeeTabObj.work_org_id);
            lPreparedStatement.setString(37, lDmEmployeeTabObj.marital_status);
            lPreparedStatement.setString(38, lDmEmployeeTabObj.pan_ind);
            lPreparedStatement.setString(39, lDmEmployeeTabObj.pf_ind);
            lPreparedStatement.setString(40, lDmEmployeeTabObj.esi_ind);
            lPreparedStatement.setString(41, lDmEmployeeTabObj.pan_num);
            lPreparedStatement.setString(42, lDmEmployeeTabObj.pan_create_date);
            lPreparedStatement.setString(43, lDmEmployeeTabObj.epf_act_num);
            lPreparedStatement.setString(44, lDmEmployeeTabObj.epf_act_open_dt);
            lPreparedStatement.setString(45, lDmEmployeeTabObj.epf_act_close_dt);
            lPreparedStatement.setString(46, lDmEmployeeTabObj.prev_epf_act_num);
            lPreparedStatement.setString(47, lDmEmployeeTabObj.prev_epf_act_open_dt);
            lPreparedStatement.setString(48, lDmEmployeeTabObj.prev_epf_act_close_dt);
            lPreparedStatement.setString(49, lDmEmployeeTabObj.esi_num);
            lPreparedStatement.setString(50, lDmEmployeeTabObj.esi_act_open_dt);
            lPreparedStatement.setString(51, lDmEmployeeTabObj.esi_act_close_dt);
            lPreparedStatement.setString(52, lDmEmployeeTabObj.prev_esi_num);
            lPreparedStatement.setString(53, lDmEmployeeTabObj.prev_esi_num_open_dt);
            lPreparedStatement.setString(54, lDmEmployeeTabObj.prev_esi_num_close_dt);
            lPreparedStatement.setString(55, lDmEmployeeTabObj.nss_num);
            lPreparedStatement.setString(56, lDmEmployeeTabObj.nss_create_date);
            lPreparedStatement.setString(57, lDmEmployeeTabObj.gender);
            lPreparedStatement.setString(58, lDmEmployeeTabObj.dob);
            lPreparedStatement.setString(59, lDmEmployeeTabObj.birth_city);
            lPreparedStatement.setString(60, lDmEmployeeTabObj.birth_country);
            lPreparedStatement.setString(61, lDmEmployeeTabObj.barcode);
            lPreparedStatement.setString(62, lDmEmployeeTabObj.user_id);
            lPreparedStatement.setString(63, lDmEmployeeTabObj.pswd_0);
            lPreparedStatement.setString(64, lDmEmployeeTabObj.relation_type);
            lPreparedStatement.setString(65, lDmEmployeeTabObj.relative_name);
            lPreparedStatement.setString(66, lDmEmployeeTabObj.applicant_id);
              lPreparedStatement.setInt(67, lDmEmployeeTabObj.emp_card_id);
            lPreparedStatement.setString(68, lDmEmployeeTabObj.banker_code);
            lPreparedStatement.setString(69, lDmEmployeeTabObj.banker_name);
            lPreparedStatement.setString(70, lDmEmployeeTabObj.salary_mode);
            lPreparedStatement.setString(71, lDmEmployeeTabObj.pay_card_num);
            lPreparedStatement.setString(72, lDmEmployeeTabObj.bank_act_num);
            lPreparedStatement.setString(73, lDmEmployeeTabObj.father_name);
            lPreparedStatement.setString(74, lDmEmployeeTabObj.mother_name);
            lPreparedStatement.setString(75, lDmEmployeeTabObj.spouse_name);
            lPreparedStatement.setString(76, lDmEmployeeTabObj.p_address_1);
            lPreparedStatement.setString(77, lDmEmployeeTabObj.p_address_2);
            lPreparedStatement.setString(78, lDmEmployeeTabObj.p_city);
            lPreparedStatement.setString(79, lDmEmployeeTabObj.p_state);
            lPreparedStatement.setString(80, lDmEmployeeTabObj.p_zip);
            lPreparedStatement.setString(81, lDmEmployeeTabObj.p_country);
            lPreparedStatement.setString(82, lDmEmployeeTabObj.m_address_1);
            lPreparedStatement.setString(83, lDmEmployeeTabObj.m_address_2);
            lPreparedStatement.setString(84, lDmEmployeeTabObj.m_city);
            lPreparedStatement.setString(85, lDmEmployeeTabObj.m_state);
            lPreparedStatement.setString(86, lDmEmployeeTabObj.m_zip);
            lPreparedStatement.setString(87, lDmEmployeeTabObj.m_country);
            lPreparedStatement.setString(88, lDmEmployeeTabObj.hospital_id);
            lPreparedStatement.setString(89, lDmEmployeeTabObj.course_id);
            lPreparedStatement.setString(90, lDmEmployeeTabObj.course_stream);
            lPreparedStatement.setString(91, lDmEmployeeTabObj.emp_track_id);
            lPreparedStatement.setString(92, lDmEmployeeTabObj.allocation_sts);
            lPreparedStatement.setString(93, lDmEmployeeTabObj.release_date);
            lPreparedStatement.setString(94, lDmEmployeeTabObj.rp_id);
              lPreparedStatement.setDouble(95, lDmEmployeeTabObj.billing_rate);
              lPreparedStatement.setDouble(96, lDmEmployeeTabObj.paying_rate);
            lPreparedStatement.setString(97, lDmEmployeeTabObj.pf_nominee_1);
            lPreparedStatement.setString(98, lDmEmployeeTabObj.pf_nominee_2);
            lPreparedStatement.setString(99, lDmEmployeeTabObj.esi_nominee_1);
            lPreparedStatement.setString(100, lDmEmployeeTabObj.esi_nominee_2);
              lPreparedStatement.setDouble(101, lDmEmployeeTabObj.pf_nominee_1_percent);
              lPreparedStatement.setDouble(102, lDmEmployeeTabObj.pf_nominee_2_percent);
              lPreparedStatement.setDouble(103, lDmEmployeeTabObj.esi_nominee_1_percent);
              lPreparedStatement.setDouble(104, lDmEmployeeTabObj.esi_nominee_2_percent);
            lPreparedStatement.setString(105, lDmEmployeeTabObj.rec_status);
            lPreparedStatement.setString(106, lDmEmployeeTabObj.rec_cre_date);
            lPreparedStatement.setString(107, lDmEmployeeTabObj.rec_cre_time);
            lPreparedStatement.setString(108, lDmEmployeeTabObj.rec_upd_date);
            lPreparedStatement.setString(109, lDmEmployeeTabObj.rec_upd_time);
            lPreparedStatement.setString(110, lDmEmployeeTabObj.file_name);
            lPreparedStatement.setString(111, lDmEmployeeTabObj.file_cre_date);
            lPreparedStatement.setString(112, lDmEmployeeTabObj.file_cre_time);
            lPreparedStatement.setString(113, lDmEmployeeTabObj.file_status);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popDmEmployeeReq2Obj
               ( HttpServletRequest inRequest
               , DmEmployeeTabObj  outDmEmployeeTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outDmEmployeeTabObj.tab_rowid = lTabRowidValue;

    outDmEmployeeTabObj.org_id = inRequest.getParameter("org_id");
    outDmEmployeeTabObj.customer_id = inRequest.getParameter("customer_id");
    outDmEmployeeTabObj.employee_id = inRequest.getParameter("employee_id");
    outDmEmployeeTabObj.allocation_date = inRequest.getParameter("allocation_date");
    outDmEmployeeTabObj.name_initials = inRequest.getParameter("name_initials");
    outDmEmployeeTabObj.employee_f_name = inRequest.getParameter("employee_f_name");
    outDmEmployeeTabObj.employee_m_name = inRequest.getParameter("employee_m_name");
    outDmEmployeeTabObj.employee_l_name = inRequest.getParameter("employee_l_name");
    outDmEmployeeTabObj.employee_short_name = inRequest.getParameter("employee_short_name");
    outDmEmployeeTabObj.emp_type = inRequest.getParameter("emp_type");
    outDmEmployeeTabObj.emp_ctg = inRequest.getParameter("emp_ctg");
    outDmEmployeeTabObj.reporting_head_id = inRequest.getParameter("reporting_head_id");
    outDmEmployeeTabObj.dept_id = inRequest.getParameter("dept_id");
    outDmEmployeeTabObj.logical_group_id = inRequest.getParameter("logical_group_id");
    outDmEmployeeTabObj.position_id = inRequest.getParameter("position_id");
    outDmEmployeeTabObj.level_id = inRequest.getParameter("level_id");
    outDmEmployeeTabObj.designation = inRequest.getParameter("designation");
    outDmEmployeeTabObj.doj = inRequest.getParameter("doj");
    outDmEmployeeTabObj.dot = inRequest.getParameter("dot");
    outDmEmployeeTabObj.project_id = inRequest.getParameter("project_id");
    outDmEmployeeTabObj.shift_code = inRequest.getParameter("shift_code");
    outDmEmployeeTabObj.cycle_code = inRequest.getParameter("cycle_code");
    outDmEmployeeTabObj.phone = inRequest.getParameter("phone");
    outDmEmployeeTabObj.ext = inRequest.getParameter("ext");
    outDmEmployeeTabObj.email_id = inRequest.getParameter("email_id");
    outDmEmployeeTabObj.building_id = inRequest.getParameter("building_id");
    outDmEmployeeTabObj.floor_num = inRequest.getParameter("floor_num");
    outDmEmployeeTabObj.room_num = inRequest.getParameter("room_num");
    outDmEmployeeTabObj.cubical_num = inRequest.getParameter("cubical_num");
    outDmEmployeeTabObj.emp_status = inRequest.getParameter("emp_status");
    outDmEmployeeTabObj.emp_status_date = inRequest.getParameter("emp_status_date");
    outDmEmployeeTabObj.emp_agreement_sts = inRequest.getParameter("emp_agreement_sts");
    outDmEmployeeTabObj.emp_agreement_sts_date = inRequest.getParameter("emp_agreement_sts_date");
    outDmEmployeeTabObj.country = inRequest.getParameter("country");
    outDmEmployeeTabObj.recruit_req_id = inRequest.getParameter("recruit_req_id");
    outDmEmployeeTabObj.work_org_id = inRequest.getParameter("work_org_id");
    outDmEmployeeTabObj.marital_status = inRequest.getParameter("marital_status");
    outDmEmployeeTabObj.pan_ind = inRequest.getParameter("pan_ind");
    outDmEmployeeTabObj.pf_ind = inRequest.getParameter("pf_ind");
    outDmEmployeeTabObj.esi_ind = inRequest.getParameter("esi_ind");
    outDmEmployeeTabObj.pan_num = inRequest.getParameter("pan_num");
    outDmEmployeeTabObj.pan_create_date = inRequest.getParameter("pan_create_date");
    outDmEmployeeTabObj.epf_act_num = inRequest.getParameter("epf_act_num");
    outDmEmployeeTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt");
    outDmEmployeeTabObj.epf_act_close_dt = inRequest.getParameter("epf_act_close_dt");
    outDmEmployeeTabObj.prev_epf_act_num = inRequest.getParameter("prev_epf_act_num");
    outDmEmployeeTabObj.prev_epf_act_open_dt = inRequest.getParameter("prev_epf_act_open_dt");
    outDmEmployeeTabObj.prev_epf_act_close_dt = inRequest.getParameter("prev_epf_act_close_dt");
    outDmEmployeeTabObj.esi_num = inRequest.getParameter("esi_num");
    outDmEmployeeTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt");
    outDmEmployeeTabObj.esi_act_close_dt = inRequest.getParameter("esi_act_close_dt");
    outDmEmployeeTabObj.prev_esi_num = inRequest.getParameter("prev_esi_num");
    outDmEmployeeTabObj.prev_esi_num_open_dt = inRequest.getParameter("prev_esi_num_open_dt");
    outDmEmployeeTabObj.prev_esi_num_close_dt = inRequest.getParameter("prev_esi_num_close_dt");
    outDmEmployeeTabObj.nss_num = inRequest.getParameter("nss_num");
    outDmEmployeeTabObj.nss_create_date = inRequest.getParameter("nss_create_date");
    outDmEmployeeTabObj.gender = inRequest.getParameter("gender");
    outDmEmployeeTabObj.dob = inRequest.getParameter("dob");
    outDmEmployeeTabObj.birth_city = inRequest.getParameter("birth_city");
    outDmEmployeeTabObj.birth_country = inRequest.getParameter("birth_country");
    outDmEmployeeTabObj.barcode = inRequest.getParameter("barcode");
    outDmEmployeeTabObj.user_id = inRequest.getParameter("user_id");
    outDmEmployeeTabObj.pswd_0 = inRequest.getParameter("pswd_0");
    outDmEmployeeTabObj.relation_type = inRequest.getParameter("relation_type");
    outDmEmployeeTabObj.relative_name = inRequest.getParameter("relative_name");
    outDmEmployeeTabObj.applicant_id = inRequest.getParameter("applicant_id");
    if ( inRequest.getParameter("emp_card_id") == null )
      outDmEmployeeTabObj.emp_card_id = 0;
    else
    if ( inRequest.getParameter("emp_card_id").trim().length() == 0 )
      outDmEmployeeTabObj.emp_card_id = 0;
    else
      outDmEmployeeTabObj.emp_card_id = Integer.parseInt( inRequest.getParameter("emp_card_id"));
    outDmEmployeeTabObj.banker_code = inRequest.getParameter("banker_code");
    outDmEmployeeTabObj.banker_name = inRequest.getParameter("banker_name");
    outDmEmployeeTabObj.salary_mode = inRequest.getParameter("salary_mode");
    outDmEmployeeTabObj.pay_card_num = inRequest.getParameter("pay_card_num");
    outDmEmployeeTabObj.bank_act_num = inRequest.getParameter("bank_act_num");
    outDmEmployeeTabObj.father_name = inRequest.getParameter("father_name");
    outDmEmployeeTabObj.mother_name = inRequest.getParameter("mother_name");
    outDmEmployeeTabObj.spouse_name = inRequest.getParameter("spouse_name");
    outDmEmployeeTabObj.p_address_1 = inRequest.getParameter("p_address_1");
    outDmEmployeeTabObj.p_address_2 = inRequest.getParameter("p_address_2");
    outDmEmployeeTabObj.p_city = inRequest.getParameter("p_city");
    outDmEmployeeTabObj.p_state = inRequest.getParameter("p_state");
    outDmEmployeeTabObj.p_zip = inRequest.getParameter("p_zip");
    outDmEmployeeTabObj.p_country = inRequest.getParameter("p_country");
    outDmEmployeeTabObj.m_address_1 = inRequest.getParameter("m_address_1");
    outDmEmployeeTabObj.m_address_2 = inRequest.getParameter("m_address_2");
    outDmEmployeeTabObj.m_city = inRequest.getParameter("m_city");
    outDmEmployeeTabObj.m_state = inRequest.getParameter("m_state");
    outDmEmployeeTabObj.m_zip = inRequest.getParameter("m_zip");
    outDmEmployeeTabObj.m_country = inRequest.getParameter("m_country");
    outDmEmployeeTabObj.hospital_id = inRequest.getParameter("hospital_id");
    outDmEmployeeTabObj.course_id = inRequest.getParameter("course_id");
    outDmEmployeeTabObj.course_stream = inRequest.getParameter("course_stream");
    outDmEmployeeTabObj.emp_track_id = inRequest.getParameter("emp_track_id");
    outDmEmployeeTabObj.allocation_sts = inRequest.getParameter("allocation_sts");
    outDmEmployeeTabObj.release_date = inRequest.getParameter("release_date");
    outDmEmployeeTabObj.rp_id = inRequest.getParameter("rp_id");
    if ( inRequest.getParameter("billing_rate") == null )
      outDmEmployeeTabObj.billing_rate = 0;
    else
    if ( inRequest.getParameter("billing_rate").trim().length() == 0 )
      outDmEmployeeTabObj.billing_rate = 0;
    else
      outDmEmployeeTabObj.billing_rate = Double.parseDouble( inRequest.getParameter("billing_rate"));
    if ( inRequest.getParameter("paying_rate") == null )
      outDmEmployeeTabObj.paying_rate = 0;
    else
    if ( inRequest.getParameter("paying_rate").trim().length() == 0 )
      outDmEmployeeTabObj.paying_rate = 0;
    else
      outDmEmployeeTabObj.paying_rate = Double.parseDouble( inRequest.getParameter("paying_rate"));
    outDmEmployeeTabObj.pf_nominee_1 = inRequest.getParameter("pf_nominee_1");
    outDmEmployeeTabObj.pf_nominee_2 = inRequest.getParameter("pf_nominee_2");
    outDmEmployeeTabObj.esi_nominee_1 = inRequest.getParameter("esi_nominee_1");
    outDmEmployeeTabObj.esi_nominee_2 = inRequest.getParameter("esi_nominee_2");
    if ( inRequest.getParameter("pf_nominee_1_percent") == null )
      outDmEmployeeTabObj.pf_nominee_1_percent = 0;
    else
    if ( inRequest.getParameter("pf_nominee_1_percent").trim().length() == 0 )
      outDmEmployeeTabObj.pf_nominee_1_percent = 0;
    else
      outDmEmployeeTabObj.pf_nominee_1_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_1_percent"));
    if ( inRequest.getParameter("pf_nominee_2_percent") == null )
      outDmEmployeeTabObj.pf_nominee_2_percent = 0;
    else
    if ( inRequest.getParameter("pf_nominee_2_percent").trim().length() == 0 )
      outDmEmployeeTabObj.pf_nominee_2_percent = 0;
    else
      outDmEmployeeTabObj.pf_nominee_2_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_2_percent"));
    if ( inRequest.getParameter("esi_nominee_1_percent") == null )
      outDmEmployeeTabObj.esi_nominee_1_percent = 0;
    else
    if ( inRequest.getParameter("esi_nominee_1_percent").trim().length() == 0 )
      outDmEmployeeTabObj.esi_nominee_1_percent = 0;
    else
      outDmEmployeeTabObj.esi_nominee_1_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_1_percent"));
    if ( inRequest.getParameter("esi_nominee_2_percent") == null )
      outDmEmployeeTabObj.esi_nominee_2_percent = 0;
    else
    if ( inRequest.getParameter("esi_nominee_2_percent").trim().length() == 0 )
      outDmEmployeeTabObj.esi_nominee_2_percent = 0;
    else
      outDmEmployeeTabObj.esi_nominee_2_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_2_percent"));
    outDmEmployeeTabObj.rec_status = inRequest.getParameter("rec_status");
    outDmEmployeeTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outDmEmployeeTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outDmEmployeeTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outDmEmployeeTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outDmEmployeeTabObj.file_name = inRequest.getParameter("file_name");
    outDmEmployeeTabObj.file_cre_date = inRequest.getParameter("file_cre_date");
    outDmEmployeeTabObj.file_cre_time = inRequest.getParameter("file_cre_time");
    outDmEmployeeTabObj.file_status = inRequest.getParameter("file_status");
    return lReturnValue;
  }


  public int popDmEmployeeReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmEmployeeTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmEmployeeTabObj lDmEmployeeTabObj= new DmEmployeeTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmEmployeeTabObj.tab_rowid = lTabRowidValue;

      lDmEmployeeTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lDmEmployeeTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
      lDmEmployeeTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
      lDmEmployeeTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
      lDmEmployeeTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
      lDmEmployeeTabObj.employee_f_name = inRequest.getParameter("employee_f_name_r"+lNumRec);
      lDmEmployeeTabObj.employee_m_name = inRequest.getParameter("employee_m_name_r"+lNumRec);
      lDmEmployeeTabObj.employee_l_name = inRequest.getParameter("employee_l_name_r"+lNumRec);
      lDmEmployeeTabObj.employee_short_name = inRequest.getParameter("employee_short_name_r"+lNumRec);
      lDmEmployeeTabObj.emp_type = inRequest.getParameter("emp_type_r"+lNumRec);
      lDmEmployeeTabObj.emp_ctg = inRequest.getParameter("emp_ctg_r"+lNumRec);
      lDmEmployeeTabObj.reporting_head_id = inRequest.getParameter("reporting_head_id_r"+lNumRec);
      lDmEmployeeTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
      lDmEmployeeTabObj.logical_group_id = inRequest.getParameter("logical_group_id_r"+lNumRec);
      lDmEmployeeTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
      lDmEmployeeTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
      lDmEmployeeTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
      lDmEmployeeTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
      lDmEmployeeTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
      lDmEmployeeTabObj.project_id = inRequest.getParameter("project_id_r"+lNumRec);
      lDmEmployeeTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
      lDmEmployeeTabObj.cycle_code = inRequest.getParameter("cycle_code_r"+lNumRec);
      lDmEmployeeTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
      lDmEmployeeTabObj.ext = inRequest.getParameter("ext_r"+lNumRec);
      lDmEmployeeTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
      lDmEmployeeTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
      lDmEmployeeTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
      lDmEmployeeTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
      lDmEmployeeTabObj.cubical_num = inRequest.getParameter("cubical_num_r"+lNumRec);
      lDmEmployeeTabObj.emp_status = inRequest.getParameter("emp_status_r"+lNumRec);
      lDmEmployeeTabObj.emp_status_date = inRequest.getParameter("emp_status_date_r"+lNumRec);
      lDmEmployeeTabObj.emp_agreement_sts = inRequest.getParameter("emp_agreement_sts_r"+lNumRec);
      lDmEmployeeTabObj.emp_agreement_sts_date = inRequest.getParameter("emp_agreement_sts_date_r"+lNumRec);
      lDmEmployeeTabObj.country = inRequest.getParameter("country_r"+lNumRec);
      lDmEmployeeTabObj.recruit_req_id = inRequest.getParameter("recruit_req_id_r"+lNumRec);
      lDmEmployeeTabObj.work_org_id = inRequest.getParameter("work_org_id_r"+lNumRec);
      lDmEmployeeTabObj.marital_status = inRequest.getParameter("marital_status_r"+lNumRec);
      lDmEmployeeTabObj.pan_ind = inRequest.getParameter("pan_ind_r"+lNumRec);
      lDmEmployeeTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
      lDmEmployeeTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
      lDmEmployeeTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
      lDmEmployeeTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
      lDmEmployeeTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
      lDmEmployeeTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
      lDmEmployeeTabObj.epf_act_close_dt = inRequest.getParameter("epf_act_close_dt_r"+lNumRec);
      lDmEmployeeTabObj.prev_epf_act_num = inRequest.getParameter("prev_epf_act_num_r"+lNumRec);
      lDmEmployeeTabObj.prev_epf_act_open_dt = inRequest.getParameter("prev_epf_act_open_dt_r"+lNumRec);
      lDmEmployeeTabObj.prev_epf_act_close_dt = inRequest.getParameter("prev_epf_act_close_dt_r"+lNumRec);
      lDmEmployeeTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
      lDmEmployeeTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
      lDmEmployeeTabObj.esi_act_close_dt = inRequest.getParameter("esi_act_close_dt_r"+lNumRec);
      lDmEmployeeTabObj.prev_esi_num = inRequest.getParameter("prev_esi_num_r"+lNumRec);
      lDmEmployeeTabObj.prev_esi_num_open_dt = inRequest.getParameter("prev_esi_num_open_dt_r"+lNumRec);
      lDmEmployeeTabObj.prev_esi_num_close_dt = inRequest.getParameter("prev_esi_num_close_dt_r"+lNumRec);
      lDmEmployeeTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
      lDmEmployeeTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
      lDmEmployeeTabObj.gender = inRequest.getParameter("gender_r"+lNumRec);
      lDmEmployeeTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
      lDmEmployeeTabObj.birth_city = inRequest.getParameter("birth_city_r"+lNumRec);
      lDmEmployeeTabObj.birth_country = inRequest.getParameter("birth_country_r"+lNumRec);
      lDmEmployeeTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
      lDmEmployeeTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
      lDmEmployeeTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
      lDmEmployeeTabObj.relation_type = inRequest.getParameter("relation_type_r"+lNumRec);
      lDmEmployeeTabObj.relative_name = inRequest.getParameter("relative_name_r"+lNumRec);
      lDmEmployeeTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
      if ( inRequest.getParameter("emp_card_id_r"+lNumRec) == null )
        lDmEmployeeTabObj.emp_card_id = 0;
      else
      if ( inRequest.getParameter("emp_card_id_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.emp_card_id = 0;
      else
        lDmEmployeeTabObj.emp_card_id = Integer.parseInt( inRequest.getParameter("emp_card_id_r"+lNumRec));
      lDmEmployeeTabObj.banker_code = inRequest.getParameter("banker_code_r"+lNumRec);
      lDmEmployeeTabObj.banker_name = inRequest.getParameter("banker_name_r"+lNumRec);
      lDmEmployeeTabObj.salary_mode = inRequest.getParameter("salary_mode_r"+lNumRec);
      lDmEmployeeTabObj.pay_card_num = inRequest.getParameter("pay_card_num_r"+lNumRec);
      lDmEmployeeTabObj.bank_act_num = inRequest.getParameter("bank_act_num_r"+lNumRec);
      lDmEmployeeTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
      lDmEmployeeTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
      lDmEmployeeTabObj.spouse_name = inRequest.getParameter("spouse_name_r"+lNumRec);
      lDmEmployeeTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
      lDmEmployeeTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
      lDmEmployeeTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
      lDmEmployeeTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
      lDmEmployeeTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
      lDmEmployeeTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
      lDmEmployeeTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
      lDmEmployeeTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
      lDmEmployeeTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
      lDmEmployeeTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
      lDmEmployeeTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
      lDmEmployeeTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
      lDmEmployeeTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
      lDmEmployeeTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
      lDmEmployeeTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
      lDmEmployeeTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
      lDmEmployeeTabObj.allocation_sts = inRequest.getParameter("allocation_sts_r"+lNumRec);
      lDmEmployeeTabObj.release_date = inRequest.getParameter("release_date_r"+lNumRec);
      lDmEmployeeTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
      if ( inRequest.getParameter("billing_rate_r"+lNumRec) == null )
        lDmEmployeeTabObj.billing_rate = 0;
      else
      if ( inRequest.getParameter("billing_rate_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.billing_rate = 0;
      else
        lDmEmployeeTabObj.billing_rate = Double.parseDouble( inRequest.getParameter("billing_rate_r"+lNumRec));
      if ( inRequest.getParameter("paying_rate_r"+lNumRec) == null )
        lDmEmployeeTabObj.paying_rate = 0;
      else
      if ( inRequest.getParameter("paying_rate_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.paying_rate = 0;
      else
        lDmEmployeeTabObj.paying_rate = Double.parseDouble( inRequest.getParameter("paying_rate_r"+lNumRec));
      lDmEmployeeTabObj.pf_nominee_1 = inRequest.getParameter("pf_nominee_1_r"+lNumRec);
      lDmEmployeeTabObj.pf_nominee_2 = inRequest.getParameter("pf_nominee_2_r"+lNumRec);
      lDmEmployeeTabObj.esi_nominee_1 = inRequest.getParameter("esi_nominee_1_r"+lNumRec);
      lDmEmployeeTabObj.esi_nominee_2 = inRequest.getParameter("esi_nominee_2_r"+lNumRec);
      if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec) == null )
        lDmEmployeeTabObj.pf_nominee_1_percent = 0;
      else
      if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.pf_nominee_1_percent = 0;
      else
        lDmEmployeeTabObj.pf_nominee_1_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec));
      if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec) == null )
        lDmEmployeeTabObj.pf_nominee_2_percent = 0;
      else
      if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.pf_nominee_2_percent = 0;
      else
        lDmEmployeeTabObj.pf_nominee_2_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec));
      if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec) == null )
        lDmEmployeeTabObj.esi_nominee_1_percent = 0;
      else
      if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.esi_nominee_1_percent = 0;
      else
        lDmEmployeeTabObj.esi_nominee_1_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec));
      if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec) == null )
        lDmEmployeeTabObj.esi_nominee_2_percent = 0;
      else
      if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
        lDmEmployeeTabObj.esi_nominee_2_percent = 0;
      else
        lDmEmployeeTabObj.esi_nominee_2_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec));
      lDmEmployeeTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
      lDmEmployeeTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lDmEmployeeTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lDmEmployeeTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lDmEmployeeTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lDmEmployeeTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
      lDmEmployeeTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
      lDmEmployeeTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
      lDmEmployeeTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      outDmEmployeeTabObjArr.add( lDmEmployeeTabObj);
    }
    return lReturnValue;
  }


  public int popDmEmployeeReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , DmEmployeeTabObj outDmEmployeeTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_employee_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outDmEmployeeTabObj.tab_rowid = lTabRowidValue;

        outDmEmployeeTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outDmEmployeeTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        outDmEmployeeTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
        outDmEmployeeTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
        outDmEmployeeTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        outDmEmployeeTabObj.employee_f_name = inRequest.getParameter("employee_f_name_r"+lNumRec);
        outDmEmployeeTabObj.employee_m_name = inRequest.getParameter("employee_m_name_r"+lNumRec);
        outDmEmployeeTabObj.employee_l_name = inRequest.getParameter("employee_l_name_r"+lNumRec);
        outDmEmployeeTabObj.employee_short_name = inRequest.getParameter("employee_short_name_r"+lNumRec);
        outDmEmployeeTabObj.emp_type = inRequest.getParameter("emp_type_r"+lNumRec);
        outDmEmployeeTabObj.emp_ctg = inRequest.getParameter("emp_ctg_r"+lNumRec);
        outDmEmployeeTabObj.reporting_head_id = inRequest.getParameter("reporting_head_id_r"+lNumRec);
        outDmEmployeeTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        outDmEmployeeTabObj.logical_group_id = inRequest.getParameter("logical_group_id_r"+lNumRec);
        outDmEmployeeTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        outDmEmployeeTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        outDmEmployeeTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
        outDmEmployeeTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
        outDmEmployeeTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
        outDmEmployeeTabObj.project_id = inRequest.getParameter("project_id_r"+lNumRec);
        outDmEmployeeTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
        outDmEmployeeTabObj.cycle_code = inRequest.getParameter("cycle_code_r"+lNumRec);
        outDmEmployeeTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
        outDmEmployeeTabObj.ext = inRequest.getParameter("ext_r"+lNumRec);
        outDmEmployeeTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        outDmEmployeeTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        outDmEmployeeTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        outDmEmployeeTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        outDmEmployeeTabObj.cubical_num = inRequest.getParameter("cubical_num_r"+lNumRec);
        outDmEmployeeTabObj.emp_status = inRequest.getParameter("emp_status_r"+lNumRec);
        outDmEmployeeTabObj.emp_status_date = inRequest.getParameter("emp_status_date_r"+lNumRec);
        outDmEmployeeTabObj.emp_agreement_sts = inRequest.getParameter("emp_agreement_sts_r"+lNumRec);
        outDmEmployeeTabObj.emp_agreement_sts_date = inRequest.getParameter("emp_agreement_sts_date_r"+lNumRec);
        outDmEmployeeTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        outDmEmployeeTabObj.recruit_req_id = inRequest.getParameter("recruit_req_id_r"+lNumRec);
        outDmEmployeeTabObj.work_org_id = inRequest.getParameter("work_org_id_r"+lNumRec);
        outDmEmployeeTabObj.marital_status = inRequest.getParameter("marital_status_r"+lNumRec);
        outDmEmployeeTabObj.pan_ind = inRequest.getParameter("pan_ind_r"+lNumRec);
        outDmEmployeeTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
        outDmEmployeeTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
        outDmEmployeeTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        outDmEmployeeTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
        outDmEmployeeTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
        outDmEmployeeTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
        outDmEmployeeTabObj.epf_act_close_dt = inRequest.getParameter("epf_act_close_dt_r"+lNumRec);
        outDmEmployeeTabObj.prev_epf_act_num = inRequest.getParameter("prev_epf_act_num_r"+lNumRec);
        outDmEmployeeTabObj.prev_epf_act_open_dt = inRequest.getParameter("prev_epf_act_open_dt_r"+lNumRec);
        outDmEmployeeTabObj.prev_epf_act_close_dt = inRequest.getParameter("prev_epf_act_close_dt_r"+lNumRec);
        outDmEmployeeTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
        outDmEmployeeTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
        outDmEmployeeTabObj.esi_act_close_dt = inRequest.getParameter("esi_act_close_dt_r"+lNumRec);
        outDmEmployeeTabObj.prev_esi_num = inRequest.getParameter("prev_esi_num_r"+lNumRec);
        outDmEmployeeTabObj.prev_esi_num_open_dt = inRequest.getParameter("prev_esi_num_open_dt_r"+lNumRec);
        outDmEmployeeTabObj.prev_esi_num_close_dt = inRequest.getParameter("prev_esi_num_close_dt_r"+lNumRec);
        outDmEmployeeTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
        outDmEmployeeTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
        outDmEmployeeTabObj.gender = inRequest.getParameter("gender_r"+lNumRec);
        outDmEmployeeTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        outDmEmployeeTabObj.birth_city = inRequest.getParameter("birth_city_r"+lNumRec);
        outDmEmployeeTabObj.birth_country = inRequest.getParameter("birth_country_r"+lNumRec);
        outDmEmployeeTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
        outDmEmployeeTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
        outDmEmployeeTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        outDmEmployeeTabObj.relation_type = inRequest.getParameter("relation_type_r"+lNumRec);
        outDmEmployeeTabObj.relative_name = inRequest.getParameter("relative_name_r"+lNumRec);
        outDmEmployeeTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        if ( inRequest.getParameter("emp_card_id_r"+lNumRec) == null )
          outDmEmployeeTabObj.emp_card_id = 0;
        else
        if ( inRequest.getParameter("emp_card_id_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.emp_card_id = 0;
        else
          outDmEmployeeTabObj.emp_card_id = Integer.parseInt( inRequest.getParameter("emp_card_id_r"+lNumRec));
        outDmEmployeeTabObj.banker_code = inRequest.getParameter("banker_code_r"+lNumRec);
        outDmEmployeeTabObj.banker_name = inRequest.getParameter("banker_name_r"+lNumRec);
        outDmEmployeeTabObj.salary_mode = inRequest.getParameter("salary_mode_r"+lNumRec);
        outDmEmployeeTabObj.pay_card_num = inRequest.getParameter("pay_card_num_r"+lNumRec);
        outDmEmployeeTabObj.bank_act_num = inRequest.getParameter("bank_act_num_r"+lNumRec);
        outDmEmployeeTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        outDmEmployeeTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        outDmEmployeeTabObj.spouse_name = inRequest.getParameter("spouse_name_r"+lNumRec);
        outDmEmployeeTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        outDmEmployeeTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        outDmEmployeeTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        outDmEmployeeTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        outDmEmployeeTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        outDmEmployeeTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        outDmEmployeeTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        outDmEmployeeTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        outDmEmployeeTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        outDmEmployeeTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        outDmEmployeeTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        outDmEmployeeTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        outDmEmployeeTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
        outDmEmployeeTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        outDmEmployeeTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        outDmEmployeeTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
        outDmEmployeeTabObj.allocation_sts = inRequest.getParameter("allocation_sts_r"+lNumRec);
        outDmEmployeeTabObj.release_date = inRequest.getParameter("release_date_r"+lNumRec);
        outDmEmployeeTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
        if ( inRequest.getParameter("billing_rate_r"+lNumRec) == null )
          outDmEmployeeTabObj.billing_rate = 0;
        else
        if ( inRequest.getParameter("billing_rate_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.billing_rate = 0;
        else
          outDmEmployeeTabObj.billing_rate = Double.parseDouble( inRequest.getParameter("billing_rate_r"+lNumRec));
        if ( inRequest.getParameter("paying_rate_r"+lNumRec) == null )
          outDmEmployeeTabObj.paying_rate = 0;
        else
        if ( inRequest.getParameter("paying_rate_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.paying_rate = 0;
        else
          outDmEmployeeTabObj.paying_rate = Double.parseDouble( inRequest.getParameter("paying_rate_r"+lNumRec));
        outDmEmployeeTabObj.pf_nominee_1 = inRequest.getParameter("pf_nominee_1_r"+lNumRec);
        outDmEmployeeTabObj.pf_nominee_2 = inRequest.getParameter("pf_nominee_2_r"+lNumRec);
        outDmEmployeeTabObj.esi_nominee_1 = inRequest.getParameter("esi_nominee_1_r"+lNumRec);
        outDmEmployeeTabObj.esi_nominee_2 = inRequest.getParameter("esi_nominee_2_r"+lNumRec);
        if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec) == null )
          outDmEmployeeTabObj.pf_nominee_1_percent = 0;
        else
        if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.pf_nominee_1_percent = 0;
        else
          outDmEmployeeTabObj.pf_nominee_1_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec));
        if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec) == null )
          outDmEmployeeTabObj.pf_nominee_2_percent = 0;
        else
        if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.pf_nominee_2_percent = 0;
        else
          outDmEmployeeTabObj.pf_nominee_2_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec));
        if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec) == null )
          outDmEmployeeTabObj.esi_nominee_1_percent = 0;
        else
        if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.esi_nominee_1_percent = 0;
        else
          outDmEmployeeTabObj.esi_nominee_1_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec));
        if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec) == null )
          outDmEmployeeTabObj.esi_nominee_2_percent = 0;
        else
        if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
          outDmEmployeeTabObj.esi_nominee_2_percent = 0;
        else
          outDmEmployeeTabObj.esi_nominee_2_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec));
        outDmEmployeeTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        outDmEmployeeTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outDmEmployeeTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outDmEmployeeTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outDmEmployeeTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outDmEmployeeTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        outDmEmployeeTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        outDmEmployeeTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        outDmEmployeeTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popDmEmployeeReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmEmployeeTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmEmployeeTabObj lDmEmployeeTabObj= new DmEmployeeTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_employee_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmEmployeeTabObj.tab_rowid = lTabRowidValue;

        lDmEmployeeTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lDmEmployeeTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        lDmEmployeeTabObj.employee_id = inRequest.getParameter("employee_id_r"+lNumRec);
        lDmEmployeeTabObj.allocation_date = inRequest.getParameter("allocation_date_r"+lNumRec);
        lDmEmployeeTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        lDmEmployeeTabObj.employee_f_name = inRequest.getParameter("employee_f_name_r"+lNumRec);
        lDmEmployeeTabObj.employee_m_name = inRequest.getParameter("employee_m_name_r"+lNumRec);
        lDmEmployeeTabObj.employee_l_name = inRequest.getParameter("employee_l_name_r"+lNumRec);
        lDmEmployeeTabObj.employee_short_name = inRequest.getParameter("employee_short_name_r"+lNumRec);
        lDmEmployeeTabObj.emp_type = inRequest.getParameter("emp_type_r"+lNumRec);
        lDmEmployeeTabObj.emp_ctg = inRequest.getParameter("emp_ctg_r"+lNumRec);
        lDmEmployeeTabObj.reporting_head_id = inRequest.getParameter("reporting_head_id_r"+lNumRec);
        lDmEmployeeTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        lDmEmployeeTabObj.logical_group_id = inRequest.getParameter("logical_group_id_r"+lNumRec);
        lDmEmployeeTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        lDmEmployeeTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        lDmEmployeeTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
        lDmEmployeeTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
        lDmEmployeeTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
        lDmEmployeeTabObj.project_id = inRequest.getParameter("project_id_r"+lNumRec);
        lDmEmployeeTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
        lDmEmployeeTabObj.cycle_code = inRequest.getParameter("cycle_code_r"+lNumRec);
        lDmEmployeeTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
        lDmEmployeeTabObj.ext = inRequest.getParameter("ext_r"+lNumRec);
        lDmEmployeeTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        lDmEmployeeTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        lDmEmployeeTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        lDmEmployeeTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        lDmEmployeeTabObj.cubical_num = inRequest.getParameter("cubical_num_r"+lNumRec);
        lDmEmployeeTabObj.emp_status = inRequest.getParameter("emp_status_r"+lNumRec);
        lDmEmployeeTabObj.emp_status_date = inRequest.getParameter("emp_status_date_r"+lNumRec);
        lDmEmployeeTabObj.emp_agreement_sts = inRequest.getParameter("emp_agreement_sts_r"+lNumRec);
        lDmEmployeeTabObj.emp_agreement_sts_date = inRequest.getParameter("emp_agreement_sts_date_r"+lNumRec);
        lDmEmployeeTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        lDmEmployeeTabObj.recruit_req_id = inRequest.getParameter("recruit_req_id_r"+lNumRec);
        lDmEmployeeTabObj.work_org_id = inRequest.getParameter("work_org_id_r"+lNumRec);
        lDmEmployeeTabObj.marital_status = inRequest.getParameter("marital_status_r"+lNumRec);
        lDmEmployeeTabObj.pan_ind = inRequest.getParameter("pan_ind_r"+lNumRec);
        lDmEmployeeTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
        lDmEmployeeTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
        lDmEmployeeTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        lDmEmployeeTabObj.pan_create_date = inRequest.getParameter("pan_create_date_r"+lNumRec);
        lDmEmployeeTabObj.epf_act_num = inRequest.getParameter("epf_act_num_r"+lNumRec);
        lDmEmployeeTabObj.epf_act_open_dt = inRequest.getParameter("epf_act_open_dt_r"+lNumRec);
        lDmEmployeeTabObj.epf_act_close_dt = inRequest.getParameter("epf_act_close_dt_r"+lNumRec);
        lDmEmployeeTabObj.prev_epf_act_num = inRequest.getParameter("prev_epf_act_num_r"+lNumRec);
        lDmEmployeeTabObj.prev_epf_act_open_dt = inRequest.getParameter("prev_epf_act_open_dt_r"+lNumRec);
        lDmEmployeeTabObj.prev_epf_act_close_dt = inRequest.getParameter("prev_epf_act_close_dt_r"+lNumRec);
        lDmEmployeeTabObj.esi_num = inRequest.getParameter("esi_num_r"+lNumRec);
        lDmEmployeeTabObj.esi_act_open_dt = inRequest.getParameter("esi_act_open_dt_r"+lNumRec);
        lDmEmployeeTabObj.esi_act_close_dt = inRequest.getParameter("esi_act_close_dt_r"+lNumRec);
        lDmEmployeeTabObj.prev_esi_num = inRequest.getParameter("prev_esi_num_r"+lNumRec);
        lDmEmployeeTabObj.prev_esi_num_open_dt = inRequest.getParameter("prev_esi_num_open_dt_r"+lNumRec);
        lDmEmployeeTabObj.prev_esi_num_close_dt = inRequest.getParameter("prev_esi_num_close_dt_r"+lNumRec);
        lDmEmployeeTabObj.nss_num = inRequest.getParameter("nss_num_r"+lNumRec);
        lDmEmployeeTabObj.nss_create_date = inRequest.getParameter("nss_create_date_r"+lNumRec);
        lDmEmployeeTabObj.gender = inRequest.getParameter("gender_r"+lNumRec);
        lDmEmployeeTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        lDmEmployeeTabObj.birth_city = inRequest.getParameter("birth_city_r"+lNumRec);
        lDmEmployeeTabObj.birth_country = inRequest.getParameter("birth_country_r"+lNumRec);
        lDmEmployeeTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
        lDmEmployeeTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
        lDmEmployeeTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        lDmEmployeeTabObj.relation_type = inRequest.getParameter("relation_type_r"+lNumRec);
        lDmEmployeeTabObj.relative_name = inRequest.getParameter("relative_name_r"+lNumRec);
        lDmEmployeeTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        if ( inRequest.getParameter("emp_card_id_r"+lNumRec) == null )
          lDmEmployeeTabObj.emp_card_id = 0;
        else
        if ( inRequest.getParameter("emp_card_id_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.emp_card_id = 0;
        else
          lDmEmployeeTabObj.emp_card_id = Integer.parseInt( inRequest.getParameter("emp_card_id_r"+lNumRec));
        lDmEmployeeTabObj.banker_code = inRequest.getParameter("banker_code_r"+lNumRec);
        lDmEmployeeTabObj.banker_name = inRequest.getParameter("banker_name_r"+lNumRec);
        lDmEmployeeTabObj.salary_mode = inRequest.getParameter("salary_mode_r"+lNumRec);
        lDmEmployeeTabObj.pay_card_num = inRequest.getParameter("pay_card_num_r"+lNumRec);
        lDmEmployeeTabObj.bank_act_num = inRequest.getParameter("bank_act_num_r"+lNumRec);
        lDmEmployeeTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        lDmEmployeeTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        lDmEmployeeTabObj.spouse_name = inRequest.getParameter("spouse_name_r"+lNumRec);
        lDmEmployeeTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        lDmEmployeeTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        lDmEmployeeTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        lDmEmployeeTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        lDmEmployeeTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        lDmEmployeeTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        lDmEmployeeTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        lDmEmployeeTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        lDmEmployeeTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        lDmEmployeeTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        lDmEmployeeTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        lDmEmployeeTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        lDmEmployeeTabObj.hospital_id = inRequest.getParameter("hospital_id_r"+lNumRec);
        lDmEmployeeTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        lDmEmployeeTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        lDmEmployeeTabObj.emp_track_id = inRequest.getParameter("emp_track_id_r"+lNumRec);
        lDmEmployeeTabObj.allocation_sts = inRequest.getParameter("allocation_sts_r"+lNumRec);
        lDmEmployeeTabObj.release_date = inRequest.getParameter("release_date_r"+lNumRec);
        lDmEmployeeTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
        if ( inRequest.getParameter("billing_rate_r"+lNumRec) == null )
          lDmEmployeeTabObj.billing_rate = 0;
        else
        if ( inRequest.getParameter("billing_rate_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.billing_rate = 0;
        else
            lDmEmployeeTabObj.billing_rate = Double.parseDouble( inRequest.getParameter("billing_rate_r"+lNumRec));
        if ( inRequest.getParameter("paying_rate_r"+lNumRec) == null )
          lDmEmployeeTabObj.paying_rate = 0;
        else
        if ( inRequest.getParameter("paying_rate_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.paying_rate = 0;
        else
            lDmEmployeeTabObj.paying_rate = Double.parseDouble( inRequest.getParameter("paying_rate_r"+lNumRec));
        lDmEmployeeTabObj.pf_nominee_1 = inRequest.getParameter("pf_nominee_1_r"+lNumRec);
        lDmEmployeeTabObj.pf_nominee_2 = inRequest.getParameter("pf_nominee_2_r"+lNumRec);
        lDmEmployeeTabObj.esi_nominee_1 = inRequest.getParameter("esi_nominee_1_r"+lNumRec);
        lDmEmployeeTabObj.esi_nominee_2 = inRequest.getParameter("esi_nominee_2_r"+lNumRec);
        if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec) == null )
          lDmEmployeeTabObj.pf_nominee_1_percent = 0;
        else
        if ( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.pf_nominee_1_percent = 0;
        else
            lDmEmployeeTabObj.pf_nominee_1_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_1_percent_r"+lNumRec));
        if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec) == null )
          lDmEmployeeTabObj.pf_nominee_2_percent = 0;
        else
        if ( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.pf_nominee_2_percent = 0;
        else
            lDmEmployeeTabObj.pf_nominee_2_percent = Double.parseDouble( inRequest.getParameter("pf_nominee_2_percent_r"+lNumRec));
        if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec) == null )
          lDmEmployeeTabObj.esi_nominee_1_percent = 0;
        else
        if ( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.esi_nominee_1_percent = 0;
        else
            lDmEmployeeTabObj.esi_nominee_1_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_1_percent_r"+lNumRec));
        if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec) == null )
          lDmEmployeeTabObj.esi_nominee_2_percent = 0;
        else
        if ( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec).trim().length() == 0 )
          lDmEmployeeTabObj.esi_nominee_2_percent = 0;
        else
            lDmEmployeeTabObj.esi_nominee_2_percent = Double.parseDouble( inRequest.getParameter("esi_nominee_2_percent_r"+lNumRec));
        lDmEmployeeTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        lDmEmployeeTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lDmEmployeeTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lDmEmployeeTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lDmEmployeeTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lDmEmployeeTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        lDmEmployeeTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        lDmEmployeeTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        lDmEmployeeTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
        outDmEmployeeTabObjArr.add( lDmEmployeeTabObj);
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeRecByRowid
               ( String inRowId
               , DmEmployeeTabObj  inDmEmployeeTabObj
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeTabObj.allocation_date != null && inDmEmployeeTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.doj != null && inDmEmployeeTabObj.doj.length() > 0 ) 
            inDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.doj, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dot != null && inDmEmployeeTabObj.dot.length() > 0 ) 
            inDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dot, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_status_date != null && inDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_status_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_agreement_sts_date != null && inDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.pan_create_date != null && inDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            inDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_open_dt != null && inDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_close_dt != null && inDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null && inDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null && inDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_open_dt != null && inDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_close_dt != null && inDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null && inDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null && inDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.nss_create_date != null && inDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            inDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.nss_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dob != null && inDmEmployeeTabObj.dob.length() > 0 ) 
            inDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dob, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.release_date != null && inDmEmployeeTabObj.release_date.length() > 0 ) 
            inDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.release_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_cre_date != null && inDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_upd_date != null && inDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.file_cre_date != null && inDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inDmEmployeeTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmEmployeeTabObj.org_id+"', ";
      if ( inDmEmployeeTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmEmployeeTabObj.customer_id+"', ";
      if ( inDmEmployeeTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = "+"'"+inDmEmployeeTabObj.employee_id+"', ";
      if ( inDmEmployeeTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = "+"'"+inDmEmployeeTabObj.allocation_date+"', ";
      if ( inDmEmployeeTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inDmEmployeeTabObj.name_initials+"', ";
      if ( inDmEmployeeTabObj.employee_f_name != null  )         lSqlStmt = lSqlStmt + "employee_f_name = "+"'"+inDmEmployeeTabObj.employee_f_name+"', ";
      if ( inDmEmployeeTabObj.employee_m_name != null  )         lSqlStmt = lSqlStmt + "employee_m_name = "+"'"+inDmEmployeeTabObj.employee_m_name+"', ";
      if ( inDmEmployeeTabObj.employee_l_name != null  )         lSqlStmt = lSqlStmt + "employee_l_name = "+"'"+inDmEmployeeTabObj.employee_l_name+"', ";
      if ( inDmEmployeeTabObj.employee_short_name != null  )         lSqlStmt = lSqlStmt + "employee_short_name = "+"'"+inDmEmployeeTabObj.employee_short_name+"', ";
      if ( inDmEmployeeTabObj.emp_type != null  )         lSqlStmt = lSqlStmt + "emp_type = "+"'"+inDmEmployeeTabObj.emp_type+"', ";
      if ( inDmEmployeeTabObj.emp_ctg != null  )         lSqlStmt = lSqlStmt + "emp_ctg = "+"'"+inDmEmployeeTabObj.emp_ctg+"', ";
      if ( inDmEmployeeTabObj.reporting_head_id != null  )         lSqlStmt = lSqlStmt + "reporting_head_id = "+"'"+inDmEmployeeTabObj.reporting_head_id+"', ";
      if ( inDmEmployeeTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmEmployeeTabObj.dept_id+"', ";
      if ( inDmEmployeeTabObj.logical_group_id != null  )         lSqlStmt = lSqlStmt + "logical_group_id = "+"'"+inDmEmployeeTabObj.logical_group_id+"', ";
      if ( inDmEmployeeTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmEmployeeTabObj.position_id+"', ";
      if ( inDmEmployeeTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmEmployeeTabObj.level_id+"', ";
      if ( inDmEmployeeTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = "+"'"+inDmEmployeeTabObj.designation+"', ";
      if ( inDmEmployeeTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = "+"'"+inDmEmployeeTabObj.doj+"', ";
      if ( inDmEmployeeTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = "+"'"+inDmEmployeeTabObj.dot+"', ";
      if ( inDmEmployeeTabObj.project_id != null  )         lSqlStmt = lSqlStmt + "project_id = "+"'"+inDmEmployeeTabObj.project_id+"', ";
      if ( inDmEmployeeTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = "+"'"+inDmEmployeeTabObj.shift_code+"', ";
      if ( inDmEmployeeTabObj.cycle_code != null  )         lSqlStmt = lSqlStmt + "cycle_code = "+"'"+inDmEmployeeTabObj.cycle_code+"', ";
      if ( inDmEmployeeTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = "+"'"+inDmEmployeeTabObj.phone+"', ";
      if ( inDmEmployeeTabObj.ext != null  )         lSqlStmt = lSqlStmt + "ext = "+"'"+inDmEmployeeTabObj.ext+"', ";
      if ( inDmEmployeeTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inDmEmployeeTabObj.email_id+"', ";
      if ( inDmEmployeeTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inDmEmployeeTabObj.building_id+"', ";
      if ( inDmEmployeeTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inDmEmployeeTabObj.floor_num+"', ";
      if ( inDmEmployeeTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inDmEmployeeTabObj.room_num+"', ";
      if ( inDmEmployeeTabObj.cubical_num != null  )         lSqlStmt = lSqlStmt + "cubical_num = "+"'"+inDmEmployeeTabObj.cubical_num+"', ";
      if ( inDmEmployeeTabObj.emp_status != null  )         lSqlStmt = lSqlStmt + "emp_status = "+"'"+inDmEmployeeTabObj.emp_status+"', ";
      if ( inDmEmployeeTabObj.emp_status_date != null  )         lSqlStmt = lSqlStmt + "emp_status_date = "+"'"+inDmEmployeeTabObj.emp_status_date+"', ";
      if ( inDmEmployeeTabObj.emp_agreement_sts != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts = "+"'"+inDmEmployeeTabObj.emp_agreement_sts+"', ";
      if ( inDmEmployeeTabObj.emp_agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts_date = "+"'"+inDmEmployeeTabObj.emp_agreement_sts_date+"', ";
      if ( inDmEmployeeTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inDmEmployeeTabObj.country+"', ";
      if ( inDmEmployeeTabObj.recruit_req_id != null  )         lSqlStmt = lSqlStmt + "recruit_req_id = "+"'"+inDmEmployeeTabObj.recruit_req_id+"', ";
      if ( inDmEmployeeTabObj.work_org_id != null  )         lSqlStmt = lSqlStmt + "work_org_id = "+"'"+inDmEmployeeTabObj.work_org_id+"', ";
      if ( inDmEmployeeTabObj.marital_status != null  )         lSqlStmt = lSqlStmt + "marital_status = "+"'"+inDmEmployeeTabObj.marital_status+"', ";
      if ( inDmEmployeeTabObj.pan_ind != null  )         lSqlStmt = lSqlStmt + "pan_ind = "+"'"+inDmEmployeeTabObj.pan_ind+"', ";
      if ( inDmEmployeeTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = "+"'"+inDmEmployeeTabObj.pf_ind+"', ";
      if ( inDmEmployeeTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = "+"'"+inDmEmployeeTabObj.esi_ind+"', ";
      if ( inDmEmployeeTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inDmEmployeeTabObj.pan_num+"', ";
      if ( inDmEmployeeTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = "+"'"+inDmEmployeeTabObj.pan_create_date+"', ";
      if ( inDmEmployeeTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = "+"'"+inDmEmployeeTabObj.epf_act_num+"', ";
      if ( inDmEmployeeTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = "+"'"+inDmEmployeeTabObj.epf_act_open_dt+"', ";
      if ( inDmEmployeeTabObj.epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_close_dt = "+"'"+inDmEmployeeTabObj.epf_act_close_dt+"', ";
      if ( inDmEmployeeTabObj.prev_epf_act_num != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_num = "+"'"+inDmEmployeeTabObj.prev_epf_act_num+"', ";
      if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_open_dt = "+"'"+inDmEmployeeTabObj.prev_epf_act_open_dt+"', ";
      if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_close_dt = "+"'"+inDmEmployeeTabObj.prev_epf_act_close_dt+"', ";
      if ( inDmEmployeeTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = "+"'"+inDmEmployeeTabObj.esi_num+"', ";
      if ( inDmEmployeeTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = "+"'"+inDmEmployeeTabObj.esi_act_open_dt+"', ";
      if ( inDmEmployeeTabObj.esi_act_close_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_close_dt = "+"'"+inDmEmployeeTabObj.esi_act_close_dt+"', ";
      if ( inDmEmployeeTabObj.prev_esi_num != null  )         lSqlStmt = lSqlStmt + "prev_esi_num = "+"'"+inDmEmployeeTabObj.prev_esi_num+"', ";
      if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_open_dt = "+"'"+inDmEmployeeTabObj.prev_esi_num_open_dt+"', ";
      if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_close_dt = "+"'"+inDmEmployeeTabObj.prev_esi_num_close_dt+"', ";
      if ( inDmEmployeeTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = "+"'"+inDmEmployeeTabObj.nss_num+"', ";
      if ( inDmEmployeeTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = "+"'"+inDmEmployeeTabObj.nss_create_date+"', ";
      if ( inDmEmployeeTabObj.gender != null  )         lSqlStmt = lSqlStmt + "gender = "+"'"+inDmEmployeeTabObj.gender+"', ";
      if ( inDmEmployeeTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inDmEmployeeTabObj.dob+"', ";
      if ( inDmEmployeeTabObj.birth_city != null  )         lSqlStmt = lSqlStmt + "birth_city = "+"'"+inDmEmployeeTabObj.birth_city+"', ";
      if ( inDmEmployeeTabObj.birth_country != null  )         lSqlStmt = lSqlStmt + "birth_country = "+"'"+inDmEmployeeTabObj.birth_country+"', ";
      if ( inDmEmployeeTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = "+"'"+inDmEmployeeTabObj.barcode+"', ";
      if ( inDmEmployeeTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = "+"'"+inDmEmployeeTabObj.user_id+"', ";
      if ( inDmEmployeeTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inDmEmployeeTabObj.pswd_0+"', ";
      if ( inDmEmployeeTabObj.relation_type != null  )         lSqlStmt = lSqlStmt + "relation_type = "+"'"+inDmEmployeeTabObj.relation_type+"', ";
      if ( inDmEmployeeTabObj.relative_name != null  )         lSqlStmt = lSqlStmt + "relative_name = "+"'"+inDmEmployeeTabObj.relative_name+"', ";
      if ( inDmEmployeeTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inDmEmployeeTabObj.applicant_id+"', ";
             lSqlStmt = lSqlStmt + "emp_card_id = "+inDmEmployeeTabObj.emp_card_id+", ";
      if ( inDmEmployeeTabObj.banker_code != null  )         lSqlStmt = lSqlStmt + "banker_code = "+"'"+inDmEmployeeTabObj.banker_code+"', ";
      if ( inDmEmployeeTabObj.banker_name != null  )         lSqlStmt = lSqlStmt + "banker_name = "+"'"+inDmEmployeeTabObj.banker_name+"', ";
      if ( inDmEmployeeTabObj.salary_mode != null  )         lSqlStmt = lSqlStmt + "salary_mode = "+"'"+inDmEmployeeTabObj.salary_mode+"', ";
      if ( inDmEmployeeTabObj.pay_card_num != null  )         lSqlStmt = lSqlStmt + "pay_card_num = "+"'"+inDmEmployeeTabObj.pay_card_num+"', ";
      if ( inDmEmployeeTabObj.bank_act_num != null  )         lSqlStmt = lSqlStmt + "bank_act_num = "+"'"+inDmEmployeeTabObj.bank_act_num+"', ";
      if ( inDmEmployeeTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inDmEmployeeTabObj.father_name+"', ";
      if ( inDmEmployeeTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inDmEmployeeTabObj.mother_name+"', ";
      if ( inDmEmployeeTabObj.spouse_name != null  )         lSqlStmt = lSqlStmt + "spouse_name = "+"'"+inDmEmployeeTabObj.spouse_name+"', ";
      if ( inDmEmployeeTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inDmEmployeeTabObj.p_address_1+"', ";
      if ( inDmEmployeeTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inDmEmployeeTabObj.p_address_2+"', ";
      if ( inDmEmployeeTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inDmEmployeeTabObj.p_city+"', ";
      if ( inDmEmployeeTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inDmEmployeeTabObj.p_state+"', ";
      if ( inDmEmployeeTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inDmEmployeeTabObj.p_zip+"', ";
      if ( inDmEmployeeTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inDmEmployeeTabObj.p_country+"', ";
      if ( inDmEmployeeTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inDmEmployeeTabObj.m_address_1+"', ";
      if ( inDmEmployeeTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inDmEmployeeTabObj.m_address_2+"', ";
      if ( inDmEmployeeTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inDmEmployeeTabObj.m_city+"', ";
      if ( inDmEmployeeTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inDmEmployeeTabObj.m_state+"', ";
      if ( inDmEmployeeTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inDmEmployeeTabObj.m_zip+"', ";
      if ( inDmEmployeeTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inDmEmployeeTabObj.m_country+"', ";
      if ( inDmEmployeeTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = "+"'"+inDmEmployeeTabObj.hospital_id+"', ";
      if ( inDmEmployeeTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inDmEmployeeTabObj.course_id+"', ";
      if ( inDmEmployeeTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inDmEmployeeTabObj.course_stream+"', ";
      if ( inDmEmployeeTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = "+"'"+inDmEmployeeTabObj.emp_track_id+"', ";
      if ( inDmEmployeeTabObj.allocation_sts != null  )         lSqlStmt = lSqlStmt + "allocation_sts = "+"'"+inDmEmployeeTabObj.allocation_sts+"', ";
      if ( inDmEmployeeTabObj.release_date != null  )         lSqlStmt = lSqlStmt + "release_date = "+"'"+inDmEmployeeTabObj.release_date+"', ";
      if ( inDmEmployeeTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = "+"'"+inDmEmployeeTabObj.rp_id+"', ";
             lSqlStmt = lSqlStmt + "billing_rate = "+inDmEmployeeTabObj.billing_rate+", ";
             lSqlStmt = lSqlStmt + "paying_rate = "+inDmEmployeeTabObj.paying_rate+", ";
      if ( inDmEmployeeTabObj.pf_nominee_1 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_1 = "+"'"+inDmEmployeeTabObj.pf_nominee_1+"', ";
      if ( inDmEmployeeTabObj.pf_nominee_2 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_2 = "+"'"+inDmEmployeeTabObj.pf_nominee_2+"', ";
      if ( inDmEmployeeTabObj.esi_nominee_1 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_1 = "+"'"+inDmEmployeeTabObj.esi_nominee_1+"', ";
      if ( inDmEmployeeTabObj.esi_nominee_2 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_2 = "+"'"+inDmEmployeeTabObj.esi_nominee_2+"', ";
             lSqlStmt = lSqlStmt + "pf_nominee_1_percent = "+inDmEmployeeTabObj.pf_nominee_1_percent+", ";
             lSqlStmt = lSqlStmt + "pf_nominee_2_percent = "+inDmEmployeeTabObj.pf_nominee_2_percent+", ";
             lSqlStmt = lSqlStmt + "esi_nominee_1_percent = "+inDmEmployeeTabObj.esi_nominee_1_percent+", ";
             lSqlStmt = lSqlStmt + "esi_nominee_2_percent = "+inDmEmployeeTabObj.esi_nominee_2_percent+", ";
      if ( inDmEmployeeTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmEmployeeTabObj.rec_status+"', ";
      if ( inDmEmployeeTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmEmployeeTabObj.rec_cre_date+"', ";
      if ( inDmEmployeeTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmEmployeeTabObj.rec_cre_time+"', ";
      if ( inDmEmployeeTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmEmployeeTabObj.rec_upd_date+"', ";
      if ( inDmEmployeeTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmEmployeeTabObj.rec_upd_time+"', ";
      if ( inDmEmployeeTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmEmployeeTabObj.file_name+"', ";
      if ( inDmEmployeeTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmEmployeeTabObj.file_cre_date+"', ";
      if ( inDmEmployeeTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmEmployeeTabObj.file_cre_time+"', ";
      if ( inDmEmployeeTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmEmployeeTabObj.file_status+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeRecByPkey
               ( DmEmployeePkeyObj inDmEmployeePkeyObj
               , DmEmployeeTabObj  inDmEmployeeTabObj
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmEmployeeTabObj.allocation_date != null && inDmEmployeeTabObj.allocation_date.length() > 0 ) 
            inDmEmployeeTabObj.allocation_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.allocation_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.doj != null && inDmEmployeeTabObj.doj.length() > 0 ) 
            inDmEmployeeTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.doj, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dot != null && inDmEmployeeTabObj.dot.length() > 0 ) 
            inDmEmployeeTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dot, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_status_date != null && inDmEmployeeTabObj.emp_status_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_status_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.emp_agreement_sts_date != null && inDmEmployeeTabObj.emp_agreement_sts_date.length() > 0 ) 
            inDmEmployeeTabObj.emp_agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.emp_agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.pan_create_date != null && inDmEmployeeTabObj.pan_create_date.length() > 0 ) 
            inDmEmployeeTabObj.pan_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.pan_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_open_dt != null && inDmEmployeeTabObj.epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.epf_act_close_dt != null && inDmEmployeeTabObj.epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null && inDmEmployeeTabObj.prev_epf_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null && inDmEmployeeTabObj.prev_epf_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_epf_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_epf_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_open_dt != null && inDmEmployeeTabObj.esi_act_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.esi_act_close_dt != null && inDmEmployeeTabObj.esi_act_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.esi_act_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.esi_act_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null && inDmEmployeeTabObj.prev_esi_num_open_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_open_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_open_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null && inDmEmployeeTabObj.prev_esi_num_close_dt.length() > 0 ) 
            inDmEmployeeTabObj.prev_esi_num_close_dt  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.prev_esi_num_close_dt, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.nss_create_date != null && inDmEmployeeTabObj.nss_create_date.length() > 0 ) 
            inDmEmployeeTabObj.nss_create_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.nss_create_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.dob != null && inDmEmployeeTabObj.dob.length() > 0 ) 
            inDmEmployeeTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.dob, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.release_date != null && inDmEmployeeTabObj.release_date.length() > 0 ) 
            inDmEmployeeTabObj.release_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.release_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_cre_date != null && inDmEmployeeTabObj.rec_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.rec_upd_date != null && inDmEmployeeTabObj.rec_upd_date.length() > 0 ) 
            inDmEmployeeTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmEmployeeTabObj.file_cre_date != null && inDmEmployeeTabObj.file_cre_date.length() > 0 ) 
            inDmEmployeeTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmEmployeeTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inDmEmployeeTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inDmEmployeeTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = ? , ";
        if ( inDmEmployeeTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = ? , ";
        if ( inDmEmployeeTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = ? , ";
        if ( inDmEmployeeTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = ? , ";
        if ( inDmEmployeeTabObj.employee_f_name != null  )         lSqlStmt = lSqlStmt + "employee_f_name = ? , ";
        if ( inDmEmployeeTabObj.employee_m_name != null  )         lSqlStmt = lSqlStmt + "employee_m_name = ? , ";
        if ( inDmEmployeeTabObj.employee_l_name != null  )         lSqlStmt = lSqlStmt + "employee_l_name = ? , ";
        if ( inDmEmployeeTabObj.employee_short_name != null  )         lSqlStmt = lSqlStmt + "employee_short_name = ? , ";
        if ( inDmEmployeeTabObj.emp_type != null  )         lSqlStmt = lSqlStmt + "emp_type = ? , ";
        if ( inDmEmployeeTabObj.emp_ctg != null  )         lSqlStmt = lSqlStmt + "emp_ctg = ? , ";
        if ( inDmEmployeeTabObj.reporting_head_id != null  )         lSqlStmt = lSqlStmt + "reporting_head_id = ? , ";
        if ( inDmEmployeeTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = ? , ";
        if ( inDmEmployeeTabObj.logical_group_id != null  )         lSqlStmt = lSqlStmt + "logical_group_id = ? , ";
        if ( inDmEmployeeTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = ? , ";
        if ( inDmEmployeeTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = ? , ";
        if ( inDmEmployeeTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = ? , ";
        if ( inDmEmployeeTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = ? , ";
        if ( inDmEmployeeTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = ? , ";
        if ( inDmEmployeeTabObj.project_id != null  )         lSqlStmt = lSqlStmt + "project_id = ? , ";
        if ( inDmEmployeeTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = ? , ";
        if ( inDmEmployeeTabObj.cycle_code != null  )         lSqlStmt = lSqlStmt + "cycle_code = ? , ";
        if ( inDmEmployeeTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = ? , ";
        if ( inDmEmployeeTabObj.ext != null  )         lSqlStmt = lSqlStmt + "ext = ? , ";
        if ( inDmEmployeeTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = ? , ";
        if ( inDmEmployeeTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = ? , ";
        if ( inDmEmployeeTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = ? , ";
        if ( inDmEmployeeTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = ? , ";
        if ( inDmEmployeeTabObj.cubical_num != null  )         lSqlStmt = lSqlStmt + "cubical_num = ? , ";
        if ( inDmEmployeeTabObj.emp_status != null  )         lSqlStmt = lSqlStmt + "emp_status = ? , ";
        if ( inDmEmployeeTabObj.emp_status_date != null  )         lSqlStmt = lSqlStmt + "emp_status_date = ? , ";
        if ( inDmEmployeeTabObj.emp_agreement_sts != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts = ? , ";
        if ( inDmEmployeeTabObj.emp_agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts_date = ? , ";
        if ( inDmEmployeeTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = ? , ";
        if ( inDmEmployeeTabObj.recruit_req_id != null  )         lSqlStmt = lSqlStmt + "recruit_req_id = ? , ";
        if ( inDmEmployeeTabObj.work_org_id != null  )         lSqlStmt = lSqlStmt + "work_org_id = ? , ";
        if ( inDmEmployeeTabObj.marital_status != null  )         lSqlStmt = lSqlStmt + "marital_status = ? , ";
        if ( inDmEmployeeTabObj.pan_ind != null  )         lSqlStmt = lSqlStmt + "pan_ind = ? , ";
        if ( inDmEmployeeTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = ? , ";
        if ( inDmEmployeeTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = ? , ";
        if ( inDmEmployeeTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = ? , ";
        if ( inDmEmployeeTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = ? , ";
        if ( inDmEmployeeTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = ? , ";
        if ( inDmEmployeeTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = ? , ";
        if ( inDmEmployeeTabObj.epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_close_dt = ? , ";
        if ( inDmEmployeeTabObj.prev_epf_act_num != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_num = ? , ";
        if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_open_dt = ? , ";
        if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_close_dt = ? , ";
        if ( inDmEmployeeTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = ? , ";
        if ( inDmEmployeeTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = ? , ";
        if ( inDmEmployeeTabObj.esi_act_close_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_close_dt = ? , ";
        if ( inDmEmployeeTabObj.prev_esi_num != null  )         lSqlStmt = lSqlStmt + "prev_esi_num = ? , ";
        if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_open_dt = ? , ";
        if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_close_dt = ? , ";
        if ( inDmEmployeeTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = ? , ";
        if ( inDmEmployeeTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = ? , ";
        if ( inDmEmployeeTabObj.gender != null  )         lSqlStmt = lSqlStmt + "gender = ? , ";
        if ( inDmEmployeeTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = ? , ";
        if ( inDmEmployeeTabObj.birth_city != null  )         lSqlStmt = lSqlStmt + "birth_city = ? , ";
        if ( inDmEmployeeTabObj.birth_country != null  )         lSqlStmt = lSqlStmt + "birth_country = ? , ";
        if ( inDmEmployeeTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = ? , ";
        if ( inDmEmployeeTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = ? , ";
        if ( inDmEmployeeTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = ? , ";
        if ( inDmEmployeeTabObj.relation_type != null  )         lSqlStmt = lSqlStmt + "relation_type = ? , ";
        if ( inDmEmployeeTabObj.relative_name != null  )         lSqlStmt = lSqlStmt + "relative_name = ? , ";
        if ( inDmEmployeeTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = ? , ";
               lSqlStmt = lSqlStmt + "emp_card_id = ? , ";
        if ( inDmEmployeeTabObj.banker_code != null  )         lSqlStmt = lSqlStmt + "banker_code = ? , ";
        if ( inDmEmployeeTabObj.banker_name != null  )         lSqlStmt = lSqlStmt + "banker_name = ? , ";
        if ( inDmEmployeeTabObj.salary_mode != null  )         lSqlStmt = lSqlStmt + "salary_mode = ? , ";
        if ( inDmEmployeeTabObj.pay_card_num != null  )         lSqlStmt = lSqlStmt + "pay_card_num = ? , ";
        if ( inDmEmployeeTabObj.bank_act_num != null  )         lSqlStmt = lSqlStmt + "bank_act_num = ? , ";
        if ( inDmEmployeeTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = ? , ";
        if ( inDmEmployeeTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = ? , ";
        if ( inDmEmployeeTabObj.spouse_name != null  )         lSqlStmt = lSqlStmt + "spouse_name = ? , ";
        if ( inDmEmployeeTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = ? , ";
        if ( inDmEmployeeTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = ? , ";
        if ( inDmEmployeeTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = ? , ";
        if ( inDmEmployeeTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = ? , ";
        if ( inDmEmployeeTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = ? , ";
        if ( inDmEmployeeTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = ? , ";
        if ( inDmEmployeeTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = ? , ";
        if ( inDmEmployeeTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = ? , ";
        if ( inDmEmployeeTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = ? , ";
        if ( inDmEmployeeTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = ? , ";
        if ( inDmEmployeeTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = ? , ";
        if ( inDmEmployeeTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = ? , ";
        if ( inDmEmployeeTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = ? , ";
        if ( inDmEmployeeTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = ? , ";
        if ( inDmEmployeeTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = ? , ";
        if ( inDmEmployeeTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = ? , ";
        if ( inDmEmployeeTabObj.allocation_sts != null  )         lSqlStmt = lSqlStmt + "allocation_sts = ? , ";
        if ( inDmEmployeeTabObj.release_date != null  )         lSqlStmt = lSqlStmt + "release_date = ? , ";
        if ( inDmEmployeeTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = ? , ";
               lSqlStmt = lSqlStmt + "billing_rate = ? , ";
               lSqlStmt = lSqlStmt + "paying_rate = ? , ";
        if ( inDmEmployeeTabObj.pf_nominee_1 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_1 = ? , ";
        if ( inDmEmployeeTabObj.pf_nominee_2 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_2 = ? , ";
        if ( inDmEmployeeTabObj.esi_nominee_1 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_1 = ? , ";
        if ( inDmEmployeeTabObj.esi_nominee_2 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_2 = ? , ";
               lSqlStmt = lSqlStmt + "pf_nominee_1_percent = ? , ";
               lSqlStmt = lSqlStmt + "pf_nominee_2_percent = ? , ";
               lSqlStmt = lSqlStmt + "esi_nominee_1_percent = ? , ";
               lSqlStmt = lSqlStmt + "esi_nominee_2_percent = ? , ";
        if ( inDmEmployeeTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = ? , ";
        if ( inDmEmployeeTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inDmEmployeeTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inDmEmployeeTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inDmEmployeeTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inDmEmployeeTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = ? , ";
        if ( inDmEmployeeTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = ? , ";
        if ( inDmEmployeeTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = ? , ";
        if ( inDmEmployeeTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inDmEmployeeTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmEmployeeTabObj.org_id+"', ";
        if ( inDmEmployeeTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmEmployeeTabObj.customer_id+"', ";
        if ( inDmEmployeeTabObj.employee_id != null  )         lSqlStmt = lSqlStmt + "employee_id = "+"'"+inDmEmployeeTabObj.employee_id+"', ";
        if ( inDmEmployeeTabObj.allocation_date != null  )         lSqlStmt = lSqlStmt + "allocation_date = "+"'"+inDmEmployeeTabObj.allocation_date+"', ";
        if ( inDmEmployeeTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inDmEmployeeTabObj.name_initials+"', ";
        if ( inDmEmployeeTabObj.employee_f_name != null  )         lSqlStmt = lSqlStmt + "employee_f_name = "+"'"+inDmEmployeeTabObj.employee_f_name+"', ";
        if ( inDmEmployeeTabObj.employee_m_name != null  )         lSqlStmt = lSqlStmt + "employee_m_name = "+"'"+inDmEmployeeTabObj.employee_m_name+"', ";
        if ( inDmEmployeeTabObj.employee_l_name != null  )         lSqlStmt = lSqlStmt + "employee_l_name = "+"'"+inDmEmployeeTabObj.employee_l_name+"', ";
        if ( inDmEmployeeTabObj.employee_short_name != null  )         lSqlStmt = lSqlStmt + "employee_short_name = "+"'"+inDmEmployeeTabObj.employee_short_name+"', ";
        if ( inDmEmployeeTabObj.emp_type != null  )         lSqlStmt = lSqlStmt + "emp_type = "+"'"+inDmEmployeeTabObj.emp_type+"', ";
        if ( inDmEmployeeTabObj.emp_ctg != null  )         lSqlStmt = lSqlStmt + "emp_ctg = "+"'"+inDmEmployeeTabObj.emp_ctg+"', ";
        if ( inDmEmployeeTabObj.reporting_head_id != null  )         lSqlStmt = lSqlStmt + "reporting_head_id = "+"'"+inDmEmployeeTabObj.reporting_head_id+"', ";
        if ( inDmEmployeeTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmEmployeeTabObj.dept_id+"', ";
        if ( inDmEmployeeTabObj.logical_group_id != null  )         lSqlStmt = lSqlStmt + "logical_group_id = "+"'"+inDmEmployeeTabObj.logical_group_id+"', ";
        if ( inDmEmployeeTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmEmployeeTabObj.position_id+"', ";
        if ( inDmEmployeeTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmEmployeeTabObj.level_id+"', ";
        if ( inDmEmployeeTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = "+"'"+inDmEmployeeTabObj.designation+"', ";
        if ( inDmEmployeeTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = "+"'"+inDmEmployeeTabObj.doj+"', ";
        if ( inDmEmployeeTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = "+"'"+inDmEmployeeTabObj.dot+"', ";
        if ( inDmEmployeeTabObj.project_id != null  )         lSqlStmt = lSqlStmt + "project_id = "+"'"+inDmEmployeeTabObj.project_id+"', ";
        if ( inDmEmployeeTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = "+"'"+inDmEmployeeTabObj.shift_code+"', ";
        if ( inDmEmployeeTabObj.cycle_code != null  )         lSqlStmt = lSqlStmt + "cycle_code = "+"'"+inDmEmployeeTabObj.cycle_code+"', ";
        if ( inDmEmployeeTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = "+"'"+inDmEmployeeTabObj.phone+"', ";
        if ( inDmEmployeeTabObj.ext != null  )         lSqlStmt = lSqlStmt + "ext = "+"'"+inDmEmployeeTabObj.ext+"', ";
        if ( inDmEmployeeTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inDmEmployeeTabObj.email_id+"', ";
        if ( inDmEmployeeTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inDmEmployeeTabObj.building_id+"', ";
        if ( inDmEmployeeTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inDmEmployeeTabObj.floor_num+"', ";
        if ( inDmEmployeeTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inDmEmployeeTabObj.room_num+"', ";
        if ( inDmEmployeeTabObj.cubical_num != null  )         lSqlStmt = lSqlStmt + "cubical_num = "+"'"+inDmEmployeeTabObj.cubical_num+"', ";
        if ( inDmEmployeeTabObj.emp_status != null  )         lSqlStmt = lSqlStmt + "emp_status = "+"'"+inDmEmployeeTabObj.emp_status+"', ";
        if ( inDmEmployeeTabObj.emp_status_date != null  )         lSqlStmt = lSqlStmt + "emp_status_date = "+"'"+inDmEmployeeTabObj.emp_status_date+"', ";
        if ( inDmEmployeeTabObj.emp_agreement_sts != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts = "+"'"+inDmEmployeeTabObj.emp_agreement_sts+"', ";
        if ( inDmEmployeeTabObj.emp_agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "emp_agreement_sts_date = "+"'"+inDmEmployeeTabObj.emp_agreement_sts_date+"', ";
        if ( inDmEmployeeTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inDmEmployeeTabObj.country+"', ";
        if ( inDmEmployeeTabObj.recruit_req_id != null  )         lSqlStmt = lSqlStmt + "recruit_req_id = "+"'"+inDmEmployeeTabObj.recruit_req_id+"', ";
        if ( inDmEmployeeTabObj.work_org_id != null  )         lSqlStmt = lSqlStmt + "work_org_id = "+"'"+inDmEmployeeTabObj.work_org_id+"', ";
        if ( inDmEmployeeTabObj.marital_status != null  )         lSqlStmt = lSqlStmt + "marital_status = "+"'"+inDmEmployeeTabObj.marital_status+"', ";
        if ( inDmEmployeeTabObj.pan_ind != null  )         lSqlStmt = lSqlStmt + "pan_ind = "+"'"+inDmEmployeeTabObj.pan_ind+"', ";
        if ( inDmEmployeeTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = "+"'"+inDmEmployeeTabObj.pf_ind+"', ";
        if ( inDmEmployeeTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = "+"'"+inDmEmployeeTabObj.esi_ind+"', ";
        if ( inDmEmployeeTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inDmEmployeeTabObj.pan_num+"', ";
        if ( inDmEmployeeTabObj.pan_create_date != null  )         lSqlStmt = lSqlStmt + "pan_create_date = "+"'"+inDmEmployeeTabObj.pan_create_date+"', ";
        if ( inDmEmployeeTabObj.epf_act_num != null  )         lSqlStmt = lSqlStmt + "epf_act_num = "+"'"+inDmEmployeeTabObj.epf_act_num+"', ";
        if ( inDmEmployeeTabObj.epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_open_dt = "+"'"+inDmEmployeeTabObj.epf_act_open_dt+"', ";
        if ( inDmEmployeeTabObj.epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "epf_act_close_dt = "+"'"+inDmEmployeeTabObj.epf_act_close_dt+"', ";
        if ( inDmEmployeeTabObj.prev_epf_act_num != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_num = "+"'"+inDmEmployeeTabObj.prev_epf_act_num+"', ";
        if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_open_dt = "+"'"+inDmEmployeeTabObj.prev_epf_act_open_dt+"', ";
        if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_epf_act_close_dt = "+"'"+inDmEmployeeTabObj.prev_epf_act_close_dt+"', ";
        if ( inDmEmployeeTabObj.esi_num != null  )         lSqlStmt = lSqlStmt + "esi_num = "+"'"+inDmEmployeeTabObj.esi_num+"', ";
        if ( inDmEmployeeTabObj.esi_act_open_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_open_dt = "+"'"+inDmEmployeeTabObj.esi_act_open_dt+"', ";
        if ( inDmEmployeeTabObj.esi_act_close_dt != null  )         lSqlStmt = lSqlStmt + "esi_act_close_dt = "+"'"+inDmEmployeeTabObj.esi_act_close_dt+"', ";
        if ( inDmEmployeeTabObj.prev_esi_num != null  )         lSqlStmt = lSqlStmt + "prev_esi_num = "+"'"+inDmEmployeeTabObj.prev_esi_num+"', ";
        if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_open_dt = "+"'"+inDmEmployeeTabObj.prev_esi_num_open_dt+"', ";
        if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null  )         lSqlStmt = lSqlStmt + "prev_esi_num_close_dt = "+"'"+inDmEmployeeTabObj.prev_esi_num_close_dt+"', ";
        if ( inDmEmployeeTabObj.nss_num != null  )         lSqlStmt = lSqlStmt + "nss_num = "+"'"+inDmEmployeeTabObj.nss_num+"', ";
        if ( inDmEmployeeTabObj.nss_create_date != null  )         lSqlStmt = lSqlStmt + "nss_create_date = "+"'"+inDmEmployeeTabObj.nss_create_date+"', ";
        if ( inDmEmployeeTabObj.gender != null  )         lSqlStmt = lSqlStmt + "gender = "+"'"+inDmEmployeeTabObj.gender+"', ";
        if ( inDmEmployeeTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inDmEmployeeTabObj.dob+"', ";
        if ( inDmEmployeeTabObj.birth_city != null  )         lSqlStmt = lSqlStmt + "birth_city = "+"'"+inDmEmployeeTabObj.birth_city+"', ";
        if ( inDmEmployeeTabObj.birth_country != null  )         lSqlStmt = lSqlStmt + "birth_country = "+"'"+inDmEmployeeTabObj.birth_country+"', ";
        if ( inDmEmployeeTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = "+"'"+inDmEmployeeTabObj.barcode+"', ";
        if ( inDmEmployeeTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = "+"'"+inDmEmployeeTabObj.user_id+"', ";
        if ( inDmEmployeeTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inDmEmployeeTabObj.pswd_0+"', ";
        if ( inDmEmployeeTabObj.relation_type != null  )         lSqlStmt = lSqlStmt + "relation_type = "+"'"+inDmEmployeeTabObj.relation_type+"', ";
        if ( inDmEmployeeTabObj.relative_name != null  )         lSqlStmt = lSqlStmt + "relative_name = "+"'"+inDmEmployeeTabObj.relative_name+"', ";
        if ( inDmEmployeeTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inDmEmployeeTabObj.applicant_id+"', ";
               lSqlStmt = lSqlStmt + "emp_card_id = "+inDmEmployeeTabObj.emp_card_id+", ";
        if ( inDmEmployeeTabObj.banker_code != null  )         lSqlStmt = lSqlStmt + "banker_code = "+"'"+inDmEmployeeTabObj.banker_code+"', ";
        if ( inDmEmployeeTabObj.banker_name != null  )         lSqlStmt = lSqlStmt + "banker_name = "+"'"+inDmEmployeeTabObj.banker_name+"', ";
        if ( inDmEmployeeTabObj.salary_mode != null  )         lSqlStmt = lSqlStmt + "salary_mode = "+"'"+inDmEmployeeTabObj.salary_mode+"', ";
        if ( inDmEmployeeTabObj.pay_card_num != null  )         lSqlStmt = lSqlStmt + "pay_card_num = "+"'"+inDmEmployeeTabObj.pay_card_num+"', ";
        if ( inDmEmployeeTabObj.bank_act_num != null  )         lSqlStmt = lSqlStmt + "bank_act_num = "+"'"+inDmEmployeeTabObj.bank_act_num+"', ";
        if ( inDmEmployeeTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inDmEmployeeTabObj.father_name+"', ";
        if ( inDmEmployeeTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inDmEmployeeTabObj.mother_name+"', ";
        if ( inDmEmployeeTabObj.spouse_name != null  )         lSqlStmt = lSqlStmt + "spouse_name = "+"'"+inDmEmployeeTabObj.spouse_name+"', ";
        if ( inDmEmployeeTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inDmEmployeeTabObj.p_address_1+"', ";
        if ( inDmEmployeeTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inDmEmployeeTabObj.p_address_2+"', ";
        if ( inDmEmployeeTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inDmEmployeeTabObj.p_city+"', ";
        if ( inDmEmployeeTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inDmEmployeeTabObj.p_state+"', ";
        if ( inDmEmployeeTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inDmEmployeeTabObj.p_zip+"', ";
        if ( inDmEmployeeTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inDmEmployeeTabObj.p_country+"', ";
        if ( inDmEmployeeTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inDmEmployeeTabObj.m_address_1+"', ";
        if ( inDmEmployeeTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inDmEmployeeTabObj.m_address_2+"', ";
        if ( inDmEmployeeTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inDmEmployeeTabObj.m_city+"', ";
        if ( inDmEmployeeTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inDmEmployeeTabObj.m_state+"', ";
        if ( inDmEmployeeTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inDmEmployeeTabObj.m_zip+"', ";
        if ( inDmEmployeeTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inDmEmployeeTabObj.m_country+"', ";
        if ( inDmEmployeeTabObj.hospital_id != null  )         lSqlStmt = lSqlStmt + "hospital_id = "+"'"+inDmEmployeeTabObj.hospital_id+"', ";
        if ( inDmEmployeeTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inDmEmployeeTabObj.course_id+"', ";
        if ( inDmEmployeeTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inDmEmployeeTabObj.course_stream+"', ";
        if ( inDmEmployeeTabObj.emp_track_id != null  )         lSqlStmt = lSqlStmt + "emp_track_id = "+"'"+inDmEmployeeTabObj.emp_track_id+"', ";
        if ( inDmEmployeeTabObj.allocation_sts != null  )         lSqlStmt = lSqlStmt + "allocation_sts = "+"'"+inDmEmployeeTabObj.allocation_sts+"', ";
        if ( inDmEmployeeTabObj.release_date != null  )         lSqlStmt = lSqlStmt + "release_date = "+"'"+inDmEmployeeTabObj.release_date+"', ";
        if ( inDmEmployeeTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = "+"'"+inDmEmployeeTabObj.rp_id+"', ";
               lSqlStmt = lSqlStmt + "billing_rate = "+inDmEmployeeTabObj.billing_rate+", ";
               lSqlStmt = lSqlStmt + "paying_rate = "+inDmEmployeeTabObj.paying_rate+", ";
        if ( inDmEmployeeTabObj.pf_nominee_1 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_1 = "+"'"+inDmEmployeeTabObj.pf_nominee_1+"', ";
        if ( inDmEmployeeTabObj.pf_nominee_2 != null  )         lSqlStmt = lSqlStmt + "pf_nominee_2 = "+"'"+inDmEmployeeTabObj.pf_nominee_2+"', ";
        if ( inDmEmployeeTabObj.esi_nominee_1 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_1 = "+"'"+inDmEmployeeTabObj.esi_nominee_1+"', ";
        if ( inDmEmployeeTabObj.esi_nominee_2 != null  )         lSqlStmt = lSqlStmt + "esi_nominee_2 = "+"'"+inDmEmployeeTabObj.esi_nominee_2+"', ";
               lSqlStmt = lSqlStmt + "pf_nominee_1_percent = "+inDmEmployeeTabObj.pf_nominee_1_percent+", ";
               lSqlStmt = lSqlStmt + "pf_nominee_2_percent = "+inDmEmployeeTabObj.pf_nominee_2_percent+", ";
               lSqlStmt = lSqlStmt + "esi_nominee_1_percent = "+inDmEmployeeTabObj.esi_nominee_1_percent+", ";
               lSqlStmt = lSqlStmt + "esi_nominee_2_percent = "+inDmEmployeeTabObj.esi_nominee_2_percent+", ";
        if ( inDmEmployeeTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmEmployeeTabObj.rec_status+"', ";
        if ( inDmEmployeeTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmEmployeeTabObj.rec_cre_date+"', ";
        if ( inDmEmployeeTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmEmployeeTabObj.rec_cre_time+"', ";
        if ( inDmEmployeeTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmEmployeeTabObj.rec_upd_date+"', ";
        if ( inDmEmployeeTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmEmployeeTabObj.rec_upd_time+"', ";
        if ( inDmEmployeeTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmEmployeeTabObj.file_name+"', ";
        if ( inDmEmployeeTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmEmployeeTabObj.file_cre_date+"', ";
        if ( inDmEmployeeTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmEmployeeTabObj.file_cre_time+"', ";
        if ( inDmEmployeeTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmEmployeeTabObj.file_status+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeePkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeePkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeePkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeePkeyObj.allocation_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inDmEmployeeTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.org_id); } 
         if ( inDmEmployeeTabObj.customer_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.customer_id); } 
         if ( inDmEmployeeTabObj.employee_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.employee_id); } 
         if ( inDmEmployeeTabObj.allocation_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.allocation_date); } 
         if ( inDmEmployeeTabObj.name_initials != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.name_initials); } 
         if ( inDmEmployeeTabObj.employee_f_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.employee_f_name); } 
         if ( inDmEmployeeTabObj.employee_m_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.employee_m_name); } 
         if ( inDmEmployeeTabObj.employee_l_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.employee_l_name); } 
         if ( inDmEmployeeTabObj.employee_short_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.employee_short_name); } 
         if ( inDmEmployeeTabObj.emp_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_type); } 
         if ( inDmEmployeeTabObj.emp_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_ctg); } 
         if ( inDmEmployeeTabObj.reporting_head_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.reporting_head_id); } 
         if ( inDmEmployeeTabObj.dept_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.dept_id); } 
         if ( inDmEmployeeTabObj.logical_group_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.logical_group_id); } 
         if ( inDmEmployeeTabObj.position_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.position_id); } 
         if ( inDmEmployeeTabObj.level_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.level_id); } 
         if ( inDmEmployeeTabObj.designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.designation); } 
         if ( inDmEmployeeTabObj.doj != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.doj); } 
         if ( inDmEmployeeTabObj.dot != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.dot); } 
         if ( inDmEmployeeTabObj.project_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.project_id); } 
         if ( inDmEmployeeTabObj.shift_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.shift_code); } 
         if ( inDmEmployeeTabObj.cycle_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.cycle_code); } 
         if ( inDmEmployeeTabObj.phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.phone); } 
         if ( inDmEmployeeTabObj.ext != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.ext); } 
         if ( inDmEmployeeTabObj.email_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.email_id); } 
         if ( inDmEmployeeTabObj.building_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.building_id); } 
         if ( inDmEmployeeTabObj.floor_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.floor_num); } 
         if ( inDmEmployeeTabObj.room_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.room_num); } 
         if ( inDmEmployeeTabObj.cubical_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.cubical_num); } 
         if ( inDmEmployeeTabObj.emp_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_status); } 
         if ( inDmEmployeeTabObj.emp_status_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_status_date); } 
         if ( inDmEmployeeTabObj.emp_agreement_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_agreement_sts); } 
         if ( inDmEmployeeTabObj.emp_agreement_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_agreement_sts_date); } 
         if ( inDmEmployeeTabObj.country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.country); } 
         if ( inDmEmployeeTabObj.recruit_req_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.recruit_req_id); } 
         if ( inDmEmployeeTabObj.work_org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.work_org_id); } 
         if ( inDmEmployeeTabObj.marital_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.marital_status); } 
         if ( inDmEmployeeTabObj.pan_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pan_ind); } 
         if ( inDmEmployeeTabObj.pf_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pf_ind); } 
         if ( inDmEmployeeTabObj.esi_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_ind); } 
         if ( inDmEmployeeTabObj.pan_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pan_num); } 
         if ( inDmEmployeeTabObj.pan_create_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pan_create_date); } 
         if ( inDmEmployeeTabObj.epf_act_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.epf_act_num); } 
         if ( inDmEmployeeTabObj.epf_act_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.epf_act_open_dt); } 
         if ( inDmEmployeeTabObj.epf_act_close_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.epf_act_close_dt); } 
         if ( inDmEmployeeTabObj.prev_epf_act_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_epf_act_num); } 
         if ( inDmEmployeeTabObj.prev_epf_act_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_epf_act_open_dt); } 
         if ( inDmEmployeeTabObj.prev_epf_act_close_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_epf_act_close_dt); } 
         if ( inDmEmployeeTabObj.esi_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_num); } 
         if ( inDmEmployeeTabObj.esi_act_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_act_open_dt); } 
         if ( inDmEmployeeTabObj.esi_act_close_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_act_close_dt); } 
         if ( inDmEmployeeTabObj.prev_esi_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_esi_num); } 
         if ( inDmEmployeeTabObj.prev_esi_num_open_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_esi_num_open_dt); } 
         if ( inDmEmployeeTabObj.prev_esi_num_close_dt != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.prev_esi_num_close_dt); } 
         if ( inDmEmployeeTabObj.nss_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.nss_num); } 
         if ( inDmEmployeeTabObj.nss_create_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.nss_create_date); } 
         if ( inDmEmployeeTabObj.gender != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.gender); } 
         if ( inDmEmployeeTabObj.dob != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.dob); } 
         if ( inDmEmployeeTabObj.birth_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.birth_city); } 
         if ( inDmEmployeeTabObj.birth_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.birth_country); } 
         if ( inDmEmployeeTabObj.barcode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.barcode); } 
         if ( inDmEmployeeTabObj.user_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.user_id); } 
         if ( inDmEmployeeTabObj.pswd_0 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pswd_0); } 
         if ( inDmEmployeeTabObj.relation_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.relation_type); } 
         if ( inDmEmployeeTabObj.relative_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.relative_name); } 
         if ( inDmEmployeeTabObj.applicant_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.applicant_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(67, inDmEmployeeTabObj.emp_card_id);
         if ( inDmEmployeeTabObj.banker_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.banker_code); } 
         if ( inDmEmployeeTabObj.banker_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.banker_name); } 
         if ( inDmEmployeeTabObj.salary_mode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.salary_mode); } 
         if ( inDmEmployeeTabObj.pay_card_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pay_card_num); } 
         if ( inDmEmployeeTabObj.bank_act_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.bank_act_num); } 
         if ( inDmEmployeeTabObj.father_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.father_name); } 
         if ( inDmEmployeeTabObj.mother_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.mother_name); } 
         if ( inDmEmployeeTabObj.spouse_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.spouse_name); } 
         if ( inDmEmployeeTabObj.p_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_address_1); } 
         if ( inDmEmployeeTabObj.p_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_address_2); } 
         if ( inDmEmployeeTabObj.p_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_city); } 
         if ( inDmEmployeeTabObj.p_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_state); } 
         if ( inDmEmployeeTabObj.p_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_zip); } 
         if ( inDmEmployeeTabObj.p_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.p_country); } 
         if ( inDmEmployeeTabObj.m_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_address_1); } 
         if ( inDmEmployeeTabObj.m_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_address_2); } 
         if ( inDmEmployeeTabObj.m_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_city); } 
         if ( inDmEmployeeTabObj.m_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_state); } 
         if ( inDmEmployeeTabObj.m_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_zip); } 
         if ( inDmEmployeeTabObj.m_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.m_country); } 
         if ( inDmEmployeeTabObj.hospital_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.hospital_id); } 
         if ( inDmEmployeeTabObj.course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.course_id); } 
         if ( inDmEmployeeTabObj.course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.course_stream); } 
         if ( inDmEmployeeTabObj.emp_track_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.emp_track_id); } 
         if ( inDmEmployeeTabObj.allocation_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.allocation_sts); } 
         if ( inDmEmployeeTabObj.release_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.release_date); } 
         if ( inDmEmployeeTabObj.rp_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rp_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(95, inDmEmployeeTabObj.billing_rate);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(96, inDmEmployeeTabObj.paying_rate);
         if ( inDmEmployeeTabObj.pf_nominee_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pf_nominee_1); } 
         if ( inDmEmployeeTabObj.pf_nominee_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.pf_nominee_2); } 
         if ( inDmEmployeeTabObj.esi_nominee_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_nominee_1); } 
         if ( inDmEmployeeTabObj.esi_nominee_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.esi_nominee_2); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(101, inDmEmployeeTabObj.pf_nominee_1_percent);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(102, inDmEmployeeTabObj.pf_nominee_2_percent);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(103, inDmEmployeeTabObj.esi_nominee_1_percent);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(104, inDmEmployeeTabObj.esi_nominee_2_percent);
         if ( inDmEmployeeTabObj.rec_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rec_status); } 
         if ( inDmEmployeeTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rec_cre_date); } 
         if ( inDmEmployeeTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rec_cre_time); } 
         if ( inDmEmployeeTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rec_upd_date); } 
         if ( inDmEmployeeTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.rec_upd_time); } 
         if ( inDmEmployeeTabObj.file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.file_name); } 
         if ( inDmEmployeeTabObj.file_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.file_cre_date); } 
         if ( inDmEmployeeTabObj.file_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.file_cre_time); } 
         if ( inDmEmployeeTabObj.file_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmEmployeeTabObj.file_status); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   DM_EMPLOYEE "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeRecByPkeyWithSet
               ( DmEmployeePkeyObj inDmEmployeePkeyObj
               , String  inDmEmployeeSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmEmployeeSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeePkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeePkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeePkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeePkeyObj.allocation_date+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeRecByRowidWithSet
               ( String inRowId
               , String  inDmEmployeeSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmEmployeeSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmEmployeeRecByWhereWithSet
               ( String inDmEmployeeWhereText
               , String  inDmEmployeeSetlist
               )
  {
    int lUpdateCount;
    sop("updDmEmployeeRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmEmployeeRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_EMPLOYEE ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inDmEmployeeSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeRecByPkey
               ( DmEmployeePkeyObj  inDmEmployeePkeyObj
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   DM_EMPLOYEE " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmEmployeePkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmEmployeePkeyObj.customer_id+"' and "+
                              "employee_id = "+"'"+inDmEmployeePkeyObj.employee_id+"' and "+
                              "allocation_date = "+"'"+inDmEmployeePkeyObj.allocation_date+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmEmployeeByWhere
               ( String inDmEmployeeWhereText
               )
  {
    int lUpdateCount;
    sop("delDmEmployeeByWhere - Started");
    gSSTErrorObj.sourceMethod = "delDmEmployeeByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmEmployeeWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmEmployeeWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   DM_EMPLOYEE "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
