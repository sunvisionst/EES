
var lDmSrcFileTabObjJSArr = new Array();
<%
{
   if ( lDmSrcFileTabObjArrCache != null && lDmSrcFileTabObjArrCache.size() > 0 )
   {
%>
       lDmSrcFileTabObjJSArr = new Array(<%=lDmSrcFileTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lDmSrcFileTabObjArrCache.size(); lRecNum++ )
       {
          DmSrcFileTabObj lDmSrcFileTabObj    =    new DmSrcFileTabObj();
          lDmSrcFileTabObj = (DmSrcFileTabObj)lDmSrcFileTabObjArrCache.get(lRecNum);
%>
          lDmSrcFileTabObjJSArr[<%=lRecNum%>] = new constructorDmSrcFile
          (
          "<%=lDmSrcFileTabObj.org_id%>",
          "<%=lDmSrcFileTabObj.file_id%>",
          "<%=lDmSrcFileTabObj.file_type%>",
          "<%=lDmSrcFileTabObj.new_file_name%>",
          "<%=lDmSrcFileTabObj.new_file_cre_date%>",
          "<%=lDmSrcFileTabObj.new_file_cre_time%>",
          "<%=lDmSrcFileTabObj.file_status%>",
          "<%=lDmSrcFileTabObj.orig_file_name%>",
          "<%=lDmSrcFileTabObj.orig_file_cre_date%>",
          "<%=lDmSrcFileTabObj.orig_file_cre_time%>"
          );
<%
       }
   }
}
%>


