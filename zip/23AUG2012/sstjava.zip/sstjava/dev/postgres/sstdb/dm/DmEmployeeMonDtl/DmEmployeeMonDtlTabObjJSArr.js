
var lDmEmployeeMonDtlTabObjJSArr = new Array();
<%
{
   if ( lDmEmployeeMonDtlTabObjArrCache != null && lDmEmployeeMonDtlTabObjArrCache.size() > 0 )
   {
%>
       lDmEmployeeMonDtlTabObjJSArr = new Array(<%=lDmEmployeeMonDtlTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lDmEmployeeMonDtlTabObjArrCache.size(); lRecNum++ )
       {
          DmEmployeeMonDtlTabObj lDmEmployeeMonDtlTabObj    =    new DmEmployeeMonDtlTabObj();
          lDmEmployeeMonDtlTabObj = (DmEmployeeMonDtlTabObj)lDmEmployeeMonDtlTabObjArrCache.get(lRecNum);
%>
          lDmEmployeeMonDtlTabObjJSArr[<%=lRecNum%>] = new constructorDmEmployeeMonDtl
          (
          "<%=lDmEmployeeMonDtlTabObj.org_id%>",
          "<%=lDmEmployeeMonDtlTabObj.customer_id%>",
          "<%=lDmEmployeeMonDtlTabObj.employee_id%>",
          "<%=lDmEmployeeMonDtlTabObj.allocation_date%>",
          "<%=lDmEmployeeMonDtlTabObj.dept_id%>",
          "<%=lDmEmployeeMonDtlTabObj.position_id%>",
          "<%=lDmEmployeeMonDtlTabObj.level_id%>",
          "<%=lDmEmployeeMonDtlTabObj.name_initials%>",
          "<%=lDmEmployeeMonDtlTabObj.employee_name%>",
          "<%=lDmEmployeeMonDtlTabObj.emp_track_id%>",
          "<%=lDmEmployeeMonDtlTabObj.month_num%>",
          "<%=lDmEmployeeMonDtlTabObj.working_days%>",
          "<%=lDmEmployeeMonDtlTabObj.absent_days%>",
          "<%=lDmEmployeeMonDtlTabObj.wages_rate%>",
          "<%=lDmEmployeeMonDtlTabObj.gross_mon_wages%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_bas%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_da%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_hra%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_conv%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_woff%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_shift_alw%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_wash_alw%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_oth_inc%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_pf%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_esi%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_swf_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.sh_amt_oth_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.ot_hour%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_ot%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_oth_inc%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_adv%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_hra%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_weekoff%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_washing%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_areer%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_shift_alw%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_medi_alw%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_convy%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_insur%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_dress%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_swf_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_gen_fine%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_pc%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_sec_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_oth_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.act_amt_adv_ded%>",
          "<%=lDmEmployeeMonDtlTabObj.rec_status%>",
          "<%=lDmEmployeeMonDtlTabObj.rec_cre_date%>",
          "<%=lDmEmployeeMonDtlTabObj.rec_cre_time%>",
          "<%=lDmEmployeeMonDtlTabObj.rec_upd_date%>",
          "<%=lDmEmployeeMonDtlTabObj.rec_upd_time%>",
          "<%=lDmEmployeeMonDtlTabObj.file_name%>",
          "<%=lDmEmployeeMonDtlTabObj.file_cre_date%>",
          "<%=lDmEmployeeMonDtlTabObj.file_cre_time%>",
          "<%=lDmEmployeeMonDtlTabObj.file_status%>"
          );
<%
       }
   }
}
%>


