package sstdb.dm.DmCustAgreement;


public class DmCustAgreementPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 rp_id;
  public String                                 allowance_id;
}