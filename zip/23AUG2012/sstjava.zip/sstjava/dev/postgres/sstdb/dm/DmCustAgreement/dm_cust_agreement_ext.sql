CREATE TABLE DM_CUST_AGREEMENT_EXT
(
  org_id                                                                                              VARCHAR(10),
  customer_id                                                                                         VARCHAR(10),
  rp_id                                                                                               VARCHAR(10),
  allowance_id                                                                                        VARCHAR(10),
  dept_id                                                                                             VARCHAR(10),
  position_id                                                                                         VARCHAR(10),
  level_id                                                                                            VARCHAR(10),
  seq_num                                                                                             NUMERIC(9),
  benefit_flag                                                                                        VARCHAR(1),
  allowance_type                                                                                      VARCHAR(5),
  amount_flag                                                                                         VARCHAR(1),
  default_amount                                                                                      NUMERIC(13,2),
  billing_charge                                                                                      NUMERIC(13,2),
  paying_charge                                                                                       NUMERIC(13,2),
  vacation_code                                                                                       VARCHAR(10),
  leave_quota                                                                                         NUMERIC(9),
  salary_flag                                                                                         VARCHAR(5),
  active_flag                                                                                         VARCHAR(1),
  tax_flag                                                                                            VARCHAR(1),
  tax_percent                                                                                         NUMERIC(5,2),
  sal_deduction_flag                                                                                  VARCHAR(1),
  remark                                                                                              VARCHAR(100),
  agreement_sts                                                                                       VARCHAR(10),
  agreement_sts_date                                                                                  VARCHAR(8),
  effective_date                                                                                      VARCHAR(8),
  expiration_date                                                                                     VARCHAR(8),
  wages_print_ind                                                                                     VARCHAR(1),
  wages_tot_calc_ind                                                                                  VARCHAR(1),
  rec_status                                                                                          VARCHAR(5),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6),
  file_name                                                                                           VARCHAR(56),
  file_cre_date                                                                                       VARCHAR(8),
  file_cre_time                                                                                       VARCHAR(6),
  file_status                                                                                         VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       CUSTOMER_ID                                                                                         CHAR(10),
       RP_ID                                                                                               CHAR(10),
       ALLOWANCE_ID                                                                                        CHAR(10),
       DEPT_ID                                                                                             CHAR(10),
       POSITION_ID                                                                                         CHAR(10),
       LEVEL_ID                                                                                            CHAR(10),
       SEQ_NUM                                                                                             CHAR(9),
       BENEFIT_FLAG                                                                                        CHAR(1),
       ALLOWANCE_TYPE                                                                                      CHAR(5),
       AMOUNT_FLAG                                                                                         CHAR(1),
       DEFAULT_AMOUNT                                                                                      CHAR(13),
       BILLING_CHARGE                                                                                      CHAR(13),
       PAYING_CHARGE                                                                                       CHAR(13),
       VACATION_CODE                                                                                       CHAR(10),
       LEAVE_QUOTA                                                                                         CHAR(9),
       SALARY_FLAG                                                                                         CHAR(5),
       ACTIVE_FLAG                                                                                         CHAR(1),
       TAX_FLAG                                                                                            CHAR(1),
       TAX_PERCENT                                                                                         CHAR(5),
       SAL_DEDUCTION_FLAG                                                                                  CHAR(1),
       REMARK                                                                                              CHAR(100),
       AGREEMENT_STS                                                                                       CHAR(10),
       AGREEMENT_STS_DATE                                                                                  CHAR(8),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRATION_DATE                                                                                     CHAR(8),
       WAGES_PRINT_IND                                                                                     CHAR(1),
       WAGES_TOT_CALC_IND                                                                                  CHAR(1),
       REC_STATUS                                                                                          CHAR(5),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6),
       FILE_NAME                                                                                           CHAR(56),
       FILE_CRE_DATE                                                                                       CHAR(8),
       FILE_CRE_TIME                                                                                       CHAR(6),
       FILE_STATUS                                                                                         CHAR(10)
    )
  )
  LOCATION ('dm_cust_agreement_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
