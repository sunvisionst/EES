package sstdb.dm.DmEmployeeMonDtl;


public class DmEmployeeMonDtlPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 employee_id;
  public String                                 allocation_date;
}