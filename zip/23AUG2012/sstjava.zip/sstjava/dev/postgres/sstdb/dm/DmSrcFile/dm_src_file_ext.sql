CREATE TABLE DM_SRC_FILE_EXT
(
  org_id                                                                                              VARCHAR(10),
  file_id                                                                                             VARCHAR(10),
  file_type                                                                                           VARCHAR(10),
  new_file_name                                                                                       VARCHAR(56),
  new_file_cre_date                                                                                   VARCHAR(8),
  new_file_cre_time                                                                                   VARCHAR(6),
  file_status                                                                                         VARCHAR(10),
  orig_file_name                                                                                      VARCHAR(56),
  orig_file_cre_date                                                                                  VARCHAR(8),
  orig_file_cre_time                                                                                  VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       FILE_ID                                                                                             CHAR(10),
       FILE_TYPE                                                                                           CHAR(10),
       NEW_FILE_NAME                                                                                       CHAR(56),
       NEW_FILE_CRE_DATE                                                                                   CHAR(8),
       NEW_FILE_CRE_TIME                                                                                   CHAR(6),
       FILE_STATUS                                                                                         CHAR(10),
       ORIG_FILE_NAME                                                                                      CHAR(56),
       ORIG_FILE_CRE_DATE                                                                                  CHAR(8),
       ORIG_FILE_CRE_TIME                                                                                  CHAR(6)
    )
  )
  LOCATION ('dm_src_file_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
