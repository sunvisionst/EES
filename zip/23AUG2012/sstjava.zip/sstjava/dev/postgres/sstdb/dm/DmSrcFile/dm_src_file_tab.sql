CREATE TABLE DM_SRC_FILE
(
  ORG_ID                                                                                              VARCHAR(10),
  FILE_ID                                                                                             VARCHAR(10),
  FILE_TYPE                                                                                           VARCHAR(10),
  NEW_FILE_NAME                                                                                       VARCHAR(56),
  NEW_FILE_CRE_DATE                                                                                   VARCHAR(8),
  NEW_FILE_CRE_TIME                                                                                   VARCHAR(6),
  FILE_STATUS                                                                                         VARCHAR(10),
  ORIG_FILE_NAME                                                                                      VARCHAR(56),
  ORIG_FILE_CRE_DATE                                                                                  VARCHAR(8),
  ORIG_FILE_CRE_TIME                                                                                  VARCHAR(6)
)
 WITH OIDS;
