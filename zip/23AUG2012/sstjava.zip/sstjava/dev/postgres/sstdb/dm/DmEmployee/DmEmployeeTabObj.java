package sstdb.dm.DmEmployee;


public class DmEmployeeTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 employee_id;
  public String                                 allocation_date;
  public String                                 name_initials;
  public String                                 employee_f_name;
  public String                                 employee_m_name;
  public String                                 employee_l_name;
  public String                                 employee_short_name;
  public String                                 emp_type;
  public String                                 emp_ctg;
  public String                                 reporting_head_id;
  public String                                 dept_id;
  public String                                 logical_group_id;
  public String                                 position_id;
  public String                                 level_id;
  public String                                 designation;
  public String                                 doj;
  public String                                 dot;
  public String                                 project_id;
  public String                                 shift_code;
  public String                                 cycle_code;
  public String                                 phone;
  public String                                 ext;
  public String                                 email_id;
  public String                                 building_id;
  public String                                 floor_num;
  public String                                 room_num;
  public String                                 cubical_num;
  public String                                 emp_status;
  public String                                 emp_status_date;
  public String                                 emp_agreement_sts;
  public String                                 emp_agreement_sts_date;
  public String                                 country;
  public String                                 recruit_req_id;
  public String                                 work_org_id;
  public String                                 marital_status;
  public String                                 pan_ind;
  public String                                 pf_ind;
  public String                                 esi_ind;
  public String                                 pan_num;
  public String                                 pan_create_date;
  public String                                 epf_act_num;
  public String                                 epf_act_open_dt;
  public String                                 epf_act_close_dt;
  public String                                 prev_epf_act_num;
  public String                                 prev_epf_act_open_dt;
  public String                                 prev_epf_act_close_dt;
  public String                                 esi_num;
  public String                                 esi_act_open_dt;
  public String                                 esi_act_close_dt;
  public String                                 prev_esi_num;
  public String                                 prev_esi_num_open_dt;
  public String                                 prev_esi_num_close_dt;
  public String                                 nss_num;
  public String                                 nss_create_date;
  public String                                 gender;
  public String                                 dob;
  public String                                 birth_city;
  public String                                 birth_country;
  public String                                 barcode;
  public String                                 user_id;
  public String                                 pswd_0;
  public String                                 relation_type;
  public String                                 relative_name;
  public String                                 applicant_id;
  public int                                  emp_card_id;
  public String                                 banker_code;
  public String                                 banker_name;
  public String                                 salary_mode;
  public String                                 pay_card_num;
  public String                                 bank_act_num;
  public String                                 father_name;
  public String                                 mother_name;
  public String                                 spouse_name;
  public String                                 p_address_1;
  public String                                 p_address_2;
  public String                                 p_city;
  public String                                 p_state;
  public String                                 p_zip;
  public String                                 p_country;
  public String                                 m_address_1;
  public String                                 m_address_2;
  public String                                 m_city;
  public String                                 m_state;
  public String                                 m_zip;
  public String                                 m_country;
  public String                                 hospital_id;
  public String                                 course_id;
  public String                                 course_stream;
  public String                                 emp_track_id;
  public String                                 allocation_sts;
  public String                                 release_date;
  public String                                 rp_id;
  public double                                 billing_rate;
  public double                                 paying_rate;
  public String                                 pf_nominee_1;
  public String                                 pf_nominee_2;
  public String                                 esi_nominee_1;
  public String                                 esi_nominee_2;
  public double                                 pf_nominee_1_percent;
  public double                                 pf_nominee_2_percent;
  public double                                 esi_nominee_1_percent;
  public double                                 esi_nominee_2_percent;
  public String                                 rec_status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 file_name;
  public String                                 file_cre_date;
  public String                                 file_cre_time;
  public String                                 file_status;





  public short                                  org_id_ind;
  public short                                  customer_id_ind;
  public short                                  employee_id_ind;
  public short                                  allocation_date_ind;
  public short                                  name_initials_ind;
  public short                                  employee_f_name_ind;
  public short                                  employee_m_name_ind;
  public short                                  employee_l_name_ind;
  public short                                  employee_short_name_ind;
  public short                                  emp_type_ind;
  public short                                  emp_ctg_ind;
  public short                                  reporting_head_id_ind;
  public short                                  dept_id_ind;
  public short                                  logical_group_id_ind;
  public short                                  position_id_ind;
  public short                                  level_id_ind;
  public short                                  designation_ind;
  public short                                  doj_ind;
  public short                                  dot_ind;
  public short                                  project_id_ind;
  public short                                  shift_code_ind;
  public short                                  cycle_code_ind;
  public short                                  phone_ind;
  public short                                  ext_ind;
  public short                                  email_id_ind;
  public short                                  building_id_ind;
  public short                                  floor_num_ind;
  public short                                  room_num_ind;
  public short                                  cubical_num_ind;
  public short                                  emp_status_ind;
  public short                                  emp_status_date_ind;
  public short                                  emp_agreement_sts_ind;
  public short                                  emp_agreement_sts_date_ind;
  public short                                  country_ind;
  public short                                  recruit_req_id_ind;
  public short                                  work_org_id_ind;
  public short                                  marital_status_ind;
  public short                                  pan_ind_ind;
  public short                                  pf_ind_ind;
  public short                                  esi_ind_ind;
  public short                                  pan_num_ind;
  public short                                  pan_create_date_ind;
  public short                                  epf_act_num_ind;
  public short                                  epf_act_open_dt_ind;
  public short                                  epf_act_close_dt_ind;
  public short                                  prev_epf_act_num_ind;
  public short                                  prev_epf_act_open_dt_ind;
  public short                                  prev_epf_act_close_dt_ind;
  public short                                  esi_num_ind;
  public short                                  esi_act_open_dt_ind;
  public short                                  esi_act_close_dt_ind;
  public short                                  prev_esi_num_ind;
  public short                                  prev_esi_num_open_dt_ind;
  public short                                  prev_esi_num_close_dt_ind;
  public short                                  nss_num_ind;
  public short                                  nss_create_date_ind;
  public short                                  gender_ind;
  public short                                  dob_ind;
  public short                                  birth_city_ind;
  public short                                  birth_country_ind;
  public short                                  barcode_ind;
  public short                                  user_id_ind;
  public short                                  pswd_0_ind;
  public short                                  relation_type_ind;
  public short                                  relative_name_ind;
  public short                                  applicant_id_ind;
  public short                                  emp_card_id_ind;
  public short                                  banker_code_ind;
  public short                                  banker_name_ind;
  public short                                  salary_mode_ind;
  public short                                  pay_card_num_ind;
  public short                                  bank_act_num_ind;
  public short                                  father_name_ind;
  public short                                  mother_name_ind;
  public short                                  spouse_name_ind;
  public short                                  p_address_1_ind;
  public short                                  p_address_2_ind;
  public short                                  p_city_ind;
  public short                                  p_state_ind;
  public short                                  p_zip_ind;
  public short                                  p_country_ind;
  public short                                  m_address_1_ind;
  public short                                  m_address_2_ind;
  public short                                  m_city_ind;
  public short                                  m_state_ind;
  public short                                  m_zip_ind;
  public short                                  m_country_ind;
  public short                                  hospital_id_ind;
  public short                                  course_id_ind;
  public short                                  course_stream_ind;
  public short                                  emp_track_id_ind;
  public short                                  allocation_sts_ind;
  public short                                  release_date_ind;
  public short                                  rp_id_ind;
  public short                                  billing_rate_ind;
  public short                                  paying_rate_ind;
  public short                                  pf_nominee_1_ind;
  public short                                  pf_nominee_2_ind;
  public short                                  esi_nominee_1_ind;
  public short                                  esi_nominee_2_ind;
  public short                                  pf_nominee_1_percent_ind;
  public short                                  pf_nominee_2_percent_ind;
  public short                                  esi_nominee_1_percent_ind;
  public short                                  esi_nominee_2_percent_ind;
  public short                                  rec_status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  file_name_ind;
  public short                                  file_cre_date_ind;
  public short                                  file_cre_time_ind;
  public short                                  file_status_ind;


  public DmEmployeeTabObj(){}


  public DmEmployeeTabObj
  (
    String org_id,
    String customer_id,
    String employee_id,
    String allocation_date,
    String name_initials,
    String employee_f_name,
    String employee_m_name,
    String employee_l_name,
    String employee_short_name,
    String emp_type,
    String emp_ctg,
    String reporting_head_id,
    String dept_id,
    String logical_group_id,
    String position_id,
    String level_id,
    String designation,
    String doj,
    String dot,
    String project_id,
    String shift_code,
    String cycle_code,
    String phone,
    String ext,
    String email_id,
    String building_id,
    String floor_num,
    String room_num,
    String cubical_num,
    String emp_status,
    String emp_status_date,
    String emp_agreement_sts,
    String emp_agreement_sts_date,
    String country,
    String recruit_req_id,
    String work_org_id,
    String marital_status,
    String pan_ind,
    String pf_ind,
    String esi_ind,
    String pan_num,
    String pan_create_date,
    String epf_act_num,
    String epf_act_open_dt,
    String epf_act_close_dt,
    String prev_epf_act_num,
    String prev_epf_act_open_dt,
    String prev_epf_act_close_dt,
    String esi_num,
    String esi_act_open_dt,
    String esi_act_close_dt,
    String prev_esi_num,
    String prev_esi_num_open_dt,
    String prev_esi_num_close_dt,
    String nss_num,
    String nss_create_date,
    String gender,
    String dob,
    String birth_city,
    String birth_country,
    String barcode,
    String user_id,
    String pswd_0,
    String relation_type,
    String relative_name,
    String applicant_id,
    int emp_card_id,
    String banker_code,
    String banker_name,
    String salary_mode,
    String pay_card_num,
    String bank_act_num,
    String father_name,
    String mother_name,
    String spouse_name,
    String p_address_1,
    String p_address_2,
    String p_city,
    String p_state,
    String p_zip,
    String p_country,
    String m_address_1,
    String m_address_2,
    String m_city,
    String m_state,
    String m_zip,
    String m_country,
    String hospital_id,
    String course_id,
    String course_stream,
    String emp_track_id,
    String allocation_sts,
    String release_date,
    String rp_id,
    double billing_rate,
    double paying_rate,
    String pf_nominee_1,
    String pf_nominee_2,
    String esi_nominee_1,
    String esi_nominee_2,
    double pf_nominee_1_percent,
    double pf_nominee_2_percent,
    double esi_nominee_1_percent,
    double esi_nominee_2_percent,
    String rec_status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String file_name,
    String file_cre_date,
    String file_cre_time,
    String file_status
  )
  {
     this.org_id = org_id;
     this.customer_id = customer_id;
     this.employee_id = employee_id;
     this.allocation_date = allocation_date;
     this.name_initials = name_initials;
     this.employee_f_name = employee_f_name;
     this.employee_m_name = employee_m_name;
     this.employee_l_name = employee_l_name;
     this.employee_short_name = employee_short_name;
     this.emp_type = emp_type;
     this.emp_ctg = emp_ctg;
     this.reporting_head_id = reporting_head_id;
     this.dept_id = dept_id;
     this.logical_group_id = logical_group_id;
     this.position_id = position_id;
     this.level_id = level_id;
     this.designation = designation;
     this.doj = doj;
     this.dot = dot;
     this.project_id = project_id;
     this.shift_code = shift_code;
     this.cycle_code = cycle_code;
     this.phone = phone;
     this.ext = ext;
     this.email_id = email_id;
     this.building_id = building_id;
     this.floor_num = floor_num;
     this.room_num = room_num;
     this.cubical_num = cubical_num;
     this.emp_status = emp_status;
     this.emp_status_date = emp_status_date;
     this.emp_agreement_sts = emp_agreement_sts;
     this.emp_agreement_sts_date = emp_agreement_sts_date;
     this.country = country;
     this.recruit_req_id = recruit_req_id;
     this.work_org_id = work_org_id;
     this.marital_status = marital_status;
     this.pan_ind = pan_ind;
     this.pf_ind = pf_ind;
     this.esi_ind = esi_ind;
     this.pan_num = pan_num;
     this.pan_create_date = pan_create_date;
     this.epf_act_num = epf_act_num;
     this.epf_act_open_dt = epf_act_open_dt;
     this.epf_act_close_dt = epf_act_close_dt;
     this.prev_epf_act_num = prev_epf_act_num;
     this.prev_epf_act_open_dt = prev_epf_act_open_dt;
     this.prev_epf_act_close_dt = prev_epf_act_close_dt;
     this.esi_num = esi_num;
     this.esi_act_open_dt = esi_act_open_dt;
     this.esi_act_close_dt = esi_act_close_dt;
     this.prev_esi_num = prev_esi_num;
     this.prev_esi_num_open_dt = prev_esi_num_open_dt;
     this.prev_esi_num_close_dt = prev_esi_num_close_dt;
     this.nss_num = nss_num;
     this.nss_create_date = nss_create_date;
     this.gender = gender;
     this.dob = dob;
     this.birth_city = birth_city;
     this.birth_country = birth_country;
     this.barcode = barcode;
     this.user_id = user_id;
     this.pswd_0 = pswd_0;
     this.relation_type = relation_type;
     this.relative_name = relative_name;
     this.applicant_id = applicant_id;
     this.emp_card_id = emp_card_id;
     this.banker_code = banker_code;
     this.banker_name = banker_name;
     this.salary_mode = salary_mode;
     this.pay_card_num = pay_card_num;
     this.bank_act_num = bank_act_num;
     this.father_name = father_name;
     this.mother_name = mother_name;
     this.spouse_name = spouse_name;
     this.p_address_1 = p_address_1;
     this.p_address_2 = p_address_2;
     this.p_city = p_city;
     this.p_state = p_state;
     this.p_zip = p_zip;
     this.p_country = p_country;
     this.m_address_1 = m_address_1;
     this.m_address_2 = m_address_2;
     this.m_city = m_city;
     this.m_state = m_state;
     this.m_zip = m_zip;
     this.m_country = m_country;
     this.hospital_id = hospital_id;
     this.course_id = course_id;
     this.course_stream = course_stream;
     this.emp_track_id = emp_track_id;
     this.allocation_sts = allocation_sts;
     this.release_date = release_date;
     this.rp_id = rp_id;
     this.billing_rate = billing_rate;
     this.paying_rate = paying_rate;
     this.pf_nominee_1 = pf_nominee_1;
     this.pf_nominee_2 = pf_nominee_2;
     this.esi_nominee_1 = esi_nominee_1;
     this.esi_nominee_2 = esi_nominee_2;
     this.pf_nominee_1_percent = pf_nominee_1_percent;
     this.pf_nominee_2_percent = pf_nominee_2_percent;
     this.esi_nominee_1_percent = esi_nominee_1_percent;
     this.esi_nominee_2_percent = esi_nominee_2_percent;
     this.rec_status = rec_status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.file_name = file_name;
     this.file_cre_date = file_cre_date;
     this.file_cre_time = file_cre_time;
     this.file_status = file_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getcustomer_id()                        { return customer_id; }
  public String getemployee_id()                        { return employee_id; }
  public String getallocation_date()                      { return allocation_date; }
  public String getname_initials()                       { return name_initials; }
  public String getemployee_f_name()                      { return employee_f_name; }
  public String getemployee_m_name()                      { return employee_m_name; }
  public String getemployee_l_name()                      { return employee_l_name; }
  public String getemployee_short_name()                    { return employee_short_name; }
  public String getemp_type()                          { return emp_type; }
  public String getemp_ctg()                          { return emp_ctg; }
  public String getreporting_head_id()                     { return reporting_head_id; }
  public String getdept_id()                          { return dept_id; }
  public String getlogical_group_id()                      { return logical_group_id; }
  public String getposition_id()                        { return position_id; }
  public String getlevel_id()                          { return level_id; }
  public String getdesignation()                        { return designation; }
  public String getdoj()                            { return doj; }
  public String getdot()                            { return dot; }
  public String getproject_id()                         { return project_id; }
  public String getshift_code()                         { return shift_code; }
  public String getcycle_code()                         { return cycle_code; }
  public String getphone()                           { return phone; }
  public String getext()                            { return ext; }
  public String getemail_id()                          { return email_id; }
  public String getbuilding_id()                        { return building_id; }
  public String getfloor_num()                         { return floor_num; }
  public String getroom_num()                          { return room_num; }
  public String getcubical_num()                        { return cubical_num; }
  public String getemp_status()                         { return emp_status; }
  public String getemp_status_date()                      { return emp_status_date; }
  public String getemp_agreement_sts()                     { return emp_agreement_sts; }
  public String getemp_agreement_sts_date()                   { return emp_agreement_sts_date; }
  public String getcountry()                          { return country; }
  public String getrecruit_req_id()                       { return recruit_req_id; }
  public String getwork_org_id()                        { return work_org_id; }
  public String getmarital_status()                       { return marital_status; }
  public String getpan_ind()                          { return pan_ind; }
  public String getpf_ind()                           { return pf_ind; }
  public String getesi_ind()                          { return esi_ind; }
  public String getpan_num()                          { return pan_num; }
  public String getpan_create_date()                      { return pan_create_date; }
  public String getepf_act_num()                        { return epf_act_num; }
  public String getepf_act_open_dt()                      { return epf_act_open_dt; }
  public String getepf_act_close_dt()                      { return epf_act_close_dt; }
  public String getprev_epf_act_num()                      { return prev_epf_act_num; }
  public String getprev_epf_act_open_dt()                    { return prev_epf_act_open_dt; }
  public String getprev_epf_act_close_dt()                   { return prev_epf_act_close_dt; }
  public String getesi_num()                          { return esi_num; }
  public String getesi_act_open_dt()                      { return esi_act_open_dt; }
  public String getesi_act_close_dt()                      { return esi_act_close_dt; }
  public String getprev_esi_num()                        { return prev_esi_num; }
  public String getprev_esi_num_open_dt()                    { return prev_esi_num_open_dt; }
  public String getprev_esi_num_close_dt()                   { return prev_esi_num_close_dt; }
  public String getnss_num()                          { return nss_num; }
  public String getnss_create_date()                      { return nss_create_date; }
  public String getgender()                           { return gender; }
  public String getdob()                            { return dob; }
  public String getbirth_city()                         { return birth_city; }
  public String getbirth_country()                       { return birth_country; }
  public String getbarcode()                          { return barcode; }
  public String getuser_id()                          { return user_id; }
  public String getpswd_0()                           { return pswd_0; }
  public String getrelation_type()                       { return relation_type; }
  public String getrelative_name()                       { return relative_name; }
  public String getapplicant_id()                        { return applicant_id; }
  public int getemp_card_id()                          { return emp_card_id; }
  public String getbanker_code()                        { return banker_code; }
  public String getbanker_name()                        { return banker_name; }
  public String getsalary_mode()                        { return salary_mode; }
  public String getpay_card_num()                        { return pay_card_num; }
  public String getbank_act_num()                        { return bank_act_num; }
  public String getfather_name()                        { return father_name; }
  public String getmother_name()                        { return mother_name; }
  public String getspouse_name()                        { return spouse_name; }
  public String getp_address_1()                        { return p_address_1; }
  public String getp_address_2()                        { return p_address_2; }
  public String getp_city()                           { return p_city; }
  public String getp_state()                          { return p_state; }
  public String getp_zip()                           { return p_zip; }
  public String getp_country()                         { return p_country; }
  public String getm_address_1()                        { return m_address_1; }
  public String getm_address_2()                        { return m_address_2; }
  public String getm_city()                           { return m_city; }
  public String getm_state()                          { return m_state; }
  public String getm_zip()                           { return m_zip; }
  public String getm_country()                         { return m_country; }
  public String gethospital_id()                        { return hospital_id; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_stream()                       { return course_stream; }
  public String getemp_track_id()                        { return emp_track_id; }
  public String getallocation_sts()                       { return allocation_sts; }
  public String getrelease_date()                        { return release_date; }
  public String getrp_id()                           { return rp_id; }
  public double getbilling_rate()                        { return billing_rate; }
  public double getpaying_rate()                        { return paying_rate; }
  public String getpf_nominee_1()                        { return pf_nominee_1; }
  public String getpf_nominee_2()                        { return pf_nominee_2; }
  public String getesi_nominee_1()                       { return esi_nominee_1; }
  public String getesi_nominee_2()                       { return esi_nominee_2; }
  public double getpf_nominee_1_percent()                    { return pf_nominee_1_percent; }
  public double getpf_nominee_2_percent()                    { return pf_nominee_2_percent; }
  public double getesi_nominee_1_percent()                   { return esi_nominee_1_percent; }
  public double getesi_nominee_2_percent()                   { return esi_nominee_2_percent; }
  public String getrec_status()                         { return rec_status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String getfile_name()                         { return file_name; }
  public String getfile_cre_date()                       { return file_cre_date; }
  public String getfile_cre_time()                       { return file_cre_time; }
  public String getfile_status()                        { return file_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setemployee_id(String employee_id )               { this.employee_id = employee_id; }
  public void  setallocation_date(String allocation_date )           { this.allocation_date = allocation_date; }
  public void  setname_initials(String name_initials )             { this.name_initials = name_initials; }
  public void  setemployee_f_name(String employee_f_name )           { this.employee_f_name = employee_f_name; }
  public void  setemployee_m_name(String employee_m_name )           { this.employee_m_name = employee_m_name; }
  public void  setemployee_l_name(String employee_l_name )           { this.employee_l_name = employee_l_name; }
  public void  setemployee_short_name(String employee_short_name )       { this.employee_short_name = employee_short_name; }
  public void  setemp_type(String emp_type )                  { this.emp_type = emp_type; }
  public void  setemp_ctg(String emp_ctg )                   { this.emp_ctg = emp_ctg; }
  public void  setreporting_head_id(String reporting_head_id )         { this.reporting_head_id = reporting_head_id; }
  public void  setdept_id(String dept_id )                   { this.dept_id = dept_id; }
  public void  setlogical_group_id(String logical_group_id )          { this.logical_group_id = logical_group_id; }
  public void  setposition_id(String position_id )               { this.position_id = position_id; }
  public void  setlevel_id(String level_id )                  { this.level_id = level_id; }
  public void  setdesignation(String designation )               { this.designation = designation; }
  public void  setdoj(String doj )                       { this.doj = doj; }
  public void  setdot(String dot )                       { this.dot = dot; }
  public void  setproject_id(String project_id )                { this.project_id = project_id; }
  public void  setshift_code(String shift_code )                { this.shift_code = shift_code; }
  public void  setcycle_code(String cycle_code )                { this.cycle_code = cycle_code; }
  public void  setphone(String phone )                     { this.phone = phone; }
  public void  setext(String ext )                       { this.ext = ext; }
  public void  setemail_id(String email_id )                  { this.email_id = email_id; }
  public void  setbuilding_id(String building_id )               { this.building_id = building_id; }
  public void  setfloor_num(String floor_num )                 { this.floor_num = floor_num; }
  public void  setroom_num(String room_num )                  { this.room_num = room_num; }
  public void  setcubical_num(String cubical_num )               { this.cubical_num = cubical_num; }
  public void  setemp_status(String emp_status )                { this.emp_status = emp_status; }
  public void  setemp_status_date(String emp_status_date )           { this.emp_status_date = emp_status_date; }
  public void  setemp_agreement_sts(String emp_agreement_sts )         { this.emp_agreement_sts = emp_agreement_sts; }
  public void  setemp_agreement_sts_date(String emp_agreement_sts_date )    { this.emp_agreement_sts_date = emp_agreement_sts_date; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setrecruit_req_id(String recruit_req_id )            { this.recruit_req_id = recruit_req_id; }
  public void  setwork_org_id(String work_org_id )               { this.work_org_id = work_org_id; }
  public void  setmarital_status(String marital_status )            { this.marital_status = marital_status; }
  public void  setpan_ind(String pan_ind )                   { this.pan_ind = pan_ind; }
  public void  setpf_ind(String pf_ind )                    { this.pf_ind = pf_ind; }
  public void  setesi_ind(String esi_ind )                   { this.esi_ind = esi_ind; }
  public void  setpan_num(String pan_num )                   { this.pan_num = pan_num; }
  public void  setpan_create_date(String pan_create_date )           { this.pan_create_date = pan_create_date; }
  public void  setepf_act_num(String epf_act_num )               { this.epf_act_num = epf_act_num; }
  public void  setepf_act_open_dt(String epf_act_open_dt )           { this.epf_act_open_dt = epf_act_open_dt; }
  public void  setepf_act_close_dt(String epf_act_close_dt )          { this.epf_act_close_dt = epf_act_close_dt; }
  public void  setprev_epf_act_num(String prev_epf_act_num )          { this.prev_epf_act_num = prev_epf_act_num; }
  public void  setprev_epf_act_open_dt(String prev_epf_act_open_dt )      { this.prev_epf_act_open_dt = prev_epf_act_open_dt; }
  public void  setprev_epf_act_close_dt(String prev_epf_act_close_dt )     { this.prev_epf_act_close_dt = prev_epf_act_close_dt; }
  public void  setesi_num(String esi_num )                   { this.esi_num = esi_num; }
  public void  setesi_act_open_dt(String esi_act_open_dt )           { this.esi_act_open_dt = esi_act_open_dt; }
  public void  setesi_act_close_dt(String esi_act_close_dt )          { this.esi_act_close_dt = esi_act_close_dt; }
  public void  setprev_esi_num(String prev_esi_num )              { this.prev_esi_num = prev_esi_num; }
  public void  setprev_esi_num_open_dt(String prev_esi_num_open_dt )      { this.prev_esi_num_open_dt = prev_esi_num_open_dt; }
  public void  setprev_esi_num_close_dt(String prev_esi_num_close_dt )     { this.prev_esi_num_close_dt = prev_esi_num_close_dt; }
  public void  setnss_num(String nss_num )                   { this.nss_num = nss_num; }
  public void  setnss_create_date(String nss_create_date )           { this.nss_create_date = nss_create_date; }
  public void  setgender(String gender )                    { this.gender = gender; }
  public void  setdob(String dob )                       { this.dob = dob; }
  public void  setbirth_city(String birth_city )                { this.birth_city = birth_city; }
  public void  setbirth_country(String birth_country )             { this.birth_country = birth_country; }
  public void  setbarcode(String barcode )                   { this.barcode = barcode; }
  public void  setuser_id(String user_id )                   { this.user_id = user_id; }
  public void  setpswd_0(String pswd_0 )                    { this.pswd_0 = pswd_0; }
  public void  setrelation_type(String relation_type )             { this.relation_type = relation_type; }
  public void  setrelative_name(String relative_name )             { this.relative_name = relative_name; }
  public void  setapplicant_id(String applicant_id )              { this.applicant_id = applicant_id; }
  public void  setemp_card_id(int emp_card_id )                 { this.emp_card_id = emp_card_id; }
  public void  setbanker_code(String banker_code )               { this.banker_code = banker_code; }
  public void  setbanker_name(String banker_name )               { this.banker_name = banker_name; }
  public void  setsalary_mode(String salary_mode )               { this.salary_mode = salary_mode; }
  public void  setpay_card_num(String pay_card_num )              { this.pay_card_num = pay_card_num; }
  public void  setbank_act_num(String bank_act_num )              { this.bank_act_num = bank_act_num; }
  public void  setfather_name(String father_name )               { this.father_name = father_name; }
  public void  setmother_name(String mother_name )               { this.mother_name = mother_name; }
  public void  setspouse_name(String spouse_name )               { this.spouse_name = spouse_name; }
  public void  setp_address_1(String p_address_1 )               { this.p_address_1 = p_address_1; }
  public void  setp_address_2(String p_address_2 )               { this.p_address_2 = p_address_2; }
  public void  setp_city(String p_city )                    { this.p_city = p_city; }
  public void  setp_state(String p_state )                   { this.p_state = p_state; }
  public void  setp_zip(String p_zip )                     { this.p_zip = p_zip; }
  public void  setp_country(String p_country )                 { this.p_country = p_country; }
  public void  setm_address_1(String m_address_1 )               { this.m_address_1 = m_address_1; }
  public void  setm_address_2(String m_address_2 )               { this.m_address_2 = m_address_2; }
  public void  setm_city(String m_city )                    { this.m_city = m_city; }
  public void  setm_state(String m_state )                   { this.m_state = m_state; }
  public void  setm_zip(String m_zip )                     { this.m_zip = m_zip; }
  public void  setm_country(String m_country )                 { this.m_country = m_country; }
  public void  sethospital_id(String hospital_id )               { this.hospital_id = hospital_id; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setemp_track_id(String emp_track_id )              { this.emp_track_id = emp_track_id; }
  public void  setallocation_sts(String allocation_sts )            { this.allocation_sts = allocation_sts; }
  public void  setrelease_date(String release_date )              { this.release_date = release_date; }
  public void  setrp_id(String rp_id )                     { this.rp_id = rp_id; }
  public void  setbilling_rate(double billing_rate )              { this.billing_rate = billing_rate; }
  public void  setpaying_rate(double paying_rate )               { this.paying_rate = paying_rate; }
  public void  setpf_nominee_1(String pf_nominee_1 )              { this.pf_nominee_1 = pf_nominee_1; }
  public void  setpf_nominee_2(String pf_nominee_2 )              { this.pf_nominee_2 = pf_nominee_2; }
  public void  setesi_nominee_1(String esi_nominee_1 )             { this.esi_nominee_1 = esi_nominee_1; }
  public void  setesi_nominee_2(String esi_nominee_2 )             { this.esi_nominee_2 = esi_nominee_2; }
  public void  setpf_nominee_1_percent(double pf_nominee_1_percent )      { this.pf_nominee_1_percent = pf_nominee_1_percent; }
  public void  setpf_nominee_2_percent(double pf_nominee_2_percent )      { this.pf_nominee_2_percent = pf_nominee_2_percent; }
  public void  setesi_nominee_1_percent(double esi_nominee_1_percent )     { this.esi_nominee_1_percent = esi_nominee_1_percent; }
  public void  setesi_nominee_2_percent(double esi_nominee_2_percent )     { this.esi_nominee_2_percent = esi_nominee_2_percent; }
  public void  setrec_status(String rec_status )                { this.rec_status = rec_status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  setfile_name(String file_name )                 { this.file_name = file_name; }
  public void  setfile_cre_date(String file_cre_date )             { this.file_cre_date = file_cre_date; }
  public void  setfile_cre_time(String file_cre_time )             { this.file_cre_time = file_cre_time; }
  public void  setfile_status(String file_status )               { this.file_status = file_status; }
}