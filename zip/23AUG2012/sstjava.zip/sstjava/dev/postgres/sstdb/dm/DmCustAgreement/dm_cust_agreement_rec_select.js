function DmCustAgreementRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("customer_id").value  = document.getElementById("customer_id"+"_r"+inRecNum).value;
    document.getElementById("customer_id").readOnly = true;
    document.getElementById("rp_id").value  = document.getElementById("rp_id"+"_r"+inRecNum).value;
    document.getElementById("rp_id").readOnly = true;
    document.getElementById("allowance_id").value  = document.getElementById("allowance_id"+"_r"+inRecNum).value;
    document.getElementById("allowance_id").readOnly = true;
    document.getElementById("dept_id").value  = document.getElementById("dept_id"+"_r"+inRecNum).value;
    document.getElementById("position_id").value  = document.getElementById("position_id"+"_r"+inRecNum).value;
    document.getElementById("level_id").value  = document.getElementById("level_id"+"_r"+inRecNum).value;
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("benefit_flag").value  = document.getElementById("benefit_flag"+"_r"+inRecNum).value;
    document.getElementById("allowance_type").value  = document.getElementById("allowance_type"+"_r"+inRecNum).value;
    document.getElementById("amount_flag").value  = document.getElementById("amount_flag"+"_r"+inRecNum).value;
    document.getElementById("default_amount").value  = document.getElementById("default_amount"+"_r"+inRecNum).value;
    document.getElementById("billing_charge").value  = document.getElementById("billing_charge"+"_r"+inRecNum).value;
    document.getElementById("paying_charge").value  = document.getElementById("paying_charge"+"_r"+inRecNum).value;
    document.getElementById("vacation_code").value  = document.getElementById("vacation_code"+"_r"+inRecNum).value;
    document.getElementById("leave_quota").value  = document.getElementById("leave_quota"+"_r"+inRecNum).value;
    document.getElementById("salary_flag").value  = document.getElementById("salary_flag"+"_r"+inRecNum).value;
    document.getElementById("active_flag").value  = document.getElementById("active_flag"+"_r"+inRecNum).value;
    document.getElementById("tax_flag").value  = document.getElementById("tax_flag"+"_r"+inRecNum).value;
    document.getElementById("tax_percent").value  = document.getElementById("tax_percent"+"_r"+inRecNum).value;
    document.getElementById("sal_deduction_flag").value  = document.getElementById("sal_deduction_flag"+"_r"+inRecNum).value;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
    document.getElementById("agreement_sts").value  = document.getElementById("agreement_sts"+"_r"+inRecNum).value;
    document.getElementById("agreement_sts_date").value  = document.getElementById("agreement_sts_date"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiration_date").value  = document.getElementById("expiration_date"+"_r"+inRecNum).value;
    document.getElementById("wages_print_ind").value  = document.getElementById("wages_print_ind"+"_r"+inRecNum).value;
    document.getElementById("wages_tot_calc_ind").value  = document.getElementById("wages_tot_calc_ind"+"_r"+inRecNum).value;
    document.getElementById("rec_status").value  = document.getElementById("rec_status"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_date").value  = document.getElementById("rec_cre_date"+"_r"+inRecNum).value;
    document.getElementById("rec_cre_time").value  = document.getElementById("rec_cre_time"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_date").value  = document.getElementById("rec_upd_date"+"_r"+inRecNum).value;
    document.getElementById("rec_upd_time").value  = document.getElementById("rec_upd_time"+"_r"+inRecNum).value;
    document.getElementById("file_name").value  = document.getElementById("file_name"+"_r"+inRecNum).value;
    document.getElementById("file_cre_date").value  = document.getElementById("file_cre_date"+"_r"+inRecNum).value;
    document.getElementById("file_cre_time").value  = document.getElementById("file_cre_time"+"_r"+inRecNum).value;
    document.getElementById("file_status").value  = document.getElementById("file_status"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("customer_id").value = '';
    document.getElementById("customer_id").readOnly = false;
    document.getElementById("rp_id").value = '';
    document.getElementById("rp_id").readOnly = false;
    document.getElementById("allowance_id").value = '';
    document.getElementById("allowance_id").readOnly = false;
    document.getElementById("dept_id").value = '';
    document.getElementById("position_id").value = '';
    document.getElementById("level_id").value = '';
    document.getElementById("seq_num").value = '';
    document.getElementById("benefit_flag").value = '';
    document.getElementById("allowance_type").value = '';
    document.getElementById("amount_flag").value = '';
    document.getElementById("default_amount").value = '';
    document.getElementById("billing_charge").value = '';
    document.getElementById("paying_charge").value = '';
    document.getElementById("vacation_code").value = '';
    document.getElementById("leave_quota").value = '';
    document.getElementById("salary_flag").value = '';
    document.getElementById("active_flag").value = '';
    document.getElementById("tax_flag").value = '';
    document.getElementById("tax_percent").value = '';
    document.getElementById("sal_deduction_flag").value = '';
    document.getElementById("remark").value = '';
    document.getElementById("agreement_sts").value = '';
    document.getElementById("agreement_sts_date").value = '';
    document.getElementById("effective_date").value = '';
    document.getElementById("expiration_date").value = '';
    document.getElementById("wages_print_ind").value = '';
    document.getElementById("wages_tot_calc_ind").value = '';
    document.getElementById("rec_status").value = '';
    document.getElementById("rec_cre_date").value = '';
    document.getElementById("rec_cre_time").value = '';
    document.getElementById("rec_upd_date").value = '';
    document.getElementById("rec_upd_time").value = '';
    document.getElementById("file_name").value = '';
    document.getElementById("file_cre_date").value = '';
    document.getElementById("file_cre_time").value = '';
    document.getElementById("file_status").value = '';
  }
}
