package sstdb.dm.DmCustomer;


public class DmCustomerPkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
}