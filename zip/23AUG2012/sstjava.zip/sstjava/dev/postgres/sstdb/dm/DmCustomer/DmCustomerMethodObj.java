package sstdb.dm.DmCustomer;

import sstdb.dm.DmCustomer.DmCustomerTabObj;
import sstdb.dm.DmCustomer.DmCustomerPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class DmCustomerMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public DmCustomerMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "DmCustomerMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initDmCustomerTabObj
               ( 
                 DmCustomerTabObj  outDmCustomerTabObj
               )
  {
  
     outDmCustomerTabObj.org_id = ""; 
     outDmCustomerTabObj.customer_id = ""; 
     outDmCustomerTabObj.customer_type = ""; 
     outDmCustomerTabObj.customer_ctg = ""; 
     outDmCustomerTabObj.customer_name = ""; 
     outDmCustomerTabObj.customer_group = ""; 
     outDmCustomerTabObj.referred_by = ""; 
     outDmCustomerTabObj.turn_over = (double)0.00; 
     outDmCustomerTabObj.business_area_cd = ""; 
     outDmCustomerTabObj.state_code = ""; 
     outDmCustomerTabObj.region_id = ""; 
     outDmCustomerTabObj.country_code = ""; 
     outDmCustomerTabObj.status = ""; 
     outDmCustomerTabObj.expiration_date = ""; 
     outDmCustomerTabObj.effective_date = ""; 
     outDmCustomerTabObj.business_type = ""; 
     outDmCustomerTabObj.business_est_date = ""; 
     outDmCustomerTabObj.employee_strength = (int)0; 
     outDmCustomerTabObj.business_currency = ""; 
     outDmCustomerTabObj.address_1 = ""; 
     outDmCustomerTabObj.address_2 = ""; 
     outDmCustomerTabObj.address_3 = ""; 
     outDmCustomerTabObj.cst_form_num = ""; 
     outDmCustomerTabObj.cst_form_date = ""; 
     outDmCustomerTabObj.lst_form_num = ""; 
     outDmCustomerTabObj.lst_form_date = ""; 
     outDmCustomerTabObj.tin_num = ""; 
     outDmCustomerTabObj.tin_date = ""; 
     outDmCustomerTabObj.pan_num = ""; 
     outDmCustomerTabObj.pan_date = ""; 
     outDmCustomerTabObj.tan_num = ""; 
     outDmCustomerTabObj.tan_date = ""; 
     outDmCustomerTabObj.strn_num = ""; 
     outDmCustomerTabObj.strn_date = ""; 
     outDmCustomerTabObj.account_num = ""; 
     outDmCustomerTabObj.bal_close = (double)0.00; 
     outDmCustomerTabObj.bal_open = (double)0.00; 
     outDmCustomerTabObj.dr_amt = (double)0.00; 
     outDmCustomerTabObj.cr_amt = (double)0.00; 
     outDmCustomerTabObj.ar_bal = (double)0.00; 
     outDmCustomerTabObj.sal_cycle_code = ""; 
     outDmCustomerTabObj.bill_cycle_code = ""; 
     outDmCustomerTabObj.agreement_id = ""; 
     outDmCustomerTabObj.agreement_eff_date = ""; 
     outDmCustomerTabObj.agreement_exp_date = ""; 
     outDmCustomerTabObj.agreement_cre_date = ""; 
     outDmCustomerTabObj.agreement_sts = ""; 
     outDmCustomerTabObj.agreement_sts_date = ""; 
     outDmCustomerTabObj.prev_agreement_id = ""; 
     outDmCustomerTabObj.renew_ind = ""; 
     outDmCustomerTabObj.cycle_id = ""; 
     outDmCustomerTabObj.spl_training_ind = ""; 
     outDmCustomerTabObj.spl_uniform_ind = ""; 
     outDmCustomerTabObj.pay_day = (int)0; 
     outDmCustomerTabObj.basic = (double)0.00; 
     outDmCustomerTabObj.pf_ind = ""; 
     outDmCustomerTabObj.pf_rate = (double)0.00; 
     outDmCustomerTabObj.esi_ind = ""; 
     outDmCustomerTabObj.esi_rate = (double)0.00; 
     outDmCustomerTabObj.da_ind = ""; 
     outDmCustomerTabObj.da_rate = (double)0.00; 
     outDmCustomerTabObj.ta_ind = ""; 
     outDmCustomerTabObj.ta_rate = (double)0.00; 
     outDmCustomerTabObj.hra_ind = ""; 
     outDmCustomerTabObj.hra_rate = (double)0.00; 
     outDmCustomerTabObj.staff_wf_ind = ""; 
     outDmCustomerTabObj.staff_wf_rate = (double)0.00; 
     outDmCustomerTabObj.lunch_ind = ""; 
     outDmCustomerTabObj.lunch_rate = (double)0.00; 
     outDmCustomerTabObj.jurisdiction = ""; 
     outDmCustomerTabObj.remark = ""; 
     outDmCustomerTabObj.cacnel_remark = ""; 
     outDmCustomerTabObj.service_charge = (double)0.00; 
     outDmCustomerTabObj.service_tax = (double)0.00; 
     outDmCustomerTabObj.weeken_off_ind = ""; 
     outDmCustomerTabObj.working_days = (int)0; 
     outDmCustomerTabObj.manpower_qty = (int)0; 
     outDmCustomerTabObj.work_hour_qty = (int)0; 
     outDmCustomerTabObj.ot_hour_qty = (int)0; 
     outDmCustomerTabObj.labour_licence_ind = ""; 
     outDmCustomerTabObj.labour_licence_num = ""; 
     outDmCustomerTabObj.labour_licence_date = ""; 
     outDmCustomerTabObj.labour_licence_exp_date = ""; 
     outDmCustomerTabObj.rec_status = ""; 
     outDmCustomerTabObj.rec_cre_date = ""; 
     outDmCustomerTabObj.rec_cre_time = ""; 
     outDmCustomerTabObj.rec_upd_date = ""; 
     outDmCustomerTabObj.rec_upd_time = ""; 
     outDmCustomerTabObj.file_name = ""; 
     outDmCustomerTabObj.file_cre_date = ""; 
     outDmCustomerTabObj.file_cre_time = ""; 
     outDmCustomerTabObj.file_status = ""; 
  }





  public void guiDateConvDmCustomerTabObj
               ( 
                 DmCustomerTabObj  inDmCustomerTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inDmCustomerTabObj.expiration_date != null && inDmCustomerTabObj.expiration_date.length() > 0 ) 
            inDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.effective_date != null && inDmCustomerTabObj.effective_date.length() > 0 ) 
            inDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.effective_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.business_est_date != null && inDmCustomerTabObj.business_est_date.length() > 0 ) 
            inDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.cst_form_date != null && inDmCustomerTabObj.cst_form_date.length() > 0 ) 
            inDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.lst_form_date != null && inDmCustomerTabObj.lst_form_date.length() > 0 ) 
            inDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.tin_date != null && inDmCustomerTabObj.tin_date.length() > 0 ) 
            inDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.tin_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.pan_date != null && inDmCustomerTabObj.pan_date.length() > 0 ) 
            inDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.pan_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.tan_date != null && inDmCustomerTabObj.tan_date.length() > 0 ) 
            inDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.tan_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.strn_date != null && inDmCustomerTabObj.strn_date.length() > 0 ) 
            inDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.strn_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.agreement_eff_date != null && inDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.agreement_exp_date != null && inDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.agreement_cre_date != null && inDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.agreement_sts_date != null && inDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.labour_licence_date != null && inDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.labour_licence_exp_date != null && inDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.rec_cre_date != null && inDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            inDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.rec_upd_date != null && inDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            inDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);

          if ( inDmCustomerTabObj.file_cre_date != null && inDmCustomerTabObj.file_cre_date.length() > 0 ) 
            inDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
  }





  public void refreshCtxDmCustomerByTabObj
               ( 
                 DmCustomerTabObj  inDmCustomerTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lDmCustomerTabObjArrCtx  = new ArrayList(); 
    lDmCustomerTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lDmCustomerTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lDmCustomerTabObjArrCtx.add(inDmCustomerTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lDmCustomerTabObjArrCtx.size();  lRecNum++ )
      {
        DmCustomerTabObj lDmCustomerTabObj = new DmCustomerTabObj();
        lDmCustomerTabObj = (DmCustomerTabObj)lDmCustomerTabObjArrCtx.get(lRecNum);
    
        if ( 
              lDmCustomerTabObj.org_id.equals(lDmCustomerTabObj.org_id) &&
              lDmCustomerTabObj.customer_id.equals(lDmCustomerTabObj.customer_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lDmCustomerTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lDmCustomerTabObjArrCtx.set(lRecNum, inDmCustomerTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lDmCustomerTabObjArrCtx",lDmCustomerTabObjArrCtx);
  }





  public void sortDmCustomerTabObjArr
               ( 
                 ArrayList  inDmCustomerTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lDmCustomerTabObjArr  = new ArrayList(); 
     lDmCustomerTabObjArr = inDmCustomerTabObjArr; 
     List lDmCustomerTabObjList  = new ArrayList(lDmCustomerTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lDmCustomerTabObjArr.size();  lRecNum++ )
     {
       DmCustomerTabObj  lDmCustomerTabObj = new DmCustomerTabObj(); 
       lDmCustomerTabObj = (DmCustomerTabObj)lDmCustomerTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.customer_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.customer_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.customer_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.customer_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.customer_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.customer_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.customer_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.customer_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_group") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.customer_group.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.customer_group+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("referred_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lDmCustomerTabObj.referred_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.referred_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("turn_over") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.turn_over).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.turn_over+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("business_area_cd") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.business_area_cd.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.business_area_cd+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("state_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.state_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.state_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("region_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.region_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.region_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.country_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.country_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("expiration_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.expiration_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.expiration_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("effective_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.effective_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.effective_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("business_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.business_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.business_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("business_est_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.business_est_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.business_est_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("employee_strength") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustomerTabObj.employee_strength).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.employee_strength+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("business_currency") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.business_currency.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.business_currency+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.address_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.address_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cst_form_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.cst_form_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.cst_form_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cst_form_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.cst_form_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.cst_form_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lst_form_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.lst_form_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.lst_form_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lst_form_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.lst_form_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.lst_form_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tin_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.tin_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.tin_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tin_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.tin_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.tin_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.pan_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.pan_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pan_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.pan_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.pan_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tan_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.tan_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.tan_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tan_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.tan_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.tan_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("strn_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lDmCustomerTabObj.strn_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.strn_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("strn_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.strn_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.strn_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("account_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmCustomerTabObj.account_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.account_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bal_close") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.bal_close).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.bal_close+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bal_open") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.bal_open).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.bal_open+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dr_amt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.dr_amt).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.dr_amt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cr_amt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.cr_amt).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.cr_amt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ar_bal") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.ar_bal).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.ar_bal+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sal_cycle_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - lDmCustomerTabObj.sal_cycle_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.sal_cycle_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bill_cycle_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - lDmCustomerTabObj.bill_cycle_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.bill_cycle_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmCustomerTabObj.agreement_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_eff_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.agreement_eff_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_eff_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_exp_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.agreement_exp_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_exp_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.agreement_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.agreement_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.agreement_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.agreement_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_agreement_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmCustomerTabObj.prev_agreement_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.prev_agreement_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("renew_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.renew_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.renew_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cycle_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.cycle_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.cycle_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_training_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.spl_training_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.spl_training_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spl_uniform_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.spl_uniform_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.spl_uniform_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pay_day") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lDmCustomerTabObj.pay_day).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.pay_day+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("basic") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.basic).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.basic+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.pf_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.pf_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pf_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.pf_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.pf_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.esi_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.esi_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("esi_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.esi_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.esi_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("da_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.da_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.da_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("da_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.da_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.da_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ta_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.ta_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.ta_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ta_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.ta_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.ta_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("hra_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.hra_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.hra_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("hra_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.hra_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.hra_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("staff_wf_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.staff_wf_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.staff_wf_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("staff_wf_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.staff_wf_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.staff_wf_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lunch_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.lunch_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.lunch_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lunch_rate") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.lunch_rate).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.lunch_rate+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("jurisdiction") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.jurisdiction.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.jurisdiction+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cacnel_remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustomerTabObj.cacnel_remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.cacnel_remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("service_charge") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.service_charge).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.service_charge+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("service_tax") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustomerTabObj.service_tax).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.service_tax+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("weeken_off_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.weeken_off_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.weeken_off_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("working_days") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustomerTabObj.working_days).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.working_days+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("manpower_qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustomerTabObj.manpower_qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.manpower_qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("work_hour_qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustomerTabObj.work_hour_qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.work_hour_qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ot_hour_qty") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustomerTabObj.ot_hour_qty).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.ot_hour_qty+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("labour_licence_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustomerTabObj.labour_licence_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.labour_licence_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("labour_licence_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lDmCustomerTabObj.labour_licence_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.labour_licence_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("labour_licence_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.labour_licence_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.labour_licence_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("labour_licence_exp_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.labour_licence_exp_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.labour_licence_exp_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmCustomerTabObj.rec_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.rec_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustomerTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustomerTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lDmCustomerTabObj.file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustomerTabObj.file_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.file_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustomerTabObj.file_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.file_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustomerTabObj.file_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustomerTabObj.file_status+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lDmCustomerTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lDmCustomerTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lDmCustomerTabObjList ); 
     ArrayList lDmCustomerTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lDmCustomerTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lDmCustomerTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lDmCustomerTabObjArrSorted.add( (DmCustomerTabObj)lDmCustomerTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lDmCustomerTabObjArr.size();  lRecNum++ )
     {
       inDmCustomerTabObjArr.set( lRecNum, (DmCustomerTabObj)lDmCustomerTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvDmCustomerTabObj
               ( 
                 DmCustomerTabObj  inDmCustomerTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inDmCustomerTabObj.expiration_date != null && inDmCustomerTabObj.expiration_date.length() > 0 ) 
            inDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.effective_date != null && inDmCustomerTabObj.effective_date.length() > 0 ) 
            inDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.business_est_date != null && inDmCustomerTabObj.business_est_date.length() > 0 ) 
            inDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.business_est_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.cst_form_date != null && inDmCustomerTabObj.cst_form_date.length() > 0 ) 
            inDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.cst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.lst_form_date != null && inDmCustomerTabObj.lst_form_date.length() > 0 ) 
            inDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.lst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tin_date != null && inDmCustomerTabObj.tin_date.length() > 0 ) 
            inDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tin_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.pan_date != null && inDmCustomerTabObj.pan_date.length() > 0 ) 
            inDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.pan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tan_date != null && inDmCustomerTabObj.tan_date.length() > 0 ) 
            inDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.strn_date != null && inDmCustomerTabObj.strn_date.length() > 0 ) 
            inDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.strn_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_eff_date != null && inDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_eff_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_exp_date != null && inDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_cre_date != null && inDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_sts_date != null && inDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_date != null && inDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_exp_date != null && inDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_cre_date != null && inDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            inDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_upd_date != null && inDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            inDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.file_cre_date != null && inDmCustomerTabObj.file_cre_date.length() > 0 ) 
            inDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.file_cre_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_CTG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerGroup
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_GROUP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReferredBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REFERRED_BY";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTurnOver
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TURN_OVER";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusinessAreaCd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUSINESS_AREA_CD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStateCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATE_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRegionId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REGION_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountryCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpirationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXPIRATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffectiveDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFFECTIVE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusinessType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUSINESS_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusinessEstDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUSINESS_EST_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmployeeStrength
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMPLOYEE_STRENGTH";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBusinessCurrency
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUSINESS_CURRENCY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_3";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCstFormNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CST_FORM_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCstFormDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CST_FORM_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLstFormNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LST_FORM_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLstFormDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LST_FORM_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTinNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TIN_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTinDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TIN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePanDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTanNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TAN_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTanDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TAN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStrnNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STRN_NUM";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStrnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STRN_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAccountNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACCOUNT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBalClose
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BAL_CLOSE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBalOpen
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BAL_OPEN";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDrAmt
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DR_AMT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCrAmt
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CR_AMT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeArBal
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AR_BAL";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSalCycleCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SAL_CYCLE_CODE";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBillCycleCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BILL_CYCLE_CODE";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementEffDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_EFF_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementExpDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_EXP_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevAgreementId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_AGREEMENT_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRenewInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RENEW_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCycleId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CYCLE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplTrainingInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_TRAINING_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSplUniformInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPL_UNIFORM_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePayDay
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAY_DAY";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBasic
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BASIC";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePfRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PF_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEsiRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ESI_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDaInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DA_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDaRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DA_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTaInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TA_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTaRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TA_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHraInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HRA_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHraRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HRA_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStaffWfInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STAFF_WF_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStaffWfRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STAFF_WF_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLunchInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LUNCH_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLunchRate
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LUNCH_RATE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeJurisdiction
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "JURISDICTION";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCacnelRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CACNEL_REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeServiceCharge
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SERVICE_CHARGE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeServiceTax
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SERVICE_TAX";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWeekenOffInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WEEKEN_OFF_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWorkingDays
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WORKING_DAYS";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeManpowerQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MANPOWER_QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWorkHourQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WORK_HOUR_QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOtHourQty
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OT_HOUR_QTY";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLabourLicenceInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LABOUR_LICENCE_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLabourLicenceNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LABOUR_LICENCE_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLabourLicenceDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LABOUR_LICENCE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLabourLicenceExpDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LABOUR_LICENCE_EXP_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtDmCustomerCount
               ( String inDmCustomerWhereText
               )
  {
    sop("gtDmCustomerCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerCount
               ( String inDmCustomerWhereText
               , String inDmCustomerSelectFieldList
               )
  {
    sop("gtDmCustomerCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inDmCustomerSelectFieldList+" AS count "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerRecByPkey
               ( DmCustomerPkeyObj inDmCustomerPkeyObj
               , DmCustomerTabObj  outDmCustomerTabObj
               )
  {
    sop("gtDmCustomerRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "customer_type, "+
                                 "customer_ctg, "+
                                 "customer_name, "+
                                 "customer_group, "+
                                 "referred_by, "+
                                 "turn_over, "+
                                 "business_area_cd, "+
                                 "state_code, "+
                                 "region_id, "+
                                 "country_code, "+
                                 "status, "+
                                 "expiration_date, "+
                                 "effective_date, "+
                                 "business_type, "+
                                 "business_est_date, "+
                                 "employee_strength, "+
                                 "business_currency, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "address_3, "+
                                 "cst_form_num, "+
                                 "cst_form_date, "+
                                 "lst_form_num, "+
                                 "lst_form_date, "+
                                 "tin_num, "+
                                 "tin_date, "+
                                 "pan_num, "+
                                 "pan_date, "+
                                 "tan_num, "+
                                 "tan_date, "+
                                 "strn_num, "+
                                 "strn_date, "+
                                 "account_num, "+
                                 "bal_close, "+
                                 "bal_open, "+
                                 "dr_amt, "+
                                 "cr_amt, "+
                                 "ar_bal, "+
                                 "sal_cycle_code, "+
                                 "bill_cycle_code, "+
                                 "agreement_id, "+
                                 "agreement_eff_date, "+
                                 "agreement_exp_date, "+
                                 "agreement_cre_date, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "prev_agreement_id, "+
                                 "renew_ind, "+
                                 "cycle_id, "+
                                 "spl_training_ind, "+
                                 "spl_uniform_ind, "+
                                 "pay_day, "+
                                 "basic, "+
                                 "pf_ind, "+
                                 "pf_rate, "+
                                 "esi_ind, "+
                                 "esi_rate, "+
                                 "da_ind, "+
                                 "da_rate, "+
                                 "ta_ind, "+
                                 "ta_rate, "+
                                 "hra_ind, "+
                                 "hra_rate, "+
                                 "staff_wf_ind, "+
                                 "staff_wf_rate, "+
                                 "lunch_ind, "+
                                 "lunch_rate, "+
                                 "jurisdiction, "+
                                 "remark, "+
                                 "cacnel_remark, "+
                                 "service_charge, "+
                                 "service_tax, "+
                                 "weeken_off_ind, "+
                                 "working_days, "+
                                 "manpower_qty, "+
                                 "work_hour_qty, "+
                                 "ot_hour_qty, "+
                                 "labour_licence_ind, "+
                                 "labour_licence_num, "+
                                 "labour_licence_date, "+
                                 "labour_licence_exp_date, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUSTOMER " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmCustomerPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustomerPkeyObj.customer_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outDmCustomerTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmCustomerTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmCustomerTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmCustomerTabObj.customer_type  =  lResultSet.getString("CUSTOMER_TYPE");
          outDmCustomerTabObj.customer_ctg  =  lResultSet.getString("CUSTOMER_CTG");
          outDmCustomerTabObj.customer_name  =  lResultSet.getString("CUSTOMER_NAME");
          outDmCustomerTabObj.customer_group  =  lResultSet.getString("CUSTOMER_GROUP");
          outDmCustomerTabObj.referred_by  =  lResultSet.getString("REFERRED_BY");
          outDmCustomerTabObj.turn_over  =  lResultSet.getDouble("TURN_OVER");
          outDmCustomerTabObj.business_area_cd  =  lResultSet.getString("BUSINESS_AREA_CD");
          outDmCustomerTabObj.state_code  =  lResultSet.getString("STATE_CODE");
          outDmCustomerTabObj.region_id  =  lResultSet.getString("REGION_ID");
          outDmCustomerTabObj.country_code  =  lResultSet.getString("COUNTRY_CODE");
          outDmCustomerTabObj.status  =  lResultSet.getString("STATUS");
          outDmCustomerTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outDmCustomerTabObj.expiration_date != null && outDmCustomerTabObj.expiration_date.length() > 0 ) 
            outDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outDmCustomerTabObj.effective_date != null && outDmCustomerTabObj.effective_date.length() > 0 ) 
            outDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.effective_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.business_type  =  lResultSet.getString("BUSINESS_TYPE");
          outDmCustomerTabObj.business_est_date  =  lResultSet.getString("BUSINESS_EST_DATE");

          if ( outDmCustomerTabObj.business_est_date != null && outDmCustomerTabObj.business_est_date.length() > 0 ) 
            outDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.employee_strength  =  lResultSet.getInt("EMPLOYEE_STRENGTH");
          outDmCustomerTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          outDmCustomerTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outDmCustomerTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outDmCustomerTabObj.address_3  =  lResultSet.getString("ADDRESS_3");
          outDmCustomerTabObj.cst_form_num  =  lResultSet.getString("CST_FORM_NUM");
          outDmCustomerTabObj.cst_form_date  =  lResultSet.getString("CST_FORM_DATE");

          if ( outDmCustomerTabObj.cst_form_date != null && outDmCustomerTabObj.cst_form_date.length() > 0 ) 
            outDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.lst_form_num  =  lResultSet.getString("LST_FORM_NUM");
          outDmCustomerTabObj.lst_form_date  =  lResultSet.getString("LST_FORM_DATE");

          if ( outDmCustomerTabObj.lst_form_date != null && outDmCustomerTabObj.lst_form_date.length() > 0 ) 
            outDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.tin_num  =  lResultSet.getString("TIN_NUM");
          outDmCustomerTabObj.tin_date  =  lResultSet.getString("TIN_DATE");

          if ( outDmCustomerTabObj.tin_date != null && outDmCustomerTabObj.tin_date.length() > 0 ) 
            outDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.tin_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outDmCustomerTabObj.pan_date  =  lResultSet.getString("PAN_DATE");

          if ( outDmCustomerTabObj.pan_date != null && outDmCustomerTabObj.pan_date.length() > 0 ) 
            outDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.pan_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.tan_num  =  lResultSet.getString("TAN_NUM");
          outDmCustomerTabObj.tan_date  =  lResultSet.getString("TAN_DATE");

          if ( outDmCustomerTabObj.tan_date != null && outDmCustomerTabObj.tan_date.length() > 0 ) 
            outDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.tan_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.strn_num  =  lResultSet.getString("STRN_NUM");
          outDmCustomerTabObj.strn_date  =  lResultSet.getString("STRN_DATE");

          if ( outDmCustomerTabObj.strn_date != null && outDmCustomerTabObj.strn_date.length() > 0 ) 
            outDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.strn_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.account_num  =  lResultSet.getString("ACCOUNT_NUM");
          outDmCustomerTabObj.bal_close  =  lResultSet.getDouble("BAL_CLOSE");
          outDmCustomerTabObj.bal_open  =  lResultSet.getDouble("BAL_OPEN");
          outDmCustomerTabObj.dr_amt  =  lResultSet.getDouble("DR_AMT");
          outDmCustomerTabObj.cr_amt  =  lResultSet.getDouble("CR_AMT");
          outDmCustomerTabObj.ar_bal  =  lResultSet.getDouble("AR_BAL");
          outDmCustomerTabObj.sal_cycle_code  =  lResultSet.getString("SAL_CYCLE_CODE");
          outDmCustomerTabObj.bill_cycle_code  =  lResultSet.getString("BILL_CYCLE_CODE");
          outDmCustomerTabObj.agreement_id  =  lResultSet.getString("AGREEMENT_ID");
          outDmCustomerTabObj.agreement_eff_date  =  lResultSet.getString("AGREEMENT_EFF_DATE");

          if ( outDmCustomerTabObj.agreement_eff_date != null && outDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_exp_date  =  lResultSet.getString("AGREEMENT_EXP_DATE");

          if ( outDmCustomerTabObj.agreement_exp_date != null && outDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_cre_date  =  lResultSet.getString("AGREEMENT_CRE_DATE");

          if ( outDmCustomerTabObj.agreement_cre_date != null && outDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          outDmCustomerTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( outDmCustomerTabObj.agreement_sts_date != null && outDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.prev_agreement_id  =  lResultSet.getString("PREV_AGREEMENT_ID");
          outDmCustomerTabObj.renew_ind  =  lResultSet.getString("RENEW_IND");
          outDmCustomerTabObj.cycle_id  =  lResultSet.getString("CYCLE_ID");
          outDmCustomerTabObj.spl_training_ind  =  lResultSet.getString("SPL_TRAINING_IND");
          outDmCustomerTabObj.spl_uniform_ind  =  lResultSet.getString("SPL_UNIFORM_IND");
          outDmCustomerTabObj.pay_day  =  lResultSet.getByte("PAY_DAY");
          outDmCustomerTabObj.basic  =  lResultSet.getDouble("BASIC");
          outDmCustomerTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          outDmCustomerTabObj.pf_rate  =  lResultSet.getDouble("PF_RATE");
          outDmCustomerTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          outDmCustomerTabObj.esi_rate  =  lResultSet.getDouble("ESI_RATE");
          outDmCustomerTabObj.da_ind  =  lResultSet.getString("DA_IND");
          outDmCustomerTabObj.da_rate  =  lResultSet.getDouble("DA_RATE");
          outDmCustomerTabObj.ta_ind  =  lResultSet.getString("TA_IND");
          outDmCustomerTabObj.ta_rate  =  lResultSet.getDouble("TA_RATE");
          outDmCustomerTabObj.hra_ind  =  lResultSet.getString("HRA_IND");
          outDmCustomerTabObj.hra_rate  =  lResultSet.getDouble("HRA_RATE");
          outDmCustomerTabObj.staff_wf_ind  =  lResultSet.getString("STAFF_WF_IND");
          outDmCustomerTabObj.staff_wf_rate  =  lResultSet.getDouble("STAFF_WF_RATE");
          outDmCustomerTabObj.lunch_ind  =  lResultSet.getString("LUNCH_IND");
          outDmCustomerTabObj.lunch_rate  =  lResultSet.getDouble("LUNCH_RATE");
          outDmCustomerTabObj.jurisdiction  =  lResultSet.getString("JURISDICTION");
          outDmCustomerTabObj.remark  =  lResultSet.getString("REMARK");
          outDmCustomerTabObj.cacnel_remark  =  lResultSet.getString("CACNEL_REMARK");
          outDmCustomerTabObj.service_charge  =  lResultSet.getDouble("SERVICE_CHARGE");
          outDmCustomerTabObj.service_tax  =  lResultSet.getDouble("SERVICE_TAX");
          outDmCustomerTabObj.weeken_off_ind  =  lResultSet.getString("WEEKEN_OFF_IND");
          outDmCustomerTabObj.working_days  =  lResultSet.getInt("WORKING_DAYS");
          outDmCustomerTabObj.manpower_qty  =  lResultSet.getInt("MANPOWER_QTY");
          outDmCustomerTabObj.work_hour_qty  =  lResultSet.getInt("WORK_HOUR_QTY");
          outDmCustomerTabObj.ot_hour_qty  =  lResultSet.getInt("OT_HOUR_QTY");
          outDmCustomerTabObj.labour_licence_ind  =  lResultSet.getString("LABOUR_LICENCE_IND");
          outDmCustomerTabObj.labour_licence_num  =  lResultSet.getString("LABOUR_LICENCE_NUM");
          outDmCustomerTabObj.labour_licence_date  =  lResultSet.getString("LABOUR_LICENCE_DATE");

          if ( outDmCustomerTabObj.labour_licence_date != null && outDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            outDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.labour_licence_exp_date  =  lResultSet.getString("LABOUR_LICENCE_EXP_DATE");

          if ( outDmCustomerTabObj.labour_licence_exp_date != null && outDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            outDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmCustomerTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmCustomerTabObj.rec_cre_date != null && outDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            outDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmCustomerTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmCustomerTabObj.rec_upd_date != null && outDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            outDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmCustomerTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmCustomerTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmCustomerTabObj.file_cre_date != null && outDmCustomerTabObj.file_cre_date.length() > 0 ) 
            outDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmCustomerTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmCustomerTabObj( outDmCustomerTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerArr
               ( DmCustomerPkeyObj inDmCustomerPkeyObj
               , ArrayList  outDmCustomerTabObjArr
               )
  {
    sop("gtDmCustomerArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "customer_type, "+
                                 "customer_ctg, "+
                                 "customer_name, "+
                                 "customer_group, "+
                                 "referred_by, "+
                                 "turn_over, "+
                                 "business_area_cd, "+
                                 "state_code, "+
                                 "region_id, "+
                                 "country_code, "+
                                 "status, "+
                                 "expiration_date, "+
                                 "effective_date, "+
                                 "business_type, "+
                                 "business_est_date, "+
                                 "employee_strength, "+
                                 "business_currency, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "address_3, "+
                                 "cst_form_num, "+
                                 "cst_form_date, "+
                                 "lst_form_num, "+
                                 "lst_form_date, "+
                                 "tin_num, "+
                                 "tin_date, "+
                                 "pan_num, "+
                                 "pan_date, "+
                                 "tan_num, "+
                                 "tan_date, "+
                                 "strn_num, "+
                                 "strn_date, "+
                                 "account_num, "+
                                 "bal_close, "+
                                 "bal_open, "+
                                 "dr_amt, "+
                                 "cr_amt, "+
                                 "ar_bal, "+
                                 "sal_cycle_code, "+
                                 "bill_cycle_code, "+
                                 "agreement_id, "+
                                 "agreement_eff_date, "+
                                 "agreement_exp_date, "+
                                 "agreement_cre_date, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "prev_agreement_id, "+
                                 "renew_ind, "+
                                 "cycle_id, "+
                                 "spl_training_ind, "+
                                 "spl_uniform_ind, "+
                                 "pay_day, "+
                                 "basic, "+
                                 "pf_ind, "+
                                 "pf_rate, "+
                                 "esi_ind, "+
                                 "esi_rate, "+
                                 "da_ind, "+
                                 "da_rate, "+
                                 "ta_ind, "+
                                 "ta_rate, "+
                                 "hra_ind, "+
                                 "hra_rate, "+
                                 "staff_wf_ind, "+
                                 "staff_wf_rate, "+
                                 "lunch_ind, "+
                                 "lunch_rate, "+
                                 "jurisdiction, "+
                                 "remark, "+
                                 "cacnel_remark, "+
                                 "service_charge, "+
                                 "service_tax, "+
                                 "weeken_off_ind, "+
                                 "working_days, "+
                                 "manpower_qty, "+
                                 "work_hour_qty, "+
                                 "ot_hour_qty, "+
                                 "labour_licence_ind, "+
                                 "labour_licence_num, "+
                                 "labour_licence_date, "+
                                 "labour_licence_exp_date, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUSTOMER";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmCustomerTabObj  lDmCustomerTabObj = new DmCustomerTabObj();
          lDmCustomerTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lDmCustomerTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmCustomerTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmCustomerTabObj.customer_type  =  lResultSet.getString("CUSTOMER_TYPE");
          lDmCustomerTabObj.customer_ctg  =  lResultSet.getString("CUSTOMER_CTG");
          lDmCustomerTabObj.customer_name  =  lResultSet.getString("CUSTOMER_NAME");
          lDmCustomerTabObj.customer_group  =  lResultSet.getString("CUSTOMER_GROUP");
          lDmCustomerTabObj.referred_by  =  lResultSet.getString("REFERRED_BY");
          lDmCustomerTabObj.turn_over  =  lResultSet.getDouble("TURN_OVER");
          lDmCustomerTabObj.business_area_cd  =  lResultSet.getString("BUSINESS_AREA_CD");
          lDmCustomerTabObj.state_code  =  lResultSet.getString("STATE_CODE");
          lDmCustomerTabObj.region_id  =  lResultSet.getString("REGION_ID");
          lDmCustomerTabObj.country_code  =  lResultSet.getString("COUNTRY_CODE");
          lDmCustomerTabObj.status  =  lResultSet.getString("STATUS");
          lDmCustomerTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lDmCustomerTabObj.expiration_date != null && lDmCustomerTabObj.expiration_date.length() > 0 ) 
            lDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lDmCustomerTabObj.effective_date != null && lDmCustomerTabObj.effective_date.length() > 0 ) 
            lDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.effective_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.business_type  =  lResultSet.getString("BUSINESS_TYPE");
          lDmCustomerTabObj.business_est_date  =  lResultSet.getString("BUSINESS_EST_DATE");

          if ( lDmCustomerTabObj.business_est_date != null && lDmCustomerTabObj.business_est_date.length() > 0 ) 
            lDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.employee_strength  =  lResultSet.getInt("EMPLOYEE_STRENGTH");
          lDmCustomerTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          lDmCustomerTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lDmCustomerTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lDmCustomerTabObj.address_3  =  lResultSet.getString("ADDRESS_3");
          lDmCustomerTabObj.cst_form_num  =  lResultSet.getString("CST_FORM_NUM");
          lDmCustomerTabObj.cst_form_date  =  lResultSet.getString("CST_FORM_DATE");

          if ( lDmCustomerTabObj.cst_form_date != null && lDmCustomerTabObj.cst_form_date.length() > 0 ) 
            lDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.lst_form_num  =  lResultSet.getString("LST_FORM_NUM");
          lDmCustomerTabObj.lst_form_date  =  lResultSet.getString("LST_FORM_DATE");

          if ( lDmCustomerTabObj.lst_form_date != null && lDmCustomerTabObj.lst_form_date.length() > 0 ) 
            lDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.tin_num  =  lResultSet.getString("TIN_NUM");
          lDmCustomerTabObj.tin_date  =  lResultSet.getString("TIN_DATE");

          if ( lDmCustomerTabObj.tin_date != null && lDmCustomerTabObj.tin_date.length() > 0 ) 
            lDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tin_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lDmCustomerTabObj.pan_date  =  lResultSet.getString("PAN_DATE");

          if ( lDmCustomerTabObj.pan_date != null && lDmCustomerTabObj.pan_date.length() > 0 ) 
            lDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.pan_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.tan_num  =  lResultSet.getString("TAN_NUM");
          lDmCustomerTabObj.tan_date  =  lResultSet.getString("TAN_DATE");

          if ( lDmCustomerTabObj.tan_date != null && lDmCustomerTabObj.tan_date.length() > 0 ) 
            lDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tan_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.strn_num  =  lResultSet.getString("STRN_NUM");
          lDmCustomerTabObj.strn_date  =  lResultSet.getString("STRN_DATE");

          if ( lDmCustomerTabObj.strn_date != null && lDmCustomerTabObj.strn_date.length() > 0 ) 
            lDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.strn_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.account_num  =  lResultSet.getString("ACCOUNT_NUM");
          lDmCustomerTabObj.bal_close  =  lResultSet.getDouble("BAL_CLOSE");
          lDmCustomerTabObj.bal_open  =  lResultSet.getDouble("BAL_OPEN");
          lDmCustomerTabObj.dr_amt  =  lResultSet.getDouble("DR_AMT");
          lDmCustomerTabObj.cr_amt  =  lResultSet.getDouble("CR_AMT");
          lDmCustomerTabObj.ar_bal  =  lResultSet.getDouble("AR_BAL");
          lDmCustomerTabObj.sal_cycle_code  =  lResultSet.getString("SAL_CYCLE_CODE");
          lDmCustomerTabObj.bill_cycle_code  =  lResultSet.getString("BILL_CYCLE_CODE");
          lDmCustomerTabObj.agreement_id  =  lResultSet.getString("AGREEMENT_ID");
          lDmCustomerTabObj.agreement_eff_date  =  lResultSet.getString("AGREEMENT_EFF_DATE");

          if ( lDmCustomerTabObj.agreement_eff_date != null && lDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_exp_date  =  lResultSet.getString("AGREEMENT_EXP_DATE");

          if ( lDmCustomerTabObj.agreement_exp_date != null && lDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_cre_date  =  lResultSet.getString("AGREEMENT_CRE_DATE");

          if ( lDmCustomerTabObj.agreement_cre_date != null && lDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          lDmCustomerTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( lDmCustomerTabObj.agreement_sts_date != null && lDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.prev_agreement_id  =  lResultSet.getString("PREV_AGREEMENT_ID");
          lDmCustomerTabObj.renew_ind  =  lResultSet.getString("RENEW_IND");
          lDmCustomerTabObj.cycle_id  =  lResultSet.getString("CYCLE_ID");
          lDmCustomerTabObj.spl_training_ind  =  lResultSet.getString("SPL_TRAINING_IND");
          lDmCustomerTabObj.spl_uniform_ind  =  lResultSet.getString("SPL_UNIFORM_IND");
          lDmCustomerTabObj.pay_day  =  lResultSet.getByte("PAY_DAY");
          lDmCustomerTabObj.basic  =  lResultSet.getDouble("BASIC");
          lDmCustomerTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          lDmCustomerTabObj.pf_rate  =  lResultSet.getDouble("PF_RATE");
          lDmCustomerTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          lDmCustomerTabObj.esi_rate  =  lResultSet.getDouble("ESI_RATE");
          lDmCustomerTabObj.da_ind  =  lResultSet.getString("DA_IND");
          lDmCustomerTabObj.da_rate  =  lResultSet.getDouble("DA_RATE");
          lDmCustomerTabObj.ta_ind  =  lResultSet.getString("TA_IND");
          lDmCustomerTabObj.ta_rate  =  lResultSet.getDouble("TA_RATE");
          lDmCustomerTabObj.hra_ind  =  lResultSet.getString("HRA_IND");
          lDmCustomerTabObj.hra_rate  =  lResultSet.getDouble("HRA_RATE");
          lDmCustomerTabObj.staff_wf_ind  =  lResultSet.getString("STAFF_WF_IND");
          lDmCustomerTabObj.staff_wf_rate  =  lResultSet.getDouble("STAFF_WF_RATE");
          lDmCustomerTabObj.lunch_ind  =  lResultSet.getString("LUNCH_IND");
          lDmCustomerTabObj.lunch_rate  =  lResultSet.getDouble("LUNCH_RATE");
          lDmCustomerTabObj.jurisdiction  =  lResultSet.getString("JURISDICTION");
          lDmCustomerTabObj.remark  =  lResultSet.getString("REMARK");
          lDmCustomerTabObj.cacnel_remark  =  lResultSet.getString("CACNEL_REMARK");
          lDmCustomerTabObj.service_charge  =  lResultSet.getDouble("SERVICE_CHARGE");
          lDmCustomerTabObj.service_tax  =  lResultSet.getDouble("SERVICE_TAX");
          lDmCustomerTabObj.weeken_off_ind  =  lResultSet.getString("WEEKEN_OFF_IND");
          lDmCustomerTabObj.working_days  =  lResultSet.getInt("WORKING_DAYS");
          lDmCustomerTabObj.manpower_qty  =  lResultSet.getInt("MANPOWER_QTY");
          lDmCustomerTabObj.work_hour_qty  =  lResultSet.getInt("WORK_HOUR_QTY");
          lDmCustomerTabObj.ot_hour_qty  =  lResultSet.getInt("OT_HOUR_QTY");
          lDmCustomerTabObj.labour_licence_ind  =  lResultSet.getString("LABOUR_LICENCE_IND");
          lDmCustomerTabObj.labour_licence_num  =  lResultSet.getString("LABOUR_LICENCE_NUM");
          lDmCustomerTabObj.labour_licence_date  =  lResultSet.getString("LABOUR_LICENCE_DATE");

          if ( lDmCustomerTabObj.labour_licence_date != null && lDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.labour_licence_exp_date  =  lResultSet.getString("LABOUR_LICENCE_EXP_DATE");

          if ( lDmCustomerTabObj.labour_licence_exp_date != null && lDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmCustomerTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmCustomerTabObj.rec_cre_date != null && lDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            lDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmCustomerTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmCustomerTabObj.rec_upd_date != null && lDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            lDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmCustomerTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmCustomerTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmCustomerTabObj.file_cre_date != null && lDmCustomerTabObj.file_cre_date.length() > 0 ) 
            lDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmCustomerTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmCustomerTabObj( lDmCustomerTabObj );

          outDmCustomerTabObjArr.add(  lDmCustomerTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustomerTabObjArr != null && outDmCustomerTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtDmCustomerArr2XML
               ( String inDmCustomerWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtDmCustomerArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<DmCustomer>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_id") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_ID>" +  lResultSet.getString("CUSTOMER_ID") +   "</CUSTOMER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_type") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_TYPE>" +  lResultSet.getString("CUSTOMER_TYPE") +   "</CUSTOMER_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_ctg") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_CTG>" +  lResultSet.getString("CUSTOMER_CTG") +   "</CUSTOMER_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_name") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_NAME>" +  lResultSet.getString("CUSTOMER_NAME") +   "</CUSTOMER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_group") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_GROUP>" +  lResultSet.getString("CUSTOMER_GROUP") +   "</CUSTOMER_GROUP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("referred_by") )
              lXmlBuffer = lXmlBuffer +   "<REFERRED_BY>" +  lResultSet.getString("REFERRED_BY") +   "</REFERRED_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("turn_over") )
              lXmlBuffer = lXmlBuffer +   "<TURN_OVER>" +  lResultSet.getDouble("TURN_OVER") +   "</TURN_OVER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("business_area_cd") )
              lXmlBuffer = lXmlBuffer +   "<BUSINESS_AREA_CD>" +  lResultSet.getString("BUSINESS_AREA_CD") +   "</BUSINESS_AREA_CD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("state_code") )
              lXmlBuffer = lXmlBuffer +   "<STATE_CODE>" +  lResultSet.getString("STATE_CODE") +   "</STATE_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("region_id") )
              lXmlBuffer = lXmlBuffer +   "<REGION_ID>" +  lResultSet.getString("REGION_ID") +   "</REGION_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country_code") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY_CODE>" +  lResultSet.getString("COUNTRY_CODE") +   "</COUNTRY_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("expiration_date") )
              lXmlBuffer = lXmlBuffer +   "<EXPIRATION_DATE>" +  lResultSet.getString("EXPIRATION_DATE") +   "</EXPIRATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("effective_date") )
              lXmlBuffer = lXmlBuffer +   "<EFFECTIVE_DATE>" +  lResultSet.getString("EFFECTIVE_DATE") +   "</EFFECTIVE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("business_type") )
              lXmlBuffer = lXmlBuffer +   "<BUSINESS_TYPE>" +  lResultSet.getString("BUSINESS_TYPE") +   "</BUSINESS_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("business_est_date") )
              lXmlBuffer = lXmlBuffer +   "<BUSINESS_EST_DATE>" +  lResultSet.getString("BUSINESS_EST_DATE") +   "</BUSINESS_EST_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("employee_strength") )
              lXmlBuffer = lXmlBuffer +   "<EMPLOYEE_STRENGTH>" +  lResultSet.getInt("EMPLOYEE_STRENGTH") +   "</EMPLOYEE_STRENGTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("business_currency") )
              lXmlBuffer = lXmlBuffer +   "<BUSINESS_CURRENCY>" +  lResultSet.getString("BUSINESS_CURRENCY") +   "</BUSINESS_CURRENCY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_1") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_1>" +  lResultSet.getString("ADDRESS_1") +   "</ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_2") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_2>" +  lResultSet.getString("ADDRESS_2") +   "</ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_3") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_3>" +  lResultSet.getString("ADDRESS_3") +   "</ADDRESS_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cst_form_num") )
              lXmlBuffer = lXmlBuffer +   "<CST_FORM_NUM>" +  lResultSet.getString("CST_FORM_NUM") +   "</CST_FORM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cst_form_date") )
              lXmlBuffer = lXmlBuffer +   "<CST_FORM_DATE>" +  lResultSet.getString("CST_FORM_DATE") +   "</CST_FORM_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lst_form_num") )
              lXmlBuffer = lXmlBuffer +   "<LST_FORM_NUM>" +  lResultSet.getString("LST_FORM_NUM") +   "</LST_FORM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lst_form_date") )
              lXmlBuffer = lXmlBuffer +   "<LST_FORM_DATE>" +  lResultSet.getString("LST_FORM_DATE") +   "</LST_FORM_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tin_num") )
              lXmlBuffer = lXmlBuffer +   "<TIN_NUM>" +  lResultSet.getString("TIN_NUM") +   "</TIN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tin_date") )
              lXmlBuffer = lXmlBuffer +   "<TIN_DATE>" +  lResultSet.getString("TIN_DATE") +   "</TIN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_num") )
              lXmlBuffer = lXmlBuffer +   "<PAN_NUM>" +  lResultSet.getString("PAN_NUM") +   "</PAN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pan_date") )
              lXmlBuffer = lXmlBuffer +   "<PAN_DATE>" +  lResultSet.getString("PAN_DATE") +   "</PAN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tan_num") )
              lXmlBuffer = lXmlBuffer +   "<TAN_NUM>" +  lResultSet.getString("TAN_NUM") +   "</TAN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tan_date") )
              lXmlBuffer = lXmlBuffer +   "<TAN_DATE>" +  lResultSet.getString("TAN_DATE") +   "</TAN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("strn_num") )
              lXmlBuffer = lXmlBuffer +   "<STRN_NUM>" +  lResultSet.getString("STRN_NUM") +   "</STRN_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("strn_date") )
              lXmlBuffer = lXmlBuffer +   "<STRN_DATE>" +  lResultSet.getString("STRN_DATE") +   "</STRN_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("account_num") )
              lXmlBuffer = lXmlBuffer +   "<ACCOUNT_NUM>" +  lResultSet.getString("ACCOUNT_NUM") +   "</ACCOUNT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bal_close") )
              lXmlBuffer = lXmlBuffer +   "<BAL_CLOSE>" +  lResultSet.getDouble("BAL_CLOSE") +   "</BAL_CLOSE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bal_open") )
              lXmlBuffer = lXmlBuffer +   "<BAL_OPEN>" +  lResultSet.getDouble("BAL_OPEN") +   "</BAL_OPEN>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dr_amt") )
              lXmlBuffer = lXmlBuffer +   "<DR_AMT>" +  lResultSet.getDouble("DR_AMT") +   "</DR_AMT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cr_amt") )
              lXmlBuffer = lXmlBuffer +   "<CR_AMT>" +  lResultSet.getDouble("CR_AMT") +   "</CR_AMT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ar_bal") )
              lXmlBuffer = lXmlBuffer +   "<AR_BAL>" +  lResultSet.getDouble("AR_BAL") +   "</AR_BAL>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sal_cycle_code") )
              lXmlBuffer = lXmlBuffer +   "<SAL_CYCLE_CODE>" +  lResultSet.getString("SAL_CYCLE_CODE") +   "</SAL_CYCLE_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bill_cycle_code") )
              lXmlBuffer = lXmlBuffer +   "<BILL_CYCLE_CODE>" +  lResultSet.getString("BILL_CYCLE_CODE") +   "</BILL_CYCLE_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_id") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_ID>" +  lResultSet.getString("AGREEMENT_ID") +   "</AGREEMENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_eff_date") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_EFF_DATE>" +  lResultSet.getString("AGREEMENT_EFF_DATE") +   "</AGREEMENT_EFF_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_exp_date") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_EXP_DATE>" +  lResultSet.getString("AGREEMENT_EXP_DATE") +   "</AGREEMENT_EXP_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_CRE_DATE>" +  lResultSet.getString("AGREEMENT_CRE_DATE") +   "</AGREEMENT_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_sts") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_STS>" +  lResultSet.getString("AGREEMENT_STS") +   "</AGREEMENT_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_STS_DATE>" +  lResultSet.getString("AGREEMENT_STS_DATE") +   "</AGREEMENT_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_agreement_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_AGREEMENT_ID>" +  lResultSet.getString("PREV_AGREEMENT_ID") +   "</PREV_AGREEMENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("renew_ind") )
              lXmlBuffer = lXmlBuffer +   "<RENEW_IND>" +  lResultSet.getString("RENEW_IND") +   "</RENEW_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cycle_id") )
              lXmlBuffer = lXmlBuffer +   "<CYCLE_ID>" +  lResultSet.getString("CYCLE_ID") +   "</CYCLE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_training_ind") )
              lXmlBuffer = lXmlBuffer +   "<SPL_TRAINING_IND>" +  lResultSet.getString("SPL_TRAINING_IND") +   "</SPL_TRAINING_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spl_uniform_ind") )
              lXmlBuffer = lXmlBuffer +   "<SPL_UNIFORM_IND>" +  lResultSet.getString("SPL_UNIFORM_IND") +   "</SPL_UNIFORM_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pay_day") )
              lXmlBuffer = lXmlBuffer +   "<PAY_DAY>" +  lResultSet.getByte("PAY_DAY") +   "</PAY_DAY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("basic") )
              lXmlBuffer = lXmlBuffer +   "<BASIC>" +  lResultSet.getDouble("BASIC") +   "</BASIC>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_ind") )
              lXmlBuffer = lXmlBuffer +   "<PF_IND>" +  lResultSet.getString("PF_IND") +   "</PF_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pf_rate") )
              lXmlBuffer = lXmlBuffer +   "<PF_RATE>" +  lResultSet.getDouble("PF_RATE") +   "</PF_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_ind") )
              lXmlBuffer = lXmlBuffer +   "<ESI_IND>" +  lResultSet.getString("ESI_IND") +   "</ESI_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("esi_rate") )
              lXmlBuffer = lXmlBuffer +   "<ESI_RATE>" +  lResultSet.getDouble("ESI_RATE") +   "</ESI_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("da_ind") )
              lXmlBuffer = lXmlBuffer +   "<DA_IND>" +  lResultSet.getString("DA_IND") +   "</DA_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("da_rate") )
              lXmlBuffer = lXmlBuffer +   "<DA_RATE>" +  lResultSet.getDouble("DA_RATE") +   "</DA_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ta_ind") )
              lXmlBuffer = lXmlBuffer +   "<TA_IND>" +  lResultSet.getString("TA_IND") +   "</TA_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ta_rate") )
              lXmlBuffer = lXmlBuffer +   "<TA_RATE>" +  lResultSet.getDouble("TA_RATE") +   "</TA_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hra_ind") )
              lXmlBuffer = lXmlBuffer +   "<HRA_IND>" +  lResultSet.getString("HRA_IND") +   "</HRA_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("hra_rate") )
              lXmlBuffer = lXmlBuffer +   "<HRA_RATE>" +  lResultSet.getDouble("HRA_RATE") +   "</HRA_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("staff_wf_ind") )
              lXmlBuffer = lXmlBuffer +   "<STAFF_WF_IND>" +  lResultSet.getString("STAFF_WF_IND") +   "</STAFF_WF_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("staff_wf_rate") )
              lXmlBuffer = lXmlBuffer +   "<STAFF_WF_RATE>" +  lResultSet.getDouble("STAFF_WF_RATE") +   "</STAFF_WF_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lunch_ind") )
              lXmlBuffer = lXmlBuffer +   "<LUNCH_IND>" +  lResultSet.getString("LUNCH_IND") +   "</LUNCH_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lunch_rate") )
              lXmlBuffer = lXmlBuffer +   "<LUNCH_RATE>" +  lResultSet.getDouble("LUNCH_RATE") +   "</LUNCH_RATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("jurisdiction") )
              lXmlBuffer = lXmlBuffer +   "<JURISDICTION>" +  lResultSet.getString("JURISDICTION") +   "</JURISDICTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cacnel_remark") )
              lXmlBuffer = lXmlBuffer +   "<CACNEL_REMARK>" +  lResultSet.getString("CACNEL_REMARK") +   "</CACNEL_REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("service_charge") )
              lXmlBuffer = lXmlBuffer +   "<SERVICE_CHARGE>" +  lResultSet.getDouble("SERVICE_CHARGE") +   "</SERVICE_CHARGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("service_tax") )
              lXmlBuffer = lXmlBuffer +   "<SERVICE_TAX>" +  lResultSet.getDouble("SERVICE_TAX") +   "</SERVICE_TAX>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("weeken_off_ind") )
              lXmlBuffer = lXmlBuffer +   "<WEEKEN_OFF_IND>" +  lResultSet.getString("WEEKEN_OFF_IND") +   "</WEEKEN_OFF_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("working_days") )
              lXmlBuffer = lXmlBuffer +   "<WORKING_DAYS>" +  lResultSet.getInt("WORKING_DAYS") +   "</WORKING_DAYS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("manpower_qty") )
              lXmlBuffer = lXmlBuffer +   "<MANPOWER_QTY>" +  lResultSet.getInt("MANPOWER_QTY") +   "</MANPOWER_QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("work_hour_qty") )
              lXmlBuffer = lXmlBuffer +   "<WORK_HOUR_QTY>" +  lResultSet.getInt("WORK_HOUR_QTY") +   "</WORK_HOUR_QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ot_hour_qty") )
              lXmlBuffer = lXmlBuffer +   "<OT_HOUR_QTY>" +  lResultSet.getInt("OT_HOUR_QTY") +   "</OT_HOUR_QTY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("labour_licence_ind") )
              lXmlBuffer = lXmlBuffer +   "<LABOUR_LICENCE_IND>" +  lResultSet.getString("LABOUR_LICENCE_IND") +   "</LABOUR_LICENCE_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("labour_licence_num") )
              lXmlBuffer = lXmlBuffer +   "<LABOUR_LICENCE_NUM>" +  lResultSet.getString("LABOUR_LICENCE_NUM") +   "</LABOUR_LICENCE_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("labour_licence_date") )
              lXmlBuffer = lXmlBuffer +   "<LABOUR_LICENCE_DATE>" +  lResultSet.getString("LABOUR_LICENCE_DATE") +   "</LABOUR_LICENCE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("labour_licence_exp_date") )
              lXmlBuffer = lXmlBuffer +   "<LABOUR_LICENCE_EXP_DATE>" +  lResultSet.getString("LABOUR_LICENCE_EXP_DATE") +   "</LABOUR_LICENCE_EXP_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_status") )
              lXmlBuffer = lXmlBuffer +   "<REC_STATUS>" +  lResultSet.getString("REC_STATUS") +   "</REC_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_name") )
              lXmlBuffer = lXmlBuffer +   "<FILE_NAME>" +  lResultSet.getString("FILE_NAME") +   "</FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_DATE>" +  lResultSet.getString("FILE_CRE_DATE") +   "</FILE_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_TIME>" +  lResultSet.getString("FILE_CRE_TIME") +   "</FILE_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_status") )
              lXmlBuffer = lXmlBuffer +   "<FILE_STATUS>" +  lResultSet.getString("FILE_STATUS") +   "</FILE_STATUS>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</DmCustomer>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtDmCustomerRecByRowid
               ( String inRowId
               , DmCustomerTabObj  outDmCustomerTabObj
               )
  {
    sop("gtDmCustomerRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "customer_type, "+
                                 "customer_ctg, "+
                                 "customer_name, "+
                                 "customer_group, "+
                                 "referred_by, "+
                                 "turn_over, "+
                                 "business_area_cd, "+
                                 "state_code, "+
                                 "region_id, "+
                                 "country_code, "+
                                 "status, "+
                                 "expiration_date, "+
                                 "effective_date, "+
                                 "business_type, "+
                                 "business_est_date, "+
                                 "employee_strength, "+
                                 "business_currency, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "address_3, "+
                                 "cst_form_num, "+
                                 "cst_form_date, "+
                                 "lst_form_num, "+
                                 "lst_form_date, "+
                                 "tin_num, "+
                                 "tin_date, "+
                                 "pan_num, "+
                                 "pan_date, "+
                                 "tan_num, "+
                                 "tan_date, "+
                                 "strn_num, "+
                                 "strn_date, "+
                                 "account_num, "+
                                 "bal_close, "+
                                 "bal_open, "+
                                 "dr_amt, "+
                                 "cr_amt, "+
                                 "ar_bal, "+
                                 "sal_cycle_code, "+
                                 "bill_cycle_code, "+
                                 "agreement_id, "+
                                 "agreement_eff_date, "+
                                 "agreement_exp_date, "+
                                 "agreement_cre_date, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "prev_agreement_id, "+
                                 "renew_ind, "+
                                 "cycle_id, "+
                                 "spl_training_ind, "+
                                 "spl_uniform_ind, "+
                                 "pay_day, "+
                                 "basic, "+
                                 "pf_ind, "+
                                 "pf_rate, "+
                                 "esi_ind, "+
                                 "esi_rate, "+
                                 "da_ind, "+
                                 "da_rate, "+
                                 "ta_ind, "+
                                 "ta_rate, "+
                                 "hra_ind, "+
                                 "hra_rate, "+
                                 "staff_wf_ind, "+
                                 "staff_wf_rate, "+
                                 "lunch_ind, "+
                                 "lunch_rate, "+
                                 "jurisdiction, "+
                                 "remark, "+
                                 "cacnel_remark, "+
                                 "service_charge, "+
                                 "service_tax, "+
                                 "weeken_off_ind, "+
                                 "working_days, "+
                                 "manpower_qty, "+
                                 "work_hour_qty, "+
                                 "ot_hour_qty, "+
                                 "labour_licence_ind, "+
                                 "labour_licence_num, "+
                                 "labour_licence_date, "+
                                 "labour_licence_exp_date, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUSTOMER "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outDmCustomerTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmCustomerTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmCustomerTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmCustomerTabObj.customer_type  =  lResultSet.getString("CUSTOMER_TYPE");
          outDmCustomerTabObj.customer_ctg  =  lResultSet.getString("CUSTOMER_CTG");
          outDmCustomerTabObj.customer_name  =  lResultSet.getString("CUSTOMER_NAME");
          outDmCustomerTabObj.customer_group  =  lResultSet.getString("CUSTOMER_GROUP");
          outDmCustomerTabObj.referred_by  =  lResultSet.getString("REFERRED_BY");
          outDmCustomerTabObj.turn_over  =  lResultSet.getDouble("TURN_OVER");
          outDmCustomerTabObj.business_area_cd  =  lResultSet.getString("BUSINESS_AREA_CD");
          outDmCustomerTabObj.state_code  =  lResultSet.getString("STATE_CODE");
          outDmCustomerTabObj.region_id  =  lResultSet.getString("REGION_ID");
          outDmCustomerTabObj.country_code  =  lResultSet.getString("COUNTRY_CODE");
          outDmCustomerTabObj.status  =  lResultSet.getString("STATUS");
          outDmCustomerTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outDmCustomerTabObj.expiration_date != null && outDmCustomerTabObj.expiration_date.length() > 0 ) 
            outDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outDmCustomerTabObj.effective_date != null && outDmCustomerTabObj.effective_date.length() > 0 ) 
            outDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.effective_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.business_type  =  lResultSet.getString("BUSINESS_TYPE");
          outDmCustomerTabObj.business_est_date  =  lResultSet.getString("BUSINESS_EST_DATE");

          if ( outDmCustomerTabObj.business_est_date != null && outDmCustomerTabObj.business_est_date.length() > 0 ) 
            outDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.employee_strength  =  lResultSet.getInt("EMPLOYEE_STRENGTH");
          outDmCustomerTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          outDmCustomerTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outDmCustomerTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outDmCustomerTabObj.address_3  =  lResultSet.getString("ADDRESS_3");
          outDmCustomerTabObj.cst_form_num  =  lResultSet.getString("CST_FORM_NUM");
          outDmCustomerTabObj.cst_form_date  =  lResultSet.getString("CST_FORM_DATE");

          if ( outDmCustomerTabObj.cst_form_date != null && outDmCustomerTabObj.cst_form_date.length() > 0 ) 
            outDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.lst_form_num  =  lResultSet.getString("LST_FORM_NUM");
          outDmCustomerTabObj.lst_form_date  =  lResultSet.getString("LST_FORM_DATE");

          if ( outDmCustomerTabObj.lst_form_date != null && outDmCustomerTabObj.lst_form_date.length() > 0 ) 
            outDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.tin_num  =  lResultSet.getString("TIN_NUM");
          outDmCustomerTabObj.tin_date  =  lResultSet.getString("TIN_DATE");

          if ( outDmCustomerTabObj.tin_date != null && outDmCustomerTabObj.tin_date.length() > 0 ) 
            outDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.tin_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          outDmCustomerTabObj.pan_date  =  lResultSet.getString("PAN_DATE");

          if ( outDmCustomerTabObj.pan_date != null && outDmCustomerTabObj.pan_date.length() > 0 ) 
            outDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.pan_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.tan_num  =  lResultSet.getString("TAN_NUM");
          outDmCustomerTabObj.tan_date  =  lResultSet.getString("TAN_DATE");

          if ( outDmCustomerTabObj.tan_date != null && outDmCustomerTabObj.tan_date.length() > 0 ) 
            outDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.tan_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.strn_num  =  lResultSet.getString("STRN_NUM");
          outDmCustomerTabObj.strn_date  =  lResultSet.getString("STRN_DATE");

          if ( outDmCustomerTabObj.strn_date != null && outDmCustomerTabObj.strn_date.length() > 0 ) 
            outDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.strn_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.account_num  =  lResultSet.getString("ACCOUNT_NUM");
          outDmCustomerTabObj.bal_close  =  lResultSet.getDouble("BAL_CLOSE");
          outDmCustomerTabObj.bal_open  =  lResultSet.getDouble("BAL_OPEN");
          outDmCustomerTabObj.dr_amt  =  lResultSet.getDouble("DR_AMT");
          outDmCustomerTabObj.cr_amt  =  lResultSet.getDouble("CR_AMT");
          outDmCustomerTabObj.ar_bal  =  lResultSet.getDouble("AR_BAL");
          outDmCustomerTabObj.sal_cycle_code  =  lResultSet.getString("SAL_CYCLE_CODE");
          outDmCustomerTabObj.bill_cycle_code  =  lResultSet.getString("BILL_CYCLE_CODE");
          outDmCustomerTabObj.agreement_id  =  lResultSet.getString("AGREEMENT_ID");
          outDmCustomerTabObj.agreement_eff_date  =  lResultSet.getString("AGREEMENT_EFF_DATE");

          if ( outDmCustomerTabObj.agreement_eff_date != null && outDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_exp_date  =  lResultSet.getString("AGREEMENT_EXP_DATE");

          if ( outDmCustomerTabObj.agreement_exp_date != null && outDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_cre_date  =  lResultSet.getString("AGREEMENT_CRE_DATE");

          if ( outDmCustomerTabObj.agreement_cre_date != null && outDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          outDmCustomerTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( outDmCustomerTabObj.agreement_sts_date != null && outDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            outDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.prev_agreement_id  =  lResultSet.getString("PREV_AGREEMENT_ID");
          outDmCustomerTabObj.renew_ind  =  lResultSet.getString("RENEW_IND");
          outDmCustomerTabObj.cycle_id  =  lResultSet.getString("CYCLE_ID");
          outDmCustomerTabObj.spl_training_ind  =  lResultSet.getString("SPL_TRAINING_IND");
          outDmCustomerTabObj.spl_uniform_ind  =  lResultSet.getString("SPL_UNIFORM_IND");
          outDmCustomerTabObj.pay_day  =  lResultSet.getByte("PAY_DAY");
          outDmCustomerTabObj.basic  =  lResultSet.getDouble("BASIC");
          outDmCustomerTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          outDmCustomerTabObj.pf_rate  =  lResultSet.getDouble("PF_RATE");
          outDmCustomerTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          outDmCustomerTabObj.esi_rate  =  lResultSet.getDouble("ESI_RATE");
          outDmCustomerTabObj.da_ind  =  lResultSet.getString("DA_IND");
          outDmCustomerTabObj.da_rate  =  lResultSet.getDouble("DA_RATE");
          outDmCustomerTabObj.ta_ind  =  lResultSet.getString("TA_IND");
          outDmCustomerTabObj.ta_rate  =  lResultSet.getDouble("TA_RATE");
          outDmCustomerTabObj.hra_ind  =  lResultSet.getString("HRA_IND");
          outDmCustomerTabObj.hra_rate  =  lResultSet.getDouble("HRA_RATE");
          outDmCustomerTabObj.staff_wf_ind  =  lResultSet.getString("STAFF_WF_IND");
          outDmCustomerTabObj.staff_wf_rate  =  lResultSet.getDouble("STAFF_WF_RATE");
          outDmCustomerTabObj.lunch_ind  =  lResultSet.getString("LUNCH_IND");
          outDmCustomerTabObj.lunch_rate  =  lResultSet.getDouble("LUNCH_RATE");
          outDmCustomerTabObj.jurisdiction  =  lResultSet.getString("JURISDICTION");
          outDmCustomerTabObj.remark  =  lResultSet.getString("REMARK");
          outDmCustomerTabObj.cacnel_remark  =  lResultSet.getString("CACNEL_REMARK");
          outDmCustomerTabObj.service_charge  =  lResultSet.getDouble("SERVICE_CHARGE");
          outDmCustomerTabObj.service_tax  =  lResultSet.getDouble("SERVICE_TAX");
          outDmCustomerTabObj.weeken_off_ind  =  lResultSet.getString("WEEKEN_OFF_IND");
          outDmCustomerTabObj.working_days  =  lResultSet.getInt("WORKING_DAYS");
          outDmCustomerTabObj.manpower_qty  =  lResultSet.getInt("MANPOWER_QTY");
          outDmCustomerTabObj.work_hour_qty  =  lResultSet.getInt("WORK_HOUR_QTY");
          outDmCustomerTabObj.ot_hour_qty  =  lResultSet.getInt("OT_HOUR_QTY");
          outDmCustomerTabObj.labour_licence_ind  =  lResultSet.getString("LABOUR_LICENCE_IND");
          outDmCustomerTabObj.labour_licence_num  =  lResultSet.getString("LABOUR_LICENCE_NUM");
          outDmCustomerTabObj.labour_licence_date  =  lResultSet.getString("LABOUR_LICENCE_DATE");

          if ( outDmCustomerTabObj.labour_licence_date != null && outDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            outDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.labour_licence_exp_date  =  lResultSet.getString("LABOUR_LICENCE_EXP_DATE");

          if ( outDmCustomerTabObj.labour_licence_exp_date != null && outDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            outDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmCustomerTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmCustomerTabObj.rec_cre_date != null && outDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            outDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmCustomerTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmCustomerTabObj.rec_upd_date != null && outDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            outDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmCustomerTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmCustomerTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmCustomerTabObj.file_cre_date != null && outDmCustomerTabObj.file_cre_date.length() > 0 ) 
            outDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmCustomerTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmCustomerTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmCustomerTabObj( outDmCustomerTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerArr
               ( String inDmCustomerWhereText
               , ArrayList  outDmCustomerTabObjArr
               )
  {
    sop("gtDmCustomerArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "customer_type, "+
                                 "customer_ctg, "+
                                 "customer_name, "+
                                 "customer_group, "+
                                 "referred_by, "+
                                 "turn_over, "+
                                 "business_area_cd, "+
                                 "state_code, "+
                                 "region_id, "+
                                 "country_code, "+
                                 "status, "+
                                 "expiration_date, "+
                                 "effective_date, "+
                                 "business_type, "+
                                 "business_est_date, "+
                                 "employee_strength, "+
                                 "business_currency, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "address_3, "+
                                 "cst_form_num, "+
                                 "cst_form_date, "+
                                 "lst_form_num, "+
                                 "lst_form_date, "+
                                 "tin_num, "+
                                 "tin_date, "+
                                 "pan_num, "+
                                 "pan_date, "+
                                 "tan_num, "+
                                 "tan_date, "+
                                 "strn_num, "+
                                 "strn_date, "+
                                 "account_num, "+
                                 "bal_close, "+
                                 "bal_open, "+
                                 "dr_amt, "+
                                 "cr_amt, "+
                                 "ar_bal, "+
                                 "sal_cycle_code, "+
                                 "bill_cycle_code, "+
                                 "agreement_id, "+
                                 "agreement_eff_date, "+
                                 "agreement_exp_date, "+
                                 "agreement_cre_date, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "prev_agreement_id, "+
                                 "renew_ind, "+
                                 "cycle_id, "+
                                 "spl_training_ind, "+
                                 "spl_uniform_ind, "+
                                 "pay_day, "+
                                 "basic, "+
                                 "pf_ind, "+
                                 "pf_rate, "+
                                 "esi_ind, "+
                                 "esi_rate, "+
                                 "da_ind, "+
                                 "da_rate, "+
                                 "ta_ind, "+
                                 "ta_rate, "+
                                 "hra_ind, "+
                                 "hra_rate, "+
                                 "staff_wf_ind, "+
                                 "staff_wf_rate, "+
                                 "lunch_ind, "+
                                 "lunch_rate, "+
                                 "jurisdiction, "+
                                 "remark, "+
                                 "cacnel_remark, "+
                                 "service_charge, "+
                                 "service_tax, "+
                                 "weeken_off_ind, "+
                                 "working_days, "+
                                 "manpower_qty, "+
                                 "work_hour_qty, "+
                                 "ot_hour_qty, "+
                                 "labour_licence_ind, "+
                                 "labour_licence_num, "+
                                 "labour_licence_date, "+
                                 "labour_licence_exp_date, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmCustomerTabObj  lDmCustomerTabObj = new DmCustomerTabObj();
          lDmCustomerTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lDmCustomerTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmCustomerTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmCustomerTabObj.customer_type  =  lResultSet.getString("CUSTOMER_TYPE");
          lDmCustomerTabObj.customer_ctg  =  lResultSet.getString("CUSTOMER_CTG");
          lDmCustomerTabObj.customer_name  =  lResultSet.getString("CUSTOMER_NAME");
          lDmCustomerTabObj.customer_group  =  lResultSet.getString("CUSTOMER_GROUP");
          lDmCustomerTabObj.referred_by  =  lResultSet.getString("REFERRED_BY");
          lDmCustomerTabObj.turn_over  =  lResultSet.getDouble("TURN_OVER");
          lDmCustomerTabObj.business_area_cd  =  lResultSet.getString("BUSINESS_AREA_CD");
          lDmCustomerTabObj.state_code  =  lResultSet.getString("STATE_CODE");
          lDmCustomerTabObj.region_id  =  lResultSet.getString("REGION_ID");
          lDmCustomerTabObj.country_code  =  lResultSet.getString("COUNTRY_CODE");
          lDmCustomerTabObj.status  =  lResultSet.getString("STATUS");
          lDmCustomerTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lDmCustomerTabObj.expiration_date != null && lDmCustomerTabObj.expiration_date.length() > 0 ) 
            lDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lDmCustomerTabObj.effective_date != null && lDmCustomerTabObj.effective_date.length() > 0 ) 
            lDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.effective_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.business_type  =  lResultSet.getString("BUSINESS_TYPE");
          lDmCustomerTabObj.business_est_date  =  lResultSet.getString("BUSINESS_EST_DATE");

          if ( lDmCustomerTabObj.business_est_date != null && lDmCustomerTabObj.business_est_date.length() > 0 ) 
            lDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.employee_strength  =  lResultSet.getInt("EMPLOYEE_STRENGTH");
          lDmCustomerTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
          lDmCustomerTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lDmCustomerTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lDmCustomerTabObj.address_3  =  lResultSet.getString("ADDRESS_3");
          lDmCustomerTabObj.cst_form_num  =  lResultSet.getString("CST_FORM_NUM");
          lDmCustomerTabObj.cst_form_date  =  lResultSet.getString("CST_FORM_DATE");

          if ( lDmCustomerTabObj.cst_form_date != null && lDmCustomerTabObj.cst_form_date.length() > 0 ) 
            lDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.lst_form_num  =  lResultSet.getString("LST_FORM_NUM");
          lDmCustomerTabObj.lst_form_date  =  lResultSet.getString("LST_FORM_DATE");

          if ( lDmCustomerTabObj.lst_form_date != null && lDmCustomerTabObj.lst_form_date.length() > 0 ) 
            lDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.tin_num  =  lResultSet.getString("TIN_NUM");
          lDmCustomerTabObj.tin_date  =  lResultSet.getString("TIN_DATE");

          if ( lDmCustomerTabObj.tin_date != null && lDmCustomerTabObj.tin_date.length() > 0 ) 
            lDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tin_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
          lDmCustomerTabObj.pan_date  =  lResultSet.getString("PAN_DATE");

          if ( lDmCustomerTabObj.pan_date != null && lDmCustomerTabObj.pan_date.length() > 0 ) 
            lDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.pan_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.tan_num  =  lResultSet.getString("TAN_NUM");
          lDmCustomerTabObj.tan_date  =  lResultSet.getString("TAN_DATE");

          if ( lDmCustomerTabObj.tan_date != null && lDmCustomerTabObj.tan_date.length() > 0 ) 
            lDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tan_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.strn_num  =  lResultSet.getString("STRN_NUM");
          lDmCustomerTabObj.strn_date  =  lResultSet.getString("STRN_DATE");

          if ( lDmCustomerTabObj.strn_date != null && lDmCustomerTabObj.strn_date.length() > 0 ) 
            lDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.strn_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.account_num  =  lResultSet.getString("ACCOUNT_NUM");
          lDmCustomerTabObj.bal_close  =  lResultSet.getDouble("BAL_CLOSE");
          lDmCustomerTabObj.bal_open  =  lResultSet.getDouble("BAL_OPEN");
          lDmCustomerTabObj.dr_amt  =  lResultSet.getDouble("DR_AMT");
          lDmCustomerTabObj.cr_amt  =  lResultSet.getDouble("CR_AMT");
          lDmCustomerTabObj.ar_bal  =  lResultSet.getDouble("AR_BAL");
          lDmCustomerTabObj.sal_cycle_code  =  lResultSet.getString("SAL_CYCLE_CODE");
          lDmCustomerTabObj.bill_cycle_code  =  lResultSet.getString("BILL_CYCLE_CODE");
          lDmCustomerTabObj.agreement_id  =  lResultSet.getString("AGREEMENT_ID");
          lDmCustomerTabObj.agreement_eff_date  =  lResultSet.getString("AGREEMENT_EFF_DATE");

          if ( lDmCustomerTabObj.agreement_eff_date != null && lDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_exp_date  =  lResultSet.getString("AGREEMENT_EXP_DATE");

          if ( lDmCustomerTabObj.agreement_exp_date != null && lDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_cre_date  =  lResultSet.getString("AGREEMENT_CRE_DATE");

          if ( lDmCustomerTabObj.agreement_cre_date != null && lDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          lDmCustomerTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( lDmCustomerTabObj.agreement_sts_date != null && lDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.prev_agreement_id  =  lResultSet.getString("PREV_AGREEMENT_ID");
          lDmCustomerTabObj.renew_ind  =  lResultSet.getString("RENEW_IND");
          lDmCustomerTabObj.cycle_id  =  lResultSet.getString("CYCLE_ID");
          lDmCustomerTabObj.spl_training_ind  =  lResultSet.getString("SPL_TRAINING_IND");
          lDmCustomerTabObj.spl_uniform_ind  =  lResultSet.getString("SPL_UNIFORM_IND");
          lDmCustomerTabObj.pay_day  =  lResultSet.getByte("PAY_DAY");
          lDmCustomerTabObj.basic  =  lResultSet.getDouble("BASIC");
          lDmCustomerTabObj.pf_ind  =  lResultSet.getString("PF_IND");
          lDmCustomerTabObj.pf_rate  =  lResultSet.getDouble("PF_RATE");
          lDmCustomerTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
          lDmCustomerTabObj.esi_rate  =  lResultSet.getDouble("ESI_RATE");
          lDmCustomerTabObj.da_ind  =  lResultSet.getString("DA_IND");
          lDmCustomerTabObj.da_rate  =  lResultSet.getDouble("DA_RATE");
          lDmCustomerTabObj.ta_ind  =  lResultSet.getString("TA_IND");
          lDmCustomerTabObj.ta_rate  =  lResultSet.getDouble("TA_RATE");
          lDmCustomerTabObj.hra_ind  =  lResultSet.getString("HRA_IND");
          lDmCustomerTabObj.hra_rate  =  lResultSet.getDouble("HRA_RATE");
          lDmCustomerTabObj.staff_wf_ind  =  lResultSet.getString("STAFF_WF_IND");
          lDmCustomerTabObj.staff_wf_rate  =  lResultSet.getDouble("STAFF_WF_RATE");
          lDmCustomerTabObj.lunch_ind  =  lResultSet.getString("LUNCH_IND");
          lDmCustomerTabObj.lunch_rate  =  lResultSet.getDouble("LUNCH_RATE");
          lDmCustomerTabObj.jurisdiction  =  lResultSet.getString("JURISDICTION");
          lDmCustomerTabObj.remark  =  lResultSet.getString("REMARK");
          lDmCustomerTabObj.cacnel_remark  =  lResultSet.getString("CACNEL_REMARK");
          lDmCustomerTabObj.service_charge  =  lResultSet.getDouble("SERVICE_CHARGE");
          lDmCustomerTabObj.service_tax  =  lResultSet.getDouble("SERVICE_TAX");
          lDmCustomerTabObj.weeken_off_ind  =  lResultSet.getString("WEEKEN_OFF_IND");
          lDmCustomerTabObj.working_days  =  lResultSet.getInt("WORKING_DAYS");
          lDmCustomerTabObj.manpower_qty  =  lResultSet.getInt("MANPOWER_QTY");
          lDmCustomerTabObj.work_hour_qty  =  lResultSet.getInt("WORK_HOUR_QTY");
          lDmCustomerTabObj.ot_hour_qty  =  lResultSet.getInt("OT_HOUR_QTY");
          lDmCustomerTabObj.labour_licence_ind  =  lResultSet.getString("LABOUR_LICENCE_IND");
          lDmCustomerTabObj.labour_licence_num  =  lResultSet.getString("LABOUR_LICENCE_NUM");
          lDmCustomerTabObj.labour_licence_date  =  lResultSet.getString("LABOUR_LICENCE_DATE");

          if ( lDmCustomerTabObj.labour_licence_date != null && lDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.labour_licence_exp_date  =  lResultSet.getString("LABOUR_LICENCE_EXP_DATE");

          if ( lDmCustomerTabObj.labour_licence_exp_date != null && lDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmCustomerTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmCustomerTabObj.rec_cre_date != null && lDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            lDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmCustomerTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmCustomerTabObj.rec_upd_date != null && lDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            lDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmCustomerTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmCustomerTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmCustomerTabObj.file_cre_date != null && lDmCustomerTabObj.file_cre_date.length() > 0 ) 
            lDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmCustomerTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmCustomerTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmCustomerTabObj( lDmCustomerTabObj );

          outDmCustomerTabObjArr.add(  lDmCustomerTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustomerTabObjArr != null && outDmCustomerTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerArrDist
               ( String inDmCustomerWhereText
               , String inDistDmCustomerField
               , ArrayList  outDmCustomerTabObjArr
               )
  {

    sop("gtDmCustomerArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";
  

       String lDistDmCustomerFieldQry = inDistDmCustomerField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmCustomerFieldQry+
                         " FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmCustomerField.substring(inDistDmCustomerField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          DmCustomerTabObj  lDmCustomerTabObj = new DmCustomerTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lDmCustomerTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_id") )
              lDmCustomerTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_type") )
              lDmCustomerTabObj.customer_type  =  lResultSet.getString("CUSTOMER_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_ctg") )
              lDmCustomerTabObj.customer_ctg  =  lResultSet.getString("CUSTOMER_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_name") )
              lDmCustomerTabObj.customer_name  =  lResultSet.getString("CUSTOMER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_group") )
              lDmCustomerTabObj.customer_group  =  lResultSet.getString("CUSTOMER_GROUP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("referred_by") )
              lDmCustomerTabObj.referred_by  =  lResultSet.getString("REFERRED_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("turn_over") )
              lDmCustomerTabObj.turn_over  =  lResultSet.getDouble("TURN_OVER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("business_area_cd") )
              lDmCustomerTabObj.business_area_cd  =  lResultSet.getString("BUSINESS_AREA_CD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("state_code") )
              lDmCustomerTabObj.state_code  =  lResultSet.getString("STATE_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("region_id") )
              lDmCustomerTabObj.region_id  =  lResultSet.getString("REGION_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country_code") )
              lDmCustomerTabObj.country_code  =  lResultSet.getString("COUNTRY_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lDmCustomerTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("expiration_date") )
              {
              lDmCustomerTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
  
          if ( lDmCustomerTabObj.expiration_date != null && lDmCustomerTabObj.expiration_date.length() > 0 ) 
            lDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.expiration_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("effective_date") )
              {
              lDmCustomerTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
  
          if ( lDmCustomerTabObj.effective_date != null && lDmCustomerTabObj.effective_date.length() > 0 ) 
            lDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.effective_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("business_type") )
              lDmCustomerTabObj.business_type  =  lResultSet.getString("BUSINESS_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("business_est_date") )
              {
              lDmCustomerTabObj.business_est_date  =  lResultSet.getString("BUSINESS_EST_DATE");
  
          if ( lDmCustomerTabObj.business_est_date != null && lDmCustomerTabObj.business_est_date.length() > 0 ) 
            lDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.business_est_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("employee_strength") )
              lDmCustomerTabObj.employee_strength  =  lResultSet.getInt("EMPLOYEE_STRENGTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("business_currency") )
              lDmCustomerTabObj.business_currency  =  lResultSet.getString("BUSINESS_CURRENCY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_1") )
              lDmCustomerTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_2") )
              lDmCustomerTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_3") )
              lDmCustomerTabObj.address_3  =  lResultSet.getString("ADDRESS_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cst_form_num") )
              lDmCustomerTabObj.cst_form_num  =  lResultSet.getString("CST_FORM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cst_form_date") )
              {
              lDmCustomerTabObj.cst_form_date  =  lResultSet.getString("CST_FORM_DATE");
  
          if ( lDmCustomerTabObj.cst_form_date != null && lDmCustomerTabObj.cst_form_date.length() > 0 ) 
            lDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.cst_form_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lst_form_num") )
              lDmCustomerTabObj.lst_form_num  =  lResultSet.getString("LST_FORM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lst_form_date") )
              {
              lDmCustomerTabObj.lst_form_date  =  lResultSet.getString("LST_FORM_DATE");
  
          if ( lDmCustomerTabObj.lst_form_date != null && lDmCustomerTabObj.lst_form_date.length() > 0 ) 
            lDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.lst_form_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tin_num") )
              lDmCustomerTabObj.tin_num  =  lResultSet.getString("TIN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tin_date") )
              {
              lDmCustomerTabObj.tin_date  =  lResultSet.getString("TIN_DATE");
  
          if ( lDmCustomerTabObj.tin_date != null && lDmCustomerTabObj.tin_date.length() > 0 ) 
            lDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tin_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_num") )
              lDmCustomerTabObj.pan_num  =  lResultSet.getString("PAN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pan_date") )
              {
              lDmCustomerTabObj.pan_date  =  lResultSet.getString("PAN_DATE");
  
          if ( lDmCustomerTabObj.pan_date != null && lDmCustomerTabObj.pan_date.length() > 0 ) 
            lDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.pan_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tan_num") )
              lDmCustomerTabObj.tan_num  =  lResultSet.getString("TAN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tan_date") )
              {
              lDmCustomerTabObj.tan_date  =  lResultSet.getString("TAN_DATE");
  
          if ( lDmCustomerTabObj.tan_date != null && lDmCustomerTabObj.tan_date.length() > 0 ) 
            lDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.tan_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("strn_num") )
              lDmCustomerTabObj.strn_num  =  lResultSet.getString("STRN_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("strn_date") )
              {
              lDmCustomerTabObj.strn_date  =  lResultSet.getString("STRN_DATE");
  
          if ( lDmCustomerTabObj.strn_date != null && lDmCustomerTabObj.strn_date.length() > 0 ) 
            lDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.strn_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("account_num") )
              lDmCustomerTabObj.account_num  =  lResultSet.getString("ACCOUNT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bal_close") )
              lDmCustomerTabObj.bal_close  =  lResultSet.getDouble("BAL_CLOSE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bal_open") )
              lDmCustomerTabObj.bal_open  =  lResultSet.getDouble("BAL_OPEN");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dr_amt") )
              lDmCustomerTabObj.dr_amt  =  lResultSet.getDouble("DR_AMT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cr_amt") )
              lDmCustomerTabObj.cr_amt  =  lResultSet.getDouble("CR_AMT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ar_bal") )
              lDmCustomerTabObj.ar_bal  =  lResultSet.getDouble("AR_BAL");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sal_cycle_code") )
              lDmCustomerTabObj.sal_cycle_code  =  lResultSet.getString("SAL_CYCLE_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bill_cycle_code") )
              lDmCustomerTabObj.bill_cycle_code  =  lResultSet.getString("BILL_CYCLE_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_id") )
              lDmCustomerTabObj.agreement_id  =  lResultSet.getString("AGREEMENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_eff_date") )
              {
              lDmCustomerTabObj.agreement_eff_date  =  lResultSet.getString("AGREEMENT_EFF_DATE");
  
          if ( lDmCustomerTabObj.agreement_eff_date != null && lDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_eff_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_exp_date") )
              {
              lDmCustomerTabObj.agreement_exp_date  =  lResultSet.getString("AGREEMENT_EXP_DATE");
  
          if ( lDmCustomerTabObj.agreement_exp_date != null && lDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_exp_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_cre_date") )
              {
              lDmCustomerTabObj.agreement_cre_date  =  lResultSet.getString("AGREEMENT_CRE_DATE");
  
          if ( lDmCustomerTabObj.agreement_cre_date != null && lDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_sts") )
              lDmCustomerTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_sts_date") )
              {
              lDmCustomerTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");
  
          if ( lDmCustomerTabObj.agreement_sts_date != null && lDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.agreement_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_agreement_id") )
              lDmCustomerTabObj.prev_agreement_id  =  lResultSet.getString("PREV_AGREEMENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("renew_ind") )
              lDmCustomerTabObj.renew_ind  =  lResultSet.getString("RENEW_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cycle_id") )
              lDmCustomerTabObj.cycle_id  =  lResultSet.getString("CYCLE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_training_ind") )
              lDmCustomerTabObj.spl_training_ind  =  lResultSet.getString("SPL_TRAINING_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spl_uniform_ind") )
              lDmCustomerTabObj.spl_uniform_ind  =  lResultSet.getString("SPL_UNIFORM_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pay_day") )
              lDmCustomerTabObj.pay_day  =  lResultSet.getByte("PAY_DAY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("basic") )
              lDmCustomerTabObj.basic  =  lResultSet.getDouble("BASIC");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_ind") )
              lDmCustomerTabObj.pf_ind  =  lResultSet.getString("PF_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pf_rate") )
              lDmCustomerTabObj.pf_rate  =  lResultSet.getDouble("PF_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_ind") )
              lDmCustomerTabObj.esi_ind  =  lResultSet.getString("ESI_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("esi_rate") )
              lDmCustomerTabObj.esi_rate  =  lResultSet.getDouble("ESI_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("da_ind") )
              lDmCustomerTabObj.da_ind  =  lResultSet.getString("DA_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("da_rate") )
              lDmCustomerTabObj.da_rate  =  lResultSet.getDouble("DA_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ta_ind") )
              lDmCustomerTabObj.ta_ind  =  lResultSet.getString("TA_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ta_rate") )
              lDmCustomerTabObj.ta_rate  =  lResultSet.getDouble("TA_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hra_ind") )
              lDmCustomerTabObj.hra_ind  =  lResultSet.getString("HRA_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("hra_rate") )
              lDmCustomerTabObj.hra_rate  =  lResultSet.getDouble("HRA_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("staff_wf_ind") )
              lDmCustomerTabObj.staff_wf_ind  =  lResultSet.getString("STAFF_WF_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("staff_wf_rate") )
              lDmCustomerTabObj.staff_wf_rate  =  lResultSet.getDouble("STAFF_WF_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lunch_ind") )
              lDmCustomerTabObj.lunch_ind  =  lResultSet.getString("LUNCH_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lunch_rate") )
              lDmCustomerTabObj.lunch_rate  =  lResultSet.getDouble("LUNCH_RATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("jurisdiction") )
              lDmCustomerTabObj.jurisdiction  =  lResultSet.getString("JURISDICTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lDmCustomerTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cacnel_remark") )
              lDmCustomerTabObj.cacnel_remark  =  lResultSet.getString("CACNEL_REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("service_charge") )
              lDmCustomerTabObj.service_charge  =  lResultSet.getDouble("SERVICE_CHARGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("service_tax") )
              lDmCustomerTabObj.service_tax  =  lResultSet.getDouble("SERVICE_TAX");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("weeken_off_ind") )
              lDmCustomerTabObj.weeken_off_ind  =  lResultSet.getString("WEEKEN_OFF_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("working_days") )
              lDmCustomerTabObj.working_days  =  lResultSet.getInt("WORKING_DAYS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("manpower_qty") )
              lDmCustomerTabObj.manpower_qty  =  lResultSet.getInt("MANPOWER_QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("work_hour_qty") )
              lDmCustomerTabObj.work_hour_qty  =  lResultSet.getInt("WORK_HOUR_QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ot_hour_qty") )
              lDmCustomerTabObj.ot_hour_qty  =  lResultSet.getInt("OT_HOUR_QTY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("labour_licence_ind") )
              lDmCustomerTabObj.labour_licence_ind  =  lResultSet.getString("LABOUR_LICENCE_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("labour_licence_num") )
              lDmCustomerTabObj.labour_licence_num  =  lResultSet.getString("LABOUR_LICENCE_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("labour_licence_date") )
              {
              lDmCustomerTabObj.labour_licence_date  =  lResultSet.getString("LABOUR_LICENCE_DATE");
  
          if ( lDmCustomerTabObj.labour_licence_date != null && lDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("labour_licence_exp_date") )
              {
              lDmCustomerTabObj.labour_licence_exp_date  =  lResultSet.getString("LABOUR_LICENCE_EXP_DATE");
  
          if ( lDmCustomerTabObj.labour_licence_exp_date != null && lDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.labour_licence_exp_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_status") )
              lDmCustomerTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lDmCustomerTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lDmCustomerTabObj.rec_cre_date != null && lDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            lDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lDmCustomerTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lDmCustomerTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lDmCustomerTabObj.rec_upd_date != null && lDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            lDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lDmCustomerTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_name") )
              lDmCustomerTabObj.file_name  =  lResultSet.getString("FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_date") )
              {
              lDmCustomerTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");
  
          if ( lDmCustomerTabObj.file_cre_date != null && lDmCustomerTabObj.file_cre_date.length() > 0 ) 
            lDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustomerTabObj.file_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_time") )
              lDmCustomerTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_status") )
              lDmCustomerTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          }
          removeNullDmCustomerTabObj( lDmCustomerTabObj );

          outDmCustomerTabObjArr.add(  lDmCustomerTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustomerTabObjArr != null && outDmCustomerTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustomerStrArrDist
               ( String inDmCustomerWhereText
               , String inDistDmCustomerField
               , ArrayList  outDmCustomerTabObjArr
               )
  {

    sop("gtDmCustomerStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustomerStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";
  

       String lDistDmCustomerFieldQry = inDistDmCustomerField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmCustomerFieldQry+
                         " FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmCustomerField.substring(inDistDmCustomerField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lDmCustomerTabObjStr = "";
       while(lResultSet.next())
       {
          lDmCustomerTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lDmCustomerTabObjStr =   lDmCustomerTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outDmCustomerTabObjArr.add(  lDmCustomerTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustomerTabObjArr != null && outDmCustomerTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValDmCustomer
               ( String inDmCustomerWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValDmCustomer - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValDmCustomer";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullDmCustomerTabObj
               ( 
                 DmCustomerTabObj  outDmCustomerTabObj
               )
  {
  
    if ( outDmCustomerTabObj.org_id == null ) 
     outDmCustomerTabObj.org_id = ""; 
    if ( outDmCustomerTabObj.customer_id == null ) 
     outDmCustomerTabObj.customer_id = ""; 
    if ( outDmCustomerTabObj.customer_type == null ) 
     outDmCustomerTabObj.customer_type = ""; 
    if ( outDmCustomerTabObj.customer_ctg == null ) 
     outDmCustomerTabObj.customer_ctg = ""; 
    if ( outDmCustomerTabObj.customer_name == null ) 
     outDmCustomerTabObj.customer_name = ""; 
    if ( outDmCustomerTabObj.customer_group == null ) 
     outDmCustomerTabObj.customer_group = ""; 
    if ( outDmCustomerTabObj.referred_by == null ) 
     outDmCustomerTabObj.referred_by = ""; 
    if ( outDmCustomerTabObj.turn_over == (double)0.00 ) 
     outDmCustomerTabObj.turn_over = (double)0.00; 
    if ( outDmCustomerTabObj.business_area_cd == null ) 
     outDmCustomerTabObj.business_area_cd = ""; 
    if ( outDmCustomerTabObj.state_code == null ) 
     outDmCustomerTabObj.state_code = ""; 
    if ( outDmCustomerTabObj.region_id == null ) 
     outDmCustomerTabObj.region_id = ""; 
    if ( outDmCustomerTabObj.country_code == null ) 
     outDmCustomerTabObj.country_code = ""; 
    if ( outDmCustomerTabObj.status == null ) 
     outDmCustomerTabObj.status = ""; 
    if ( outDmCustomerTabObj.expiration_date == null ) 
     outDmCustomerTabObj.expiration_date = ""; 
    if ( outDmCustomerTabObj.effective_date == null ) 
     outDmCustomerTabObj.effective_date = ""; 
    if ( outDmCustomerTabObj.business_type == null ) 
     outDmCustomerTabObj.business_type = ""; 
    if ( outDmCustomerTabObj.business_est_date == null ) 
     outDmCustomerTabObj.business_est_date = ""; 
    if ( outDmCustomerTabObj.employee_strength == (int)0 ) 
     outDmCustomerTabObj.employee_strength = (int)0; 
    if ( outDmCustomerTabObj.business_currency == null ) 
     outDmCustomerTabObj.business_currency = ""; 
    if ( outDmCustomerTabObj.address_1 == null ) 
     outDmCustomerTabObj.address_1 = ""; 
    if ( outDmCustomerTabObj.address_2 == null ) 
     outDmCustomerTabObj.address_2 = ""; 
    if ( outDmCustomerTabObj.address_3 == null ) 
     outDmCustomerTabObj.address_3 = ""; 
    if ( outDmCustomerTabObj.cst_form_num == null ) 
     outDmCustomerTabObj.cst_form_num = ""; 
    if ( outDmCustomerTabObj.cst_form_date == null ) 
     outDmCustomerTabObj.cst_form_date = ""; 
    if ( outDmCustomerTabObj.lst_form_num == null ) 
     outDmCustomerTabObj.lst_form_num = ""; 
    if ( outDmCustomerTabObj.lst_form_date == null ) 
     outDmCustomerTabObj.lst_form_date = ""; 
    if ( outDmCustomerTabObj.tin_num == null ) 
     outDmCustomerTabObj.tin_num = ""; 
    if ( outDmCustomerTabObj.tin_date == null ) 
     outDmCustomerTabObj.tin_date = ""; 
    if ( outDmCustomerTabObj.pan_num == null ) 
     outDmCustomerTabObj.pan_num = ""; 
    if ( outDmCustomerTabObj.pan_date == null ) 
     outDmCustomerTabObj.pan_date = ""; 
    if ( outDmCustomerTabObj.tan_num == null ) 
     outDmCustomerTabObj.tan_num = ""; 
    if ( outDmCustomerTabObj.tan_date == null ) 
     outDmCustomerTabObj.tan_date = ""; 
    if ( outDmCustomerTabObj.strn_num == null ) 
     outDmCustomerTabObj.strn_num = ""; 
    if ( outDmCustomerTabObj.strn_date == null ) 
     outDmCustomerTabObj.strn_date = ""; 
    if ( outDmCustomerTabObj.account_num == null ) 
     outDmCustomerTabObj.account_num = ""; 
    if ( outDmCustomerTabObj.bal_close == (double)0.00 ) 
     outDmCustomerTabObj.bal_close = (double)0.00; 
    if ( outDmCustomerTabObj.bal_open == (double)0.00 ) 
     outDmCustomerTabObj.bal_open = (double)0.00; 
    if ( outDmCustomerTabObj.dr_amt == (double)0.00 ) 
     outDmCustomerTabObj.dr_amt = (double)0.00; 
    if ( outDmCustomerTabObj.cr_amt == (double)0.00 ) 
     outDmCustomerTabObj.cr_amt = (double)0.00; 
    if ( outDmCustomerTabObj.ar_bal == (double)0.00 ) 
     outDmCustomerTabObj.ar_bal = (double)0.00; 
    if ( outDmCustomerTabObj.sal_cycle_code == null ) 
     outDmCustomerTabObj.sal_cycle_code = ""; 
    if ( outDmCustomerTabObj.bill_cycle_code == null ) 
     outDmCustomerTabObj.bill_cycle_code = ""; 
    if ( outDmCustomerTabObj.agreement_id == null ) 
     outDmCustomerTabObj.agreement_id = ""; 
    if ( outDmCustomerTabObj.agreement_eff_date == null ) 
     outDmCustomerTabObj.agreement_eff_date = ""; 
    if ( outDmCustomerTabObj.agreement_exp_date == null ) 
     outDmCustomerTabObj.agreement_exp_date = ""; 
    if ( outDmCustomerTabObj.agreement_cre_date == null ) 
     outDmCustomerTabObj.agreement_cre_date = ""; 
    if ( outDmCustomerTabObj.agreement_sts == null ) 
     outDmCustomerTabObj.agreement_sts = ""; 
    if ( outDmCustomerTabObj.agreement_sts_date == null ) 
     outDmCustomerTabObj.agreement_sts_date = ""; 
    if ( outDmCustomerTabObj.prev_agreement_id == null ) 
     outDmCustomerTabObj.prev_agreement_id = ""; 
    if ( outDmCustomerTabObj.renew_ind == null ) 
     outDmCustomerTabObj.renew_ind = ""; 
    if ( outDmCustomerTabObj.cycle_id == null ) 
     outDmCustomerTabObj.cycle_id = ""; 
    if ( outDmCustomerTabObj.spl_training_ind == null ) 
     outDmCustomerTabObj.spl_training_ind = ""; 
    if ( outDmCustomerTabObj.spl_uniform_ind == null ) 
     outDmCustomerTabObj.spl_uniform_ind = ""; 
    if ( outDmCustomerTabObj.pay_day == (int)0 ) 
     outDmCustomerTabObj.pay_day = (int)0; 
    if ( outDmCustomerTabObj.basic == (double)0.00 ) 
     outDmCustomerTabObj.basic = (double)0.00; 
    if ( outDmCustomerTabObj.pf_ind == null ) 
     outDmCustomerTabObj.pf_ind = ""; 
    if ( outDmCustomerTabObj.pf_rate == (double)0.00 ) 
     outDmCustomerTabObj.pf_rate = (double)0.00; 
    if ( outDmCustomerTabObj.esi_ind == null ) 
     outDmCustomerTabObj.esi_ind = ""; 
    if ( outDmCustomerTabObj.esi_rate == (double)0.00 ) 
     outDmCustomerTabObj.esi_rate = (double)0.00; 
    if ( outDmCustomerTabObj.da_ind == null ) 
     outDmCustomerTabObj.da_ind = ""; 
    if ( outDmCustomerTabObj.da_rate == (double)0.00 ) 
     outDmCustomerTabObj.da_rate = (double)0.00; 
    if ( outDmCustomerTabObj.ta_ind == null ) 
     outDmCustomerTabObj.ta_ind = ""; 
    if ( outDmCustomerTabObj.ta_rate == (double)0.00 ) 
     outDmCustomerTabObj.ta_rate = (double)0.00; 
    if ( outDmCustomerTabObj.hra_ind == null ) 
     outDmCustomerTabObj.hra_ind = ""; 
    if ( outDmCustomerTabObj.hra_rate == (double)0.00 ) 
     outDmCustomerTabObj.hra_rate = (double)0.00; 
    if ( outDmCustomerTabObj.staff_wf_ind == null ) 
     outDmCustomerTabObj.staff_wf_ind = ""; 
    if ( outDmCustomerTabObj.staff_wf_rate == (double)0.00 ) 
     outDmCustomerTabObj.staff_wf_rate = (double)0.00; 
    if ( outDmCustomerTabObj.lunch_ind == null ) 
     outDmCustomerTabObj.lunch_ind = ""; 
    if ( outDmCustomerTabObj.lunch_rate == (double)0.00 ) 
     outDmCustomerTabObj.lunch_rate = (double)0.00; 
    if ( outDmCustomerTabObj.jurisdiction == null ) 
     outDmCustomerTabObj.jurisdiction = ""; 
    if ( outDmCustomerTabObj.remark == null ) 
     outDmCustomerTabObj.remark = ""; 
    if ( outDmCustomerTabObj.cacnel_remark == null ) 
     outDmCustomerTabObj.cacnel_remark = ""; 
    if ( outDmCustomerTabObj.service_charge == (double)0.00 ) 
     outDmCustomerTabObj.service_charge = (double)0.00; 
    if ( outDmCustomerTabObj.service_tax == (double)0.00 ) 
     outDmCustomerTabObj.service_tax = (double)0.00; 
    if ( outDmCustomerTabObj.weeken_off_ind == null ) 
     outDmCustomerTabObj.weeken_off_ind = ""; 
    if ( outDmCustomerTabObj.working_days == (int)0 ) 
     outDmCustomerTabObj.working_days = (int)0; 
    if ( outDmCustomerTabObj.manpower_qty == (int)0 ) 
     outDmCustomerTabObj.manpower_qty = (int)0; 
    if ( outDmCustomerTabObj.work_hour_qty == (int)0 ) 
     outDmCustomerTabObj.work_hour_qty = (int)0; 
    if ( outDmCustomerTabObj.ot_hour_qty == (int)0 ) 
     outDmCustomerTabObj.ot_hour_qty = (int)0; 
    if ( outDmCustomerTabObj.labour_licence_ind == null ) 
     outDmCustomerTabObj.labour_licence_ind = ""; 
    if ( outDmCustomerTabObj.labour_licence_num == null ) 
     outDmCustomerTabObj.labour_licence_num = ""; 
    if ( outDmCustomerTabObj.labour_licence_date == null ) 
     outDmCustomerTabObj.labour_licence_date = ""; 
    if ( outDmCustomerTabObj.labour_licence_exp_date == null ) 
     outDmCustomerTabObj.labour_licence_exp_date = ""; 
    if ( outDmCustomerTabObj.rec_status == null ) 
     outDmCustomerTabObj.rec_status = ""; 
    if ( outDmCustomerTabObj.rec_cre_date == null ) 
     outDmCustomerTabObj.rec_cre_date = ""; 
    if ( outDmCustomerTabObj.rec_cre_time == null ) 
     outDmCustomerTabObj.rec_cre_time = ""; 
    if ( outDmCustomerTabObj.rec_upd_date == null ) 
     outDmCustomerTabObj.rec_upd_date = ""; 
    if ( outDmCustomerTabObj.rec_upd_time == null ) 
     outDmCustomerTabObj.rec_upd_time = ""; 
    if ( outDmCustomerTabObj.file_name == null ) 
     outDmCustomerTabObj.file_name = ""; 
    if ( outDmCustomerTabObj.file_cre_date == null ) 
     outDmCustomerTabObj.file_cre_date = ""; 
    if ( outDmCustomerTabObj.file_cre_time == null ) 
     outDmCustomerTabObj.file_cre_time = ""; 
    if ( outDmCustomerTabObj.file_status == null ) 
     outDmCustomerTabObj.file_status = ""; 
  }





  public int insDmCustomerRec
               ( DmCustomerTabObj  inDmCustomerTabObj )
  {
    int lUpdateCount;
    sop("insDmCustomerRec - Started");
    gSSTErrorObj.sourceMethod = "insDmCustomerRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustomerTabObj.expiration_date != null && inDmCustomerTabObj.expiration_date.length() > 0 ) 
            inDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.effective_date != null && inDmCustomerTabObj.effective_date.length() > 0 ) 
            inDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.business_est_date != null && inDmCustomerTabObj.business_est_date.length() > 0 ) 
            inDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.business_est_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.cst_form_date != null && inDmCustomerTabObj.cst_form_date.length() > 0 ) 
            inDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.cst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.lst_form_date != null && inDmCustomerTabObj.lst_form_date.length() > 0 ) 
            inDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.lst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tin_date != null && inDmCustomerTabObj.tin_date.length() > 0 ) 
            inDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tin_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.pan_date != null && inDmCustomerTabObj.pan_date.length() > 0 ) 
            inDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.pan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tan_date != null && inDmCustomerTabObj.tan_date.length() > 0 ) 
            inDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.strn_date != null && inDmCustomerTabObj.strn_date.length() > 0 ) 
            inDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.strn_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_eff_date != null && inDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_eff_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_exp_date != null && inDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_cre_date != null && inDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_sts_date != null && inDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_date != null && inDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_exp_date != null && inDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_cre_date != null && inDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            inDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_upd_date != null && inDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            inDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.file_cre_date != null && inDmCustomerTabObj.file_cre_date.length() > 0 ) 
            inDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_CUSTOMER"+
                        "("+
                                "org_id,"+
                                "customer_id,"+
                                "customer_type,"+
                                "customer_ctg,"+
                                "customer_name,"+
                                "customer_group,"+
                                "referred_by,"+
                                "turn_over,"+
                                "business_area_cd,"+
                                "state_code,"+
                                "region_id,"+
                                "country_code,"+
                                "status,"+
                                "expiration_date,"+
                                "effective_date,"+
                                "business_type,"+
                                "business_est_date,"+
                                "employee_strength,"+
                                "business_currency,"+
                                "address_1,"+
                                "address_2,"+
                                "address_3,"+
                                "cst_form_num,"+
                                "cst_form_date,"+
                                "lst_form_num,"+
                                "lst_form_date,"+
                                "tin_num,"+
                                "tin_date,"+
                                "pan_num,"+
                                "pan_date,"+
                                "tan_num,"+
                                "tan_date,"+
                                "strn_num,"+
                                "strn_date,"+
                                "account_num,"+
                                "bal_close,"+
                                "bal_open,"+
                                "dr_amt,"+
                                "cr_amt,"+
                                "ar_bal,"+
                                "sal_cycle_code,"+
                                "bill_cycle_code,"+
                                "agreement_id,"+
                                "agreement_eff_date,"+
                                "agreement_exp_date,"+
                                "agreement_cre_date,"+
                                "agreement_sts,"+
                                "agreement_sts_date,"+
                                "prev_agreement_id,"+
                                "renew_ind,"+
                                "cycle_id,"+
                                "spl_training_ind,"+
                                "spl_uniform_ind,"+
                                "pay_day,"+
                                "basic,"+
                                "pf_ind,"+
                                "pf_rate,"+
                                "esi_ind,"+
                                "esi_rate,"+
                                "da_ind,"+
                                "da_rate,"+
                                "ta_ind,"+
                                "ta_rate,"+
                                "hra_ind,"+
                                "hra_rate,"+
                                "staff_wf_ind,"+
                                "staff_wf_rate,"+
                                "lunch_ind,"+
                                "lunch_rate,"+
                                "jurisdiction,"+
                                "remark,"+
                                "cacnel_remark,"+
                                "service_charge,"+
                                "service_tax,"+
                                "weeken_off_ind,"+
                                "working_days,"+
                                "manpower_qty,"+
                                "work_hour_qty,"+
                                "ot_hour_qty,"+
                                "labour_licence_ind,"+
                                "labour_licence_num,"+
                                "labour_licence_date,"+
                                "labour_licence_exp_date,"+
                                "rec_status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "file_name,"+
                                "file_cre_date,"+
                                "file_cre_time,"+
                                "file_status"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.customer_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.customer_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.customer_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.customer_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.customer_group+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.referred_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.turn_over+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.business_area_cd+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.state_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.region_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.country_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.expiration_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.effective_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.business_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.business_est_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.employee_strength+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.business_currency+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.address_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.cst_form_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.cst_form_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.lst_form_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.lst_form_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.tin_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.tin_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.pan_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.pan_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.tan_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.tan_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.strn_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.strn_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.account_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.bal_close+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.bal_open+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.dr_amt+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.cr_amt+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.ar_bal+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.sal_cycle_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.bill_cycle_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_eff_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_exp_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.agreement_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.prev_agreement_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.renew_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.cycle_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.spl_training_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.spl_uniform_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.pay_day+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.basic+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.pf_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.pf_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.esi_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.esi_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.da_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.da_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.ta_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.ta_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.hra_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.hra_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.staff_wf_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.staff_wf_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.lunch_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.lunch_rate+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.jurisdiction+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.cacnel_remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.service_charge+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.service_tax+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.weeken_off_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.working_days+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.manpower_qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.work_hour_qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustomerTabObj.ot_hour_qty+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.labour_licence_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.labour_licence_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.labour_licence_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.labour_licence_exp_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.rec_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.file_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustomerTabObj.file_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inDmCustomerTabObj.file_status+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inDmCustomerTabObj.org_id);
        lPreparedStatement.setString(2, inDmCustomerTabObj.customer_id);
        lPreparedStatement.setString(3, inDmCustomerTabObj.customer_type);
        lPreparedStatement.setString(4, inDmCustomerTabObj.customer_ctg);
        lPreparedStatement.setString(5, inDmCustomerTabObj.customer_name);
        lPreparedStatement.setString(6, inDmCustomerTabObj.customer_group);
        lPreparedStatement.setString(7, inDmCustomerTabObj.referred_by);
          lPreparedStatement.setDouble(8, inDmCustomerTabObj.turn_over);
        lPreparedStatement.setString(9, inDmCustomerTabObj.business_area_cd);
        lPreparedStatement.setString(10, inDmCustomerTabObj.state_code);
        lPreparedStatement.setString(11, inDmCustomerTabObj.region_id);
        lPreparedStatement.setString(12, inDmCustomerTabObj.country_code);
        lPreparedStatement.setString(13, inDmCustomerTabObj.status);
        lPreparedStatement.setString(14, inDmCustomerTabObj.expiration_date);
        lPreparedStatement.setString(15, inDmCustomerTabObj.effective_date);
        lPreparedStatement.setString(16, inDmCustomerTabObj.business_type);
        lPreparedStatement.setString(17, inDmCustomerTabObj.business_est_date);
          lPreparedStatement.setInt(18, inDmCustomerTabObj.employee_strength);
        lPreparedStatement.setString(19, inDmCustomerTabObj.business_currency);
        lPreparedStatement.setString(20, inDmCustomerTabObj.address_1);
        lPreparedStatement.setString(21, inDmCustomerTabObj.address_2);
        lPreparedStatement.setString(22, inDmCustomerTabObj.address_3);
        lPreparedStatement.setString(23, inDmCustomerTabObj.cst_form_num);
        lPreparedStatement.setString(24, inDmCustomerTabObj.cst_form_date);
        lPreparedStatement.setString(25, inDmCustomerTabObj.lst_form_num);
        lPreparedStatement.setString(26, inDmCustomerTabObj.lst_form_date);
        lPreparedStatement.setString(27, inDmCustomerTabObj.tin_num);
        lPreparedStatement.setString(28, inDmCustomerTabObj.tin_date);
        lPreparedStatement.setString(29, inDmCustomerTabObj.pan_num);
        lPreparedStatement.setString(30, inDmCustomerTabObj.pan_date);
        lPreparedStatement.setString(31, inDmCustomerTabObj.tan_num);
        lPreparedStatement.setString(32, inDmCustomerTabObj.tan_date);
        lPreparedStatement.setString(33, inDmCustomerTabObj.strn_num);
        lPreparedStatement.setString(34, inDmCustomerTabObj.strn_date);
        lPreparedStatement.setString(35, inDmCustomerTabObj.account_num);
          lPreparedStatement.setDouble(36, inDmCustomerTabObj.bal_close);
          lPreparedStatement.setDouble(37, inDmCustomerTabObj.bal_open);
          lPreparedStatement.setDouble(38, inDmCustomerTabObj.dr_amt);
          lPreparedStatement.setDouble(39, inDmCustomerTabObj.cr_amt);
          lPreparedStatement.setDouble(40, inDmCustomerTabObj.ar_bal);
        lPreparedStatement.setString(41, inDmCustomerTabObj.sal_cycle_code);
        lPreparedStatement.setString(42, inDmCustomerTabObj.bill_cycle_code);
        lPreparedStatement.setString(43, inDmCustomerTabObj.agreement_id);
        lPreparedStatement.setString(44, inDmCustomerTabObj.agreement_eff_date);
        lPreparedStatement.setString(45, inDmCustomerTabObj.agreement_exp_date);
        lPreparedStatement.setString(46, inDmCustomerTabObj.agreement_cre_date);
        lPreparedStatement.setString(47, inDmCustomerTabObj.agreement_sts);
        lPreparedStatement.setString(48, inDmCustomerTabObj.agreement_sts_date);
        lPreparedStatement.setString(49, inDmCustomerTabObj.prev_agreement_id);
        lPreparedStatement.setString(50, inDmCustomerTabObj.renew_ind);
        lPreparedStatement.setString(51, inDmCustomerTabObj.cycle_id);
        lPreparedStatement.setString(52, inDmCustomerTabObj.spl_training_ind);
        lPreparedStatement.setString(53, inDmCustomerTabObj.spl_uniform_ind);
          lPreparedStatement.setByte(54, inDmCustomerTabObj.pay_day);
          lPreparedStatement.setDouble(55, inDmCustomerTabObj.basic);
        lPreparedStatement.setString(56, inDmCustomerTabObj.pf_ind);
          lPreparedStatement.setDouble(57, inDmCustomerTabObj.pf_rate);
        lPreparedStatement.setString(58, inDmCustomerTabObj.esi_ind);
          lPreparedStatement.setDouble(59, inDmCustomerTabObj.esi_rate);
        lPreparedStatement.setString(60, inDmCustomerTabObj.da_ind);
          lPreparedStatement.setDouble(61, inDmCustomerTabObj.da_rate);
        lPreparedStatement.setString(62, inDmCustomerTabObj.ta_ind);
          lPreparedStatement.setDouble(63, inDmCustomerTabObj.ta_rate);
        lPreparedStatement.setString(64, inDmCustomerTabObj.hra_ind);
          lPreparedStatement.setDouble(65, inDmCustomerTabObj.hra_rate);
        lPreparedStatement.setString(66, inDmCustomerTabObj.staff_wf_ind);
          lPreparedStatement.setDouble(67, inDmCustomerTabObj.staff_wf_rate);
        lPreparedStatement.setString(68, inDmCustomerTabObj.lunch_ind);
          lPreparedStatement.setDouble(69, inDmCustomerTabObj.lunch_rate);
        lPreparedStatement.setString(70, inDmCustomerTabObj.jurisdiction);
        lPreparedStatement.setString(71, inDmCustomerTabObj.remark);
        lPreparedStatement.setString(72, inDmCustomerTabObj.cacnel_remark);
          lPreparedStatement.setDouble(73, inDmCustomerTabObj.service_charge);
          lPreparedStatement.setDouble(74, inDmCustomerTabObj.service_tax);
        lPreparedStatement.setString(75, inDmCustomerTabObj.weeken_off_ind);
          lPreparedStatement.setInt(76, inDmCustomerTabObj.working_days);
          lPreparedStatement.setInt(77, inDmCustomerTabObj.manpower_qty);
          lPreparedStatement.setInt(78, inDmCustomerTabObj.work_hour_qty);
          lPreparedStatement.setInt(79, inDmCustomerTabObj.ot_hour_qty);
        lPreparedStatement.setString(80, inDmCustomerTabObj.labour_licence_ind);
        lPreparedStatement.setString(81, inDmCustomerTabObj.labour_licence_num);
        lPreparedStatement.setString(82, inDmCustomerTabObj.labour_licence_date);
        lPreparedStatement.setString(83, inDmCustomerTabObj.labour_licence_exp_date);
        lPreparedStatement.setString(84, inDmCustomerTabObj.rec_status);
        lPreparedStatement.setString(85, inDmCustomerTabObj.rec_cre_date);
        lPreparedStatement.setString(86, inDmCustomerTabObj.rec_cre_time);
        lPreparedStatement.setString(87, inDmCustomerTabObj.rec_upd_date);
        lPreparedStatement.setString(88, inDmCustomerTabObj.rec_upd_time);
        lPreparedStatement.setString(89, inDmCustomerTabObj.file_name);
        lPreparedStatement.setString(90, inDmCustomerTabObj.file_cre_date);
        lPreparedStatement.setString(91, inDmCustomerTabObj.file_cre_time);
        lPreparedStatement.setString(92, inDmCustomerTabObj.file_status);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insDmCustomerArr
               ( ArrayList  inDmCustomerTabObjArr 
               , String  inRowidFlag )
  {
    DmCustomerTabObj  lDmCustomerTabObj = new DmCustomerTabObj();
    int lUpdateCount;
    sop("insDmCustomerArr - Started");
    gSSTErrorObj.sourceMethod = "insDmCustomerArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inDmCustomerTabObjArr.size(); lNumRec++ )
      {
        lDmCustomerTabObj = (DmCustomerTabObj)inDmCustomerTabObjArr.get(lNumRec);

          if ( lDmCustomerTabObj.expiration_date != null && lDmCustomerTabObj.expiration_date.length() > 0 ) 
            lDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.expiration_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.effective_date != null && lDmCustomerTabObj.effective_date.length() > 0 ) 
            lDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.effective_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.business_est_date != null && lDmCustomerTabObj.business_est_date.length() > 0 ) 
            lDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.business_est_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.cst_form_date != null && lDmCustomerTabObj.cst_form_date.length() > 0 ) 
            lDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.cst_form_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.lst_form_date != null && lDmCustomerTabObj.lst_form_date.length() > 0 ) 
            lDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.lst_form_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.tin_date != null && lDmCustomerTabObj.tin_date.length() > 0 ) 
            lDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.tin_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.pan_date != null && lDmCustomerTabObj.pan_date.length() > 0 ) 
            lDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.pan_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.tan_date != null && lDmCustomerTabObj.tan_date.length() > 0 ) 
            lDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.tan_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.strn_date != null && lDmCustomerTabObj.strn_date.length() > 0 ) 
            lDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.strn_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.agreement_eff_date != null && lDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.agreement_eff_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.agreement_exp_date != null && lDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.agreement_exp_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.agreement_cre_date != null && lDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.agreement_cre_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.agreement_sts_date != null && lDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.labour_licence_date != null && lDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.labour_licence_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.labour_licence_exp_date != null && lDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            lDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.labour_licence_exp_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.rec_cre_date != null && lDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            lDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.rec_upd_date != null && lDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            lDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( lDmCustomerTabObj.file_cre_date != null && lDmCustomerTabObj.file_cre_date.length() > 0 ) 
            lDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustomerTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_CUSTOMER"+
                        "("+
                        "org_id,"+
                        "customer_id,"+
                        "customer_type,"+
                        "customer_ctg,"+
                        "customer_name,"+
                        "customer_group,"+
                        "referred_by,"+
                        "turn_over,"+
                        "business_area_cd,"+
                        "state_code,"+
                        "region_id,"+
                        "country_code,"+
                        "status,"+
                        "expiration_date,"+
                        "effective_date,"+
                        "business_type,"+
                        "business_est_date,"+
                        "employee_strength,"+
                        "business_currency,"+
                        "address_1,"+
                        "address_2,"+
                        "address_3,"+
                        "cst_form_num,"+
                        "cst_form_date,"+
                        "lst_form_num,"+
                        "lst_form_date,"+
                        "tin_num,"+
                        "tin_date,"+
                        "pan_num,"+
                        "pan_date,"+
                        "tan_num,"+
                        "tan_date,"+
                        "strn_num,"+
                        "strn_date,"+
                        "account_num,"+
                        "bal_close,"+
                        "bal_open,"+
                        "dr_amt,"+
                        "cr_amt,"+
                        "ar_bal,"+
                        "sal_cycle_code,"+
                        "bill_cycle_code,"+
                        "agreement_id,"+
                        "agreement_eff_date,"+
                        "agreement_exp_date,"+
                        "agreement_cre_date,"+
                        "agreement_sts,"+
                        "agreement_sts_date,"+
                        "prev_agreement_id,"+
                        "renew_ind,"+
                        "cycle_id,"+
                        "spl_training_ind,"+
                        "spl_uniform_ind,"+
                        "pay_day,"+
                        "basic,"+
                        "pf_ind,"+
                        "pf_rate,"+
                        "esi_ind,"+
                        "esi_rate,"+
                        "da_ind,"+
                        "da_rate,"+
                        "ta_ind,"+
                        "ta_rate,"+
                        "hra_ind,"+
                        "hra_rate,"+
                        "staff_wf_ind,"+
                        "staff_wf_rate,"+
                        "lunch_ind,"+
                        "lunch_rate,"+
                        "jurisdiction,"+
                        "remark,"+
                        "cacnel_remark,"+
                        "service_charge,"+
                        "service_tax,"+
                        "weeken_off_ind,"+
                        "working_days,"+
                        "manpower_qty,"+
                        "work_hour_qty,"+
                        "ot_hour_qty,"+
                        "labour_licence_ind,"+
                        "labour_licence_num,"+
                        "labour_licence_date,"+
                        "labour_licence_exp_date,"+
                        "rec_status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "file_name,"+
                        "file_cre_date,"+
                        "file_cre_time,"+
                        "file_status"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.customer_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.customer_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.customer_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.customer_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.customer_group+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.referred_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.turn_over+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.business_area_cd+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.state_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.region_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.country_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.expiration_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.effective_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.business_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.business_est_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.employee_strength+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.business_currency+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.address_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.cst_form_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.cst_form_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.lst_form_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.lst_form_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.tin_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.tin_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.pan_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.pan_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.tan_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.tan_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.strn_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.strn_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.account_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.bal_close+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.bal_open+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.dr_amt+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.cr_amt+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.ar_bal+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.sal_cycle_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.bill_cycle_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_eff_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_exp_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.agreement_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.prev_agreement_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.renew_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.cycle_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.spl_training_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.spl_uniform_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.pay_day+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.basic+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.pf_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.pf_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.esi_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.esi_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.da_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.da_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.ta_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.ta_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.hra_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.hra_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.staff_wf_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.staff_wf_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.lunch_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.lunch_rate+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.jurisdiction+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.cacnel_remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.service_charge+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.service_tax+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.weeken_off_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.working_days+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.manpower_qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.work_hour_qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustomerTabObj.ot_hour_qty+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.labour_licence_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.labour_licence_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.labour_licence_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.labour_licence_exp_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.rec_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.file_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustomerTabObj.file_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lDmCustomerTabObj.file_status+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lDmCustomerTabObj.org_id);
            lPreparedStatement.setString(2, lDmCustomerTabObj.customer_id);
            lPreparedStatement.setString(3, lDmCustomerTabObj.customer_type);
            lPreparedStatement.setString(4, lDmCustomerTabObj.customer_ctg);
            lPreparedStatement.setString(5, lDmCustomerTabObj.customer_name);
            lPreparedStatement.setString(6, lDmCustomerTabObj.customer_group);
            lPreparedStatement.setString(7, lDmCustomerTabObj.referred_by);
              lPreparedStatement.setDouble(8, lDmCustomerTabObj.turn_over);
            lPreparedStatement.setString(9, lDmCustomerTabObj.business_area_cd);
            lPreparedStatement.setString(10, lDmCustomerTabObj.state_code);
            lPreparedStatement.setString(11, lDmCustomerTabObj.region_id);
            lPreparedStatement.setString(12, lDmCustomerTabObj.country_code);
            lPreparedStatement.setString(13, lDmCustomerTabObj.status);
            lPreparedStatement.setString(14, lDmCustomerTabObj.expiration_date);
            lPreparedStatement.setString(15, lDmCustomerTabObj.effective_date);
            lPreparedStatement.setString(16, lDmCustomerTabObj.business_type);
            lPreparedStatement.setString(17, lDmCustomerTabObj.business_est_date);
              lPreparedStatement.setInt(18, lDmCustomerTabObj.employee_strength);
            lPreparedStatement.setString(19, lDmCustomerTabObj.business_currency);
            lPreparedStatement.setString(20, lDmCustomerTabObj.address_1);
            lPreparedStatement.setString(21, lDmCustomerTabObj.address_2);
            lPreparedStatement.setString(22, lDmCustomerTabObj.address_3);
            lPreparedStatement.setString(23, lDmCustomerTabObj.cst_form_num);
            lPreparedStatement.setString(24, lDmCustomerTabObj.cst_form_date);
            lPreparedStatement.setString(25, lDmCustomerTabObj.lst_form_num);
            lPreparedStatement.setString(26, lDmCustomerTabObj.lst_form_date);
            lPreparedStatement.setString(27, lDmCustomerTabObj.tin_num);
            lPreparedStatement.setString(28, lDmCustomerTabObj.tin_date);
            lPreparedStatement.setString(29, lDmCustomerTabObj.pan_num);
            lPreparedStatement.setString(30, lDmCustomerTabObj.pan_date);
            lPreparedStatement.setString(31, lDmCustomerTabObj.tan_num);
            lPreparedStatement.setString(32, lDmCustomerTabObj.tan_date);
            lPreparedStatement.setString(33, lDmCustomerTabObj.strn_num);
            lPreparedStatement.setString(34, lDmCustomerTabObj.strn_date);
            lPreparedStatement.setString(35, lDmCustomerTabObj.account_num);
              lPreparedStatement.setDouble(36, lDmCustomerTabObj.bal_close);
              lPreparedStatement.setDouble(37, lDmCustomerTabObj.bal_open);
              lPreparedStatement.setDouble(38, lDmCustomerTabObj.dr_amt);
              lPreparedStatement.setDouble(39, lDmCustomerTabObj.cr_amt);
              lPreparedStatement.setDouble(40, lDmCustomerTabObj.ar_bal);
            lPreparedStatement.setString(41, lDmCustomerTabObj.sal_cycle_code);
            lPreparedStatement.setString(42, lDmCustomerTabObj.bill_cycle_code);
            lPreparedStatement.setString(43, lDmCustomerTabObj.agreement_id);
            lPreparedStatement.setString(44, lDmCustomerTabObj.agreement_eff_date);
            lPreparedStatement.setString(45, lDmCustomerTabObj.agreement_exp_date);
            lPreparedStatement.setString(46, lDmCustomerTabObj.agreement_cre_date);
            lPreparedStatement.setString(47, lDmCustomerTabObj.agreement_sts);
            lPreparedStatement.setString(48, lDmCustomerTabObj.agreement_sts_date);
            lPreparedStatement.setString(49, lDmCustomerTabObj.prev_agreement_id);
            lPreparedStatement.setString(50, lDmCustomerTabObj.renew_ind);
            lPreparedStatement.setString(51, lDmCustomerTabObj.cycle_id);
            lPreparedStatement.setString(52, lDmCustomerTabObj.spl_training_ind);
            lPreparedStatement.setString(53, lDmCustomerTabObj.spl_uniform_ind);
              lPreparedStatement.setByte(54, lDmCustomerTabObj.pay_day);
              lPreparedStatement.setDouble(55, lDmCustomerTabObj.basic);
            lPreparedStatement.setString(56, lDmCustomerTabObj.pf_ind);
              lPreparedStatement.setDouble(57, lDmCustomerTabObj.pf_rate);
            lPreparedStatement.setString(58, lDmCustomerTabObj.esi_ind);
              lPreparedStatement.setDouble(59, lDmCustomerTabObj.esi_rate);
            lPreparedStatement.setString(60, lDmCustomerTabObj.da_ind);
              lPreparedStatement.setDouble(61, lDmCustomerTabObj.da_rate);
            lPreparedStatement.setString(62, lDmCustomerTabObj.ta_ind);
              lPreparedStatement.setDouble(63, lDmCustomerTabObj.ta_rate);
            lPreparedStatement.setString(64, lDmCustomerTabObj.hra_ind);
              lPreparedStatement.setDouble(65, lDmCustomerTabObj.hra_rate);
            lPreparedStatement.setString(66, lDmCustomerTabObj.staff_wf_ind);
              lPreparedStatement.setDouble(67, lDmCustomerTabObj.staff_wf_rate);
            lPreparedStatement.setString(68, lDmCustomerTabObj.lunch_ind);
              lPreparedStatement.setDouble(69, lDmCustomerTabObj.lunch_rate);
            lPreparedStatement.setString(70, lDmCustomerTabObj.jurisdiction);
            lPreparedStatement.setString(71, lDmCustomerTabObj.remark);
            lPreparedStatement.setString(72, lDmCustomerTabObj.cacnel_remark);
              lPreparedStatement.setDouble(73, lDmCustomerTabObj.service_charge);
              lPreparedStatement.setDouble(74, lDmCustomerTabObj.service_tax);
            lPreparedStatement.setString(75, lDmCustomerTabObj.weeken_off_ind);
              lPreparedStatement.setInt(76, lDmCustomerTabObj.working_days);
              lPreparedStatement.setInt(77, lDmCustomerTabObj.manpower_qty);
              lPreparedStatement.setInt(78, lDmCustomerTabObj.work_hour_qty);
              lPreparedStatement.setInt(79, lDmCustomerTabObj.ot_hour_qty);
            lPreparedStatement.setString(80, lDmCustomerTabObj.labour_licence_ind);
            lPreparedStatement.setString(81, lDmCustomerTabObj.labour_licence_num);
            lPreparedStatement.setString(82, lDmCustomerTabObj.labour_licence_date);
            lPreparedStatement.setString(83, lDmCustomerTabObj.labour_licence_exp_date);
            lPreparedStatement.setString(84, lDmCustomerTabObj.rec_status);
            lPreparedStatement.setString(85, lDmCustomerTabObj.rec_cre_date);
            lPreparedStatement.setString(86, lDmCustomerTabObj.rec_cre_time);
            lPreparedStatement.setString(87, lDmCustomerTabObj.rec_upd_date);
            lPreparedStatement.setString(88, lDmCustomerTabObj.rec_upd_time);
            lPreparedStatement.setString(89, lDmCustomerTabObj.file_name);
            lPreparedStatement.setString(90, lDmCustomerTabObj.file_cre_date);
            lPreparedStatement.setString(91, lDmCustomerTabObj.file_cre_time);
            lPreparedStatement.setString(92, lDmCustomerTabObj.file_status);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popDmCustomerReq2Obj
               ( HttpServletRequest inRequest
               , DmCustomerTabObj  outDmCustomerTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outDmCustomerTabObj.tab_rowid = lTabRowidValue;

    outDmCustomerTabObj.org_id = inRequest.getParameter("org_id");
    outDmCustomerTabObj.customer_id = inRequest.getParameter("customer_id");
    outDmCustomerTabObj.customer_type = inRequest.getParameter("customer_type");
    outDmCustomerTabObj.customer_ctg = inRequest.getParameter("customer_ctg");
    outDmCustomerTabObj.customer_name = inRequest.getParameter("customer_name");
    outDmCustomerTabObj.customer_group = inRequest.getParameter("customer_group");
    outDmCustomerTabObj.referred_by = inRequest.getParameter("referred_by");
    if ( inRequest.getParameter("turn_over") == null )
      outDmCustomerTabObj.turn_over = 0;
    else
    if ( inRequest.getParameter("turn_over").trim().length() == 0 )
      outDmCustomerTabObj.turn_over = 0;
    else
      outDmCustomerTabObj.turn_over = Double.parseDouble( inRequest.getParameter("turn_over"));
    outDmCustomerTabObj.business_area_cd = inRequest.getParameter("business_area_cd");
    outDmCustomerTabObj.state_code = inRequest.getParameter("state_code");
    outDmCustomerTabObj.region_id = inRequest.getParameter("region_id");
    outDmCustomerTabObj.country_code = inRequest.getParameter("country_code");
    outDmCustomerTabObj.status = inRequest.getParameter("status");
    outDmCustomerTabObj.expiration_date = inRequest.getParameter("expiration_date");
    outDmCustomerTabObj.effective_date = inRequest.getParameter("effective_date");
    outDmCustomerTabObj.business_type = inRequest.getParameter("business_type");
    outDmCustomerTabObj.business_est_date = inRequest.getParameter("business_est_date");
    if ( inRequest.getParameter("employee_strength") == null )
      outDmCustomerTabObj.employee_strength = 0;
    else
    if ( inRequest.getParameter("employee_strength").trim().length() == 0 )
      outDmCustomerTabObj.employee_strength = 0;
    else
      outDmCustomerTabObj.employee_strength = Integer.parseInt( inRequest.getParameter("employee_strength"));
    outDmCustomerTabObj.business_currency = inRequest.getParameter("business_currency");
    outDmCustomerTabObj.address_1 = inRequest.getParameter("address_1");
    outDmCustomerTabObj.address_2 = inRequest.getParameter("address_2");
    outDmCustomerTabObj.address_3 = inRequest.getParameter("address_3");
    outDmCustomerTabObj.cst_form_num = inRequest.getParameter("cst_form_num");
    outDmCustomerTabObj.cst_form_date = inRequest.getParameter("cst_form_date");
    outDmCustomerTabObj.lst_form_num = inRequest.getParameter("lst_form_num");
    outDmCustomerTabObj.lst_form_date = inRequest.getParameter("lst_form_date");
    outDmCustomerTabObj.tin_num = inRequest.getParameter("tin_num");
    outDmCustomerTabObj.tin_date = inRequest.getParameter("tin_date");
    outDmCustomerTabObj.pan_num = inRequest.getParameter("pan_num");
    outDmCustomerTabObj.pan_date = inRequest.getParameter("pan_date");
    outDmCustomerTabObj.tan_num = inRequest.getParameter("tan_num");
    outDmCustomerTabObj.tan_date = inRequest.getParameter("tan_date");
    outDmCustomerTabObj.strn_num = inRequest.getParameter("strn_num");
    outDmCustomerTabObj.strn_date = inRequest.getParameter("strn_date");
    outDmCustomerTabObj.account_num = inRequest.getParameter("account_num");
    if ( inRequest.getParameter("bal_close") == null )
      outDmCustomerTabObj.bal_close = 0;
    else
    if ( inRequest.getParameter("bal_close").trim().length() == 0 )
      outDmCustomerTabObj.bal_close = 0;
    else
      outDmCustomerTabObj.bal_close = Double.parseDouble( inRequest.getParameter("bal_close"));
    if ( inRequest.getParameter("bal_open") == null )
      outDmCustomerTabObj.bal_open = 0;
    else
    if ( inRequest.getParameter("bal_open").trim().length() == 0 )
      outDmCustomerTabObj.bal_open = 0;
    else
      outDmCustomerTabObj.bal_open = Double.parseDouble( inRequest.getParameter("bal_open"));
    if ( inRequest.getParameter("dr_amt") == null )
      outDmCustomerTabObj.dr_amt = 0;
    else
    if ( inRequest.getParameter("dr_amt").trim().length() == 0 )
      outDmCustomerTabObj.dr_amt = 0;
    else
      outDmCustomerTabObj.dr_amt = Double.parseDouble( inRequest.getParameter("dr_amt"));
    if ( inRequest.getParameter("cr_amt") == null )
      outDmCustomerTabObj.cr_amt = 0;
    else
    if ( inRequest.getParameter("cr_amt").trim().length() == 0 )
      outDmCustomerTabObj.cr_amt = 0;
    else
      outDmCustomerTabObj.cr_amt = Double.parseDouble( inRequest.getParameter("cr_amt"));
    if ( inRequest.getParameter("ar_bal") == null )
      outDmCustomerTabObj.ar_bal = 0;
    else
    if ( inRequest.getParameter("ar_bal").trim().length() == 0 )
      outDmCustomerTabObj.ar_bal = 0;
    else
      outDmCustomerTabObj.ar_bal = Double.parseDouble( inRequest.getParameter("ar_bal"));
    outDmCustomerTabObj.sal_cycle_code = inRequest.getParameter("sal_cycle_code");
    outDmCustomerTabObj.bill_cycle_code = inRequest.getParameter("bill_cycle_code");
    outDmCustomerTabObj.agreement_id = inRequest.getParameter("agreement_id");
    outDmCustomerTabObj.agreement_eff_date = inRequest.getParameter("agreement_eff_date");
    outDmCustomerTabObj.agreement_exp_date = inRequest.getParameter("agreement_exp_date");
    outDmCustomerTabObj.agreement_cre_date = inRequest.getParameter("agreement_cre_date");
    outDmCustomerTabObj.agreement_sts = inRequest.getParameter("agreement_sts");
    outDmCustomerTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date");
    outDmCustomerTabObj.prev_agreement_id = inRequest.getParameter("prev_agreement_id");
    outDmCustomerTabObj.renew_ind = inRequest.getParameter("renew_ind");
    outDmCustomerTabObj.cycle_id = inRequest.getParameter("cycle_id");
    outDmCustomerTabObj.spl_training_ind = inRequest.getParameter("spl_training_ind");
    outDmCustomerTabObj.spl_uniform_ind = inRequest.getParameter("spl_uniform_ind");
    if ( inRequest.getParameter("pay_day") == null )
      outDmCustomerTabObj.pay_day = 0;
    else
    if ( inRequest.getParameter("pay_day").trim().length() == 0 )
      outDmCustomerTabObj.pay_day = 0;
    else
      outDmCustomerTabObj.pay_day = Byte.parseByte( inRequest.getParameter("pay_day"));
    if ( inRequest.getParameter("basic") == null )
      outDmCustomerTabObj.basic = 0;
    else
    if ( inRequest.getParameter("basic").trim().length() == 0 )
      outDmCustomerTabObj.basic = 0;
    else
      outDmCustomerTabObj.basic = Double.parseDouble( inRequest.getParameter("basic"));
    outDmCustomerTabObj.pf_ind = inRequest.getParameter("pf_ind");
    if ( inRequest.getParameter("pf_rate") == null )
      outDmCustomerTabObj.pf_rate = 0;
    else
    if ( inRequest.getParameter("pf_rate").trim().length() == 0 )
      outDmCustomerTabObj.pf_rate = 0;
    else
      outDmCustomerTabObj.pf_rate = Double.parseDouble( inRequest.getParameter("pf_rate"));
    outDmCustomerTabObj.esi_ind = inRequest.getParameter("esi_ind");
    if ( inRequest.getParameter("esi_rate") == null )
      outDmCustomerTabObj.esi_rate = 0;
    else
    if ( inRequest.getParameter("esi_rate").trim().length() == 0 )
      outDmCustomerTabObj.esi_rate = 0;
    else
      outDmCustomerTabObj.esi_rate = Double.parseDouble( inRequest.getParameter("esi_rate"));
    outDmCustomerTabObj.da_ind = inRequest.getParameter("da_ind");
    if ( inRequest.getParameter("da_rate") == null )
      outDmCustomerTabObj.da_rate = 0;
    else
    if ( inRequest.getParameter("da_rate").trim().length() == 0 )
      outDmCustomerTabObj.da_rate = 0;
    else
      outDmCustomerTabObj.da_rate = Double.parseDouble( inRequest.getParameter("da_rate"));
    outDmCustomerTabObj.ta_ind = inRequest.getParameter("ta_ind");
    if ( inRequest.getParameter("ta_rate") == null )
      outDmCustomerTabObj.ta_rate = 0;
    else
    if ( inRequest.getParameter("ta_rate").trim().length() == 0 )
      outDmCustomerTabObj.ta_rate = 0;
    else
      outDmCustomerTabObj.ta_rate = Double.parseDouble( inRequest.getParameter("ta_rate"));
    outDmCustomerTabObj.hra_ind = inRequest.getParameter("hra_ind");
    if ( inRequest.getParameter("hra_rate") == null )
      outDmCustomerTabObj.hra_rate = 0;
    else
    if ( inRequest.getParameter("hra_rate").trim().length() == 0 )
      outDmCustomerTabObj.hra_rate = 0;
    else
      outDmCustomerTabObj.hra_rate = Double.parseDouble( inRequest.getParameter("hra_rate"));
    outDmCustomerTabObj.staff_wf_ind = inRequest.getParameter("staff_wf_ind");
    if ( inRequest.getParameter("staff_wf_rate") == null )
      outDmCustomerTabObj.staff_wf_rate = 0;
    else
    if ( inRequest.getParameter("staff_wf_rate").trim().length() == 0 )
      outDmCustomerTabObj.staff_wf_rate = 0;
    else
      outDmCustomerTabObj.staff_wf_rate = Double.parseDouble( inRequest.getParameter("staff_wf_rate"));
    outDmCustomerTabObj.lunch_ind = inRequest.getParameter("lunch_ind");
    if ( inRequest.getParameter("lunch_rate") == null )
      outDmCustomerTabObj.lunch_rate = 0;
    else
    if ( inRequest.getParameter("lunch_rate").trim().length() == 0 )
      outDmCustomerTabObj.lunch_rate = 0;
    else
      outDmCustomerTabObj.lunch_rate = Double.parseDouble( inRequest.getParameter("lunch_rate"));
    outDmCustomerTabObj.jurisdiction = inRequest.getParameter("jurisdiction");
    outDmCustomerTabObj.remark = inRequest.getParameter("remark");
    outDmCustomerTabObj.cacnel_remark = inRequest.getParameter("cacnel_remark");
    if ( inRequest.getParameter("service_charge") == null )
      outDmCustomerTabObj.service_charge = 0;
    else
    if ( inRequest.getParameter("service_charge").trim().length() == 0 )
      outDmCustomerTabObj.service_charge = 0;
    else
      outDmCustomerTabObj.service_charge = Double.parseDouble( inRequest.getParameter("service_charge"));
    if ( inRequest.getParameter("service_tax") == null )
      outDmCustomerTabObj.service_tax = 0;
    else
    if ( inRequest.getParameter("service_tax").trim().length() == 0 )
      outDmCustomerTabObj.service_tax = 0;
    else
      outDmCustomerTabObj.service_tax = Double.parseDouble( inRequest.getParameter("service_tax"));
    outDmCustomerTabObj.weeken_off_ind = inRequest.getParameter("weeken_off_ind");
    if ( inRequest.getParameter("working_days") == null )
      outDmCustomerTabObj.working_days = 0;
    else
    if ( inRequest.getParameter("working_days").trim().length() == 0 )
      outDmCustomerTabObj.working_days = 0;
    else
      outDmCustomerTabObj.working_days = Integer.parseInt( inRequest.getParameter("working_days"));
    if ( inRequest.getParameter("manpower_qty") == null )
      outDmCustomerTabObj.manpower_qty = 0;
    else
    if ( inRequest.getParameter("manpower_qty").trim().length() == 0 )
      outDmCustomerTabObj.manpower_qty = 0;
    else
      outDmCustomerTabObj.manpower_qty = Integer.parseInt( inRequest.getParameter("manpower_qty"));
    if ( inRequest.getParameter("work_hour_qty") == null )
      outDmCustomerTabObj.work_hour_qty = 0;
    else
    if ( inRequest.getParameter("work_hour_qty").trim().length() == 0 )
      outDmCustomerTabObj.work_hour_qty = 0;
    else
      outDmCustomerTabObj.work_hour_qty = Integer.parseInt( inRequest.getParameter("work_hour_qty"));
    if ( inRequest.getParameter("ot_hour_qty") == null )
      outDmCustomerTabObj.ot_hour_qty = 0;
    else
    if ( inRequest.getParameter("ot_hour_qty").trim().length() == 0 )
      outDmCustomerTabObj.ot_hour_qty = 0;
    else
      outDmCustomerTabObj.ot_hour_qty = Integer.parseInt( inRequest.getParameter("ot_hour_qty"));
    outDmCustomerTabObj.labour_licence_ind = inRequest.getParameter("labour_licence_ind");
    outDmCustomerTabObj.labour_licence_num = inRequest.getParameter("labour_licence_num");
    outDmCustomerTabObj.labour_licence_date = inRequest.getParameter("labour_licence_date");
    outDmCustomerTabObj.labour_licence_exp_date = inRequest.getParameter("labour_licence_exp_date");
    outDmCustomerTabObj.rec_status = inRequest.getParameter("rec_status");
    outDmCustomerTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outDmCustomerTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outDmCustomerTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outDmCustomerTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outDmCustomerTabObj.file_name = inRequest.getParameter("file_name");
    outDmCustomerTabObj.file_cre_date = inRequest.getParameter("file_cre_date");
    outDmCustomerTabObj.file_cre_time = inRequest.getParameter("file_cre_time");
    outDmCustomerTabObj.file_status = inRequest.getParameter("file_status");
    return lReturnValue;
  }


  public int popDmCustomerReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmCustomerTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmCustomerTabObj lDmCustomerTabObj= new DmCustomerTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmCustomerTabObj.tab_rowid = lTabRowidValue;

      lDmCustomerTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lDmCustomerTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
      lDmCustomerTabObj.customer_type = inRequest.getParameter("customer_type_r"+lNumRec);
      lDmCustomerTabObj.customer_ctg = inRequest.getParameter("customer_ctg_r"+lNumRec);
      lDmCustomerTabObj.customer_name = inRequest.getParameter("customer_name_r"+lNumRec);
      lDmCustomerTabObj.customer_group = inRequest.getParameter("customer_group_r"+lNumRec);
      lDmCustomerTabObj.referred_by = inRequest.getParameter("referred_by_r"+lNumRec);
      if ( inRequest.getParameter("turn_over_r"+lNumRec) == null )
        lDmCustomerTabObj.turn_over = 0;
      else
      if ( inRequest.getParameter("turn_over_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.turn_over = 0;
      else
        lDmCustomerTabObj.turn_over = Double.parseDouble( inRequest.getParameter("turn_over_r"+lNumRec));
      lDmCustomerTabObj.business_area_cd = inRequest.getParameter("business_area_cd_r"+lNumRec);
      lDmCustomerTabObj.state_code = inRequest.getParameter("state_code_r"+lNumRec);
      lDmCustomerTabObj.region_id = inRequest.getParameter("region_id_r"+lNumRec);
      lDmCustomerTabObj.country_code = inRequest.getParameter("country_code_r"+lNumRec);
      lDmCustomerTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lDmCustomerTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
      lDmCustomerTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
      lDmCustomerTabObj.business_type = inRequest.getParameter("business_type_r"+lNumRec);
      lDmCustomerTabObj.business_est_date = inRequest.getParameter("business_est_date_r"+lNumRec);
      if ( inRequest.getParameter("employee_strength_r"+lNumRec) == null )
        lDmCustomerTabObj.employee_strength = 0;
      else
      if ( inRequest.getParameter("employee_strength_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.employee_strength = 0;
      else
        lDmCustomerTabObj.employee_strength = Integer.parseInt( inRequest.getParameter("employee_strength_r"+lNumRec));
      lDmCustomerTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
      lDmCustomerTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
      lDmCustomerTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
      lDmCustomerTabObj.address_3 = inRequest.getParameter("address_3_r"+lNumRec);
      lDmCustomerTabObj.cst_form_num = inRequest.getParameter("cst_form_num_r"+lNumRec);
      lDmCustomerTabObj.cst_form_date = inRequest.getParameter("cst_form_date_r"+lNumRec);
      lDmCustomerTabObj.lst_form_num = inRequest.getParameter("lst_form_num_r"+lNumRec);
      lDmCustomerTabObj.lst_form_date = inRequest.getParameter("lst_form_date_r"+lNumRec);
      lDmCustomerTabObj.tin_num = inRequest.getParameter("tin_num_r"+lNumRec);
      lDmCustomerTabObj.tin_date = inRequest.getParameter("tin_date_r"+lNumRec);
      lDmCustomerTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
      lDmCustomerTabObj.pan_date = inRequest.getParameter("pan_date_r"+lNumRec);
      lDmCustomerTabObj.tan_num = inRequest.getParameter("tan_num_r"+lNumRec);
      lDmCustomerTabObj.tan_date = inRequest.getParameter("tan_date_r"+lNumRec);
      lDmCustomerTabObj.strn_num = inRequest.getParameter("strn_num_r"+lNumRec);
      lDmCustomerTabObj.strn_date = inRequest.getParameter("strn_date_r"+lNumRec);
      lDmCustomerTabObj.account_num = inRequest.getParameter("account_num_r"+lNumRec);
      if ( inRequest.getParameter("bal_close_r"+lNumRec) == null )
        lDmCustomerTabObj.bal_close = 0;
      else
      if ( inRequest.getParameter("bal_close_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.bal_close = 0;
      else
        lDmCustomerTabObj.bal_close = Double.parseDouble( inRequest.getParameter("bal_close_r"+lNumRec));
      if ( inRequest.getParameter("bal_open_r"+lNumRec) == null )
        lDmCustomerTabObj.bal_open = 0;
      else
      if ( inRequest.getParameter("bal_open_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.bal_open = 0;
      else
        lDmCustomerTabObj.bal_open = Double.parseDouble( inRequest.getParameter("bal_open_r"+lNumRec));
      if ( inRequest.getParameter("dr_amt_r"+lNumRec) == null )
        lDmCustomerTabObj.dr_amt = 0;
      else
      if ( inRequest.getParameter("dr_amt_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.dr_amt = 0;
      else
        lDmCustomerTabObj.dr_amt = Double.parseDouble( inRequest.getParameter("dr_amt_r"+lNumRec));
      if ( inRequest.getParameter("cr_amt_r"+lNumRec) == null )
        lDmCustomerTabObj.cr_amt = 0;
      else
      if ( inRequest.getParameter("cr_amt_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.cr_amt = 0;
      else
        lDmCustomerTabObj.cr_amt = Double.parseDouble( inRequest.getParameter("cr_amt_r"+lNumRec));
      if ( inRequest.getParameter("ar_bal_r"+lNumRec) == null )
        lDmCustomerTabObj.ar_bal = 0;
      else
      if ( inRequest.getParameter("ar_bal_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.ar_bal = 0;
      else
        lDmCustomerTabObj.ar_bal = Double.parseDouble( inRequest.getParameter("ar_bal_r"+lNumRec));
      lDmCustomerTabObj.sal_cycle_code = inRequest.getParameter("sal_cycle_code_r"+lNumRec);
      lDmCustomerTabObj.bill_cycle_code = inRequest.getParameter("bill_cycle_code_r"+lNumRec);
      lDmCustomerTabObj.agreement_id = inRequest.getParameter("agreement_id_r"+lNumRec);
      lDmCustomerTabObj.agreement_eff_date = inRequest.getParameter("agreement_eff_date_r"+lNumRec);
      lDmCustomerTabObj.agreement_exp_date = inRequest.getParameter("agreement_exp_date_r"+lNumRec);
      lDmCustomerTabObj.agreement_cre_date = inRequest.getParameter("agreement_cre_date_r"+lNumRec);
      lDmCustomerTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
      lDmCustomerTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
      lDmCustomerTabObj.prev_agreement_id = inRequest.getParameter("prev_agreement_id_r"+lNumRec);
      lDmCustomerTabObj.renew_ind = inRequest.getParameter("renew_ind_r"+lNumRec);
      lDmCustomerTabObj.cycle_id = inRequest.getParameter("cycle_id_r"+lNumRec);
      lDmCustomerTabObj.spl_training_ind = inRequest.getParameter("spl_training_ind_r"+lNumRec);
      lDmCustomerTabObj.spl_uniform_ind = inRequest.getParameter("spl_uniform_ind_r"+lNumRec);
      if ( inRequest.getParameter("pay_day_r"+lNumRec) == null )
        lDmCustomerTabObj.pay_day = 0;
      else
      if ( inRequest.getParameter("pay_day_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.pay_day = 0;
      else
        lDmCustomerTabObj.pay_day = Byte.parseByte( inRequest.getParameter("pay_day_r"+lNumRec));
      if ( inRequest.getParameter("basic_r"+lNumRec) == null )
        lDmCustomerTabObj.basic = 0;
      else
      if ( inRequest.getParameter("basic_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.basic = 0;
      else
        lDmCustomerTabObj.basic = Double.parseDouble( inRequest.getParameter("basic_r"+lNumRec));
      lDmCustomerTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
      if ( inRequest.getParameter("pf_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.pf_rate = 0;
      else
      if ( inRequest.getParameter("pf_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.pf_rate = 0;
      else
        lDmCustomerTabObj.pf_rate = Double.parseDouble( inRequest.getParameter("pf_rate_r"+lNumRec));
      lDmCustomerTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
      if ( inRequest.getParameter("esi_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.esi_rate = 0;
      else
      if ( inRequest.getParameter("esi_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.esi_rate = 0;
      else
        lDmCustomerTabObj.esi_rate = Double.parseDouble( inRequest.getParameter("esi_rate_r"+lNumRec));
      lDmCustomerTabObj.da_ind = inRequest.getParameter("da_ind_r"+lNumRec);
      if ( inRequest.getParameter("da_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.da_rate = 0;
      else
      if ( inRequest.getParameter("da_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.da_rate = 0;
      else
        lDmCustomerTabObj.da_rate = Double.parseDouble( inRequest.getParameter("da_rate_r"+lNumRec));
      lDmCustomerTabObj.ta_ind = inRequest.getParameter("ta_ind_r"+lNumRec);
      if ( inRequest.getParameter("ta_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.ta_rate = 0;
      else
      if ( inRequest.getParameter("ta_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.ta_rate = 0;
      else
        lDmCustomerTabObj.ta_rate = Double.parseDouble( inRequest.getParameter("ta_rate_r"+lNumRec));
      lDmCustomerTabObj.hra_ind = inRequest.getParameter("hra_ind_r"+lNumRec);
      if ( inRequest.getParameter("hra_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.hra_rate = 0;
      else
      if ( inRequest.getParameter("hra_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.hra_rate = 0;
      else
        lDmCustomerTabObj.hra_rate = Double.parseDouble( inRequest.getParameter("hra_rate_r"+lNumRec));
      lDmCustomerTabObj.staff_wf_ind = inRequest.getParameter("staff_wf_ind_r"+lNumRec);
      if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.staff_wf_rate = 0;
      else
      if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.staff_wf_rate = 0;
      else
        lDmCustomerTabObj.staff_wf_rate = Double.parseDouble( inRequest.getParameter("staff_wf_rate_r"+lNumRec));
      lDmCustomerTabObj.lunch_ind = inRequest.getParameter("lunch_ind_r"+lNumRec);
      if ( inRequest.getParameter("lunch_rate_r"+lNumRec) == null )
        lDmCustomerTabObj.lunch_rate = 0;
      else
      if ( inRequest.getParameter("lunch_rate_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.lunch_rate = 0;
      else
        lDmCustomerTabObj.lunch_rate = Double.parseDouble( inRequest.getParameter("lunch_rate_r"+lNumRec));
      lDmCustomerTabObj.jurisdiction = inRequest.getParameter("jurisdiction_r"+lNumRec);
      lDmCustomerTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      lDmCustomerTabObj.cacnel_remark = inRequest.getParameter("cacnel_remark_r"+lNumRec);
      if ( inRequest.getParameter("service_charge_r"+lNumRec) == null )
        lDmCustomerTabObj.service_charge = 0;
      else
      if ( inRequest.getParameter("service_charge_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.service_charge = 0;
      else
        lDmCustomerTabObj.service_charge = Double.parseDouble( inRequest.getParameter("service_charge_r"+lNumRec));
      if ( inRequest.getParameter("service_tax_r"+lNumRec) == null )
        lDmCustomerTabObj.service_tax = 0;
      else
      if ( inRequest.getParameter("service_tax_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.service_tax = 0;
      else
        lDmCustomerTabObj.service_tax = Double.parseDouble( inRequest.getParameter("service_tax_r"+lNumRec));
      lDmCustomerTabObj.weeken_off_ind = inRequest.getParameter("weeken_off_ind_r"+lNumRec);
      if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
        lDmCustomerTabObj.working_days = 0;
      else
      if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.working_days = 0;
      else
        lDmCustomerTabObj.working_days = Integer.parseInt( inRequest.getParameter("working_days_r"+lNumRec));
      if ( inRequest.getParameter("manpower_qty_r"+lNumRec) == null )
        lDmCustomerTabObj.manpower_qty = 0;
      else
      if ( inRequest.getParameter("manpower_qty_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.manpower_qty = 0;
      else
        lDmCustomerTabObj.manpower_qty = Integer.parseInt( inRequest.getParameter("manpower_qty_r"+lNumRec));
      if ( inRequest.getParameter("work_hour_qty_r"+lNumRec) == null )
        lDmCustomerTabObj.work_hour_qty = 0;
      else
      if ( inRequest.getParameter("work_hour_qty_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.work_hour_qty = 0;
      else
        lDmCustomerTabObj.work_hour_qty = Integer.parseInt( inRequest.getParameter("work_hour_qty_r"+lNumRec));
      if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec) == null )
        lDmCustomerTabObj.ot_hour_qty = 0;
      else
      if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec).trim().length() == 0 )
        lDmCustomerTabObj.ot_hour_qty = 0;
      else
        lDmCustomerTabObj.ot_hour_qty = Integer.parseInt( inRequest.getParameter("ot_hour_qty_r"+lNumRec));
      lDmCustomerTabObj.labour_licence_ind = inRequest.getParameter("labour_licence_ind_r"+lNumRec);
      lDmCustomerTabObj.labour_licence_num = inRequest.getParameter("labour_licence_num_r"+lNumRec);
      lDmCustomerTabObj.labour_licence_date = inRequest.getParameter("labour_licence_date_r"+lNumRec);
      lDmCustomerTabObj.labour_licence_exp_date = inRequest.getParameter("labour_licence_exp_date_r"+lNumRec);
      lDmCustomerTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
      lDmCustomerTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lDmCustomerTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lDmCustomerTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lDmCustomerTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lDmCustomerTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
      lDmCustomerTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
      lDmCustomerTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
      lDmCustomerTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      outDmCustomerTabObjArr.add( lDmCustomerTabObj);
    }
    return lReturnValue;
  }


  public int popDmCustomerReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , DmCustomerTabObj outDmCustomerTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_customer_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outDmCustomerTabObj.tab_rowid = lTabRowidValue;

        outDmCustomerTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outDmCustomerTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        outDmCustomerTabObj.customer_type = inRequest.getParameter("customer_type_r"+lNumRec);
        outDmCustomerTabObj.customer_ctg = inRequest.getParameter("customer_ctg_r"+lNumRec);
        outDmCustomerTabObj.customer_name = inRequest.getParameter("customer_name_r"+lNumRec);
        outDmCustomerTabObj.customer_group = inRequest.getParameter("customer_group_r"+lNumRec);
        outDmCustomerTabObj.referred_by = inRequest.getParameter("referred_by_r"+lNumRec);
        if ( inRequest.getParameter("turn_over_r"+lNumRec) == null )
          outDmCustomerTabObj.turn_over = 0;
        else
        if ( inRequest.getParameter("turn_over_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.turn_over = 0;
        else
          outDmCustomerTabObj.turn_over = Double.parseDouble( inRequest.getParameter("turn_over_r"+lNumRec));
        outDmCustomerTabObj.business_area_cd = inRequest.getParameter("business_area_cd_r"+lNumRec);
        outDmCustomerTabObj.state_code = inRequest.getParameter("state_code_r"+lNumRec);
        outDmCustomerTabObj.region_id = inRequest.getParameter("region_id_r"+lNumRec);
        outDmCustomerTabObj.country_code = inRequest.getParameter("country_code_r"+lNumRec);
        outDmCustomerTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outDmCustomerTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        outDmCustomerTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        outDmCustomerTabObj.business_type = inRequest.getParameter("business_type_r"+lNumRec);
        outDmCustomerTabObj.business_est_date = inRequest.getParameter("business_est_date_r"+lNumRec);
        if ( inRequest.getParameter("employee_strength_r"+lNumRec) == null )
          outDmCustomerTabObj.employee_strength = 0;
        else
        if ( inRequest.getParameter("employee_strength_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.employee_strength = 0;
        else
          outDmCustomerTabObj.employee_strength = Integer.parseInt( inRequest.getParameter("employee_strength_r"+lNumRec));
        outDmCustomerTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
        outDmCustomerTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        outDmCustomerTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        outDmCustomerTabObj.address_3 = inRequest.getParameter("address_3_r"+lNumRec);
        outDmCustomerTabObj.cst_form_num = inRequest.getParameter("cst_form_num_r"+lNumRec);
        outDmCustomerTabObj.cst_form_date = inRequest.getParameter("cst_form_date_r"+lNumRec);
        outDmCustomerTabObj.lst_form_num = inRequest.getParameter("lst_form_num_r"+lNumRec);
        outDmCustomerTabObj.lst_form_date = inRequest.getParameter("lst_form_date_r"+lNumRec);
        outDmCustomerTabObj.tin_num = inRequest.getParameter("tin_num_r"+lNumRec);
        outDmCustomerTabObj.tin_date = inRequest.getParameter("tin_date_r"+lNumRec);
        outDmCustomerTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        outDmCustomerTabObj.pan_date = inRequest.getParameter("pan_date_r"+lNumRec);
        outDmCustomerTabObj.tan_num = inRequest.getParameter("tan_num_r"+lNumRec);
        outDmCustomerTabObj.tan_date = inRequest.getParameter("tan_date_r"+lNumRec);
        outDmCustomerTabObj.strn_num = inRequest.getParameter("strn_num_r"+lNumRec);
        outDmCustomerTabObj.strn_date = inRequest.getParameter("strn_date_r"+lNumRec);
        outDmCustomerTabObj.account_num = inRequest.getParameter("account_num_r"+lNumRec);
        if ( inRequest.getParameter("bal_close_r"+lNumRec) == null )
          outDmCustomerTabObj.bal_close = 0;
        else
        if ( inRequest.getParameter("bal_close_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.bal_close = 0;
        else
          outDmCustomerTabObj.bal_close = Double.parseDouble( inRequest.getParameter("bal_close_r"+lNumRec));
        if ( inRequest.getParameter("bal_open_r"+lNumRec) == null )
          outDmCustomerTabObj.bal_open = 0;
        else
        if ( inRequest.getParameter("bal_open_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.bal_open = 0;
        else
          outDmCustomerTabObj.bal_open = Double.parseDouble( inRequest.getParameter("bal_open_r"+lNumRec));
        if ( inRequest.getParameter("dr_amt_r"+lNumRec) == null )
          outDmCustomerTabObj.dr_amt = 0;
        else
        if ( inRequest.getParameter("dr_amt_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.dr_amt = 0;
        else
          outDmCustomerTabObj.dr_amt = Double.parseDouble( inRequest.getParameter("dr_amt_r"+lNumRec));
        if ( inRequest.getParameter("cr_amt_r"+lNumRec) == null )
          outDmCustomerTabObj.cr_amt = 0;
        else
        if ( inRequest.getParameter("cr_amt_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.cr_amt = 0;
        else
          outDmCustomerTabObj.cr_amt = Double.parseDouble( inRequest.getParameter("cr_amt_r"+lNumRec));
        if ( inRequest.getParameter("ar_bal_r"+lNumRec) == null )
          outDmCustomerTabObj.ar_bal = 0;
        else
        if ( inRequest.getParameter("ar_bal_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.ar_bal = 0;
        else
          outDmCustomerTabObj.ar_bal = Double.parseDouble( inRequest.getParameter("ar_bal_r"+lNumRec));
        outDmCustomerTabObj.sal_cycle_code = inRequest.getParameter("sal_cycle_code_r"+lNumRec);
        outDmCustomerTabObj.bill_cycle_code = inRequest.getParameter("bill_cycle_code_r"+lNumRec);
        outDmCustomerTabObj.agreement_id = inRequest.getParameter("agreement_id_r"+lNumRec);
        outDmCustomerTabObj.agreement_eff_date = inRequest.getParameter("agreement_eff_date_r"+lNumRec);
        outDmCustomerTabObj.agreement_exp_date = inRequest.getParameter("agreement_exp_date_r"+lNumRec);
        outDmCustomerTabObj.agreement_cre_date = inRequest.getParameter("agreement_cre_date_r"+lNumRec);
        outDmCustomerTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
        outDmCustomerTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
        outDmCustomerTabObj.prev_agreement_id = inRequest.getParameter("prev_agreement_id_r"+lNumRec);
        outDmCustomerTabObj.renew_ind = inRequest.getParameter("renew_ind_r"+lNumRec);
        outDmCustomerTabObj.cycle_id = inRequest.getParameter("cycle_id_r"+lNumRec);
        outDmCustomerTabObj.spl_training_ind = inRequest.getParameter("spl_training_ind_r"+lNumRec);
        outDmCustomerTabObj.spl_uniform_ind = inRequest.getParameter("spl_uniform_ind_r"+lNumRec);
        if ( inRequest.getParameter("pay_day_r"+lNumRec) == null )
          outDmCustomerTabObj.pay_day = 0;
        else
        if ( inRequest.getParameter("pay_day_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.pay_day = 0;
        else
          outDmCustomerTabObj.pay_day = Byte.parseByte( inRequest.getParameter("pay_day_r"+lNumRec));
        if ( inRequest.getParameter("basic_r"+lNumRec) == null )
          outDmCustomerTabObj.basic = 0;
        else
        if ( inRequest.getParameter("basic_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.basic = 0;
        else
          outDmCustomerTabObj.basic = Double.parseDouble( inRequest.getParameter("basic_r"+lNumRec));
        outDmCustomerTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
        if ( inRequest.getParameter("pf_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.pf_rate = 0;
        else
        if ( inRequest.getParameter("pf_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.pf_rate = 0;
        else
          outDmCustomerTabObj.pf_rate = Double.parseDouble( inRequest.getParameter("pf_rate_r"+lNumRec));
        outDmCustomerTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
        if ( inRequest.getParameter("esi_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.esi_rate = 0;
        else
        if ( inRequest.getParameter("esi_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.esi_rate = 0;
        else
          outDmCustomerTabObj.esi_rate = Double.parseDouble( inRequest.getParameter("esi_rate_r"+lNumRec));
        outDmCustomerTabObj.da_ind = inRequest.getParameter("da_ind_r"+lNumRec);
        if ( inRequest.getParameter("da_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.da_rate = 0;
        else
        if ( inRequest.getParameter("da_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.da_rate = 0;
        else
          outDmCustomerTabObj.da_rate = Double.parseDouble( inRequest.getParameter("da_rate_r"+lNumRec));
        outDmCustomerTabObj.ta_ind = inRequest.getParameter("ta_ind_r"+lNumRec);
        if ( inRequest.getParameter("ta_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.ta_rate = 0;
        else
        if ( inRequest.getParameter("ta_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.ta_rate = 0;
        else
          outDmCustomerTabObj.ta_rate = Double.parseDouble( inRequest.getParameter("ta_rate_r"+lNumRec));
        outDmCustomerTabObj.hra_ind = inRequest.getParameter("hra_ind_r"+lNumRec);
        if ( inRequest.getParameter("hra_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.hra_rate = 0;
        else
        if ( inRequest.getParameter("hra_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.hra_rate = 0;
        else
          outDmCustomerTabObj.hra_rate = Double.parseDouble( inRequest.getParameter("hra_rate_r"+lNumRec));
        outDmCustomerTabObj.staff_wf_ind = inRequest.getParameter("staff_wf_ind_r"+lNumRec);
        if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.staff_wf_rate = 0;
        else
        if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.staff_wf_rate = 0;
        else
          outDmCustomerTabObj.staff_wf_rate = Double.parseDouble( inRequest.getParameter("staff_wf_rate_r"+lNumRec));
        outDmCustomerTabObj.lunch_ind = inRequest.getParameter("lunch_ind_r"+lNumRec);
        if ( inRequest.getParameter("lunch_rate_r"+lNumRec) == null )
          outDmCustomerTabObj.lunch_rate = 0;
        else
        if ( inRequest.getParameter("lunch_rate_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.lunch_rate = 0;
        else
          outDmCustomerTabObj.lunch_rate = Double.parseDouble( inRequest.getParameter("lunch_rate_r"+lNumRec));
        outDmCustomerTabObj.jurisdiction = inRequest.getParameter("jurisdiction_r"+lNumRec);
        outDmCustomerTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        outDmCustomerTabObj.cacnel_remark = inRequest.getParameter("cacnel_remark_r"+lNumRec);
        if ( inRequest.getParameter("service_charge_r"+lNumRec) == null )
          outDmCustomerTabObj.service_charge = 0;
        else
        if ( inRequest.getParameter("service_charge_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.service_charge = 0;
        else
          outDmCustomerTabObj.service_charge = Double.parseDouble( inRequest.getParameter("service_charge_r"+lNumRec));
        if ( inRequest.getParameter("service_tax_r"+lNumRec) == null )
          outDmCustomerTabObj.service_tax = 0;
        else
        if ( inRequest.getParameter("service_tax_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.service_tax = 0;
        else
          outDmCustomerTabObj.service_tax = Double.parseDouble( inRequest.getParameter("service_tax_r"+lNumRec));
        outDmCustomerTabObj.weeken_off_ind = inRequest.getParameter("weeken_off_ind_r"+lNumRec);
        if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
          outDmCustomerTabObj.working_days = 0;
        else
        if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.working_days = 0;
        else
          outDmCustomerTabObj.working_days = Integer.parseInt( inRequest.getParameter("working_days_r"+lNumRec));
        if ( inRequest.getParameter("manpower_qty_r"+lNumRec) == null )
          outDmCustomerTabObj.manpower_qty = 0;
        else
        if ( inRequest.getParameter("manpower_qty_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.manpower_qty = 0;
        else
          outDmCustomerTabObj.manpower_qty = Integer.parseInt( inRequest.getParameter("manpower_qty_r"+lNumRec));
        if ( inRequest.getParameter("work_hour_qty_r"+lNumRec) == null )
          outDmCustomerTabObj.work_hour_qty = 0;
        else
        if ( inRequest.getParameter("work_hour_qty_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.work_hour_qty = 0;
        else
          outDmCustomerTabObj.work_hour_qty = Integer.parseInt( inRequest.getParameter("work_hour_qty_r"+lNumRec));
        if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec) == null )
          outDmCustomerTabObj.ot_hour_qty = 0;
        else
        if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec).trim().length() == 0 )
          outDmCustomerTabObj.ot_hour_qty = 0;
        else
          outDmCustomerTabObj.ot_hour_qty = Integer.parseInt( inRequest.getParameter("ot_hour_qty_r"+lNumRec));
        outDmCustomerTabObj.labour_licence_ind = inRequest.getParameter("labour_licence_ind_r"+lNumRec);
        outDmCustomerTabObj.labour_licence_num = inRequest.getParameter("labour_licence_num_r"+lNumRec);
        outDmCustomerTabObj.labour_licence_date = inRequest.getParameter("labour_licence_date_r"+lNumRec);
        outDmCustomerTabObj.labour_licence_exp_date = inRequest.getParameter("labour_licence_exp_date_r"+lNumRec);
        outDmCustomerTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        outDmCustomerTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outDmCustomerTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outDmCustomerTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outDmCustomerTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outDmCustomerTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        outDmCustomerTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        outDmCustomerTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        outDmCustomerTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popDmCustomerReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmCustomerTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmCustomerTabObj lDmCustomerTabObj= new DmCustomerTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_customer_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmCustomerTabObj.tab_rowid = lTabRowidValue;

        lDmCustomerTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lDmCustomerTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        lDmCustomerTabObj.customer_type = inRequest.getParameter("customer_type_r"+lNumRec);
        lDmCustomerTabObj.customer_ctg = inRequest.getParameter("customer_ctg_r"+lNumRec);
        lDmCustomerTabObj.customer_name = inRequest.getParameter("customer_name_r"+lNumRec);
        lDmCustomerTabObj.customer_group = inRequest.getParameter("customer_group_r"+lNumRec);
        lDmCustomerTabObj.referred_by = inRequest.getParameter("referred_by_r"+lNumRec);
        if ( inRequest.getParameter("turn_over_r"+lNumRec) == null )
          lDmCustomerTabObj.turn_over = 0;
        else
        if ( inRequest.getParameter("turn_over_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.turn_over = 0;
        else
            lDmCustomerTabObj.turn_over = Double.parseDouble( inRequest.getParameter("turn_over_r"+lNumRec));
        lDmCustomerTabObj.business_area_cd = inRequest.getParameter("business_area_cd_r"+lNumRec);
        lDmCustomerTabObj.state_code = inRequest.getParameter("state_code_r"+lNumRec);
        lDmCustomerTabObj.region_id = inRequest.getParameter("region_id_r"+lNumRec);
        lDmCustomerTabObj.country_code = inRequest.getParameter("country_code_r"+lNumRec);
        lDmCustomerTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lDmCustomerTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        lDmCustomerTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        lDmCustomerTabObj.business_type = inRequest.getParameter("business_type_r"+lNumRec);
        lDmCustomerTabObj.business_est_date = inRequest.getParameter("business_est_date_r"+lNumRec);
        if ( inRequest.getParameter("employee_strength_r"+lNumRec) == null )
          lDmCustomerTabObj.employee_strength = 0;
        else
        if ( inRequest.getParameter("employee_strength_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.employee_strength = 0;
        else
          lDmCustomerTabObj.employee_strength = Integer.parseInt( inRequest.getParameter("employee_strength_r"+lNumRec));
        lDmCustomerTabObj.business_currency = inRequest.getParameter("business_currency_r"+lNumRec);
        lDmCustomerTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        lDmCustomerTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        lDmCustomerTabObj.address_3 = inRequest.getParameter("address_3_r"+lNumRec);
        lDmCustomerTabObj.cst_form_num = inRequest.getParameter("cst_form_num_r"+lNumRec);
        lDmCustomerTabObj.cst_form_date = inRequest.getParameter("cst_form_date_r"+lNumRec);
        lDmCustomerTabObj.lst_form_num = inRequest.getParameter("lst_form_num_r"+lNumRec);
        lDmCustomerTabObj.lst_form_date = inRequest.getParameter("lst_form_date_r"+lNumRec);
        lDmCustomerTabObj.tin_num = inRequest.getParameter("tin_num_r"+lNumRec);
        lDmCustomerTabObj.tin_date = inRequest.getParameter("tin_date_r"+lNumRec);
        lDmCustomerTabObj.pan_num = inRequest.getParameter("pan_num_r"+lNumRec);
        lDmCustomerTabObj.pan_date = inRequest.getParameter("pan_date_r"+lNumRec);
        lDmCustomerTabObj.tan_num = inRequest.getParameter("tan_num_r"+lNumRec);
        lDmCustomerTabObj.tan_date = inRequest.getParameter("tan_date_r"+lNumRec);
        lDmCustomerTabObj.strn_num = inRequest.getParameter("strn_num_r"+lNumRec);
        lDmCustomerTabObj.strn_date = inRequest.getParameter("strn_date_r"+lNumRec);
        lDmCustomerTabObj.account_num = inRequest.getParameter("account_num_r"+lNumRec);
        if ( inRequest.getParameter("bal_close_r"+lNumRec) == null )
          lDmCustomerTabObj.bal_close = 0;
        else
        if ( inRequest.getParameter("bal_close_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.bal_close = 0;
        else
            lDmCustomerTabObj.bal_close = Double.parseDouble( inRequest.getParameter("bal_close_r"+lNumRec));
        if ( inRequest.getParameter("bal_open_r"+lNumRec) == null )
          lDmCustomerTabObj.bal_open = 0;
        else
        if ( inRequest.getParameter("bal_open_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.bal_open = 0;
        else
            lDmCustomerTabObj.bal_open = Double.parseDouble( inRequest.getParameter("bal_open_r"+lNumRec));
        if ( inRequest.getParameter("dr_amt_r"+lNumRec) == null )
          lDmCustomerTabObj.dr_amt = 0;
        else
        if ( inRequest.getParameter("dr_amt_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.dr_amt = 0;
        else
            lDmCustomerTabObj.dr_amt = Double.parseDouble( inRequest.getParameter("dr_amt_r"+lNumRec));
        if ( inRequest.getParameter("cr_amt_r"+lNumRec) == null )
          lDmCustomerTabObj.cr_amt = 0;
        else
        if ( inRequest.getParameter("cr_amt_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.cr_amt = 0;
        else
            lDmCustomerTabObj.cr_amt = Double.parseDouble( inRequest.getParameter("cr_amt_r"+lNumRec));
        if ( inRequest.getParameter("ar_bal_r"+lNumRec) == null )
          lDmCustomerTabObj.ar_bal = 0;
        else
        if ( inRequest.getParameter("ar_bal_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.ar_bal = 0;
        else
            lDmCustomerTabObj.ar_bal = Double.parseDouble( inRequest.getParameter("ar_bal_r"+lNumRec));
        lDmCustomerTabObj.sal_cycle_code = inRequest.getParameter("sal_cycle_code_r"+lNumRec);
        lDmCustomerTabObj.bill_cycle_code = inRequest.getParameter("bill_cycle_code_r"+lNumRec);
        lDmCustomerTabObj.agreement_id = inRequest.getParameter("agreement_id_r"+lNumRec);
        lDmCustomerTabObj.agreement_eff_date = inRequest.getParameter("agreement_eff_date_r"+lNumRec);
        lDmCustomerTabObj.agreement_exp_date = inRequest.getParameter("agreement_exp_date_r"+lNumRec);
        lDmCustomerTabObj.agreement_cre_date = inRequest.getParameter("agreement_cre_date_r"+lNumRec);
        lDmCustomerTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
        lDmCustomerTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
        lDmCustomerTabObj.prev_agreement_id = inRequest.getParameter("prev_agreement_id_r"+lNumRec);
        lDmCustomerTabObj.renew_ind = inRequest.getParameter("renew_ind_r"+lNumRec);
        lDmCustomerTabObj.cycle_id = inRequest.getParameter("cycle_id_r"+lNumRec);
        lDmCustomerTabObj.spl_training_ind = inRequest.getParameter("spl_training_ind_r"+lNumRec);
        lDmCustomerTabObj.spl_uniform_ind = inRequest.getParameter("spl_uniform_ind_r"+lNumRec);
        if ( inRequest.getParameter("pay_day_r"+lNumRec) == null )
          lDmCustomerTabObj.pay_day = 0;
        else
        if ( inRequest.getParameter("pay_day_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.pay_day = 0;
        else
          lDmCustomerTabObj.pay_day = Byte.parseByte( inRequest.getParameter("pay_day_r"+lNumRec));
        if ( inRequest.getParameter("basic_r"+lNumRec) == null )
          lDmCustomerTabObj.basic = 0;
        else
        if ( inRequest.getParameter("basic_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.basic = 0;
        else
            lDmCustomerTabObj.basic = Double.parseDouble( inRequest.getParameter("basic_r"+lNumRec));
        lDmCustomerTabObj.pf_ind = inRequest.getParameter("pf_ind_r"+lNumRec);
        if ( inRequest.getParameter("pf_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.pf_rate = 0;
        else
        if ( inRequest.getParameter("pf_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.pf_rate = 0;
        else
            lDmCustomerTabObj.pf_rate = Double.parseDouble( inRequest.getParameter("pf_rate_r"+lNumRec));
        lDmCustomerTabObj.esi_ind = inRequest.getParameter("esi_ind_r"+lNumRec);
        if ( inRequest.getParameter("esi_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.esi_rate = 0;
        else
        if ( inRequest.getParameter("esi_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.esi_rate = 0;
        else
            lDmCustomerTabObj.esi_rate = Double.parseDouble( inRequest.getParameter("esi_rate_r"+lNumRec));
        lDmCustomerTabObj.da_ind = inRequest.getParameter("da_ind_r"+lNumRec);
        if ( inRequest.getParameter("da_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.da_rate = 0;
        else
        if ( inRequest.getParameter("da_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.da_rate = 0;
        else
            lDmCustomerTabObj.da_rate = Double.parseDouble( inRequest.getParameter("da_rate_r"+lNumRec));
        lDmCustomerTabObj.ta_ind = inRequest.getParameter("ta_ind_r"+lNumRec);
        if ( inRequest.getParameter("ta_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.ta_rate = 0;
        else
        if ( inRequest.getParameter("ta_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.ta_rate = 0;
        else
            lDmCustomerTabObj.ta_rate = Double.parseDouble( inRequest.getParameter("ta_rate_r"+lNumRec));
        lDmCustomerTabObj.hra_ind = inRequest.getParameter("hra_ind_r"+lNumRec);
        if ( inRequest.getParameter("hra_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.hra_rate = 0;
        else
        if ( inRequest.getParameter("hra_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.hra_rate = 0;
        else
            lDmCustomerTabObj.hra_rate = Double.parseDouble( inRequest.getParameter("hra_rate_r"+lNumRec));
        lDmCustomerTabObj.staff_wf_ind = inRequest.getParameter("staff_wf_ind_r"+lNumRec);
        if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.staff_wf_rate = 0;
        else
        if ( inRequest.getParameter("staff_wf_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.staff_wf_rate = 0;
        else
            lDmCustomerTabObj.staff_wf_rate = Double.parseDouble( inRequest.getParameter("staff_wf_rate_r"+lNumRec));
        lDmCustomerTabObj.lunch_ind = inRequest.getParameter("lunch_ind_r"+lNumRec);
        if ( inRequest.getParameter("lunch_rate_r"+lNumRec) == null )
          lDmCustomerTabObj.lunch_rate = 0;
        else
        if ( inRequest.getParameter("lunch_rate_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.lunch_rate = 0;
        else
            lDmCustomerTabObj.lunch_rate = Double.parseDouble( inRequest.getParameter("lunch_rate_r"+lNumRec));
        lDmCustomerTabObj.jurisdiction = inRequest.getParameter("jurisdiction_r"+lNumRec);
        lDmCustomerTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        lDmCustomerTabObj.cacnel_remark = inRequest.getParameter("cacnel_remark_r"+lNumRec);
        if ( inRequest.getParameter("service_charge_r"+lNumRec) == null )
          lDmCustomerTabObj.service_charge = 0;
        else
        if ( inRequest.getParameter("service_charge_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.service_charge = 0;
        else
            lDmCustomerTabObj.service_charge = Double.parseDouble( inRequest.getParameter("service_charge_r"+lNumRec));
        if ( inRequest.getParameter("service_tax_r"+lNumRec) == null )
          lDmCustomerTabObj.service_tax = 0;
        else
        if ( inRequest.getParameter("service_tax_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.service_tax = 0;
        else
            lDmCustomerTabObj.service_tax = Double.parseDouble( inRequest.getParameter("service_tax_r"+lNumRec));
        lDmCustomerTabObj.weeken_off_ind = inRequest.getParameter("weeken_off_ind_r"+lNumRec);
        if ( inRequest.getParameter("working_days_r"+lNumRec) == null )
          lDmCustomerTabObj.working_days = 0;
        else
        if ( inRequest.getParameter("working_days_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.working_days = 0;
        else
          lDmCustomerTabObj.working_days = Integer.parseInt( inRequest.getParameter("working_days_r"+lNumRec));
        if ( inRequest.getParameter("manpower_qty_r"+lNumRec) == null )
          lDmCustomerTabObj.manpower_qty = 0;
        else
        if ( inRequest.getParameter("manpower_qty_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.manpower_qty = 0;
        else
          lDmCustomerTabObj.manpower_qty = Integer.parseInt( inRequest.getParameter("manpower_qty_r"+lNumRec));
        if ( inRequest.getParameter("work_hour_qty_r"+lNumRec) == null )
          lDmCustomerTabObj.work_hour_qty = 0;
        else
        if ( inRequest.getParameter("work_hour_qty_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.work_hour_qty = 0;
        else
          lDmCustomerTabObj.work_hour_qty = Integer.parseInt( inRequest.getParameter("work_hour_qty_r"+lNumRec));
        if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec) == null )
          lDmCustomerTabObj.ot_hour_qty = 0;
        else
        if ( inRequest.getParameter("ot_hour_qty_r"+lNumRec).trim().length() == 0 )
          lDmCustomerTabObj.ot_hour_qty = 0;
        else
          lDmCustomerTabObj.ot_hour_qty = Integer.parseInt( inRequest.getParameter("ot_hour_qty_r"+lNumRec));
        lDmCustomerTabObj.labour_licence_ind = inRequest.getParameter("labour_licence_ind_r"+lNumRec);
        lDmCustomerTabObj.labour_licence_num = inRequest.getParameter("labour_licence_num_r"+lNumRec);
        lDmCustomerTabObj.labour_licence_date = inRequest.getParameter("labour_licence_date_r"+lNumRec);
        lDmCustomerTabObj.labour_licence_exp_date = inRequest.getParameter("labour_licence_exp_date_r"+lNumRec);
        lDmCustomerTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        lDmCustomerTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lDmCustomerTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lDmCustomerTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lDmCustomerTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lDmCustomerTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        lDmCustomerTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        lDmCustomerTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        lDmCustomerTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
        outDmCustomerTabObjArr.add( lDmCustomerTabObj);
      }
    }
    return lReturnValue;
  }





  public int updDmCustomerRecByRowid
               ( String inRowId
               , DmCustomerTabObj  inDmCustomerTabObj
               )
  {
    int lUpdateCount;
    sop("updDmCustomerRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updDmCustomerRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustomerTabObj.expiration_date != null && inDmCustomerTabObj.expiration_date.length() > 0 ) 
            inDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.effective_date != null && inDmCustomerTabObj.effective_date.length() > 0 ) 
            inDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.business_est_date != null && inDmCustomerTabObj.business_est_date.length() > 0 ) 
            inDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.business_est_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.cst_form_date != null && inDmCustomerTabObj.cst_form_date.length() > 0 ) 
            inDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.cst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.lst_form_date != null && inDmCustomerTabObj.lst_form_date.length() > 0 ) 
            inDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.lst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tin_date != null && inDmCustomerTabObj.tin_date.length() > 0 ) 
            inDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tin_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.pan_date != null && inDmCustomerTabObj.pan_date.length() > 0 ) 
            inDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.pan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tan_date != null && inDmCustomerTabObj.tan_date.length() > 0 ) 
            inDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.strn_date != null && inDmCustomerTabObj.strn_date.length() > 0 ) 
            inDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.strn_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_eff_date != null && inDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_eff_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_exp_date != null && inDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_cre_date != null && inDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_sts_date != null && inDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_date != null && inDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_exp_date != null && inDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_cre_date != null && inDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            inDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_upd_date != null && inDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            inDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.file_cre_date != null && inDmCustomerTabObj.file_cre_date.length() > 0 ) 
            inDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUSTOMER ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inDmCustomerTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmCustomerTabObj.org_id+"', ";
      if ( inDmCustomerTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmCustomerTabObj.customer_id+"', ";
      if ( inDmCustomerTabObj.customer_type != null  )         lSqlStmt = lSqlStmt + "customer_type = "+"'"+inDmCustomerTabObj.customer_type+"', ";
      if ( inDmCustomerTabObj.customer_ctg != null  )         lSqlStmt = lSqlStmt + "customer_ctg = "+"'"+inDmCustomerTabObj.customer_ctg+"', ";
      if ( inDmCustomerTabObj.customer_name != null  )         lSqlStmt = lSqlStmt + "customer_name = "+"'"+inDmCustomerTabObj.customer_name+"', ";
      if ( inDmCustomerTabObj.customer_group != null  )         lSqlStmt = lSqlStmt + "customer_group = "+"'"+inDmCustomerTabObj.customer_group+"', ";
      if ( inDmCustomerTabObj.referred_by != null  )         lSqlStmt = lSqlStmt + "referred_by = "+"'"+inDmCustomerTabObj.referred_by+"', ";
             lSqlStmt = lSqlStmt + "turn_over = "+inDmCustomerTabObj.turn_over+", ";
      if ( inDmCustomerTabObj.business_area_cd != null  )         lSqlStmt = lSqlStmt + "business_area_cd = "+"'"+inDmCustomerTabObj.business_area_cd+"', ";
      if ( inDmCustomerTabObj.state_code != null  )         lSqlStmt = lSqlStmt + "state_code = "+"'"+inDmCustomerTabObj.state_code+"', ";
      if ( inDmCustomerTabObj.region_id != null  )         lSqlStmt = lSqlStmt + "region_id = "+"'"+inDmCustomerTabObj.region_id+"', ";
      if ( inDmCustomerTabObj.country_code != null  )         lSqlStmt = lSqlStmt + "country_code = "+"'"+inDmCustomerTabObj.country_code+"', ";
      if ( inDmCustomerTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inDmCustomerTabObj.status+"', ";
      if ( inDmCustomerTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inDmCustomerTabObj.expiration_date+"', ";
      if ( inDmCustomerTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inDmCustomerTabObj.effective_date+"', ";
      if ( inDmCustomerTabObj.business_type != null  )         lSqlStmt = lSqlStmt + "business_type = "+"'"+inDmCustomerTabObj.business_type+"', ";
      if ( inDmCustomerTabObj.business_est_date != null  )         lSqlStmt = lSqlStmt + "business_est_date = "+"'"+inDmCustomerTabObj.business_est_date+"', ";
             lSqlStmt = lSqlStmt + "employee_strength = "+inDmCustomerTabObj.employee_strength+", ";
      if ( inDmCustomerTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = "+"'"+inDmCustomerTabObj.business_currency+"', ";
      if ( inDmCustomerTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inDmCustomerTabObj.address_1+"', ";
      if ( inDmCustomerTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inDmCustomerTabObj.address_2+"', ";
      if ( inDmCustomerTabObj.address_3 != null  )         lSqlStmt = lSqlStmt + "address_3 = "+"'"+inDmCustomerTabObj.address_3+"', ";
      if ( inDmCustomerTabObj.cst_form_num != null  )         lSqlStmt = lSqlStmt + "cst_form_num = "+"'"+inDmCustomerTabObj.cst_form_num+"', ";
      if ( inDmCustomerTabObj.cst_form_date != null  )         lSqlStmt = lSqlStmt + "cst_form_date = "+"'"+inDmCustomerTabObj.cst_form_date+"', ";
      if ( inDmCustomerTabObj.lst_form_num != null  )         lSqlStmt = lSqlStmt + "lst_form_num = "+"'"+inDmCustomerTabObj.lst_form_num+"', ";
      if ( inDmCustomerTabObj.lst_form_date != null  )         lSqlStmt = lSqlStmt + "lst_form_date = "+"'"+inDmCustomerTabObj.lst_form_date+"', ";
      if ( inDmCustomerTabObj.tin_num != null  )         lSqlStmt = lSqlStmt + "tin_num = "+"'"+inDmCustomerTabObj.tin_num+"', ";
      if ( inDmCustomerTabObj.tin_date != null  )         lSqlStmt = lSqlStmt + "tin_date = "+"'"+inDmCustomerTabObj.tin_date+"', ";
      if ( inDmCustomerTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inDmCustomerTabObj.pan_num+"', ";
      if ( inDmCustomerTabObj.pan_date != null  )         lSqlStmt = lSqlStmt + "pan_date = "+"'"+inDmCustomerTabObj.pan_date+"', ";
      if ( inDmCustomerTabObj.tan_num != null  )         lSqlStmt = lSqlStmt + "tan_num = "+"'"+inDmCustomerTabObj.tan_num+"', ";
      if ( inDmCustomerTabObj.tan_date != null  )         lSqlStmt = lSqlStmt + "tan_date = "+"'"+inDmCustomerTabObj.tan_date+"', ";
      if ( inDmCustomerTabObj.strn_num != null  )         lSqlStmt = lSqlStmt + "strn_num = "+"'"+inDmCustomerTabObj.strn_num+"', ";
      if ( inDmCustomerTabObj.strn_date != null  )         lSqlStmt = lSqlStmt + "strn_date = "+"'"+inDmCustomerTabObj.strn_date+"', ";
      if ( inDmCustomerTabObj.account_num != null  )         lSqlStmt = lSqlStmt + "account_num = "+"'"+inDmCustomerTabObj.account_num+"', ";
             lSqlStmt = lSqlStmt + "bal_close = "+inDmCustomerTabObj.bal_close+", ";
             lSqlStmt = lSqlStmt + "bal_open = "+inDmCustomerTabObj.bal_open+", ";
             lSqlStmt = lSqlStmt + "dr_amt = "+inDmCustomerTabObj.dr_amt+", ";
             lSqlStmt = lSqlStmt + "cr_amt = "+inDmCustomerTabObj.cr_amt+", ";
             lSqlStmt = lSqlStmt + "ar_bal = "+inDmCustomerTabObj.ar_bal+", ";
      if ( inDmCustomerTabObj.sal_cycle_code != null  )         lSqlStmt = lSqlStmt + "sal_cycle_code = "+"'"+inDmCustomerTabObj.sal_cycle_code+"', ";
      if ( inDmCustomerTabObj.bill_cycle_code != null  )         lSqlStmt = lSqlStmt + "bill_cycle_code = "+"'"+inDmCustomerTabObj.bill_cycle_code+"', ";
      if ( inDmCustomerTabObj.agreement_id != null  )         lSqlStmt = lSqlStmt + "agreement_id = "+"'"+inDmCustomerTabObj.agreement_id+"', ";
      if ( inDmCustomerTabObj.agreement_eff_date != null  )         lSqlStmt = lSqlStmt + "agreement_eff_date = "+"'"+inDmCustomerTabObj.agreement_eff_date+"', ";
      if ( inDmCustomerTabObj.agreement_exp_date != null  )         lSqlStmt = lSqlStmt + "agreement_exp_date = "+"'"+inDmCustomerTabObj.agreement_exp_date+"', ";
      if ( inDmCustomerTabObj.agreement_cre_date != null  )         lSqlStmt = lSqlStmt + "agreement_cre_date = "+"'"+inDmCustomerTabObj.agreement_cre_date+"', ";
      if ( inDmCustomerTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = "+"'"+inDmCustomerTabObj.agreement_sts+"', ";
      if ( inDmCustomerTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = "+"'"+inDmCustomerTabObj.agreement_sts_date+"', ";
      if ( inDmCustomerTabObj.prev_agreement_id != null  )         lSqlStmt = lSqlStmt + "prev_agreement_id = "+"'"+inDmCustomerTabObj.prev_agreement_id+"', ";
      if ( inDmCustomerTabObj.renew_ind != null  )         lSqlStmt = lSqlStmt + "renew_ind = "+"'"+inDmCustomerTabObj.renew_ind+"', ";
      if ( inDmCustomerTabObj.cycle_id != null  )         lSqlStmt = lSqlStmt + "cycle_id = "+"'"+inDmCustomerTabObj.cycle_id+"', ";
      if ( inDmCustomerTabObj.spl_training_ind != null  )         lSqlStmt = lSqlStmt + "spl_training_ind = "+"'"+inDmCustomerTabObj.spl_training_ind+"', ";
      if ( inDmCustomerTabObj.spl_uniform_ind != null  )         lSqlStmt = lSqlStmt + "spl_uniform_ind = "+"'"+inDmCustomerTabObj.spl_uniform_ind+"', ";
             lSqlStmt = lSqlStmt + "pay_day = "+inDmCustomerTabObj.pay_day+", ";
             lSqlStmt = lSqlStmt + "basic = "+inDmCustomerTabObj.basic+", ";
      if ( inDmCustomerTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = "+"'"+inDmCustomerTabObj.pf_ind+"', ";
             lSqlStmt = lSqlStmt + "pf_rate = "+inDmCustomerTabObj.pf_rate+", ";
      if ( inDmCustomerTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = "+"'"+inDmCustomerTabObj.esi_ind+"', ";
             lSqlStmt = lSqlStmt + "esi_rate = "+inDmCustomerTabObj.esi_rate+", ";
      if ( inDmCustomerTabObj.da_ind != null  )         lSqlStmt = lSqlStmt + "da_ind = "+"'"+inDmCustomerTabObj.da_ind+"', ";
             lSqlStmt = lSqlStmt + "da_rate = "+inDmCustomerTabObj.da_rate+", ";
      if ( inDmCustomerTabObj.ta_ind != null  )         lSqlStmt = lSqlStmt + "ta_ind = "+"'"+inDmCustomerTabObj.ta_ind+"', ";
             lSqlStmt = lSqlStmt + "ta_rate = "+inDmCustomerTabObj.ta_rate+", ";
      if ( inDmCustomerTabObj.hra_ind != null  )         lSqlStmt = lSqlStmt + "hra_ind = "+"'"+inDmCustomerTabObj.hra_ind+"', ";
             lSqlStmt = lSqlStmt + "hra_rate = "+inDmCustomerTabObj.hra_rate+", ";
      if ( inDmCustomerTabObj.staff_wf_ind != null  )         lSqlStmt = lSqlStmt + "staff_wf_ind = "+"'"+inDmCustomerTabObj.staff_wf_ind+"', ";
             lSqlStmt = lSqlStmt + "staff_wf_rate = "+inDmCustomerTabObj.staff_wf_rate+", ";
      if ( inDmCustomerTabObj.lunch_ind != null  )         lSqlStmt = lSqlStmt + "lunch_ind = "+"'"+inDmCustomerTabObj.lunch_ind+"', ";
             lSqlStmt = lSqlStmt + "lunch_rate = "+inDmCustomerTabObj.lunch_rate+", ";
      if ( inDmCustomerTabObj.jurisdiction != null  )         lSqlStmt = lSqlStmt + "jurisdiction = "+"'"+inDmCustomerTabObj.jurisdiction+"', ";
      if ( inDmCustomerTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inDmCustomerTabObj.remark+"', ";
      if ( inDmCustomerTabObj.cacnel_remark != null  )         lSqlStmt = lSqlStmt + "cacnel_remark = "+"'"+inDmCustomerTabObj.cacnel_remark+"', ";
             lSqlStmt = lSqlStmt + "service_charge = "+inDmCustomerTabObj.service_charge+", ";
             lSqlStmt = lSqlStmt + "service_tax = "+inDmCustomerTabObj.service_tax+", ";
      if ( inDmCustomerTabObj.weeken_off_ind != null  )         lSqlStmt = lSqlStmt + "weeken_off_ind = "+"'"+inDmCustomerTabObj.weeken_off_ind+"', ";
             lSqlStmt = lSqlStmt + "working_days = "+inDmCustomerTabObj.working_days+", ";
             lSqlStmt = lSqlStmt + "manpower_qty = "+inDmCustomerTabObj.manpower_qty+", ";
             lSqlStmt = lSqlStmt + "work_hour_qty = "+inDmCustomerTabObj.work_hour_qty+", ";
             lSqlStmt = lSqlStmt + "ot_hour_qty = "+inDmCustomerTabObj.ot_hour_qty+", ";
      if ( inDmCustomerTabObj.labour_licence_ind != null  )         lSqlStmt = lSqlStmt + "labour_licence_ind = "+"'"+inDmCustomerTabObj.labour_licence_ind+"', ";
      if ( inDmCustomerTabObj.labour_licence_num != null  )         lSqlStmt = lSqlStmt + "labour_licence_num = "+"'"+inDmCustomerTabObj.labour_licence_num+"', ";
      if ( inDmCustomerTabObj.labour_licence_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_date = "+"'"+inDmCustomerTabObj.labour_licence_date+"', ";
      if ( inDmCustomerTabObj.labour_licence_exp_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_exp_date = "+"'"+inDmCustomerTabObj.labour_licence_exp_date+"', ";
      if ( inDmCustomerTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmCustomerTabObj.rec_status+"', ";
      if ( inDmCustomerTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmCustomerTabObj.rec_cre_date+"', ";
      if ( inDmCustomerTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmCustomerTabObj.rec_cre_time+"', ";
      if ( inDmCustomerTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmCustomerTabObj.rec_upd_date+"', ";
      if ( inDmCustomerTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmCustomerTabObj.rec_upd_time+"', ";
      if ( inDmCustomerTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmCustomerTabObj.file_name+"', ";
      if ( inDmCustomerTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmCustomerTabObj.file_cre_date+"', ";
      if ( inDmCustomerTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmCustomerTabObj.file_cre_time+"', ";
      if ( inDmCustomerTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmCustomerTabObj.file_status+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustomerRecByPkey
               ( DmCustomerPkeyObj inDmCustomerPkeyObj
               , DmCustomerTabObj  inDmCustomerTabObj
               )
  {
    int lUpdateCount;
    sop("updDmCustomerRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updDmCustomerRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustomerTabObj.expiration_date != null && inDmCustomerTabObj.expiration_date.length() > 0 ) 
            inDmCustomerTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.effective_date != null && inDmCustomerTabObj.effective_date.length() > 0 ) 
            inDmCustomerTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.business_est_date != null && inDmCustomerTabObj.business_est_date.length() > 0 ) 
            inDmCustomerTabObj.business_est_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.business_est_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.cst_form_date != null && inDmCustomerTabObj.cst_form_date.length() > 0 ) 
            inDmCustomerTabObj.cst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.cst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.lst_form_date != null && inDmCustomerTabObj.lst_form_date.length() > 0 ) 
            inDmCustomerTabObj.lst_form_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.lst_form_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tin_date != null && inDmCustomerTabObj.tin_date.length() > 0 ) 
            inDmCustomerTabObj.tin_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tin_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.pan_date != null && inDmCustomerTabObj.pan_date.length() > 0 ) 
            inDmCustomerTabObj.pan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.pan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.tan_date != null && inDmCustomerTabObj.tan_date.length() > 0 ) 
            inDmCustomerTabObj.tan_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.tan_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.strn_date != null && inDmCustomerTabObj.strn_date.length() > 0 ) 
            inDmCustomerTabObj.strn_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.strn_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_eff_date != null && inDmCustomerTabObj.agreement_eff_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_eff_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_eff_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_exp_date != null && inDmCustomerTabObj.agreement_exp_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_cre_date != null && inDmCustomerTabObj.agreement_cre_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.agreement_sts_date != null && inDmCustomerTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustomerTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_date != null && inDmCustomerTabObj.labour_licence_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.labour_licence_exp_date != null && inDmCustomerTabObj.labour_licence_exp_date.length() > 0 ) 
            inDmCustomerTabObj.labour_licence_exp_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.labour_licence_exp_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_cre_date != null && inDmCustomerTabObj.rec_cre_date.length() > 0 ) 
            inDmCustomerTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.rec_upd_date != null && inDmCustomerTabObj.rec_upd_date.length() > 0 ) 
            inDmCustomerTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustomerTabObj.file_cre_date != null && inDmCustomerTabObj.file_cre_date.length() > 0 ) 
            inDmCustomerTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustomerTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUSTOMER ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inDmCustomerTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inDmCustomerTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = ? , ";
        if ( inDmCustomerTabObj.customer_type != null  )         lSqlStmt = lSqlStmt + "customer_type = ? , ";
        if ( inDmCustomerTabObj.customer_ctg != null  )         lSqlStmt = lSqlStmt + "customer_ctg = ? , ";
        if ( inDmCustomerTabObj.customer_name != null  )         lSqlStmt = lSqlStmt + "customer_name = ? , ";
        if ( inDmCustomerTabObj.customer_group != null  )         lSqlStmt = lSqlStmt + "customer_group = ? , ";
        if ( inDmCustomerTabObj.referred_by != null  )         lSqlStmt = lSqlStmt + "referred_by = ? , ";
               lSqlStmt = lSqlStmt + "turn_over = ? , ";
        if ( inDmCustomerTabObj.business_area_cd != null  )         lSqlStmt = lSqlStmt + "business_area_cd = ? , ";
        if ( inDmCustomerTabObj.state_code != null  )         lSqlStmt = lSqlStmt + "state_code = ? , ";
        if ( inDmCustomerTabObj.region_id != null  )         lSqlStmt = lSqlStmt + "region_id = ? , ";
        if ( inDmCustomerTabObj.country_code != null  )         lSqlStmt = lSqlStmt + "country_code = ? , ";
        if ( inDmCustomerTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inDmCustomerTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = ? , ";
        if ( inDmCustomerTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = ? , ";
        if ( inDmCustomerTabObj.business_type != null  )         lSqlStmt = lSqlStmt + "business_type = ? , ";
        if ( inDmCustomerTabObj.business_est_date != null  )         lSqlStmt = lSqlStmt + "business_est_date = ? , ";
               lSqlStmt = lSqlStmt + "employee_strength = ? , ";
        if ( inDmCustomerTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = ? , ";
        if ( inDmCustomerTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = ? , ";
        if ( inDmCustomerTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = ? , ";
        if ( inDmCustomerTabObj.address_3 != null  )         lSqlStmt = lSqlStmt + "address_3 = ? , ";
        if ( inDmCustomerTabObj.cst_form_num != null  )         lSqlStmt = lSqlStmt + "cst_form_num = ? , ";
        if ( inDmCustomerTabObj.cst_form_date != null  )         lSqlStmt = lSqlStmt + "cst_form_date = ? , ";
        if ( inDmCustomerTabObj.lst_form_num != null  )         lSqlStmt = lSqlStmt + "lst_form_num = ? , ";
        if ( inDmCustomerTabObj.lst_form_date != null  )         lSqlStmt = lSqlStmt + "lst_form_date = ? , ";
        if ( inDmCustomerTabObj.tin_num != null  )         lSqlStmt = lSqlStmt + "tin_num = ? , ";
        if ( inDmCustomerTabObj.tin_date != null  )         lSqlStmt = lSqlStmt + "tin_date = ? , ";
        if ( inDmCustomerTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = ? , ";
        if ( inDmCustomerTabObj.pan_date != null  )         lSqlStmt = lSqlStmt + "pan_date = ? , ";
        if ( inDmCustomerTabObj.tan_num != null  )         lSqlStmt = lSqlStmt + "tan_num = ? , ";
        if ( inDmCustomerTabObj.tan_date != null  )         lSqlStmt = lSqlStmt + "tan_date = ? , ";
        if ( inDmCustomerTabObj.strn_num != null  )         lSqlStmt = lSqlStmt + "strn_num = ? , ";
        if ( inDmCustomerTabObj.strn_date != null  )         lSqlStmt = lSqlStmt + "strn_date = ? , ";
        if ( inDmCustomerTabObj.account_num != null  )         lSqlStmt = lSqlStmt + "account_num = ? , ";
               lSqlStmt = lSqlStmt + "bal_close = ? , ";
               lSqlStmt = lSqlStmt + "bal_open = ? , ";
               lSqlStmt = lSqlStmt + "dr_amt = ? , ";
               lSqlStmt = lSqlStmt + "cr_amt = ? , ";
               lSqlStmt = lSqlStmt + "ar_bal = ? , ";
        if ( inDmCustomerTabObj.sal_cycle_code != null  )         lSqlStmt = lSqlStmt + "sal_cycle_code = ? , ";
        if ( inDmCustomerTabObj.bill_cycle_code != null  )         lSqlStmt = lSqlStmt + "bill_cycle_code = ? , ";
        if ( inDmCustomerTabObj.agreement_id != null  )         lSqlStmt = lSqlStmt + "agreement_id = ? , ";
        if ( inDmCustomerTabObj.agreement_eff_date != null  )         lSqlStmt = lSqlStmt + "agreement_eff_date = ? , ";
        if ( inDmCustomerTabObj.agreement_exp_date != null  )         lSqlStmt = lSqlStmt + "agreement_exp_date = ? , ";
        if ( inDmCustomerTabObj.agreement_cre_date != null  )         lSqlStmt = lSqlStmt + "agreement_cre_date = ? , ";
        if ( inDmCustomerTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = ? , ";
        if ( inDmCustomerTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = ? , ";
        if ( inDmCustomerTabObj.prev_agreement_id != null  )         lSqlStmt = lSqlStmt + "prev_agreement_id = ? , ";
        if ( inDmCustomerTabObj.renew_ind != null  )         lSqlStmt = lSqlStmt + "renew_ind = ? , ";
        if ( inDmCustomerTabObj.cycle_id != null  )         lSqlStmt = lSqlStmt + "cycle_id = ? , ";
        if ( inDmCustomerTabObj.spl_training_ind != null  )         lSqlStmt = lSqlStmt + "spl_training_ind = ? , ";
        if ( inDmCustomerTabObj.spl_uniform_ind != null  )         lSqlStmt = lSqlStmt + "spl_uniform_ind = ? , ";
               lSqlStmt = lSqlStmt + "pay_day = ? , ";
               lSqlStmt = lSqlStmt + "basic = ? , ";
        if ( inDmCustomerTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = ? , ";
               lSqlStmt = lSqlStmt + "pf_rate = ? , ";
        if ( inDmCustomerTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = ? , ";
               lSqlStmt = lSqlStmt + "esi_rate = ? , ";
        if ( inDmCustomerTabObj.da_ind != null  )         lSqlStmt = lSqlStmt + "da_ind = ? , ";
               lSqlStmt = lSqlStmt + "da_rate = ? , ";
        if ( inDmCustomerTabObj.ta_ind != null  )         lSqlStmt = lSqlStmt + "ta_ind = ? , ";
               lSqlStmt = lSqlStmt + "ta_rate = ? , ";
        if ( inDmCustomerTabObj.hra_ind != null  )         lSqlStmt = lSqlStmt + "hra_ind = ? , ";
               lSqlStmt = lSqlStmt + "hra_rate = ? , ";
        if ( inDmCustomerTabObj.staff_wf_ind != null  )         lSqlStmt = lSqlStmt + "staff_wf_ind = ? , ";
               lSqlStmt = lSqlStmt + "staff_wf_rate = ? , ";
        if ( inDmCustomerTabObj.lunch_ind != null  )         lSqlStmt = lSqlStmt + "lunch_ind = ? , ";
               lSqlStmt = lSqlStmt + "lunch_rate = ? , ";
        if ( inDmCustomerTabObj.jurisdiction != null  )         lSqlStmt = lSqlStmt + "jurisdiction = ? , ";
        if ( inDmCustomerTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
        if ( inDmCustomerTabObj.cacnel_remark != null  )         lSqlStmt = lSqlStmt + "cacnel_remark = ? , ";
               lSqlStmt = lSqlStmt + "service_charge = ? , ";
               lSqlStmt = lSqlStmt + "service_tax = ? , ";
        if ( inDmCustomerTabObj.weeken_off_ind != null  )         lSqlStmt = lSqlStmt + "weeken_off_ind = ? , ";
               lSqlStmt = lSqlStmt + "working_days = ? , ";
               lSqlStmt = lSqlStmt + "manpower_qty = ? , ";
               lSqlStmt = lSqlStmt + "work_hour_qty = ? , ";
               lSqlStmt = lSqlStmt + "ot_hour_qty = ? , ";
        if ( inDmCustomerTabObj.labour_licence_ind != null  )         lSqlStmt = lSqlStmt + "labour_licence_ind = ? , ";
        if ( inDmCustomerTabObj.labour_licence_num != null  )         lSqlStmt = lSqlStmt + "labour_licence_num = ? , ";
        if ( inDmCustomerTabObj.labour_licence_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_date = ? , ";
        if ( inDmCustomerTabObj.labour_licence_exp_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_exp_date = ? , ";
        if ( inDmCustomerTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = ? , ";
        if ( inDmCustomerTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inDmCustomerTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inDmCustomerTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inDmCustomerTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inDmCustomerTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = ? , ";
        if ( inDmCustomerTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = ? , ";
        if ( inDmCustomerTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = ? , ";
        if ( inDmCustomerTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inDmCustomerTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmCustomerTabObj.org_id+"', ";
        if ( inDmCustomerTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmCustomerTabObj.customer_id+"', ";
        if ( inDmCustomerTabObj.customer_type != null  )         lSqlStmt = lSqlStmt + "customer_type = "+"'"+inDmCustomerTabObj.customer_type+"', ";
        if ( inDmCustomerTabObj.customer_ctg != null  )         lSqlStmt = lSqlStmt + "customer_ctg = "+"'"+inDmCustomerTabObj.customer_ctg+"', ";
        if ( inDmCustomerTabObj.customer_name != null  )         lSqlStmt = lSqlStmt + "customer_name = "+"'"+inDmCustomerTabObj.customer_name+"', ";
        if ( inDmCustomerTabObj.customer_group != null  )         lSqlStmt = lSqlStmt + "customer_group = "+"'"+inDmCustomerTabObj.customer_group+"', ";
        if ( inDmCustomerTabObj.referred_by != null  )         lSqlStmt = lSqlStmt + "referred_by = "+"'"+inDmCustomerTabObj.referred_by+"', ";
               lSqlStmt = lSqlStmt + "turn_over = "+inDmCustomerTabObj.turn_over+", ";
        if ( inDmCustomerTabObj.business_area_cd != null  )         lSqlStmt = lSqlStmt + "business_area_cd = "+"'"+inDmCustomerTabObj.business_area_cd+"', ";
        if ( inDmCustomerTabObj.state_code != null  )         lSqlStmt = lSqlStmt + "state_code = "+"'"+inDmCustomerTabObj.state_code+"', ";
        if ( inDmCustomerTabObj.region_id != null  )         lSqlStmt = lSqlStmt + "region_id = "+"'"+inDmCustomerTabObj.region_id+"', ";
        if ( inDmCustomerTabObj.country_code != null  )         lSqlStmt = lSqlStmt + "country_code = "+"'"+inDmCustomerTabObj.country_code+"', ";
        if ( inDmCustomerTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inDmCustomerTabObj.status+"', ";
        if ( inDmCustomerTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inDmCustomerTabObj.expiration_date+"', ";
        if ( inDmCustomerTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inDmCustomerTabObj.effective_date+"', ";
        if ( inDmCustomerTabObj.business_type != null  )         lSqlStmt = lSqlStmt + "business_type = "+"'"+inDmCustomerTabObj.business_type+"', ";
        if ( inDmCustomerTabObj.business_est_date != null  )         lSqlStmt = lSqlStmt + "business_est_date = "+"'"+inDmCustomerTabObj.business_est_date+"', ";
               lSqlStmt = lSqlStmt + "employee_strength = "+inDmCustomerTabObj.employee_strength+", ";
        if ( inDmCustomerTabObj.business_currency != null  )         lSqlStmt = lSqlStmt + "business_currency = "+"'"+inDmCustomerTabObj.business_currency+"', ";
        if ( inDmCustomerTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inDmCustomerTabObj.address_1+"', ";
        if ( inDmCustomerTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inDmCustomerTabObj.address_2+"', ";
        if ( inDmCustomerTabObj.address_3 != null  )         lSqlStmt = lSqlStmt + "address_3 = "+"'"+inDmCustomerTabObj.address_3+"', ";
        if ( inDmCustomerTabObj.cst_form_num != null  )         lSqlStmt = lSqlStmt + "cst_form_num = "+"'"+inDmCustomerTabObj.cst_form_num+"', ";
        if ( inDmCustomerTabObj.cst_form_date != null  )         lSqlStmt = lSqlStmt + "cst_form_date = "+"'"+inDmCustomerTabObj.cst_form_date+"', ";
        if ( inDmCustomerTabObj.lst_form_num != null  )         lSqlStmt = lSqlStmt + "lst_form_num = "+"'"+inDmCustomerTabObj.lst_form_num+"', ";
        if ( inDmCustomerTabObj.lst_form_date != null  )         lSqlStmt = lSqlStmt + "lst_form_date = "+"'"+inDmCustomerTabObj.lst_form_date+"', ";
        if ( inDmCustomerTabObj.tin_num != null  )         lSqlStmt = lSqlStmt + "tin_num = "+"'"+inDmCustomerTabObj.tin_num+"', ";
        if ( inDmCustomerTabObj.tin_date != null  )         lSqlStmt = lSqlStmt + "tin_date = "+"'"+inDmCustomerTabObj.tin_date+"', ";
        if ( inDmCustomerTabObj.pan_num != null  )         lSqlStmt = lSqlStmt + "pan_num = "+"'"+inDmCustomerTabObj.pan_num+"', ";
        if ( inDmCustomerTabObj.pan_date != null  )         lSqlStmt = lSqlStmt + "pan_date = "+"'"+inDmCustomerTabObj.pan_date+"', ";
        if ( inDmCustomerTabObj.tan_num != null  )         lSqlStmt = lSqlStmt + "tan_num = "+"'"+inDmCustomerTabObj.tan_num+"', ";
        if ( inDmCustomerTabObj.tan_date != null  )         lSqlStmt = lSqlStmt + "tan_date = "+"'"+inDmCustomerTabObj.tan_date+"', ";
        if ( inDmCustomerTabObj.strn_num != null  )         lSqlStmt = lSqlStmt + "strn_num = "+"'"+inDmCustomerTabObj.strn_num+"', ";
        if ( inDmCustomerTabObj.strn_date != null  )         lSqlStmt = lSqlStmt + "strn_date = "+"'"+inDmCustomerTabObj.strn_date+"', ";
        if ( inDmCustomerTabObj.account_num != null  )         lSqlStmt = lSqlStmt + "account_num = "+"'"+inDmCustomerTabObj.account_num+"', ";
               lSqlStmt = lSqlStmt + "bal_close = "+inDmCustomerTabObj.bal_close+", ";
               lSqlStmt = lSqlStmt + "bal_open = "+inDmCustomerTabObj.bal_open+", ";
               lSqlStmt = lSqlStmt + "dr_amt = "+inDmCustomerTabObj.dr_amt+", ";
               lSqlStmt = lSqlStmt + "cr_amt = "+inDmCustomerTabObj.cr_amt+", ";
               lSqlStmt = lSqlStmt + "ar_bal = "+inDmCustomerTabObj.ar_bal+", ";
        if ( inDmCustomerTabObj.sal_cycle_code != null  )         lSqlStmt = lSqlStmt + "sal_cycle_code = "+"'"+inDmCustomerTabObj.sal_cycle_code+"', ";
        if ( inDmCustomerTabObj.bill_cycle_code != null  )         lSqlStmt = lSqlStmt + "bill_cycle_code = "+"'"+inDmCustomerTabObj.bill_cycle_code+"', ";
        if ( inDmCustomerTabObj.agreement_id != null  )         lSqlStmt = lSqlStmt + "agreement_id = "+"'"+inDmCustomerTabObj.agreement_id+"', ";
        if ( inDmCustomerTabObj.agreement_eff_date != null  )         lSqlStmt = lSqlStmt + "agreement_eff_date = "+"'"+inDmCustomerTabObj.agreement_eff_date+"', ";
        if ( inDmCustomerTabObj.agreement_exp_date != null  )         lSqlStmt = lSqlStmt + "agreement_exp_date = "+"'"+inDmCustomerTabObj.agreement_exp_date+"', ";
        if ( inDmCustomerTabObj.agreement_cre_date != null  )         lSqlStmt = lSqlStmt + "agreement_cre_date = "+"'"+inDmCustomerTabObj.agreement_cre_date+"', ";
        if ( inDmCustomerTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = "+"'"+inDmCustomerTabObj.agreement_sts+"', ";
        if ( inDmCustomerTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = "+"'"+inDmCustomerTabObj.agreement_sts_date+"', ";
        if ( inDmCustomerTabObj.prev_agreement_id != null  )         lSqlStmt = lSqlStmt + "prev_agreement_id = "+"'"+inDmCustomerTabObj.prev_agreement_id+"', ";
        if ( inDmCustomerTabObj.renew_ind != null  )         lSqlStmt = lSqlStmt + "renew_ind = "+"'"+inDmCustomerTabObj.renew_ind+"', ";
        if ( inDmCustomerTabObj.cycle_id != null  )         lSqlStmt = lSqlStmt + "cycle_id = "+"'"+inDmCustomerTabObj.cycle_id+"', ";
        if ( inDmCustomerTabObj.spl_training_ind != null  )         lSqlStmt = lSqlStmt + "spl_training_ind = "+"'"+inDmCustomerTabObj.spl_training_ind+"', ";
        if ( inDmCustomerTabObj.spl_uniform_ind != null  )         lSqlStmt = lSqlStmt + "spl_uniform_ind = "+"'"+inDmCustomerTabObj.spl_uniform_ind+"', ";
               lSqlStmt = lSqlStmt + "pay_day = "+inDmCustomerTabObj.pay_day+", ";
               lSqlStmt = lSqlStmt + "basic = "+inDmCustomerTabObj.basic+", ";
        if ( inDmCustomerTabObj.pf_ind != null  )         lSqlStmt = lSqlStmt + "pf_ind = "+"'"+inDmCustomerTabObj.pf_ind+"', ";
               lSqlStmt = lSqlStmt + "pf_rate = "+inDmCustomerTabObj.pf_rate+", ";
        if ( inDmCustomerTabObj.esi_ind != null  )         lSqlStmt = lSqlStmt + "esi_ind = "+"'"+inDmCustomerTabObj.esi_ind+"', ";
               lSqlStmt = lSqlStmt + "esi_rate = "+inDmCustomerTabObj.esi_rate+", ";
        if ( inDmCustomerTabObj.da_ind != null  )         lSqlStmt = lSqlStmt + "da_ind = "+"'"+inDmCustomerTabObj.da_ind+"', ";
               lSqlStmt = lSqlStmt + "da_rate = "+inDmCustomerTabObj.da_rate+", ";
        if ( inDmCustomerTabObj.ta_ind != null  )         lSqlStmt = lSqlStmt + "ta_ind = "+"'"+inDmCustomerTabObj.ta_ind+"', ";
               lSqlStmt = lSqlStmt + "ta_rate = "+inDmCustomerTabObj.ta_rate+", ";
        if ( inDmCustomerTabObj.hra_ind != null  )         lSqlStmt = lSqlStmt + "hra_ind = "+"'"+inDmCustomerTabObj.hra_ind+"', ";
               lSqlStmt = lSqlStmt + "hra_rate = "+inDmCustomerTabObj.hra_rate+", ";
        if ( inDmCustomerTabObj.staff_wf_ind != null  )         lSqlStmt = lSqlStmt + "staff_wf_ind = "+"'"+inDmCustomerTabObj.staff_wf_ind+"', ";
               lSqlStmt = lSqlStmt + "staff_wf_rate = "+inDmCustomerTabObj.staff_wf_rate+", ";
        if ( inDmCustomerTabObj.lunch_ind != null  )         lSqlStmt = lSqlStmt + "lunch_ind = "+"'"+inDmCustomerTabObj.lunch_ind+"', ";
               lSqlStmt = lSqlStmt + "lunch_rate = "+inDmCustomerTabObj.lunch_rate+", ";
        if ( inDmCustomerTabObj.jurisdiction != null  )         lSqlStmt = lSqlStmt + "jurisdiction = "+"'"+inDmCustomerTabObj.jurisdiction+"', ";
        if ( inDmCustomerTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inDmCustomerTabObj.remark+"', ";
        if ( inDmCustomerTabObj.cacnel_remark != null  )         lSqlStmt = lSqlStmt + "cacnel_remark = "+"'"+inDmCustomerTabObj.cacnel_remark+"', ";
               lSqlStmt = lSqlStmt + "service_charge = "+inDmCustomerTabObj.service_charge+", ";
               lSqlStmt = lSqlStmt + "service_tax = "+inDmCustomerTabObj.service_tax+", ";
        if ( inDmCustomerTabObj.weeken_off_ind != null  )         lSqlStmt = lSqlStmt + "weeken_off_ind = "+"'"+inDmCustomerTabObj.weeken_off_ind+"', ";
               lSqlStmt = lSqlStmt + "working_days = "+inDmCustomerTabObj.working_days+", ";
               lSqlStmt = lSqlStmt + "manpower_qty = "+inDmCustomerTabObj.manpower_qty+", ";
               lSqlStmt = lSqlStmt + "work_hour_qty = "+inDmCustomerTabObj.work_hour_qty+", ";
               lSqlStmt = lSqlStmt + "ot_hour_qty = "+inDmCustomerTabObj.ot_hour_qty+", ";
        if ( inDmCustomerTabObj.labour_licence_ind != null  )         lSqlStmt = lSqlStmt + "labour_licence_ind = "+"'"+inDmCustomerTabObj.labour_licence_ind+"', ";
        if ( inDmCustomerTabObj.labour_licence_num != null  )         lSqlStmt = lSqlStmt + "labour_licence_num = "+"'"+inDmCustomerTabObj.labour_licence_num+"', ";
        if ( inDmCustomerTabObj.labour_licence_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_date = "+"'"+inDmCustomerTabObj.labour_licence_date+"', ";
        if ( inDmCustomerTabObj.labour_licence_exp_date != null  )         lSqlStmt = lSqlStmt + "labour_licence_exp_date = "+"'"+inDmCustomerTabObj.labour_licence_exp_date+"', ";
        if ( inDmCustomerTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmCustomerTabObj.rec_status+"', ";
        if ( inDmCustomerTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmCustomerTabObj.rec_cre_date+"', ";
        if ( inDmCustomerTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmCustomerTabObj.rec_cre_time+"', ";
        if ( inDmCustomerTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmCustomerTabObj.rec_upd_date+"', ";
        if ( inDmCustomerTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmCustomerTabObj.rec_upd_time+"', ";
        if ( inDmCustomerTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmCustomerTabObj.file_name+"', ";
        if ( inDmCustomerTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmCustomerTabObj.file_cre_date+"', ";
        if ( inDmCustomerTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmCustomerTabObj.file_cre_time+"', ";
        if ( inDmCustomerTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmCustomerTabObj.file_status+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmCustomerPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustomerPkeyObj.customer_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inDmCustomerTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.org_id); } 
         if ( inDmCustomerTabObj.customer_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.customer_id); } 
         if ( inDmCustomerTabObj.customer_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.customer_type); } 
         if ( inDmCustomerTabObj.customer_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.customer_ctg); } 
         if ( inDmCustomerTabObj.customer_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.customer_name); } 
         if ( inDmCustomerTabObj.customer_group != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.customer_group); } 
         if ( inDmCustomerTabObj.referred_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.referred_by); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(8, inDmCustomerTabObj.turn_over);
         if ( inDmCustomerTabObj.business_area_cd != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.business_area_cd); } 
         if ( inDmCustomerTabObj.state_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.state_code); } 
         if ( inDmCustomerTabObj.region_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.region_id); } 
         if ( inDmCustomerTabObj.country_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.country_code); } 
         if ( inDmCustomerTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.status); } 
         if ( inDmCustomerTabObj.expiration_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.expiration_date); } 
         if ( inDmCustomerTabObj.effective_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.effective_date); } 
         if ( inDmCustomerTabObj.business_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.business_type); } 
         if ( inDmCustomerTabObj.business_est_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.business_est_date); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(18, inDmCustomerTabObj.employee_strength);
         if ( inDmCustomerTabObj.business_currency != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.business_currency); } 
         if ( inDmCustomerTabObj.address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.address_1); } 
         if ( inDmCustomerTabObj.address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.address_2); } 
         if ( inDmCustomerTabObj.address_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.address_3); } 
         if ( inDmCustomerTabObj.cst_form_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.cst_form_num); } 
         if ( inDmCustomerTabObj.cst_form_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.cst_form_date); } 
         if ( inDmCustomerTabObj.lst_form_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.lst_form_num); } 
         if ( inDmCustomerTabObj.lst_form_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.lst_form_date); } 
         if ( inDmCustomerTabObj.tin_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.tin_num); } 
         if ( inDmCustomerTabObj.tin_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.tin_date); } 
         if ( inDmCustomerTabObj.pan_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.pan_num); } 
         if ( inDmCustomerTabObj.pan_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.pan_date); } 
         if ( inDmCustomerTabObj.tan_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.tan_num); } 
         if ( inDmCustomerTabObj.tan_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.tan_date); } 
         if ( inDmCustomerTabObj.strn_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.strn_num); } 
         if ( inDmCustomerTabObj.strn_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.strn_date); } 
         if ( inDmCustomerTabObj.account_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.account_num); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(36, inDmCustomerTabObj.bal_close);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(37, inDmCustomerTabObj.bal_open);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(38, inDmCustomerTabObj.dr_amt);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(39, inDmCustomerTabObj.cr_amt);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(40, inDmCustomerTabObj.ar_bal);
         if ( inDmCustomerTabObj.sal_cycle_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.sal_cycle_code); } 
         if ( inDmCustomerTabObj.bill_cycle_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.bill_cycle_code); } 
         if ( inDmCustomerTabObj.agreement_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_id); } 
         if ( inDmCustomerTabObj.agreement_eff_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_eff_date); } 
         if ( inDmCustomerTabObj.agreement_exp_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_exp_date); } 
         if ( inDmCustomerTabObj.agreement_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_cre_date); } 
         if ( inDmCustomerTabObj.agreement_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_sts); } 
         if ( inDmCustomerTabObj.agreement_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.agreement_sts_date); } 
         if ( inDmCustomerTabObj.prev_agreement_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.prev_agreement_id); } 
         if ( inDmCustomerTabObj.renew_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.renew_ind); } 
         if ( inDmCustomerTabObj.cycle_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.cycle_id); } 
         if ( inDmCustomerTabObj.spl_training_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.spl_training_ind); } 
         if ( inDmCustomerTabObj.spl_uniform_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.spl_uniform_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(54, inDmCustomerTabObj.pay_day);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(55, inDmCustomerTabObj.basic);
         if ( inDmCustomerTabObj.pf_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.pf_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(57, inDmCustomerTabObj.pf_rate);
         if ( inDmCustomerTabObj.esi_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.esi_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(59, inDmCustomerTabObj.esi_rate);
         if ( inDmCustomerTabObj.da_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.da_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(61, inDmCustomerTabObj.da_rate);
         if ( inDmCustomerTabObj.ta_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.ta_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(63, inDmCustomerTabObj.ta_rate);
         if ( inDmCustomerTabObj.hra_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.hra_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(65, inDmCustomerTabObj.hra_rate);
         if ( inDmCustomerTabObj.staff_wf_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.staff_wf_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(67, inDmCustomerTabObj.staff_wf_rate);
         if ( inDmCustomerTabObj.lunch_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.lunch_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(69, inDmCustomerTabObj.lunch_rate);
         if ( inDmCustomerTabObj.jurisdiction != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.jurisdiction); } 
         if ( inDmCustomerTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.remark); } 
         if ( inDmCustomerTabObj.cacnel_remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.cacnel_remark); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(73, inDmCustomerTabObj.service_charge);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(74, inDmCustomerTabObj.service_tax);
         if ( inDmCustomerTabObj.weeken_off_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.weeken_off_ind); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(76, inDmCustomerTabObj.working_days);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(77, inDmCustomerTabObj.manpower_qty);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(78, inDmCustomerTabObj.work_hour_qty);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(79, inDmCustomerTabObj.ot_hour_qty);
         if ( inDmCustomerTabObj.labour_licence_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.labour_licence_ind); } 
         if ( inDmCustomerTabObj.labour_licence_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.labour_licence_num); } 
         if ( inDmCustomerTabObj.labour_licence_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.labour_licence_date); } 
         if ( inDmCustomerTabObj.labour_licence_exp_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.labour_licence_exp_date); } 
         if ( inDmCustomerTabObj.rec_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.rec_status); } 
         if ( inDmCustomerTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.rec_cre_date); } 
         if ( inDmCustomerTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.rec_cre_time); } 
         if ( inDmCustomerTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.rec_upd_date); } 
         if ( inDmCustomerTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.rec_upd_time); } 
         if ( inDmCustomerTabObj.file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.file_name); } 
         if ( inDmCustomerTabObj.file_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.file_cre_date); } 
         if ( inDmCustomerTabObj.file_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.file_cre_time); } 
         if ( inDmCustomerTabObj.file_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustomerTabObj.file_status); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustomerRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delDmCustomerRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delDmCustomerRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   DM_CUSTOMER "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustomerRecByPkeyWithSet
               ( DmCustomerPkeyObj inDmCustomerPkeyObj
               , String  inDmCustomerSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustomerRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustomerRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUSTOMER ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmCustomerSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmCustomerPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustomerPkeyObj.customer_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustomerRecByRowidWithSet
               ( String inRowId
               , String  inDmCustomerSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustomerRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustomerRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUSTOMER ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmCustomerSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustomerRecByWhereWithSet
               ( String inDmCustomerWhereText
               , String  inDmCustomerSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustomerRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustomerRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUSTOMER ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inDmCustomerSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustomerRecByPkey
               ( DmCustomerPkeyObj  inDmCustomerPkeyObj
               )
  {
    int lUpdateCount;
    sop("delDmCustomerRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delDmCustomerRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   DM_CUSTOMER " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmCustomerPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustomerPkeyObj.customer_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustomerByWhere
               ( String inDmCustomerWhereText
               )
  {
    int lUpdateCount;
    sop("delDmCustomerByWhere - Started");
    gSSTErrorObj.sourceMethod = "delDmCustomerByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustomerWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustomerWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   DM_CUSTOMER "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
