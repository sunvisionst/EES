function DmSrcFileRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("file_id").value  = document.getElementById("file_id"+"_r"+inRecNum).value;
    document.getElementById("file_id").readOnly = true;
    document.getElementById("file_type").value  = document.getElementById("file_type"+"_r"+inRecNum).value;
    document.getElementById("new_file_name").value  = document.getElementById("new_file_name"+"_r"+inRecNum).value;
    document.getElementById("new_file_cre_date").value  = document.getElementById("new_file_cre_date"+"_r"+inRecNum).value;
    document.getElementById("new_file_cre_time").value  = document.getElementById("new_file_cre_time"+"_r"+inRecNum).value;
    document.getElementById("file_status").value  = document.getElementById("file_status"+"_r"+inRecNum).value;
    document.getElementById("orig_file_name").value  = document.getElementById("orig_file_name"+"_r"+inRecNum).value;
    document.getElementById("orig_file_cre_date").value  = document.getElementById("orig_file_cre_date"+"_r"+inRecNum).value;
    document.getElementById("orig_file_cre_time").value  = document.getElementById("orig_file_cre_time"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("file_id").value = '';
    document.getElementById("file_id").readOnly = false;
    document.getElementById("file_type").value = '';
    document.getElementById("new_file_name").value = '';
    document.getElementById("new_file_cre_date").value = '';
    document.getElementById("new_file_cre_time").value = '';
    document.getElementById("file_status").value = '';
    document.getElementById("orig_file_name").value = '';
    document.getElementById("orig_file_cre_date").value = '';
    document.getElementById("orig_file_cre_time").value = '';
  }
}
