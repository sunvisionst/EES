package sstdb.dm.DmSrcFile;


public class DmSrcFilePkeyObj
{
  public String                                 org_id;
  public String                                 file_id;
}