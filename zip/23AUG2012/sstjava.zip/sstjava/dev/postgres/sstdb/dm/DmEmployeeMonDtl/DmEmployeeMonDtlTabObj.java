package sstdb.dm.DmEmployeeMonDtl;


public class DmEmployeeMonDtlTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 employee_id;
  public String                                 allocation_date;
  public String                                 dept_id;
  public String                                 position_id;
  public String                                 level_id;
  public String                                 name_initials;
  public String                                 employee_name;
  public String                                 emp_track_id;
  public byte                                  month_num;
  public float                                 working_days;
  public float                                 absent_days;
  public double                                 wages_rate;
  public double                                 gross_mon_wages;
  public double                                 sh_amt_bas;
  public double                                 sh_amt_da;
  public double                                 sh_amt_hra;
  public double                                 sh_amt_conv;
  public double                                 sh_amt_woff;
  public double                                 sh_amt_shift_alw;
  public double                                 sh_amt_wash_alw;
  public double                                 sh_amt_oth_inc;
  public double                                 sh_amt_pf;
  public double                                 sh_amt_esi;
  public double                                 sh_amt_swf_ded;
  public double                                 sh_amt_oth_ded;
  public double                                 ot_hour;
  public double                                 act_amt_ot;
  public double                                 act_amt_oth_inc;
  public double                                 act_amt_adv;
  public double                                 act_amt_hra;
  public double                                 act_amt_weekoff;
  public double                                 act_amt_washing;
  public double                                 act_amt_areer;
  public double                                 act_amt_shift_alw;
  public double                                 act_amt_medi_alw;
  public double                                 act_amt_convy;
  public double                                 act_amt_insur;
  public double                                 act_amt_dress;
  public double                                 act_amt_swf_ded;
  public double                                 act_amt_gen_fine;
  public double                                 act_amt_pc;
  public double                                 act_amt_sec_ded;
  public double                                 act_amt_oth_ded;
  public double                                 act_amt_adv_ded;
  public String                                 rec_status;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;
  public String                                 file_name;
  public String                                 file_cre_date;
  public String                                 file_cre_time;
  public String                                 file_status;





  public short                                  org_id_ind;
  public short                                  customer_id_ind;
  public short                                  employee_id_ind;
  public short                                  allocation_date_ind;
  public short                                  dept_id_ind;
  public short                                  position_id_ind;
  public short                                  level_id_ind;
  public short                                  name_initials_ind;
  public short                                  employee_name_ind;
  public short                                  emp_track_id_ind;
  public short                                  month_num_ind;
  public short                                  working_days_ind;
  public short                                  absent_days_ind;
  public short                                  wages_rate_ind;
  public short                                  gross_mon_wages_ind;
  public short                                  sh_amt_bas_ind;
  public short                                  sh_amt_da_ind;
  public short                                  sh_amt_hra_ind;
  public short                                  sh_amt_conv_ind;
  public short                                  sh_amt_woff_ind;
  public short                                  sh_amt_shift_alw_ind;
  public short                                  sh_amt_wash_alw_ind;
  public short                                  sh_amt_oth_inc_ind;
  public short                                  sh_amt_pf_ind;
  public short                                  sh_amt_esi_ind;
  public short                                  sh_amt_swf_ded_ind;
  public short                                  sh_amt_oth_ded_ind;
  public short                                  ot_hour_ind;
  public short                                  act_amt_ot_ind;
  public short                                  act_amt_oth_inc_ind;
  public short                                  act_amt_adv_ind;
  public short                                  act_amt_hra_ind;
  public short                                  act_amt_weekoff_ind;
  public short                                  act_amt_washing_ind;
  public short                                  act_amt_areer_ind;
  public short                                  act_amt_shift_alw_ind;
  public short                                  act_amt_medi_alw_ind;
  public short                                  act_amt_convy_ind;
  public short                                  act_amt_insur_ind;
  public short                                  act_amt_dress_ind;
  public short                                  act_amt_swf_ded_ind;
  public short                                  act_amt_gen_fine_ind;
  public short                                  act_amt_pc_ind;
  public short                                  act_amt_sec_ded_ind;
  public short                                  act_amt_oth_ded_ind;
  public short                                  act_amt_adv_ded_ind;
  public short                                  rec_status_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;
  public short                                  file_name_ind;
  public short                                  file_cre_date_ind;
  public short                                  file_cre_time_ind;
  public short                                  file_status_ind;


  public DmEmployeeMonDtlTabObj(){}


  public DmEmployeeMonDtlTabObj
  (
    String org_id,
    String customer_id,
    String employee_id,
    String allocation_date,
    String dept_id,
    String position_id,
    String level_id,
    String name_initials,
    String employee_name,
    String emp_track_id,
    byte month_num,
    float working_days,
    float absent_days,
    double wages_rate,
    double gross_mon_wages,
    double sh_amt_bas,
    double sh_amt_da,
    double sh_amt_hra,
    double sh_amt_conv,
    double sh_amt_woff,
    double sh_amt_shift_alw,
    double sh_amt_wash_alw,
    double sh_amt_oth_inc,
    double sh_amt_pf,
    double sh_amt_esi,
    double sh_amt_swf_ded,
    double sh_amt_oth_ded,
    double ot_hour,
    double act_amt_ot,
    double act_amt_oth_inc,
    double act_amt_adv,
    double act_amt_hra,
    double act_amt_weekoff,
    double act_amt_washing,
    double act_amt_areer,
    double act_amt_shift_alw,
    double act_amt_medi_alw,
    double act_amt_convy,
    double act_amt_insur,
    double act_amt_dress,
    double act_amt_swf_ded,
    double act_amt_gen_fine,
    double act_amt_pc,
    double act_amt_sec_ded,
    double act_amt_oth_ded,
    double act_amt_adv_ded,
    String rec_status,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_date,
    String rec_upd_time,
    String file_name,
    String file_cre_date,
    String file_cre_time,
    String file_status
  )
  {
     this.org_id = org_id;
     this.customer_id = customer_id;
     this.employee_id = employee_id;
     this.allocation_date = allocation_date;
     this.dept_id = dept_id;
     this.position_id = position_id;
     this.level_id = level_id;
     this.name_initials = name_initials;
     this.employee_name = employee_name;
     this.emp_track_id = emp_track_id;
     this.month_num = month_num;
     this.working_days = working_days;
     this.absent_days = absent_days;
     this.wages_rate = wages_rate;
     this.gross_mon_wages = gross_mon_wages;
     this.sh_amt_bas = sh_amt_bas;
     this.sh_amt_da = sh_amt_da;
     this.sh_amt_hra = sh_amt_hra;
     this.sh_amt_conv = sh_amt_conv;
     this.sh_amt_woff = sh_amt_woff;
     this.sh_amt_shift_alw = sh_amt_shift_alw;
     this.sh_amt_wash_alw = sh_amt_wash_alw;
     this.sh_amt_oth_inc = sh_amt_oth_inc;
     this.sh_amt_pf = sh_amt_pf;
     this.sh_amt_esi = sh_amt_esi;
     this.sh_amt_swf_ded = sh_amt_swf_ded;
     this.sh_amt_oth_ded = sh_amt_oth_ded;
     this.ot_hour = ot_hour;
     this.act_amt_ot = act_amt_ot;
     this.act_amt_oth_inc = act_amt_oth_inc;
     this.act_amt_adv = act_amt_adv;
     this.act_amt_hra = act_amt_hra;
     this.act_amt_weekoff = act_amt_weekoff;
     this.act_amt_washing = act_amt_washing;
     this.act_amt_areer = act_amt_areer;
     this.act_amt_shift_alw = act_amt_shift_alw;
     this.act_amt_medi_alw = act_amt_medi_alw;
     this.act_amt_convy = act_amt_convy;
     this.act_amt_insur = act_amt_insur;
     this.act_amt_dress = act_amt_dress;
     this.act_amt_swf_ded = act_amt_swf_ded;
     this.act_amt_gen_fine = act_amt_gen_fine;
     this.act_amt_pc = act_amt_pc;
     this.act_amt_sec_ded = act_amt_sec_ded;
     this.act_amt_oth_ded = act_amt_oth_ded;
     this.act_amt_adv_ded = act_amt_adv_ded;
     this.rec_status = rec_status;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
     this.file_name = file_name;
     this.file_cre_date = file_cre_date;
     this.file_cre_time = file_cre_time;
     this.file_status = file_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getcustomer_id()                        { return customer_id; }
  public String getemployee_id()                        { return employee_id; }
  public String getallocation_date()                      { return allocation_date; }
  public String getdept_id()                          { return dept_id; }
  public String getposition_id()                        { return position_id; }
  public String getlevel_id()                          { return level_id; }
  public String getname_initials()                       { return name_initials; }
  public String getemployee_name()                       { return employee_name; }
  public String getemp_track_id()                        { return emp_track_id; }
  public byte getmonth_num()                          { return month_num; }
  public float getworking_days()                        { return working_days; }
  public float getabsent_days()                         { return absent_days; }
  public double getwages_rate()                         { return wages_rate; }
  public double getgross_mon_wages()                      { return gross_mon_wages; }
  public double getsh_amt_bas()                         { return sh_amt_bas; }
  public double getsh_amt_da()                         { return sh_amt_da; }
  public double getsh_amt_hra()                         { return sh_amt_hra; }
  public double getsh_amt_conv()                        { return sh_amt_conv; }
  public double getsh_amt_woff()                        { return sh_amt_woff; }
  public double getsh_amt_shift_alw()                      { return sh_amt_shift_alw; }
  public double getsh_amt_wash_alw()                      { return sh_amt_wash_alw; }
  public double getsh_amt_oth_inc()                       { return sh_amt_oth_inc; }
  public double getsh_amt_pf()                         { return sh_amt_pf; }
  public double getsh_amt_esi()                         { return sh_amt_esi; }
  public double getsh_amt_swf_ded()                       { return sh_amt_swf_ded; }
  public double getsh_amt_oth_ded()                       { return sh_amt_oth_ded; }
  public double getot_hour()                          { return ot_hour; }
  public double getact_amt_ot()                         { return act_amt_ot; }
  public double getact_amt_oth_inc()                      { return act_amt_oth_inc; }
  public double getact_amt_adv()                        { return act_amt_adv; }
  public double getact_amt_hra()                        { return act_amt_hra; }
  public double getact_amt_weekoff()                      { return act_amt_weekoff; }
  public double getact_amt_washing()                      { return act_amt_washing; }
  public double getact_amt_areer()                       { return act_amt_areer; }
  public double getact_amt_shift_alw()                     { return act_amt_shift_alw; }
  public double getact_amt_medi_alw()                      { return act_amt_medi_alw; }
  public double getact_amt_convy()                       { return act_amt_convy; }
  public double getact_amt_insur()                       { return act_amt_insur; }
  public double getact_amt_dress()                       { return act_amt_dress; }
  public double getact_amt_swf_ded()                      { return act_amt_swf_ded; }
  public double getact_amt_gen_fine()                      { return act_amt_gen_fine; }
  public double getact_amt_pc()                         { return act_amt_pc; }
  public double getact_amt_sec_ded()                      { return act_amt_sec_ded; }
  public double getact_amt_oth_ded()                      { return act_amt_oth_ded; }
  public double getact_amt_adv_ded()                      { return act_amt_adv_ded; }
  public String getrec_status()                         { return rec_status; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }
  public String getfile_name()                         { return file_name; }
  public String getfile_cre_date()                       { return file_cre_date; }
  public String getfile_cre_time()                       { return file_cre_time; }
  public String getfile_status()                        { return file_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcustomer_id(String customer_id )               { this.customer_id = customer_id; }
  public void  setemployee_id(String employee_id )               { this.employee_id = employee_id; }
  public void  setallocation_date(String allocation_date )           { this.allocation_date = allocation_date; }
  public void  setdept_id(String dept_id )                   { this.dept_id = dept_id; }
  public void  setposition_id(String position_id )               { this.position_id = position_id; }
  public void  setlevel_id(String level_id )                  { this.level_id = level_id; }
  public void  setname_initials(String name_initials )             { this.name_initials = name_initials; }
  public void  setemployee_name(String employee_name )             { this.employee_name = employee_name; }
  public void  setemp_track_id(String emp_track_id )              { this.emp_track_id = emp_track_id; }
  public void  setmonth_num(byte month_num )                  { this.month_num = month_num; }
  public void  setworking_days(float working_days )               { this.working_days = working_days; }
  public void  setabsent_days(float absent_days )                { this.absent_days = absent_days; }
  public void  setwages_rate(double wages_rate )                { this.wages_rate = wages_rate; }
  public void  setgross_mon_wages(double gross_mon_wages )           { this.gross_mon_wages = gross_mon_wages; }
  public void  setsh_amt_bas(double sh_amt_bas )                { this.sh_amt_bas = sh_amt_bas; }
  public void  setsh_amt_da(double sh_amt_da )                 { this.sh_amt_da = sh_amt_da; }
  public void  setsh_amt_hra(double sh_amt_hra )                { this.sh_amt_hra = sh_amt_hra; }
  public void  setsh_amt_conv(double sh_amt_conv )               { this.sh_amt_conv = sh_amt_conv; }
  public void  setsh_amt_woff(double sh_amt_woff )               { this.sh_amt_woff = sh_amt_woff; }
  public void  setsh_amt_shift_alw(double sh_amt_shift_alw )          { this.sh_amt_shift_alw = sh_amt_shift_alw; }
  public void  setsh_amt_wash_alw(double sh_amt_wash_alw )           { this.sh_amt_wash_alw = sh_amt_wash_alw; }
  public void  setsh_amt_oth_inc(double sh_amt_oth_inc )            { this.sh_amt_oth_inc = sh_amt_oth_inc; }
  public void  setsh_amt_pf(double sh_amt_pf )                 { this.sh_amt_pf = sh_amt_pf; }
  public void  setsh_amt_esi(double sh_amt_esi )                { this.sh_amt_esi = sh_amt_esi; }
  public void  setsh_amt_swf_ded(double sh_amt_swf_ded )            { this.sh_amt_swf_ded = sh_amt_swf_ded; }
  public void  setsh_amt_oth_ded(double sh_amt_oth_ded )            { this.sh_amt_oth_ded = sh_amt_oth_ded; }
  public void  setot_hour(double ot_hour )                   { this.ot_hour = ot_hour; }
  public void  setact_amt_ot(double act_amt_ot )                { this.act_amt_ot = act_amt_ot; }
  public void  setact_amt_oth_inc(double act_amt_oth_inc )           { this.act_amt_oth_inc = act_amt_oth_inc; }
  public void  setact_amt_adv(double act_amt_adv )               { this.act_amt_adv = act_amt_adv; }
  public void  setact_amt_hra(double act_amt_hra )               { this.act_amt_hra = act_amt_hra; }
  public void  setact_amt_weekoff(double act_amt_weekoff )           { this.act_amt_weekoff = act_amt_weekoff; }
  public void  setact_amt_washing(double act_amt_washing )           { this.act_amt_washing = act_amt_washing; }
  public void  setact_amt_areer(double act_amt_areer )             { this.act_amt_areer = act_amt_areer; }
  public void  setact_amt_shift_alw(double act_amt_shift_alw )         { this.act_amt_shift_alw = act_amt_shift_alw; }
  public void  setact_amt_medi_alw(double act_amt_medi_alw )          { this.act_amt_medi_alw = act_amt_medi_alw; }
  public void  setact_amt_convy(double act_amt_convy )             { this.act_amt_convy = act_amt_convy; }
  public void  setact_amt_insur(double act_amt_insur )             { this.act_amt_insur = act_amt_insur; }
  public void  setact_amt_dress(double act_amt_dress )             { this.act_amt_dress = act_amt_dress; }
  public void  setact_amt_swf_ded(double act_amt_swf_ded )           { this.act_amt_swf_ded = act_amt_swf_ded; }
  public void  setact_amt_gen_fine(double act_amt_gen_fine )          { this.act_amt_gen_fine = act_amt_gen_fine; }
  public void  setact_amt_pc(double act_amt_pc )                { this.act_amt_pc = act_amt_pc; }
  public void  setact_amt_sec_ded(double act_amt_sec_ded )           { this.act_amt_sec_ded = act_amt_sec_ded; }
  public void  setact_amt_oth_ded(double act_amt_oth_ded )           { this.act_amt_oth_ded = act_amt_oth_ded; }
  public void  setact_amt_adv_ded(double act_amt_adv_ded )           { this.act_amt_adv_ded = act_amt_adv_ded; }
  public void  setrec_status(String rec_status )                { this.rec_status = rec_status; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
  public void  setfile_name(String file_name )                 { this.file_name = file_name; }
  public void  setfile_cre_date(String file_cre_date )             { this.file_cre_date = file_cre_date; }
  public void  setfile_cre_time(String file_cre_time )             { this.file_cre_time = file_cre_time; }
  public void  setfile_status(String file_status )               { this.file_status = file_status; }
}