package sstdb.dm.DmEmployee;


public class DmEmployeePkeyObj
{
  public String                                 org_id;
  public String                                 customer_id;
  public String                                 employee_id;
  public String                                 allocation_date;
}