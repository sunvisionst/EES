ALTER TABLE           DM_SRC_FILE
  ADD                 CONSTRAINT DM_SRC_FILE_PK
  PRIMARY             KEY
  ( ORG_ID, FILE_ID )
;
