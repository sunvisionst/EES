
var lDmCustAgreementTabObjJSArr = new Array();
<%
{
   if ( lDmCustAgreementTabObjArrCache != null && lDmCustAgreementTabObjArrCache.size() > 0 )
   {
%>
       lDmCustAgreementTabObjJSArr = new Array(<%=lDmCustAgreementTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lDmCustAgreementTabObjArrCache.size(); lRecNum++ )
       {
          DmCustAgreementTabObj lDmCustAgreementTabObj    =    new DmCustAgreementTabObj();
          lDmCustAgreementTabObj = (DmCustAgreementTabObj)lDmCustAgreementTabObjArrCache.get(lRecNum);
%>
          lDmCustAgreementTabObjJSArr[<%=lRecNum%>] = new constructorDmCustAgreement
          (
          "<%=lDmCustAgreementTabObj.org_id%>",
          "<%=lDmCustAgreementTabObj.customer_id%>",
          "<%=lDmCustAgreementTabObj.rp_id%>",
          "<%=lDmCustAgreementTabObj.allowance_id%>",
          "<%=lDmCustAgreementTabObj.dept_id%>",
          "<%=lDmCustAgreementTabObj.position_id%>",
          "<%=lDmCustAgreementTabObj.level_id%>",
          "<%=lDmCustAgreementTabObj.seq_num%>",
          "<%=lDmCustAgreementTabObj.benefit_flag%>",
          "<%=lDmCustAgreementTabObj.allowance_type%>",
          "<%=lDmCustAgreementTabObj.amount_flag%>",
          "<%=lDmCustAgreementTabObj.default_amount%>",
          "<%=lDmCustAgreementTabObj.billing_charge%>",
          "<%=lDmCustAgreementTabObj.paying_charge%>",
          "<%=lDmCustAgreementTabObj.vacation_code%>",
          "<%=lDmCustAgreementTabObj.leave_quota%>",
          "<%=lDmCustAgreementTabObj.salary_flag%>",
          "<%=lDmCustAgreementTabObj.active_flag%>",
          "<%=lDmCustAgreementTabObj.tax_flag%>",
          "<%=lDmCustAgreementTabObj.tax_percent%>",
          "<%=lDmCustAgreementTabObj.sal_deduction_flag%>",
          "<%=lDmCustAgreementTabObj.remark%>",
          "<%=lDmCustAgreementTabObj.agreement_sts%>",
          "<%=lDmCustAgreementTabObj.agreement_sts_date%>",
          "<%=lDmCustAgreementTabObj.effective_date%>",
          "<%=lDmCustAgreementTabObj.expiration_date%>",
          "<%=lDmCustAgreementTabObj.wages_print_ind%>",
          "<%=lDmCustAgreementTabObj.wages_tot_calc_ind%>",
          "<%=lDmCustAgreementTabObj.rec_status%>",
          "<%=lDmCustAgreementTabObj.rec_cre_date%>",
          "<%=lDmCustAgreementTabObj.rec_cre_time%>",
          "<%=lDmCustAgreementTabObj.rec_upd_date%>",
          "<%=lDmCustAgreementTabObj.rec_upd_time%>",
          "<%=lDmCustAgreementTabObj.file_name%>",
          "<%=lDmCustAgreementTabObj.file_cre_date%>",
          "<%=lDmCustAgreementTabObj.file_cre_time%>",
          "<%=lDmCustAgreementTabObj.file_status%>"
          );
<%
       }
   }
}
%>


