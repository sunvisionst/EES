ALTER TABLE           DM_CUSTOMER
  ADD                 CONSTRAINT DM_CUSTOMER_PK
  PRIMARY             KEY
  ( ORG_ID, CUSTOMER_ID )
;
