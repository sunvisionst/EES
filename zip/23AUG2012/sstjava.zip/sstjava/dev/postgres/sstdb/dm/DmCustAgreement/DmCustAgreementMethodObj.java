package sstdb.dm.DmCustAgreement;

import sstdb.dm.DmCustAgreement.DmCustAgreementTabObj;
import sstdb.dm.DmCustAgreement.DmCustAgreementPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class DmCustAgreementMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public DmCustAgreementMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "DmCustAgreementMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initDmCustAgreementTabObj
               ( 
                 DmCustAgreementTabObj  outDmCustAgreementTabObj
               )
  {
  
     outDmCustAgreementTabObj.org_id = ""; 
     outDmCustAgreementTabObj.customer_id = ""; 
     outDmCustAgreementTabObj.rp_id = ""; 
     outDmCustAgreementTabObj.allowance_id = ""; 
     outDmCustAgreementTabObj.dept_id = ""; 
     outDmCustAgreementTabObj.position_id = ""; 
     outDmCustAgreementTabObj.level_id = ""; 
     outDmCustAgreementTabObj.seq_num = (int)0; 
     outDmCustAgreementTabObj.benefit_flag = ""; 
     outDmCustAgreementTabObj.allowance_type = ""; 
     outDmCustAgreementTabObj.amount_flag = ""; 
     outDmCustAgreementTabObj.default_amount = (double)0.00; 
     outDmCustAgreementTabObj.billing_charge = (double)0.00; 
     outDmCustAgreementTabObj.paying_charge = (double)0.00; 
     outDmCustAgreementTabObj.vacation_code = ""; 
     outDmCustAgreementTabObj.leave_quota = (int)0; 
     outDmCustAgreementTabObj.salary_flag = ""; 
     outDmCustAgreementTabObj.active_flag = ""; 
     outDmCustAgreementTabObj.tax_flag = ""; 
     outDmCustAgreementTabObj.tax_percent = (float)0.00; 
     outDmCustAgreementTabObj.sal_deduction_flag = ""; 
     outDmCustAgreementTabObj.remark = ""; 
     outDmCustAgreementTabObj.agreement_sts = ""; 
     outDmCustAgreementTabObj.agreement_sts_date = ""; 
     outDmCustAgreementTabObj.effective_date = ""; 
     outDmCustAgreementTabObj.expiration_date = ""; 
     outDmCustAgreementTabObj.wages_print_ind = ""; 
     outDmCustAgreementTabObj.wages_tot_calc_ind = ""; 
     outDmCustAgreementTabObj.rec_status = ""; 
     outDmCustAgreementTabObj.rec_cre_date = ""; 
     outDmCustAgreementTabObj.rec_cre_time = ""; 
     outDmCustAgreementTabObj.rec_upd_date = ""; 
     outDmCustAgreementTabObj.rec_upd_time = ""; 
     outDmCustAgreementTabObj.file_name = ""; 
     outDmCustAgreementTabObj.file_cre_date = ""; 
     outDmCustAgreementTabObj.file_cre_time = ""; 
     outDmCustAgreementTabObj.file_status = ""; 
  }





  public void guiDateConvDmCustAgreementTabObj
               ( 
                 DmCustAgreementTabObj  inDmCustAgreementTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inDmCustAgreementTabObj.agreement_sts_date != null && inDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);

          if ( inDmCustAgreementTabObj.effective_date != null && inDmCustAgreementTabObj.effective_date.length() > 0 ) 
            inDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);

          if ( inDmCustAgreementTabObj.expiration_date != null && inDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            inDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);

          if ( inDmCustAgreementTabObj.rec_cre_date != null && inDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inDmCustAgreementTabObj.rec_upd_date != null && inDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);

          if ( inDmCustAgreementTabObj.file_cre_date != null && inDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
  }





  public void refreshCtxDmCustAgreementByTabObj
               ( 
                 DmCustAgreementTabObj  inDmCustAgreementTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lDmCustAgreementTabObjArrCtx  = new ArrayList(); 
    lDmCustAgreementTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lDmCustAgreementTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lDmCustAgreementTabObjArrCtx.add(inDmCustAgreementTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lDmCustAgreementTabObjArrCtx.size();  lRecNum++ )
      {
        DmCustAgreementTabObj lDmCustAgreementTabObj = new DmCustAgreementTabObj();
        lDmCustAgreementTabObj = (DmCustAgreementTabObj)lDmCustAgreementTabObjArrCtx.get(lRecNum);
    
        if ( 
              lDmCustAgreementTabObj.org_id.equals(lDmCustAgreementTabObj.org_id) &&
              lDmCustAgreementTabObj.customer_id.equals(lDmCustAgreementTabObj.customer_id) &&
              lDmCustAgreementTabObj.rp_id.equals(lDmCustAgreementTabObj.rp_id) &&
              lDmCustAgreementTabObj.allowance_id.equals(lDmCustAgreementTabObj.allowance_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lDmCustAgreementTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lDmCustAgreementTabObjArrCtx.set(lRecNum, inDmCustAgreementTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lDmCustAgreementTabObjArrCtx",lDmCustAgreementTabObjArrCtx);
  }





  public void sortDmCustAgreementTabObjArr
               ( 
                 ArrayList  inDmCustAgreementTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lDmCustAgreementTabObjArr  = new ArrayList(); 
     lDmCustAgreementTabObjArr = inDmCustAgreementTabObjArr; 
     List lDmCustAgreementTabObjList  = new ArrayList(lDmCustAgreementTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lDmCustAgreementTabObjArr.size();  lRecNum++ )
     {
       DmCustAgreementTabObj  lDmCustAgreementTabObj = new DmCustAgreementTabObj(); 
       lDmCustAgreementTabObj = (DmCustAgreementTabObj)lDmCustAgreementTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("customer_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.customer_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.customer_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rp_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.rp_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rp_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allowance_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.allowance_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.allowance_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dept_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.dept_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.dept_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("position_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.position_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.position_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("level_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.level_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.level_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("seq_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustAgreementTabObj.seq_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.seq_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("benefit_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.benefit_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.benefit_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allowance_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmCustAgreementTabObj.allowance_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.allowance_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("amount_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.amount_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.amount_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("default_amount") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustAgreementTabObj.default_amount).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.default_amount+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("billing_charge") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustAgreementTabObj.billing_charge).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.billing_charge+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("paying_charge") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lDmCustAgreementTabObj.paying_charge).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.paying_charge+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("vacation_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.vacation_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.vacation_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("leave_quota") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lDmCustAgreementTabObj.leave_quota).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.leave_quota+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("salary_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmCustAgreementTabObj.salary_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.salary_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("active_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.active_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.active_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tax_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.tax_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.tax_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("tax_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - Float.toString(lDmCustAgreementTabObj.tax_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.tax_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sal_deduction_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.sal_deduction_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.sal_deduction_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lDmCustAgreementTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.agreement_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.agreement_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("agreement_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.agreement_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.agreement_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("effective_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.effective_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.effective_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("expiration_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.expiration_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.expiration_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("wages_print_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.wages_print_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.wages_print_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("wages_tot_calc_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lDmCustAgreementTabObj.wages_tot_calc_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.wages_tot_calc_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lDmCustAgreementTabObj.rec_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rec_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustAgreementTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustAgreementTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.rec_upd_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lDmCustAgreementTabObj.file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lDmCustAgreementTabObj.file_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.file_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lDmCustAgreementTabObj.file_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.file_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("file_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lDmCustAgreementTabObj.file_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lDmCustAgreementTabObj.file_status+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lDmCustAgreementTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lDmCustAgreementTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lDmCustAgreementTabObjList ); 
     ArrayList lDmCustAgreementTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lDmCustAgreementTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lDmCustAgreementTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lDmCustAgreementTabObjArrSorted.add( (DmCustAgreementTabObj)lDmCustAgreementTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lDmCustAgreementTabObjArr.size();  lRecNum++ )
     {
       inDmCustAgreementTabObjArr.set( lRecNum, (DmCustAgreementTabObj)lDmCustAgreementTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvDmCustAgreementTabObj
               ( 
                 DmCustAgreementTabObj  inDmCustAgreementTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inDmCustAgreementTabObj.agreement_sts_date != null && inDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.effective_date != null && inDmCustAgreementTabObj.effective_date.length() > 0 ) 
            inDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.expiration_date != null && inDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            inDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_cre_date != null && inDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_upd_date != null && inDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.file_cre_date != null && inDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.file_cre_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCustomerId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CUSTOMER_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRpId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RP_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllowanceId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLOWANCE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDeptId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DEPT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePositionId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "POSITION_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLevelId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LEVEL_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSeqNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SEQ_NUM";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBenefitFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BENEFIT_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllowanceType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLOWANCE_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAmountFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AMOUNT_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDefaultAmount
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DEFAULT_AMOUNT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBillingCharge
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BILLING_CHARGE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePayingCharge
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAYING_CHARGE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeVacationCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "VACATION_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLeaveQuota
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LEAVE_QUOTA";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSalaryFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SALARY_FLAG";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeActiveFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACTIVE_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTaxFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TAX_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTaxPercent
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TAX_PERCENT";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSalDeductionFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SAL_DEDUCTION_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgreementStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGREEMENT_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEffectiveDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EFFECTIVE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExpirationDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXPIRATION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWagesPrintInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WAGES_PRINT_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWagesTotCalcInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WAGES_TOT_CALC_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFileStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FILE_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtDmCustAgreementCount
               ( String inDmCustAgreementWhereText
               )
  {
    sop("gtDmCustAgreementCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementCount
               ( String inDmCustAgreementWhereText
               , String inDmCustAgreementSelectFieldList
               )
  {
    sop("gtDmCustAgreementCount - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inDmCustAgreementSelectFieldList+" AS count "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementRecByPkey
               ( DmCustAgreementPkeyObj inDmCustAgreementPkeyObj
               , DmCustAgreementTabObj  outDmCustAgreementTabObj
               )
  {
    sop("gtDmCustAgreementRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "rp_id, "+
                                 "allowance_id, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "seq_num, "+
                                 "benefit_flag, "+
                                 "allowance_type, "+
                                 "amount_flag, "+
                                 "default_amount, "+
                                 "billing_charge, "+
                                 "paying_charge, "+
                                 "vacation_code, "+
                                 "leave_quota, "+
                                 "salary_flag, "+
                                 "active_flag, "+
                                 "tax_flag, "+
                                 "tax_percent, "+
                                 "sal_deduction_flag, "+
                                 "remark, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "wages_print_ind, "+
                                 "wages_tot_calc_ind, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUST_AGREEMENT " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmCustAgreementPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustAgreementPkeyObj.customer_id+"' and "+
                              "rp_id = "+"'"+inDmCustAgreementPkeyObj.rp_id+"' and "+
                              "allowance_id = "+"'"+inDmCustAgreementPkeyObj.allowance_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outDmCustAgreementTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmCustAgreementTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmCustAgreementTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmCustAgreementTabObj.rp_id  =  lResultSet.getString("RP_ID");
          outDmCustAgreementTabObj.allowance_id  =  lResultSet.getString("ALLOWANCE_ID");
          outDmCustAgreementTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmCustAgreementTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmCustAgreementTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmCustAgreementTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          outDmCustAgreementTabObj.benefit_flag  =  lResultSet.getString("BENEFIT_FLAG");
          outDmCustAgreementTabObj.allowance_type  =  lResultSet.getString("ALLOWANCE_TYPE");
          outDmCustAgreementTabObj.amount_flag  =  lResultSet.getString("AMOUNT_FLAG");
          outDmCustAgreementTabObj.default_amount  =  lResultSet.getDouble("DEFAULT_AMOUNT");
          outDmCustAgreementTabObj.billing_charge  =  lResultSet.getDouble("BILLING_CHARGE");
          outDmCustAgreementTabObj.paying_charge  =  lResultSet.getDouble("PAYING_CHARGE");
          outDmCustAgreementTabObj.vacation_code  =  lResultSet.getString("VACATION_CODE");
          outDmCustAgreementTabObj.leave_quota  =  lResultSet.getInt("LEAVE_QUOTA");
          outDmCustAgreementTabObj.salary_flag  =  lResultSet.getString("SALARY_FLAG");
          outDmCustAgreementTabObj.active_flag  =  lResultSet.getString("ACTIVE_FLAG");
          outDmCustAgreementTabObj.tax_flag  =  lResultSet.getString("TAX_FLAG");
          outDmCustAgreementTabObj.tax_percent  =  lResultSet.getFloat("TAX_PERCENT");
          outDmCustAgreementTabObj.sal_deduction_flag  =  lResultSet.getString("SAL_DEDUCTION_FLAG");
          outDmCustAgreementTabObj.remark  =  lResultSet.getString("REMARK");
          outDmCustAgreementTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          outDmCustAgreementTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( outDmCustAgreementTabObj.agreement_sts_date != null && outDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            outDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outDmCustAgreementTabObj.effective_date != null && outDmCustAgreementTabObj.effective_date.length() > 0 ) 
            outDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outDmCustAgreementTabObj.expiration_date != null && outDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            outDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.wages_print_ind  =  lResultSet.getString("WAGES_PRINT_IND");
          outDmCustAgreementTabObj.wages_tot_calc_ind  =  lResultSet.getString("WAGES_TOT_CALC_IND");
          outDmCustAgreementTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmCustAgreementTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmCustAgreementTabObj.rec_cre_date != null && outDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            outDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmCustAgreementTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmCustAgreementTabObj.rec_upd_date != null && outDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            outDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmCustAgreementTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmCustAgreementTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmCustAgreementTabObj.file_cre_date != null && outDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            outDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmCustAgreementTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmCustAgreementTabObj( outDmCustAgreementTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementArr
               ( DmCustAgreementPkeyObj inDmCustAgreementPkeyObj
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {
    sop("gtDmCustAgreementArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "rp_id, "+
                                 "allowance_id, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "seq_num, "+
                                 "benefit_flag, "+
                                 "allowance_type, "+
                                 "amount_flag, "+
                                 "default_amount, "+
                                 "billing_charge, "+
                                 "paying_charge, "+
                                 "vacation_code, "+
                                 "leave_quota, "+
                                 "salary_flag, "+
                                 "active_flag, "+
                                 "tax_flag, "+
                                 "tax_percent, "+
                                 "sal_deduction_flag, "+
                                 "remark, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "wages_print_ind, "+
                                 "wages_tot_calc_ind, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUST_AGREEMENT";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmCustAgreementTabObj  lDmCustAgreementTabObj = new DmCustAgreementTabObj();
          lDmCustAgreementTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lDmCustAgreementTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmCustAgreementTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmCustAgreementTabObj.rp_id  =  lResultSet.getString("RP_ID");
          lDmCustAgreementTabObj.allowance_id  =  lResultSet.getString("ALLOWANCE_ID");
          lDmCustAgreementTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmCustAgreementTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmCustAgreementTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmCustAgreementTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          lDmCustAgreementTabObj.benefit_flag  =  lResultSet.getString("BENEFIT_FLAG");
          lDmCustAgreementTabObj.allowance_type  =  lResultSet.getString("ALLOWANCE_TYPE");
          lDmCustAgreementTabObj.amount_flag  =  lResultSet.getString("AMOUNT_FLAG");
          lDmCustAgreementTabObj.default_amount  =  lResultSet.getDouble("DEFAULT_AMOUNT");
          lDmCustAgreementTabObj.billing_charge  =  lResultSet.getDouble("BILLING_CHARGE");
          lDmCustAgreementTabObj.paying_charge  =  lResultSet.getDouble("PAYING_CHARGE");
          lDmCustAgreementTabObj.vacation_code  =  lResultSet.getString("VACATION_CODE");
          lDmCustAgreementTabObj.leave_quota  =  lResultSet.getInt("LEAVE_QUOTA");
          lDmCustAgreementTabObj.salary_flag  =  lResultSet.getString("SALARY_FLAG");
          lDmCustAgreementTabObj.active_flag  =  lResultSet.getString("ACTIVE_FLAG");
          lDmCustAgreementTabObj.tax_flag  =  lResultSet.getString("TAX_FLAG");
          lDmCustAgreementTabObj.tax_percent  =  lResultSet.getFloat("TAX_PERCENT");
          lDmCustAgreementTabObj.sal_deduction_flag  =  lResultSet.getString("SAL_DEDUCTION_FLAG");
          lDmCustAgreementTabObj.remark  =  lResultSet.getString("REMARK");
          lDmCustAgreementTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          lDmCustAgreementTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( lDmCustAgreementTabObj.agreement_sts_date != null && lDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lDmCustAgreementTabObj.effective_date != null && lDmCustAgreementTabObj.effective_date.length() > 0 ) 
            lDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lDmCustAgreementTabObj.expiration_date != null && lDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            lDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.wages_print_ind  =  lResultSet.getString("WAGES_PRINT_IND");
          lDmCustAgreementTabObj.wages_tot_calc_ind  =  lResultSet.getString("WAGES_TOT_CALC_IND");
          lDmCustAgreementTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmCustAgreementTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmCustAgreementTabObj.rec_cre_date != null && lDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmCustAgreementTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmCustAgreementTabObj.rec_upd_date != null && lDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmCustAgreementTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmCustAgreementTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmCustAgreementTabObj.file_cre_date != null && lDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmCustAgreementTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmCustAgreementTabObj( lDmCustAgreementTabObj );

          outDmCustAgreementTabObjArr.add(  lDmCustAgreementTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustAgreementTabObjArr != null && outDmCustAgreementTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtDmCustAgreementArr2XML
               ( String inDmCustAgreementWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtDmCustAgreementArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<DmCustAgreement>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("customer_id") )
              lXmlBuffer = lXmlBuffer +   "<CUSTOMER_ID>" +  lResultSet.getString("CUSTOMER_ID") +   "</CUSTOMER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rp_id") )
              lXmlBuffer = lXmlBuffer +   "<RP_ID>" +  lResultSet.getString("RP_ID") +   "</RP_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allowance_id") )
              lXmlBuffer = lXmlBuffer +   "<ALLOWANCE_ID>" +  lResultSet.getString("ALLOWANCE_ID") +   "</ALLOWANCE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dept_id") )
              lXmlBuffer = lXmlBuffer +   "<DEPT_ID>" +  lResultSet.getString("DEPT_ID") +   "</DEPT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("position_id") )
              lXmlBuffer = lXmlBuffer +   "<POSITION_ID>" +  lResultSet.getString("POSITION_ID") +   "</POSITION_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("level_id") )
              lXmlBuffer = lXmlBuffer +   "<LEVEL_ID>" +  lResultSet.getString("LEVEL_ID") +   "</LEVEL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("seq_num") )
              lXmlBuffer = lXmlBuffer +   "<SEQ_NUM>" +  lResultSet.getInt("SEQ_NUM") +   "</SEQ_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("benefit_flag") )
              lXmlBuffer = lXmlBuffer +   "<BENEFIT_FLAG>" +  lResultSet.getString("BENEFIT_FLAG") +   "</BENEFIT_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allowance_type") )
              lXmlBuffer = lXmlBuffer +   "<ALLOWANCE_TYPE>" +  lResultSet.getString("ALLOWANCE_TYPE") +   "</ALLOWANCE_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("amount_flag") )
              lXmlBuffer = lXmlBuffer +   "<AMOUNT_FLAG>" +  lResultSet.getString("AMOUNT_FLAG") +   "</AMOUNT_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("default_amount") )
              lXmlBuffer = lXmlBuffer +   "<DEFAULT_AMOUNT>" +  lResultSet.getDouble("DEFAULT_AMOUNT") +   "</DEFAULT_AMOUNT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("billing_charge") )
              lXmlBuffer = lXmlBuffer +   "<BILLING_CHARGE>" +  lResultSet.getDouble("BILLING_CHARGE") +   "</BILLING_CHARGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("paying_charge") )
              lXmlBuffer = lXmlBuffer +   "<PAYING_CHARGE>" +  lResultSet.getDouble("PAYING_CHARGE") +   "</PAYING_CHARGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("vacation_code") )
              lXmlBuffer = lXmlBuffer +   "<VACATION_CODE>" +  lResultSet.getString("VACATION_CODE") +   "</VACATION_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("leave_quota") )
              lXmlBuffer = lXmlBuffer +   "<LEAVE_QUOTA>" +  lResultSet.getInt("LEAVE_QUOTA") +   "</LEAVE_QUOTA>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("salary_flag") )
              lXmlBuffer = lXmlBuffer +   "<SALARY_FLAG>" +  lResultSet.getString("SALARY_FLAG") +   "</SALARY_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("active_flag") )
              lXmlBuffer = lXmlBuffer +   "<ACTIVE_FLAG>" +  lResultSet.getString("ACTIVE_FLAG") +   "</ACTIVE_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tax_flag") )
              lXmlBuffer = lXmlBuffer +   "<TAX_FLAG>" +  lResultSet.getString("TAX_FLAG") +   "</TAX_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("tax_percent") )
              lXmlBuffer = lXmlBuffer +   "<TAX_PERCENT>" +  lResultSet.getFloat("TAX_PERCENT") +   "</TAX_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sal_deduction_flag") )
              lXmlBuffer = lXmlBuffer +   "<SAL_DEDUCTION_FLAG>" +  lResultSet.getString("SAL_DEDUCTION_FLAG") +   "</SAL_DEDUCTION_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_sts") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_STS>" +  lResultSet.getString("AGREEMENT_STS") +   "</AGREEMENT_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("agreement_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<AGREEMENT_STS_DATE>" +  lResultSet.getString("AGREEMENT_STS_DATE") +   "</AGREEMENT_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("effective_date") )
              lXmlBuffer = lXmlBuffer +   "<EFFECTIVE_DATE>" +  lResultSet.getString("EFFECTIVE_DATE") +   "</EFFECTIVE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("expiration_date") )
              lXmlBuffer = lXmlBuffer +   "<EXPIRATION_DATE>" +  lResultSet.getString("EXPIRATION_DATE") +   "</EXPIRATION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("wages_print_ind") )
              lXmlBuffer = lXmlBuffer +   "<WAGES_PRINT_IND>" +  lResultSet.getString("WAGES_PRINT_IND") +   "</WAGES_PRINT_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("wages_tot_calc_ind") )
              lXmlBuffer = lXmlBuffer +   "<WAGES_TOT_CALC_IND>" +  lResultSet.getString("WAGES_TOT_CALC_IND") +   "</WAGES_TOT_CALC_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_status") )
              lXmlBuffer = lXmlBuffer +   "<REC_STATUS>" +  lResultSet.getString("REC_STATUS") +   "</REC_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_name") )
              lXmlBuffer = lXmlBuffer +   "<FILE_NAME>" +  lResultSet.getString("FILE_NAME") +   "</FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_DATE>" +  lResultSet.getString("FILE_CRE_DATE") +   "</FILE_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<FILE_CRE_TIME>" +  lResultSet.getString("FILE_CRE_TIME") +   "</FILE_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("file_status") )
              lXmlBuffer = lXmlBuffer +   "<FILE_STATUS>" +  lResultSet.getString("FILE_STATUS") +   "</FILE_STATUS>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</DmCustAgreement>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtDmCustAgreementRecByRowid
               ( String inRowId
               , DmCustAgreementTabObj  outDmCustAgreementTabObj
               )
  {
    sop("gtDmCustAgreementRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "rp_id, "+
                                 "allowance_id, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "seq_num, "+
                                 "benefit_flag, "+
                                 "allowance_type, "+
                                 "amount_flag, "+
                                 "default_amount, "+
                                 "billing_charge, "+
                                 "paying_charge, "+
                                 "vacation_code, "+
                                 "leave_quota, "+
                                 "salary_flag, "+
                                 "active_flag, "+
                                 "tax_flag, "+
                                 "tax_percent, "+
                                 "sal_deduction_flag, "+
                                 "remark, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "wages_print_ind, "+
                                 "wages_tot_calc_ind, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUST_AGREEMENT "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outDmCustAgreementTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outDmCustAgreementTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outDmCustAgreementTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          outDmCustAgreementTabObj.rp_id  =  lResultSet.getString("RP_ID");
          outDmCustAgreementTabObj.allowance_id  =  lResultSet.getString("ALLOWANCE_ID");
          outDmCustAgreementTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          outDmCustAgreementTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          outDmCustAgreementTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          outDmCustAgreementTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          outDmCustAgreementTabObj.benefit_flag  =  lResultSet.getString("BENEFIT_FLAG");
          outDmCustAgreementTabObj.allowance_type  =  lResultSet.getString("ALLOWANCE_TYPE");
          outDmCustAgreementTabObj.amount_flag  =  lResultSet.getString("AMOUNT_FLAG");
          outDmCustAgreementTabObj.default_amount  =  lResultSet.getDouble("DEFAULT_AMOUNT");
          outDmCustAgreementTabObj.billing_charge  =  lResultSet.getDouble("BILLING_CHARGE");
          outDmCustAgreementTabObj.paying_charge  =  lResultSet.getDouble("PAYING_CHARGE");
          outDmCustAgreementTabObj.vacation_code  =  lResultSet.getString("VACATION_CODE");
          outDmCustAgreementTabObj.leave_quota  =  lResultSet.getInt("LEAVE_QUOTA");
          outDmCustAgreementTabObj.salary_flag  =  lResultSet.getString("SALARY_FLAG");
          outDmCustAgreementTabObj.active_flag  =  lResultSet.getString("ACTIVE_FLAG");
          outDmCustAgreementTabObj.tax_flag  =  lResultSet.getString("TAX_FLAG");
          outDmCustAgreementTabObj.tax_percent  =  lResultSet.getFloat("TAX_PERCENT");
          outDmCustAgreementTabObj.sal_deduction_flag  =  lResultSet.getString("SAL_DEDUCTION_FLAG");
          outDmCustAgreementTabObj.remark  =  lResultSet.getString("REMARK");
          outDmCustAgreementTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          outDmCustAgreementTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( outDmCustAgreementTabObj.agreement_sts_date != null && outDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            outDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( outDmCustAgreementTabObj.effective_date != null && outDmCustAgreementTabObj.effective_date.length() > 0 ) 
            outDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( outDmCustAgreementTabObj.expiration_date != null && outDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            outDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.wages_print_ind  =  lResultSet.getString("WAGES_PRINT_IND");
          outDmCustAgreementTabObj.wages_tot_calc_ind  =  lResultSet.getString("WAGES_TOT_CALC_IND");
          outDmCustAgreementTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          outDmCustAgreementTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outDmCustAgreementTabObj.rec_cre_date != null && outDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            outDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outDmCustAgreementTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outDmCustAgreementTabObj.rec_upd_date != null && outDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            outDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          outDmCustAgreementTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          outDmCustAgreementTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( outDmCustAgreementTabObj.file_cre_date != null && outDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            outDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
          outDmCustAgreementTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          outDmCustAgreementTabObj.file_status  =  lResultSet.getString("FILE_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullDmCustAgreementTabObj( outDmCustAgreementTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementArr
               ( String inDmCustAgreementWhereText
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {
    sop("gtDmCustAgreementArr - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "customer_id, "+
                                 "rp_id, "+
                                 "allowance_id, "+
                                 "dept_id, "+
                                 "position_id, "+
                                 "level_id, "+
                                 "seq_num, "+
                                 "benefit_flag, "+
                                 "allowance_type, "+
                                 "amount_flag, "+
                                 "default_amount, "+
                                 "billing_charge, "+
                                 "paying_charge, "+
                                 "vacation_code, "+
                                 "leave_quota, "+
                                 "salary_flag, "+
                                 "active_flag, "+
                                 "tax_flag, "+
                                 "tax_percent, "+
                                 "sal_deduction_flag, "+
                                 "remark, "+
                                 "agreement_sts, "+
                                 "agreement_sts_date, "+
                                 "effective_date, "+
                                 "expiration_date, "+
                                 "wages_print_ind, "+
                                 "wages_tot_calc_ind, "+
                                 "rec_status, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time, "+
                                 "file_name, "+
                                 "file_cre_date, "+
                                 "file_cre_time, "+
                                 "file_status "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          DmCustAgreementTabObj  lDmCustAgreementTabObj = new DmCustAgreementTabObj();
          lDmCustAgreementTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lDmCustAgreementTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lDmCustAgreementTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
          lDmCustAgreementTabObj.rp_id  =  lResultSet.getString("RP_ID");
          lDmCustAgreementTabObj.allowance_id  =  lResultSet.getString("ALLOWANCE_ID");
          lDmCustAgreementTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
          lDmCustAgreementTabObj.position_id  =  lResultSet.getString("POSITION_ID");
          lDmCustAgreementTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
          lDmCustAgreementTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          lDmCustAgreementTabObj.benefit_flag  =  lResultSet.getString("BENEFIT_FLAG");
          lDmCustAgreementTabObj.allowance_type  =  lResultSet.getString("ALLOWANCE_TYPE");
          lDmCustAgreementTabObj.amount_flag  =  lResultSet.getString("AMOUNT_FLAG");
          lDmCustAgreementTabObj.default_amount  =  lResultSet.getDouble("DEFAULT_AMOUNT");
          lDmCustAgreementTabObj.billing_charge  =  lResultSet.getDouble("BILLING_CHARGE");
          lDmCustAgreementTabObj.paying_charge  =  lResultSet.getDouble("PAYING_CHARGE");
          lDmCustAgreementTabObj.vacation_code  =  lResultSet.getString("VACATION_CODE");
          lDmCustAgreementTabObj.leave_quota  =  lResultSet.getInt("LEAVE_QUOTA");
          lDmCustAgreementTabObj.salary_flag  =  lResultSet.getString("SALARY_FLAG");
          lDmCustAgreementTabObj.active_flag  =  lResultSet.getString("ACTIVE_FLAG");
          lDmCustAgreementTabObj.tax_flag  =  lResultSet.getString("TAX_FLAG");
          lDmCustAgreementTabObj.tax_percent  =  lResultSet.getFloat("TAX_PERCENT");
          lDmCustAgreementTabObj.sal_deduction_flag  =  lResultSet.getString("SAL_DEDUCTION_FLAG");
          lDmCustAgreementTabObj.remark  =  lResultSet.getString("REMARK");
          lDmCustAgreementTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
          lDmCustAgreementTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");

          if ( lDmCustAgreementTabObj.agreement_sts_date != null && lDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");

          if ( lDmCustAgreementTabObj.effective_date != null && lDmCustAgreementTabObj.effective_date.length() > 0 ) 
            lDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");

          if ( lDmCustAgreementTabObj.expiration_date != null && lDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            lDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.wages_print_ind  =  lResultSet.getString("WAGES_PRINT_IND");
          lDmCustAgreementTabObj.wages_tot_calc_ind  =  lResultSet.getString("WAGES_TOT_CALC_IND");
          lDmCustAgreementTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
          lDmCustAgreementTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lDmCustAgreementTabObj.rec_cre_date != null && lDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lDmCustAgreementTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lDmCustAgreementTabObj.rec_upd_date != null && lDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          lDmCustAgreementTabObj.file_name  =  lResultSet.getString("FILE_NAME");
          lDmCustAgreementTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");

          if ( lDmCustAgreementTabObj.file_cre_date != null && lDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
          lDmCustAgreementTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
          lDmCustAgreementTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          removeNullDmCustAgreementTabObj( lDmCustAgreementTabObj );

          outDmCustAgreementTabObjArr.add(  lDmCustAgreementTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustAgreementTabObjArr != null && outDmCustAgreementTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementArrDist
               ( String inDmCustAgreementWhereText
               , String inDistDmCustAgreementField
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {

    sop("gtDmCustAgreementArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";
  

       String lDistDmCustAgreementFieldQry = inDistDmCustAgreementField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmCustAgreementFieldQry+
                         " FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmCustAgreementField.substring(inDistDmCustAgreementField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          DmCustAgreementTabObj  lDmCustAgreementTabObj = new DmCustAgreementTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lDmCustAgreementTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("customer_id") )
              lDmCustAgreementTabObj.customer_id  =  lResultSet.getString("CUSTOMER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rp_id") )
              lDmCustAgreementTabObj.rp_id  =  lResultSet.getString("RP_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allowance_id") )
              lDmCustAgreementTabObj.allowance_id  =  lResultSet.getString("ALLOWANCE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dept_id") )
              lDmCustAgreementTabObj.dept_id  =  lResultSet.getString("DEPT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("position_id") )
              lDmCustAgreementTabObj.position_id  =  lResultSet.getString("POSITION_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("level_id") )
              lDmCustAgreementTabObj.level_id  =  lResultSet.getString("LEVEL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("seq_num") )
              lDmCustAgreementTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("benefit_flag") )
              lDmCustAgreementTabObj.benefit_flag  =  lResultSet.getString("BENEFIT_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allowance_type") )
              lDmCustAgreementTabObj.allowance_type  =  lResultSet.getString("ALLOWANCE_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("amount_flag") )
              lDmCustAgreementTabObj.amount_flag  =  lResultSet.getString("AMOUNT_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("default_amount") )
              lDmCustAgreementTabObj.default_amount  =  lResultSet.getDouble("DEFAULT_AMOUNT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("billing_charge") )
              lDmCustAgreementTabObj.billing_charge  =  lResultSet.getDouble("BILLING_CHARGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("paying_charge") )
              lDmCustAgreementTabObj.paying_charge  =  lResultSet.getDouble("PAYING_CHARGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("vacation_code") )
              lDmCustAgreementTabObj.vacation_code  =  lResultSet.getString("VACATION_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("leave_quota") )
              lDmCustAgreementTabObj.leave_quota  =  lResultSet.getInt("LEAVE_QUOTA");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("salary_flag") )
              lDmCustAgreementTabObj.salary_flag  =  lResultSet.getString("SALARY_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("active_flag") )
              lDmCustAgreementTabObj.active_flag  =  lResultSet.getString("ACTIVE_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tax_flag") )
              lDmCustAgreementTabObj.tax_flag  =  lResultSet.getString("TAX_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("tax_percent") )
              lDmCustAgreementTabObj.tax_percent  =  lResultSet.getFloat("TAX_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sal_deduction_flag") )
              lDmCustAgreementTabObj.sal_deduction_flag  =  lResultSet.getString("SAL_DEDUCTION_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lDmCustAgreementTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_sts") )
              lDmCustAgreementTabObj.agreement_sts  =  lResultSet.getString("AGREEMENT_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("agreement_sts_date") )
              {
              lDmCustAgreementTabObj.agreement_sts_date  =  lResultSet.getString("AGREEMENT_STS_DATE");
  
          if ( lDmCustAgreementTabObj.agreement_sts_date != null && lDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.agreement_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("effective_date") )
              {
              lDmCustAgreementTabObj.effective_date  =  lResultSet.getString("EFFECTIVE_DATE");
  
          if ( lDmCustAgreementTabObj.effective_date != null && lDmCustAgreementTabObj.effective_date.length() > 0 ) 
            lDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.effective_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("expiration_date") )
              {
              lDmCustAgreementTabObj.expiration_date  =  lResultSet.getString("EXPIRATION_DATE");
  
          if ( lDmCustAgreementTabObj.expiration_date != null && lDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            lDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.expiration_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("wages_print_ind") )
              lDmCustAgreementTabObj.wages_print_ind  =  lResultSet.getString("WAGES_PRINT_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("wages_tot_calc_ind") )
              lDmCustAgreementTabObj.wages_tot_calc_ind  =  lResultSet.getString("WAGES_TOT_CALC_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_status") )
              lDmCustAgreementTabObj.rec_status  =  lResultSet.getString("REC_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lDmCustAgreementTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lDmCustAgreementTabObj.rec_cre_date != null && lDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lDmCustAgreementTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lDmCustAgreementTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lDmCustAgreementTabObj.rec_upd_date != null && lDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lDmCustAgreementTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_name") )
              lDmCustAgreementTabObj.file_name  =  lResultSet.getString("FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_date") )
              {
              lDmCustAgreementTabObj.file_cre_date  =  lResultSet.getString("FILE_CRE_DATE");
  
          if ( lDmCustAgreementTabObj.file_cre_date != null && lDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lDmCustAgreementTabObj.file_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_cre_time") )
              lDmCustAgreementTabObj.file_cre_time  =  lResultSet.getString("FILE_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("file_status") )
              lDmCustAgreementTabObj.file_status  =  lResultSet.getString("FILE_STATUS");

          }
          removeNullDmCustAgreementTabObj( lDmCustAgreementTabObj );

          outDmCustAgreementTabObjArr.add(  lDmCustAgreementTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustAgreementTabObjArr != null && outDmCustAgreementTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtDmCustAgreementStrArrDist
               ( String inDmCustAgreementWhereText
               , String inDistDmCustAgreementField
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {

    sop("gtDmCustAgreementStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtDmCustAgreementStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";
  

       String lDistDmCustAgreementFieldQry = inDistDmCustAgreementField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistDmCustAgreementFieldQry+
                         " FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistDmCustAgreementField.substring(inDistDmCustAgreementField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lDmCustAgreementTabObjStr = "";
       while(lResultSet.next())
       {
          lDmCustAgreementTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lDmCustAgreementTabObjStr =   lDmCustAgreementTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outDmCustAgreementTabObjArr.add(  lDmCustAgreementTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outDmCustAgreementTabObjArr != null && outDmCustAgreementTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValDmCustAgreement
               ( String inDmCustAgreementWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValDmCustAgreement - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValDmCustAgreement";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullDmCustAgreementTabObj
               ( 
                 DmCustAgreementTabObj  outDmCustAgreementTabObj
               )
  {
  
    if ( outDmCustAgreementTabObj.org_id == null ) 
     outDmCustAgreementTabObj.org_id = ""; 
    if ( outDmCustAgreementTabObj.customer_id == null ) 
     outDmCustAgreementTabObj.customer_id = ""; 
    if ( outDmCustAgreementTabObj.rp_id == null ) 
     outDmCustAgreementTabObj.rp_id = ""; 
    if ( outDmCustAgreementTabObj.allowance_id == null ) 
     outDmCustAgreementTabObj.allowance_id = ""; 
    if ( outDmCustAgreementTabObj.dept_id == null ) 
     outDmCustAgreementTabObj.dept_id = ""; 
    if ( outDmCustAgreementTabObj.position_id == null ) 
     outDmCustAgreementTabObj.position_id = ""; 
    if ( outDmCustAgreementTabObj.level_id == null ) 
     outDmCustAgreementTabObj.level_id = ""; 
    if ( outDmCustAgreementTabObj.seq_num == (int)0 ) 
     outDmCustAgreementTabObj.seq_num = (int)0; 
    if ( outDmCustAgreementTabObj.benefit_flag == null ) 
     outDmCustAgreementTabObj.benefit_flag = ""; 
    if ( outDmCustAgreementTabObj.allowance_type == null ) 
     outDmCustAgreementTabObj.allowance_type = ""; 
    if ( outDmCustAgreementTabObj.amount_flag == null ) 
     outDmCustAgreementTabObj.amount_flag = ""; 
    if ( outDmCustAgreementTabObj.default_amount == (double)0.00 ) 
     outDmCustAgreementTabObj.default_amount = (double)0.00; 
    if ( outDmCustAgreementTabObj.billing_charge == (double)0.00 ) 
     outDmCustAgreementTabObj.billing_charge = (double)0.00; 
    if ( outDmCustAgreementTabObj.paying_charge == (double)0.00 ) 
     outDmCustAgreementTabObj.paying_charge = (double)0.00; 
    if ( outDmCustAgreementTabObj.vacation_code == null ) 
     outDmCustAgreementTabObj.vacation_code = ""; 
    if ( outDmCustAgreementTabObj.leave_quota == (int)0 ) 
     outDmCustAgreementTabObj.leave_quota = (int)0; 
    if ( outDmCustAgreementTabObj.salary_flag == null ) 
     outDmCustAgreementTabObj.salary_flag = ""; 
    if ( outDmCustAgreementTabObj.active_flag == null ) 
     outDmCustAgreementTabObj.active_flag = ""; 
    if ( outDmCustAgreementTabObj.tax_flag == null ) 
     outDmCustAgreementTabObj.tax_flag = ""; 
    if ( outDmCustAgreementTabObj.tax_percent == (float)0.00 ) 
     outDmCustAgreementTabObj.tax_percent = (float)0.00; 
    if ( outDmCustAgreementTabObj.sal_deduction_flag == null ) 
     outDmCustAgreementTabObj.sal_deduction_flag = ""; 
    if ( outDmCustAgreementTabObj.remark == null ) 
     outDmCustAgreementTabObj.remark = ""; 
    if ( outDmCustAgreementTabObj.agreement_sts == null ) 
     outDmCustAgreementTabObj.agreement_sts = ""; 
    if ( outDmCustAgreementTabObj.agreement_sts_date == null ) 
     outDmCustAgreementTabObj.agreement_sts_date = ""; 
    if ( outDmCustAgreementTabObj.effective_date == null ) 
     outDmCustAgreementTabObj.effective_date = ""; 
    if ( outDmCustAgreementTabObj.expiration_date == null ) 
     outDmCustAgreementTabObj.expiration_date = ""; 
    if ( outDmCustAgreementTabObj.wages_print_ind == null ) 
     outDmCustAgreementTabObj.wages_print_ind = ""; 
    if ( outDmCustAgreementTabObj.wages_tot_calc_ind == null ) 
     outDmCustAgreementTabObj.wages_tot_calc_ind = ""; 
    if ( outDmCustAgreementTabObj.rec_status == null ) 
     outDmCustAgreementTabObj.rec_status = ""; 
    if ( outDmCustAgreementTabObj.rec_cre_date == null ) 
     outDmCustAgreementTabObj.rec_cre_date = ""; 
    if ( outDmCustAgreementTabObj.rec_cre_time == null ) 
     outDmCustAgreementTabObj.rec_cre_time = ""; 
    if ( outDmCustAgreementTabObj.rec_upd_date == null ) 
     outDmCustAgreementTabObj.rec_upd_date = ""; 
    if ( outDmCustAgreementTabObj.rec_upd_time == null ) 
     outDmCustAgreementTabObj.rec_upd_time = ""; 
    if ( outDmCustAgreementTabObj.file_name == null ) 
     outDmCustAgreementTabObj.file_name = ""; 
    if ( outDmCustAgreementTabObj.file_cre_date == null ) 
     outDmCustAgreementTabObj.file_cre_date = ""; 
    if ( outDmCustAgreementTabObj.file_cre_time == null ) 
     outDmCustAgreementTabObj.file_cre_time = ""; 
    if ( outDmCustAgreementTabObj.file_status == null ) 
     outDmCustAgreementTabObj.file_status = ""; 
  }





  public int insDmCustAgreementRec
               ( DmCustAgreementTabObj  inDmCustAgreementTabObj )
  {
    int lUpdateCount;
    sop("insDmCustAgreementRec - Started");
    gSSTErrorObj.sourceMethod = "insDmCustAgreementRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustAgreementTabObj.agreement_sts_date != null && inDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.effective_date != null && inDmCustAgreementTabObj.effective_date.length() > 0 ) 
            inDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.expiration_date != null && inDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            inDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_cre_date != null && inDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_upd_date != null && inDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.file_cre_date != null && inDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_CUST_AGREEMENT"+
                        "("+
                                "org_id,"+
                                "customer_id,"+
                                "rp_id,"+
                                "allowance_id,"+
                                "dept_id,"+
                                "position_id,"+
                                "level_id,"+
                                "seq_num,"+
                                "benefit_flag,"+
                                "allowance_type,"+
                                "amount_flag,"+
                                "default_amount,"+
                                "billing_charge,"+
                                "paying_charge,"+
                                "vacation_code,"+
                                "leave_quota,"+
                                "salary_flag,"+
                                "active_flag,"+
                                "tax_flag,"+
                                "tax_percent,"+
                                "sal_deduction_flag,"+
                                "remark,"+
                                "agreement_sts,"+
                                "agreement_sts_date,"+
                                "effective_date,"+
                                "expiration_date,"+
                                "wages_print_ind,"+
                                "wages_tot_calc_ind,"+
                                "rec_status,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_date,"+
                                "rec_upd_time,"+
                                "file_name,"+
                                "file_cre_date,"+
                                "file_cre_time,"+
                                "file_status"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.customer_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rp_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.allowance_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.dept_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.position_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.level_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.seq_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.benefit_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.allowance_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.amount_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.default_amount+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.billing_charge+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.paying_charge+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.vacation_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.leave_quota+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.salary_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.active_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.tax_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inDmCustAgreementTabObj.tax_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.sal_deduction_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.agreement_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.agreement_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.effective_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.expiration_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.wages_print_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.wages_tot_calc_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rec_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.rec_upd_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.file_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inDmCustAgreementTabObj.file_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inDmCustAgreementTabObj.file_status+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inDmCustAgreementTabObj.org_id);
        lPreparedStatement.setString(2, inDmCustAgreementTabObj.customer_id);
        lPreparedStatement.setString(3, inDmCustAgreementTabObj.rp_id);
        lPreparedStatement.setString(4, inDmCustAgreementTabObj.allowance_id);
        lPreparedStatement.setString(5, inDmCustAgreementTabObj.dept_id);
        lPreparedStatement.setString(6, inDmCustAgreementTabObj.position_id);
        lPreparedStatement.setString(7, inDmCustAgreementTabObj.level_id);
          lPreparedStatement.setInt(8, inDmCustAgreementTabObj.seq_num);
        lPreparedStatement.setString(9, inDmCustAgreementTabObj.benefit_flag);
        lPreparedStatement.setString(10, inDmCustAgreementTabObj.allowance_type);
        lPreparedStatement.setString(11, inDmCustAgreementTabObj.amount_flag);
          lPreparedStatement.setDouble(12, inDmCustAgreementTabObj.default_amount);
          lPreparedStatement.setDouble(13, inDmCustAgreementTabObj.billing_charge);
          lPreparedStatement.setDouble(14, inDmCustAgreementTabObj.paying_charge);
        lPreparedStatement.setString(15, inDmCustAgreementTabObj.vacation_code);
          lPreparedStatement.setInt(16, inDmCustAgreementTabObj.leave_quota);
        lPreparedStatement.setString(17, inDmCustAgreementTabObj.salary_flag);
        lPreparedStatement.setString(18, inDmCustAgreementTabObj.active_flag);
        lPreparedStatement.setString(19, inDmCustAgreementTabObj.tax_flag);
          lPreparedStatement.setFloat(20, inDmCustAgreementTabObj.tax_percent);
        lPreparedStatement.setString(21, inDmCustAgreementTabObj.sal_deduction_flag);
        lPreparedStatement.setString(22, inDmCustAgreementTabObj.remark);
        lPreparedStatement.setString(23, inDmCustAgreementTabObj.agreement_sts);
        lPreparedStatement.setString(24, inDmCustAgreementTabObj.agreement_sts_date);
        lPreparedStatement.setString(25, inDmCustAgreementTabObj.effective_date);
        lPreparedStatement.setString(26, inDmCustAgreementTabObj.expiration_date);
        lPreparedStatement.setString(27, inDmCustAgreementTabObj.wages_print_ind);
        lPreparedStatement.setString(28, inDmCustAgreementTabObj.wages_tot_calc_ind);
        lPreparedStatement.setString(29, inDmCustAgreementTabObj.rec_status);
        lPreparedStatement.setString(30, inDmCustAgreementTabObj.rec_cre_date);
        lPreparedStatement.setString(31, inDmCustAgreementTabObj.rec_cre_time);
        lPreparedStatement.setString(32, inDmCustAgreementTabObj.rec_upd_date);
        lPreparedStatement.setString(33, inDmCustAgreementTabObj.rec_upd_time);
        lPreparedStatement.setString(34, inDmCustAgreementTabObj.file_name);
        lPreparedStatement.setString(35, inDmCustAgreementTabObj.file_cre_date);
        lPreparedStatement.setString(36, inDmCustAgreementTabObj.file_cre_time);
        lPreparedStatement.setString(37, inDmCustAgreementTabObj.file_status);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insDmCustAgreementArr
               ( ArrayList  inDmCustAgreementTabObjArr 
               , String  inRowidFlag )
  {
    DmCustAgreementTabObj  lDmCustAgreementTabObj = new DmCustAgreementTabObj();
    int lUpdateCount;
    sop("insDmCustAgreementArr - Started");
    gSSTErrorObj.sourceMethod = "insDmCustAgreementArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inDmCustAgreementTabObjArr.size(); lNumRec++ )
      {
        lDmCustAgreementTabObj = (DmCustAgreementTabObj)inDmCustAgreementTabObjArr.get(lNumRec);

          if ( lDmCustAgreementTabObj.agreement_sts_date != null && lDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            lDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( lDmCustAgreementTabObj.effective_date != null && lDmCustAgreementTabObj.effective_date.length() > 0 ) 
            lDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.effective_date, lDateTimeSrcFmt);

          if ( lDmCustAgreementTabObj.expiration_date != null && lDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            lDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.expiration_date, lDateTimeSrcFmt);

          if ( lDmCustAgreementTabObj.rec_cre_date != null && lDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lDmCustAgreementTabObj.rec_upd_date != null && lDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            lDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( lDmCustAgreementTabObj.file_cre_date != null && lDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            lDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lDmCustAgreementTabObj.file_cre_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO DM_CUST_AGREEMENT"+
                        "("+
                        "org_id,"+
                        "customer_id,"+
                        "rp_id,"+
                        "allowance_id,"+
                        "dept_id,"+
                        "position_id,"+
                        "level_id,"+
                        "seq_num,"+
                        "benefit_flag,"+
                        "allowance_type,"+
                        "amount_flag,"+
                        "default_amount,"+
                        "billing_charge,"+
                        "paying_charge,"+
                        "vacation_code,"+
                        "leave_quota,"+
                        "salary_flag,"+
                        "active_flag,"+
                        "tax_flag,"+
                        "tax_percent,"+
                        "sal_deduction_flag,"+
                        "remark,"+
                        "agreement_sts,"+
                        "agreement_sts_date,"+
                        "effective_date,"+
                        "expiration_date,"+
                        "wages_print_ind,"+
                        "wages_tot_calc_ind,"+
                        "rec_status,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_date,"+
                        "rec_upd_time,"+
                        "file_name,"+
                        "file_cre_date,"+
                        "file_cre_time,"+
                        "file_status"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.customer_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rp_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.allowance_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.dept_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.position_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.level_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.seq_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.benefit_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.allowance_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.amount_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.default_amount+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.billing_charge+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.paying_charge+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.vacation_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.leave_quota+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.salary_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.active_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.tax_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lDmCustAgreementTabObj.tax_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.sal_deduction_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.agreement_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.agreement_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.effective_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.expiration_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.wages_print_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.wages_tot_calc_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rec_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.rec_upd_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.file_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lDmCustAgreementTabObj.file_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lDmCustAgreementTabObj.file_status+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lDmCustAgreementTabObj.org_id);
            lPreparedStatement.setString(2, lDmCustAgreementTabObj.customer_id);
            lPreparedStatement.setString(3, lDmCustAgreementTabObj.rp_id);
            lPreparedStatement.setString(4, lDmCustAgreementTabObj.allowance_id);
            lPreparedStatement.setString(5, lDmCustAgreementTabObj.dept_id);
            lPreparedStatement.setString(6, lDmCustAgreementTabObj.position_id);
            lPreparedStatement.setString(7, lDmCustAgreementTabObj.level_id);
              lPreparedStatement.setInt(8, lDmCustAgreementTabObj.seq_num);
            lPreparedStatement.setString(9, lDmCustAgreementTabObj.benefit_flag);
            lPreparedStatement.setString(10, lDmCustAgreementTabObj.allowance_type);
            lPreparedStatement.setString(11, lDmCustAgreementTabObj.amount_flag);
              lPreparedStatement.setDouble(12, lDmCustAgreementTabObj.default_amount);
              lPreparedStatement.setDouble(13, lDmCustAgreementTabObj.billing_charge);
              lPreparedStatement.setDouble(14, lDmCustAgreementTabObj.paying_charge);
            lPreparedStatement.setString(15, lDmCustAgreementTabObj.vacation_code);
              lPreparedStatement.setInt(16, lDmCustAgreementTabObj.leave_quota);
            lPreparedStatement.setString(17, lDmCustAgreementTabObj.salary_flag);
            lPreparedStatement.setString(18, lDmCustAgreementTabObj.active_flag);
            lPreparedStatement.setString(19, lDmCustAgreementTabObj.tax_flag);
              lPreparedStatement.setFloat(20, lDmCustAgreementTabObj.tax_percent);
            lPreparedStatement.setString(21, lDmCustAgreementTabObj.sal_deduction_flag);
            lPreparedStatement.setString(22, lDmCustAgreementTabObj.remark);
            lPreparedStatement.setString(23, lDmCustAgreementTabObj.agreement_sts);
            lPreparedStatement.setString(24, lDmCustAgreementTabObj.agreement_sts_date);
            lPreparedStatement.setString(25, lDmCustAgreementTabObj.effective_date);
            lPreparedStatement.setString(26, lDmCustAgreementTabObj.expiration_date);
            lPreparedStatement.setString(27, lDmCustAgreementTabObj.wages_print_ind);
            lPreparedStatement.setString(28, lDmCustAgreementTabObj.wages_tot_calc_ind);
            lPreparedStatement.setString(29, lDmCustAgreementTabObj.rec_status);
            lPreparedStatement.setString(30, lDmCustAgreementTabObj.rec_cre_date);
            lPreparedStatement.setString(31, lDmCustAgreementTabObj.rec_cre_time);
            lPreparedStatement.setString(32, lDmCustAgreementTabObj.rec_upd_date);
            lPreparedStatement.setString(33, lDmCustAgreementTabObj.rec_upd_time);
            lPreparedStatement.setString(34, lDmCustAgreementTabObj.file_name);
            lPreparedStatement.setString(35, lDmCustAgreementTabObj.file_cre_date);
            lPreparedStatement.setString(36, lDmCustAgreementTabObj.file_cre_time);
            lPreparedStatement.setString(37, lDmCustAgreementTabObj.file_status);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popDmCustAgreementReq2Obj
               ( HttpServletRequest inRequest
               , DmCustAgreementTabObj  outDmCustAgreementTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outDmCustAgreementTabObj.tab_rowid = lTabRowidValue;

    outDmCustAgreementTabObj.org_id = inRequest.getParameter("org_id");
    outDmCustAgreementTabObj.customer_id = inRequest.getParameter("customer_id");
    outDmCustAgreementTabObj.rp_id = inRequest.getParameter("rp_id");
    outDmCustAgreementTabObj.allowance_id = inRequest.getParameter("allowance_id");
    outDmCustAgreementTabObj.dept_id = inRequest.getParameter("dept_id");
    outDmCustAgreementTabObj.position_id = inRequest.getParameter("position_id");
    outDmCustAgreementTabObj.level_id = inRequest.getParameter("level_id");
    if ( inRequest.getParameter("seq_num") == null )
      outDmCustAgreementTabObj.seq_num = 0;
    else
    if ( inRequest.getParameter("seq_num").trim().length() == 0 )
      outDmCustAgreementTabObj.seq_num = 0;
    else
      outDmCustAgreementTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num"));
    outDmCustAgreementTabObj.benefit_flag = inRequest.getParameter("benefit_flag");
    outDmCustAgreementTabObj.allowance_type = inRequest.getParameter("allowance_type");
    outDmCustAgreementTabObj.amount_flag = inRequest.getParameter("amount_flag");
    if ( inRequest.getParameter("default_amount") == null )
      outDmCustAgreementTabObj.default_amount = 0;
    else
    if ( inRequest.getParameter("default_amount").trim().length() == 0 )
      outDmCustAgreementTabObj.default_amount = 0;
    else
      outDmCustAgreementTabObj.default_amount = Double.parseDouble( inRequest.getParameter("default_amount"));
    if ( inRequest.getParameter("billing_charge") == null )
      outDmCustAgreementTabObj.billing_charge = 0;
    else
    if ( inRequest.getParameter("billing_charge").trim().length() == 0 )
      outDmCustAgreementTabObj.billing_charge = 0;
    else
      outDmCustAgreementTabObj.billing_charge = Double.parseDouble( inRequest.getParameter("billing_charge"));
    if ( inRequest.getParameter("paying_charge") == null )
      outDmCustAgreementTabObj.paying_charge = 0;
    else
    if ( inRequest.getParameter("paying_charge").trim().length() == 0 )
      outDmCustAgreementTabObj.paying_charge = 0;
    else
      outDmCustAgreementTabObj.paying_charge = Double.parseDouble( inRequest.getParameter("paying_charge"));
    outDmCustAgreementTabObj.vacation_code = inRequest.getParameter("vacation_code");
    if ( inRequest.getParameter("leave_quota") == null )
      outDmCustAgreementTabObj.leave_quota = 0;
    else
    if ( inRequest.getParameter("leave_quota").trim().length() == 0 )
      outDmCustAgreementTabObj.leave_quota = 0;
    else
      outDmCustAgreementTabObj.leave_quota = Integer.parseInt( inRequest.getParameter("leave_quota"));
    outDmCustAgreementTabObj.salary_flag = inRequest.getParameter("salary_flag");
    outDmCustAgreementTabObj.active_flag = inRequest.getParameter("active_flag");
    outDmCustAgreementTabObj.tax_flag = inRequest.getParameter("tax_flag");
    if ( inRequest.getParameter("tax_percent") == null )
      outDmCustAgreementTabObj.tax_percent = 0;
    else
    if ( inRequest.getParameter("tax_percent").trim().length() == 0 )
      outDmCustAgreementTabObj.tax_percent = 0;
    else
      outDmCustAgreementTabObj.tax_percent = Float.parseFloat( inRequest.getParameter("tax_percent"));
    outDmCustAgreementTabObj.sal_deduction_flag = inRequest.getParameter("sal_deduction_flag");
    outDmCustAgreementTabObj.remark = inRequest.getParameter("remark");
    outDmCustAgreementTabObj.agreement_sts = inRequest.getParameter("agreement_sts");
    outDmCustAgreementTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date");
    outDmCustAgreementTabObj.effective_date = inRequest.getParameter("effective_date");
    outDmCustAgreementTabObj.expiration_date = inRequest.getParameter("expiration_date");
    outDmCustAgreementTabObj.wages_print_ind = inRequest.getParameter("wages_print_ind");
    outDmCustAgreementTabObj.wages_tot_calc_ind = inRequest.getParameter("wages_tot_calc_ind");
    outDmCustAgreementTabObj.rec_status = inRequest.getParameter("rec_status");
    outDmCustAgreementTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outDmCustAgreementTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outDmCustAgreementTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outDmCustAgreementTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    outDmCustAgreementTabObj.file_name = inRequest.getParameter("file_name");
    outDmCustAgreementTabObj.file_cre_date = inRequest.getParameter("file_cre_date");
    outDmCustAgreementTabObj.file_cre_time = inRequest.getParameter("file_cre_time");
    outDmCustAgreementTabObj.file_status = inRequest.getParameter("file_status");
    return lReturnValue;
  }


  public int popDmCustAgreementReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmCustAgreementTabObj lDmCustAgreementTabObj= new DmCustAgreementTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmCustAgreementTabObj.tab_rowid = lTabRowidValue;

      lDmCustAgreementTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lDmCustAgreementTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
      lDmCustAgreementTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
      lDmCustAgreementTabObj.allowance_id = inRequest.getParameter("allowance_id_r"+lNumRec);
      lDmCustAgreementTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
      lDmCustAgreementTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
      lDmCustAgreementTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
      if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
        lDmCustAgreementTabObj.seq_num = 0;
      else
      if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.seq_num = 0;
      else
        lDmCustAgreementTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
      lDmCustAgreementTabObj.benefit_flag = inRequest.getParameter("benefit_flag_r"+lNumRec);
      lDmCustAgreementTabObj.allowance_type = inRequest.getParameter("allowance_type_r"+lNumRec);
      lDmCustAgreementTabObj.amount_flag = inRequest.getParameter("amount_flag_r"+lNumRec);
      if ( inRequest.getParameter("default_amount_r"+lNumRec) == null )
        lDmCustAgreementTabObj.default_amount = 0;
      else
      if ( inRequest.getParameter("default_amount_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.default_amount = 0;
      else
        lDmCustAgreementTabObj.default_amount = Double.parseDouble( inRequest.getParameter("default_amount_r"+lNumRec));
      if ( inRequest.getParameter("billing_charge_r"+lNumRec) == null )
        lDmCustAgreementTabObj.billing_charge = 0;
      else
      if ( inRequest.getParameter("billing_charge_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.billing_charge = 0;
      else
        lDmCustAgreementTabObj.billing_charge = Double.parseDouble( inRequest.getParameter("billing_charge_r"+lNumRec));
      if ( inRequest.getParameter("paying_charge_r"+lNumRec) == null )
        lDmCustAgreementTabObj.paying_charge = 0;
      else
      if ( inRequest.getParameter("paying_charge_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.paying_charge = 0;
      else
        lDmCustAgreementTabObj.paying_charge = Double.parseDouble( inRequest.getParameter("paying_charge_r"+lNumRec));
      lDmCustAgreementTabObj.vacation_code = inRequest.getParameter("vacation_code_r"+lNumRec);
      if ( inRequest.getParameter("leave_quota_r"+lNumRec) == null )
        lDmCustAgreementTabObj.leave_quota = 0;
      else
      if ( inRequest.getParameter("leave_quota_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.leave_quota = 0;
      else
        lDmCustAgreementTabObj.leave_quota = Integer.parseInt( inRequest.getParameter("leave_quota_r"+lNumRec));
      lDmCustAgreementTabObj.salary_flag = inRequest.getParameter("salary_flag_r"+lNumRec);
      lDmCustAgreementTabObj.active_flag = inRequest.getParameter("active_flag_r"+lNumRec);
      lDmCustAgreementTabObj.tax_flag = inRequest.getParameter("tax_flag_r"+lNumRec);
      if ( inRequest.getParameter("tax_percent_r"+lNumRec) == null )
        lDmCustAgreementTabObj.tax_percent = 0;
      else
      if ( inRequest.getParameter("tax_percent_r"+lNumRec).trim().length() == 0 )
        lDmCustAgreementTabObj.tax_percent = 0;
      else
        lDmCustAgreementTabObj.tax_percent = Float.parseFloat( inRequest.getParameter("tax_percent_r"+lNumRec));
      lDmCustAgreementTabObj.sal_deduction_flag = inRequest.getParameter("sal_deduction_flag_r"+lNumRec);
      lDmCustAgreementTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      lDmCustAgreementTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
      lDmCustAgreementTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
      lDmCustAgreementTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
      lDmCustAgreementTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
      lDmCustAgreementTabObj.wages_print_ind = inRequest.getParameter("wages_print_ind_r"+lNumRec);
      lDmCustAgreementTabObj.wages_tot_calc_ind = inRequest.getParameter("wages_tot_calc_ind_r"+lNumRec);
      lDmCustAgreementTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
      lDmCustAgreementTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lDmCustAgreementTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lDmCustAgreementTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lDmCustAgreementTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      lDmCustAgreementTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
      lDmCustAgreementTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
      lDmCustAgreementTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
      lDmCustAgreementTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      outDmCustAgreementTabObjArr.add( lDmCustAgreementTabObj);
    }
    return lReturnValue;
  }


  public int popDmCustAgreementReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , DmCustAgreementTabObj outDmCustAgreementTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_cust_agreement_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outDmCustAgreementTabObj.tab_rowid = lTabRowidValue;

        outDmCustAgreementTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outDmCustAgreementTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        outDmCustAgreementTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
        outDmCustAgreementTabObj.allowance_id = inRequest.getParameter("allowance_id_r"+lNumRec);
        outDmCustAgreementTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        outDmCustAgreementTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        outDmCustAgreementTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
          outDmCustAgreementTabObj.seq_num = 0;
        else
        if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.seq_num = 0;
        else
          outDmCustAgreementTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
        outDmCustAgreementTabObj.benefit_flag = inRequest.getParameter("benefit_flag_r"+lNumRec);
        outDmCustAgreementTabObj.allowance_type = inRequest.getParameter("allowance_type_r"+lNumRec);
        outDmCustAgreementTabObj.amount_flag = inRequest.getParameter("amount_flag_r"+lNumRec);
        if ( inRequest.getParameter("default_amount_r"+lNumRec) == null )
          outDmCustAgreementTabObj.default_amount = 0;
        else
        if ( inRequest.getParameter("default_amount_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.default_amount = 0;
        else
          outDmCustAgreementTabObj.default_amount = Double.parseDouble( inRequest.getParameter("default_amount_r"+lNumRec));
        if ( inRequest.getParameter("billing_charge_r"+lNumRec) == null )
          outDmCustAgreementTabObj.billing_charge = 0;
        else
        if ( inRequest.getParameter("billing_charge_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.billing_charge = 0;
        else
          outDmCustAgreementTabObj.billing_charge = Double.parseDouble( inRequest.getParameter("billing_charge_r"+lNumRec));
        if ( inRequest.getParameter("paying_charge_r"+lNumRec) == null )
          outDmCustAgreementTabObj.paying_charge = 0;
        else
        if ( inRequest.getParameter("paying_charge_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.paying_charge = 0;
        else
          outDmCustAgreementTabObj.paying_charge = Double.parseDouble( inRequest.getParameter("paying_charge_r"+lNumRec));
        outDmCustAgreementTabObj.vacation_code = inRequest.getParameter("vacation_code_r"+lNumRec);
        if ( inRequest.getParameter("leave_quota_r"+lNumRec) == null )
          outDmCustAgreementTabObj.leave_quota = 0;
        else
        if ( inRequest.getParameter("leave_quota_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.leave_quota = 0;
        else
          outDmCustAgreementTabObj.leave_quota = Integer.parseInt( inRequest.getParameter("leave_quota_r"+lNumRec));
        outDmCustAgreementTabObj.salary_flag = inRequest.getParameter("salary_flag_r"+lNumRec);
        outDmCustAgreementTabObj.active_flag = inRequest.getParameter("active_flag_r"+lNumRec);
        outDmCustAgreementTabObj.tax_flag = inRequest.getParameter("tax_flag_r"+lNumRec);
        if ( inRequest.getParameter("tax_percent_r"+lNumRec) == null )
          outDmCustAgreementTabObj.tax_percent = 0;
        else
        if ( inRequest.getParameter("tax_percent_r"+lNumRec).trim().length() == 0 )
          outDmCustAgreementTabObj.tax_percent = 0;
        else
          outDmCustAgreementTabObj.tax_percent = Float.parseFloat( inRequest.getParameter("tax_percent_r"+lNumRec));
        outDmCustAgreementTabObj.sal_deduction_flag = inRequest.getParameter("sal_deduction_flag_r"+lNumRec);
        outDmCustAgreementTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        outDmCustAgreementTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
        outDmCustAgreementTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
        outDmCustAgreementTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        outDmCustAgreementTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        outDmCustAgreementTabObj.wages_print_ind = inRequest.getParameter("wages_print_ind_r"+lNumRec);
        outDmCustAgreementTabObj.wages_tot_calc_ind = inRequest.getParameter("wages_tot_calc_ind_r"+lNumRec);
        outDmCustAgreementTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        outDmCustAgreementTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outDmCustAgreementTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outDmCustAgreementTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outDmCustAgreementTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outDmCustAgreementTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        outDmCustAgreementTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        outDmCustAgreementTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        outDmCustAgreementTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popDmCustAgreementReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outDmCustAgreementTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      DmCustAgreementTabObj lDmCustAgreementTabObj= new DmCustAgreementTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("dm_cust_agreement_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lDmCustAgreementTabObj.tab_rowid = lTabRowidValue;

        lDmCustAgreementTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lDmCustAgreementTabObj.customer_id = inRequest.getParameter("customer_id_r"+lNumRec);
        lDmCustAgreementTabObj.rp_id = inRequest.getParameter("rp_id_r"+lNumRec);
        lDmCustAgreementTabObj.allowance_id = inRequest.getParameter("allowance_id_r"+lNumRec);
        lDmCustAgreementTabObj.dept_id = inRequest.getParameter("dept_id_r"+lNumRec);
        lDmCustAgreementTabObj.position_id = inRequest.getParameter("position_id_r"+lNumRec);
        lDmCustAgreementTabObj.level_id = inRequest.getParameter("level_id_r"+lNumRec);
        if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
          lDmCustAgreementTabObj.seq_num = 0;
        else
        if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.seq_num = 0;
        else
          lDmCustAgreementTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
        lDmCustAgreementTabObj.benefit_flag = inRequest.getParameter("benefit_flag_r"+lNumRec);
        lDmCustAgreementTabObj.allowance_type = inRequest.getParameter("allowance_type_r"+lNumRec);
        lDmCustAgreementTabObj.amount_flag = inRequest.getParameter("amount_flag_r"+lNumRec);
        if ( inRequest.getParameter("default_amount_r"+lNumRec) == null )
          lDmCustAgreementTabObj.default_amount = 0;
        else
        if ( inRequest.getParameter("default_amount_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.default_amount = 0;
        else
            lDmCustAgreementTabObj.default_amount = Double.parseDouble( inRequest.getParameter("default_amount_r"+lNumRec));
        if ( inRequest.getParameter("billing_charge_r"+lNumRec) == null )
          lDmCustAgreementTabObj.billing_charge = 0;
        else
        if ( inRequest.getParameter("billing_charge_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.billing_charge = 0;
        else
            lDmCustAgreementTabObj.billing_charge = Double.parseDouble( inRequest.getParameter("billing_charge_r"+lNumRec));
        if ( inRequest.getParameter("paying_charge_r"+lNumRec) == null )
          lDmCustAgreementTabObj.paying_charge = 0;
        else
        if ( inRequest.getParameter("paying_charge_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.paying_charge = 0;
        else
            lDmCustAgreementTabObj.paying_charge = Double.parseDouble( inRequest.getParameter("paying_charge_r"+lNumRec));
        lDmCustAgreementTabObj.vacation_code = inRequest.getParameter("vacation_code_r"+lNumRec);
        if ( inRequest.getParameter("leave_quota_r"+lNumRec) == null )
          lDmCustAgreementTabObj.leave_quota = 0;
        else
        if ( inRequest.getParameter("leave_quota_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.leave_quota = 0;
        else
          lDmCustAgreementTabObj.leave_quota = Integer.parseInt( inRequest.getParameter("leave_quota_r"+lNumRec));
        lDmCustAgreementTabObj.salary_flag = inRequest.getParameter("salary_flag_r"+lNumRec);
        lDmCustAgreementTabObj.active_flag = inRequest.getParameter("active_flag_r"+lNumRec);
        lDmCustAgreementTabObj.tax_flag = inRequest.getParameter("tax_flag_r"+lNumRec);
        if ( inRequest.getParameter("tax_percent_r"+lNumRec) == null )
          lDmCustAgreementTabObj.tax_percent = 0;
        else
        if ( inRequest.getParameter("tax_percent_r"+lNumRec).trim().length() == 0 )
          lDmCustAgreementTabObj.tax_percent = 0;
        else
            lDmCustAgreementTabObj.tax_percent = Float.parseFloat( inRequest.getParameter("tax_percent_r"+lNumRec));
        lDmCustAgreementTabObj.sal_deduction_flag = inRequest.getParameter("sal_deduction_flag_r"+lNumRec);
        lDmCustAgreementTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        lDmCustAgreementTabObj.agreement_sts = inRequest.getParameter("agreement_sts_r"+lNumRec);
        lDmCustAgreementTabObj.agreement_sts_date = inRequest.getParameter("agreement_sts_date_r"+lNumRec);
        lDmCustAgreementTabObj.effective_date = inRequest.getParameter("effective_date_r"+lNumRec);
        lDmCustAgreementTabObj.expiration_date = inRequest.getParameter("expiration_date_r"+lNumRec);
        lDmCustAgreementTabObj.wages_print_ind = inRequest.getParameter("wages_print_ind_r"+lNumRec);
        lDmCustAgreementTabObj.wages_tot_calc_ind = inRequest.getParameter("wages_tot_calc_ind_r"+lNumRec);
        lDmCustAgreementTabObj.rec_status = inRequest.getParameter("rec_status_r"+lNumRec);
        lDmCustAgreementTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lDmCustAgreementTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lDmCustAgreementTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lDmCustAgreementTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        lDmCustAgreementTabObj.file_name = inRequest.getParameter("file_name_r"+lNumRec);
        lDmCustAgreementTabObj.file_cre_date = inRequest.getParameter("file_cre_date_r"+lNumRec);
        lDmCustAgreementTabObj.file_cre_time = inRequest.getParameter("file_cre_time_r"+lNumRec);
        lDmCustAgreementTabObj.file_status = inRequest.getParameter("file_status_r"+lNumRec);
        outDmCustAgreementTabObjArr.add( lDmCustAgreementTabObj);
      }
    }
    return lReturnValue;
  }





  public int updDmCustAgreementRecByRowid
               ( String inRowId
               , DmCustAgreementTabObj  inDmCustAgreementTabObj
               )
  {
    int lUpdateCount;
    sop("updDmCustAgreementRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updDmCustAgreementRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustAgreementTabObj.agreement_sts_date != null && inDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.effective_date != null && inDmCustAgreementTabObj.effective_date.length() > 0 ) 
            inDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.expiration_date != null && inDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            inDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_cre_date != null && inDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_upd_date != null && inDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.file_cre_date != null && inDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUST_AGREEMENT ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inDmCustAgreementTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmCustAgreementTabObj.org_id+"', ";
      if ( inDmCustAgreementTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmCustAgreementTabObj.customer_id+"', ";
      if ( inDmCustAgreementTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = "+"'"+inDmCustAgreementTabObj.rp_id+"', ";
      if ( inDmCustAgreementTabObj.allowance_id != null  )         lSqlStmt = lSqlStmt + "allowance_id = "+"'"+inDmCustAgreementTabObj.allowance_id+"', ";
      if ( inDmCustAgreementTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmCustAgreementTabObj.dept_id+"', ";
      if ( inDmCustAgreementTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmCustAgreementTabObj.position_id+"', ";
      if ( inDmCustAgreementTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmCustAgreementTabObj.level_id+"', ";
             lSqlStmt = lSqlStmt + "seq_num = "+inDmCustAgreementTabObj.seq_num+", ";
      if ( inDmCustAgreementTabObj.benefit_flag != null  )         lSqlStmt = lSqlStmt + "benefit_flag = "+"'"+inDmCustAgreementTabObj.benefit_flag+"', ";
      if ( inDmCustAgreementTabObj.allowance_type != null  )         lSqlStmt = lSqlStmt + "allowance_type = "+"'"+inDmCustAgreementTabObj.allowance_type+"', ";
      if ( inDmCustAgreementTabObj.amount_flag != null  )         lSqlStmt = lSqlStmt + "amount_flag = "+"'"+inDmCustAgreementTabObj.amount_flag+"', ";
             lSqlStmt = lSqlStmt + "default_amount = "+inDmCustAgreementTabObj.default_amount+", ";
             lSqlStmt = lSqlStmt + "billing_charge = "+inDmCustAgreementTabObj.billing_charge+", ";
             lSqlStmt = lSqlStmt + "paying_charge = "+inDmCustAgreementTabObj.paying_charge+", ";
      if ( inDmCustAgreementTabObj.vacation_code != null  )         lSqlStmt = lSqlStmt + "vacation_code = "+"'"+inDmCustAgreementTabObj.vacation_code+"', ";
             lSqlStmt = lSqlStmt + "leave_quota = "+inDmCustAgreementTabObj.leave_quota+", ";
      if ( inDmCustAgreementTabObj.salary_flag != null  )         lSqlStmt = lSqlStmt + "salary_flag = "+"'"+inDmCustAgreementTabObj.salary_flag+"', ";
      if ( inDmCustAgreementTabObj.active_flag != null  )         lSqlStmt = lSqlStmt + "active_flag = "+"'"+inDmCustAgreementTabObj.active_flag+"', ";
      if ( inDmCustAgreementTabObj.tax_flag != null  )         lSqlStmt = lSqlStmt + "tax_flag = "+"'"+inDmCustAgreementTabObj.tax_flag+"', ";
             lSqlStmt = lSqlStmt + "tax_percent = "+inDmCustAgreementTabObj.tax_percent+", ";
      if ( inDmCustAgreementTabObj.sal_deduction_flag != null  )         lSqlStmt = lSqlStmt + "sal_deduction_flag = "+"'"+inDmCustAgreementTabObj.sal_deduction_flag+"', ";
      if ( inDmCustAgreementTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inDmCustAgreementTabObj.remark+"', ";
      if ( inDmCustAgreementTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = "+"'"+inDmCustAgreementTabObj.agreement_sts+"', ";
      if ( inDmCustAgreementTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = "+"'"+inDmCustAgreementTabObj.agreement_sts_date+"', ";
      if ( inDmCustAgreementTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inDmCustAgreementTabObj.effective_date+"', ";
      if ( inDmCustAgreementTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inDmCustAgreementTabObj.expiration_date+"', ";
      if ( inDmCustAgreementTabObj.wages_print_ind != null  )         lSqlStmt = lSqlStmt + "wages_print_ind = "+"'"+inDmCustAgreementTabObj.wages_print_ind+"', ";
      if ( inDmCustAgreementTabObj.wages_tot_calc_ind != null  )         lSqlStmt = lSqlStmt + "wages_tot_calc_ind = "+"'"+inDmCustAgreementTabObj.wages_tot_calc_ind+"', ";
      if ( inDmCustAgreementTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmCustAgreementTabObj.rec_status+"', ";
      if ( inDmCustAgreementTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmCustAgreementTabObj.rec_cre_date+"', ";
      if ( inDmCustAgreementTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmCustAgreementTabObj.rec_cre_time+"', ";
      if ( inDmCustAgreementTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmCustAgreementTabObj.rec_upd_date+"', ";
      if ( inDmCustAgreementTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmCustAgreementTabObj.rec_upd_time+"', ";
      if ( inDmCustAgreementTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmCustAgreementTabObj.file_name+"', ";
      if ( inDmCustAgreementTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmCustAgreementTabObj.file_cre_date+"', ";
      if ( inDmCustAgreementTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmCustAgreementTabObj.file_cre_time+"', ";
      if ( inDmCustAgreementTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmCustAgreementTabObj.file_status+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustAgreementRecByPkey
               ( DmCustAgreementPkeyObj inDmCustAgreementPkeyObj
               , DmCustAgreementTabObj  inDmCustAgreementTabObj
               )
  {
    int lUpdateCount;
    sop("updDmCustAgreementRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updDmCustAgreementRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inDmCustAgreementTabObj.agreement_sts_date != null && inDmCustAgreementTabObj.agreement_sts_date.length() > 0 ) 
            inDmCustAgreementTabObj.agreement_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.agreement_sts_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.effective_date != null && inDmCustAgreementTabObj.effective_date.length() > 0 ) 
            inDmCustAgreementTabObj.effective_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.effective_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.expiration_date != null && inDmCustAgreementTabObj.expiration_date.length() > 0 ) 
            inDmCustAgreementTabObj.expiration_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.expiration_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_cre_date != null && inDmCustAgreementTabObj.rec_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.rec_upd_date != null && inDmCustAgreementTabObj.rec_upd_date.length() > 0 ) 
            inDmCustAgreementTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.rec_upd_date, lDateTimeSrcFmt);

          if ( inDmCustAgreementTabObj.file_cre_date != null && inDmCustAgreementTabObj.file_cre_date.length() > 0 ) 
            inDmCustAgreementTabObj.file_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inDmCustAgreementTabObj.file_cre_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUST_AGREEMENT ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inDmCustAgreementTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inDmCustAgreementTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = ? , ";
        if ( inDmCustAgreementTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = ? , ";
        if ( inDmCustAgreementTabObj.allowance_id != null  )         lSqlStmt = lSqlStmt + "allowance_id = ? , ";
        if ( inDmCustAgreementTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = ? , ";
        if ( inDmCustAgreementTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = ? , ";
        if ( inDmCustAgreementTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = ? , ";
               lSqlStmt = lSqlStmt + "seq_num = ? , ";
        if ( inDmCustAgreementTabObj.benefit_flag != null  )         lSqlStmt = lSqlStmt + "benefit_flag = ? , ";
        if ( inDmCustAgreementTabObj.allowance_type != null  )         lSqlStmt = lSqlStmt + "allowance_type = ? , ";
        if ( inDmCustAgreementTabObj.amount_flag != null  )         lSqlStmt = lSqlStmt + "amount_flag = ? , ";
               lSqlStmt = lSqlStmt + "default_amount = ? , ";
               lSqlStmt = lSqlStmt + "billing_charge = ? , ";
               lSqlStmt = lSqlStmt + "paying_charge = ? , ";
        if ( inDmCustAgreementTabObj.vacation_code != null  )         lSqlStmt = lSqlStmt + "vacation_code = ? , ";
               lSqlStmt = lSqlStmt + "leave_quota = ? , ";
        if ( inDmCustAgreementTabObj.salary_flag != null  )         lSqlStmt = lSqlStmt + "salary_flag = ? , ";
        if ( inDmCustAgreementTabObj.active_flag != null  )         lSqlStmt = lSqlStmt + "active_flag = ? , ";
        if ( inDmCustAgreementTabObj.tax_flag != null  )         lSqlStmt = lSqlStmt + "tax_flag = ? , ";
               lSqlStmt = lSqlStmt + "tax_percent = ? , ";
        if ( inDmCustAgreementTabObj.sal_deduction_flag != null  )         lSqlStmt = lSqlStmt + "sal_deduction_flag = ? , ";
        if ( inDmCustAgreementTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
        if ( inDmCustAgreementTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = ? , ";
        if ( inDmCustAgreementTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = ? , ";
        if ( inDmCustAgreementTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = ? , ";
        if ( inDmCustAgreementTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = ? , ";
        if ( inDmCustAgreementTabObj.wages_print_ind != null  )         lSqlStmt = lSqlStmt + "wages_print_ind = ? , ";
        if ( inDmCustAgreementTabObj.wages_tot_calc_ind != null  )         lSqlStmt = lSqlStmt + "wages_tot_calc_ind = ? , ";
        if ( inDmCustAgreementTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = ? , ";
        if ( inDmCustAgreementTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inDmCustAgreementTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inDmCustAgreementTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inDmCustAgreementTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( inDmCustAgreementTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = ? , ";
        if ( inDmCustAgreementTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = ? , ";
        if ( inDmCustAgreementTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = ? , ";
        if ( inDmCustAgreementTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inDmCustAgreementTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inDmCustAgreementTabObj.org_id+"', ";
        if ( inDmCustAgreementTabObj.customer_id != null  )         lSqlStmt = lSqlStmt + "customer_id = "+"'"+inDmCustAgreementTabObj.customer_id+"', ";
        if ( inDmCustAgreementTabObj.rp_id != null  )         lSqlStmt = lSqlStmt + "rp_id = "+"'"+inDmCustAgreementTabObj.rp_id+"', ";
        if ( inDmCustAgreementTabObj.allowance_id != null  )         lSqlStmt = lSqlStmt + "allowance_id = "+"'"+inDmCustAgreementTabObj.allowance_id+"', ";
        if ( inDmCustAgreementTabObj.dept_id != null  )         lSqlStmt = lSqlStmt + "dept_id = "+"'"+inDmCustAgreementTabObj.dept_id+"', ";
        if ( inDmCustAgreementTabObj.position_id != null  )         lSqlStmt = lSqlStmt + "position_id = "+"'"+inDmCustAgreementTabObj.position_id+"', ";
        if ( inDmCustAgreementTabObj.level_id != null  )         lSqlStmt = lSqlStmt + "level_id = "+"'"+inDmCustAgreementTabObj.level_id+"', ";
               lSqlStmt = lSqlStmt + "seq_num = "+inDmCustAgreementTabObj.seq_num+", ";
        if ( inDmCustAgreementTabObj.benefit_flag != null  )         lSqlStmt = lSqlStmt + "benefit_flag = "+"'"+inDmCustAgreementTabObj.benefit_flag+"', ";
        if ( inDmCustAgreementTabObj.allowance_type != null  )         lSqlStmt = lSqlStmt + "allowance_type = "+"'"+inDmCustAgreementTabObj.allowance_type+"', ";
        if ( inDmCustAgreementTabObj.amount_flag != null  )         lSqlStmt = lSqlStmt + "amount_flag = "+"'"+inDmCustAgreementTabObj.amount_flag+"', ";
               lSqlStmt = lSqlStmt + "default_amount = "+inDmCustAgreementTabObj.default_amount+", ";
               lSqlStmt = lSqlStmt + "billing_charge = "+inDmCustAgreementTabObj.billing_charge+", ";
               lSqlStmt = lSqlStmt + "paying_charge = "+inDmCustAgreementTabObj.paying_charge+", ";
        if ( inDmCustAgreementTabObj.vacation_code != null  )         lSqlStmt = lSqlStmt + "vacation_code = "+"'"+inDmCustAgreementTabObj.vacation_code+"', ";
               lSqlStmt = lSqlStmt + "leave_quota = "+inDmCustAgreementTabObj.leave_quota+", ";
        if ( inDmCustAgreementTabObj.salary_flag != null  )         lSqlStmt = lSqlStmt + "salary_flag = "+"'"+inDmCustAgreementTabObj.salary_flag+"', ";
        if ( inDmCustAgreementTabObj.active_flag != null  )         lSqlStmt = lSqlStmt + "active_flag = "+"'"+inDmCustAgreementTabObj.active_flag+"', ";
        if ( inDmCustAgreementTabObj.tax_flag != null  )         lSqlStmt = lSqlStmt + "tax_flag = "+"'"+inDmCustAgreementTabObj.tax_flag+"', ";
               lSqlStmt = lSqlStmt + "tax_percent = "+inDmCustAgreementTabObj.tax_percent+", ";
        if ( inDmCustAgreementTabObj.sal_deduction_flag != null  )         lSqlStmt = lSqlStmt + "sal_deduction_flag = "+"'"+inDmCustAgreementTabObj.sal_deduction_flag+"', ";
        if ( inDmCustAgreementTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inDmCustAgreementTabObj.remark+"', ";
        if ( inDmCustAgreementTabObj.agreement_sts != null  )         lSqlStmt = lSqlStmt + "agreement_sts = "+"'"+inDmCustAgreementTabObj.agreement_sts+"', ";
        if ( inDmCustAgreementTabObj.agreement_sts_date != null  )         lSqlStmt = lSqlStmt + "agreement_sts_date = "+"'"+inDmCustAgreementTabObj.agreement_sts_date+"', ";
        if ( inDmCustAgreementTabObj.effective_date != null  )         lSqlStmt = lSqlStmt + "effective_date = "+"'"+inDmCustAgreementTabObj.effective_date+"', ";
        if ( inDmCustAgreementTabObj.expiration_date != null  )         lSqlStmt = lSqlStmt + "expiration_date = "+"'"+inDmCustAgreementTabObj.expiration_date+"', ";
        if ( inDmCustAgreementTabObj.wages_print_ind != null  )         lSqlStmt = lSqlStmt + "wages_print_ind = "+"'"+inDmCustAgreementTabObj.wages_print_ind+"', ";
        if ( inDmCustAgreementTabObj.wages_tot_calc_ind != null  )         lSqlStmt = lSqlStmt + "wages_tot_calc_ind = "+"'"+inDmCustAgreementTabObj.wages_tot_calc_ind+"', ";
        if ( inDmCustAgreementTabObj.rec_status != null  )         lSqlStmt = lSqlStmt + "rec_status = "+"'"+inDmCustAgreementTabObj.rec_status+"', ";
        if ( inDmCustAgreementTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inDmCustAgreementTabObj.rec_cre_date+"', ";
        if ( inDmCustAgreementTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inDmCustAgreementTabObj.rec_cre_time+"', ";
        if ( inDmCustAgreementTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inDmCustAgreementTabObj.rec_upd_date+"', ";
        if ( inDmCustAgreementTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inDmCustAgreementTabObj.rec_upd_time+"', ";
        if ( inDmCustAgreementTabObj.file_name != null  )         lSqlStmt = lSqlStmt + "file_name = "+"'"+inDmCustAgreementTabObj.file_name+"', ";
        if ( inDmCustAgreementTabObj.file_cre_date != null  )         lSqlStmt = lSqlStmt + "file_cre_date = "+"'"+inDmCustAgreementTabObj.file_cre_date+"', ";
        if ( inDmCustAgreementTabObj.file_cre_time != null  )         lSqlStmt = lSqlStmt + "file_cre_time = "+"'"+inDmCustAgreementTabObj.file_cre_time+"', ";
        if ( inDmCustAgreementTabObj.file_status != null  )         lSqlStmt = lSqlStmt + "file_status = "+"'"+inDmCustAgreementTabObj.file_status+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmCustAgreementPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustAgreementPkeyObj.customer_id+"' and "+
                              "rp_id = "+"'"+inDmCustAgreementPkeyObj.rp_id+"' and "+
                              "allowance_id = "+"'"+inDmCustAgreementPkeyObj.allowance_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inDmCustAgreementTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.org_id); } 
         if ( inDmCustAgreementTabObj.customer_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.customer_id); } 
         if ( inDmCustAgreementTabObj.rp_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rp_id); } 
         if ( inDmCustAgreementTabObj.allowance_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.allowance_id); } 
         if ( inDmCustAgreementTabObj.dept_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.dept_id); } 
         if ( inDmCustAgreementTabObj.position_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.position_id); } 
         if ( inDmCustAgreementTabObj.level_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.level_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(8, inDmCustAgreementTabObj.seq_num);
         if ( inDmCustAgreementTabObj.benefit_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.benefit_flag); } 
         if ( inDmCustAgreementTabObj.allowance_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.allowance_type); } 
         if ( inDmCustAgreementTabObj.amount_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.amount_flag); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(12, inDmCustAgreementTabObj.default_amount);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(13, inDmCustAgreementTabObj.billing_charge);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(14, inDmCustAgreementTabObj.paying_charge);
         if ( inDmCustAgreementTabObj.vacation_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.vacation_code); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(16, inDmCustAgreementTabObj.leave_quota);
         if ( inDmCustAgreementTabObj.salary_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.salary_flag); } 
         if ( inDmCustAgreementTabObj.active_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.active_flag); } 
         if ( inDmCustAgreementTabObj.tax_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.tax_flag); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(20, inDmCustAgreementTabObj.tax_percent);
         if ( inDmCustAgreementTabObj.sal_deduction_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.sal_deduction_flag); } 
         if ( inDmCustAgreementTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.remark); } 
         if ( inDmCustAgreementTabObj.agreement_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.agreement_sts); } 
         if ( inDmCustAgreementTabObj.agreement_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.agreement_sts_date); } 
         if ( inDmCustAgreementTabObj.effective_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.effective_date); } 
         if ( inDmCustAgreementTabObj.expiration_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.expiration_date); } 
         if ( inDmCustAgreementTabObj.wages_print_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.wages_print_ind); } 
         if ( inDmCustAgreementTabObj.wages_tot_calc_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.wages_tot_calc_ind); } 
         if ( inDmCustAgreementTabObj.rec_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rec_status); } 
         if ( inDmCustAgreementTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rec_cre_date); } 
         if ( inDmCustAgreementTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rec_cre_time); } 
         if ( inDmCustAgreementTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rec_upd_date); } 
         if ( inDmCustAgreementTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.rec_upd_time); } 
         if ( inDmCustAgreementTabObj.file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.file_name); } 
         if ( inDmCustAgreementTabObj.file_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.file_cre_date); } 
         if ( inDmCustAgreementTabObj.file_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.file_cre_time); } 
         if ( inDmCustAgreementTabObj.file_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inDmCustAgreementTabObj.file_status); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustAgreementRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delDmCustAgreementRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delDmCustAgreementRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   DM_CUST_AGREEMENT "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustAgreementRecByPkeyWithSet
               ( DmCustAgreementPkeyObj inDmCustAgreementPkeyObj
               , String  inDmCustAgreementSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustAgreementRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustAgreementRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUST_AGREEMENT ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmCustAgreementSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inDmCustAgreementPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustAgreementPkeyObj.customer_id+"' and "+
                              "rp_id = "+"'"+inDmCustAgreementPkeyObj.rp_id+"' and "+
                              "allowance_id = "+"'"+inDmCustAgreementPkeyObj.allowance_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustAgreementRecByRowidWithSet
               ( String inRowId
               , String  inDmCustAgreementSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustAgreementRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustAgreementRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUST_AGREEMENT ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inDmCustAgreementSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updDmCustAgreementRecByWhereWithSet
               ( String inDmCustAgreementWhereText
               , String  inDmCustAgreementSetlist
               )
  {
    int lUpdateCount;
    sop("updDmCustAgreementRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updDmCustAgreementRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE DM_CUST_AGREEMENT ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inDmCustAgreementSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustAgreementRecByPkey
               ( DmCustAgreementPkeyObj  inDmCustAgreementPkeyObj
               )
  {
    int lUpdateCount;
    sop("delDmCustAgreementRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delDmCustAgreementRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   DM_CUST_AGREEMENT " + 
                         "WHERE "+
                              "org_id = "+"'"+inDmCustAgreementPkeyObj.org_id+"' and "+
                              "customer_id = "+"'"+inDmCustAgreementPkeyObj.customer_id+"' and "+
                              "rp_id = "+"'"+inDmCustAgreementPkeyObj.rp_id+"' and "+
                              "allowance_id = "+"'"+inDmCustAgreementPkeyObj.allowance_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delDmCustAgreementByWhere
               ( String inDmCustAgreementWhereText
               )
  {
    int lUpdateCount;
    sop("delDmCustAgreementByWhere - Started");
    gSSTErrorObj.sourceMethod = "delDmCustAgreementByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inDmCustAgreementWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inDmCustAgreementWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   DM_CUST_AGREEMENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
