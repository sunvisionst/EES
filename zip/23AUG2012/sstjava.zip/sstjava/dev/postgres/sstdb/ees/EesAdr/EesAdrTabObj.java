package sstdb.ees.EesAdr;


public class EesAdrTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 employee_id;
  public byte                                  period_num;
  public String                                 adr_date;
  public String                                 topic_id;
  public String                                 adr_start_time;
  public String                                 adr_end_time;
  public String                                 lecture_num;
  public String                                 subject_code;
  public float                                 topic_percent_covered;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;





  public short                                  org_id_ind;
  public short                                  employee_id_ind;
  public short                                  period_num_ind;
  public short                                  adr_date_ind;
  public short                                  topic_id_ind;
  public short                                  adr_start_time_ind;
  public short                                  adr_end_time_ind;
  public short                                  lecture_num_ind;
  public short                                  subject_code_ind;
  public short                                  topic_percent_covered_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;


  public EesAdrTabObj(){}


  public EesAdrTabObj
  (
    String org_id,
    String employee_id,
    byte period_num,
    String adr_date,
    String topic_id,
    String adr_start_time,
    String adr_end_time,
    String lecture_num,
    String subject_code,
    float topic_percent_covered,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream
  )
  {
     this.org_id = org_id;
     this.employee_id = employee_id;
     this.period_num = period_num;
     this.adr_date = adr_date;
     this.topic_id = topic_id;
     this.adr_start_time = adr_start_time;
     this.adr_end_time = adr_end_time;
     this.lecture_num = lecture_num;
     this.subject_code = subject_code;
     this.topic_percent_covered = topic_percent_covered;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
  }

  public String getorg_id()                           { return org_id; }
  public String getemployee_id()                        { return employee_id; }
  public byte getperiod_num()                          { return period_num; }
  public String getadr_date()                          { return adr_date; }
  public String gettopic_id()                          { return topic_id; }
  public String getadr_start_time()                       { return adr_start_time; }
  public String getadr_end_time()                        { return adr_end_time; }
  public String getlecture_num()                        { return lecture_num; }
  public String getsubject_code()                        { return subject_code; }
  public float gettopic_percent_covered()                    { return topic_percent_covered; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setemployee_id(String employee_id )               { this.employee_id = employee_id; }
  public void  setperiod_num(byte period_num )                 { this.period_num = period_num; }
  public void  setadr_date(String adr_date )                  { this.adr_date = adr_date; }
  public void  settopic_id(String topic_id )                  { this.topic_id = topic_id; }
  public void  setadr_start_time(String adr_start_time )            { this.adr_start_time = adr_start_time; }
  public void  setadr_end_time(String adr_end_time )              { this.adr_end_time = adr_end_time; }
  public void  setlecture_num(String lecture_num )               { this.lecture_num = lecture_num; }
  public void  setsubject_code(String subject_code )              { this.subject_code = subject_code; }
  public void  settopic_percent_covered(float topic_percent_covered )      { this.topic_percent_covered = topic_percent_covered; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
}