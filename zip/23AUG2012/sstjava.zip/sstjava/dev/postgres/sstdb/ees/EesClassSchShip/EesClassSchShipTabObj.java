package sstdb.ees.EesClassSchShip;


public class EesClassSchShipTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 scholorship_id;
  public String                                 class_id;
  public double                                 scholorship_amt;
  public String                                 start_date;
  public String                                 end_date;
  public String                                 scholorship_status;





  public short                                  org_id_ind;
  public short                                  scholorship_id_ind;
  public short                                  class_id_ind;
  public short                                  scholorship_amt_ind;
  public short                                  start_date_ind;
  public short                                  end_date_ind;
  public short                                  scholorship_status_ind;


  public EesClassSchShipTabObj(){}


  public EesClassSchShipTabObj
  (
    String org_id,
    String scholorship_id,
    String class_id,
    double scholorship_amt,
    String start_date,
    String end_date,
    String scholorship_status
  )
  {
     this.org_id = org_id;
     this.scholorship_id = scholorship_id;
     this.class_id = class_id;
     this.scholorship_amt = scholorship_amt;
     this.start_date = start_date;
     this.end_date = end_date;
     this.scholorship_status = scholorship_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getscholorship_id()                       { return scholorship_id; }
  public String getclass_id()                          { return class_id; }
  public double getscholorship_amt()                      { return scholorship_amt; }
  public String getstart_date()                         { return start_date; }
  public String getend_date()                          { return end_date; }
  public String getscholorship_status()                     { return scholorship_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setscholorship_id(String scholorship_id )            { this.scholorship_id = scholorship_id; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setscholorship_amt(double scholorship_amt )           { this.scholorship_amt = scholorship_amt; }
  public void  setstart_date(String start_date )                { this.start_date = start_date; }
  public void  setend_date(String end_date )                  { this.end_date = end_date; }
  public void  setscholorship_status(String scholorship_status )        { this.scholorship_status = scholorship_status; }
}