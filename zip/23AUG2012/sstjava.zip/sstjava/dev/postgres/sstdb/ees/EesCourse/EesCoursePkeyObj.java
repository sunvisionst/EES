package sstdb.ees.EesCourse;


public class EesCoursePkeyObj
{
  public String                                 org_id;
  public String                                 course_id;
}