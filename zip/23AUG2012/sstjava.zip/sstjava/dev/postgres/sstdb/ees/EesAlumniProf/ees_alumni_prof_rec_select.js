function EesAlumniProfRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("student_org_id").value  = document.getElementById("student_org_id"+"_r"+inRecNum).value;
    document.getElementById("student_org_id").readOnly = true;
    document.getElementById("alumni_id").value  = document.getElementById("alumni_id"+"_r"+inRecNum).value;
    document.getElementById("alumni_id").readOnly = true;
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("seq_num").readOnly = true;
    document.getElementById("occupation").value  = document.getElementById("occupation"+"_r"+inRecNum).value;
    document.getElementById("designation").value  = document.getElementById("designation"+"_r"+inRecNum).value;
    document.getElementById("joining_date").value  = document.getElementById("joining_date"+"_r"+inRecNum).value;
    document.getElementById("org_name").value  = document.getElementById("org_name"+"_r"+inRecNum).value;
    document.getElementById("working_tech").value  = document.getElementById("working_tech"+"_r"+inRecNum).value;
    document.getElementById("area_of_interest").value  = document.getElementById("area_of_interest"+"_r"+inRecNum).value;
    document.getElementById("web_page_ind").value  = document.getElementById("web_page_ind"+"_r"+inRecNum).value;
    document.getElementById("office_address1").value  = document.getElementById("office_address1"+"_r"+inRecNum).value;
    document.getElementById("office_address2").value  = document.getElementById("office_address2"+"_r"+inRecNum).value;
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value;
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value;
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value;
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value;
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("student_org_id").value = '';
    document.getElementById("student_org_id").readOnly = false;
    document.getElementById("alumni_id").value = '';
    document.getElementById("alumni_id").readOnly = false;
    document.getElementById("seq_num").value = '';
    document.getElementById("seq_num").readOnly = false;
    document.getElementById("occupation").value = '';
    document.getElementById("designation").value = '';
    document.getElementById("joining_date").value = '';
    document.getElementById("org_name").value = '';
    document.getElementById("working_tech").value = '';
    document.getElementById("area_of_interest").value = '';
    document.getElementById("web_page_ind").value = '';
    document.getElementById("office_address1").value = '';
    document.getElementById("office_address2").value = '';
    document.getElementById("city").value = '';
    document.getElementById("state").value = '';
    document.getElementById("zip").value = '';
    document.getElementById("country").value = '';
    document.getElementById("phone_list").value = '';
    document.getElementById("email_list").value = '';
    document.getElementById("fax_list").value = '';
  }
}
