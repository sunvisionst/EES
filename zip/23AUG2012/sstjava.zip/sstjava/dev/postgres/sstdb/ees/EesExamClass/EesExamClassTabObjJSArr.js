
var lEesExamClassTabObjJSArr = new Array();
<%
{
   if ( lEesExamClassTabObjArrCache != null && lEesExamClassTabObjArrCache.size() > 0 )
   {
%>
       lEesExamClassTabObjJSArr = new Array(<%=lEesExamClassTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesExamClassTabObjArrCache.size(); lRecNum++ )
       {
          EesExamClassTabObj lEesExamClassTabObj    =    new EesExamClassTabObj();
          lEesExamClassTabObj = (EesExamClassTabObj)lEesExamClassTabObjArrCache.get(lRecNum);
%>
          lEesExamClassTabObjJSArr[<%=lRecNum%>] = new constructorEesExamClass
          (
          "<%=lEesExamClassTabObj.org_id%>",
          "<%=lEesExamClassTabObj.exam_id%>",
          "<%=lEesExamClassTabObj.class_id%>",
          "<%=lEesExamClassTabObj.class_num%>",
          "<%=lEesExamClassTabObj.class_std%>",
          "<%=lEesExamClassTabObj.class_section%>",
          "<%=lEesExamClassTabObj.course_id%>",
          "<%=lEesExamClassTabObj.course_term%>",
          "<%=lEesExamClassTabObj.course_stream%>",
          "<%=lEesExamClassTabObj.exam_term%>",
          "<%=lEesExamClassTabObj.exam_type%>",
          "<%=lEesExamClassTabObj.year%>",
          "<%=lEesExamClassTabObj.month%>",
          "<%=lEesExamClassTabObj.academic_session%>",
          "<%=lEesExamClassTabObj.exam_status%>",
          "<%=lEesExamClassTabObj.exam_status_date%>"
          );
<%
       }
   }
}
%>


