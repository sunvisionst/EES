
var lEesAppcPrevMarkTabObjJSArr = new Array();
<%
{
   if ( lEesAppcPrevMarkTabObjArrCache != null && lEesAppcPrevMarkTabObjArrCache.size() > 0 )
   {
%>
       lEesAppcPrevMarkTabObjJSArr = new Array(<%=lEesAppcPrevMarkTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAppcPrevMarkTabObjArrCache.size(); lRecNum++ )
       {
          EesAppcPrevMarkTabObj lEesAppcPrevMarkTabObj    =    new EesAppcPrevMarkTabObj();
          lEesAppcPrevMarkTabObj = (EesAppcPrevMarkTabObj)lEesAppcPrevMarkTabObjArrCache.get(lRecNum);
%>
          lEesAppcPrevMarkTabObjJSArr[<%=lRecNum%>] = new constructorEesAppcPrevMark
          (
          "<%=lEesAppcPrevMarkTabObj.org_id%>",
          "<%=lEesAppcPrevMarkTabObj.applicant_id%>",
          "<%=lEesAppcPrevMarkTabObj.stmm_1%>",
          "<%=lEesAppcPrevMarkTabObj.stmo_1%>",
          "<%=lEesAppcPrevMarkTabObj.spmm_1%>",
          "<%=lEesAppcPrevMarkTabObj.spmo_1%>",
          "<%=lEesAppcPrevMarkTabObj.stmm_2%>",
          "<%=lEesAppcPrevMarkTabObj.stmo_2%>",
          "<%=lEesAppcPrevMarkTabObj.spmm_2%>",
          "<%=lEesAppcPrevMarkTabObj.spmo_2%>",
          "<%=lEesAppcPrevMarkTabObj.stmm_3%>",
          "<%=lEesAppcPrevMarkTabObj.stmo_3%>",
          "<%=lEesAppcPrevMarkTabObj.spmm_3%>",
          "<%=lEesAppcPrevMarkTabObj.spmo_3%>",
          "<%=lEesAppcPrevMarkTabObj.stmm_4%>",
          "<%=lEesAppcPrevMarkTabObj.stmo_4%>",
          "<%=lEesAppcPrevMarkTabObj.spmm_4%>",
          "<%=lEesAppcPrevMarkTabObj.spmo_4%>",
          "<%=lEesAppcPrevMarkTabObj.adm_req_id_req%>",
          "<%=lEesAppcPrevMarkTabObj.adm_req_id_list%>"
          );
<%
       }
   }
}
%>


