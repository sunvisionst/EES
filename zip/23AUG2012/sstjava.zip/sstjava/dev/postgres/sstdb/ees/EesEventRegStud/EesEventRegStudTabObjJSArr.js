
var lEesEventRegStudTabObjJSArr = new Array();
<%
{
   if ( lEesEventRegStudTabObjArrCache != null && lEesEventRegStudTabObjArrCache.size() > 0 )
   {
%>
       lEesEventRegStudTabObjJSArr = new Array(<%=lEesEventRegStudTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesEventRegStudTabObjArrCache.size(); lRecNum++ )
       {
          EesEventRegStudTabObj lEesEventRegStudTabObj    =    new EesEventRegStudTabObj();
          lEesEventRegStudTabObj = (EesEventRegStudTabObj)lEesEventRegStudTabObjArrCache.get(lRecNum);
%>
          lEesEventRegStudTabObjJSArr[<%=lRecNum%>] = new constructorEesEventRegStud
          (
          "<%=lEesEventRegStudTabObj.org_id%>",
          "<%=lEesEventRegStudTabObj.activity_id%>",
          "<%=lEesEventRegStudTabObj.student_id%>",
          "<%=lEesEventRegStudTabObj.event_id%>",
          "<%=lEesEventRegStudTabObj.status%>",
          "<%=lEesEventRegStudTabObj.status_date%>"
          );
<%
       }
   }
}
%>


