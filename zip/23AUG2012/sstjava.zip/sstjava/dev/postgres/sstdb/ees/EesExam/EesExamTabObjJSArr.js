
var lEesExamTabObjJSArr = new Array();
<%
{
   if ( lEesExamTabObjArrCache != null && lEesExamTabObjArrCache.size() > 0 )
   {
%>
       lEesExamTabObjJSArr = new Array(<%=lEesExamTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesExamTabObjArrCache.size(); lRecNum++ )
       {
          EesExamTabObj lEesExamTabObj    =    new EesExamTabObj();
          lEesExamTabObj = (EesExamTabObj)lEesExamTabObjArrCache.get(lRecNum);
%>
          lEesExamTabObjJSArr[<%=lRecNum%>] = new constructorEesExam
          (
          "<%=lEesExamTabObj.org_id%>",
          "<%=lEesExamTabObj.exam_id%>",
          "<%=lEesExamTabObj.exam_term%>",
          "<%=lEesExamTabObj.exam_type%>",
          "<%=lEesExamTabObj.year%>",
          "<%=lEesExamTabObj.month%>",
          "<%=lEesExamTabObj.academic_session%>",
          "<%=lEesExamTabObj.exam_start_date%>",
          "<%=lEesExamTabObj.exam_end_date%>",
          "<%=lEesExamTabObj.exam_status%>",
          "<%=lEesExamTabObj.exam_status_date%>",
          "<%=lEesExamTabObj.exam_sch_status%>",
          "<%=lEesExamTabObj.sitting_plan_status%>",
          "<%=lEesExamTabObj.seat_alloc_status%>",
          "<%=lEesExamTabObj.exam_attn_status%>",
          "<%=lEesExamTabObj.mark_entry_status%>"
          );
<%
       }
   }
}
%>


