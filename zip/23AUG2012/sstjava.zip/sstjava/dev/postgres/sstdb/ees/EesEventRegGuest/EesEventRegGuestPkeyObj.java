package sstdb.ees.EesEventRegGuest;


public class EesEventRegGuestPkeyObj
{
  public String                                 org_id;
  public String                                 activity_id;
}