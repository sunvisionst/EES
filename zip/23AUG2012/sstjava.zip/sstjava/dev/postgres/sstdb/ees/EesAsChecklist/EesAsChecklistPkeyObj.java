package sstdb.ees.EesAsChecklist;


public class EesAsChecklistPkeyObj
{
  public String                                 org_id;
  public String                                 academic_session;
  public String                                 checklist_id;
}