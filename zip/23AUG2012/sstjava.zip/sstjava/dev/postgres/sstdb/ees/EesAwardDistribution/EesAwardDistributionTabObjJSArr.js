
var lEesAwardDistributionTabObjJSArr = new Array();
<%
{
   if ( lEesAwardDistributionTabObjArrCache != null && lEesAwardDistributionTabObjArrCache.size() > 0 )
   {
%>
       lEesAwardDistributionTabObjJSArr = new Array(<%=lEesAwardDistributionTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAwardDistributionTabObjArrCache.size(); lRecNum++ )
       {
          EesAwardDistributionTabObj lEesAwardDistributionTabObj    =    new EesAwardDistributionTabObj();
          lEesAwardDistributionTabObj = (EesAwardDistributionTabObj)lEesAwardDistributionTabObjArrCache.get(lRecNum);
%>
          lEesAwardDistributionTabObjJSArr[<%=lRecNum%>] = new constructorEesAwardDistribution
          (
          "<%=lEesAwardDistributionTabObj.org_id%>",
          "<%=lEesAwardDistributionTabObj.event_id%>",
          "<%=lEesAwardDistributionTabObj.awardee_id%>",
          "<%=lEesAwardDistributionTabObj.awardee_type%>",
          "<%=lEesAwardDistributionTabObj.award_id%>",
          "<%=lEesAwardDistributionTabObj.distribution_date%>",
          "<%=lEesAwardDistributionTabObj.distributed_by%>"
          );
<%
       }
   }
}
%>


