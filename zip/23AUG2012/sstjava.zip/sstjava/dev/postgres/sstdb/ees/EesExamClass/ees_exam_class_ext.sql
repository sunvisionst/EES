CREATE TABLE EES_EXAM_CLASS_EXT
(
  org_id                                                                                              VARCHAR(10),
  exam_id                                                                                             VARCHAR(10),
  class_id                                                                                            VARCHAR(20),
  class_num                                                                                           VARCHAR(10),
  class_std                                                                                           VARCHAR(10),
  class_section                                                                                       VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  course_term                                                                                         VARCHAR(10),
  course_stream                                                                                       VARCHAR(10),
  exam_term                                                                                           VARCHAR(10),
  exam_type                                                                                           VARCHAR(10),
  year                                                                                                NUMERIC(4),
  month                                                                                               NUMERIC(2),
  academic_session                                                                                    VARCHAR(11),
  exam_status                                                                                         VARCHAR(1),
  exam_status_date                                                                                    VARCHAR(8)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       EXAM_ID                                                                                             CHAR(10),
       CLASS_ID                                                                                            CHAR(20),
       CLASS_NUM                                                                                           CHAR(10),
       CLASS_STD                                                                                           CHAR(10),
       CLASS_SECTION                                                                                       CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       COURSE_TERM                                                                                         CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10),
       EXAM_TERM                                                                                           CHAR(10),
       EXAM_TYPE                                                                                           CHAR(10),
       YEAR                                                                                                CHAR(4),
       MONTH                                                                                               CHAR(2),
       ACADEMIC_SESSION                                                                                    CHAR(11),
       EXAM_STATUS                                                                                         CHAR(1),
       EXAM_STATUS_DATE                                                                                    CHAR(8)
    )
  )
  LOCATION ('ees_exam_class_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
