function EesDailyTripRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("wo_num").value  = document.getElementById("wo_num"+"_r"+inRecNum).value;
    document.getElementById("wo_num").readOnly = true;
    document.getElementById("wo_date").value  = document.getElementById("wo_date"+"_r"+inRecNum).value;
    document.getElementById("route_id").value  = document.getElementById("route_id"+"_r"+inRecNum).value;
    document.getElementById("trip_id").value  = document.getElementById("trip_id"+"_r"+inRecNum).value;
    document.getElementById("trip_num").value  = document.getElementById("trip_num"+"_r"+inRecNum).value;
    document.getElementById("vehicle_id").value  = document.getElementById("vehicle_id"+"_r"+inRecNum).value;
    document.getElementById("driver_id").value  = document.getElementById("driver_id"+"_r"+inRecNum).value;
    document.getElementById("start_time").value  = document.getElementById("start_time"+"_r"+inRecNum).value;
    document.getElementById("end_time").value  = document.getElementById("end_time"+"_r"+inRecNum).value;
    document.getElementById("omr").value  = document.getElementById("omr"+"_r"+inRecNum).value;
    document.getElementById("cmr").value  = document.getElementById("cmr"+"_r"+inRecNum).value;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("wo_num").value = '';
    document.getElementById("wo_num").readOnly = false;
    document.getElementById("wo_date").value = '';
    document.getElementById("route_id").value = '';
    document.getElementById("trip_id").value = '';
    document.getElementById("trip_num").value = '';
    document.getElementById("vehicle_id").value = '';
    document.getElementById("driver_id").value = '';
    document.getElementById("start_time").value = '';
    document.getElementById("end_time").value = '';
    document.getElementById("omr").value = '';
    document.getElementById("cmr").value = '';
    document.getElementById("remark").value = '';
  }
}
