package sstdb.ees.EesDailyTrip;


public class EesDailyTripTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 wo_num;
  public String                                 wo_date;
  public String                                 route_id;
  public String                                 trip_id;
  public String                                 trip_num;
  public String                                 vehicle_id;
  public String                                 driver_id;
  public String                                 start_time;
  public String                                 end_time;
  public int                                  omr;
  public int                                  cmr;
  public String                                 remark;





  public short                                  org_id_ind;
  public short                                  wo_num_ind;
  public short                                  wo_date_ind;
  public short                                  route_id_ind;
  public short                                  trip_id_ind;
  public short                                  trip_num_ind;
  public short                                  vehicle_id_ind;
  public short                                  driver_id_ind;
  public short                                  start_time_ind;
  public short                                  end_time_ind;
  public short                                  omr_ind;
  public short                                  cmr_ind;
  public short                                  remark_ind;


  public EesDailyTripTabObj(){}


  public EesDailyTripTabObj
  (
    String org_id,
    String wo_num,
    String wo_date,
    String route_id,
    String trip_id,
    String trip_num,
    String vehicle_id,
    String driver_id,
    String start_time,
    String end_time,
    int omr,
    int cmr,
    String remark
  )
  {
     this.org_id = org_id;
     this.wo_num = wo_num;
     this.wo_date = wo_date;
     this.route_id = route_id;
     this.trip_id = trip_id;
     this.trip_num = trip_num;
     this.vehicle_id = vehicle_id;
     this.driver_id = driver_id;
     this.start_time = start_time;
     this.end_time = end_time;
     this.omr = omr;
     this.cmr = cmr;
     this.remark = remark;
  }

  public String getorg_id()                           { return org_id; }
  public String getwo_num()                           { return wo_num; }
  public String getwo_date()                          { return wo_date; }
  public String getroute_id()                          { return route_id; }
  public String gettrip_id()                          { return trip_id; }
  public String gettrip_num()                          { return trip_num; }
  public String getvehicle_id()                         { return vehicle_id; }
  public String getdriver_id()                         { return driver_id; }
  public String getstart_time()                         { return start_time; }
  public String getend_time()                          { return end_time; }
  public int getomr()                              { return omr; }
  public int getcmr()                              { return cmr; }
  public String getremark()                           { return remark; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setwo_num(String wo_num )                    { this.wo_num = wo_num; }
  public void  setwo_date(String wo_date )                   { this.wo_date = wo_date; }
  public void  setroute_id(String route_id )                  { this.route_id = route_id; }
  public void  settrip_id(String trip_id )                   { this.trip_id = trip_id; }
  public void  settrip_num(String trip_num )                  { this.trip_num = trip_num; }
  public void  setvehicle_id(String vehicle_id )                { this.vehicle_id = vehicle_id; }
  public void  setdriver_id(String driver_id )                 { this.driver_id = driver_id; }
  public void  setstart_time(String start_time )                { this.start_time = start_time; }
  public void  setend_time(String end_time )                  { this.end_time = end_time; }
  public void  setomr(int omr )                         { this.omr = omr; }
  public void  setcmr(int cmr )                         { this.cmr = cmr; }
  public void  setremark(String remark )                    { this.remark = remark; }
}