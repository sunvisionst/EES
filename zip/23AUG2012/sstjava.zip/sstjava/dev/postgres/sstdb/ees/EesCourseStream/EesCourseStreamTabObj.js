{


   function vldDBSizeEnvEesCourseStream
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeCourseId ( inTableName, inFieldName );
      vldFieldDBSizeCourseStream ( inTableName, inFieldName );
      vldFieldDBSizeDescription ( inTableName, inFieldName );
      vldFieldDBSizeStreamStrength ( inTableName, inFieldName );
      vldFieldDBSizeQuotaQty ( inTableName, inFieldName );
      vldFieldDBSizeCourseCode ( inTableName, inFieldName );
      vldFieldDBSizeShortCode ( inTableName, inFieldName );
      vldFieldDBSizeSstStreamId ( inTableName, inFieldName );
      vldFieldDBSizeCourseCoord ( inTableName, inFieldName );
      vldFieldDBSizeBoardUniversity ( inTableName, inFieldName );
      vldFieldDBSizeMinFeeAmt ( inTableName, inFieldName );
      vldFieldDBSizeCcPtlUserId ( inTableName, inFieldName );
      vldFieldDBSizeClassStd ( inTableName, inFieldName );
   }



   function constructorEesCourseStream
   (
      org_id,
      course_id,
      course_stream,
      description,
      stream_strength,
      quota_qty,
      course_code,
      short_code,
      sst_stream_id,
      course_coord,
      board_university,
      min_fee_amt,
      cc_ptl_user_id,
      class_std
   )
   {
      this.org_id = org_id;
      this.course_id = course_id;
      this.course_stream = course_stream;
      this.description = description;
      this.stream_strength = stream_strength;
      this.quota_qty = quota_qty;
      this.course_code = course_code;
      this.short_code = short_code;
      this.sst_stream_id = sst_stream_id;
      this.course_coord = course_coord;
      this.board_university = board_university;
      this.min_fee_amt = min_fee_amt;
      this.cc_ptl_user_id = cc_ptl_user_id;
      this.class_std = class_std;
   }



   function EesCourseStreamFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lEesCourseStreamTabObjJSArr.length )
      {
         if
         ( 
           ( lEesCourseStreamTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lEesCourseStreamTabObjJSArr[lRecNum].course_id != document.form.course_id.value ) &&
           ( lEesCourseStreamTabObjJSArr[lRecNum].course_stream != document.form.course_stream.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeEesCourseStreamTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjCourseId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjCourseStream
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjDescription
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjStreamStrength
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjQuotaQty
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjCourseCode
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjShortCode
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjSstStreamId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjCourseCoord
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjBoardUniversity
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjMinFeeAmt
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjCcPtlUserId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesCourseStreamTabObjClassStd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseStream
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisDescription
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisStreamStrength
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisQuotaQty
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseCode
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisShortCode
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSstStreamId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseCoord
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisBoardUniversity
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMinFeeAmt
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >16 )
      {
         alert("Data base field size error. Size should be <= 16");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >13 )
      {
         alert("Data base field size error. Integer Size should be <= 13");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCcPtlUserId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisClassStd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



}