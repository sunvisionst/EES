package sstdb.ees.EesAppcRef;


public class EesAppcRefTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 applicant_id;
  public byte                                  seq_num;
  public String                                 application_form_num;
  public String                                 student_id;
  public String                                 roll_num;
  public String                                 ref_name;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;
  public String                                 adm_req_id_req;
  public String                                 adm_req_id_list;





  public short                                  org_id_ind;
  public short                                  applicant_id_ind;
  public short                                  seq_num_ind;
  public short                                  application_form_num_ind;
  public short                                  student_id_ind;
  public short                                  roll_num_ind;
  public short                                  ref_name_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;
  public short                                  adm_req_id_req_ind;
  public short                                  adm_req_id_list_ind;


  public EesAppcRefTabObj(){}


  public EesAppcRefTabObj
  (
    String org_id,
    String applicant_id,
    byte seq_num,
    String application_form_num,
    String student_id,
    String roll_num,
    String ref_name,
    String address_1,
    String address_2,
    String phone_list,
    String email_list,
    String fax_list,
    String adm_req_id_req,
    String adm_req_id_list
  )
  {
     this.org_id = org_id;
     this.applicant_id = applicant_id;
     this.seq_num = seq_num;
     this.application_form_num = application_form_num;
     this.student_id = student_id;
     this.roll_num = roll_num;
     this.ref_name = ref_name;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
     this.adm_req_id_req = adm_req_id_req;
     this.adm_req_id_list = adm_req_id_list;
  }

  public String getorg_id()                           { return org_id; }
  public String getapplicant_id()                        { return applicant_id; }
  public byte getseq_num()                           { return seq_num; }
  public String getapplication_form_num()                    { return application_form_num; }
  public String getstudent_id()                         { return student_id; }
  public String getroll_num()                          { return roll_num; }
  public String getref_name()                          { return ref_name; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }
  public String getadm_req_id_req()                       { return adm_req_id_req; }
  public String getadm_req_id_list()                      { return adm_req_id_list; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setapplicant_id(String applicant_id )              { this.applicant_id = applicant_id; }
  public void  setseq_num(byte seq_num )                    { this.seq_num = seq_num; }
  public void  setapplication_form_num(String application_form_num )      { this.application_form_num = application_form_num; }
  public void  setstudent_id(String student_id )                { this.student_id = student_id; }
  public void  setroll_num(String roll_num )                  { this.roll_num = roll_num; }
  public void  setref_name(String ref_name )                  { this.ref_name = ref_name; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
  public void  setadm_req_id_req(String adm_req_id_req )            { this.adm_req_id_req = adm_req_id_req; }
  public void  setadm_req_id_list(String adm_req_id_list )           { this.adm_req_id_list = adm_req_id_list; }
}