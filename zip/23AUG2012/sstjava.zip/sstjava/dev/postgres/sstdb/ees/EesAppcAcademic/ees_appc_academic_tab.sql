CREATE TABLE EES_APPC_ACADEMIC
(
  ORG_ID                                                                                              VARCHAR(10),
  APPLICANT_ID                                                                                        VARCHAR(25),
  SEQ_NUM                                                                                             NUMERIC(9),
  CLASS_NUM                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  FULL_PART_TIME                                                                                      VARCHAR(1),
  UNIVERSITY_BOARD_NAME                                                                               VARCHAR(100),
  COLLEGE_SCHOOL_NAME                                                                                 VARCHAR(100),
  STATE                                                                                               VARCHAR(50),
  COUNTRY                                                                                             VARCHAR(10),
  UNV_RN                                                                                              VARCHAR(10),
  SUBJECT_LIST                                                                                        VARCHAR(200),
  YEAR_OF_PASSING                                                                                     NUMERIC(4),
  PERCENT_GRADE                                                                                       VARCHAR(1),
  MARKS_IN_PERCENT                                                                                    NUMERIC(5,2),
  GRADE                                                                                               VARCHAR(5),
  ADM_REQ_ID_REQ                                                                                      VARCHAR(30),
  ADM_REQ_ID_LIST                                                                                     VARCHAR(30)
)
 WITH OIDS;
