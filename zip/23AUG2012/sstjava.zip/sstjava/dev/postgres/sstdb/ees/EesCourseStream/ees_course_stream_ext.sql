CREATE TABLE EES_COURSE_STREAM_EXT
(
  org_id                                                                                              VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  course_stream                                                                                       VARCHAR(10),
  description                                                                                         VARCHAR(100),
  stream_strength                                                                                     NUMERIC(9),
  quota_qty                                                                                           NUMERIC(9),
  course_code                                                                                         VARCHAR(10),
  short_code                                                                                          VARCHAR(10),
  sst_stream_id                                                                                       VARCHAR(10),
  course_coord                                                                                        VARCHAR(20),
  board_university                                                                                    VARCHAR(100),
  min_fee_amt                                                                                         NUMERIC(13,2),
  cc_ptl_user_id                                                                                      VARCHAR(50),
  class_std                                                                                           VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10),
       DESCRIPTION                                                                                         CHAR(100),
       STREAM_STRENGTH                                                                                     CHAR(9),
       QUOTA_QTY                                                                                           CHAR(9),
       COURSE_CODE                                                                                         CHAR(10),
       SHORT_CODE                                                                                          CHAR(10),
       SST_STREAM_ID                                                                                       CHAR(10),
       COURSE_COORD                                                                                        CHAR(20),
       BOARD_UNIVERSITY                                                                                    CHAR(100),
       MIN_FEE_AMT                                                                                         CHAR(13),
       CC_PTL_USER_ID                                                                                      CHAR(50),
       CLASS_STD                                                                                           CHAR(10)
    )
  )
  LOCATION ('ees_course_stream_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
