
var lEesAsChecklistTabObjJSArr = new Array();
<%
{
   if ( lEesAsChecklistTabObjArrCache != null && lEesAsChecklistTabObjArrCache.size() > 0 )
   {
%>
       lEesAsChecklistTabObjJSArr = new Array(<%=lEesAsChecklistTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAsChecklistTabObjArrCache.size(); lRecNum++ )
       {
          EesAsChecklistTabObj lEesAsChecklistTabObj    =    new EesAsChecklistTabObj();
          lEesAsChecklistTabObj = (EesAsChecklistTabObj)lEesAsChecklistTabObjArrCache.get(lRecNum);
%>
          lEesAsChecklistTabObjJSArr[<%=lRecNum%>] = new constructorEesAsChecklist
          (
          "<%=lEesAsChecklistTabObj.org_id%>",
          "<%=lEesAsChecklistTabObj.academic_session%>",
          "<%=lEesAsChecklistTabObj.checklist_id%>",
          "<%=lEesAsChecklistTabObj.description%>",
          "<%=lEesAsChecklistTabObj.checklist_sts%>",
          "<%=lEesAsChecklistTabObj.checklist_sts_date%>",
          "<%=lEesAsChecklistTabObj.apr_sts_date%>",
          "<%=lEesAsChecklistTabObj.apr_remark%>",
          "<%=lEesAsChecklistTabObj.rej_remark%>"
          );
<%
       }
   }
}
%>


