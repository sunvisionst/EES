package sstdb.ees.EesAlumniProf;


public class EesAlumniProfTabObj
{
  public String                                 tab_rowid;
  public String                                 student_org_id;
  public String                                 alumni_id;
  public int                                  seq_num;
  public String                                 occupation;
  public String                                 designation;
  public String                                 joining_date;
  public String                                 org_name;
  public String                                 working_tech;
  public String                                 area_of_interest;
  public String                                 web_page_ind;
  public String                                 office_address1;
  public String                                 office_address2;
  public String                                 city;
  public String                                 state;
  public String                                 zip;
  public String                                 country;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;





  public short                                  student_org_id_ind;
  public short                                  alumni_id_ind;
  public short                                  seq_num_ind;
  public short                                  occupation_ind;
  public short                                  designation_ind;
  public short                                  joining_date_ind;
  public short                                  org_name_ind;
  public short                                  working_tech_ind;
  public short                                  area_of_interest_ind;
  public short                                  web_page_ind_ind;
  public short                                  office_address1_ind;
  public short                                  office_address2_ind;
  public short                                  city_ind;
  public short                                  state_ind;
  public short                                  zip_ind;
  public short                                  country_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;


  public EesAlumniProfTabObj(){}


  public EesAlumniProfTabObj
  (
    String student_org_id,
    String alumni_id,
    int seq_num,
    String occupation,
    String designation,
    String joining_date,
    String org_name,
    String working_tech,
    String area_of_interest,
    String web_page_ind,
    String office_address1,
    String office_address2,
    String city,
    String state,
    String zip,
    String country,
    String phone_list,
    String email_list,
    String fax_list
  )
  {
     this.student_org_id = student_org_id;
     this.alumni_id = alumni_id;
     this.seq_num = seq_num;
     this.occupation = occupation;
     this.designation = designation;
     this.joining_date = joining_date;
     this.org_name = org_name;
     this.working_tech = working_tech;
     this.area_of_interest = area_of_interest;
     this.web_page_ind = web_page_ind;
     this.office_address1 = office_address1;
     this.office_address2 = office_address2;
     this.city = city;
     this.state = state;
     this.zip = zip;
     this.country = country;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
  }

  public String getstudent_org_id()                       { return student_org_id; }
  public String getalumni_id()                         { return alumni_id; }
  public int getseq_num()                            { return seq_num; }
  public String getoccupation()                         { return occupation; }
  public String getdesignation()                        { return designation; }
  public String getjoining_date()                        { return joining_date; }
  public String getorg_name()                          { return org_name; }
  public String getworking_tech()                        { return working_tech; }
  public String getarea_of_interest()                      { return area_of_interest; }
  public String getweb_page_ind()                        { return web_page_ind; }
  public String getoffice_address1()                      { return office_address1; }
  public String getoffice_address2()                      { return office_address2; }
  public String getcity()                            { return city; }
  public String getstate()                           { return state; }
  public String getzip()                            { return zip; }
  public String getcountry()                          { return country; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }



  public void  setstudent_org_id(String student_org_id )            { this.student_org_id = student_org_id; }
  public void  setalumni_id(String alumni_id )                 { this.alumni_id = alumni_id; }
  public void  setseq_num(int seq_num )                     { this.seq_num = seq_num; }
  public void  setoccupation(String occupation )                { this.occupation = occupation; }
  public void  setdesignation(String designation )               { this.designation = designation; }
  public void  setjoining_date(String joining_date )              { this.joining_date = joining_date; }
  public void  setorg_name(String org_name )                  { this.org_name = org_name; }
  public void  setworking_tech(String working_tech )              { this.working_tech = working_tech; }
  public void  setarea_of_interest(String area_of_interest )          { this.area_of_interest = area_of_interest; }
  public void  setweb_page_ind(String web_page_ind )              { this.web_page_ind = web_page_ind; }
  public void  setoffice_address1(String office_address1 )           { this.office_address1 = office_address1; }
  public void  setoffice_address2(String office_address2 )           { this.office_address2 = office_address2; }
  public void  setcity(String city )                      { this.city = city; }
  public void  setstate(String state )                     { this.state = state; }
  public void  setzip(String zip )                       { this.zip = zip; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
}