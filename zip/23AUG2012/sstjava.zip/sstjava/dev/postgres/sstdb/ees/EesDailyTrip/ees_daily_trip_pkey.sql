ALTER TABLE           EES_DAILY_TRIP
  ADD                 CONSTRAINT EES_DAILY_TRIP_PK
  PRIMARY             KEY
  ( ORG_ID, WO_NUM )
;
