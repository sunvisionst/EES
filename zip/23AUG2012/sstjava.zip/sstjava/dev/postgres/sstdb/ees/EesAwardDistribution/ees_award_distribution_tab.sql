CREATE TABLE EES_AWARD_DISTRIBUTION
(
  ORG_ID                                                                                              VARCHAR(10),
  EVENT_ID                                                                                            VARCHAR(10),
  AWARDEE_ID                                                                                          VARCHAR(10),
  AWARDEE_TYPE                                                                                        VARCHAR(1),
  AWARD_ID                                                                                            VARCHAR(10),
  DISTRIBUTION_DATE                                                                                   VARCHAR(8),
  DISTRIBUTED_BY                                                                                      VARCHAR(100)
)
 WITH OIDS;
