ALTER TABLE           EES_ADM_REQ
  ADD                 CONSTRAINT EES_ADM_REQ_PK
  PRIMARY             KEY
  ( ORG_ID, ADM_REQ_ID )
;
