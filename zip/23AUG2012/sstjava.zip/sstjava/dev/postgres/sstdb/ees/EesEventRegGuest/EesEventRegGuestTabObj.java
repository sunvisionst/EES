package sstdb.ees.EesEventRegGuest;


public class EesEventRegGuestTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 activity_id;
  public String                                 event_id;
  public String                                 speaker_ind;
  public String                                 attendee_name;
  public String                                 attendee_email;
  public String                                 attendee_phone;
  public String                                 attendee_fax;
  public String                                 status;
  public String                                 status_date;





  public short                                  org_id_ind;
  public short                                  activity_id_ind;
  public short                                  event_id_ind;
  public short                                  speaker_ind_ind;
  public short                                  attendee_name_ind;
  public short                                  attendee_email_ind;
  public short                                  attendee_phone_ind;
  public short                                  attendee_fax_ind;
  public short                                  status_ind;
  public short                                  status_date_ind;


  public EesEventRegGuestTabObj(){}


  public EesEventRegGuestTabObj
  (
    String org_id,
    String activity_id,
    String event_id,
    String speaker_ind,
    String attendee_name,
    String attendee_email,
    String attendee_phone,
    String attendee_fax,
    String status,
    String status_date
  )
  {
     this.org_id = org_id;
     this.activity_id = activity_id;
     this.event_id = event_id;
     this.speaker_ind = speaker_ind;
     this.attendee_name = attendee_name;
     this.attendee_email = attendee_email;
     this.attendee_phone = attendee_phone;
     this.attendee_fax = attendee_fax;
     this.status = status;
     this.status_date = status_date;
  }

  public String getorg_id()                           { return org_id; }
  public String getactivity_id()                        { return activity_id; }
  public String getevent_id()                          { return event_id; }
  public String getspeaker_ind()                        { return speaker_ind; }
  public String getattendee_name()                       { return attendee_name; }
  public String getattendee_email()                       { return attendee_email; }
  public String getattendee_phone()                       { return attendee_phone; }
  public String getattendee_fax()                        { return attendee_fax; }
  public String getstatus()                           { return status; }
  public String getstatus_date()                        { return status_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setactivity_id(String activity_id )               { this.activity_id = activity_id; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setspeaker_ind(String speaker_ind )               { this.speaker_ind = speaker_ind; }
  public void  setattendee_name(String attendee_name )             { this.attendee_name = attendee_name; }
  public void  setattendee_email(String attendee_email )            { this.attendee_email = attendee_email; }
  public void  setattendee_phone(String attendee_phone )            { this.attendee_phone = attendee_phone; }
  public void  setattendee_fax(String attendee_fax )              { this.attendee_fax = attendee_fax; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setstatus_date(String status_date )               { this.status_date = status_date; }
}