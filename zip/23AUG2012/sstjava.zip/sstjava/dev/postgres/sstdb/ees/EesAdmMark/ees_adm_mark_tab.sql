CREATE TABLE EES_ADM_MARK
(
  ORG_ID                                                                                              VARCHAR(10),
  ADM_REQ_ID                                                                                          VARCHAR(30),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  SUBJECT_CODE                                                                                        VARCHAR(10),
  CLASS_NUM                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  OBTAINED_MARK                                                                                       NUMERIC(9),
  MAX_MARK                                                                                            NUMERIC(9)
)
 WITH OIDS;
