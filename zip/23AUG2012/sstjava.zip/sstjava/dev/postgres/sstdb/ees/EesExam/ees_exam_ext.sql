CREATE TABLE EES_EXAM_EXT
(
  org_id                                                                                              VARCHAR(10),
  exam_id                                                                                             VARCHAR(10),
  exam_term                                                                                           VARCHAR(10),
  exam_type                                                                                           VARCHAR(10),
  year                                                                                                NUMERIC(4),
  month                                                                                               NUMERIC(2),
  academic_session                                                                                    VARCHAR(11),
  exam_start_date                                                                                     VARCHAR(8),
  exam_end_date                                                                                       VARCHAR(8),
  exam_status                                                                                         VARCHAR(1),
  exam_status_date                                                                                    VARCHAR(8),
  exam_sch_status                                                                                     VARCHAR(1),
  sitting_plan_status                                                                                 VARCHAR(1),
  seat_alloc_status                                                                                   VARCHAR(1),
  exam_attn_status                                                                                    VARCHAR(1),
  mark_entry_status                                                                                   VARCHAR(1)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       EXAM_ID                                                                                             CHAR(10),
       EXAM_TERM                                                                                           CHAR(10),
       EXAM_TYPE                                                                                           CHAR(10),
       YEAR                                                                                                CHAR(4),
       MONTH                                                                                               CHAR(2),
       ACADEMIC_SESSION                                                                                    CHAR(11),
       EXAM_START_DATE                                                                                     CHAR(8),
       EXAM_END_DATE                                                                                       CHAR(8),
       EXAM_STATUS                                                                                         CHAR(1),
       EXAM_STATUS_DATE                                                                                    CHAR(8),
       EXAM_SCH_STATUS                                                                                     CHAR(1),
       SITTING_PLAN_STATUS                                                                                 CHAR(1),
       SEAT_ALLOC_STATUS                                                                                   CHAR(1),
       EXAM_ATTN_STATUS                                                                                    CHAR(1),
       MARK_ENTRY_STATUS                                                                                   CHAR(1)
    )
  )
  LOCATION ('ees_exam_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
