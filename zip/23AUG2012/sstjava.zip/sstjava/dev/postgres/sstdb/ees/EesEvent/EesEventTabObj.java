package sstdb.ees.EesEvent;


public class EesEventTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 event_id;
  public String                                 event_type;
  public String                                 event_desc;
  public String                                 status;
  public String                                 event_start_date;
  public String                                 event_close_date;
  public String                                 ptl_publish_ind;
  public String                                 ptl_publish_start_date;
  public String                                 ptl_publish_close_date;
  public String                                 ptl_user_id;
  public String                                 rec_cre_by;
  public String                                 rec_cre_date;
  public String                                 rec_cre_time;
  public String                                 rec_upd_by;
  public String                                 rec_upd_date;
  public String                                 rec_upd_time;





  public short                                  org_id_ind;
  public short                                  event_id_ind;
  public short                                  event_type_ind;
  public short                                  event_desc_ind;
  public short                                  status_ind;
  public short                                  event_start_date_ind;
  public short                                  event_close_date_ind;
  public short                                  ptl_publish_ind_ind;
  public short                                  ptl_publish_start_date_ind;
  public short                                  ptl_publish_close_date_ind;
  public short                                  ptl_user_id_ind;
  public short                                  rec_cre_by_ind;
  public short                                  rec_cre_date_ind;
  public short                                  rec_cre_time_ind;
  public short                                  rec_upd_by_ind;
  public short                                  rec_upd_date_ind;
  public short                                  rec_upd_time_ind;


  public EesEventTabObj(){}


  public EesEventTabObj
  (
    String org_id,
    String event_id,
    String event_type,
    String event_desc,
    String status,
    String event_start_date,
    String event_close_date,
    String ptl_publish_ind,
    String ptl_publish_start_date,
    String ptl_publish_close_date,
    String ptl_user_id,
    String rec_cre_by,
    String rec_cre_date,
    String rec_cre_time,
    String rec_upd_by,
    String rec_upd_date,
    String rec_upd_time
  )
  {
     this.org_id = org_id;
     this.event_id = event_id;
     this.event_type = event_type;
     this.event_desc = event_desc;
     this.status = status;
     this.event_start_date = event_start_date;
     this.event_close_date = event_close_date;
     this.ptl_publish_ind = ptl_publish_ind;
     this.ptl_publish_start_date = ptl_publish_start_date;
     this.ptl_publish_close_date = ptl_publish_close_date;
     this.ptl_user_id = ptl_user_id;
     this.rec_cre_by = rec_cre_by;
     this.rec_cre_date = rec_cre_date;
     this.rec_cre_time = rec_cre_time;
     this.rec_upd_by = rec_upd_by;
     this.rec_upd_date = rec_upd_date;
     this.rec_upd_time = rec_upd_time;
  }

  public String getorg_id()                           { return org_id; }
  public String getevent_id()                          { return event_id; }
  public String getevent_type()                         { return event_type; }
  public String getevent_desc()                         { return event_desc; }
  public String getstatus()                           { return status; }
  public String getevent_start_date()                      { return event_start_date; }
  public String getevent_close_date()                      { return event_close_date; }
  public String getptl_publish_ind()                      { return ptl_publish_ind; }
  public String getptl_publish_start_date()                   { return ptl_publish_start_date; }
  public String getptl_publish_close_date()                   { return ptl_publish_close_date; }
  public String getptl_user_id()                        { return ptl_user_id; }
  public String getrec_cre_by()                         { return rec_cre_by; }
  public String getrec_cre_date()                        { return rec_cre_date; }
  public String getrec_cre_time()                        { return rec_cre_time; }
  public String getrec_upd_by()                         { return rec_upd_by; }
  public String getrec_upd_date()                        { return rec_upd_date; }
  public String getrec_upd_time()                        { return rec_upd_time; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setevent_type(String event_type )                { this.event_type = event_type; }
  public void  setevent_desc(String event_desc )                { this.event_desc = event_desc; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setevent_start_date(String event_start_date )          { this.event_start_date = event_start_date; }
  public void  setevent_close_date(String event_close_date )          { this.event_close_date = event_close_date; }
  public void  setptl_publish_ind(String ptl_publish_ind )           { this.ptl_publish_ind = ptl_publish_ind; }
  public void  setptl_publish_start_date(String ptl_publish_start_date )    { this.ptl_publish_start_date = ptl_publish_start_date; }
  public void  setptl_publish_close_date(String ptl_publish_close_date )    { this.ptl_publish_close_date = ptl_publish_close_date; }
  public void  setptl_user_id(String ptl_user_id )               { this.ptl_user_id = ptl_user_id; }
  public void  setrec_cre_by(String rec_cre_by )                { this.rec_cre_by = rec_cre_by; }
  public void  setrec_cre_date(String rec_cre_date )              { this.rec_cre_date = rec_cre_date; }
  public void  setrec_cre_time(String rec_cre_time )              { this.rec_cre_time = rec_cre_time; }
  public void  setrec_upd_by(String rec_upd_by )                { this.rec_upd_by = rec_upd_by; }
  public void  setrec_upd_date(String rec_upd_date )              { this.rec_upd_date = rec_upd_date; }
  public void  setrec_upd_time(String rec_upd_time )              { this.rec_upd_time = rec_upd_time; }
}