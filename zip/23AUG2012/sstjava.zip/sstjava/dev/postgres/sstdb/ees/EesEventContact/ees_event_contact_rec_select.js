function EesEventContactRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("activity_id").value  = document.getElementById("activity_id"+"_r"+inRecNum).value;
    document.getElementById("activity_id").readOnly = true;
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("seq_num").readOnly = true;
    document.getElementById("event_id").value  = document.getElementById("event_id"+"_r"+inRecNum).value;
    document.getElementById("contact_type").value  = document.getElementById("contact_type"+"_r"+inRecNum).value;
    document.getElementById("poc_type").value  = document.getElementById("poc_type"+"_r"+inRecNum).value;
    document.getElementById("poc_id").value  = document.getElementById("poc_id"+"_r"+inRecNum).value;
    document.getElementById("poc_name").value  = document.getElementById("poc_name"+"_r"+inRecNum).value;
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value;
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value;
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value;
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value;
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value;
    document.getElementById("city").value  = document.getElementById("city"+"_r"+inRecNum).value;
    document.getElementById("district").value  = document.getElementById("district"+"_r"+inRecNum).value;
    document.getElementById("zip").value  = document.getElementById("zip"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("activity_id").value = '';
    document.getElementById("activity_id").readOnly = false;
    document.getElementById("seq_num").value = '';
    document.getElementById("seq_num").readOnly = false;
    document.getElementById("event_id").value = '';
    document.getElementById("contact_type").value = '';
    document.getElementById("poc_type").value = '';
    document.getElementById("poc_id").value = '';
    document.getElementById("poc_name").value = '';
    document.getElementById("phone_list").value = '';
    document.getElementById("email_list").value = '';
    document.getElementById("fax_list").value = '';
    document.getElementById("address_1").value = '';
    document.getElementById("address_2").value = '';
    document.getElementById("country").value = '';
    document.getElementById("state").value = '';
    document.getElementById("city").value = '';
    document.getElementById("district").value = '';
    document.getElementById("zip").value = '';
  }
}
