CREATE TABLE EES_EVENT_CONTACT_EXT
(
  org_id                                                                                              VARCHAR(10),
  activity_id                                                                                         VARCHAR(10),
  seq_num                                                                                             NUMERIC(9),
  event_id                                                                                            VARCHAR(10),
  contact_type                                                                                        VARCHAR(1),
  poc_type                                                                                            VARCHAR(10),
  poc_id                                                                                              VARCHAR(10),
  poc_name                                                                                            VARCHAR(100),
  phone_list                                                                                          VARCHAR(100),
  email_list                                                                                          VARCHAR(100),
  fax_list                                                                                            VARCHAR(100),
  address_1                                                                                           VARCHAR(150),
  address_2                                                                                           VARCHAR(150),
  country                                                                                             VARCHAR(10),
  state                                                                                               VARCHAR(50),
  city                                                                                                VARCHAR(50),
  district                                                                                            VARCHAR(50),
  zip                                                                                                 VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACTIVITY_ID                                                                                         CHAR(10),
       SEQ_NUM                                                                                             CHAR(9),
       EVENT_ID                                                                                            CHAR(10),
       CONTACT_TYPE                                                                                        CHAR(1),
       POC_TYPE                                                                                            CHAR(10),
       POC_ID                                                                                              CHAR(10),
       POC_NAME                                                                                            CHAR(100),
       PHONE_LIST                                                                                          CHAR(100),
       EMAIL_LIST                                                                                          CHAR(100),
       FAX_LIST                                                                                            CHAR(100),
       ADDRESS_1                                                                                           CHAR(150),
       ADDRESS_2                                                                                           CHAR(150),
       COUNTRY                                                                                             CHAR(10),
       STATE                                                                                               CHAR(50),
       CITY                                                                                                CHAR(50),
       DISTRICT                                                                                            CHAR(50),
       ZIP                                                                                                 CHAR(10)
    )
  )
  LOCATION ('ees_event_contact_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
