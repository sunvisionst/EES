package sstdb.ees.EesEventContact;


public class EesEventContactTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 activity_id;
  public int                                  seq_num;
  public String                                 event_id;
  public String                                 contact_type;
  public String                                 poc_type;
  public String                                 poc_id;
  public String                                 poc_name;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 country;
  public String                                 state;
  public String                                 city;
  public String                                 district;
  public String                                 zip;





  public short                                  org_id_ind;
  public short                                  activity_id_ind;
  public short                                  seq_num_ind;
  public short                                  event_id_ind;
  public short                                  contact_type_ind;
  public short                                  poc_type_ind;
  public short                                  poc_id_ind;
  public short                                  poc_name_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  country_ind;
  public short                                  state_ind;
  public short                                  city_ind;
  public short                                  district_ind;
  public short                                  zip_ind;


  public EesEventContactTabObj(){}


  public EesEventContactTabObj
  (
    String org_id,
    String activity_id,
    int seq_num,
    String event_id,
    String contact_type,
    String poc_type,
    String poc_id,
    String poc_name,
    String phone_list,
    String email_list,
    String fax_list,
    String address_1,
    String address_2,
    String country,
    String state,
    String city,
    String district,
    String zip
  )
  {
     this.org_id = org_id;
     this.activity_id = activity_id;
     this.seq_num = seq_num;
     this.event_id = event_id;
     this.contact_type = contact_type;
     this.poc_type = poc_type;
     this.poc_id = poc_id;
     this.poc_name = poc_name;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.country = country;
     this.state = state;
     this.city = city;
     this.district = district;
     this.zip = zip;
  }

  public String getorg_id()                           { return org_id; }
  public String getactivity_id()                        { return activity_id; }
  public int getseq_num()                            { return seq_num; }
  public String getevent_id()                          { return event_id; }
  public String getcontact_type()                        { return contact_type; }
  public String getpoc_type()                          { return poc_type; }
  public String getpoc_id()                           { return poc_id; }
  public String getpoc_name()                          { return poc_name; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getcountry()                          { return country; }
  public String getstate()                           { return state; }
  public String getcity()                            { return city; }
  public String getdistrict()                          { return district; }
  public String getzip()                            { return zip; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setactivity_id(String activity_id )               { this.activity_id = activity_id; }
  public void  setseq_num(int seq_num )                     { this.seq_num = seq_num; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setcontact_type(String contact_type )              { this.contact_type = contact_type; }
  public void  setpoc_type(String poc_type )                  { this.poc_type = poc_type; }
  public void  setpoc_id(String poc_id )                    { this.poc_id = poc_id; }
  public void  setpoc_name(String poc_name )                  { this.poc_name = poc_name; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setstate(String state )                     { this.state = state; }
  public void  setcity(String city )                      { this.city = city; }
  public void  setdistrict(String district )                  { this.district = district; }
  public void  setzip(String zip )                       { this.zip = zip; }
}