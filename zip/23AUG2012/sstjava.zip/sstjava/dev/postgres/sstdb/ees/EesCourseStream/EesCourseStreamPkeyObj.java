package sstdb.ees.EesCourseStream;


public class EesCourseStreamPkeyObj
{
  public String                                 org_id;
  public String                                 course_id;
  public String                                 course_stream;
}