CREATE TABLE EES_ALUMNI_PROF
(
  STUDENT_ORG_ID                                                                                      VARCHAR(10),
  ALUMNI_ID                                                                                           VARCHAR(10),
  SEQ_NUM                                                                                             NUMERIC(9),
  OCCUPATION                                                                                          VARCHAR(100),
  DESIGNATION                                                                                         VARCHAR(60),
  JOINING_DATE                                                                                        VARCHAR(8),
  ORG_NAME                                                                                            VARCHAR(100),
  WORKING_TECH                                                                                        VARCHAR(100),
  AREA_OF_INTEREST                                                                                    VARCHAR(100),
  WEB_PAGE_IND                                                                                        VARCHAR(1),
  OFFICE_ADDRESS1                                                                                     VARCHAR(100),
  OFFICE_ADDRESS2                                                                                     VARCHAR(100),
  CITY                                                                                                VARCHAR(50),
  STATE                                                                                               VARCHAR(50),
  ZIP                                                                                                 VARCHAR(10),
  COUNTRY                                                                                             VARCHAR(50),
  PHONE_LIST                                                                                          VARCHAR(100),
  EMAIL_LIST                                                                                          VARCHAR(100),
  FAX_LIST                                                                                            VARCHAR(100)
)
 WITH OIDS;
