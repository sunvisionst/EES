ALTER TABLE           EES_AWARD
  ADD                 CONSTRAINT EES_AWARD_PK
  PRIMARY             KEY
  ( ORG_ID, AWARD_ID )
;
