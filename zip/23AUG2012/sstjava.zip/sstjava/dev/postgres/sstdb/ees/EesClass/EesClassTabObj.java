package sstdb.ees.EesClass;


public class EesClassTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 description;
  public String                                 duration_type;
  public int                                  course_duration;
  public String                                 remark;
  public String                                 upgrade_ind;
  public String                                 run_ind;
  public String                                 room_num;
  public String                                 building_id;
  public String                                 room_share_ind;
  public String                                 class_teacher;
  public String                                 stream_ind;
  public String                                 shift_code;





  public short                                  org_id_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  description_ind;
  public short                                  duration_type_ind;
  public short                                  course_duration_ind;
  public short                                  remark_ind;
  public short                                  upgrade_ind_ind;
  public short                                  run_ind_ind;
  public short                                  room_num_ind;
  public short                                  building_id_ind;
  public short                                  room_share_ind_ind;
  public short                                  class_teacher_ind;
  public short                                  stream_ind_ind;
  public short                                  shift_code_ind;


  public EesClassTabObj(){}


  public EesClassTabObj
  (
    String org_id,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream,
    String description,
    String duration_type,
    int course_duration,
    String remark,
    String upgrade_ind,
    String run_ind,
    String room_num,
    String building_id,
    String room_share_ind,
    String class_teacher,
    String stream_ind,
    String shift_code
  )
  {
     this.org_id = org_id;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.description = description;
     this.duration_type = duration_type;
     this.course_duration = course_duration;
     this.remark = remark;
     this.upgrade_ind = upgrade_ind;
     this.run_ind = run_ind;
     this.room_num = room_num;
     this.building_id = building_id;
     this.room_share_ind = room_share_ind;
     this.class_teacher = class_teacher;
     this.stream_ind = stream_ind;
     this.shift_code = shift_code;
  }

  public String getorg_id()                           { return org_id; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getdescription()                        { return description; }
  public String getduration_type()                       { return duration_type; }
  public int getcourse_duration()                        { return course_duration; }
  public String getremark()                           { return remark; }
  public String getupgrade_ind()                        { return upgrade_ind; }
  public String getrun_ind()                          { return run_ind; }
  public String getroom_num()                          { return room_num; }
  public String getbuilding_id()                        { return building_id; }
  public String getroom_share_ind()                       { return room_share_ind; }
  public String getclass_teacher()                       { return class_teacher; }
  public String getstream_ind()                         { return stream_ind; }
  public String getshift_code()                         { return shift_code; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setdescription(String description )               { this.description = description; }
  public void  setduration_type(String duration_type )             { this.duration_type = duration_type; }
  public void  setcourse_duration(int course_duration )             { this.course_duration = course_duration; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setupgrade_ind(String upgrade_ind )               { this.upgrade_ind = upgrade_ind; }
  public void  setrun_ind(String run_ind )                   { this.run_ind = run_ind; }
  public void  setroom_num(String room_num )                  { this.room_num = room_num; }
  public void  setbuilding_id(String building_id )               { this.building_id = building_id; }
  public void  setroom_share_ind(String room_share_ind )            { this.room_share_ind = room_share_ind; }
  public void  setclass_teacher(String class_teacher )             { this.class_teacher = class_teacher; }
  public void  setstream_ind(String stream_ind )                { this.stream_ind = stream_ind; }
  public void  setshift_code(String shift_code )                { this.shift_code = shift_code; }
}