package sstdb.ees.EesAdmReq;

import sstdb.ees.EesAdmReq.EesAdmReqTabObj;
import sstdb.ees.EesAdmReq.EesAdmReqPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesAdmReqMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesAdmReqMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesAdmReqMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesAdmReqTabObj
               ( 
                 EesAdmReqTabObj  outEesAdmReqTabObj
               )
  {
  
     outEesAdmReqTabObj.org_id = ""; 
     outEesAdmReqTabObj.adm_req_id = ""; 
     outEesAdmReqTabObj.application_form_num = ""; 
     outEesAdmReqTabObj.applicant_id = ""; 
     outEesAdmReqTabObj.student_photo_file = ""; 
     outEesAdmReqTabObj.mother_photo_file = ""; 
     outEesAdmReqTabObj.father_photo_file = ""; 
     outEesAdmReqTabObj.class_id = ""; 
     outEesAdmReqTabObj.class_num = ""; 
     outEesAdmReqTabObj.class_std = ""; 
     outEesAdmReqTabObj.class_section = ""; 
     outEesAdmReqTabObj.course_id = ""; 
     outEesAdmReqTabObj.course_term = ""; 
     outEesAdmReqTabObj.course_stream = ""; 
     outEesAdmReqTabObj.name_initials = ""; 
     outEesAdmReqTabObj.student_f_name = ""; 
     outEesAdmReqTabObj.student_m_name = ""; 
     outEesAdmReqTabObj.student_l_name = ""; 
     outEesAdmReqTabObj.dob = ""; 
     outEesAdmReqTabObj.age_on_date = ""; 
     outEesAdmReqTabObj.age_year = (int)0; 
     outEesAdmReqTabObj.age_month = ""; 
     outEesAdmReqTabObj.age_day = (int)0; 
     outEesAdmReqTabObj.s_nationality = ""; 
     outEesAdmReqTabObj.religion = ""; 
     outEesAdmReqTabObj.student_ctg = ""; 
     outEesAdmReqTabObj.gender_flag = ""; 
     outEesAdmReqTabObj.p_address_1 = ""; 
     outEesAdmReqTabObj.p_address_2 = ""; 
     outEesAdmReqTabObj.p_country = ""; 
     outEesAdmReqTabObj.p_state = ""; 
     outEesAdmReqTabObj.p_city = ""; 
     outEesAdmReqTabObj.p_district = ""; 
     outEesAdmReqTabObj.p_zip = ""; 
     outEesAdmReqTabObj.m_address_1 = ""; 
     outEesAdmReqTabObj.m_address_2 = ""; 
     outEesAdmReqTabObj.m_country = ""; 
     outEesAdmReqTabObj.m_state = ""; 
     outEesAdmReqTabObj.m_city = ""; 
     outEesAdmReqTabObj.m_district = ""; 
     outEesAdmReqTabObj.m_zip = ""; 
     outEesAdmReqTabObj.phone_list = ""; 
     outEesAdmReqTabObj.email_list = ""; 
     outEesAdmReqTabObj.fax_list = ""; 
     outEesAdmReqTabObj.prev_org_name = ""; 
     outEesAdmReqTabObj.prev_class_id = ""; 
     outEesAdmReqTabObj.prev_class_num = ""; 
     outEesAdmReqTabObj.prev_class_std = ""; 
     outEesAdmReqTabObj.prev_class_section = ""; 
     outEesAdmReqTabObj.prev_course_id = ""; 
     outEesAdmReqTabObj.prev_course_term = ""; 
     outEesAdmReqTabObj.prev_course_stream = ""; 
     outEesAdmReqTabObj.reason_for_leaving = ""; 
     outEesAdmReqTabObj.father_name = ""; 
     outEesAdmReqTabObj.father_age = (int)0; 
     outEesAdmReqTabObj.f_nationality = ""; 
     outEesAdmReqTabObj.father_occ_type = ""; 
     outEesAdmReqTabObj.father_employer = ""; 
     outEesAdmReqTabObj.father_designation = ""; 
     outEesAdmReqTabObj.father_annual_income = (double)0.00; 
     outEesAdmReqTabObj.f_off_address_1 = ""; 
     outEesAdmReqTabObj.f_phone_list = ""; 
     outEesAdmReqTabObj.mother_name = ""; 
     outEesAdmReqTabObj.mother_age = (int)0; 
     outEesAdmReqTabObj.m_nationality = ""; 
     outEesAdmReqTabObj.mother_occ_type = ""; 
     outEesAdmReqTabObj.mother_employer = ""; 
     outEesAdmReqTabObj.mother_designation = ""; 
     outEesAdmReqTabObj.mother_annual_income = (double)0.00; 
     outEesAdmReqTabObj.m_off_address_1 = ""; 
     outEesAdmReqTabObj.m_phone_list = ""; 
     outEesAdmReqTabObj.divorced_flag = ""; 
     outEesAdmReqTabObj.child_with = ""; 
     outEesAdmReqTabObj.roll_num = ""; 
     outEesAdmReqTabObj.academic_session = ""; 
     outEesAdmReqTabObj.adm_req_sts = ""; 
     outEesAdmReqTabObj.adm_req_sts_date = ""; 
     outEesAdmReqTabObj.student_id = ""; 
     outEesAdmReqTabObj.scholor_num = ""; 
     outEesAdmReqTabObj.form_recv_date = ""; 
     outEesAdmReqTabObj.form_recv_time = ""; 
     outEesAdmReqTabObj.prospectus_sale_date = ""; 
     outEesAdmReqTabObj.prospectus_sale_time = ""; 
     outEesAdmReqTabObj.prospectus_sold_by = ""; 
     outEesAdmReqTabObj.application_form_fee = (double)0.00; 
     outEesAdmReqTabObj.adm_academic_session = ""; 
     outEesAdmReqTabObj.entrance_exam_date = ""; 
     outEesAdmReqTabObj.entrance_exam_time_start = ""; 
     outEesAdmReqTabObj.entrance_exam_time_end = ""; 
     outEesAdmReqTabObj.exam_present_status = ""; 
     outEesAdmReqTabObj.building_id = ""; 
     outEesAdmReqTabObj.floor_num = ""; 
     outEesAdmReqTabObj.room_num = ""; 
     outEesAdmReqTabObj.max_mark = (int)0; 
     outEesAdmReqTabObj.obtained_mark = (int)0; 
     outEesAdmReqTabObj.grade = ""; 
     outEesAdmReqTabObj.fee_sch_date = ""; 
     outEesAdmReqTabObj.fee_deposit_date = ""; 
     outEesAdmReqTabObj.online_flag = ""; 
     outEesAdmReqTabObj.admission_mode = ""; 
     outEesAdmReqTabObj.course_stream_1 = ""; 
     outEesAdmReqTabObj.course_stream_2 = ""; 
     outEesAdmReqTabObj.course_stream_3 = ""; 
     outEesAdmReqTabObj.course_stream_4 = ""; 
     outEesAdmReqTabObj.apr_course_stream = ""; 
     outEesAdmReqTabObj.unv_1 = ""; 
     outEesAdmReqTabObj.unv_rn_1 = ""; 
     outEesAdmReqTabObj.gen_rank_1 = ""; 
     outEesAdmReqTabObj.ctg_rank_1 = ""; 
     outEesAdmReqTabObj.stt_rank_1 = ""; 
     outEesAdmReqTabObj.yoa_1 = ""; 
     outEesAdmReqTabObj.unv_2 = ""; 
     outEesAdmReqTabObj.unv_rn_2 = ""; 
     outEesAdmReqTabObj.gen_rank_2 = ""; 
     outEesAdmReqTabObj.ctg_rank_2 = ""; 
     outEesAdmReqTabObj.stt_rank_2 = ""; 
     outEesAdmReqTabObj.yoa_2 = ""; 
     outEesAdmReqTabObj.prev_mark_percent = (float)0.00; 
     outEesAdmReqTabObj.domecile_ind = ""; 
     outEesAdmReqTabObj.org_transport_req_ind = ""; 
     outEesAdmReqTabObj.org_hostel_req_ind = ""; 
     outEesAdmReqTabObj.cheque_num = ""; 
     outEesAdmReqTabObj.cheque_date = ""; 
     outEesAdmReqTabObj.bank_code = ""; 
     outEesAdmReqTabObj.bank_name = ""; 
     outEesAdmReqTabObj.cheque_amt = (double)0.00; 
     outEesAdmReqTabObj.lg_0_name = ""; 
     outEesAdmReqTabObj.lg_0_rel_type = ""; 
     outEesAdmReqTabObj.lg_0_address = ""; 
     outEesAdmReqTabObj.lg_0_phone = ""; 
     outEesAdmReqTabObj.lg_1_name = ""; 
     outEesAdmReqTabObj.lg_1_rel_type = ""; 
     outEesAdmReqTabObj.lg_1_address = ""; 
     outEesAdmReqTabObj.lg_1_phone = ""; 
     outEesAdmReqTabObj.st_cap_attr_1 = ""; 
     outEesAdmReqTabObj.st_cap_attr_2 = ""; 
     outEesAdmReqTabObj.st_cap_attr_3 = ""; 
     outEesAdmReqTabObj.st_cap_attr_4 = ""; 
     outEesAdmReqTabObj.st_cap_attr_5 = ""; 
     outEesAdmReqTabObj.st_cap_attr_6 = ""; 
     outEesAdmReqTabObj.st_cap_attr_7 = ""; 
     outEesAdmReqTabObj.st_cap_attr_8 = ""; 
     outEesAdmReqTabObj.allergy = ""; 
     outEesAdmReqTabObj.physical_disability = ""; 
     outEesAdmReqTabObj.health_problem = ""; 
     outEesAdmReqTabObj.health_problem_1 = ""; 
     outEesAdmReqTabObj.health_problem_2 = ""; 
     outEesAdmReqTabObj.health_problem_3 = ""; 
     outEesAdmReqTabObj.health_problem_4 = ""; 
     outEesAdmReqTabObj.health_problem_5 = ""; 
     outEesAdmReqTabObj.health_problem_6 = ""; 
     outEesAdmReqTabObj.health_problem_7 = ""; 
     outEesAdmReqTabObj.health_problem_8 = ""; 
     outEesAdmReqTabObj.health_problem_9 = ""; 
     outEesAdmReqTabObj.health_problem_10 = ""; 
     outEesAdmReqTabObj.health_problem_11 = ""; 
     outEesAdmReqTabObj.health_problem_12 = ""; 
     outEesAdmReqTabObj.enclosure_1 = ""; 
     outEesAdmReqTabObj.enclosure_2 = ""; 
     outEesAdmReqTabObj.enclosure_3 = ""; 
     outEesAdmReqTabObj.enclosure_4 = ""; 
     outEesAdmReqTabObj.enclosure_5 = ""; 
     outEesAdmReqTabObj.enclosure_6 = ""; 
     outEesAdmReqTabObj.enclosure_7 = ""; 
     outEesAdmReqTabObj.enclosure_8 = ""; 
     outEesAdmReqTabObj.seat_num = (int)0; 
     outEesAdmReqTabObj.reason_for_join = ""; 
     outEesAdmReqTabObj.remark = ""; 
     outEesAdmReqTabObj.place_of_birth = ""; 
     outEesAdmReqTabObj.adv_adm_fee = (double)0.00; 
     outEesAdmReqTabObj.payment_mode = ""; 
     outEesAdmReqTabObj.target_ptl_user_id = ""; 
     outEesAdmReqTabObj.adm_req_id_req = ""; 
     outEesAdmReqTabObj.adm_req_id_list = ""; 
  }





  public void guiDateConvEesAdmReqTabObj
               ( 
                 EesAdmReqTabObj  inEesAdmReqTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesAdmReqTabObj.dob != null && inEesAdmReqTabObj.dob.length() > 0 ) 
            inEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.dob, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.age_on_date != null && inEesAdmReqTabObj.age_on_date.length() > 0 ) 
            inEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.adm_req_sts_date != null && inEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.form_recv_date != null && inEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            inEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.prospectus_sale_date != null && inEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.entrance_exam_date != null && inEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.fee_sch_date != null && inEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.fee_deposit_date != null && inEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);

          if ( inEesAdmReqTabObj.cheque_date != null && inEesAdmReqTabObj.cheque_date.length() > 0 ) 
            inEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesAdmReqByTabObj
               ( 
                 EesAdmReqTabObj  inEesAdmReqTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesAdmReqTabObjArrCtx  = new ArrayList(); 
    lEesAdmReqTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesAdmReqTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesAdmReqTabObjArrCtx.add(inEesAdmReqTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesAdmReqTabObjArrCtx.size();  lRecNum++ )
      {
        EesAdmReqTabObj lEesAdmReqTabObj = new EesAdmReqTabObj();
        lEesAdmReqTabObj = (EesAdmReqTabObj)lEesAdmReqTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesAdmReqTabObj.org_id.equals(lEesAdmReqTabObj.org_id) &&
              lEesAdmReqTabObj.adm_req_id.equals(lEesAdmReqTabObj.adm_req_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesAdmReqTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesAdmReqTabObjArrCtx.set(lRecNum, inEesAdmReqTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesAdmReqTabObjArrCtx",lEesAdmReqTabObjArrCtx);
  }





  public void sortEesAdmReqTabObjArr
               ( 
                 ArrayList  inEesAdmReqTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesAdmReqTabObjArr  = new ArrayList(); 
     lEesAdmReqTabObjArr = inEesAdmReqTabObjArr; 
     List lEesAdmReqTabObjList  = new ArrayList(lEesAdmReqTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesAdmReqTabObjArr.size();  lRecNum++ )
     {
       EesAdmReqTabObj  lEesAdmReqTabObj = new EesAdmReqTabObj(); 
       lEesAdmReqTabObj = (EesAdmReqTabObj)lEesAdmReqTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.adm_req_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_req_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("application_form_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.application_form_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.application_form_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("applicant_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.applicant_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.applicant_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmReqTabObj.student_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmReqTabObj.mother_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmReqTabObj.father_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("name_initials") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.name_initials.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.name_initials+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_f_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.student_f_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_f_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_m_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.student_m_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_m_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_l_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.student_l_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_l_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dob") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.dob.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.dob+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_on_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.age_on_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.age_on_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_year") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmReqTabObj.age_year).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.age_year+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_month") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - lEesAdmReqTabObj.age_month.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.age_month+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_day") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmReqTabObj.age_day).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.age_day+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("s_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.s_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.s_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("religion") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.religion.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.religion+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.student_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gender_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.gender_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.gender_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.p_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.p_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.p_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.p_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.p_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_district") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.p_district.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_district+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.p_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.p_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.m_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.m_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.m_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.m_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.m_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_district") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.m_district.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_district+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.m_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.email_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.email_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fax_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.fax_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.fax_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_org_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmReqTabObj.prev_org_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_org_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.prev_class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prev_course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reason_for_leaving") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.reason_for_leaving.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.reason_for_leaving+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.father_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_age") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmReqTabObj.father_age).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_age+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.f_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.f_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_occ_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.father_occ_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_occ_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_employer") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.father_employer.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_employer+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmReqTabObj.father_designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_annual_income") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmReqTabObj.father_annual_income).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.father_annual_income+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_off_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.f_off_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.f_off_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.f_phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.f_phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.mother_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_age") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmReqTabObj.mother_age).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_age+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.m_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_occ_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.mother_occ_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_occ_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_employer") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.mother_employer.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_employer+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmReqTabObj.mother_designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_annual_income") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmReqTabObj.mother_annual_income).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.mother_annual_income+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_off_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.m_off_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_off_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.m_phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.m_phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("divorced_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.divorced_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.divorced_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("child_with") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.child_with.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.child_with+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("roll_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.roll_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.roll_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("academic_session") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (11 - lEesAdmReqTabObj.academic_session.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.academic_session+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.adm_req_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_req_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.adm_req_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_req_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.student_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.student_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("scholor_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.scholor_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.scholor_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("form_recv_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.form_recv_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.form_recv_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("form_recv_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmReqTabObj.form_recv_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.form_recv_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sale_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.prospectus_sale_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prospectus_sale_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sale_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmReqTabObj.prospectus_sale_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prospectus_sale_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sold_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.prospectus_sold_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prospectus_sold_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("application_form_fee") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmReqTabObj.application_form_fee).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.application_form_fee+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_academic_session") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (11 - lEesAdmReqTabObj.adm_academic_session.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_academic_session+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.entrance_exam_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.entrance_exam_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_time_start") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmReqTabObj.entrance_exam_time_start.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.entrance_exam_time_start+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_time_end") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmReqTabObj.entrance_exam_time_end.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.entrance_exam_time_end+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_present_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.exam_present_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.exam_present_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("building_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.building_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.building_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("floor_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.floor_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.floor_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("room_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.room_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.room_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("max_mark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (4 - Short.toString(lEesAdmReqTabObj.max_mark).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.max_mark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("obtained_mark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (4 - Short.toString(lEesAdmReqTabObj.obtained_mark).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.obtained_mark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("grade") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.grade.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.grade+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fee_sch_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.fee_sch_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.fee_sch_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fee_deposit_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.fee_deposit_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.fee_deposit_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("online_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.online_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.online_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("admission_mode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.admission_mode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.admission_mode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_stream_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_stream_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_stream_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_stream_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_stream_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_stream_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.course_stream_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.course_stream_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("apr_course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.apr_course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.apr_course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.unv_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.unv_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_rn_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.unv_rn_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.unv_rn_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gen_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.gen_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.gen_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ctg_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.ctg_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.ctg_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stt_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.stt_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.stt_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("yoa_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.yoa_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.yoa_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.unv_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.unv_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_rn_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.unv_rn_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.unv_rn_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gen_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.gen_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.gen_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ctg_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.ctg_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.ctg_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stt_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.stt_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.stt_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("yoa_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmReqTabObj.yoa_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.yoa_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_mark_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - Float.toString(lEesAdmReqTabObj.prev_mark_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.prev_mark_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("domecile_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.domecile_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.domecile_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_transport_req_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.org_transport_req_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.org_transport_req_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_hostel_req_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.org_hostel_req_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.org_hostel_req_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.cheque_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.cheque_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmReqTabObj.cheque_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.cheque_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bank_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmReqTabObj.bank_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.bank_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bank_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmReqTabObj.bank_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.bank_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_amt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmReqTabObj.cheque_amt).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.cheque_amt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_0_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_0_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_rel_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_0_rel_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_0_rel_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_address") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_0_address.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_0_address+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.lg_0_phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_0_phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_1_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_1_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_rel_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_1_rel_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_1_rel_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_address") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.lg_1_address.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_1_address+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.lg_1_phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.lg_1_phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.st_cap_attr_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.st_cap_attr_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allergy") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.allergy.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.allergy+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("physical_disability") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.physical_disability.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.physical_disability+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.health_problem.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_9") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_9.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_9+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_10") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_10.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_10+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_11") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_11.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_11+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_12") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.health_problem_12.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.health_problem_12+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmReqTabObj.enclosure_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.enclosure_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("seat_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (3 - Short.toString(lEesAdmReqTabObj.seat_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.seat_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reason_for_join") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.reason_for_join.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.reason_for_join+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("place_of_birth") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmReqTabObj.place_of_birth.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.place_of_birth+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adv_adm_fee") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmReqTabObj.adv_adm_fee).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adv_adm_fee+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("payment_mode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmReqTabObj.payment_mode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.payment_mode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("target_ptl_user_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmReqTabObj.target_ptl_user_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.target_ptl_user_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_req") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.adm_req_id_req.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_req_id_req+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmReqTabObj.adm_req_id_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmReqTabObj.adm_req_id_list+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesAdmReqTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesAdmReqTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesAdmReqTabObjList ); 
     ArrayList lEesAdmReqTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesAdmReqTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesAdmReqTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesAdmReqTabObjArrSorted.add( (EesAdmReqTabObj)lEesAdmReqTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesAdmReqTabObjArr.size();  lRecNum++ )
     {
       inEesAdmReqTabObjArr.set( lRecNum, (EesAdmReqTabObj)lEesAdmReqTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesAdmReqTabObj
               ( 
                 EesAdmReqTabObj  inEesAdmReqTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesAdmReqTabObj.dob != null && inEesAdmReqTabObj.dob.length() > 0 ) 
            inEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.age_on_date != null && inEesAdmReqTabObj.age_on_date.length() > 0 ) 
            inEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.adm_req_sts_date != null && inEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.form_recv_date != null && inEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            inEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.prospectus_sale_date != null && inEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.entrance_exam_date != null && inEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_sch_date != null && inEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_deposit_date != null && inEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.cheque_date != null && inEesAdmReqTabObj.cheque_date.length() > 0 ) 
            inEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.cheque_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicationFormNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICATION_FORM_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicantId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICANT_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNameInitials
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NAME_INITIALS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentFName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_F_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentMName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_M_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentLName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_L_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDob
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOB";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeOnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_ON_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeYear
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_YEAR";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeMonth
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_MONTH";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeDay
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_DAY";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeS_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "S_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReligion
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELIGION";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_CTG";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenderFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GENDER_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_district
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_DISTRICT";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_district
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_DISTRICT";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFaxList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FAX_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevOrgName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ORG_NAME";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReasonForLeaving
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REASON_FOR_LEAVING";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherAge
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_AGE";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherOccType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_OCC_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherEmployer
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_EMPLOYER";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherAnnualIncome
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_ANNUAL_INCOME";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_off_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_OFF_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_phone_list
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherAge
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_AGE";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherOccType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_OCC_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherEmployer
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_EMPLOYER";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherAnnualIncome
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_ANNUAL_INCOME";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_off_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_OFF_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_phone_list
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDivorcedFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DIVORCED_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChildWith
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHILD_WITH";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRollNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROLL_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAcademicSession
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 11 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACADEMIC_SESSION";
      String lErrorReason = "Size Greater Than 11";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeScholorNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SCHOLOR_NUM";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFormRecvDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FORM_RECV_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFormRecvTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FORM_RECV_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSaleDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SALE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSaleTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SALE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSoldBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SOLD_BY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicationFormFee
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICATION_FORM_FEE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmAcademicSession
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 11 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_ACADEMIC_SESSION";
      String lErrorReason = "Size Greater Than 11";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamTimeStart
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_TIME_START";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamTimeEnd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_TIME_END";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamPresentStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_PRESENT_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBuildingId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUILDING_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFloorNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FLOOR_NUM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRoomNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROOM_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMaxMark
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 4 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MAX_MARK";
      String lErrorReason = "Size Greater Than 4";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeObtainedMark
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 4 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OBTAINED_MARK";
      String lErrorReason = "Size Greater Than 4";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGrade
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GRADE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFeeSchDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FEE_SCH_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFeeDepositDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FEE_DEPOSIT_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOnlineFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ONLINE_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmissionMode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADMISSION_MODE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_3";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_4";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAprCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APR_COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnv1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnvRn1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_RN_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GEN_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCtgRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CTG_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSttRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STT_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeYoa1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "YOA_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnv2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnvRn2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_RN_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GEN_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCtgRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CTG_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSttRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STT_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeYoa2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "YOA_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevMarkPercent
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_MARK_PERCENT";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDomecileInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOMECILE_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgTransportReqInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_TRANSPORT_REQ_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgHostelReqInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_HOSTEL_REQ_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_NUM";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANK_CODE";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANK_NAME";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeAmt
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_AMT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Name
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0RelType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_REL_TYPE";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Address
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_ADDRESS";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Phone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Name
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1RelType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_REL_TYPE";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Address
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_ADDRESS";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Phone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_1";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_2";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_3";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_4";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_5";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_6";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_7";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_8";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllergy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLERGY";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhysicalDisability
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHYSICAL_DISABILITY";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_1";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_2";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_3";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_4";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_5";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_6";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_7";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_8";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem9
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_9";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem10
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_10";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem11
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_11";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem12
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_12";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_1";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_2";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_3";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_4";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_5";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_6";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_7";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_8";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSeatNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 3 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SEAT_NUM";
      String lErrorReason = "Size Greater Than 3";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReasonForJoin
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REASON_FOR_JOIN";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePlaceOfBirth
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PLACE_OF_BIRTH";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdvAdmFee
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADV_ADM_FEE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePaymentMode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAYMENT_MODE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTargetPtlUserId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TARGET_PTL_USER_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdReq
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_REQ";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_LIST";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesAdmReqCount
               ( String inEesAdmReqWhereText
               )
  {
    sop("gtEesAdmReqCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqCount
               ( String inEesAdmReqWhereText
               , String inEesAdmReqSelectFieldList
               )
  {
    sop("gtEesAdmReqCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesAdmReqSelectFieldList+" AS count "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqRecByPkey
               ( EesAdmReqPkeyObj inEesAdmReqPkeyObj
               , EesAdmReqTabObj  outEesAdmReqTabObj
               )
  {
    sop("gtEesAdmReqRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_REQ " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAdmReqPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmReqPkeyObj.adm_req_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesAdmReqTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAdmReqTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAdmReqTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          outEesAdmReqTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          outEesAdmReqTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAdmReqTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          outEesAdmReqTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          outEesAdmReqTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          outEesAdmReqTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAdmReqTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAdmReqTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAdmReqTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAdmReqTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAdmReqTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAdmReqTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAdmReqTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outEesAdmReqTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          outEesAdmReqTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          outEesAdmReqTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          outEesAdmReqTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAdmReqTabObj.dob != null && outEesAdmReqTabObj.dob.length() > 0 ) 
            outEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.dob, lDateTimeTrgFmt);
          outEesAdmReqTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( outEesAdmReqTabObj.age_on_date != null && outEesAdmReqTabObj.age_on_date.length() > 0 ) 
            outEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          outEesAdmReqTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          outEesAdmReqTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          outEesAdmReqTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          outEesAdmReqTabObj.religion  =  lResultSet.getString("RELIGION");
          outEesAdmReqTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAdmReqTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAdmReqTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outEesAdmReqTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outEesAdmReqTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outEesAdmReqTabObj.p_state  =  lResultSet.getString("P_STATE");
          outEesAdmReqTabObj.p_city  =  lResultSet.getString("P_CITY");
          outEesAdmReqTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          outEesAdmReqTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outEesAdmReqTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outEesAdmReqTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outEesAdmReqTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outEesAdmReqTabObj.m_state  =  lResultSet.getString("M_STATE");
          outEesAdmReqTabObj.m_city  =  lResultSet.getString("M_CITY");
          outEesAdmReqTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          outEesAdmReqTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outEesAdmReqTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAdmReqTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAdmReqTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outEesAdmReqTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          outEesAdmReqTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAdmReqTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAdmReqTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAdmReqTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAdmReqTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAdmReqTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAdmReqTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAdmReqTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          outEesAdmReqTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAdmReqTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          outEesAdmReqTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          outEesAdmReqTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          outEesAdmReqTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          outEesAdmReqTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          outEesAdmReqTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          outEesAdmReqTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          outEesAdmReqTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          outEesAdmReqTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAdmReqTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          outEesAdmReqTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          outEesAdmReqTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          outEesAdmReqTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          outEesAdmReqTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          outEesAdmReqTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          outEesAdmReqTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          outEesAdmReqTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          outEesAdmReqTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          outEesAdmReqTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          outEesAdmReqTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAdmReqTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesAdmReqTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          outEesAdmReqTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( outEesAdmReqTabObj.adm_req_sts_date != null && outEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            outEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          outEesAdmReqTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          outEesAdmReqTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( outEesAdmReqTabObj.form_recv_date != null && outEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            outEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          outEesAdmReqTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( outEesAdmReqTabObj.prospectus_sale_date != null && outEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            outEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          outEesAdmReqTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          outEesAdmReqTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          outEesAdmReqTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          outEesAdmReqTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( outEesAdmReqTabObj.entrance_exam_date != null && outEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            outEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          outEesAdmReqTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          outEesAdmReqTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          outEesAdmReqTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outEesAdmReqTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outEesAdmReqTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outEesAdmReqTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          outEesAdmReqTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          outEesAdmReqTabObj.grade  =  lResultSet.getString("GRADE");
          outEesAdmReqTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( outEesAdmReqTabObj.fee_sch_date != null && outEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            outEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( outEesAdmReqTabObj.fee_deposit_date != null && outEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            outEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          outEesAdmReqTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          outEesAdmReqTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          outEesAdmReqTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          outEesAdmReqTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          outEesAdmReqTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          outEesAdmReqTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          outEesAdmReqTabObj.unv_1  =  lResultSet.getString("UNV_1");
          outEesAdmReqTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          outEesAdmReqTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          outEesAdmReqTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          outEesAdmReqTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          outEesAdmReqTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          outEesAdmReqTabObj.unv_2  =  lResultSet.getString("UNV_2");
          outEesAdmReqTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          outEesAdmReqTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          outEesAdmReqTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          outEesAdmReqTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          outEesAdmReqTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          outEesAdmReqTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          outEesAdmReqTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          outEesAdmReqTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          outEesAdmReqTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          outEesAdmReqTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          outEesAdmReqTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( outEesAdmReqTabObj.cheque_date != null && outEesAdmReqTabObj.cheque_date.length() > 0 ) 
            outEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          outEesAdmReqTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          outEesAdmReqTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          outEesAdmReqTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          outEesAdmReqTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          outEesAdmReqTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          outEesAdmReqTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          outEesAdmReqTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          outEesAdmReqTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          outEesAdmReqTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          outEesAdmReqTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          outEesAdmReqTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          outEesAdmReqTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          outEesAdmReqTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          outEesAdmReqTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          outEesAdmReqTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          outEesAdmReqTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          outEesAdmReqTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          outEesAdmReqTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          outEesAdmReqTabObj.allergy  =  lResultSet.getString("ALLERGY");
          outEesAdmReqTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          outEesAdmReqTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          outEesAdmReqTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          outEesAdmReqTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          outEesAdmReqTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          outEesAdmReqTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          outEesAdmReqTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          outEesAdmReqTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          outEesAdmReqTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          outEesAdmReqTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          outEesAdmReqTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          outEesAdmReqTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          outEesAdmReqTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          outEesAdmReqTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          outEesAdmReqTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          outEesAdmReqTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          outEesAdmReqTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          outEesAdmReqTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          outEesAdmReqTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          outEesAdmReqTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          outEesAdmReqTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          outEesAdmReqTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          outEesAdmReqTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          outEesAdmReqTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          outEesAdmReqTabObj.remark  =  lResultSet.getString("REMARK");
          outEesAdmReqTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          outEesAdmReqTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          outEesAdmReqTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          outEesAdmReqTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          outEesAdmReqTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAdmReqTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAdmReqTabObj( outEesAdmReqTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqArr
               ( EesAdmReqPkeyObj inEesAdmReqPkeyObj
               , ArrayList  outEesAdmReqTabObjArr
               )
  {
    sop("gtEesAdmReqArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_REQ";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAdmReqTabObj  lEesAdmReqTabObj = new EesAdmReqTabObj();
          lEesAdmReqTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesAdmReqTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAdmReqTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          lEesAdmReqTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          lEesAdmReqTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAdmReqTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          lEesAdmReqTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          lEesAdmReqTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          lEesAdmReqTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAdmReqTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAdmReqTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAdmReqTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAdmReqTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAdmReqTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAdmReqTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAdmReqTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lEesAdmReqTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          lEesAdmReqTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          lEesAdmReqTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          lEesAdmReqTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAdmReqTabObj.dob != null && lEesAdmReqTabObj.dob.length() > 0 ) 
            lEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.dob, lDateTimeTrgFmt);
          lEesAdmReqTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( lEesAdmReqTabObj.age_on_date != null && lEesAdmReqTabObj.age_on_date.length() > 0 ) 
            lEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          lEesAdmReqTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          lEesAdmReqTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          lEesAdmReqTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          lEesAdmReqTabObj.religion  =  lResultSet.getString("RELIGION");
          lEesAdmReqTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAdmReqTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAdmReqTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lEesAdmReqTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lEesAdmReqTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lEesAdmReqTabObj.p_state  =  lResultSet.getString("P_STATE");
          lEesAdmReqTabObj.p_city  =  lResultSet.getString("P_CITY");
          lEesAdmReqTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          lEesAdmReqTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lEesAdmReqTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lEesAdmReqTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lEesAdmReqTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lEesAdmReqTabObj.m_state  =  lResultSet.getString("M_STATE");
          lEesAdmReqTabObj.m_city  =  lResultSet.getString("M_CITY");
          lEesAdmReqTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          lEesAdmReqTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lEesAdmReqTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAdmReqTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAdmReqTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lEesAdmReqTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          lEesAdmReqTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAdmReqTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAdmReqTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAdmReqTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAdmReqTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAdmReqTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAdmReqTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAdmReqTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          lEesAdmReqTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAdmReqTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          lEesAdmReqTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          lEesAdmReqTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          lEesAdmReqTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          lEesAdmReqTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          lEesAdmReqTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          lEesAdmReqTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          lEesAdmReqTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          lEesAdmReqTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAdmReqTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          lEesAdmReqTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          lEesAdmReqTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          lEesAdmReqTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          lEesAdmReqTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          lEesAdmReqTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          lEesAdmReqTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          lEesAdmReqTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          lEesAdmReqTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          lEesAdmReqTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          lEesAdmReqTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAdmReqTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesAdmReqTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          lEesAdmReqTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( lEesAdmReqTabObj.adm_req_sts_date != null && lEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          lEesAdmReqTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          lEesAdmReqTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( lEesAdmReqTabObj.form_recv_date != null && lEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            lEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          lEesAdmReqTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( lEesAdmReqTabObj.prospectus_sale_date != null && lEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          lEesAdmReqTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          lEesAdmReqTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          lEesAdmReqTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          lEesAdmReqTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( lEesAdmReqTabObj.entrance_exam_date != null && lEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          lEesAdmReqTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          lEesAdmReqTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          lEesAdmReqTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lEesAdmReqTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lEesAdmReqTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lEesAdmReqTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          lEesAdmReqTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          lEesAdmReqTabObj.grade  =  lResultSet.getString("GRADE");
          lEesAdmReqTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( lEesAdmReqTabObj.fee_sch_date != null && lEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( lEesAdmReqTabObj.fee_deposit_date != null && lEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          lEesAdmReqTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          lEesAdmReqTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          lEesAdmReqTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          lEesAdmReqTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          lEesAdmReqTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          lEesAdmReqTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          lEesAdmReqTabObj.unv_1  =  lResultSet.getString("UNV_1");
          lEesAdmReqTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          lEesAdmReqTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          lEesAdmReqTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          lEesAdmReqTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          lEesAdmReqTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          lEesAdmReqTabObj.unv_2  =  lResultSet.getString("UNV_2");
          lEesAdmReqTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          lEesAdmReqTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          lEesAdmReqTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          lEesAdmReqTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          lEesAdmReqTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          lEesAdmReqTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          lEesAdmReqTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          lEesAdmReqTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          lEesAdmReqTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          lEesAdmReqTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          lEesAdmReqTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( lEesAdmReqTabObj.cheque_date != null && lEesAdmReqTabObj.cheque_date.length() > 0 ) 
            lEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          lEesAdmReqTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          lEesAdmReqTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          lEesAdmReqTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          lEesAdmReqTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          lEesAdmReqTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          lEesAdmReqTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          lEesAdmReqTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          lEesAdmReqTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          lEesAdmReqTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          lEesAdmReqTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          lEesAdmReqTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          lEesAdmReqTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          lEesAdmReqTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          lEesAdmReqTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          lEesAdmReqTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          lEesAdmReqTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          lEesAdmReqTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          lEesAdmReqTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          lEesAdmReqTabObj.allergy  =  lResultSet.getString("ALLERGY");
          lEesAdmReqTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          lEesAdmReqTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          lEesAdmReqTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          lEesAdmReqTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          lEesAdmReqTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          lEesAdmReqTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          lEesAdmReqTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          lEesAdmReqTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          lEesAdmReqTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          lEesAdmReqTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          lEesAdmReqTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          lEesAdmReqTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          lEesAdmReqTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          lEesAdmReqTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          lEesAdmReqTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          lEesAdmReqTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          lEesAdmReqTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          lEesAdmReqTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          lEesAdmReqTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          lEesAdmReqTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          lEesAdmReqTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          lEesAdmReqTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          lEesAdmReqTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          lEesAdmReqTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          lEesAdmReqTabObj.remark  =  lResultSet.getString("REMARK");
          lEesAdmReqTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          lEesAdmReqTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          lEesAdmReqTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          lEesAdmReqTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          lEesAdmReqTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAdmReqTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAdmReqTabObj( lEesAdmReqTabObj );

          outEesAdmReqTabObjArr.add(  lEesAdmReqTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmReqTabObjArr != null && outEesAdmReqTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesAdmReqArr2XML
               ( String inEesAdmReqWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesAdmReqArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesAdmReq>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID>" +  lResultSet.getString("ADM_REQ_ID") +   "</ADM_REQ_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("application_form_num") )
              lXmlBuffer = lXmlBuffer +   "<APPLICATION_FORM_NUM>" +  lResultSet.getString("APPLICATION_FORM_NUM") +   "</APPLICATION_FORM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("applicant_id") )
              lXmlBuffer = lXmlBuffer +   "<APPLICANT_ID>" +  lResultSet.getString("APPLICANT_ID") +   "</APPLICANT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_PHOTO_FILE>" +  lResultSet.getString("STUDENT_PHOTO_FILE") +   "</STUDENT_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_PHOTO_FILE>" +  lResultSet.getString("MOTHER_PHOTO_FILE") +   "</MOTHER_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_PHOTO_FILE>" +  lResultSet.getString("FATHER_PHOTO_FILE") +   "</FATHER_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_id") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_ID>" +  lResultSet.getString("CLASS_ID") +   "</CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_num") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_NUM>" +  lResultSet.getString("CLASS_NUM") +   "</CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_std") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_STD>" +  lResultSet.getString("CLASS_STD") +   "</CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_section") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_SECTION>" +  lResultSet.getString("CLASS_SECTION") +   "</CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_id") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_ID>" +  lResultSet.getString("COURSE_ID") +   "</COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_term") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_TERM>" +  lResultSet.getString("COURSE_TERM") +   "</COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM>" +  lResultSet.getString("COURSE_STREAM") +   "</COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("name_initials") )
              lXmlBuffer = lXmlBuffer +   "<NAME_INITIALS>" +  lResultSet.getString("NAME_INITIALS") +   "</NAME_INITIALS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_f_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_F_NAME>" +  lResultSet.getString("STUDENT_F_NAME") +   "</STUDENT_F_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_m_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_M_NAME>" +  lResultSet.getString("STUDENT_M_NAME") +   "</STUDENT_M_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_l_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_L_NAME>" +  lResultSet.getString("STUDENT_L_NAME") +   "</STUDENT_L_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dob") )
              lXmlBuffer = lXmlBuffer +   "<DOB>" +  lResultSet.getString("DOB") +   "</DOB>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_on_date") )
              lXmlBuffer = lXmlBuffer +   "<AGE_ON_DATE>" +  lResultSet.getString("AGE_ON_DATE") +   "</AGE_ON_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_year") )
              lXmlBuffer = lXmlBuffer +   "<AGE_YEAR>" +  lResultSet.getByte("AGE_YEAR") +   "</AGE_YEAR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_month") )
              lXmlBuffer = lXmlBuffer +   "<AGE_MONTH>" +  lResultSet.getString("AGE_MONTH") +   "</AGE_MONTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_day") )
              lXmlBuffer = lXmlBuffer +   "<AGE_DAY>" +  lResultSet.getByte("AGE_DAY") +   "</AGE_DAY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("s_nationality") )
              lXmlBuffer = lXmlBuffer +   "<S_NATIONALITY>" +  lResultSet.getString("S_NATIONALITY") +   "</S_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("religion") )
              lXmlBuffer = lXmlBuffer +   "<RELIGION>" +  lResultSet.getString("RELIGION") +   "</RELIGION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_ctg") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_CTG>" +  lResultSet.getString("STUDENT_CTG") +   "</STUDENT_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gender_flag") )
              lXmlBuffer = lXmlBuffer +   "<GENDER_FLAG>" +  lResultSet.getString("GENDER_FLAG") +   "</GENDER_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_1") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_1>" +  lResultSet.getString("P_ADDRESS_1") +   "</P_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_2") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_2>" +  lResultSet.getString("P_ADDRESS_2") +   "</P_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_country") )
              lXmlBuffer = lXmlBuffer +   "<P_COUNTRY>" +  lResultSet.getString("P_COUNTRY") +   "</P_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_state") )
              lXmlBuffer = lXmlBuffer +   "<P_STATE>" +  lResultSet.getString("P_STATE") +   "</P_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_city") )
              lXmlBuffer = lXmlBuffer +   "<P_CITY>" +  lResultSet.getString("P_CITY") +   "</P_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_district") )
              lXmlBuffer = lXmlBuffer +   "<P_DISTRICT>" +  lResultSet.getString("P_DISTRICT") +   "</P_DISTRICT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_zip") )
              lXmlBuffer = lXmlBuffer +   "<P_ZIP>" +  lResultSet.getString("P_ZIP") +   "</P_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_1") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_1>" +  lResultSet.getString("M_ADDRESS_1") +   "</M_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_2") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_2>" +  lResultSet.getString("M_ADDRESS_2") +   "</M_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_country") )
              lXmlBuffer = lXmlBuffer +   "<M_COUNTRY>" +  lResultSet.getString("M_COUNTRY") +   "</M_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_state") )
              lXmlBuffer = lXmlBuffer +   "<M_STATE>" +  lResultSet.getString("M_STATE") +   "</M_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_city") )
              lXmlBuffer = lXmlBuffer +   "<M_CITY>" +  lResultSet.getString("M_CITY") +   "</M_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_district") )
              lXmlBuffer = lXmlBuffer +   "<M_DISTRICT>" +  lResultSet.getString("M_DISTRICT") +   "</M_DISTRICT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_zip") )
              lXmlBuffer = lXmlBuffer +   "<M_ZIP>" +  lResultSet.getString("M_ZIP") +   "</M_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone_list") )
              lXmlBuffer = lXmlBuffer +   "<PHONE_LIST>" +  lResultSet.getString("PHONE_LIST") +   "</PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_list") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_LIST>" +  lResultSet.getString("EMAIL_LIST") +   "</EMAIL_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fax_list") )
              lXmlBuffer = lXmlBuffer +   "<FAX_LIST>" +  lResultSet.getString("FAX_LIST") +   "</FAX_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_org_name") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ORG_NAME>" +  lResultSet.getString("PREV_ORG_NAME") +   "</PREV_ORG_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_ID>" +  lResultSet.getString("PREV_CLASS_ID") +   "</PREV_CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_num") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_NUM>" +  lResultSet.getString("PREV_CLASS_NUM") +   "</PREV_CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_std") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_STD>" +  lResultSet.getString("PREV_CLASS_STD") +   "</PREV_CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_section") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_SECTION>" +  lResultSet.getString("PREV_CLASS_SECTION") +   "</PREV_CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_ID>" +  lResultSet.getString("PREV_COURSE_ID") +   "</PREV_COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_term") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_TERM>" +  lResultSet.getString("PREV_COURSE_TERM") +   "</PREV_COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_stream") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_STREAM>" +  lResultSet.getString("PREV_COURSE_STREAM") +   "</PREV_COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reason_for_leaving") )
              lXmlBuffer = lXmlBuffer +   "<REASON_FOR_LEAVING>" +  lResultSet.getString("REASON_FOR_LEAVING") +   "</REASON_FOR_LEAVING>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_name") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_NAME>" +  lResultSet.getString("FATHER_NAME") +   "</FATHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_age") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_AGE>" +  lResultSet.getByte("FATHER_AGE") +   "</FATHER_AGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_nationality") )
              lXmlBuffer = lXmlBuffer +   "<F_NATIONALITY>" +  lResultSet.getString("F_NATIONALITY") +   "</F_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_occ_type") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_OCC_TYPE>" +  lResultSet.getString("FATHER_OCC_TYPE") +   "</FATHER_OCC_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_employer") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_EMPLOYER>" +  lResultSet.getString("FATHER_EMPLOYER") +   "</FATHER_EMPLOYER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_designation") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_DESIGNATION>" +  lResultSet.getString("FATHER_DESIGNATION") +   "</FATHER_DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_annual_income") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_ANNUAL_INCOME>" +  lResultSet.getDouble("FATHER_ANNUAL_INCOME") +   "</FATHER_ANNUAL_INCOME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_off_address_1") )
              lXmlBuffer = lXmlBuffer +   "<F_OFF_ADDRESS_1>" +  lResultSet.getString("F_OFF_ADDRESS_1") +   "</F_OFF_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_phone_list") )
              lXmlBuffer = lXmlBuffer +   "<F_PHONE_LIST>" +  lResultSet.getString("F_PHONE_LIST") +   "</F_PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_name") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_NAME>" +  lResultSet.getString("MOTHER_NAME") +   "</MOTHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_age") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_AGE>" +  lResultSet.getByte("MOTHER_AGE") +   "</MOTHER_AGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_nationality") )
              lXmlBuffer = lXmlBuffer +   "<M_NATIONALITY>" +  lResultSet.getString("M_NATIONALITY") +   "</M_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_occ_type") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_OCC_TYPE>" +  lResultSet.getString("MOTHER_OCC_TYPE") +   "</MOTHER_OCC_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_employer") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_EMPLOYER>" +  lResultSet.getString("MOTHER_EMPLOYER") +   "</MOTHER_EMPLOYER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_designation") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_DESIGNATION>" +  lResultSet.getString("MOTHER_DESIGNATION") +   "</MOTHER_DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_annual_income") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_ANNUAL_INCOME>" +  lResultSet.getDouble("MOTHER_ANNUAL_INCOME") +   "</MOTHER_ANNUAL_INCOME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_off_address_1") )
              lXmlBuffer = lXmlBuffer +   "<M_OFF_ADDRESS_1>" +  lResultSet.getString("M_OFF_ADDRESS_1") +   "</M_OFF_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_phone_list") )
              lXmlBuffer = lXmlBuffer +   "<M_PHONE_LIST>" +  lResultSet.getString("M_PHONE_LIST") +   "</M_PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("divorced_flag") )
              lXmlBuffer = lXmlBuffer +   "<DIVORCED_FLAG>" +  lResultSet.getString("DIVORCED_FLAG") +   "</DIVORCED_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("child_with") )
              lXmlBuffer = lXmlBuffer +   "<CHILD_WITH>" +  lResultSet.getString("CHILD_WITH") +   "</CHILD_WITH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("roll_num") )
              lXmlBuffer = lXmlBuffer +   "<ROLL_NUM>" +  lResultSet.getString("ROLL_NUM") +   "</ROLL_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("academic_session") )
              lXmlBuffer = lXmlBuffer +   "<ACADEMIC_SESSION>" +  lResultSet.getString("ACADEMIC_SESSION") +   "</ACADEMIC_SESSION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_sts") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_STS>" +  lResultSet.getString("ADM_REQ_STS") +   "</ADM_REQ_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_STS_DATE>" +  lResultSet.getString("ADM_REQ_STS_DATE") +   "</ADM_REQ_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_id") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_ID>" +  lResultSet.getString("STUDENT_ID") +   "</STUDENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("scholor_num") )
              lXmlBuffer = lXmlBuffer +   "<SCHOLOR_NUM>" +  lResultSet.getString("SCHOLOR_NUM") +   "</SCHOLOR_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("form_recv_date") )
              lXmlBuffer = lXmlBuffer +   "<FORM_RECV_DATE>" +  lResultSet.getString("FORM_RECV_DATE") +   "</FORM_RECV_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("form_recv_time") )
              lXmlBuffer = lXmlBuffer +   "<FORM_RECV_TIME>" +  lResultSet.getString("FORM_RECV_TIME") +   "</FORM_RECV_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sale_date") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SALE_DATE>" +  lResultSet.getString("PROSPECTUS_SALE_DATE") +   "</PROSPECTUS_SALE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sale_time") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SALE_TIME>" +  lResultSet.getString("PROSPECTUS_SALE_TIME") +   "</PROSPECTUS_SALE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sold_by") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SOLD_BY>" +  lResultSet.getString("PROSPECTUS_SOLD_BY") +   "</PROSPECTUS_SOLD_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("application_form_fee") )
              lXmlBuffer = lXmlBuffer +   "<APPLICATION_FORM_FEE>" +  lResultSet.getDouble("APPLICATION_FORM_FEE") +   "</APPLICATION_FORM_FEE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_academic_session") )
              lXmlBuffer = lXmlBuffer +   "<ADM_ACADEMIC_SESSION>" +  lResultSet.getString("ADM_ACADEMIC_SESSION") +   "</ADM_ACADEMIC_SESSION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_date") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_DATE>" +  lResultSet.getString("ENTRANCE_EXAM_DATE") +   "</ENTRANCE_EXAM_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_time_start") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_TIME_START>" +  lResultSet.getString("ENTRANCE_EXAM_TIME_START") +   "</ENTRANCE_EXAM_TIME_START>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_time_end") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_TIME_END>" +  lResultSet.getString("ENTRANCE_EXAM_TIME_END") +   "</ENTRANCE_EXAM_TIME_END>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_present_status") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_PRESENT_STATUS>" +  lResultSet.getString("EXAM_PRESENT_STATUS") +   "</EXAM_PRESENT_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("building_id") )
              lXmlBuffer = lXmlBuffer +   "<BUILDING_ID>" +  lResultSet.getString("BUILDING_ID") +   "</BUILDING_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("floor_num") )
              lXmlBuffer = lXmlBuffer +   "<FLOOR_NUM>" +  lResultSet.getString("FLOOR_NUM") +   "</FLOOR_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("room_num") )
              lXmlBuffer = lXmlBuffer +   "<ROOM_NUM>" +  lResultSet.getString("ROOM_NUM") +   "</ROOM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("max_mark") )
              lXmlBuffer = lXmlBuffer +   "<MAX_MARK>" +  lResultSet.getShort("MAX_MARK") +   "</MAX_MARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("obtained_mark") )
              lXmlBuffer = lXmlBuffer +   "<OBTAINED_MARK>" +  lResultSet.getShort("OBTAINED_MARK") +   "</OBTAINED_MARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("grade") )
              lXmlBuffer = lXmlBuffer +   "<GRADE>" +  lResultSet.getString("GRADE") +   "</GRADE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fee_sch_date") )
              lXmlBuffer = lXmlBuffer +   "<FEE_SCH_DATE>" +  lResultSet.getString("FEE_SCH_DATE") +   "</FEE_SCH_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fee_deposit_date") )
              lXmlBuffer = lXmlBuffer +   "<FEE_DEPOSIT_DATE>" +  lResultSet.getString("FEE_DEPOSIT_DATE") +   "</FEE_DEPOSIT_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("online_flag") )
              lXmlBuffer = lXmlBuffer +   "<ONLINE_FLAG>" +  lResultSet.getString("ONLINE_FLAG") +   "</ONLINE_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("admission_mode") )
              lXmlBuffer = lXmlBuffer +   "<ADMISSION_MODE>" +  lResultSet.getString("ADMISSION_MODE") +   "</ADMISSION_MODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_1") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_1>" +  lResultSet.getString("COURSE_STREAM_1") +   "</COURSE_STREAM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_2") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_2>" +  lResultSet.getString("COURSE_STREAM_2") +   "</COURSE_STREAM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_3") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_3>" +  lResultSet.getString("COURSE_STREAM_3") +   "</COURSE_STREAM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_4") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_4>" +  lResultSet.getString("COURSE_STREAM_4") +   "</COURSE_STREAM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("apr_course_stream") )
              lXmlBuffer = lXmlBuffer +   "<APR_COURSE_STREAM>" +  lResultSet.getString("APR_COURSE_STREAM") +   "</APR_COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_1") )
              lXmlBuffer = lXmlBuffer +   "<UNV_1>" +  lResultSet.getString("UNV_1") +   "</UNV_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_rn_1") )
              lXmlBuffer = lXmlBuffer +   "<UNV_RN_1>" +  lResultSet.getString("UNV_RN_1") +   "</UNV_RN_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gen_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<GEN_RANK_1>" +  lResultSet.getString("GEN_RANK_1") +   "</GEN_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ctg_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<CTG_RANK_1>" +  lResultSet.getString("CTG_RANK_1") +   "</CTG_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stt_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<STT_RANK_1>" +  lResultSet.getString("STT_RANK_1") +   "</STT_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("yoa_1") )
              lXmlBuffer = lXmlBuffer +   "<YOA_1>" +  lResultSet.getString("YOA_1") +   "</YOA_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_2") )
              lXmlBuffer = lXmlBuffer +   "<UNV_2>" +  lResultSet.getString("UNV_2") +   "</UNV_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_rn_2") )
              lXmlBuffer = lXmlBuffer +   "<UNV_RN_2>" +  lResultSet.getString("UNV_RN_2") +   "</UNV_RN_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gen_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<GEN_RANK_2>" +  lResultSet.getString("GEN_RANK_2") +   "</GEN_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ctg_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<CTG_RANK_2>" +  lResultSet.getString("CTG_RANK_2") +   "</CTG_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stt_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<STT_RANK_2>" +  lResultSet.getString("STT_RANK_2") +   "</STT_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("yoa_2") )
              lXmlBuffer = lXmlBuffer +   "<YOA_2>" +  lResultSet.getString("YOA_2") +   "</YOA_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_mark_percent") )
              lXmlBuffer = lXmlBuffer +   "<PREV_MARK_PERCENT>" +  lResultSet.getFloat("PREV_MARK_PERCENT") +   "</PREV_MARK_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("domecile_ind") )
              lXmlBuffer = lXmlBuffer +   "<DOMECILE_IND>" +  lResultSet.getString("DOMECILE_IND") +   "</DOMECILE_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_transport_req_ind") )
              lXmlBuffer = lXmlBuffer +   "<ORG_TRANSPORT_REQ_IND>" +  lResultSet.getString("ORG_TRANSPORT_REQ_IND") +   "</ORG_TRANSPORT_REQ_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_hostel_req_ind") )
              lXmlBuffer = lXmlBuffer +   "<ORG_HOSTEL_REQ_IND>" +  lResultSet.getString("ORG_HOSTEL_REQ_IND") +   "</ORG_HOSTEL_REQ_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_num") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_NUM>" +  lResultSet.getString("CHEQUE_NUM") +   "</CHEQUE_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_date") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_DATE>" +  lResultSet.getString("CHEQUE_DATE") +   "</CHEQUE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bank_code") )
              lXmlBuffer = lXmlBuffer +   "<BANK_CODE>" +  lResultSet.getString("BANK_CODE") +   "</BANK_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bank_name") )
              lXmlBuffer = lXmlBuffer +   "<BANK_NAME>" +  lResultSet.getString("BANK_NAME") +   "</BANK_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_amt") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_AMT>" +  lResultSet.getDouble("CHEQUE_AMT") +   "</CHEQUE_AMT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_name") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_NAME>" +  lResultSet.getString("LG_0_NAME") +   "</LG_0_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_rel_type") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_REL_TYPE>" +  lResultSet.getString("LG_0_REL_TYPE") +   "</LG_0_REL_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_address") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_ADDRESS>" +  lResultSet.getString("LG_0_ADDRESS") +   "</LG_0_ADDRESS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_phone") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_PHONE>" +  lResultSet.getString("LG_0_PHONE") +   "</LG_0_PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_name") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_NAME>" +  lResultSet.getString("LG_1_NAME") +   "</LG_1_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_rel_type") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_REL_TYPE>" +  lResultSet.getString("LG_1_REL_TYPE") +   "</LG_1_REL_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_address") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_ADDRESS>" +  lResultSet.getString("LG_1_ADDRESS") +   "</LG_1_ADDRESS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_phone") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_PHONE>" +  lResultSet.getString("LG_1_PHONE") +   "</LG_1_PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_1") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_1>" +  lResultSet.getString("ST_CAP_ATTR_1") +   "</ST_CAP_ATTR_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_2") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_2>" +  lResultSet.getString("ST_CAP_ATTR_2") +   "</ST_CAP_ATTR_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_3") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_3>" +  lResultSet.getString("ST_CAP_ATTR_3") +   "</ST_CAP_ATTR_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_4") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_4>" +  lResultSet.getString("ST_CAP_ATTR_4") +   "</ST_CAP_ATTR_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_5") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_5>" +  lResultSet.getString("ST_CAP_ATTR_5") +   "</ST_CAP_ATTR_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_6") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_6>" +  lResultSet.getString("ST_CAP_ATTR_6") +   "</ST_CAP_ATTR_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_7") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_7>" +  lResultSet.getString("ST_CAP_ATTR_7") +   "</ST_CAP_ATTR_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_8") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_8>" +  lResultSet.getString("ST_CAP_ATTR_8") +   "</ST_CAP_ATTR_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allergy") )
              lXmlBuffer = lXmlBuffer +   "<ALLERGY>" +  lResultSet.getString("ALLERGY") +   "</ALLERGY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("physical_disability") )
              lXmlBuffer = lXmlBuffer +   "<PHYSICAL_DISABILITY>" +  lResultSet.getString("PHYSICAL_DISABILITY") +   "</PHYSICAL_DISABILITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM>" +  lResultSet.getString("HEALTH_PROBLEM") +   "</HEALTH_PROBLEM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_1") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_1>" +  lResultSet.getString("HEALTH_PROBLEM_1") +   "</HEALTH_PROBLEM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_2") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_2>" +  lResultSet.getString("HEALTH_PROBLEM_2") +   "</HEALTH_PROBLEM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_3") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_3>" +  lResultSet.getString("HEALTH_PROBLEM_3") +   "</HEALTH_PROBLEM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_4") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_4>" +  lResultSet.getString("HEALTH_PROBLEM_4") +   "</HEALTH_PROBLEM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_5") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_5>" +  lResultSet.getString("HEALTH_PROBLEM_5") +   "</HEALTH_PROBLEM_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_6") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_6>" +  lResultSet.getString("HEALTH_PROBLEM_6") +   "</HEALTH_PROBLEM_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_7") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_7>" +  lResultSet.getString("HEALTH_PROBLEM_7") +   "</HEALTH_PROBLEM_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_8") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_8>" +  lResultSet.getString("HEALTH_PROBLEM_8") +   "</HEALTH_PROBLEM_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_9") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_9>" +  lResultSet.getString("HEALTH_PROBLEM_9") +   "</HEALTH_PROBLEM_9>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_10") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_10>" +  lResultSet.getString("HEALTH_PROBLEM_10") +   "</HEALTH_PROBLEM_10>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_11") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_11>" +  lResultSet.getString("HEALTH_PROBLEM_11") +   "</HEALTH_PROBLEM_11>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_12") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_12>" +  lResultSet.getString("HEALTH_PROBLEM_12") +   "</HEALTH_PROBLEM_12>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_1") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_1>" +  lResultSet.getString("ENCLOSURE_1") +   "</ENCLOSURE_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_2") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_2>" +  lResultSet.getString("ENCLOSURE_2") +   "</ENCLOSURE_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_3") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_3>" +  lResultSet.getString("ENCLOSURE_3") +   "</ENCLOSURE_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_4") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_4>" +  lResultSet.getString("ENCLOSURE_4") +   "</ENCLOSURE_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_5") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_5>" +  lResultSet.getString("ENCLOSURE_5") +   "</ENCLOSURE_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_6") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_6>" +  lResultSet.getString("ENCLOSURE_6") +   "</ENCLOSURE_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_7") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_7>" +  lResultSet.getString("ENCLOSURE_7") +   "</ENCLOSURE_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_8") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_8>" +  lResultSet.getString("ENCLOSURE_8") +   "</ENCLOSURE_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("seat_num") )
              lXmlBuffer = lXmlBuffer +   "<SEAT_NUM>" +  lResultSet.getShort("SEAT_NUM") +   "</SEAT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reason_for_join") )
              lXmlBuffer = lXmlBuffer +   "<REASON_FOR_JOIN>" +  lResultSet.getString("REASON_FOR_JOIN") +   "</REASON_FOR_JOIN>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("place_of_birth") )
              lXmlBuffer = lXmlBuffer +   "<PLACE_OF_BIRTH>" +  lResultSet.getString("PLACE_OF_BIRTH") +   "</PLACE_OF_BIRTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adv_adm_fee") )
              lXmlBuffer = lXmlBuffer +   "<ADV_ADM_FEE>" +  lResultSet.getDouble("ADV_ADM_FEE") +   "</ADV_ADM_FEE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("payment_mode") )
              lXmlBuffer = lXmlBuffer +   "<PAYMENT_MODE>" +  lResultSet.getString("PAYMENT_MODE") +   "</PAYMENT_MODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("target_ptl_user_id") )
              lXmlBuffer = lXmlBuffer +   "<TARGET_PTL_USER_ID>" +  lResultSet.getString("TARGET_PTL_USER_ID") +   "</TARGET_PTL_USER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_req") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_REQ>" +  lResultSet.getString("ADM_REQ_ID_REQ") +   "</ADM_REQ_ID_REQ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_list") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_LIST>" +  lResultSet.getString("ADM_REQ_ID_LIST") +   "</ADM_REQ_ID_LIST>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesAdmReq>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesAdmReqRecByRowid
               ( String inRowId
               , EesAdmReqTabObj  outEesAdmReqTabObj
               )
  {
    sop("gtEesAdmReqRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_REQ "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesAdmReqTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAdmReqTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAdmReqTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          outEesAdmReqTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          outEesAdmReqTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAdmReqTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          outEesAdmReqTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          outEesAdmReqTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          outEesAdmReqTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAdmReqTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAdmReqTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAdmReqTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAdmReqTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAdmReqTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAdmReqTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAdmReqTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outEesAdmReqTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          outEesAdmReqTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          outEesAdmReqTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          outEesAdmReqTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAdmReqTabObj.dob != null && outEesAdmReqTabObj.dob.length() > 0 ) 
            outEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.dob, lDateTimeTrgFmt);
          outEesAdmReqTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( outEesAdmReqTabObj.age_on_date != null && outEesAdmReqTabObj.age_on_date.length() > 0 ) 
            outEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          outEesAdmReqTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          outEesAdmReqTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          outEesAdmReqTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          outEesAdmReqTabObj.religion  =  lResultSet.getString("RELIGION");
          outEesAdmReqTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAdmReqTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAdmReqTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outEesAdmReqTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outEesAdmReqTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outEesAdmReqTabObj.p_state  =  lResultSet.getString("P_STATE");
          outEesAdmReqTabObj.p_city  =  lResultSet.getString("P_CITY");
          outEesAdmReqTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          outEesAdmReqTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outEesAdmReqTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outEesAdmReqTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outEesAdmReqTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outEesAdmReqTabObj.m_state  =  lResultSet.getString("M_STATE");
          outEesAdmReqTabObj.m_city  =  lResultSet.getString("M_CITY");
          outEesAdmReqTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          outEesAdmReqTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outEesAdmReqTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAdmReqTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAdmReqTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outEesAdmReqTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          outEesAdmReqTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAdmReqTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAdmReqTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAdmReqTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAdmReqTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAdmReqTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAdmReqTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAdmReqTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          outEesAdmReqTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAdmReqTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          outEesAdmReqTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          outEesAdmReqTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          outEesAdmReqTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          outEesAdmReqTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          outEesAdmReqTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          outEesAdmReqTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          outEesAdmReqTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          outEesAdmReqTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAdmReqTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          outEesAdmReqTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          outEesAdmReqTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          outEesAdmReqTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          outEesAdmReqTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          outEesAdmReqTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          outEesAdmReqTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          outEesAdmReqTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          outEesAdmReqTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          outEesAdmReqTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          outEesAdmReqTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAdmReqTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesAdmReqTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          outEesAdmReqTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( outEesAdmReqTabObj.adm_req_sts_date != null && outEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            outEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          outEesAdmReqTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          outEesAdmReqTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( outEesAdmReqTabObj.form_recv_date != null && outEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            outEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          outEesAdmReqTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( outEesAdmReqTabObj.prospectus_sale_date != null && outEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            outEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          outEesAdmReqTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          outEesAdmReqTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          outEesAdmReqTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          outEesAdmReqTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( outEesAdmReqTabObj.entrance_exam_date != null && outEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            outEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          outEesAdmReqTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          outEesAdmReqTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          outEesAdmReqTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outEesAdmReqTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outEesAdmReqTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outEesAdmReqTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          outEesAdmReqTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          outEesAdmReqTabObj.grade  =  lResultSet.getString("GRADE");
          outEesAdmReqTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( outEesAdmReqTabObj.fee_sch_date != null && outEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            outEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( outEesAdmReqTabObj.fee_deposit_date != null && outEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            outEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          outEesAdmReqTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          outEesAdmReqTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          outEesAdmReqTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          outEesAdmReqTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          outEesAdmReqTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          outEesAdmReqTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          outEesAdmReqTabObj.unv_1  =  lResultSet.getString("UNV_1");
          outEesAdmReqTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          outEesAdmReqTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          outEesAdmReqTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          outEesAdmReqTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          outEesAdmReqTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          outEesAdmReqTabObj.unv_2  =  lResultSet.getString("UNV_2");
          outEesAdmReqTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          outEesAdmReqTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          outEesAdmReqTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          outEesAdmReqTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          outEesAdmReqTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          outEesAdmReqTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          outEesAdmReqTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          outEesAdmReqTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          outEesAdmReqTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          outEesAdmReqTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          outEesAdmReqTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( outEesAdmReqTabObj.cheque_date != null && outEesAdmReqTabObj.cheque_date.length() > 0 ) 
            outEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
          outEesAdmReqTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          outEesAdmReqTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          outEesAdmReqTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          outEesAdmReqTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          outEesAdmReqTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          outEesAdmReqTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          outEesAdmReqTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          outEesAdmReqTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          outEesAdmReqTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          outEesAdmReqTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          outEesAdmReqTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          outEesAdmReqTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          outEesAdmReqTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          outEesAdmReqTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          outEesAdmReqTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          outEesAdmReqTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          outEesAdmReqTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          outEesAdmReqTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          outEesAdmReqTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          outEesAdmReqTabObj.allergy  =  lResultSet.getString("ALLERGY");
          outEesAdmReqTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          outEesAdmReqTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          outEesAdmReqTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          outEesAdmReqTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          outEesAdmReqTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          outEesAdmReqTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          outEesAdmReqTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          outEesAdmReqTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          outEesAdmReqTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          outEesAdmReqTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          outEesAdmReqTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          outEesAdmReqTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          outEesAdmReqTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          outEesAdmReqTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          outEesAdmReqTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          outEesAdmReqTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          outEesAdmReqTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          outEesAdmReqTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          outEesAdmReqTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          outEesAdmReqTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          outEesAdmReqTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          outEesAdmReqTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          outEesAdmReqTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          outEesAdmReqTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          outEesAdmReqTabObj.remark  =  lResultSet.getString("REMARK");
          outEesAdmReqTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          outEesAdmReqTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          outEesAdmReqTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          outEesAdmReqTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          outEesAdmReqTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAdmReqTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAdmReqTabObj( outEesAdmReqTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqArr
               ( String inEesAdmReqWhereText
               , ArrayList  outEesAdmReqTabObjArr
               )
  {
    sop("gtEesAdmReqArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAdmReqTabObj  lEesAdmReqTabObj = new EesAdmReqTabObj();
          lEesAdmReqTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesAdmReqTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAdmReqTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          lEesAdmReqTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          lEesAdmReqTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAdmReqTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          lEesAdmReqTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          lEesAdmReqTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          lEesAdmReqTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAdmReqTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAdmReqTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAdmReqTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAdmReqTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAdmReqTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAdmReqTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAdmReqTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lEesAdmReqTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          lEesAdmReqTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          lEesAdmReqTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          lEesAdmReqTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAdmReqTabObj.dob != null && lEesAdmReqTabObj.dob.length() > 0 ) 
            lEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.dob, lDateTimeTrgFmt);
          lEesAdmReqTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( lEesAdmReqTabObj.age_on_date != null && lEesAdmReqTabObj.age_on_date.length() > 0 ) 
            lEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          lEesAdmReqTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          lEesAdmReqTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          lEesAdmReqTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          lEesAdmReqTabObj.religion  =  lResultSet.getString("RELIGION");
          lEesAdmReqTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAdmReqTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAdmReqTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lEesAdmReqTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lEesAdmReqTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lEesAdmReqTabObj.p_state  =  lResultSet.getString("P_STATE");
          lEesAdmReqTabObj.p_city  =  lResultSet.getString("P_CITY");
          lEesAdmReqTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          lEesAdmReqTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lEesAdmReqTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lEesAdmReqTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lEesAdmReqTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lEesAdmReqTabObj.m_state  =  lResultSet.getString("M_STATE");
          lEesAdmReqTabObj.m_city  =  lResultSet.getString("M_CITY");
          lEesAdmReqTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          lEesAdmReqTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lEesAdmReqTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAdmReqTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAdmReqTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lEesAdmReqTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          lEesAdmReqTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAdmReqTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAdmReqTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAdmReqTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAdmReqTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAdmReqTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAdmReqTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAdmReqTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          lEesAdmReqTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAdmReqTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          lEesAdmReqTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          lEesAdmReqTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          lEesAdmReqTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          lEesAdmReqTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          lEesAdmReqTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          lEesAdmReqTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          lEesAdmReqTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          lEesAdmReqTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAdmReqTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          lEesAdmReqTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          lEesAdmReqTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          lEesAdmReqTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          lEesAdmReqTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          lEesAdmReqTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          lEesAdmReqTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          lEesAdmReqTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          lEesAdmReqTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          lEesAdmReqTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          lEesAdmReqTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAdmReqTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesAdmReqTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          lEesAdmReqTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( lEesAdmReqTabObj.adm_req_sts_date != null && lEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          lEesAdmReqTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          lEesAdmReqTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( lEesAdmReqTabObj.form_recv_date != null && lEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            lEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          lEesAdmReqTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( lEesAdmReqTabObj.prospectus_sale_date != null && lEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          lEesAdmReqTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          lEesAdmReqTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          lEesAdmReqTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          lEesAdmReqTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( lEesAdmReqTabObj.entrance_exam_date != null && lEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          lEesAdmReqTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          lEesAdmReqTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          lEesAdmReqTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lEesAdmReqTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lEesAdmReqTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lEesAdmReqTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          lEesAdmReqTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          lEesAdmReqTabObj.grade  =  lResultSet.getString("GRADE");
          lEesAdmReqTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( lEesAdmReqTabObj.fee_sch_date != null && lEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( lEesAdmReqTabObj.fee_deposit_date != null && lEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          lEesAdmReqTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          lEesAdmReqTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          lEesAdmReqTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          lEesAdmReqTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          lEesAdmReqTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          lEesAdmReqTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          lEesAdmReqTabObj.unv_1  =  lResultSet.getString("UNV_1");
          lEesAdmReqTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          lEesAdmReqTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          lEesAdmReqTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          lEesAdmReqTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          lEesAdmReqTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          lEesAdmReqTabObj.unv_2  =  lResultSet.getString("UNV_2");
          lEesAdmReqTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          lEesAdmReqTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          lEesAdmReqTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          lEesAdmReqTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          lEesAdmReqTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          lEesAdmReqTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          lEesAdmReqTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          lEesAdmReqTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          lEesAdmReqTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          lEesAdmReqTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          lEesAdmReqTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( lEesAdmReqTabObj.cheque_date != null && lEesAdmReqTabObj.cheque_date.length() > 0 ) 
            lEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
          lEesAdmReqTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          lEesAdmReqTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          lEesAdmReqTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          lEesAdmReqTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          lEesAdmReqTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          lEesAdmReqTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          lEesAdmReqTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          lEesAdmReqTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          lEesAdmReqTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          lEesAdmReqTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          lEesAdmReqTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          lEesAdmReqTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          lEesAdmReqTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          lEesAdmReqTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          lEesAdmReqTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          lEesAdmReqTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          lEesAdmReqTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          lEesAdmReqTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          lEesAdmReqTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          lEesAdmReqTabObj.allergy  =  lResultSet.getString("ALLERGY");
          lEesAdmReqTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          lEesAdmReqTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          lEesAdmReqTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          lEesAdmReqTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          lEesAdmReqTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          lEesAdmReqTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          lEesAdmReqTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          lEesAdmReqTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          lEesAdmReqTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          lEesAdmReqTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          lEesAdmReqTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          lEesAdmReqTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          lEesAdmReqTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          lEesAdmReqTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          lEesAdmReqTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          lEesAdmReqTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          lEesAdmReqTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          lEesAdmReqTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          lEesAdmReqTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          lEesAdmReqTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          lEesAdmReqTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          lEesAdmReqTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          lEesAdmReqTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          lEesAdmReqTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          lEesAdmReqTabObj.remark  =  lResultSet.getString("REMARK");
          lEesAdmReqTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          lEesAdmReqTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          lEesAdmReqTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          lEesAdmReqTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          lEesAdmReqTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAdmReqTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAdmReqTabObj( lEesAdmReqTabObj );

          outEesAdmReqTabObjArr.add(  lEesAdmReqTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmReqTabObjArr != null && outEesAdmReqTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqArrDist
               ( String inEesAdmReqWhereText
               , String inDistEesAdmReqField
               , ArrayList  outEesAdmReqTabObjArr
               )
  {

    sop("gtEesAdmReqArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";
  

       String lDistEesAdmReqFieldQry = inDistEesAdmReqField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAdmReqFieldQry+
                         " FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAdmReqField.substring(inDistEesAdmReqField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesAdmReqTabObj  lEesAdmReqTabObj = new EesAdmReqTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesAdmReqTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id") )
              lEesAdmReqTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("application_form_num") )
              lEesAdmReqTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("applicant_id") )
              lEesAdmReqTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_photo_file") )
              lEesAdmReqTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_photo_file") )
              lEesAdmReqTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_photo_file") )
              lEesAdmReqTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_id") )
              lEesAdmReqTabObj.class_id  =  lResultSet.getString("CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_num") )
              lEesAdmReqTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_std") )
              lEesAdmReqTabObj.class_std  =  lResultSet.getString("CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_section") )
              lEesAdmReqTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_id") )
              lEesAdmReqTabObj.course_id  =  lResultSet.getString("COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_term") )
              lEesAdmReqTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream") )
              lEesAdmReqTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("name_initials") )
              lEesAdmReqTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_f_name") )
              lEesAdmReqTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_m_name") )
              lEesAdmReqTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_l_name") )
              lEesAdmReqTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dob") )
              {
              lEesAdmReqTabObj.dob  =  lResultSet.getString("DOB");
  
          if ( lEesAdmReqTabObj.dob != null && lEesAdmReqTabObj.dob.length() > 0 ) 
            lEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.dob, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_on_date") )
              {
              lEesAdmReqTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");
  
          if ( lEesAdmReqTabObj.age_on_date != null && lEesAdmReqTabObj.age_on_date.length() > 0 ) 
            lEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.age_on_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_year") )
              lEesAdmReqTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_month") )
              lEesAdmReqTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_day") )
              lEesAdmReqTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("s_nationality") )
              lEesAdmReqTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("religion") )
              lEesAdmReqTabObj.religion  =  lResultSet.getString("RELIGION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_ctg") )
              lEesAdmReqTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gender_flag") )
              lEesAdmReqTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_1") )
              lEesAdmReqTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_2") )
              lEesAdmReqTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_country") )
              lEesAdmReqTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_state") )
              lEesAdmReqTabObj.p_state  =  lResultSet.getString("P_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_city") )
              lEesAdmReqTabObj.p_city  =  lResultSet.getString("P_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_district") )
              lEesAdmReqTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_zip") )
              lEesAdmReqTabObj.p_zip  =  lResultSet.getString("P_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_1") )
              lEesAdmReqTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_2") )
              lEesAdmReqTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_country") )
              lEesAdmReqTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_state") )
              lEesAdmReqTabObj.m_state  =  lResultSet.getString("M_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_city") )
              lEesAdmReqTabObj.m_city  =  lResultSet.getString("M_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_district") )
              lEesAdmReqTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_zip") )
              lEesAdmReqTabObj.m_zip  =  lResultSet.getString("M_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone_list") )
              lEesAdmReqTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_list") )
              lEesAdmReqTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fax_list") )
              lEesAdmReqTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_org_name") )
              lEesAdmReqTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_id") )
              lEesAdmReqTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_num") )
              lEesAdmReqTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_std") )
              lEesAdmReqTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_section") )
              lEesAdmReqTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_id") )
              lEesAdmReqTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_term") )
              lEesAdmReqTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_stream") )
              lEesAdmReqTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reason_for_leaving") )
              lEesAdmReqTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_name") )
              lEesAdmReqTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_age") )
              lEesAdmReqTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_nationality") )
              lEesAdmReqTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_occ_type") )
              lEesAdmReqTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_employer") )
              lEesAdmReqTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_designation") )
              lEesAdmReqTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_annual_income") )
              lEesAdmReqTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_off_address_1") )
              lEesAdmReqTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_phone_list") )
              lEesAdmReqTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_name") )
              lEesAdmReqTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_age") )
              lEesAdmReqTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_nationality") )
              lEesAdmReqTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_occ_type") )
              lEesAdmReqTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_employer") )
              lEesAdmReqTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_designation") )
              lEesAdmReqTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_annual_income") )
              lEesAdmReqTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_off_address_1") )
              lEesAdmReqTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_phone_list") )
              lEesAdmReqTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("divorced_flag") )
              lEesAdmReqTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("child_with") )
              lEesAdmReqTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("roll_num") )
              lEesAdmReqTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("academic_session") )
              lEesAdmReqTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_sts") )
              lEesAdmReqTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_sts_date") )
              {
              lEesAdmReqTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");
  
          if ( lEesAdmReqTabObj.adm_req_sts_date != null && lEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.adm_req_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_id") )
              lEesAdmReqTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("scholor_num") )
              lEesAdmReqTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("form_recv_date") )
              {
              lEesAdmReqTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");
  
          if ( lEesAdmReqTabObj.form_recv_date != null && lEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            lEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.form_recv_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("form_recv_time") )
              lEesAdmReqTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sale_date") )
              {
              lEesAdmReqTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");
  
          if ( lEesAdmReqTabObj.prospectus_sale_date != null && lEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.prospectus_sale_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sale_time") )
              lEesAdmReqTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sold_by") )
              lEesAdmReqTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("application_form_fee") )
              lEesAdmReqTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_academic_session") )
              lEesAdmReqTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_date") )
              {
              lEesAdmReqTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");
  
          if ( lEesAdmReqTabObj.entrance_exam_date != null && lEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.entrance_exam_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_time_start") )
              lEesAdmReqTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_time_end") )
              lEesAdmReqTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_present_status") )
              lEesAdmReqTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("building_id") )
              lEesAdmReqTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("floor_num") )
              lEesAdmReqTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("room_num") )
              lEesAdmReqTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("max_mark") )
              lEesAdmReqTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("obtained_mark") )
              lEesAdmReqTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("grade") )
              lEesAdmReqTabObj.grade  =  lResultSet.getString("GRADE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fee_sch_date") )
              {
              lEesAdmReqTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");
  
          if ( lEesAdmReqTabObj.fee_sch_date != null && lEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_sch_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fee_deposit_date") )
              {
              lEesAdmReqTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");
  
          if ( lEesAdmReqTabObj.fee_deposit_date != null && lEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.fee_deposit_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("online_flag") )
              lEesAdmReqTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("admission_mode") )
              lEesAdmReqTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_1") )
              lEesAdmReqTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_2") )
              lEesAdmReqTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_3") )
              lEesAdmReqTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_4") )
              lEesAdmReqTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("apr_course_stream") )
              lEesAdmReqTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_1") )
              lEesAdmReqTabObj.unv_1  =  lResultSet.getString("UNV_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_rn_1") )
              lEesAdmReqTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gen_rank_1") )
              lEesAdmReqTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ctg_rank_1") )
              lEesAdmReqTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stt_rank_1") )
              lEesAdmReqTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("yoa_1") )
              lEesAdmReqTabObj.yoa_1  =  lResultSet.getString("YOA_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_2") )
              lEesAdmReqTabObj.unv_2  =  lResultSet.getString("UNV_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_rn_2") )
              lEesAdmReqTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gen_rank_2") )
              lEesAdmReqTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ctg_rank_2") )
              lEesAdmReqTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stt_rank_2") )
              lEesAdmReqTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("yoa_2") )
              lEesAdmReqTabObj.yoa_2  =  lResultSet.getString("YOA_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_mark_percent") )
              lEesAdmReqTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("domecile_ind") )
              lEesAdmReqTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_transport_req_ind") )
              lEesAdmReqTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_hostel_req_ind") )
              lEesAdmReqTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_num") )
              lEesAdmReqTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_date") )
              {
              lEesAdmReqTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");
  
          if ( lEesAdmReqTabObj.cheque_date != null && lEesAdmReqTabObj.cheque_date.length() > 0 ) 
            lEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmReqTabObj.cheque_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bank_code") )
              lEesAdmReqTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bank_name") )
              lEesAdmReqTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_amt") )
              lEesAdmReqTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_name") )
              lEesAdmReqTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_rel_type") )
              lEesAdmReqTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_address") )
              lEesAdmReqTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_phone") )
              lEesAdmReqTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_name") )
              lEesAdmReqTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_rel_type") )
              lEesAdmReqTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_address") )
              lEesAdmReqTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_phone") )
              lEesAdmReqTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_1") )
              lEesAdmReqTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_2") )
              lEesAdmReqTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_3") )
              lEesAdmReqTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_4") )
              lEesAdmReqTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_5") )
              lEesAdmReqTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_6") )
              lEesAdmReqTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_7") )
              lEesAdmReqTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_8") )
              lEesAdmReqTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allergy") )
              lEesAdmReqTabObj.allergy  =  lResultSet.getString("ALLERGY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("physical_disability") )
              lEesAdmReqTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem") )
              lEesAdmReqTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_1") )
              lEesAdmReqTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_2") )
              lEesAdmReqTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_3") )
              lEesAdmReqTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_4") )
              lEesAdmReqTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_5") )
              lEesAdmReqTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_6") )
              lEesAdmReqTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_7") )
              lEesAdmReqTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_8") )
              lEesAdmReqTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_9") )
              lEesAdmReqTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_10") )
              lEesAdmReqTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_11") )
              lEesAdmReqTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_12") )
              lEesAdmReqTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_1") )
              lEesAdmReqTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_2") )
              lEesAdmReqTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_3") )
              lEesAdmReqTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_4") )
              lEesAdmReqTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_5") )
              lEesAdmReqTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_6") )
              lEesAdmReqTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_7") )
              lEesAdmReqTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_8") )
              lEesAdmReqTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("seat_num") )
              lEesAdmReqTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reason_for_join") )
              lEesAdmReqTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lEesAdmReqTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("place_of_birth") )
              lEesAdmReqTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adv_adm_fee") )
              lEesAdmReqTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("payment_mode") )
              lEesAdmReqTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("target_ptl_user_id") )
              lEesAdmReqTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_req") )
              lEesAdmReqTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_list") )
              lEesAdmReqTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          }
          removeNullEesAdmReqTabObj( lEesAdmReqTabObj );

          outEesAdmReqTabObjArr.add(  lEesAdmReqTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmReqTabObjArr != null && outEesAdmReqTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmReqStrArrDist
               ( String inEesAdmReqWhereText
               , String inDistEesAdmReqField
               , ArrayList  outEesAdmReqTabObjArr
               )
  {

    sop("gtEesAdmReqStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmReqStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";
  

       String lDistEesAdmReqFieldQry = inDistEesAdmReqField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAdmReqFieldQry+
                         " FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAdmReqField.substring(inDistEesAdmReqField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesAdmReqTabObjStr = "";
       while(lResultSet.next())
       {
          lEesAdmReqTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesAdmReqTabObjStr =   lEesAdmReqTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesAdmReqTabObjArr.add(  lEesAdmReqTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmReqTabObjArr != null && outEesAdmReqTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesAdmReq
               ( String inEesAdmReqWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesAdmReq - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesAdmReq";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesAdmReqTabObj
               ( 
                 EesAdmReqTabObj  outEesAdmReqTabObj
               )
  {
  
    if ( outEesAdmReqTabObj.org_id == null ) 
     outEesAdmReqTabObj.org_id = ""; 
    if ( outEesAdmReqTabObj.adm_req_id == null ) 
     outEesAdmReqTabObj.adm_req_id = ""; 
    if ( outEesAdmReqTabObj.application_form_num == null ) 
     outEesAdmReqTabObj.application_form_num = ""; 
    if ( outEesAdmReqTabObj.applicant_id == null ) 
     outEesAdmReqTabObj.applicant_id = ""; 
    if ( outEesAdmReqTabObj.student_photo_file == null ) 
     outEesAdmReqTabObj.student_photo_file = ""; 
    if ( outEesAdmReqTabObj.mother_photo_file == null ) 
     outEesAdmReqTabObj.mother_photo_file = ""; 
    if ( outEesAdmReqTabObj.father_photo_file == null ) 
     outEesAdmReqTabObj.father_photo_file = ""; 
    if ( outEesAdmReqTabObj.class_id == null ) 
     outEesAdmReqTabObj.class_id = ""; 
    if ( outEesAdmReqTabObj.class_num == null ) 
     outEesAdmReqTabObj.class_num = ""; 
    if ( outEesAdmReqTabObj.class_std == null ) 
     outEesAdmReqTabObj.class_std = ""; 
    if ( outEesAdmReqTabObj.class_section == null ) 
     outEesAdmReqTabObj.class_section = ""; 
    if ( outEesAdmReqTabObj.course_id == null ) 
     outEesAdmReqTabObj.course_id = ""; 
    if ( outEesAdmReqTabObj.course_term == null ) 
     outEesAdmReqTabObj.course_term = ""; 
    if ( outEesAdmReqTabObj.course_stream == null ) 
     outEesAdmReqTabObj.course_stream = ""; 
    if ( outEesAdmReqTabObj.name_initials == null ) 
     outEesAdmReqTabObj.name_initials = ""; 
    if ( outEesAdmReqTabObj.student_f_name == null ) 
     outEesAdmReqTabObj.student_f_name = ""; 
    if ( outEesAdmReqTabObj.student_m_name == null ) 
     outEesAdmReqTabObj.student_m_name = ""; 
    if ( outEesAdmReqTabObj.student_l_name == null ) 
     outEesAdmReqTabObj.student_l_name = ""; 
    if ( outEesAdmReqTabObj.dob == null ) 
     outEesAdmReqTabObj.dob = ""; 
    if ( outEesAdmReqTabObj.age_on_date == null ) 
     outEesAdmReqTabObj.age_on_date = ""; 
    if ( outEesAdmReqTabObj.age_year == (int)0 ) 
     outEesAdmReqTabObj.age_year = (int)0; 
    if ( outEesAdmReqTabObj.age_month == null ) 
     outEesAdmReqTabObj.age_month = ""; 
    if ( outEesAdmReqTabObj.age_day == (int)0 ) 
     outEesAdmReqTabObj.age_day = (int)0; 
    if ( outEesAdmReqTabObj.s_nationality == null ) 
     outEesAdmReqTabObj.s_nationality = ""; 
    if ( outEesAdmReqTabObj.religion == null ) 
     outEesAdmReqTabObj.religion = ""; 
    if ( outEesAdmReqTabObj.student_ctg == null ) 
     outEesAdmReqTabObj.student_ctg = ""; 
    if ( outEesAdmReqTabObj.gender_flag == null ) 
     outEesAdmReqTabObj.gender_flag = ""; 
    if ( outEesAdmReqTabObj.p_address_1 == null ) 
     outEesAdmReqTabObj.p_address_1 = ""; 
    if ( outEesAdmReqTabObj.p_address_2 == null ) 
     outEesAdmReqTabObj.p_address_2 = ""; 
    if ( outEesAdmReqTabObj.p_country == null ) 
     outEesAdmReqTabObj.p_country = ""; 
    if ( outEesAdmReqTabObj.p_state == null ) 
     outEesAdmReqTabObj.p_state = ""; 
    if ( outEesAdmReqTabObj.p_city == null ) 
     outEesAdmReqTabObj.p_city = ""; 
    if ( outEesAdmReqTabObj.p_district == null ) 
     outEesAdmReqTabObj.p_district = ""; 
    if ( outEesAdmReqTabObj.p_zip == null ) 
     outEesAdmReqTabObj.p_zip = ""; 
    if ( outEesAdmReqTabObj.m_address_1 == null ) 
     outEesAdmReqTabObj.m_address_1 = ""; 
    if ( outEesAdmReqTabObj.m_address_2 == null ) 
     outEesAdmReqTabObj.m_address_2 = ""; 
    if ( outEesAdmReqTabObj.m_country == null ) 
     outEesAdmReqTabObj.m_country = ""; 
    if ( outEesAdmReqTabObj.m_state == null ) 
     outEesAdmReqTabObj.m_state = ""; 
    if ( outEesAdmReqTabObj.m_city == null ) 
     outEesAdmReqTabObj.m_city = ""; 
    if ( outEesAdmReqTabObj.m_district == null ) 
     outEesAdmReqTabObj.m_district = ""; 
    if ( outEesAdmReqTabObj.m_zip == null ) 
     outEesAdmReqTabObj.m_zip = ""; 
    if ( outEesAdmReqTabObj.phone_list == null ) 
     outEesAdmReqTabObj.phone_list = ""; 
    if ( outEesAdmReqTabObj.email_list == null ) 
     outEesAdmReqTabObj.email_list = ""; 
    if ( outEesAdmReqTabObj.fax_list == null ) 
     outEesAdmReqTabObj.fax_list = ""; 
    if ( outEesAdmReqTabObj.prev_org_name == null ) 
     outEesAdmReqTabObj.prev_org_name = ""; 
    if ( outEesAdmReqTabObj.prev_class_id == null ) 
     outEesAdmReqTabObj.prev_class_id = ""; 
    if ( outEesAdmReqTabObj.prev_class_num == null ) 
     outEesAdmReqTabObj.prev_class_num = ""; 
    if ( outEesAdmReqTabObj.prev_class_std == null ) 
     outEesAdmReqTabObj.prev_class_std = ""; 
    if ( outEesAdmReqTabObj.prev_class_section == null ) 
     outEesAdmReqTabObj.prev_class_section = ""; 
    if ( outEesAdmReqTabObj.prev_course_id == null ) 
     outEesAdmReqTabObj.prev_course_id = ""; 
    if ( outEesAdmReqTabObj.prev_course_term == null ) 
     outEesAdmReqTabObj.prev_course_term = ""; 
    if ( outEesAdmReqTabObj.prev_course_stream == null ) 
     outEesAdmReqTabObj.prev_course_stream = ""; 
    if ( outEesAdmReqTabObj.reason_for_leaving == null ) 
     outEesAdmReqTabObj.reason_for_leaving = ""; 
    if ( outEesAdmReqTabObj.father_name == null ) 
     outEesAdmReqTabObj.father_name = ""; 
    if ( outEesAdmReqTabObj.father_age == (int)0 ) 
     outEesAdmReqTabObj.father_age = (int)0; 
    if ( outEesAdmReqTabObj.f_nationality == null ) 
     outEesAdmReqTabObj.f_nationality = ""; 
    if ( outEesAdmReqTabObj.father_occ_type == null ) 
     outEesAdmReqTabObj.father_occ_type = ""; 
    if ( outEesAdmReqTabObj.father_employer == null ) 
     outEesAdmReqTabObj.father_employer = ""; 
    if ( outEesAdmReqTabObj.father_designation == null ) 
     outEesAdmReqTabObj.father_designation = ""; 
    if ( outEesAdmReqTabObj.father_annual_income == (double)0.00 ) 
     outEesAdmReqTabObj.father_annual_income = (double)0.00; 
    if ( outEesAdmReqTabObj.f_off_address_1 == null ) 
     outEesAdmReqTabObj.f_off_address_1 = ""; 
    if ( outEesAdmReqTabObj.f_phone_list == null ) 
     outEesAdmReqTabObj.f_phone_list = ""; 
    if ( outEesAdmReqTabObj.mother_name == null ) 
     outEesAdmReqTabObj.mother_name = ""; 
    if ( outEesAdmReqTabObj.mother_age == (int)0 ) 
     outEesAdmReqTabObj.mother_age = (int)0; 
    if ( outEesAdmReqTabObj.m_nationality == null ) 
     outEesAdmReqTabObj.m_nationality = ""; 
    if ( outEesAdmReqTabObj.mother_occ_type == null ) 
     outEesAdmReqTabObj.mother_occ_type = ""; 
    if ( outEesAdmReqTabObj.mother_employer == null ) 
     outEesAdmReqTabObj.mother_employer = ""; 
    if ( outEesAdmReqTabObj.mother_designation == null ) 
     outEesAdmReqTabObj.mother_designation = ""; 
    if ( outEesAdmReqTabObj.mother_annual_income == (double)0.00 ) 
     outEesAdmReqTabObj.mother_annual_income = (double)0.00; 
    if ( outEesAdmReqTabObj.m_off_address_1 == null ) 
     outEesAdmReqTabObj.m_off_address_1 = ""; 
    if ( outEesAdmReqTabObj.m_phone_list == null ) 
     outEesAdmReqTabObj.m_phone_list = ""; 
    if ( outEesAdmReqTabObj.divorced_flag == null ) 
     outEesAdmReqTabObj.divorced_flag = ""; 
    if ( outEesAdmReqTabObj.child_with == null ) 
     outEesAdmReqTabObj.child_with = ""; 
    if ( outEesAdmReqTabObj.roll_num == null ) 
     outEesAdmReqTabObj.roll_num = ""; 
    if ( outEesAdmReqTabObj.academic_session == null ) 
     outEesAdmReqTabObj.academic_session = ""; 
    if ( outEesAdmReqTabObj.adm_req_sts == null ) 
     outEesAdmReqTabObj.adm_req_sts = ""; 
    if ( outEesAdmReqTabObj.adm_req_sts_date == null ) 
     outEesAdmReqTabObj.adm_req_sts_date = ""; 
    if ( outEesAdmReqTabObj.student_id == null ) 
     outEesAdmReqTabObj.student_id = ""; 
    if ( outEesAdmReqTabObj.scholor_num == null ) 
     outEesAdmReqTabObj.scholor_num = ""; 
    if ( outEesAdmReqTabObj.form_recv_date == null ) 
     outEesAdmReqTabObj.form_recv_date = ""; 
    if ( outEesAdmReqTabObj.form_recv_time == null ) 
     outEesAdmReqTabObj.form_recv_time = ""; 
    if ( outEesAdmReqTabObj.prospectus_sale_date == null ) 
     outEesAdmReqTabObj.prospectus_sale_date = ""; 
    if ( outEesAdmReqTabObj.prospectus_sale_time == null ) 
     outEesAdmReqTabObj.prospectus_sale_time = ""; 
    if ( outEesAdmReqTabObj.prospectus_sold_by == null ) 
     outEesAdmReqTabObj.prospectus_sold_by = ""; 
    if ( outEesAdmReqTabObj.application_form_fee == (double)0.00 ) 
     outEesAdmReqTabObj.application_form_fee = (double)0.00; 
    if ( outEesAdmReqTabObj.adm_academic_session == null ) 
     outEesAdmReqTabObj.adm_academic_session = ""; 
    if ( outEesAdmReqTabObj.entrance_exam_date == null ) 
     outEesAdmReqTabObj.entrance_exam_date = ""; 
    if ( outEesAdmReqTabObj.entrance_exam_time_start == null ) 
     outEesAdmReqTabObj.entrance_exam_time_start = ""; 
    if ( outEesAdmReqTabObj.entrance_exam_time_end == null ) 
     outEesAdmReqTabObj.entrance_exam_time_end = ""; 
    if ( outEesAdmReqTabObj.exam_present_status == null ) 
     outEesAdmReqTabObj.exam_present_status = ""; 
    if ( outEesAdmReqTabObj.building_id == null ) 
     outEesAdmReqTabObj.building_id = ""; 
    if ( outEesAdmReqTabObj.floor_num == null ) 
     outEesAdmReqTabObj.floor_num = ""; 
    if ( outEesAdmReqTabObj.room_num == null ) 
     outEesAdmReqTabObj.room_num = ""; 
    if ( outEesAdmReqTabObj.max_mark == (int)0 ) 
     outEesAdmReqTabObj.max_mark = (int)0; 
    if ( outEesAdmReqTabObj.obtained_mark == (int)0 ) 
     outEesAdmReqTabObj.obtained_mark = (int)0; 
    if ( outEesAdmReqTabObj.grade == null ) 
     outEesAdmReqTabObj.grade = ""; 
    if ( outEesAdmReqTabObj.fee_sch_date == null ) 
     outEesAdmReqTabObj.fee_sch_date = ""; 
    if ( outEesAdmReqTabObj.fee_deposit_date == null ) 
     outEesAdmReqTabObj.fee_deposit_date = ""; 
    if ( outEesAdmReqTabObj.online_flag == null ) 
     outEesAdmReqTabObj.online_flag = ""; 
    if ( outEesAdmReqTabObj.admission_mode == null ) 
     outEesAdmReqTabObj.admission_mode = ""; 
    if ( outEesAdmReqTabObj.course_stream_1 == null ) 
     outEesAdmReqTabObj.course_stream_1 = ""; 
    if ( outEesAdmReqTabObj.course_stream_2 == null ) 
     outEesAdmReqTabObj.course_stream_2 = ""; 
    if ( outEesAdmReqTabObj.course_stream_3 == null ) 
     outEesAdmReqTabObj.course_stream_3 = ""; 
    if ( outEesAdmReqTabObj.course_stream_4 == null ) 
     outEesAdmReqTabObj.course_stream_4 = ""; 
    if ( outEesAdmReqTabObj.apr_course_stream == null ) 
     outEesAdmReqTabObj.apr_course_stream = ""; 
    if ( outEesAdmReqTabObj.unv_1 == null ) 
     outEesAdmReqTabObj.unv_1 = ""; 
    if ( outEesAdmReqTabObj.unv_rn_1 == null ) 
     outEesAdmReqTabObj.unv_rn_1 = ""; 
    if ( outEesAdmReqTabObj.gen_rank_1 == null ) 
     outEesAdmReqTabObj.gen_rank_1 = ""; 
    if ( outEesAdmReqTabObj.ctg_rank_1 == null ) 
     outEesAdmReqTabObj.ctg_rank_1 = ""; 
    if ( outEesAdmReqTabObj.stt_rank_1 == null ) 
     outEesAdmReqTabObj.stt_rank_1 = ""; 
    if ( outEesAdmReqTabObj.yoa_1 == null ) 
     outEesAdmReqTabObj.yoa_1 = ""; 
    if ( outEesAdmReqTabObj.unv_2 == null ) 
     outEesAdmReqTabObj.unv_2 = ""; 
    if ( outEesAdmReqTabObj.unv_rn_2 == null ) 
     outEesAdmReqTabObj.unv_rn_2 = ""; 
    if ( outEesAdmReqTabObj.gen_rank_2 == null ) 
     outEesAdmReqTabObj.gen_rank_2 = ""; 
    if ( outEesAdmReqTabObj.ctg_rank_2 == null ) 
     outEesAdmReqTabObj.ctg_rank_2 = ""; 
    if ( outEesAdmReqTabObj.stt_rank_2 == null ) 
     outEesAdmReqTabObj.stt_rank_2 = ""; 
    if ( outEesAdmReqTabObj.yoa_2 == null ) 
     outEesAdmReqTabObj.yoa_2 = ""; 
    if ( outEesAdmReqTabObj.prev_mark_percent == (float)0.00 ) 
     outEesAdmReqTabObj.prev_mark_percent = (float)0.00; 
    if ( outEesAdmReqTabObj.domecile_ind == null ) 
     outEesAdmReqTabObj.domecile_ind = ""; 
    if ( outEesAdmReqTabObj.org_transport_req_ind == null ) 
     outEesAdmReqTabObj.org_transport_req_ind = ""; 
    if ( outEesAdmReqTabObj.org_hostel_req_ind == null ) 
     outEesAdmReqTabObj.org_hostel_req_ind = ""; 
    if ( outEesAdmReqTabObj.cheque_num == null ) 
     outEesAdmReqTabObj.cheque_num = ""; 
    if ( outEesAdmReqTabObj.cheque_date == null ) 
     outEesAdmReqTabObj.cheque_date = ""; 
    if ( outEesAdmReqTabObj.bank_code == null ) 
     outEesAdmReqTabObj.bank_code = ""; 
    if ( outEesAdmReqTabObj.bank_name == null ) 
     outEesAdmReqTabObj.bank_name = ""; 
    if ( outEesAdmReqTabObj.cheque_amt == (double)0.00 ) 
     outEesAdmReqTabObj.cheque_amt = (double)0.00; 
    if ( outEesAdmReqTabObj.lg_0_name == null ) 
     outEesAdmReqTabObj.lg_0_name = ""; 
    if ( outEesAdmReqTabObj.lg_0_rel_type == null ) 
     outEesAdmReqTabObj.lg_0_rel_type = ""; 
    if ( outEesAdmReqTabObj.lg_0_address == null ) 
     outEesAdmReqTabObj.lg_0_address = ""; 
    if ( outEesAdmReqTabObj.lg_0_phone == null ) 
     outEesAdmReqTabObj.lg_0_phone = ""; 
    if ( outEesAdmReqTabObj.lg_1_name == null ) 
     outEesAdmReqTabObj.lg_1_name = ""; 
    if ( outEesAdmReqTabObj.lg_1_rel_type == null ) 
     outEesAdmReqTabObj.lg_1_rel_type = ""; 
    if ( outEesAdmReqTabObj.lg_1_address == null ) 
     outEesAdmReqTabObj.lg_1_address = ""; 
    if ( outEesAdmReqTabObj.lg_1_phone == null ) 
     outEesAdmReqTabObj.lg_1_phone = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_1 == null ) 
     outEesAdmReqTabObj.st_cap_attr_1 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_2 == null ) 
     outEesAdmReqTabObj.st_cap_attr_2 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_3 == null ) 
     outEesAdmReqTabObj.st_cap_attr_3 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_4 == null ) 
     outEesAdmReqTabObj.st_cap_attr_4 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_5 == null ) 
     outEesAdmReqTabObj.st_cap_attr_5 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_6 == null ) 
     outEesAdmReqTabObj.st_cap_attr_6 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_7 == null ) 
     outEesAdmReqTabObj.st_cap_attr_7 = ""; 
    if ( outEesAdmReqTabObj.st_cap_attr_8 == null ) 
     outEesAdmReqTabObj.st_cap_attr_8 = ""; 
    if ( outEesAdmReqTabObj.allergy == null ) 
     outEesAdmReqTabObj.allergy = ""; 
    if ( outEesAdmReqTabObj.physical_disability == null ) 
     outEesAdmReqTabObj.physical_disability = ""; 
    if ( outEesAdmReqTabObj.health_problem == null ) 
     outEesAdmReqTabObj.health_problem = ""; 
    if ( outEesAdmReqTabObj.health_problem_1 == null ) 
     outEesAdmReqTabObj.health_problem_1 = ""; 
    if ( outEesAdmReqTabObj.health_problem_2 == null ) 
     outEesAdmReqTabObj.health_problem_2 = ""; 
    if ( outEesAdmReqTabObj.health_problem_3 == null ) 
     outEesAdmReqTabObj.health_problem_3 = ""; 
    if ( outEesAdmReqTabObj.health_problem_4 == null ) 
     outEesAdmReqTabObj.health_problem_4 = ""; 
    if ( outEesAdmReqTabObj.health_problem_5 == null ) 
     outEesAdmReqTabObj.health_problem_5 = ""; 
    if ( outEesAdmReqTabObj.health_problem_6 == null ) 
     outEesAdmReqTabObj.health_problem_6 = ""; 
    if ( outEesAdmReqTabObj.health_problem_7 == null ) 
     outEesAdmReqTabObj.health_problem_7 = ""; 
    if ( outEesAdmReqTabObj.health_problem_8 == null ) 
     outEesAdmReqTabObj.health_problem_8 = ""; 
    if ( outEesAdmReqTabObj.health_problem_9 == null ) 
     outEesAdmReqTabObj.health_problem_9 = ""; 
    if ( outEesAdmReqTabObj.health_problem_10 == null ) 
     outEesAdmReqTabObj.health_problem_10 = ""; 
    if ( outEesAdmReqTabObj.health_problem_11 == null ) 
     outEesAdmReqTabObj.health_problem_11 = ""; 
    if ( outEesAdmReqTabObj.health_problem_12 == null ) 
     outEesAdmReqTabObj.health_problem_12 = ""; 
    if ( outEesAdmReqTabObj.enclosure_1 == null ) 
     outEesAdmReqTabObj.enclosure_1 = ""; 
    if ( outEesAdmReqTabObj.enclosure_2 == null ) 
     outEesAdmReqTabObj.enclosure_2 = ""; 
    if ( outEesAdmReqTabObj.enclosure_3 == null ) 
     outEesAdmReqTabObj.enclosure_3 = ""; 
    if ( outEesAdmReqTabObj.enclosure_4 == null ) 
     outEesAdmReqTabObj.enclosure_4 = ""; 
    if ( outEesAdmReqTabObj.enclosure_5 == null ) 
     outEesAdmReqTabObj.enclosure_5 = ""; 
    if ( outEesAdmReqTabObj.enclosure_6 == null ) 
     outEesAdmReqTabObj.enclosure_6 = ""; 
    if ( outEesAdmReqTabObj.enclosure_7 == null ) 
     outEesAdmReqTabObj.enclosure_7 = ""; 
    if ( outEesAdmReqTabObj.enclosure_8 == null ) 
     outEesAdmReqTabObj.enclosure_8 = ""; 
    if ( outEesAdmReqTabObj.seat_num == (int)0 ) 
     outEesAdmReqTabObj.seat_num = (int)0; 
    if ( outEesAdmReqTabObj.reason_for_join == null ) 
     outEesAdmReqTabObj.reason_for_join = ""; 
    if ( outEesAdmReqTabObj.remark == null ) 
     outEesAdmReqTabObj.remark = ""; 
    if ( outEesAdmReqTabObj.place_of_birth == null ) 
     outEesAdmReqTabObj.place_of_birth = ""; 
    if ( outEesAdmReqTabObj.adv_adm_fee == (double)0.00 ) 
     outEesAdmReqTabObj.adv_adm_fee = (double)0.00; 
    if ( outEesAdmReqTabObj.payment_mode == null ) 
     outEesAdmReqTabObj.payment_mode = ""; 
    if ( outEesAdmReqTabObj.target_ptl_user_id == null ) 
     outEesAdmReqTabObj.target_ptl_user_id = ""; 
    if ( outEesAdmReqTabObj.adm_req_id_req == null ) 
     outEesAdmReqTabObj.adm_req_id_req = ""; 
    if ( outEesAdmReqTabObj.adm_req_id_list == null ) 
     outEesAdmReqTabObj.adm_req_id_list = ""; 
  }





  public int insEesAdmReqRec
               ( EesAdmReqTabObj  inEesAdmReqTabObj )
  {
    int lUpdateCount;
    sop("insEesAdmReqRec - Started");
    gSSTErrorObj.sourceMethod = "insEesAdmReqRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmReqTabObj.dob != null && inEesAdmReqTabObj.dob.length() > 0 ) 
            inEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.age_on_date != null && inEesAdmReqTabObj.age_on_date.length() > 0 ) 
            inEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.adm_req_sts_date != null && inEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.form_recv_date != null && inEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            inEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.prospectus_sale_date != null && inEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.entrance_exam_date != null && inEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_sch_date != null && inEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_deposit_date != null && inEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.cheque_date != null && inEesAdmReqTabObj.cheque_date.length() > 0 ) 
            inEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.cheque_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ADM_REQ"+
                        "("+
                                "org_id,"+
                                "adm_req_id,"+
                                "application_form_num,"+
                                "applicant_id,"+
                                "student_photo_file,"+
                                "mother_photo_file,"+
                                "father_photo_file,"+
                                "class_id,"+
                                "class_num,"+
                                "class_std,"+
                                "class_section,"+
                                "course_id,"+
                                "course_term,"+
                                "course_stream,"+
                                "name_initials,"+
                                "student_f_name,"+
                                "student_m_name,"+
                                "student_l_name,"+
                                "dob,"+
                                "age_on_date,"+
                                "age_year,"+
                                "age_month,"+
                                "age_day,"+
                                "s_nationality,"+
                                "religion,"+
                                "student_ctg,"+
                                "gender_flag,"+
                                "p_address_1,"+
                                "p_address_2,"+
                                "p_country,"+
                                "p_state,"+
                                "p_city,"+
                                "p_district,"+
                                "p_zip,"+
                                "m_address_1,"+
                                "m_address_2,"+
                                "m_country,"+
                                "m_state,"+
                                "m_city,"+
                                "m_district,"+
                                "m_zip,"+
                                "phone_list,"+
                                "email_list,"+
                                "fax_list,"+
                                "prev_org_name,"+
                                "prev_class_id,"+
                                "prev_class_num,"+
                                "prev_class_std,"+
                                "prev_class_section,"+
                                "prev_course_id,"+
                                "prev_course_term,"+
                                "prev_course_stream,"+
                                "reason_for_leaving,"+
                                "father_name,"+
                                "father_age,"+
                                "f_nationality,"+
                                "father_occ_type,"+
                                "father_employer,"+
                                "father_designation,"+
                                "father_annual_income,"+
                                "f_off_address_1,"+
                                "f_phone_list,"+
                                "mother_name,"+
                                "mother_age,"+
                                "m_nationality,"+
                                "mother_occ_type,"+
                                "mother_employer,"+
                                "mother_designation,"+
                                "mother_annual_income,"+
                                "m_off_address_1,"+
                                "m_phone_list,"+
                                "divorced_flag,"+
                                "child_with,"+
                                "roll_num,"+
                                "academic_session,"+
                                "adm_req_sts,"+
                                "adm_req_sts_date,"+
                                "student_id,"+
                                "scholor_num,"+
                                "form_recv_date,"+
                                "form_recv_time,"+
                                "prospectus_sale_date,"+
                                "prospectus_sale_time,"+
                                "prospectus_sold_by,"+
                                "application_form_fee,"+
                                "adm_academic_session,"+
                                "entrance_exam_date,"+
                                "entrance_exam_time_start,"+
                                "entrance_exam_time_end,"+
                                "exam_present_status,"+
                                "building_id,"+
                                "floor_num,"+
                                "room_num,"+
                                "max_mark,"+
                                "obtained_mark,"+
                                "grade,"+
                                "fee_sch_date,"+
                                "fee_deposit_date,"+
                                "online_flag,"+
                                "admission_mode,"+
                                "course_stream_1,"+
                                "course_stream_2,"+
                                "course_stream_3,"+
                                "course_stream_4,"+
                                "apr_course_stream,"+
                                "unv_1,"+
                                "unv_rn_1,"+
                                "gen_rank_1,"+
                                "ctg_rank_1,"+
                                "stt_rank_1,"+
                                "yoa_1,"+
                                "unv_2,"+
                                "unv_rn_2,"+
                                "gen_rank_2,"+
                                "ctg_rank_2,"+
                                "stt_rank_2,"+
                                "yoa_2,"+
                                "prev_mark_percent,"+
                                "domecile_ind,"+
                                "org_transport_req_ind,"+
                                "org_hostel_req_ind,"+
                                "cheque_num,"+
                                "cheque_date,"+
                                "bank_code,"+
                                "bank_name,"+
                                "cheque_amt,"+
                                "lg_0_name,"+
                                "lg_0_rel_type,"+
                                "lg_0_address,"+
                                "lg_0_phone,"+
                                "lg_1_name,"+
                                "lg_1_rel_type,"+
                                "lg_1_address,"+
                                "lg_1_phone,"+
                                "st_cap_attr_1,"+
                                "st_cap_attr_2,"+
                                "st_cap_attr_3,"+
                                "st_cap_attr_4,"+
                                "st_cap_attr_5,"+
                                "st_cap_attr_6,"+
                                "st_cap_attr_7,"+
                                "st_cap_attr_8,"+
                                "allergy,"+
                                "physical_disability,"+
                                "health_problem,"+
                                "health_problem_1,"+
                                "health_problem_2,"+
                                "health_problem_3,"+
                                "health_problem_4,"+
                                "health_problem_5,"+
                                "health_problem_6,"+
                                "health_problem_7,"+
                                "health_problem_8,"+
                                "health_problem_9,"+
                                "health_problem_10,"+
                                "health_problem_11,"+
                                "health_problem_12,"+
                                "enclosure_1,"+
                                "enclosure_2,"+
                                "enclosure_3,"+
                                "enclosure_4,"+
                                "enclosure_5,"+
                                "enclosure_6,"+
                                "enclosure_7,"+
                                "enclosure_8,"+
                                "seat_num,"+
                                "reason_for_join,"+
                                "remark,"+
                                "place_of_birth,"+
                                "adv_adm_fee,"+
                                "payment_mode,"+
                                "target_ptl_user_id,"+
                                "adm_req_id_req,"+
                                "adm_req_id_list"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_req_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.application_form_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.applicant_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.mother_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.father_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.name_initials+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_f_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_m_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_l_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.dob+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.age_on_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.age_year+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.age_month+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.age_day+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.s_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.religion+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.gender_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_district+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.p_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_district+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.email_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.fax_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_org_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prev_course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.reason_for_leaving+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.father_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.father_age+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.f_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.father_occ_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.father_employer+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.father_designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.father_annual_income+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.f_off_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.f_phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.mother_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.mother_age+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.mother_occ_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.mother_employer+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.mother_designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.mother_annual_income+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_off_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.m_phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.divorced_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.child_with+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.roll_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.academic_session+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_req_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_req_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.student_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.scholor_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.form_recv_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.form_recv_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prospectus_sale_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prospectus_sale_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.prospectus_sold_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.application_form_fee+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_academic_session+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.entrance_exam_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.entrance_exam_time_start+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.entrance_exam_time_end+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.exam_present_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.building_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.floor_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.room_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.max_mark+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.obtained_mark+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.grade+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.fee_sch_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.fee_deposit_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.online_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.admission_mode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_stream_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_stream_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_stream_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.course_stream_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.apr_course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.unv_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.unv_rn_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.gen_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.ctg_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.stt_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.yoa_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.unv_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.unv_rn_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.gen_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.ctg_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.stt_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.yoa_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.prev_mark_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.domecile_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.org_transport_req_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.org_hostel_req_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.cheque_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.cheque_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.bank_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.bank_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.cheque_amt+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_0_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_0_rel_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_0_address+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_0_phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_1_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_1_rel_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_1_address+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.lg_1_phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.st_cap_attr_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.allergy+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.physical_disability+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_9+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_10+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_11+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.health_problem_12+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.enclosure_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.seat_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.reason_for_join+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.place_of_birth+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmReqTabObj.adv_adm_fee+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.payment_mode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.target_ptl_user_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_req_id_req+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesAdmReqTabObj.adm_req_id_list+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesAdmReqTabObj.org_id);
        lPreparedStatement.setString(2, inEesAdmReqTabObj.adm_req_id);
        lPreparedStatement.setString(3, inEesAdmReqTabObj.application_form_num);
        lPreparedStatement.setString(4, inEesAdmReqTabObj.applicant_id);
        lPreparedStatement.setString(5, inEesAdmReqTabObj.student_photo_file);
        lPreparedStatement.setString(6, inEesAdmReqTabObj.mother_photo_file);
        lPreparedStatement.setString(7, inEesAdmReqTabObj.father_photo_file);
        lPreparedStatement.setString(8, inEesAdmReqTabObj.class_id);
        lPreparedStatement.setString(9, inEesAdmReqTabObj.class_num);
        lPreparedStatement.setString(10, inEesAdmReqTabObj.class_std);
        lPreparedStatement.setString(11, inEesAdmReqTabObj.class_section);
        lPreparedStatement.setString(12, inEesAdmReqTabObj.course_id);
        lPreparedStatement.setString(13, inEesAdmReqTabObj.course_term);
        lPreparedStatement.setString(14, inEesAdmReqTabObj.course_stream);
        lPreparedStatement.setString(15, inEesAdmReqTabObj.name_initials);
        lPreparedStatement.setString(16, inEesAdmReqTabObj.student_f_name);
        lPreparedStatement.setString(17, inEesAdmReqTabObj.student_m_name);
        lPreparedStatement.setString(18, inEesAdmReqTabObj.student_l_name);
        lPreparedStatement.setString(19, inEesAdmReqTabObj.dob);
        lPreparedStatement.setString(20, inEesAdmReqTabObj.age_on_date);
          lPreparedStatement.setByte(21, inEesAdmReqTabObj.age_year);
        lPreparedStatement.setString(22, inEesAdmReqTabObj.age_month);
          lPreparedStatement.setByte(23, inEesAdmReqTabObj.age_day);
        lPreparedStatement.setString(24, inEesAdmReqTabObj.s_nationality);
        lPreparedStatement.setString(25, inEesAdmReqTabObj.religion);
        lPreparedStatement.setString(26, inEesAdmReqTabObj.student_ctg);
        lPreparedStatement.setString(27, inEesAdmReqTabObj.gender_flag);
        lPreparedStatement.setString(28, inEesAdmReqTabObj.p_address_1);
        lPreparedStatement.setString(29, inEesAdmReqTabObj.p_address_2);
        lPreparedStatement.setString(30, inEesAdmReqTabObj.p_country);
        lPreparedStatement.setString(31, inEesAdmReqTabObj.p_state);
        lPreparedStatement.setString(32, inEesAdmReqTabObj.p_city);
        lPreparedStatement.setString(33, inEesAdmReqTabObj.p_district);
        lPreparedStatement.setString(34, inEesAdmReqTabObj.p_zip);
        lPreparedStatement.setString(35, inEesAdmReqTabObj.m_address_1);
        lPreparedStatement.setString(36, inEesAdmReqTabObj.m_address_2);
        lPreparedStatement.setString(37, inEesAdmReqTabObj.m_country);
        lPreparedStatement.setString(38, inEesAdmReqTabObj.m_state);
        lPreparedStatement.setString(39, inEesAdmReqTabObj.m_city);
        lPreparedStatement.setString(40, inEesAdmReqTabObj.m_district);
        lPreparedStatement.setString(41, inEesAdmReqTabObj.m_zip);
        lPreparedStatement.setString(42, inEesAdmReqTabObj.phone_list);
        lPreparedStatement.setString(43, inEesAdmReqTabObj.email_list);
        lPreparedStatement.setString(44, inEesAdmReqTabObj.fax_list);
        lPreparedStatement.setString(45, inEesAdmReqTabObj.prev_org_name);
        lPreparedStatement.setString(46, inEesAdmReqTabObj.prev_class_id);
        lPreparedStatement.setString(47, inEesAdmReqTabObj.prev_class_num);
        lPreparedStatement.setString(48, inEesAdmReqTabObj.prev_class_std);
        lPreparedStatement.setString(49, inEesAdmReqTabObj.prev_class_section);
        lPreparedStatement.setString(50, inEesAdmReqTabObj.prev_course_id);
        lPreparedStatement.setString(51, inEesAdmReqTabObj.prev_course_term);
        lPreparedStatement.setString(52, inEesAdmReqTabObj.prev_course_stream);
        lPreparedStatement.setString(53, inEesAdmReqTabObj.reason_for_leaving);
        lPreparedStatement.setString(54, inEesAdmReqTabObj.father_name);
          lPreparedStatement.setByte(55, inEesAdmReqTabObj.father_age);
        lPreparedStatement.setString(56, inEesAdmReqTabObj.f_nationality);
        lPreparedStatement.setString(57, inEesAdmReqTabObj.father_occ_type);
        lPreparedStatement.setString(58, inEesAdmReqTabObj.father_employer);
        lPreparedStatement.setString(59, inEesAdmReqTabObj.father_designation);
          lPreparedStatement.setDouble(60, inEesAdmReqTabObj.father_annual_income);
        lPreparedStatement.setString(61, inEesAdmReqTabObj.f_off_address_1);
        lPreparedStatement.setString(62, inEesAdmReqTabObj.f_phone_list);
        lPreparedStatement.setString(63, inEesAdmReqTabObj.mother_name);
          lPreparedStatement.setByte(64, inEesAdmReqTabObj.mother_age);
        lPreparedStatement.setString(65, inEesAdmReqTabObj.m_nationality);
        lPreparedStatement.setString(66, inEesAdmReqTabObj.mother_occ_type);
        lPreparedStatement.setString(67, inEesAdmReqTabObj.mother_employer);
        lPreparedStatement.setString(68, inEesAdmReqTabObj.mother_designation);
          lPreparedStatement.setDouble(69, inEesAdmReqTabObj.mother_annual_income);
        lPreparedStatement.setString(70, inEesAdmReqTabObj.m_off_address_1);
        lPreparedStatement.setString(71, inEesAdmReqTabObj.m_phone_list);
        lPreparedStatement.setString(72, inEesAdmReqTabObj.divorced_flag);
        lPreparedStatement.setString(73, inEesAdmReqTabObj.child_with);
        lPreparedStatement.setString(74, inEesAdmReqTabObj.roll_num);
        lPreparedStatement.setString(75, inEesAdmReqTabObj.academic_session);
        lPreparedStatement.setString(76, inEesAdmReqTabObj.adm_req_sts);
        lPreparedStatement.setString(77, inEesAdmReqTabObj.adm_req_sts_date);
        lPreparedStatement.setString(78, inEesAdmReqTabObj.student_id);
        lPreparedStatement.setString(79, inEesAdmReqTabObj.scholor_num);
        lPreparedStatement.setString(80, inEesAdmReqTabObj.form_recv_date);
        lPreparedStatement.setString(81, inEesAdmReqTabObj.form_recv_time);
        lPreparedStatement.setString(82, inEesAdmReqTabObj.prospectus_sale_date);
        lPreparedStatement.setString(83, inEesAdmReqTabObj.prospectus_sale_time);
        lPreparedStatement.setString(84, inEesAdmReqTabObj.prospectus_sold_by);
          lPreparedStatement.setDouble(85, inEesAdmReqTabObj.application_form_fee);
        lPreparedStatement.setString(86, inEesAdmReqTabObj.adm_academic_session);
        lPreparedStatement.setString(87, inEesAdmReqTabObj.entrance_exam_date);
        lPreparedStatement.setString(88, inEesAdmReqTabObj.entrance_exam_time_start);
        lPreparedStatement.setString(89, inEesAdmReqTabObj.entrance_exam_time_end);
        lPreparedStatement.setString(90, inEesAdmReqTabObj.exam_present_status);
        lPreparedStatement.setString(91, inEesAdmReqTabObj.building_id);
        lPreparedStatement.setString(92, inEesAdmReqTabObj.floor_num);
        lPreparedStatement.setString(93, inEesAdmReqTabObj.room_num);
          lPreparedStatement.setShort(94, inEesAdmReqTabObj.max_mark);
          lPreparedStatement.setShort(95, inEesAdmReqTabObj.obtained_mark);
        lPreparedStatement.setString(96, inEesAdmReqTabObj.grade);
        lPreparedStatement.setString(97, inEesAdmReqTabObj.fee_sch_date);
        lPreparedStatement.setString(98, inEesAdmReqTabObj.fee_deposit_date);
        lPreparedStatement.setString(99, inEesAdmReqTabObj.online_flag);
        lPreparedStatement.setString(100, inEesAdmReqTabObj.admission_mode);
        lPreparedStatement.setString(101, inEesAdmReqTabObj.course_stream_1);
        lPreparedStatement.setString(102, inEesAdmReqTabObj.course_stream_2);
        lPreparedStatement.setString(103, inEesAdmReqTabObj.course_stream_3);
        lPreparedStatement.setString(104, inEesAdmReqTabObj.course_stream_4);
        lPreparedStatement.setString(105, inEesAdmReqTabObj.apr_course_stream);
        lPreparedStatement.setString(106, inEesAdmReqTabObj.unv_1);
        lPreparedStatement.setString(107, inEesAdmReqTabObj.unv_rn_1);
        lPreparedStatement.setString(108, inEesAdmReqTabObj.gen_rank_1);
        lPreparedStatement.setString(109, inEesAdmReqTabObj.ctg_rank_1);
        lPreparedStatement.setString(110, inEesAdmReqTabObj.stt_rank_1);
        lPreparedStatement.setString(111, inEesAdmReqTabObj.yoa_1);
        lPreparedStatement.setString(112, inEesAdmReqTabObj.unv_2);
        lPreparedStatement.setString(113, inEesAdmReqTabObj.unv_rn_2);
        lPreparedStatement.setString(114, inEesAdmReqTabObj.gen_rank_2);
        lPreparedStatement.setString(115, inEesAdmReqTabObj.ctg_rank_2);
        lPreparedStatement.setString(116, inEesAdmReqTabObj.stt_rank_2);
        lPreparedStatement.setString(117, inEesAdmReqTabObj.yoa_2);
          lPreparedStatement.setFloat(118, inEesAdmReqTabObj.prev_mark_percent);
        lPreparedStatement.setString(119, inEesAdmReqTabObj.domecile_ind);
        lPreparedStatement.setString(120, inEesAdmReqTabObj.org_transport_req_ind);
        lPreparedStatement.setString(121, inEesAdmReqTabObj.org_hostel_req_ind);
        lPreparedStatement.setString(122, inEesAdmReqTabObj.cheque_num);
        lPreparedStatement.setString(123, inEesAdmReqTabObj.cheque_date);
        lPreparedStatement.setString(124, inEesAdmReqTabObj.bank_code);
        lPreparedStatement.setString(125, inEesAdmReqTabObj.bank_name);
          lPreparedStatement.setDouble(126, inEesAdmReqTabObj.cheque_amt);
        lPreparedStatement.setString(127, inEesAdmReqTabObj.lg_0_name);
        lPreparedStatement.setString(128, inEesAdmReqTabObj.lg_0_rel_type);
        lPreparedStatement.setString(129, inEesAdmReqTabObj.lg_0_address);
        lPreparedStatement.setString(130, inEesAdmReqTabObj.lg_0_phone);
        lPreparedStatement.setString(131, inEesAdmReqTabObj.lg_1_name);
        lPreparedStatement.setString(132, inEesAdmReqTabObj.lg_1_rel_type);
        lPreparedStatement.setString(133, inEesAdmReqTabObj.lg_1_address);
        lPreparedStatement.setString(134, inEesAdmReqTabObj.lg_1_phone);
        lPreparedStatement.setString(135, inEesAdmReqTabObj.st_cap_attr_1);
        lPreparedStatement.setString(136, inEesAdmReqTabObj.st_cap_attr_2);
        lPreparedStatement.setString(137, inEesAdmReqTabObj.st_cap_attr_3);
        lPreparedStatement.setString(138, inEesAdmReqTabObj.st_cap_attr_4);
        lPreparedStatement.setString(139, inEesAdmReqTabObj.st_cap_attr_5);
        lPreparedStatement.setString(140, inEesAdmReqTabObj.st_cap_attr_6);
        lPreparedStatement.setString(141, inEesAdmReqTabObj.st_cap_attr_7);
        lPreparedStatement.setString(142, inEesAdmReqTabObj.st_cap_attr_8);
        lPreparedStatement.setString(143, inEesAdmReqTabObj.allergy);
        lPreparedStatement.setString(144, inEesAdmReqTabObj.physical_disability);
        lPreparedStatement.setString(145, inEesAdmReqTabObj.health_problem);
        lPreparedStatement.setString(146, inEesAdmReqTabObj.health_problem_1);
        lPreparedStatement.setString(147, inEesAdmReqTabObj.health_problem_2);
        lPreparedStatement.setString(148, inEesAdmReqTabObj.health_problem_3);
        lPreparedStatement.setString(149, inEesAdmReqTabObj.health_problem_4);
        lPreparedStatement.setString(150, inEesAdmReqTabObj.health_problem_5);
        lPreparedStatement.setString(151, inEesAdmReqTabObj.health_problem_6);
        lPreparedStatement.setString(152, inEesAdmReqTabObj.health_problem_7);
        lPreparedStatement.setString(153, inEesAdmReqTabObj.health_problem_8);
        lPreparedStatement.setString(154, inEesAdmReqTabObj.health_problem_9);
        lPreparedStatement.setString(155, inEesAdmReqTabObj.health_problem_10);
        lPreparedStatement.setString(156, inEesAdmReqTabObj.health_problem_11);
        lPreparedStatement.setString(157, inEesAdmReqTabObj.health_problem_12);
        lPreparedStatement.setString(158, inEesAdmReqTabObj.enclosure_1);
        lPreparedStatement.setString(159, inEesAdmReqTabObj.enclosure_2);
        lPreparedStatement.setString(160, inEesAdmReqTabObj.enclosure_3);
        lPreparedStatement.setString(161, inEesAdmReqTabObj.enclosure_4);
        lPreparedStatement.setString(162, inEesAdmReqTabObj.enclosure_5);
        lPreparedStatement.setString(163, inEesAdmReqTabObj.enclosure_6);
        lPreparedStatement.setString(164, inEesAdmReqTabObj.enclosure_7);
        lPreparedStatement.setString(165, inEesAdmReqTabObj.enclosure_8);
          lPreparedStatement.setShort(166, inEesAdmReqTabObj.seat_num);
        lPreparedStatement.setString(167, inEesAdmReqTabObj.reason_for_join);
        lPreparedStatement.setString(168, inEesAdmReqTabObj.remark);
        lPreparedStatement.setString(169, inEesAdmReqTabObj.place_of_birth);
          lPreparedStatement.setDouble(170, inEesAdmReqTabObj.adv_adm_fee);
        lPreparedStatement.setString(171, inEesAdmReqTabObj.payment_mode);
        lPreparedStatement.setString(172, inEesAdmReqTabObj.target_ptl_user_id);
        lPreparedStatement.setString(173, inEesAdmReqTabObj.adm_req_id_req);
        lPreparedStatement.setString(174, inEesAdmReqTabObj.adm_req_id_list);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesAdmReqArr
               ( ArrayList  inEesAdmReqTabObjArr 
               , String  inRowidFlag )
  {
    EesAdmReqTabObj  lEesAdmReqTabObj = new EesAdmReqTabObj();
    int lUpdateCount;
    sop("insEesAdmReqArr - Started");
    gSSTErrorObj.sourceMethod = "insEesAdmReqArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesAdmReqTabObjArr.size(); lNumRec++ )
      {
        lEesAdmReqTabObj = (EesAdmReqTabObj)inEesAdmReqTabObjArr.get(lNumRec);

          if ( lEesAdmReqTabObj.dob != null && lEesAdmReqTabObj.dob.length() > 0 ) 
            lEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.dob, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.age_on_date != null && lEesAdmReqTabObj.age_on_date.length() > 0 ) 
            lEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.age_on_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.adm_req_sts_date != null && lEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.form_recv_date != null && lEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            lEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.prospectus_sale_date != null && lEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.entrance_exam_date != null && lEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.fee_sch_date != null && lEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.fee_deposit_date != null && lEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( lEesAdmReqTabObj.cheque_date != null && lEesAdmReqTabObj.cheque_date.length() > 0 ) 
            lEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmReqTabObj.cheque_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ADM_REQ"+
                        "("+
                        "org_id,"+
                        "adm_req_id,"+
                        "application_form_num,"+
                        "applicant_id,"+
                        "student_photo_file,"+
                        "mother_photo_file,"+
                        "father_photo_file,"+
                        "class_id,"+
                        "class_num,"+
                        "class_std,"+
                        "class_section,"+
                        "course_id,"+
                        "course_term,"+
                        "course_stream,"+
                        "name_initials,"+
                        "student_f_name,"+
                        "student_m_name,"+
                        "student_l_name,"+
                        "dob,"+
                        "age_on_date,"+
                        "age_year,"+
                        "age_month,"+
                        "age_day,"+
                        "s_nationality,"+
                        "religion,"+
                        "student_ctg,"+
                        "gender_flag,"+
                        "p_address_1,"+
                        "p_address_2,"+
                        "p_country,"+
                        "p_state,"+
                        "p_city,"+
                        "p_district,"+
                        "p_zip,"+
                        "m_address_1,"+
                        "m_address_2,"+
                        "m_country,"+
                        "m_state,"+
                        "m_city,"+
                        "m_district,"+
                        "m_zip,"+
                        "phone_list,"+
                        "email_list,"+
                        "fax_list,"+
                        "prev_org_name,"+
                        "prev_class_id,"+
                        "prev_class_num,"+
                        "prev_class_std,"+
                        "prev_class_section,"+
                        "prev_course_id,"+
                        "prev_course_term,"+
                        "prev_course_stream,"+
                        "reason_for_leaving,"+
                        "father_name,"+
                        "father_age,"+
                        "f_nationality,"+
                        "father_occ_type,"+
                        "father_employer,"+
                        "father_designation,"+
                        "father_annual_income,"+
                        "f_off_address_1,"+
                        "f_phone_list,"+
                        "mother_name,"+
                        "mother_age,"+
                        "m_nationality,"+
                        "mother_occ_type,"+
                        "mother_employer,"+
                        "mother_designation,"+
                        "mother_annual_income,"+
                        "m_off_address_1,"+
                        "m_phone_list,"+
                        "divorced_flag,"+
                        "child_with,"+
                        "roll_num,"+
                        "academic_session,"+
                        "adm_req_sts,"+
                        "adm_req_sts_date,"+
                        "student_id,"+
                        "scholor_num,"+
                        "form_recv_date,"+
                        "form_recv_time,"+
                        "prospectus_sale_date,"+
                        "prospectus_sale_time,"+
                        "prospectus_sold_by,"+
                        "application_form_fee,"+
                        "adm_academic_session,"+
                        "entrance_exam_date,"+
                        "entrance_exam_time_start,"+
                        "entrance_exam_time_end,"+
                        "exam_present_status,"+
                        "building_id,"+
                        "floor_num,"+
                        "room_num,"+
                        "max_mark,"+
                        "obtained_mark,"+
                        "grade,"+
                        "fee_sch_date,"+
                        "fee_deposit_date,"+
                        "online_flag,"+
                        "admission_mode,"+
                        "course_stream_1,"+
                        "course_stream_2,"+
                        "course_stream_3,"+
                        "course_stream_4,"+
                        "apr_course_stream,"+
                        "unv_1,"+
                        "unv_rn_1,"+
                        "gen_rank_1,"+
                        "ctg_rank_1,"+
                        "stt_rank_1,"+
                        "yoa_1,"+
                        "unv_2,"+
                        "unv_rn_2,"+
                        "gen_rank_2,"+
                        "ctg_rank_2,"+
                        "stt_rank_2,"+
                        "yoa_2,"+
                        "prev_mark_percent,"+
                        "domecile_ind,"+
                        "org_transport_req_ind,"+
                        "org_hostel_req_ind,"+
                        "cheque_num,"+
                        "cheque_date,"+
                        "bank_code,"+
                        "bank_name,"+
                        "cheque_amt,"+
                        "lg_0_name,"+
                        "lg_0_rel_type,"+
                        "lg_0_address,"+
                        "lg_0_phone,"+
                        "lg_1_name,"+
                        "lg_1_rel_type,"+
                        "lg_1_address,"+
                        "lg_1_phone,"+
                        "st_cap_attr_1,"+
                        "st_cap_attr_2,"+
                        "st_cap_attr_3,"+
                        "st_cap_attr_4,"+
                        "st_cap_attr_5,"+
                        "st_cap_attr_6,"+
                        "st_cap_attr_7,"+
                        "st_cap_attr_8,"+
                        "allergy,"+
                        "physical_disability,"+
                        "health_problem,"+
                        "health_problem_1,"+
                        "health_problem_2,"+
                        "health_problem_3,"+
                        "health_problem_4,"+
                        "health_problem_5,"+
                        "health_problem_6,"+
                        "health_problem_7,"+
                        "health_problem_8,"+
                        "health_problem_9,"+
                        "health_problem_10,"+
                        "health_problem_11,"+
                        "health_problem_12,"+
                        "enclosure_1,"+
                        "enclosure_2,"+
                        "enclosure_3,"+
                        "enclosure_4,"+
                        "enclosure_5,"+
                        "enclosure_6,"+
                        "enclosure_7,"+
                        "enclosure_8,"+
                        "seat_num,"+
                        "reason_for_join,"+
                        "remark,"+
                        "place_of_birth,"+
                        "adv_adm_fee,"+
                        "payment_mode,"+
                        "target_ptl_user_id,"+
                        "adm_req_id_req,"+
                        "adm_req_id_list"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_req_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.application_form_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.applicant_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.mother_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.father_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.name_initials+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_f_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_m_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_l_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.dob+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.age_on_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.age_year+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.age_month+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.age_day+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.s_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.religion+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.gender_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_district+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.p_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_district+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.email_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.fax_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_org_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prev_course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.reason_for_leaving+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.father_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.father_age+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.f_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.father_occ_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.father_employer+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.father_designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.father_annual_income+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.f_off_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.f_phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.mother_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.mother_age+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.mother_occ_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.mother_employer+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.mother_designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.mother_annual_income+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_off_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.m_phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.divorced_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.child_with+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.roll_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.academic_session+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_req_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_req_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.student_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.scholor_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.form_recv_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.form_recv_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prospectus_sale_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prospectus_sale_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.prospectus_sold_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.application_form_fee+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_academic_session+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.entrance_exam_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.entrance_exam_time_start+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.entrance_exam_time_end+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.exam_present_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.building_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.floor_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.room_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.max_mark+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.obtained_mark+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.grade+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.fee_sch_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.fee_deposit_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.online_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.admission_mode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_stream_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_stream_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_stream_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.course_stream_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.apr_course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.unv_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.unv_rn_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.gen_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.ctg_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.stt_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.yoa_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.unv_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.unv_rn_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.gen_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.ctg_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.stt_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.yoa_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.prev_mark_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.domecile_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.org_transport_req_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.org_hostel_req_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.cheque_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.cheque_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.bank_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.bank_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.cheque_amt+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_0_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_0_rel_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_0_address+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_0_phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_1_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_1_rel_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_1_address+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.lg_1_phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.st_cap_attr_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.allergy+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.physical_disability+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_9+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_10+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_11+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.health_problem_12+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.enclosure_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.seat_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.reason_for_join+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.place_of_birth+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmReqTabObj.adv_adm_fee+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.payment_mode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.target_ptl_user_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_req_id_req+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesAdmReqTabObj.adm_req_id_list+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesAdmReqTabObj.org_id);
            lPreparedStatement.setString(2, lEesAdmReqTabObj.adm_req_id);
            lPreparedStatement.setString(3, lEesAdmReqTabObj.application_form_num);
            lPreparedStatement.setString(4, lEesAdmReqTabObj.applicant_id);
            lPreparedStatement.setString(5, lEesAdmReqTabObj.student_photo_file);
            lPreparedStatement.setString(6, lEesAdmReqTabObj.mother_photo_file);
            lPreparedStatement.setString(7, lEesAdmReqTabObj.father_photo_file);
            lPreparedStatement.setString(8, lEesAdmReqTabObj.class_id);
            lPreparedStatement.setString(9, lEesAdmReqTabObj.class_num);
            lPreparedStatement.setString(10, lEesAdmReqTabObj.class_std);
            lPreparedStatement.setString(11, lEesAdmReqTabObj.class_section);
            lPreparedStatement.setString(12, lEesAdmReqTabObj.course_id);
            lPreparedStatement.setString(13, lEesAdmReqTabObj.course_term);
            lPreparedStatement.setString(14, lEesAdmReqTabObj.course_stream);
            lPreparedStatement.setString(15, lEesAdmReqTabObj.name_initials);
            lPreparedStatement.setString(16, lEesAdmReqTabObj.student_f_name);
            lPreparedStatement.setString(17, lEesAdmReqTabObj.student_m_name);
            lPreparedStatement.setString(18, lEesAdmReqTabObj.student_l_name);
            lPreparedStatement.setString(19, lEesAdmReqTabObj.dob);
            lPreparedStatement.setString(20, lEesAdmReqTabObj.age_on_date);
              lPreparedStatement.setByte(21, lEesAdmReqTabObj.age_year);
            lPreparedStatement.setString(22, lEesAdmReqTabObj.age_month);
              lPreparedStatement.setByte(23, lEesAdmReqTabObj.age_day);
            lPreparedStatement.setString(24, lEesAdmReqTabObj.s_nationality);
            lPreparedStatement.setString(25, lEesAdmReqTabObj.religion);
            lPreparedStatement.setString(26, lEesAdmReqTabObj.student_ctg);
            lPreparedStatement.setString(27, lEesAdmReqTabObj.gender_flag);
            lPreparedStatement.setString(28, lEesAdmReqTabObj.p_address_1);
            lPreparedStatement.setString(29, lEesAdmReqTabObj.p_address_2);
            lPreparedStatement.setString(30, lEesAdmReqTabObj.p_country);
            lPreparedStatement.setString(31, lEesAdmReqTabObj.p_state);
            lPreparedStatement.setString(32, lEesAdmReqTabObj.p_city);
            lPreparedStatement.setString(33, lEesAdmReqTabObj.p_district);
            lPreparedStatement.setString(34, lEesAdmReqTabObj.p_zip);
            lPreparedStatement.setString(35, lEesAdmReqTabObj.m_address_1);
            lPreparedStatement.setString(36, lEesAdmReqTabObj.m_address_2);
            lPreparedStatement.setString(37, lEesAdmReqTabObj.m_country);
            lPreparedStatement.setString(38, lEesAdmReqTabObj.m_state);
            lPreparedStatement.setString(39, lEesAdmReqTabObj.m_city);
            lPreparedStatement.setString(40, lEesAdmReqTabObj.m_district);
            lPreparedStatement.setString(41, lEesAdmReqTabObj.m_zip);
            lPreparedStatement.setString(42, lEesAdmReqTabObj.phone_list);
            lPreparedStatement.setString(43, lEesAdmReqTabObj.email_list);
            lPreparedStatement.setString(44, lEesAdmReqTabObj.fax_list);
            lPreparedStatement.setString(45, lEesAdmReqTabObj.prev_org_name);
            lPreparedStatement.setString(46, lEesAdmReqTabObj.prev_class_id);
            lPreparedStatement.setString(47, lEesAdmReqTabObj.prev_class_num);
            lPreparedStatement.setString(48, lEesAdmReqTabObj.prev_class_std);
            lPreparedStatement.setString(49, lEesAdmReqTabObj.prev_class_section);
            lPreparedStatement.setString(50, lEesAdmReqTabObj.prev_course_id);
            lPreparedStatement.setString(51, lEesAdmReqTabObj.prev_course_term);
            lPreparedStatement.setString(52, lEesAdmReqTabObj.prev_course_stream);
            lPreparedStatement.setString(53, lEesAdmReqTabObj.reason_for_leaving);
            lPreparedStatement.setString(54, lEesAdmReqTabObj.father_name);
              lPreparedStatement.setByte(55, lEesAdmReqTabObj.father_age);
            lPreparedStatement.setString(56, lEesAdmReqTabObj.f_nationality);
            lPreparedStatement.setString(57, lEesAdmReqTabObj.father_occ_type);
            lPreparedStatement.setString(58, lEesAdmReqTabObj.father_employer);
            lPreparedStatement.setString(59, lEesAdmReqTabObj.father_designation);
              lPreparedStatement.setDouble(60, lEesAdmReqTabObj.father_annual_income);
            lPreparedStatement.setString(61, lEesAdmReqTabObj.f_off_address_1);
            lPreparedStatement.setString(62, lEesAdmReqTabObj.f_phone_list);
            lPreparedStatement.setString(63, lEesAdmReqTabObj.mother_name);
              lPreparedStatement.setByte(64, lEesAdmReqTabObj.mother_age);
            lPreparedStatement.setString(65, lEesAdmReqTabObj.m_nationality);
            lPreparedStatement.setString(66, lEesAdmReqTabObj.mother_occ_type);
            lPreparedStatement.setString(67, lEesAdmReqTabObj.mother_employer);
            lPreparedStatement.setString(68, lEesAdmReqTabObj.mother_designation);
              lPreparedStatement.setDouble(69, lEesAdmReqTabObj.mother_annual_income);
            lPreparedStatement.setString(70, lEesAdmReqTabObj.m_off_address_1);
            lPreparedStatement.setString(71, lEesAdmReqTabObj.m_phone_list);
            lPreparedStatement.setString(72, lEesAdmReqTabObj.divorced_flag);
            lPreparedStatement.setString(73, lEesAdmReqTabObj.child_with);
            lPreparedStatement.setString(74, lEesAdmReqTabObj.roll_num);
            lPreparedStatement.setString(75, lEesAdmReqTabObj.academic_session);
            lPreparedStatement.setString(76, lEesAdmReqTabObj.adm_req_sts);
            lPreparedStatement.setString(77, lEesAdmReqTabObj.adm_req_sts_date);
            lPreparedStatement.setString(78, lEesAdmReqTabObj.student_id);
            lPreparedStatement.setString(79, lEesAdmReqTabObj.scholor_num);
            lPreparedStatement.setString(80, lEesAdmReqTabObj.form_recv_date);
            lPreparedStatement.setString(81, lEesAdmReqTabObj.form_recv_time);
            lPreparedStatement.setString(82, lEesAdmReqTabObj.prospectus_sale_date);
            lPreparedStatement.setString(83, lEesAdmReqTabObj.prospectus_sale_time);
            lPreparedStatement.setString(84, lEesAdmReqTabObj.prospectus_sold_by);
              lPreparedStatement.setDouble(85, lEesAdmReqTabObj.application_form_fee);
            lPreparedStatement.setString(86, lEesAdmReqTabObj.adm_academic_session);
            lPreparedStatement.setString(87, lEesAdmReqTabObj.entrance_exam_date);
            lPreparedStatement.setString(88, lEesAdmReqTabObj.entrance_exam_time_start);
            lPreparedStatement.setString(89, lEesAdmReqTabObj.entrance_exam_time_end);
            lPreparedStatement.setString(90, lEesAdmReqTabObj.exam_present_status);
            lPreparedStatement.setString(91, lEesAdmReqTabObj.building_id);
            lPreparedStatement.setString(92, lEesAdmReqTabObj.floor_num);
            lPreparedStatement.setString(93, lEesAdmReqTabObj.room_num);
              lPreparedStatement.setShort(94, lEesAdmReqTabObj.max_mark);
              lPreparedStatement.setShort(95, lEesAdmReqTabObj.obtained_mark);
            lPreparedStatement.setString(96, lEesAdmReqTabObj.grade);
            lPreparedStatement.setString(97, lEesAdmReqTabObj.fee_sch_date);
            lPreparedStatement.setString(98, lEesAdmReqTabObj.fee_deposit_date);
            lPreparedStatement.setString(99, lEesAdmReqTabObj.online_flag);
            lPreparedStatement.setString(100, lEesAdmReqTabObj.admission_mode);
            lPreparedStatement.setString(101, lEesAdmReqTabObj.course_stream_1);
            lPreparedStatement.setString(102, lEesAdmReqTabObj.course_stream_2);
            lPreparedStatement.setString(103, lEesAdmReqTabObj.course_stream_3);
            lPreparedStatement.setString(104, lEesAdmReqTabObj.course_stream_4);
            lPreparedStatement.setString(105, lEesAdmReqTabObj.apr_course_stream);
            lPreparedStatement.setString(106, lEesAdmReqTabObj.unv_1);
            lPreparedStatement.setString(107, lEesAdmReqTabObj.unv_rn_1);
            lPreparedStatement.setString(108, lEesAdmReqTabObj.gen_rank_1);
            lPreparedStatement.setString(109, lEesAdmReqTabObj.ctg_rank_1);
            lPreparedStatement.setString(110, lEesAdmReqTabObj.stt_rank_1);
            lPreparedStatement.setString(111, lEesAdmReqTabObj.yoa_1);
            lPreparedStatement.setString(112, lEesAdmReqTabObj.unv_2);
            lPreparedStatement.setString(113, lEesAdmReqTabObj.unv_rn_2);
            lPreparedStatement.setString(114, lEesAdmReqTabObj.gen_rank_2);
            lPreparedStatement.setString(115, lEesAdmReqTabObj.ctg_rank_2);
            lPreparedStatement.setString(116, lEesAdmReqTabObj.stt_rank_2);
            lPreparedStatement.setString(117, lEesAdmReqTabObj.yoa_2);
              lPreparedStatement.setFloat(118, lEesAdmReqTabObj.prev_mark_percent);
            lPreparedStatement.setString(119, lEesAdmReqTabObj.domecile_ind);
            lPreparedStatement.setString(120, lEesAdmReqTabObj.org_transport_req_ind);
            lPreparedStatement.setString(121, lEesAdmReqTabObj.org_hostel_req_ind);
            lPreparedStatement.setString(122, lEesAdmReqTabObj.cheque_num);
            lPreparedStatement.setString(123, lEesAdmReqTabObj.cheque_date);
            lPreparedStatement.setString(124, lEesAdmReqTabObj.bank_code);
            lPreparedStatement.setString(125, lEesAdmReqTabObj.bank_name);
              lPreparedStatement.setDouble(126, lEesAdmReqTabObj.cheque_amt);
            lPreparedStatement.setString(127, lEesAdmReqTabObj.lg_0_name);
            lPreparedStatement.setString(128, lEesAdmReqTabObj.lg_0_rel_type);
            lPreparedStatement.setString(129, lEesAdmReqTabObj.lg_0_address);
            lPreparedStatement.setString(130, lEesAdmReqTabObj.lg_0_phone);
            lPreparedStatement.setString(131, lEesAdmReqTabObj.lg_1_name);
            lPreparedStatement.setString(132, lEesAdmReqTabObj.lg_1_rel_type);
            lPreparedStatement.setString(133, lEesAdmReqTabObj.lg_1_address);
            lPreparedStatement.setString(134, lEesAdmReqTabObj.lg_1_phone);
            lPreparedStatement.setString(135, lEesAdmReqTabObj.st_cap_attr_1);
            lPreparedStatement.setString(136, lEesAdmReqTabObj.st_cap_attr_2);
            lPreparedStatement.setString(137, lEesAdmReqTabObj.st_cap_attr_3);
            lPreparedStatement.setString(138, lEesAdmReqTabObj.st_cap_attr_4);
            lPreparedStatement.setString(139, lEesAdmReqTabObj.st_cap_attr_5);
            lPreparedStatement.setString(140, lEesAdmReqTabObj.st_cap_attr_6);
            lPreparedStatement.setString(141, lEesAdmReqTabObj.st_cap_attr_7);
            lPreparedStatement.setString(142, lEesAdmReqTabObj.st_cap_attr_8);
            lPreparedStatement.setString(143, lEesAdmReqTabObj.allergy);
            lPreparedStatement.setString(144, lEesAdmReqTabObj.physical_disability);
            lPreparedStatement.setString(145, lEesAdmReqTabObj.health_problem);
            lPreparedStatement.setString(146, lEesAdmReqTabObj.health_problem_1);
            lPreparedStatement.setString(147, lEesAdmReqTabObj.health_problem_2);
            lPreparedStatement.setString(148, lEesAdmReqTabObj.health_problem_3);
            lPreparedStatement.setString(149, lEesAdmReqTabObj.health_problem_4);
            lPreparedStatement.setString(150, lEesAdmReqTabObj.health_problem_5);
            lPreparedStatement.setString(151, lEesAdmReqTabObj.health_problem_6);
            lPreparedStatement.setString(152, lEesAdmReqTabObj.health_problem_7);
            lPreparedStatement.setString(153, lEesAdmReqTabObj.health_problem_8);
            lPreparedStatement.setString(154, lEesAdmReqTabObj.health_problem_9);
            lPreparedStatement.setString(155, lEesAdmReqTabObj.health_problem_10);
            lPreparedStatement.setString(156, lEesAdmReqTabObj.health_problem_11);
            lPreparedStatement.setString(157, lEesAdmReqTabObj.health_problem_12);
            lPreparedStatement.setString(158, lEesAdmReqTabObj.enclosure_1);
            lPreparedStatement.setString(159, lEesAdmReqTabObj.enclosure_2);
            lPreparedStatement.setString(160, lEesAdmReqTabObj.enclosure_3);
            lPreparedStatement.setString(161, lEesAdmReqTabObj.enclosure_4);
            lPreparedStatement.setString(162, lEesAdmReqTabObj.enclosure_5);
            lPreparedStatement.setString(163, lEesAdmReqTabObj.enclosure_6);
            lPreparedStatement.setString(164, lEesAdmReqTabObj.enclosure_7);
            lPreparedStatement.setString(165, lEesAdmReqTabObj.enclosure_8);
              lPreparedStatement.setShort(166, lEesAdmReqTabObj.seat_num);
            lPreparedStatement.setString(167, lEesAdmReqTabObj.reason_for_join);
            lPreparedStatement.setString(168, lEesAdmReqTabObj.remark);
            lPreparedStatement.setString(169, lEesAdmReqTabObj.place_of_birth);
              lPreparedStatement.setDouble(170, lEesAdmReqTabObj.adv_adm_fee);
            lPreparedStatement.setString(171, lEesAdmReqTabObj.payment_mode);
            lPreparedStatement.setString(172, lEesAdmReqTabObj.target_ptl_user_id);
            lPreparedStatement.setString(173, lEesAdmReqTabObj.adm_req_id_req);
            lPreparedStatement.setString(174, lEesAdmReqTabObj.adm_req_id_list);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesAdmReqReq2Obj
               ( HttpServletRequest inRequest
               , EesAdmReqTabObj  outEesAdmReqTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesAdmReqTabObj.tab_rowid = lTabRowidValue;

    outEesAdmReqTabObj.org_id = inRequest.getParameter("org_id");
    outEesAdmReqTabObj.adm_req_id = inRequest.getParameter("adm_req_id");
    outEesAdmReqTabObj.application_form_num = inRequest.getParameter("application_form_num");
    outEesAdmReqTabObj.applicant_id = inRequest.getParameter("applicant_id");
    outEesAdmReqTabObj.student_photo_file = inRequest.getParameter("student_photo_file");
    outEesAdmReqTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file");
    outEesAdmReqTabObj.father_photo_file = inRequest.getParameter("father_photo_file");
    outEesAdmReqTabObj.class_id = inRequest.getParameter("class_id");
    outEesAdmReqTabObj.class_num = inRequest.getParameter("class_num");
    outEesAdmReqTabObj.class_std = inRequest.getParameter("class_std");
    outEesAdmReqTabObj.class_section = inRequest.getParameter("class_section");
    outEesAdmReqTabObj.course_id = inRequest.getParameter("course_id");
    outEesAdmReqTabObj.course_term = inRequest.getParameter("course_term");
    outEesAdmReqTabObj.course_stream = inRequest.getParameter("course_stream");
    outEesAdmReqTabObj.name_initials = inRequest.getParameter("name_initials");
    outEesAdmReqTabObj.student_f_name = inRequest.getParameter("student_f_name");
    outEesAdmReqTabObj.student_m_name = inRequest.getParameter("student_m_name");
    outEesAdmReqTabObj.student_l_name = inRequest.getParameter("student_l_name");
    outEesAdmReqTabObj.dob = inRequest.getParameter("dob");
    outEesAdmReqTabObj.age_on_date = inRequest.getParameter("age_on_date");
    if ( inRequest.getParameter("age_year") == null )
      outEesAdmReqTabObj.age_year = 0;
    else
    if ( inRequest.getParameter("age_year").trim().length() == 0 )
      outEesAdmReqTabObj.age_year = 0;
    else
      outEesAdmReqTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year"));
    outEesAdmReqTabObj.age_month = inRequest.getParameter("age_month");
    if ( inRequest.getParameter("age_day") == null )
      outEesAdmReqTabObj.age_day = 0;
    else
    if ( inRequest.getParameter("age_day").trim().length() == 0 )
      outEesAdmReqTabObj.age_day = 0;
    else
      outEesAdmReqTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day"));
    outEesAdmReqTabObj.s_nationality = inRequest.getParameter("s_nationality");
    outEesAdmReqTabObj.religion = inRequest.getParameter("religion");
    outEesAdmReqTabObj.student_ctg = inRequest.getParameter("student_ctg");
    outEesAdmReqTabObj.gender_flag = inRequest.getParameter("gender_flag");
    outEesAdmReqTabObj.p_address_1 = inRequest.getParameter("p_address_1");
    outEesAdmReqTabObj.p_address_2 = inRequest.getParameter("p_address_2");
    outEesAdmReqTabObj.p_country = inRequest.getParameter("p_country");
    outEesAdmReqTabObj.p_state = inRequest.getParameter("p_state");
    outEesAdmReqTabObj.p_city = inRequest.getParameter("p_city");
    outEesAdmReqTabObj.p_district = inRequest.getParameter("p_district");
    outEesAdmReqTabObj.p_zip = inRequest.getParameter("p_zip");
    outEesAdmReqTabObj.m_address_1 = inRequest.getParameter("m_address_1");
    outEesAdmReqTabObj.m_address_2 = inRequest.getParameter("m_address_2");
    outEesAdmReqTabObj.m_country = inRequest.getParameter("m_country");
    outEesAdmReqTabObj.m_state = inRequest.getParameter("m_state");
    outEesAdmReqTabObj.m_city = inRequest.getParameter("m_city");
    outEesAdmReqTabObj.m_district = inRequest.getParameter("m_district");
    outEesAdmReqTabObj.m_zip = inRequest.getParameter("m_zip");
    outEesAdmReqTabObj.phone_list = inRequest.getParameter("phone_list");
    outEesAdmReqTabObj.email_list = inRequest.getParameter("email_list");
    outEesAdmReqTabObj.fax_list = inRequest.getParameter("fax_list");
    outEesAdmReqTabObj.prev_org_name = inRequest.getParameter("prev_org_name");
    outEesAdmReqTabObj.prev_class_id = inRequest.getParameter("prev_class_id");
    outEesAdmReqTabObj.prev_class_num = inRequest.getParameter("prev_class_num");
    outEesAdmReqTabObj.prev_class_std = inRequest.getParameter("prev_class_std");
    outEesAdmReqTabObj.prev_class_section = inRequest.getParameter("prev_class_section");
    outEesAdmReqTabObj.prev_course_id = inRequest.getParameter("prev_course_id");
    outEesAdmReqTabObj.prev_course_term = inRequest.getParameter("prev_course_term");
    outEesAdmReqTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream");
    outEesAdmReqTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving");
    outEesAdmReqTabObj.father_name = inRequest.getParameter("father_name");
    if ( inRequest.getParameter("father_age") == null )
      outEesAdmReqTabObj.father_age = 0;
    else
    if ( inRequest.getParameter("father_age").trim().length() == 0 )
      outEesAdmReqTabObj.father_age = 0;
    else
      outEesAdmReqTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age"));
    outEesAdmReqTabObj.f_nationality = inRequest.getParameter("f_nationality");
    outEesAdmReqTabObj.father_occ_type = inRequest.getParameter("father_occ_type");
    outEesAdmReqTabObj.father_employer = inRequest.getParameter("father_employer");
    outEesAdmReqTabObj.father_designation = inRequest.getParameter("father_designation");
    if ( inRequest.getParameter("father_annual_income") == null )
      outEesAdmReqTabObj.father_annual_income = 0;
    else
    if ( inRequest.getParameter("father_annual_income").trim().length() == 0 )
      outEesAdmReqTabObj.father_annual_income = 0;
    else
      outEesAdmReqTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income"));
    outEesAdmReqTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1");
    outEesAdmReqTabObj.f_phone_list = inRequest.getParameter("f_phone_list");
    outEesAdmReqTabObj.mother_name = inRequest.getParameter("mother_name");
    if ( inRequest.getParameter("mother_age") == null )
      outEesAdmReqTabObj.mother_age = 0;
    else
    if ( inRequest.getParameter("mother_age").trim().length() == 0 )
      outEesAdmReqTabObj.mother_age = 0;
    else
      outEesAdmReqTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age"));
    outEesAdmReqTabObj.m_nationality = inRequest.getParameter("m_nationality");
    outEesAdmReqTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type");
    outEesAdmReqTabObj.mother_employer = inRequest.getParameter("mother_employer");
    outEesAdmReqTabObj.mother_designation = inRequest.getParameter("mother_designation");
    if ( inRequest.getParameter("mother_annual_income") == null )
      outEesAdmReqTabObj.mother_annual_income = 0;
    else
    if ( inRequest.getParameter("mother_annual_income").trim().length() == 0 )
      outEesAdmReqTabObj.mother_annual_income = 0;
    else
      outEesAdmReqTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income"));
    outEesAdmReqTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1");
    outEesAdmReqTabObj.m_phone_list = inRequest.getParameter("m_phone_list");
    outEesAdmReqTabObj.divorced_flag = inRequest.getParameter("divorced_flag");
    outEesAdmReqTabObj.child_with = inRequest.getParameter("child_with");
    outEesAdmReqTabObj.roll_num = inRequest.getParameter("roll_num");
    outEesAdmReqTabObj.academic_session = inRequest.getParameter("academic_session");
    outEesAdmReqTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts");
    outEesAdmReqTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date");
    outEesAdmReqTabObj.student_id = inRequest.getParameter("student_id");
    outEesAdmReqTabObj.scholor_num = inRequest.getParameter("scholor_num");
    outEesAdmReqTabObj.form_recv_date = inRequest.getParameter("form_recv_date");
    outEesAdmReqTabObj.form_recv_time = inRequest.getParameter("form_recv_time");
    outEesAdmReqTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date");
    outEesAdmReqTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time");
    outEesAdmReqTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by");
    if ( inRequest.getParameter("application_form_fee") == null )
      outEesAdmReqTabObj.application_form_fee = 0;
    else
    if ( inRequest.getParameter("application_form_fee").trim().length() == 0 )
      outEesAdmReqTabObj.application_form_fee = 0;
    else
      outEesAdmReqTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee"));
    outEesAdmReqTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session");
    outEesAdmReqTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date");
    outEesAdmReqTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start");
    outEesAdmReqTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end");
    outEesAdmReqTabObj.exam_present_status = inRequest.getParameter("exam_present_status");
    outEesAdmReqTabObj.building_id = inRequest.getParameter("building_id");
    outEesAdmReqTabObj.floor_num = inRequest.getParameter("floor_num");
    outEesAdmReqTabObj.room_num = inRequest.getParameter("room_num");
    if ( inRequest.getParameter("max_mark") == null )
      outEesAdmReqTabObj.max_mark = 0;
    else
    if ( inRequest.getParameter("max_mark").trim().length() == 0 )
      outEesAdmReqTabObj.max_mark = 0;
    else
      outEesAdmReqTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark"));
    if ( inRequest.getParameter("obtained_mark") == null )
      outEesAdmReqTabObj.obtained_mark = 0;
    else
    if ( inRequest.getParameter("obtained_mark").trim().length() == 0 )
      outEesAdmReqTabObj.obtained_mark = 0;
    else
      outEesAdmReqTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark"));
    outEesAdmReqTabObj.grade = inRequest.getParameter("grade");
    outEesAdmReqTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date");
    outEesAdmReqTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date");
    outEesAdmReqTabObj.online_flag = inRequest.getParameter("online_flag");
    outEesAdmReqTabObj.admission_mode = inRequest.getParameter("admission_mode");
    outEesAdmReqTabObj.course_stream_1 = inRequest.getParameter("course_stream_1");
    outEesAdmReqTabObj.course_stream_2 = inRequest.getParameter("course_stream_2");
    outEesAdmReqTabObj.course_stream_3 = inRequest.getParameter("course_stream_3");
    outEesAdmReqTabObj.course_stream_4 = inRequest.getParameter("course_stream_4");
    outEesAdmReqTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream");
    outEesAdmReqTabObj.unv_1 = inRequest.getParameter("unv_1");
    outEesAdmReqTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1");
    outEesAdmReqTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1");
    outEesAdmReqTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1");
    outEesAdmReqTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1");
    outEesAdmReqTabObj.yoa_1 = inRequest.getParameter("yoa_1");
    outEesAdmReqTabObj.unv_2 = inRequest.getParameter("unv_2");
    outEesAdmReqTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2");
    outEesAdmReqTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2");
    outEesAdmReqTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2");
    outEesAdmReqTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2");
    outEesAdmReqTabObj.yoa_2 = inRequest.getParameter("yoa_2");
    if ( inRequest.getParameter("prev_mark_percent") == null )
      outEesAdmReqTabObj.prev_mark_percent = 0;
    else
    if ( inRequest.getParameter("prev_mark_percent").trim().length() == 0 )
      outEesAdmReqTabObj.prev_mark_percent = 0;
    else
      outEesAdmReqTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent"));
    outEesAdmReqTabObj.domecile_ind = inRequest.getParameter("domecile_ind");
    outEesAdmReqTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind");
    outEesAdmReqTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind");
    outEesAdmReqTabObj.cheque_num = inRequest.getParameter("cheque_num");
    outEesAdmReqTabObj.cheque_date = inRequest.getParameter("cheque_date");
    outEesAdmReqTabObj.bank_code = inRequest.getParameter("bank_code");
    outEesAdmReqTabObj.bank_name = inRequest.getParameter("bank_name");
    if ( inRequest.getParameter("cheque_amt") == null )
      outEesAdmReqTabObj.cheque_amt = 0;
    else
    if ( inRequest.getParameter("cheque_amt").trim().length() == 0 )
      outEesAdmReqTabObj.cheque_amt = 0;
    else
      outEesAdmReqTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt"));
    outEesAdmReqTabObj.lg_0_name = inRequest.getParameter("lg_0_name");
    outEesAdmReqTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type");
    outEesAdmReqTabObj.lg_0_address = inRequest.getParameter("lg_0_address");
    outEesAdmReqTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone");
    outEesAdmReqTabObj.lg_1_name = inRequest.getParameter("lg_1_name");
    outEesAdmReqTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type");
    outEesAdmReqTabObj.lg_1_address = inRequest.getParameter("lg_1_address");
    outEesAdmReqTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone");
    outEesAdmReqTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1");
    outEesAdmReqTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2");
    outEesAdmReqTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3");
    outEesAdmReqTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4");
    outEesAdmReqTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5");
    outEesAdmReqTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6");
    outEesAdmReqTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7");
    outEesAdmReqTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8");
    outEesAdmReqTabObj.allergy = inRequest.getParameter("allergy");
    outEesAdmReqTabObj.physical_disability = inRequest.getParameter("physical_disability");
    outEesAdmReqTabObj.health_problem = inRequest.getParameter("health_problem");
    outEesAdmReqTabObj.health_problem_1 = inRequest.getParameter("health_problem_1");
    outEesAdmReqTabObj.health_problem_2 = inRequest.getParameter("health_problem_2");
    outEesAdmReqTabObj.health_problem_3 = inRequest.getParameter("health_problem_3");
    outEesAdmReqTabObj.health_problem_4 = inRequest.getParameter("health_problem_4");
    outEesAdmReqTabObj.health_problem_5 = inRequest.getParameter("health_problem_5");
    outEesAdmReqTabObj.health_problem_6 = inRequest.getParameter("health_problem_6");
    outEesAdmReqTabObj.health_problem_7 = inRequest.getParameter("health_problem_7");
    outEesAdmReqTabObj.health_problem_8 = inRequest.getParameter("health_problem_8");
    outEesAdmReqTabObj.health_problem_9 = inRequest.getParameter("health_problem_9");
    outEesAdmReqTabObj.health_problem_10 = inRequest.getParameter("health_problem_10");
    outEesAdmReqTabObj.health_problem_11 = inRequest.getParameter("health_problem_11");
    outEesAdmReqTabObj.health_problem_12 = inRequest.getParameter("health_problem_12");
    outEesAdmReqTabObj.enclosure_1 = inRequest.getParameter("enclosure_1");
    outEesAdmReqTabObj.enclosure_2 = inRequest.getParameter("enclosure_2");
    outEesAdmReqTabObj.enclosure_3 = inRequest.getParameter("enclosure_3");
    outEesAdmReqTabObj.enclosure_4 = inRequest.getParameter("enclosure_4");
    outEesAdmReqTabObj.enclosure_5 = inRequest.getParameter("enclosure_5");
    outEesAdmReqTabObj.enclosure_6 = inRequest.getParameter("enclosure_6");
    outEesAdmReqTabObj.enclosure_7 = inRequest.getParameter("enclosure_7");
    outEesAdmReqTabObj.enclosure_8 = inRequest.getParameter("enclosure_8");
    if ( inRequest.getParameter("seat_num") == null )
      outEesAdmReqTabObj.seat_num = 0;
    else
    if ( inRequest.getParameter("seat_num").trim().length() == 0 )
      outEesAdmReqTabObj.seat_num = 0;
    else
      outEesAdmReqTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num"));
    outEesAdmReqTabObj.reason_for_join = inRequest.getParameter("reason_for_join");
    outEesAdmReqTabObj.remark = inRequest.getParameter("remark");
    outEesAdmReqTabObj.place_of_birth = inRequest.getParameter("place_of_birth");
    if ( inRequest.getParameter("adv_adm_fee") == null )
      outEesAdmReqTabObj.adv_adm_fee = 0;
    else
    if ( inRequest.getParameter("adv_adm_fee").trim().length() == 0 )
      outEesAdmReqTabObj.adv_adm_fee = 0;
    else
      outEesAdmReqTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee"));
    outEesAdmReqTabObj.payment_mode = inRequest.getParameter("payment_mode");
    outEesAdmReqTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id");
    outEesAdmReqTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req");
    outEesAdmReqTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list");
    return lReturnValue;
  }


  public int popEesAdmReqReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAdmReqTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAdmReqTabObj lEesAdmReqTabObj= new EesAdmReqTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAdmReqTabObj.tab_rowid = lTabRowidValue;

      lEesAdmReqTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesAdmReqTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
      lEesAdmReqTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
      lEesAdmReqTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
      lEesAdmReqTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
      lEesAdmReqTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
      lEesAdmReqTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
      lEesAdmReqTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
      lEesAdmReqTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
      lEesAdmReqTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
      lEesAdmReqTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
      lEesAdmReqTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
      lEesAdmReqTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
      lEesAdmReqTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
      lEesAdmReqTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
      lEesAdmReqTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
      lEesAdmReqTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
      lEesAdmReqTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
      lEesAdmReqTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
      lEesAdmReqTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
      if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
        lEesAdmReqTabObj.age_year = 0;
      else
      if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.age_year = 0;
      else
        lEesAdmReqTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
      lEesAdmReqTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
      if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
        lEesAdmReqTabObj.age_day = 0;
      else
      if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.age_day = 0;
      else
        lEesAdmReqTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
      lEesAdmReqTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
      lEesAdmReqTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
      lEesAdmReqTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
      lEesAdmReqTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
      lEesAdmReqTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
      lEesAdmReqTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
      lEesAdmReqTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
      lEesAdmReqTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
      lEesAdmReqTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
      lEesAdmReqTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
      lEesAdmReqTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
      lEesAdmReqTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
      lEesAdmReqTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
      lEesAdmReqTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
      lEesAdmReqTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
      lEesAdmReqTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
      lEesAdmReqTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
      lEesAdmReqTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
      lEesAdmReqTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
      lEesAdmReqTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
      lEesAdmReqTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      lEesAdmReqTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
      lEesAdmReqTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
      lEesAdmReqTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
      lEesAdmReqTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
      lEesAdmReqTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
      lEesAdmReqTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
      lEesAdmReqTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
      lEesAdmReqTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
      lEesAdmReqTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
      lEesAdmReqTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
      if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
        lEesAdmReqTabObj.father_age = 0;
      else
      if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.father_age = 0;
      else
        lEesAdmReqTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
      lEesAdmReqTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
      lEesAdmReqTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
      lEesAdmReqTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
      lEesAdmReqTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
      if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
        lEesAdmReqTabObj.father_annual_income = 0;
      else
      if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.father_annual_income = 0;
      else
        lEesAdmReqTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
      lEesAdmReqTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
      lEesAdmReqTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
      lEesAdmReqTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
      if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
        lEesAdmReqTabObj.mother_age = 0;
      else
      if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.mother_age = 0;
      else
        lEesAdmReqTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
      lEesAdmReqTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
      lEesAdmReqTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
      lEesAdmReqTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
      lEesAdmReqTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
      if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
        lEesAdmReqTabObj.mother_annual_income = 0;
      else
      if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.mother_annual_income = 0;
      else
        lEesAdmReqTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
      lEesAdmReqTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
      lEesAdmReqTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
      lEesAdmReqTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
      lEesAdmReqTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
      lEesAdmReqTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
      lEesAdmReqTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
      lEesAdmReqTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
      lEesAdmReqTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
      lEesAdmReqTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
      lEesAdmReqTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
      lEesAdmReqTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
      lEesAdmReqTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
      lEesAdmReqTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
      lEesAdmReqTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
      lEesAdmReqTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
      if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
        lEesAdmReqTabObj.application_form_fee = 0;
      else
      if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.application_form_fee = 0;
      else
        lEesAdmReqTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
      lEesAdmReqTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
      lEesAdmReqTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
      lEesAdmReqTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
      lEesAdmReqTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
      lEesAdmReqTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
      lEesAdmReqTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
      lEesAdmReqTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
      lEesAdmReqTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
      if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
        lEesAdmReqTabObj.max_mark = 0;
      else
      if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.max_mark = 0;
      else
        lEesAdmReqTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
      if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
        lEesAdmReqTabObj.obtained_mark = 0;
      else
      if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.obtained_mark = 0;
      else
        lEesAdmReqTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
      lEesAdmReqTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
      lEesAdmReqTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
      lEesAdmReqTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
      lEesAdmReqTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
      lEesAdmReqTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
      lEesAdmReqTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
      lEesAdmReqTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
      lEesAdmReqTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
      lEesAdmReqTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
      lEesAdmReqTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
      lEesAdmReqTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
      lEesAdmReqTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
      lEesAdmReqTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
      lEesAdmReqTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
      lEesAdmReqTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
      lEesAdmReqTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
      lEesAdmReqTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
      lEesAdmReqTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
      lEesAdmReqTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
      lEesAdmReqTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
      lEesAdmReqTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
      lEesAdmReqTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
      if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
        lEesAdmReqTabObj.prev_mark_percent = 0;
      else
      if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.prev_mark_percent = 0;
      else
        lEesAdmReqTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
      lEesAdmReqTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
      lEesAdmReqTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
      lEesAdmReqTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
      lEesAdmReqTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
      lEesAdmReqTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
      lEesAdmReqTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
      lEesAdmReqTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
      if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
        lEesAdmReqTabObj.cheque_amt = 0;
      else
      if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.cheque_amt = 0;
      else
        lEesAdmReqTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
      lEesAdmReqTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
      lEesAdmReqTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
      lEesAdmReqTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
      lEesAdmReqTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
      lEesAdmReqTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
      lEesAdmReqTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
      lEesAdmReqTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
      lEesAdmReqTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
      lEesAdmReqTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
      lEesAdmReqTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
      lEesAdmReqTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
      lEesAdmReqTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
      lEesAdmReqTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
      lEesAdmReqTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
      if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
        lEesAdmReqTabObj.seat_num = 0;
      else
      if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.seat_num = 0;
      else
        lEesAdmReqTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
      lEesAdmReqTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
      lEesAdmReqTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      lEesAdmReqTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
      if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
        lEesAdmReqTabObj.adv_adm_fee = 0;
      else
      if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
        lEesAdmReqTabObj.adv_adm_fee = 0;
      else
        lEesAdmReqTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
      lEesAdmReqTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
      lEesAdmReqTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
      lEesAdmReqTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
      lEesAdmReqTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      outEesAdmReqTabObjArr.add( lEesAdmReqTabObj);
    }
    return lReturnValue;
  }


  public int popEesAdmReqReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesAdmReqTabObj outEesAdmReqTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_adm_req_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesAdmReqTabObj.tab_rowid = lTabRowidValue;

        outEesAdmReqTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesAdmReqTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
        outEesAdmReqTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
        outEesAdmReqTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        outEesAdmReqTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
        outEesAdmReqTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
        outEesAdmReqTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
        outEesAdmReqTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        outEesAdmReqTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        outEesAdmReqTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        outEesAdmReqTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        outEesAdmReqTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        outEesAdmReqTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        outEesAdmReqTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        outEesAdmReqTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        outEesAdmReqTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
        outEesAdmReqTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
        outEesAdmReqTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
        outEesAdmReqTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        outEesAdmReqTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
        if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
          outEesAdmReqTabObj.age_year = 0;
        else
        if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.age_year = 0;
        else
          outEesAdmReqTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
        outEesAdmReqTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
        if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
          outEesAdmReqTabObj.age_day = 0;
        else
        if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.age_day = 0;
        else
          outEesAdmReqTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
        outEesAdmReqTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
        outEesAdmReqTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
        outEesAdmReqTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        outEesAdmReqTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        outEesAdmReqTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        outEesAdmReqTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        outEesAdmReqTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        outEesAdmReqTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        outEesAdmReqTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        outEesAdmReqTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
        outEesAdmReqTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        outEesAdmReqTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        outEesAdmReqTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        outEesAdmReqTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        outEesAdmReqTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        outEesAdmReqTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        outEesAdmReqTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
        outEesAdmReqTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        outEesAdmReqTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        outEesAdmReqTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        outEesAdmReqTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        outEesAdmReqTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
        outEesAdmReqTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        outEesAdmReqTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        outEesAdmReqTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        outEesAdmReqTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        outEesAdmReqTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        outEesAdmReqTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        outEesAdmReqTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        outEesAdmReqTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
        outEesAdmReqTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
          outEesAdmReqTabObj.father_age = 0;
        else
        if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.father_age = 0;
        else
          outEesAdmReqTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
        outEesAdmReqTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
        outEesAdmReqTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
        outEesAdmReqTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
        outEesAdmReqTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
          outEesAdmReqTabObj.father_annual_income = 0;
        else
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.father_annual_income = 0;
        else
          outEesAdmReqTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
        outEesAdmReqTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
        outEesAdmReqTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
        outEesAdmReqTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
          outEesAdmReqTabObj.mother_age = 0;
        else
        if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.mother_age = 0;
        else
          outEesAdmReqTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
        outEesAdmReqTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
        outEesAdmReqTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
        outEesAdmReqTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
        outEesAdmReqTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
          outEesAdmReqTabObj.mother_annual_income = 0;
        else
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.mother_annual_income = 0;
        else
          outEesAdmReqTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
        outEesAdmReqTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
        outEesAdmReqTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
        outEesAdmReqTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
        outEesAdmReqTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
        outEesAdmReqTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        outEesAdmReqTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        outEesAdmReqTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
        outEesAdmReqTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
        outEesAdmReqTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
        outEesAdmReqTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
        outEesAdmReqTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
        outEesAdmReqTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
        outEesAdmReqTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
        outEesAdmReqTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
        outEesAdmReqTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
          outEesAdmReqTabObj.application_form_fee = 0;
        else
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.application_form_fee = 0;
        else
          outEesAdmReqTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
        outEesAdmReqTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
        outEesAdmReqTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
        outEesAdmReqTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
        outEesAdmReqTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
        outEesAdmReqTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
        outEesAdmReqTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        outEesAdmReqTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        outEesAdmReqTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
          outEesAdmReqTabObj.max_mark = 0;
        else
        if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.max_mark = 0;
        else
          outEesAdmReqTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
          outEesAdmReqTabObj.obtained_mark = 0;
        else
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.obtained_mark = 0;
        else
          outEesAdmReqTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
        outEesAdmReqTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
        outEesAdmReqTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
        outEesAdmReqTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
        outEesAdmReqTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
        outEesAdmReqTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
        outEesAdmReqTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
        outEesAdmReqTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
        outEesAdmReqTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
        outEesAdmReqTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
        outEesAdmReqTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
        outEesAdmReqTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
        outEesAdmReqTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
        outEesAdmReqTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
        outEesAdmReqTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
        outEesAdmReqTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
        outEesAdmReqTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
        outEesAdmReqTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
        outEesAdmReqTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
        outEesAdmReqTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
        outEesAdmReqTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
        outEesAdmReqTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
        outEesAdmReqTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
          outEesAdmReqTabObj.prev_mark_percent = 0;
        else
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.prev_mark_percent = 0;
        else
          outEesAdmReqTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
        outEesAdmReqTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
        outEesAdmReqTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
        outEesAdmReqTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
        outEesAdmReqTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
        outEesAdmReqTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
        outEesAdmReqTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
        outEesAdmReqTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
          outEesAdmReqTabObj.cheque_amt = 0;
        else
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.cheque_amt = 0;
        else
          outEesAdmReqTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
        outEesAdmReqTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
        outEesAdmReqTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
        outEesAdmReqTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
        outEesAdmReqTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
        outEesAdmReqTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
        outEesAdmReqTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
        outEesAdmReqTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
        outEesAdmReqTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
        outEesAdmReqTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
        outEesAdmReqTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
        outEesAdmReqTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
        outEesAdmReqTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
        outEesAdmReqTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
        outEesAdmReqTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
        if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
          outEesAdmReqTabObj.seat_num = 0;
        else
        if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.seat_num = 0;
        else
          outEesAdmReqTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
        outEesAdmReqTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
        outEesAdmReqTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        outEesAdmReqTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
          outEesAdmReqTabObj.adv_adm_fee = 0;
        else
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
          outEesAdmReqTabObj.adv_adm_fee = 0;
        else
          outEesAdmReqTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
        outEesAdmReqTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
        outEesAdmReqTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
        outEesAdmReqTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        outEesAdmReqTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesAdmReqReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAdmReqTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAdmReqTabObj lEesAdmReqTabObj= new EesAdmReqTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_adm_req_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAdmReqTabObj.tab_rowid = lTabRowidValue;

        lEesAdmReqTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesAdmReqTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
        lEesAdmReqTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
        lEesAdmReqTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        lEesAdmReqTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
        lEesAdmReqTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
        lEesAdmReqTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
        lEesAdmReqTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        lEesAdmReqTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        lEesAdmReqTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        lEesAdmReqTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        lEesAdmReqTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        lEesAdmReqTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        lEesAdmReqTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        lEesAdmReqTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        lEesAdmReqTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
        lEesAdmReqTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
        lEesAdmReqTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
        lEesAdmReqTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        lEesAdmReqTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
        if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
          lEesAdmReqTabObj.age_year = 0;
        else
        if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.age_year = 0;
        else
          lEesAdmReqTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
        lEesAdmReqTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
        if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
          lEesAdmReqTabObj.age_day = 0;
        else
        if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.age_day = 0;
        else
          lEesAdmReqTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
        lEesAdmReqTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
        lEesAdmReqTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
        lEesAdmReqTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        lEesAdmReqTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        lEesAdmReqTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        lEesAdmReqTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        lEesAdmReqTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        lEesAdmReqTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        lEesAdmReqTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        lEesAdmReqTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
        lEesAdmReqTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        lEesAdmReqTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        lEesAdmReqTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        lEesAdmReqTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        lEesAdmReqTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        lEesAdmReqTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        lEesAdmReqTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
        lEesAdmReqTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        lEesAdmReqTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        lEesAdmReqTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        lEesAdmReqTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        lEesAdmReqTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
        lEesAdmReqTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        lEesAdmReqTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        lEesAdmReqTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        lEesAdmReqTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        lEesAdmReqTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        lEesAdmReqTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        lEesAdmReqTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        lEesAdmReqTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
        lEesAdmReqTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
          lEesAdmReqTabObj.father_age = 0;
        else
        if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.father_age = 0;
        else
          lEesAdmReqTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
        lEesAdmReqTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
        lEesAdmReqTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
        lEesAdmReqTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
        lEesAdmReqTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
          lEesAdmReqTabObj.father_annual_income = 0;
        else
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.father_annual_income = 0;
        else
            lEesAdmReqTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
        lEesAdmReqTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
        lEesAdmReqTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
        lEesAdmReqTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
          lEesAdmReqTabObj.mother_age = 0;
        else
        if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.mother_age = 0;
        else
          lEesAdmReqTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
        lEesAdmReqTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
        lEesAdmReqTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
        lEesAdmReqTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
        lEesAdmReqTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
          lEesAdmReqTabObj.mother_annual_income = 0;
        else
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.mother_annual_income = 0;
        else
            lEesAdmReqTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
        lEesAdmReqTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
        lEesAdmReqTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
        lEesAdmReqTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
        lEesAdmReqTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
        lEesAdmReqTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        lEesAdmReqTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        lEesAdmReqTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
        lEesAdmReqTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
        lEesAdmReqTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
        lEesAdmReqTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
        lEesAdmReqTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
        lEesAdmReqTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
        lEesAdmReqTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
        lEesAdmReqTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
        lEesAdmReqTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
          lEesAdmReqTabObj.application_form_fee = 0;
        else
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.application_form_fee = 0;
        else
            lEesAdmReqTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
        lEesAdmReqTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
        lEesAdmReqTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
        lEesAdmReqTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
        lEesAdmReqTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
        lEesAdmReqTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
        lEesAdmReqTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        lEesAdmReqTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        lEesAdmReqTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
          lEesAdmReqTabObj.max_mark = 0;
        else
        if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.max_mark = 0;
        else
          lEesAdmReqTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
          lEesAdmReqTabObj.obtained_mark = 0;
        else
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.obtained_mark = 0;
        else
          lEesAdmReqTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
        lEesAdmReqTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
        lEesAdmReqTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
        lEesAdmReqTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
        lEesAdmReqTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
        lEesAdmReqTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
        lEesAdmReqTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
        lEesAdmReqTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
        lEesAdmReqTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
        lEesAdmReqTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
        lEesAdmReqTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
        lEesAdmReqTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
        lEesAdmReqTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
        lEesAdmReqTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
        lEesAdmReqTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
        lEesAdmReqTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
        lEesAdmReqTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
        lEesAdmReqTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
        lEesAdmReqTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
        lEesAdmReqTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
        lEesAdmReqTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
        lEesAdmReqTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
        lEesAdmReqTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
          lEesAdmReqTabObj.prev_mark_percent = 0;
        else
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.prev_mark_percent = 0;
        else
            lEesAdmReqTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
        lEesAdmReqTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
        lEesAdmReqTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
        lEesAdmReqTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
        lEesAdmReqTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
        lEesAdmReqTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
        lEesAdmReqTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
        lEesAdmReqTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
          lEesAdmReqTabObj.cheque_amt = 0;
        else
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.cheque_amt = 0;
        else
            lEesAdmReqTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
        lEesAdmReqTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
        lEesAdmReqTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
        lEesAdmReqTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
        lEesAdmReqTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
        lEesAdmReqTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
        lEesAdmReqTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
        lEesAdmReqTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
        lEesAdmReqTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
        lEesAdmReqTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
        lEesAdmReqTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
        lEesAdmReqTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
        lEesAdmReqTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
        lEesAdmReqTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
        lEesAdmReqTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
        if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
          lEesAdmReqTabObj.seat_num = 0;
        else
        if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.seat_num = 0;
        else
          lEesAdmReqTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
        lEesAdmReqTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
        lEesAdmReqTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        lEesAdmReqTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
          lEesAdmReqTabObj.adv_adm_fee = 0;
        else
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
          lEesAdmReqTabObj.adv_adm_fee = 0;
        else
            lEesAdmReqTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
        lEesAdmReqTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
        lEesAdmReqTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
        lEesAdmReqTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        lEesAdmReqTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
        outEesAdmReqTabObjArr.add( lEesAdmReqTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesAdmReqRecByRowid
               ( String inRowId
               , EesAdmReqTabObj  inEesAdmReqTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAdmReqRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmReqRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmReqTabObj.dob != null && inEesAdmReqTabObj.dob.length() > 0 ) 
            inEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.age_on_date != null && inEesAdmReqTabObj.age_on_date.length() > 0 ) 
            inEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.adm_req_sts_date != null && inEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.form_recv_date != null && inEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            inEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.prospectus_sale_date != null && inEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.entrance_exam_date != null && inEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_sch_date != null && inEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_deposit_date != null && inEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.cheque_date != null && inEesAdmReqTabObj.cheque_date.length() > 0 ) 
            inEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.cheque_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_REQ ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesAdmReqTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAdmReqTabObj.org_id+"', ";
      if ( inEesAdmReqTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = "+"'"+inEesAdmReqTabObj.adm_req_id+"', ";
      if ( inEesAdmReqTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = "+"'"+inEesAdmReqTabObj.application_form_num+"', ";
      if ( inEesAdmReqTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAdmReqTabObj.applicant_id+"', ";
      if ( inEesAdmReqTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = "+"'"+inEesAdmReqTabObj.student_photo_file+"', ";
      if ( inEesAdmReqTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = "+"'"+inEesAdmReqTabObj.mother_photo_file+"', ";
      if ( inEesAdmReqTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = "+"'"+inEesAdmReqTabObj.father_photo_file+"', ";
      if ( inEesAdmReqTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAdmReqTabObj.class_id+"', ";
      if ( inEesAdmReqTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAdmReqTabObj.class_num+"', ";
      if ( inEesAdmReqTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAdmReqTabObj.class_std+"', ";
      if ( inEesAdmReqTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAdmReqTabObj.class_section+"', ";
      if ( inEesAdmReqTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAdmReqTabObj.course_id+"', ";
      if ( inEesAdmReqTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAdmReqTabObj.course_term+"', ";
      if ( inEesAdmReqTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAdmReqTabObj.course_stream+"', ";
      if ( inEesAdmReqTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inEesAdmReqTabObj.name_initials+"', ";
      if ( inEesAdmReqTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = "+"'"+inEesAdmReqTabObj.student_f_name+"', ";
      if ( inEesAdmReqTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = "+"'"+inEesAdmReqTabObj.student_m_name+"', ";
      if ( inEesAdmReqTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = "+"'"+inEesAdmReqTabObj.student_l_name+"', ";
      if ( inEesAdmReqTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAdmReqTabObj.dob+"', ";
      if ( inEesAdmReqTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = "+"'"+inEesAdmReqTabObj.age_on_date+"', ";
             lSqlStmt = lSqlStmt + "age_year = "+inEesAdmReqTabObj.age_year+", ";
      if ( inEesAdmReqTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = "+"'"+inEesAdmReqTabObj.age_month+"', ";
             lSqlStmt = lSqlStmt + "age_day = "+inEesAdmReqTabObj.age_day+", ";
      if ( inEesAdmReqTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = "+"'"+inEesAdmReqTabObj.s_nationality+"', ";
      if ( inEesAdmReqTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = "+"'"+inEesAdmReqTabObj.religion+"', ";
      if ( inEesAdmReqTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAdmReqTabObj.student_ctg+"', ";
      if ( inEesAdmReqTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAdmReqTabObj.gender_flag+"', ";
      if ( inEesAdmReqTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inEesAdmReqTabObj.p_address_1+"', ";
      if ( inEesAdmReqTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inEesAdmReqTabObj.p_address_2+"', ";
      if ( inEesAdmReqTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inEesAdmReqTabObj.p_country+"', ";
      if ( inEesAdmReqTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inEesAdmReqTabObj.p_state+"', ";
      if ( inEesAdmReqTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inEesAdmReqTabObj.p_city+"', ";
      if ( inEesAdmReqTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = "+"'"+inEesAdmReqTabObj.p_district+"', ";
      if ( inEesAdmReqTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inEesAdmReqTabObj.p_zip+"', ";
      if ( inEesAdmReqTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inEesAdmReqTabObj.m_address_1+"', ";
      if ( inEesAdmReqTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inEesAdmReqTabObj.m_address_2+"', ";
      if ( inEesAdmReqTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inEesAdmReqTabObj.m_country+"', ";
      if ( inEesAdmReqTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inEesAdmReqTabObj.m_state+"', ";
      if ( inEesAdmReqTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inEesAdmReqTabObj.m_city+"', ";
      if ( inEesAdmReqTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = "+"'"+inEesAdmReqTabObj.m_district+"', ";
      if ( inEesAdmReqTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inEesAdmReqTabObj.m_zip+"', ";
      if ( inEesAdmReqTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAdmReqTabObj.phone_list+"', ";
      if ( inEesAdmReqTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAdmReqTabObj.email_list+"', ";
      if ( inEesAdmReqTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAdmReqTabObj.fax_list+"', ";
      if ( inEesAdmReqTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = "+"'"+inEesAdmReqTabObj.prev_org_name+"', ";
      if ( inEesAdmReqTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAdmReqTabObj.prev_class_id+"', ";
      if ( inEesAdmReqTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAdmReqTabObj.prev_class_num+"', ";
      if ( inEesAdmReqTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAdmReqTabObj.prev_class_std+"', ";
      if ( inEesAdmReqTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAdmReqTabObj.prev_class_section+"', ";
      if ( inEesAdmReqTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAdmReqTabObj.prev_course_id+"', ";
      if ( inEesAdmReqTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAdmReqTabObj.prev_course_term+"', ";
      if ( inEesAdmReqTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAdmReqTabObj.prev_course_stream+"', ";
      if ( inEesAdmReqTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = "+"'"+inEesAdmReqTabObj.reason_for_leaving+"', ";
      if ( inEesAdmReqTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAdmReqTabObj.father_name+"', ";
             lSqlStmt = lSqlStmt + "father_age = "+inEesAdmReqTabObj.father_age+", ";
      if ( inEesAdmReqTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = "+"'"+inEesAdmReqTabObj.f_nationality+"', ";
      if ( inEesAdmReqTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = "+"'"+inEesAdmReqTabObj.father_occ_type+"', ";
      if ( inEesAdmReqTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = "+"'"+inEesAdmReqTabObj.father_employer+"', ";
      if ( inEesAdmReqTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = "+"'"+inEesAdmReqTabObj.father_designation+"', ";
             lSqlStmt = lSqlStmt + "father_annual_income = "+inEesAdmReqTabObj.father_annual_income+", ";
      if ( inEesAdmReqTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = "+"'"+inEesAdmReqTabObj.f_off_address_1+"', ";
      if ( inEesAdmReqTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = "+"'"+inEesAdmReqTabObj.f_phone_list+"', ";
      if ( inEesAdmReqTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAdmReqTabObj.mother_name+"', ";
             lSqlStmt = lSqlStmt + "mother_age = "+inEesAdmReqTabObj.mother_age+", ";
      if ( inEesAdmReqTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = "+"'"+inEesAdmReqTabObj.m_nationality+"', ";
      if ( inEesAdmReqTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = "+"'"+inEesAdmReqTabObj.mother_occ_type+"', ";
      if ( inEesAdmReqTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = "+"'"+inEesAdmReqTabObj.mother_employer+"', ";
      if ( inEesAdmReqTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = "+"'"+inEesAdmReqTabObj.mother_designation+"', ";
             lSqlStmt = lSqlStmt + "mother_annual_income = "+inEesAdmReqTabObj.mother_annual_income+", ";
      if ( inEesAdmReqTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = "+"'"+inEesAdmReqTabObj.m_off_address_1+"', ";
      if ( inEesAdmReqTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = "+"'"+inEesAdmReqTabObj.m_phone_list+"', ";
      if ( inEesAdmReqTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = "+"'"+inEesAdmReqTabObj.divorced_flag+"', ";
      if ( inEesAdmReqTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = "+"'"+inEesAdmReqTabObj.child_with+"', ";
      if ( inEesAdmReqTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAdmReqTabObj.roll_num+"', ";
      if ( inEesAdmReqTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesAdmReqTabObj.academic_session+"', ";
      if ( inEesAdmReqTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = "+"'"+inEesAdmReqTabObj.adm_req_sts+"', ";
      if ( inEesAdmReqTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = "+"'"+inEesAdmReqTabObj.adm_req_sts_date+"', ";
      if ( inEesAdmReqTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = "+"'"+inEesAdmReqTabObj.student_id+"', ";
      if ( inEesAdmReqTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = "+"'"+inEesAdmReqTabObj.scholor_num+"', ";
      if ( inEesAdmReqTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = "+"'"+inEesAdmReqTabObj.form_recv_date+"', ";
      if ( inEesAdmReqTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = "+"'"+inEesAdmReqTabObj.form_recv_time+"', ";
      if ( inEesAdmReqTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = "+"'"+inEesAdmReqTabObj.prospectus_sale_date+"', ";
      if ( inEesAdmReqTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = "+"'"+inEesAdmReqTabObj.prospectus_sale_time+"', ";
      if ( inEesAdmReqTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = "+"'"+inEesAdmReqTabObj.prospectus_sold_by+"', ";
             lSqlStmt = lSqlStmt + "application_form_fee = "+inEesAdmReqTabObj.application_form_fee+", ";
      if ( inEesAdmReqTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = "+"'"+inEesAdmReqTabObj.adm_academic_session+"', ";
      if ( inEesAdmReqTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = "+"'"+inEesAdmReqTabObj.entrance_exam_date+"', ";
      if ( inEesAdmReqTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = "+"'"+inEesAdmReqTabObj.entrance_exam_time_start+"', ";
      if ( inEesAdmReqTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = "+"'"+inEesAdmReqTabObj.entrance_exam_time_end+"', ";
      if ( inEesAdmReqTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = "+"'"+inEesAdmReqTabObj.exam_present_status+"', ";
      if ( inEesAdmReqTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inEesAdmReqTabObj.building_id+"', ";
      if ( inEesAdmReqTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inEesAdmReqTabObj.floor_num+"', ";
      if ( inEesAdmReqTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inEesAdmReqTabObj.room_num+"', ";
             lSqlStmt = lSqlStmt + "max_mark = "+inEesAdmReqTabObj.max_mark+", ";
             lSqlStmt = lSqlStmt + "obtained_mark = "+inEesAdmReqTabObj.obtained_mark+", ";
      if ( inEesAdmReqTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = "+"'"+inEesAdmReqTabObj.grade+"', ";
      if ( inEesAdmReqTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = "+"'"+inEesAdmReqTabObj.fee_sch_date+"', ";
      if ( inEesAdmReqTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = "+"'"+inEesAdmReqTabObj.fee_deposit_date+"', ";
      if ( inEesAdmReqTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = "+"'"+inEesAdmReqTabObj.online_flag+"', ";
      if ( inEesAdmReqTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = "+"'"+inEesAdmReqTabObj.admission_mode+"', ";
      if ( inEesAdmReqTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = "+"'"+inEesAdmReqTabObj.course_stream_1+"', ";
      if ( inEesAdmReqTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = "+"'"+inEesAdmReqTabObj.course_stream_2+"', ";
      if ( inEesAdmReqTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = "+"'"+inEesAdmReqTabObj.course_stream_3+"', ";
      if ( inEesAdmReqTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = "+"'"+inEesAdmReqTabObj.course_stream_4+"', ";
      if ( inEesAdmReqTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = "+"'"+inEesAdmReqTabObj.apr_course_stream+"', ";
      if ( inEesAdmReqTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = "+"'"+inEesAdmReqTabObj.unv_1+"', ";
      if ( inEesAdmReqTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = "+"'"+inEesAdmReqTabObj.unv_rn_1+"', ";
      if ( inEesAdmReqTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = "+"'"+inEesAdmReqTabObj.gen_rank_1+"', ";
      if ( inEesAdmReqTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = "+"'"+inEesAdmReqTabObj.ctg_rank_1+"', ";
      if ( inEesAdmReqTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = "+"'"+inEesAdmReqTabObj.stt_rank_1+"', ";
      if ( inEesAdmReqTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = "+"'"+inEesAdmReqTabObj.yoa_1+"', ";
      if ( inEesAdmReqTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = "+"'"+inEesAdmReqTabObj.unv_2+"', ";
      if ( inEesAdmReqTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = "+"'"+inEesAdmReqTabObj.unv_rn_2+"', ";
      if ( inEesAdmReqTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = "+"'"+inEesAdmReqTabObj.gen_rank_2+"', ";
      if ( inEesAdmReqTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = "+"'"+inEesAdmReqTabObj.ctg_rank_2+"', ";
      if ( inEesAdmReqTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = "+"'"+inEesAdmReqTabObj.stt_rank_2+"', ";
      if ( inEesAdmReqTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = "+"'"+inEesAdmReqTabObj.yoa_2+"', ";
             lSqlStmt = lSqlStmt + "prev_mark_percent = "+inEesAdmReqTabObj.prev_mark_percent+", ";
      if ( inEesAdmReqTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = "+"'"+inEesAdmReqTabObj.domecile_ind+"', ";
      if ( inEesAdmReqTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = "+"'"+inEesAdmReqTabObj.org_transport_req_ind+"', ";
      if ( inEesAdmReqTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = "+"'"+inEesAdmReqTabObj.org_hostel_req_ind+"', ";
      if ( inEesAdmReqTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = "+"'"+inEesAdmReqTabObj.cheque_num+"', ";
      if ( inEesAdmReqTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = "+"'"+inEesAdmReqTabObj.cheque_date+"', ";
      if ( inEesAdmReqTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = "+"'"+inEesAdmReqTabObj.bank_code+"', ";
      if ( inEesAdmReqTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = "+"'"+inEesAdmReqTabObj.bank_name+"', ";
             lSqlStmt = lSqlStmt + "cheque_amt = "+inEesAdmReqTabObj.cheque_amt+", ";
      if ( inEesAdmReqTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = "+"'"+inEesAdmReqTabObj.lg_0_name+"', ";
      if ( inEesAdmReqTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = "+"'"+inEesAdmReqTabObj.lg_0_rel_type+"', ";
      if ( inEesAdmReqTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = "+"'"+inEesAdmReqTabObj.lg_0_address+"', ";
      if ( inEesAdmReqTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = "+"'"+inEesAdmReqTabObj.lg_0_phone+"', ";
      if ( inEesAdmReqTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = "+"'"+inEesAdmReqTabObj.lg_1_name+"', ";
      if ( inEesAdmReqTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = "+"'"+inEesAdmReqTabObj.lg_1_rel_type+"', ";
      if ( inEesAdmReqTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = "+"'"+inEesAdmReqTabObj.lg_1_address+"', ";
      if ( inEesAdmReqTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = "+"'"+inEesAdmReqTabObj.lg_1_phone+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = "+"'"+inEesAdmReqTabObj.st_cap_attr_1+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = "+"'"+inEesAdmReqTabObj.st_cap_attr_2+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = "+"'"+inEesAdmReqTabObj.st_cap_attr_3+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = "+"'"+inEesAdmReqTabObj.st_cap_attr_4+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = "+"'"+inEesAdmReqTabObj.st_cap_attr_5+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = "+"'"+inEesAdmReqTabObj.st_cap_attr_6+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = "+"'"+inEesAdmReqTabObj.st_cap_attr_7+"', ";
      if ( inEesAdmReqTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = "+"'"+inEesAdmReqTabObj.st_cap_attr_8+"', ";
      if ( inEesAdmReqTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = "+"'"+inEesAdmReqTabObj.allergy+"', ";
      if ( inEesAdmReqTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = "+"'"+inEesAdmReqTabObj.physical_disability+"', ";
      if ( inEesAdmReqTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = "+"'"+inEesAdmReqTabObj.health_problem+"', ";
      if ( inEesAdmReqTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = "+"'"+inEesAdmReqTabObj.health_problem_1+"', ";
      if ( inEesAdmReqTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = "+"'"+inEesAdmReqTabObj.health_problem_2+"', ";
      if ( inEesAdmReqTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = "+"'"+inEesAdmReqTabObj.health_problem_3+"', ";
      if ( inEesAdmReqTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = "+"'"+inEesAdmReqTabObj.health_problem_4+"', ";
      if ( inEesAdmReqTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = "+"'"+inEesAdmReqTabObj.health_problem_5+"', ";
      if ( inEesAdmReqTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = "+"'"+inEesAdmReqTabObj.health_problem_6+"', ";
      if ( inEesAdmReqTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = "+"'"+inEesAdmReqTabObj.health_problem_7+"', ";
      if ( inEesAdmReqTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = "+"'"+inEesAdmReqTabObj.health_problem_8+"', ";
      if ( inEesAdmReqTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = "+"'"+inEesAdmReqTabObj.health_problem_9+"', ";
      if ( inEesAdmReqTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = "+"'"+inEesAdmReqTabObj.health_problem_10+"', ";
      if ( inEesAdmReqTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = "+"'"+inEesAdmReqTabObj.health_problem_11+"', ";
      if ( inEesAdmReqTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = "+"'"+inEesAdmReqTabObj.health_problem_12+"', ";
      if ( inEesAdmReqTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = "+"'"+inEesAdmReqTabObj.enclosure_1+"', ";
      if ( inEesAdmReqTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = "+"'"+inEesAdmReqTabObj.enclosure_2+"', ";
      if ( inEesAdmReqTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = "+"'"+inEesAdmReqTabObj.enclosure_3+"', ";
      if ( inEesAdmReqTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = "+"'"+inEesAdmReqTabObj.enclosure_4+"', ";
      if ( inEesAdmReqTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = "+"'"+inEesAdmReqTabObj.enclosure_5+"', ";
      if ( inEesAdmReqTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = "+"'"+inEesAdmReqTabObj.enclosure_6+"', ";
      if ( inEesAdmReqTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = "+"'"+inEesAdmReqTabObj.enclosure_7+"', ";
      if ( inEesAdmReqTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = "+"'"+inEesAdmReqTabObj.enclosure_8+"', ";
             lSqlStmt = lSqlStmt + "seat_num = "+inEesAdmReqTabObj.seat_num+", ";
      if ( inEesAdmReqTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = "+"'"+inEesAdmReqTabObj.reason_for_join+"', ";
      if ( inEesAdmReqTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inEesAdmReqTabObj.remark+"', ";
      if ( inEesAdmReqTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = "+"'"+inEesAdmReqTabObj.place_of_birth+"', ";
             lSqlStmt = lSqlStmt + "adv_adm_fee = "+inEesAdmReqTabObj.adv_adm_fee+", ";
      if ( inEesAdmReqTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = "+"'"+inEesAdmReqTabObj.payment_mode+"', ";
      if ( inEesAdmReqTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = "+"'"+inEesAdmReqTabObj.target_ptl_user_id+"', ";
      if ( inEesAdmReqTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAdmReqTabObj.adm_req_id_req+"', ";
      if ( inEesAdmReqTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAdmReqTabObj.adm_req_id_list+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmReqRecByPkey
               ( EesAdmReqPkeyObj inEesAdmReqPkeyObj
               , EesAdmReqTabObj  inEesAdmReqTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAdmReqRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmReqRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmReqTabObj.dob != null && inEesAdmReqTabObj.dob.length() > 0 ) 
            inEesAdmReqTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.age_on_date != null && inEesAdmReqTabObj.age_on_date.length() > 0 ) 
            inEesAdmReqTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.adm_req_sts_date != null && inEesAdmReqTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmReqTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.form_recv_date != null && inEesAdmReqTabObj.form_recv_date.length() > 0 ) 
            inEesAdmReqTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.prospectus_sale_date != null && inEesAdmReqTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmReqTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.entrance_exam_date != null && inEesAdmReqTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmReqTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_sch_date != null && inEesAdmReqTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.fee_deposit_date != null && inEesAdmReqTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmReqTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmReqTabObj.cheque_date != null && inEesAdmReqTabObj.cheque_date.length() > 0 ) 
            inEesAdmReqTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmReqTabObj.cheque_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_REQ ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesAdmReqTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesAdmReqTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = ? , ";
        if ( inEesAdmReqTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = ? , ";
        if ( inEesAdmReqTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = ? , ";
        if ( inEesAdmReqTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = ? , ";
        if ( inEesAdmReqTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = ? , ";
        if ( inEesAdmReqTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = ? , ";
        if ( inEesAdmReqTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = ? , ";
        if ( inEesAdmReqTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = ? , ";
        if ( inEesAdmReqTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = ? , ";
        if ( inEesAdmReqTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = ? , ";
        if ( inEesAdmReqTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = ? , ";
        if ( inEesAdmReqTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = ? , ";
        if ( inEesAdmReqTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = ? , ";
        if ( inEesAdmReqTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = ? , ";
        if ( inEesAdmReqTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = ? , ";
        if ( inEesAdmReqTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = ? , ";
        if ( inEesAdmReqTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = ? , ";
        if ( inEesAdmReqTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = ? , ";
        if ( inEesAdmReqTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = ? , ";
               lSqlStmt = lSqlStmt + "age_year = ? , ";
        if ( inEesAdmReqTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = ? , ";
               lSqlStmt = lSqlStmt + "age_day = ? , ";
        if ( inEesAdmReqTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = ? , ";
        if ( inEesAdmReqTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = ? , ";
        if ( inEesAdmReqTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = ? , ";
        if ( inEesAdmReqTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = ? , ";
        if ( inEesAdmReqTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = ? , ";
        if ( inEesAdmReqTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = ? , ";
        if ( inEesAdmReqTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = ? , ";
        if ( inEesAdmReqTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = ? , ";
        if ( inEesAdmReqTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = ? , ";
        if ( inEesAdmReqTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = ? , ";
        if ( inEesAdmReqTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = ? , ";
        if ( inEesAdmReqTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = ? , ";
        if ( inEesAdmReqTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = ? , ";
        if ( inEesAdmReqTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = ? , ";
        if ( inEesAdmReqTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = ? , ";
        if ( inEesAdmReqTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = ? , ";
        if ( inEesAdmReqTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = ? , ";
        if ( inEesAdmReqTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = ? , ";
        if ( inEesAdmReqTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = ? , ";
        if ( inEesAdmReqTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = ? , ";
        if ( inEesAdmReqTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = ? , ";
        if ( inEesAdmReqTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = ? , ";
        if ( inEesAdmReqTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = ? , ";
        if ( inEesAdmReqTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = ? , ";
        if ( inEesAdmReqTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = ? , ";
        if ( inEesAdmReqTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = ? , ";
        if ( inEesAdmReqTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = ? , ";
        if ( inEesAdmReqTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = ? , ";
        if ( inEesAdmReqTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = ? , ";
        if ( inEesAdmReqTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = ? , ";
        if ( inEesAdmReqTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = ? , ";
               lSqlStmt = lSqlStmt + "father_age = ? , ";
        if ( inEesAdmReqTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = ? , ";
        if ( inEesAdmReqTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = ? , ";
        if ( inEesAdmReqTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = ? , ";
        if ( inEesAdmReqTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = ? , ";
               lSqlStmt = lSqlStmt + "father_annual_income = ? , ";
        if ( inEesAdmReqTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = ? , ";
        if ( inEesAdmReqTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = ? , ";
        if ( inEesAdmReqTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = ? , ";
               lSqlStmt = lSqlStmt + "mother_age = ? , ";
        if ( inEesAdmReqTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = ? , ";
        if ( inEesAdmReqTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = ? , ";
        if ( inEesAdmReqTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = ? , ";
        if ( inEesAdmReqTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = ? , ";
               lSqlStmt = lSqlStmt + "mother_annual_income = ? , ";
        if ( inEesAdmReqTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = ? , ";
        if ( inEesAdmReqTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = ? , ";
        if ( inEesAdmReqTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = ? , ";
        if ( inEesAdmReqTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = ? , ";
        if ( inEesAdmReqTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = ? , ";
        if ( inEesAdmReqTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = ? , ";
        if ( inEesAdmReqTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = ? , ";
        if ( inEesAdmReqTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = ? , ";
        if ( inEesAdmReqTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = ? , ";
        if ( inEesAdmReqTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = ? , ";
        if ( inEesAdmReqTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = ? , ";
        if ( inEesAdmReqTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = ? , ";
        if ( inEesAdmReqTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = ? , ";
        if ( inEesAdmReqTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = ? , ";
        if ( inEesAdmReqTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = ? , ";
               lSqlStmt = lSqlStmt + "application_form_fee = ? , ";
        if ( inEesAdmReqTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = ? , ";
        if ( inEesAdmReqTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = ? , ";
        if ( inEesAdmReqTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = ? , ";
        if ( inEesAdmReqTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = ? , ";
        if ( inEesAdmReqTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = ? , ";
        if ( inEesAdmReqTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = ? , ";
        if ( inEesAdmReqTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = ? , ";
        if ( inEesAdmReqTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = ? , ";
               lSqlStmt = lSqlStmt + "max_mark = ? , ";
               lSqlStmt = lSqlStmt + "obtained_mark = ? , ";
        if ( inEesAdmReqTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = ? , ";
        if ( inEesAdmReqTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = ? , ";
        if ( inEesAdmReqTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = ? , ";
        if ( inEesAdmReqTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = ? , ";
        if ( inEesAdmReqTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = ? , ";
        if ( inEesAdmReqTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = ? , ";
        if ( inEesAdmReqTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = ? , ";
        if ( inEesAdmReqTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = ? , ";
        if ( inEesAdmReqTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = ? , ";
        if ( inEesAdmReqTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = ? , ";
        if ( inEesAdmReqTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = ? , ";
        if ( inEesAdmReqTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = ? , ";
        if ( inEesAdmReqTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = ? , ";
        if ( inEesAdmReqTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = ? , ";
        if ( inEesAdmReqTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = ? , ";
        if ( inEesAdmReqTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = ? , ";
        if ( inEesAdmReqTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = ? , ";
        if ( inEesAdmReqTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = ? , ";
        if ( inEesAdmReqTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = ? , ";
        if ( inEesAdmReqTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = ? , ";
        if ( inEesAdmReqTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = ? , ";
        if ( inEesAdmReqTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = ? , ";
               lSqlStmt = lSqlStmt + "prev_mark_percent = ? , ";
        if ( inEesAdmReqTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = ? , ";
        if ( inEesAdmReqTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = ? , ";
        if ( inEesAdmReqTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = ? , ";
        if ( inEesAdmReqTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = ? , ";
        if ( inEesAdmReqTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = ? , ";
        if ( inEesAdmReqTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = ? , ";
        if ( inEesAdmReqTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = ? , ";
               lSqlStmt = lSqlStmt + "cheque_amt = ? , ";
        if ( inEesAdmReqTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = ? , ";
        if ( inEesAdmReqTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = ? , ";
        if ( inEesAdmReqTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = ? , ";
        if ( inEesAdmReqTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = ? , ";
        if ( inEesAdmReqTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = ? , ";
        if ( inEesAdmReqTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = ? , ";
        if ( inEesAdmReqTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = ? , ";
        if ( inEesAdmReqTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = ? , ";
        if ( inEesAdmReqTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = ? , ";
        if ( inEesAdmReqTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = ? , ";
        if ( inEesAdmReqTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = ? , ";
        if ( inEesAdmReqTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = ? , ";
        if ( inEesAdmReqTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = ? , ";
        if ( inEesAdmReqTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = ? , ";
        if ( inEesAdmReqTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = ? , ";
               lSqlStmt = lSqlStmt + "seat_num = ? , ";
        if ( inEesAdmReqTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = ? , ";
        if ( inEesAdmReqTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
        if ( inEesAdmReqTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = ? , ";
               lSqlStmt = lSqlStmt + "adv_adm_fee = ? , ";
        if ( inEesAdmReqTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = ? , ";
        if ( inEesAdmReqTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = ? , ";
        if ( inEesAdmReqTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = ? , ";
        if ( inEesAdmReqTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesAdmReqTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAdmReqTabObj.org_id+"', ";
        if ( inEesAdmReqTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = "+"'"+inEesAdmReqTabObj.adm_req_id+"', ";
        if ( inEesAdmReqTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = "+"'"+inEesAdmReqTabObj.application_form_num+"', ";
        if ( inEesAdmReqTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAdmReqTabObj.applicant_id+"', ";
        if ( inEesAdmReqTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = "+"'"+inEesAdmReqTabObj.student_photo_file+"', ";
        if ( inEesAdmReqTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = "+"'"+inEesAdmReqTabObj.mother_photo_file+"', ";
        if ( inEesAdmReqTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = "+"'"+inEesAdmReqTabObj.father_photo_file+"', ";
        if ( inEesAdmReqTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAdmReqTabObj.class_id+"', ";
        if ( inEesAdmReqTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAdmReqTabObj.class_num+"', ";
        if ( inEesAdmReqTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAdmReqTabObj.class_std+"', ";
        if ( inEesAdmReqTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAdmReqTabObj.class_section+"', ";
        if ( inEesAdmReqTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAdmReqTabObj.course_id+"', ";
        if ( inEesAdmReqTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAdmReqTabObj.course_term+"', ";
        if ( inEesAdmReqTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAdmReqTabObj.course_stream+"', ";
        if ( inEesAdmReqTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inEesAdmReqTabObj.name_initials+"', ";
        if ( inEesAdmReqTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = "+"'"+inEesAdmReqTabObj.student_f_name+"', ";
        if ( inEesAdmReqTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = "+"'"+inEesAdmReqTabObj.student_m_name+"', ";
        if ( inEesAdmReqTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = "+"'"+inEesAdmReqTabObj.student_l_name+"', ";
        if ( inEesAdmReqTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAdmReqTabObj.dob+"', ";
        if ( inEesAdmReqTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = "+"'"+inEesAdmReqTabObj.age_on_date+"', ";
               lSqlStmt = lSqlStmt + "age_year = "+inEesAdmReqTabObj.age_year+", ";
        if ( inEesAdmReqTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = "+"'"+inEesAdmReqTabObj.age_month+"', ";
               lSqlStmt = lSqlStmt + "age_day = "+inEesAdmReqTabObj.age_day+", ";
        if ( inEesAdmReqTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = "+"'"+inEesAdmReqTabObj.s_nationality+"', ";
        if ( inEesAdmReqTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = "+"'"+inEesAdmReqTabObj.religion+"', ";
        if ( inEesAdmReqTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAdmReqTabObj.student_ctg+"', ";
        if ( inEesAdmReqTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAdmReqTabObj.gender_flag+"', ";
        if ( inEesAdmReqTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inEesAdmReqTabObj.p_address_1+"', ";
        if ( inEesAdmReqTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inEesAdmReqTabObj.p_address_2+"', ";
        if ( inEesAdmReqTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inEesAdmReqTabObj.p_country+"', ";
        if ( inEesAdmReqTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inEesAdmReqTabObj.p_state+"', ";
        if ( inEesAdmReqTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inEesAdmReqTabObj.p_city+"', ";
        if ( inEesAdmReqTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = "+"'"+inEesAdmReqTabObj.p_district+"', ";
        if ( inEesAdmReqTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inEesAdmReqTabObj.p_zip+"', ";
        if ( inEesAdmReqTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inEesAdmReqTabObj.m_address_1+"', ";
        if ( inEesAdmReqTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inEesAdmReqTabObj.m_address_2+"', ";
        if ( inEesAdmReqTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inEesAdmReqTabObj.m_country+"', ";
        if ( inEesAdmReqTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inEesAdmReqTabObj.m_state+"', ";
        if ( inEesAdmReqTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inEesAdmReqTabObj.m_city+"', ";
        if ( inEesAdmReqTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = "+"'"+inEesAdmReqTabObj.m_district+"', ";
        if ( inEesAdmReqTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inEesAdmReqTabObj.m_zip+"', ";
        if ( inEesAdmReqTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAdmReqTabObj.phone_list+"', ";
        if ( inEesAdmReqTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAdmReqTabObj.email_list+"', ";
        if ( inEesAdmReqTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAdmReqTabObj.fax_list+"', ";
        if ( inEesAdmReqTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = "+"'"+inEesAdmReqTabObj.prev_org_name+"', ";
        if ( inEesAdmReqTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAdmReqTabObj.prev_class_id+"', ";
        if ( inEesAdmReqTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAdmReqTabObj.prev_class_num+"', ";
        if ( inEesAdmReqTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAdmReqTabObj.prev_class_std+"', ";
        if ( inEesAdmReqTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAdmReqTabObj.prev_class_section+"', ";
        if ( inEesAdmReqTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAdmReqTabObj.prev_course_id+"', ";
        if ( inEesAdmReqTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAdmReqTabObj.prev_course_term+"', ";
        if ( inEesAdmReqTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAdmReqTabObj.prev_course_stream+"', ";
        if ( inEesAdmReqTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = "+"'"+inEesAdmReqTabObj.reason_for_leaving+"', ";
        if ( inEesAdmReqTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAdmReqTabObj.father_name+"', ";
               lSqlStmt = lSqlStmt + "father_age = "+inEesAdmReqTabObj.father_age+", ";
        if ( inEesAdmReqTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = "+"'"+inEesAdmReqTabObj.f_nationality+"', ";
        if ( inEesAdmReqTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = "+"'"+inEesAdmReqTabObj.father_occ_type+"', ";
        if ( inEesAdmReqTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = "+"'"+inEesAdmReqTabObj.father_employer+"', ";
        if ( inEesAdmReqTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = "+"'"+inEesAdmReqTabObj.father_designation+"', ";
               lSqlStmt = lSqlStmt + "father_annual_income = "+inEesAdmReqTabObj.father_annual_income+", ";
        if ( inEesAdmReqTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = "+"'"+inEesAdmReqTabObj.f_off_address_1+"', ";
        if ( inEesAdmReqTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = "+"'"+inEesAdmReqTabObj.f_phone_list+"', ";
        if ( inEesAdmReqTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAdmReqTabObj.mother_name+"', ";
               lSqlStmt = lSqlStmt + "mother_age = "+inEesAdmReqTabObj.mother_age+", ";
        if ( inEesAdmReqTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = "+"'"+inEesAdmReqTabObj.m_nationality+"', ";
        if ( inEesAdmReqTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = "+"'"+inEesAdmReqTabObj.mother_occ_type+"', ";
        if ( inEesAdmReqTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = "+"'"+inEesAdmReqTabObj.mother_employer+"', ";
        if ( inEesAdmReqTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = "+"'"+inEesAdmReqTabObj.mother_designation+"', ";
               lSqlStmt = lSqlStmt + "mother_annual_income = "+inEesAdmReqTabObj.mother_annual_income+", ";
        if ( inEesAdmReqTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = "+"'"+inEesAdmReqTabObj.m_off_address_1+"', ";
        if ( inEesAdmReqTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = "+"'"+inEesAdmReqTabObj.m_phone_list+"', ";
        if ( inEesAdmReqTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = "+"'"+inEesAdmReqTabObj.divorced_flag+"', ";
        if ( inEesAdmReqTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = "+"'"+inEesAdmReqTabObj.child_with+"', ";
        if ( inEesAdmReqTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAdmReqTabObj.roll_num+"', ";
        if ( inEesAdmReqTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesAdmReqTabObj.academic_session+"', ";
        if ( inEesAdmReqTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = "+"'"+inEesAdmReqTabObj.adm_req_sts+"', ";
        if ( inEesAdmReqTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = "+"'"+inEesAdmReqTabObj.adm_req_sts_date+"', ";
        if ( inEesAdmReqTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = "+"'"+inEesAdmReqTabObj.student_id+"', ";
        if ( inEesAdmReqTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = "+"'"+inEesAdmReqTabObj.scholor_num+"', ";
        if ( inEesAdmReqTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = "+"'"+inEesAdmReqTabObj.form_recv_date+"', ";
        if ( inEesAdmReqTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = "+"'"+inEesAdmReqTabObj.form_recv_time+"', ";
        if ( inEesAdmReqTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = "+"'"+inEesAdmReqTabObj.prospectus_sale_date+"', ";
        if ( inEesAdmReqTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = "+"'"+inEesAdmReqTabObj.prospectus_sale_time+"', ";
        if ( inEesAdmReqTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = "+"'"+inEesAdmReqTabObj.prospectus_sold_by+"', ";
               lSqlStmt = lSqlStmt + "application_form_fee = "+inEesAdmReqTabObj.application_form_fee+", ";
        if ( inEesAdmReqTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = "+"'"+inEesAdmReqTabObj.adm_academic_session+"', ";
        if ( inEesAdmReqTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = "+"'"+inEesAdmReqTabObj.entrance_exam_date+"', ";
        if ( inEesAdmReqTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = "+"'"+inEesAdmReqTabObj.entrance_exam_time_start+"', ";
        if ( inEesAdmReqTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = "+"'"+inEesAdmReqTabObj.entrance_exam_time_end+"', ";
        if ( inEesAdmReqTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = "+"'"+inEesAdmReqTabObj.exam_present_status+"', ";
        if ( inEesAdmReqTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inEesAdmReqTabObj.building_id+"', ";
        if ( inEesAdmReqTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inEesAdmReqTabObj.floor_num+"', ";
        if ( inEesAdmReqTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inEesAdmReqTabObj.room_num+"', ";
               lSqlStmt = lSqlStmt + "max_mark = "+inEesAdmReqTabObj.max_mark+", ";
               lSqlStmt = lSqlStmt + "obtained_mark = "+inEesAdmReqTabObj.obtained_mark+", ";
        if ( inEesAdmReqTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = "+"'"+inEesAdmReqTabObj.grade+"', ";
        if ( inEesAdmReqTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = "+"'"+inEesAdmReqTabObj.fee_sch_date+"', ";
        if ( inEesAdmReqTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = "+"'"+inEesAdmReqTabObj.fee_deposit_date+"', ";
        if ( inEesAdmReqTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = "+"'"+inEesAdmReqTabObj.online_flag+"', ";
        if ( inEesAdmReqTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = "+"'"+inEesAdmReqTabObj.admission_mode+"', ";
        if ( inEesAdmReqTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = "+"'"+inEesAdmReqTabObj.course_stream_1+"', ";
        if ( inEesAdmReqTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = "+"'"+inEesAdmReqTabObj.course_stream_2+"', ";
        if ( inEesAdmReqTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = "+"'"+inEesAdmReqTabObj.course_stream_3+"', ";
        if ( inEesAdmReqTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = "+"'"+inEesAdmReqTabObj.course_stream_4+"', ";
        if ( inEesAdmReqTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = "+"'"+inEesAdmReqTabObj.apr_course_stream+"', ";
        if ( inEesAdmReqTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = "+"'"+inEesAdmReqTabObj.unv_1+"', ";
        if ( inEesAdmReqTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = "+"'"+inEesAdmReqTabObj.unv_rn_1+"', ";
        if ( inEesAdmReqTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = "+"'"+inEesAdmReqTabObj.gen_rank_1+"', ";
        if ( inEesAdmReqTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = "+"'"+inEesAdmReqTabObj.ctg_rank_1+"', ";
        if ( inEesAdmReqTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = "+"'"+inEesAdmReqTabObj.stt_rank_1+"', ";
        if ( inEesAdmReqTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = "+"'"+inEesAdmReqTabObj.yoa_1+"', ";
        if ( inEesAdmReqTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = "+"'"+inEesAdmReqTabObj.unv_2+"', ";
        if ( inEesAdmReqTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = "+"'"+inEesAdmReqTabObj.unv_rn_2+"', ";
        if ( inEesAdmReqTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = "+"'"+inEesAdmReqTabObj.gen_rank_2+"', ";
        if ( inEesAdmReqTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = "+"'"+inEesAdmReqTabObj.ctg_rank_2+"', ";
        if ( inEesAdmReqTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = "+"'"+inEesAdmReqTabObj.stt_rank_2+"', ";
        if ( inEesAdmReqTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = "+"'"+inEesAdmReqTabObj.yoa_2+"', ";
               lSqlStmt = lSqlStmt + "prev_mark_percent = "+inEesAdmReqTabObj.prev_mark_percent+", ";
        if ( inEesAdmReqTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = "+"'"+inEesAdmReqTabObj.domecile_ind+"', ";
        if ( inEesAdmReqTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = "+"'"+inEesAdmReqTabObj.org_transport_req_ind+"', ";
        if ( inEesAdmReqTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = "+"'"+inEesAdmReqTabObj.org_hostel_req_ind+"', ";
        if ( inEesAdmReqTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = "+"'"+inEesAdmReqTabObj.cheque_num+"', ";
        if ( inEesAdmReqTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = "+"'"+inEesAdmReqTabObj.cheque_date+"', ";
        if ( inEesAdmReqTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = "+"'"+inEesAdmReqTabObj.bank_code+"', ";
        if ( inEesAdmReqTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = "+"'"+inEesAdmReqTabObj.bank_name+"', ";
               lSqlStmt = lSqlStmt + "cheque_amt = "+inEesAdmReqTabObj.cheque_amt+", ";
        if ( inEesAdmReqTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = "+"'"+inEesAdmReqTabObj.lg_0_name+"', ";
        if ( inEesAdmReqTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = "+"'"+inEesAdmReqTabObj.lg_0_rel_type+"', ";
        if ( inEesAdmReqTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = "+"'"+inEesAdmReqTabObj.lg_0_address+"', ";
        if ( inEesAdmReqTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = "+"'"+inEesAdmReqTabObj.lg_0_phone+"', ";
        if ( inEesAdmReqTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = "+"'"+inEesAdmReqTabObj.lg_1_name+"', ";
        if ( inEesAdmReqTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = "+"'"+inEesAdmReqTabObj.lg_1_rel_type+"', ";
        if ( inEesAdmReqTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = "+"'"+inEesAdmReqTabObj.lg_1_address+"', ";
        if ( inEesAdmReqTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = "+"'"+inEesAdmReqTabObj.lg_1_phone+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = "+"'"+inEesAdmReqTabObj.st_cap_attr_1+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = "+"'"+inEesAdmReqTabObj.st_cap_attr_2+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = "+"'"+inEesAdmReqTabObj.st_cap_attr_3+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = "+"'"+inEesAdmReqTabObj.st_cap_attr_4+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = "+"'"+inEesAdmReqTabObj.st_cap_attr_5+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = "+"'"+inEesAdmReqTabObj.st_cap_attr_6+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = "+"'"+inEesAdmReqTabObj.st_cap_attr_7+"', ";
        if ( inEesAdmReqTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = "+"'"+inEesAdmReqTabObj.st_cap_attr_8+"', ";
        if ( inEesAdmReqTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = "+"'"+inEesAdmReqTabObj.allergy+"', ";
        if ( inEesAdmReqTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = "+"'"+inEesAdmReqTabObj.physical_disability+"', ";
        if ( inEesAdmReqTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = "+"'"+inEesAdmReqTabObj.health_problem+"', ";
        if ( inEesAdmReqTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = "+"'"+inEesAdmReqTabObj.health_problem_1+"', ";
        if ( inEesAdmReqTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = "+"'"+inEesAdmReqTabObj.health_problem_2+"', ";
        if ( inEesAdmReqTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = "+"'"+inEesAdmReqTabObj.health_problem_3+"', ";
        if ( inEesAdmReqTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = "+"'"+inEesAdmReqTabObj.health_problem_4+"', ";
        if ( inEesAdmReqTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = "+"'"+inEesAdmReqTabObj.health_problem_5+"', ";
        if ( inEesAdmReqTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = "+"'"+inEesAdmReqTabObj.health_problem_6+"', ";
        if ( inEesAdmReqTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = "+"'"+inEesAdmReqTabObj.health_problem_7+"', ";
        if ( inEesAdmReqTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = "+"'"+inEesAdmReqTabObj.health_problem_8+"', ";
        if ( inEesAdmReqTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = "+"'"+inEesAdmReqTabObj.health_problem_9+"', ";
        if ( inEesAdmReqTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = "+"'"+inEesAdmReqTabObj.health_problem_10+"', ";
        if ( inEesAdmReqTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = "+"'"+inEesAdmReqTabObj.health_problem_11+"', ";
        if ( inEesAdmReqTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = "+"'"+inEesAdmReqTabObj.health_problem_12+"', ";
        if ( inEesAdmReqTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = "+"'"+inEesAdmReqTabObj.enclosure_1+"', ";
        if ( inEesAdmReqTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = "+"'"+inEesAdmReqTabObj.enclosure_2+"', ";
        if ( inEesAdmReqTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = "+"'"+inEesAdmReqTabObj.enclosure_3+"', ";
        if ( inEesAdmReqTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = "+"'"+inEesAdmReqTabObj.enclosure_4+"', ";
        if ( inEesAdmReqTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = "+"'"+inEesAdmReqTabObj.enclosure_5+"', ";
        if ( inEesAdmReqTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = "+"'"+inEesAdmReqTabObj.enclosure_6+"', ";
        if ( inEesAdmReqTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = "+"'"+inEesAdmReqTabObj.enclosure_7+"', ";
        if ( inEesAdmReqTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = "+"'"+inEesAdmReqTabObj.enclosure_8+"', ";
               lSqlStmt = lSqlStmt + "seat_num = "+inEesAdmReqTabObj.seat_num+", ";
        if ( inEesAdmReqTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = "+"'"+inEesAdmReqTabObj.reason_for_join+"', ";
        if ( inEesAdmReqTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inEesAdmReqTabObj.remark+"', ";
        if ( inEesAdmReqTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = "+"'"+inEesAdmReqTabObj.place_of_birth+"', ";
               lSqlStmt = lSqlStmt + "adv_adm_fee = "+inEesAdmReqTabObj.adv_adm_fee+", ";
        if ( inEesAdmReqTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = "+"'"+inEesAdmReqTabObj.payment_mode+"', ";
        if ( inEesAdmReqTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = "+"'"+inEesAdmReqTabObj.target_ptl_user_id+"', ";
        if ( inEesAdmReqTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAdmReqTabObj.adm_req_id_req+"', ";
        if ( inEesAdmReqTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAdmReqTabObj.adm_req_id_list+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAdmReqPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmReqPkeyObj.adm_req_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesAdmReqTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.org_id); } 
         if ( inEesAdmReqTabObj.adm_req_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_req_id); } 
         if ( inEesAdmReqTabObj.application_form_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.application_form_num); } 
         if ( inEesAdmReqTabObj.applicant_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.applicant_id); } 
         if ( inEesAdmReqTabObj.student_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_photo_file); } 
         if ( inEesAdmReqTabObj.mother_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.mother_photo_file); } 
         if ( inEesAdmReqTabObj.father_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.father_photo_file); } 
         if ( inEesAdmReqTabObj.class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.class_id); } 
         if ( inEesAdmReqTabObj.class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.class_num); } 
         if ( inEesAdmReqTabObj.class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.class_std); } 
         if ( inEesAdmReqTabObj.class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.class_section); } 
         if ( inEesAdmReqTabObj.course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_id); } 
         if ( inEesAdmReqTabObj.course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_term); } 
         if ( inEesAdmReqTabObj.course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_stream); } 
         if ( inEesAdmReqTabObj.name_initials != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.name_initials); } 
         if ( inEesAdmReqTabObj.student_f_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_f_name); } 
         if ( inEesAdmReqTabObj.student_m_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_m_name); } 
         if ( inEesAdmReqTabObj.student_l_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_l_name); } 
         if ( inEesAdmReqTabObj.dob != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.dob); } 
         if ( inEesAdmReqTabObj.age_on_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.age_on_date); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(21, inEesAdmReqTabObj.age_year);
         if ( inEesAdmReqTabObj.age_month != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.age_month); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(23, inEesAdmReqTabObj.age_day);
         if ( inEesAdmReqTabObj.s_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.s_nationality); } 
         if ( inEesAdmReqTabObj.religion != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.religion); } 
         if ( inEesAdmReqTabObj.student_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_ctg); } 
         if ( inEesAdmReqTabObj.gender_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.gender_flag); } 
         if ( inEesAdmReqTabObj.p_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_address_1); } 
         if ( inEesAdmReqTabObj.p_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_address_2); } 
         if ( inEesAdmReqTabObj.p_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_country); } 
         if ( inEesAdmReqTabObj.p_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_state); } 
         if ( inEesAdmReqTabObj.p_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_city); } 
         if ( inEesAdmReqTabObj.p_district != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_district); } 
         if ( inEesAdmReqTabObj.p_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.p_zip); } 
         if ( inEesAdmReqTabObj.m_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_address_1); } 
         if ( inEesAdmReqTabObj.m_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_address_2); } 
         if ( inEesAdmReqTabObj.m_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_country); } 
         if ( inEesAdmReqTabObj.m_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_state); } 
         if ( inEesAdmReqTabObj.m_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_city); } 
         if ( inEesAdmReqTabObj.m_district != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_district); } 
         if ( inEesAdmReqTabObj.m_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_zip); } 
         if ( inEesAdmReqTabObj.phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.phone_list); } 
         if ( inEesAdmReqTabObj.email_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.email_list); } 
         if ( inEesAdmReqTabObj.fax_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.fax_list); } 
         if ( inEesAdmReqTabObj.prev_org_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_org_name); } 
         if ( inEesAdmReqTabObj.prev_class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_class_id); } 
         if ( inEesAdmReqTabObj.prev_class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_class_num); } 
         if ( inEesAdmReqTabObj.prev_class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_class_std); } 
         if ( inEesAdmReqTabObj.prev_class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_class_section); } 
         if ( inEesAdmReqTabObj.prev_course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_course_id); } 
         if ( inEesAdmReqTabObj.prev_course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_course_term); } 
         if ( inEesAdmReqTabObj.prev_course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prev_course_stream); } 
         if ( inEesAdmReqTabObj.reason_for_leaving != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.reason_for_leaving); } 
         if ( inEesAdmReqTabObj.father_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.father_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(55, inEesAdmReqTabObj.father_age);
         if ( inEesAdmReqTabObj.f_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.f_nationality); } 
         if ( inEesAdmReqTabObj.father_occ_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.father_occ_type); } 
         if ( inEesAdmReqTabObj.father_employer != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.father_employer); } 
         if ( inEesAdmReqTabObj.father_designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.father_designation); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(60, inEesAdmReqTabObj.father_annual_income);
         if ( inEesAdmReqTabObj.f_off_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.f_off_address_1); } 
         if ( inEesAdmReqTabObj.f_phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.f_phone_list); } 
         if ( inEesAdmReqTabObj.mother_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.mother_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(64, inEesAdmReqTabObj.mother_age);
         if ( inEesAdmReqTabObj.m_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_nationality); } 
         if ( inEesAdmReqTabObj.mother_occ_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.mother_occ_type); } 
         if ( inEesAdmReqTabObj.mother_employer != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.mother_employer); } 
         if ( inEesAdmReqTabObj.mother_designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.mother_designation); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(69, inEesAdmReqTabObj.mother_annual_income);
         if ( inEesAdmReqTabObj.m_off_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_off_address_1); } 
         if ( inEesAdmReqTabObj.m_phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.m_phone_list); } 
         if ( inEesAdmReqTabObj.divorced_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.divorced_flag); } 
         if ( inEesAdmReqTabObj.child_with != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.child_with); } 
         if ( inEesAdmReqTabObj.roll_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.roll_num); } 
         if ( inEesAdmReqTabObj.academic_session != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.academic_session); } 
         if ( inEesAdmReqTabObj.adm_req_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_req_sts); } 
         if ( inEesAdmReqTabObj.adm_req_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_req_sts_date); } 
         if ( inEesAdmReqTabObj.student_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.student_id); } 
         if ( inEesAdmReqTabObj.scholor_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.scholor_num); } 
         if ( inEesAdmReqTabObj.form_recv_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.form_recv_date); } 
         if ( inEesAdmReqTabObj.form_recv_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.form_recv_time); } 
         if ( inEesAdmReqTabObj.prospectus_sale_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prospectus_sale_date); } 
         if ( inEesAdmReqTabObj.prospectus_sale_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prospectus_sale_time); } 
         if ( inEesAdmReqTabObj.prospectus_sold_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.prospectus_sold_by); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(85, inEesAdmReqTabObj.application_form_fee);
         if ( inEesAdmReqTabObj.adm_academic_session != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_academic_session); } 
         if ( inEesAdmReqTabObj.entrance_exam_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.entrance_exam_date); } 
         if ( inEesAdmReqTabObj.entrance_exam_time_start != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.entrance_exam_time_start); } 
         if ( inEesAdmReqTabObj.entrance_exam_time_end != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.entrance_exam_time_end); } 
         if ( inEesAdmReqTabObj.exam_present_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.exam_present_status); } 
         if ( inEesAdmReqTabObj.building_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.building_id); } 
         if ( inEesAdmReqTabObj.floor_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.floor_num); } 
         if ( inEesAdmReqTabObj.room_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.room_num); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(94, inEesAdmReqTabObj.max_mark);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(95, inEesAdmReqTabObj.obtained_mark);
         if ( inEesAdmReqTabObj.grade != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.grade); } 
         if ( inEesAdmReqTabObj.fee_sch_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.fee_sch_date); } 
         if ( inEesAdmReqTabObj.fee_deposit_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.fee_deposit_date); } 
         if ( inEesAdmReqTabObj.online_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.online_flag); } 
         if ( inEesAdmReqTabObj.admission_mode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.admission_mode); } 
         if ( inEesAdmReqTabObj.course_stream_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_stream_1); } 
         if ( inEesAdmReqTabObj.course_stream_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_stream_2); } 
         if ( inEesAdmReqTabObj.course_stream_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_stream_3); } 
         if ( inEesAdmReqTabObj.course_stream_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.course_stream_4); } 
         if ( inEesAdmReqTabObj.apr_course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.apr_course_stream); } 
         if ( inEesAdmReqTabObj.unv_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.unv_1); } 
         if ( inEesAdmReqTabObj.unv_rn_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.unv_rn_1); } 
         if ( inEesAdmReqTabObj.gen_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.gen_rank_1); } 
         if ( inEesAdmReqTabObj.ctg_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.ctg_rank_1); } 
         if ( inEesAdmReqTabObj.stt_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.stt_rank_1); } 
         if ( inEesAdmReqTabObj.yoa_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.yoa_1); } 
         if ( inEesAdmReqTabObj.unv_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.unv_2); } 
         if ( inEesAdmReqTabObj.unv_rn_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.unv_rn_2); } 
         if ( inEesAdmReqTabObj.gen_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.gen_rank_2); } 
         if ( inEesAdmReqTabObj.ctg_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.ctg_rank_2); } 
         if ( inEesAdmReqTabObj.stt_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.stt_rank_2); } 
         if ( inEesAdmReqTabObj.yoa_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.yoa_2); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(118, inEesAdmReqTabObj.prev_mark_percent);
         if ( inEesAdmReqTabObj.domecile_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.domecile_ind); } 
         if ( inEesAdmReqTabObj.org_transport_req_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.org_transport_req_ind); } 
         if ( inEesAdmReqTabObj.org_hostel_req_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.org_hostel_req_ind); } 
         if ( inEesAdmReqTabObj.cheque_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.cheque_num); } 
         if ( inEesAdmReqTabObj.cheque_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.cheque_date); } 
         if ( inEesAdmReqTabObj.bank_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.bank_code); } 
         if ( inEesAdmReqTabObj.bank_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.bank_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(126, inEesAdmReqTabObj.cheque_amt);
         if ( inEesAdmReqTabObj.lg_0_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_0_name); } 
         if ( inEesAdmReqTabObj.lg_0_rel_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_0_rel_type); } 
         if ( inEesAdmReqTabObj.lg_0_address != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_0_address); } 
         if ( inEesAdmReqTabObj.lg_0_phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_0_phone); } 
         if ( inEesAdmReqTabObj.lg_1_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_1_name); } 
         if ( inEesAdmReqTabObj.lg_1_rel_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_1_rel_type); } 
         if ( inEesAdmReqTabObj.lg_1_address != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_1_address); } 
         if ( inEesAdmReqTabObj.lg_1_phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.lg_1_phone); } 
         if ( inEesAdmReqTabObj.st_cap_attr_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_1); } 
         if ( inEesAdmReqTabObj.st_cap_attr_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_2); } 
         if ( inEesAdmReqTabObj.st_cap_attr_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_3); } 
         if ( inEesAdmReqTabObj.st_cap_attr_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_4); } 
         if ( inEesAdmReqTabObj.st_cap_attr_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_5); } 
         if ( inEesAdmReqTabObj.st_cap_attr_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_6); } 
         if ( inEesAdmReqTabObj.st_cap_attr_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_7); } 
         if ( inEesAdmReqTabObj.st_cap_attr_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.st_cap_attr_8); } 
         if ( inEesAdmReqTabObj.allergy != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.allergy); } 
         if ( inEesAdmReqTabObj.physical_disability != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.physical_disability); } 
         if ( inEesAdmReqTabObj.health_problem != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem); } 
         if ( inEesAdmReqTabObj.health_problem_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_1); } 
         if ( inEesAdmReqTabObj.health_problem_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_2); } 
         if ( inEesAdmReqTabObj.health_problem_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_3); } 
         if ( inEesAdmReqTabObj.health_problem_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_4); } 
         if ( inEesAdmReqTabObj.health_problem_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_5); } 
         if ( inEesAdmReqTabObj.health_problem_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_6); } 
         if ( inEesAdmReqTabObj.health_problem_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_7); } 
         if ( inEesAdmReqTabObj.health_problem_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_8); } 
         if ( inEesAdmReqTabObj.health_problem_9 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_9); } 
         if ( inEesAdmReqTabObj.health_problem_10 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_10); } 
         if ( inEesAdmReqTabObj.health_problem_11 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_11); } 
         if ( inEesAdmReqTabObj.health_problem_12 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.health_problem_12); } 
         if ( inEesAdmReqTabObj.enclosure_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_1); } 
         if ( inEesAdmReqTabObj.enclosure_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_2); } 
         if ( inEesAdmReqTabObj.enclosure_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_3); } 
         if ( inEesAdmReqTabObj.enclosure_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_4); } 
         if ( inEesAdmReqTabObj.enclosure_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_5); } 
         if ( inEesAdmReqTabObj.enclosure_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_6); } 
         if ( inEesAdmReqTabObj.enclosure_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_7); } 
         if ( inEesAdmReqTabObj.enclosure_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.enclosure_8); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(166, inEesAdmReqTabObj.seat_num);
         if ( inEesAdmReqTabObj.reason_for_join != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.reason_for_join); } 
         if ( inEesAdmReqTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.remark); } 
         if ( inEesAdmReqTabObj.place_of_birth != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.place_of_birth); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(170, inEesAdmReqTabObj.adv_adm_fee);
         if ( inEesAdmReqTabObj.payment_mode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.payment_mode); } 
         if ( inEesAdmReqTabObj.target_ptl_user_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.target_ptl_user_id); } 
         if ( inEesAdmReqTabObj.adm_req_id_req != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_req_id_req); } 
         if ( inEesAdmReqTabObj.adm_req_id_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmReqTabObj.adm_req_id_list); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmReqRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesAdmReqRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmReqRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_ADM_REQ "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmReqRecByPkeyWithSet
               ( EesAdmReqPkeyObj inEesAdmReqPkeyObj
               , String  inEesAdmReqSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmReqRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmReqRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_REQ ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAdmReqSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAdmReqPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmReqPkeyObj.adm_req_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmReqRecByRowidWithSet
               ( String inRowId
               , String  inEesAdmReqSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmReqRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmReqRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_REQ ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAdmReqSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmReqRecByWhereWithSet
               ( String inEesAdmReqWhereText
               , String  inEesAdmReqSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmReqRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmReqRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_REQ ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesAdmReqSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmReqRecByPkey
               ( EesAdmReqPkeyObj  inEesAdmReqPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesAdmReqRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmReqRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_ADM_REQ " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAdmReqPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmReqPkeyObj.adm_req_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmReqByWhere
               ( String inEesAdmReqWhereText
               )
  {
    int lUpdateCount;
    sop("delEesAdmReqByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmReqByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmReqWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmReqWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_ADM_REQ "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
