package sstdb.ees.EesCourseStream;


public class EesCourseStreamTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 course_id;
  public String                                 course_stream;
  public String                                 description;
  public int                                  stream_strength;
  public int                                  quota_qty;
  public String                                 course_code;
  public String                                 short_code;
  public String                                 sst_stream_id;
  public String                                 course_coord;
  public String                                 board_university;
  public double                                 min_fee_amt;
  public String                                 cc_ptl_user_id;
  public String                                 class_std;





  public short                                  org_id_ind;
  public short                                  course_id_ind;
  public short                                  course_stream_ind;
  public short                                  description_ind;
  public short                                  stream_strength_ind;
  public short                                  quota_qty_ind;
  public short                                  course_code_ind;
  public short                                  short_code_ind;
  public short                                  sst_stream_id_ind;
  public short                                  course_coord_ind;
  public short                                  board_university_ind;
  public short                                  min_fee_amt_ind;
  public short                                  cc_ptl_user_id_ind;
  public short                                  class_std_ind;


  public EesCourseStreamTabObj(){}


  public EesCourseStreamTabObj
  (
    String org_id,
    String course_id,
    String course_stream,
    String description,
    int stream_strength,
    int quota_qty,
    String course_code,
    String short_code,
    String sst_stream_id,
    String course_coord,
    String board_university,
    double min_fee_amt,
    String cc_ptl_user_id,
    String class_std
  )
  {
     this.org_id = org_id;
     this.course_id = course_id;
     this.course_stream = course_stream;
     this.description = description;
     this.stream_strength = stream_strength;
     this.quota_qty = quota_qty;
     this.course_code = course_code;
     this.short_code = short_code;
     this.sst_stream_id = sst_stream_id;
     this.course_coord = course_coord;
     this.board_university = board_university;
     this.min_fee_amt = min_fee_amt;
     this.cc_ptl_user_id = cc_ptl_user_id;
     this.class_std = class_std;
  }

  public String getorg_id()                           { return org_id; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_stream()                       { return course_stream; }
  public String getdescription()                        { return description; }
  public int getstream_strength()                        { return stream_strength; }
  public int getquota_qty()                           { return quota_qty; }
  public String getcourse_code()                        { return course_code; }
  public String getshort_code()                         { return short_code; }
  public String getsst_stream_id()                       { return sst_stream_id; }
  public String getcourse_coord()                        { return course_coord; }
  public String getboard_university()                      { return board_university; }
  public double getmin_fee_amt()                        { return min_fee_amt; }
  public String getcc_ptl_user_id()                       { return cc_ptl_user_id; }
  public String getclass_std()                         { return class_std; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setdescription(String description )               { this.description = description; }
  public void  setstream_strength(int stream_strength )             { this.stream_strength = stream_strength; }
  public void  setquota_qty(int quota_qty )                   { this.quota_qty = quota_qty; }
  public void  setcourse_code(String course_code )               { this.course_code = course_code; }
  public void  setshort_code(String short_code )                { this.short_code = short_code; }
  public void  setsst_stream_id(String sst_stream_id )             { this.sst_stream_id = sst_stream_id; }
  public void  setcourse_coord(String course_coord )              { this.course_coord = course_coord; }
  public void  setboard_university(String board_university )          { this.board_university = board_university; }
  public void  setmin_fee_amt(double min_fee_amt )               { this.min_fee_amt = min_fee_amt; }
  public void  setcc_ptl_user_id(String cc_ptl_user_id )            { this.cc_ptl_user_id = cc_ptl_user_id; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
}