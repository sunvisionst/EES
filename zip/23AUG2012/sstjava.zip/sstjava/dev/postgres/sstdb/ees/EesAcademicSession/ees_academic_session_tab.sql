CREATE TABLE EES_ACADEMIC_SESSION
(
  ORG_ID                                                                                              VARCHAR(10),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  START_DATE                                                                                          VARCHAR(8),
  END_DATE                                                                                            VARCHAR(8),
  CLOSE_DATE                                                                                          VARCHAR(8),
  ACADEMIC_SESSION_STS                                                                                VARCHAR(1),
  SEMESTER_START_DATE                                                                                 VARCHAR(8),
  SEMESTER_END_DATE                                                                                   VARCHAR(8),
  SEMESTER_CLOSE_DATE                                                                                 VARCHAR(8)
)
 WITH OIDS;
