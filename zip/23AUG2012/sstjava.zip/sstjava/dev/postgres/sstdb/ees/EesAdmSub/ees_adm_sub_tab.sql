CREATE TABLE EES_ADM_SUB
(
  ORG_ID                                                                                              VARCHAR(10),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  SUBJECT_CODE                                                                                        VARCHAR(10),
  CLASS_NUM                                                                                           VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  MAX_MARK                                                                                            NUMERIC(9),
  MIN_MARK                                                                                            NUMERIC(9),
  DESCRIPTION                                                                                         VARCHAR(100)
)
 WITH OIDS;
