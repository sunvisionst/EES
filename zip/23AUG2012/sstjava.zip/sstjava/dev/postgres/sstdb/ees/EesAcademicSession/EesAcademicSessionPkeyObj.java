package sstdb.ees.EesAcademicSession;


public class EesAcademicSessionPkeyObj
{
  public String                                 org_id;
  public String                                 academic_session;
}