package sstdb.ees.EesAppcPrevMark;


public class EesAppcPrevMarkPkeyObj
{
  public String                                 org_id;
  public String                                 applicant_id;
}