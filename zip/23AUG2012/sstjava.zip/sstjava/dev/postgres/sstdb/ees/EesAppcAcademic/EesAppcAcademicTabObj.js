{


   function vldDBSizeEnvEesAppcAcademic
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeApplicantId ( inTableName, inFieldName );
      vldFieldDBSizeSeqNum ( inTableName, inFieldName );
      vldFieldDBSizeClassNum ( inTableName, inFieldName );
      vldFieldDBSizeClassStd ( inTableName, inFieldName );
      vldFieldDBSizeCourseId ( inTableName, inFieldName );
      vldFieldDBSizeCourseTerm ( inTableName, inFieldName );
      vldFieldDBSizeCourseStream ( inTableName, inFieldName );
      vldFieldDBSizeFullPartTime ( inTableName, inFieldName );
      vldFieldDBSizeUniversityBoardName ( inTableName, inFieldName );
      vldFieldDBSizeCollegeSchoolName ( inTableName, inFieldName );
      vldFieldDBSizeState ( inTableName, inFieldName );
      vldFieldDBSizeCountry ( inTableName, inFieldName );
      vldFieldDBSizeUnvRn ( inTableName, inFieldName );
      vldFieldDBSizeSubjectList ( inTableName, inFieldName );
      vldFieldDBSizeYearOfPassing ( inTableName, inFieldName );
      vldFieldDBSizePercentGrade ( inTableName, inFieldName );
      vldFieldDBSizeMarksInPercent ( inTableName, inFieldName );
      vldFieldDBSizeGrade ( inTableName, inFieldName );
      vldFieldDBSizeAdmReqIdReq ( inTableName, inFieldName );
      vldFieldDBSizeAdmReqIdList ( inTableName, inFieldName );
   }



   function constructorEesAppcAcademic
   (
      org_id,
      applicant_id,
      seq_num,
      class_num,
      class_std,
      course_id,
      course_term,
      course_stream,
      full_part_time,
      university_board_name,
      college_school_name,
      state,
      country,
      unv_rn,
      subject_list,
      year_of_passing,
      percent_grade,
      marks_in_percent,
      grade,
      adm_req_id_req,
      adm_req_id_list
   )
   {
      this.org_id = org_id;
      this.applicant_id = applicant_id;
      this.seq_num = seq_num;
      this.class_num = class_num;
      this.class_std = class_std;
      this.course_id = course_id;
      this.course_term = course_term;
      this.course_stream = course_stream;
      this.full_part_time = full_part_time;
      this.university_board_name = university_board_name;
      this.college_school_name = college_school_name;
      this.state = state;
      this.country = country;
      this.unv_rn = unv_rn;
      this.subject_list = subject_list;
      this.year_of_passing = year_of_passing;
      this.percent_grade = percent_grade;
      this.marks_in_percent = marks_in_percent;
      this.grade = grade;
      this.adm_req_id_req = adm_req_id_req;
      this.adm_req_id_list = adm_req_id_list;
   }



   function EesAppcAcademicFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lEesAppcAcademicTabObjJSArr.length )
      {
         if
         ( 
           ( lEesAppcAcademicTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lEesAppcAcademicTabObjJSArr[lRecNum].applicant_id != document.form.applicant_id.value ) &&
           ( lEesAppcAcademicTabObjJSArr[lRecNum].seq_num != document.form.seq_num.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeEesAppcAcademicTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjApplicantId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >25 )
      {
         alert("Data base field size error. Size should be <= 25");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjSeqNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjClassNum
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjClassStd
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjCourseId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjCourseTerm
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjCourseStream
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjFullPartTime
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjUniversityBoardName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjCollegeSchoolName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjState
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjCountry
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjUnvRn
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjSubjectList
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >200 )
      {
         alert("Data base field size error. Size should be <= 200");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjYearOfPassing
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >4 )
      {
         alert("Data base field size error. Size should be <= 4");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.') ) >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjPercentGrade
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjMarksInPercent
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.indexOf('.')+1) >5 )
      {
         alert("Data base field size error. Integer Size should be <= 5");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && (lJSFieldObj.value.length - (lJSFieldObj.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjGrade
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjAdmReqIdReq
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAppcAcademicTabObjAdmReqIdList
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisApplicantId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >25 )
      {
         alert("Data base field size error. Size should be <= 25");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSeqNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >9 )
      {
         alert("Data base field size error. Size should be <= 9");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisClassNum
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisClassStd
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseTerm
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCourseStream
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisFullPartTime
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisUniversityBoardName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCollegeSchoolName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisState
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisCountry
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisUnvRn
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisSubjectList
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >200 )
      {
         alert("Data base field size error. Size should be <= 200");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisYearOfPassing
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >4 )
      {
         alert("Data base field size error. Size should be <= 4");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.indexOf('.') >= 0 )
      {
         alert("Invalid Number. Decimal not allowed");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisPercentGrade
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >1 )
      {
         alert("Data base field size error. Size should be <= 1");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisMarksInPercent
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.indexOf('.')+1) >5 )
      {
         alert("Data base field size error. Integer Size should be <= 5");
         inFieldName.focus();
      }
      if ( inFieldName != null && (inFieldName.value.length - (inFieldName.value.indexOf('.')+1)) >2 )
      {
         alert("Data base field size error. Fraction Size should be <= 2");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisGrade
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >5 )
      {
         alert("Data base field size error. Size should be <= 5");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAdmReqIdReq
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAdmReqIdList
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >30 )
      {
         alert("Data base field size error. Size should be <= 30");
         inFieldName.focus();
      }
   }



}