package sstdb.ees.EesAdmList;


public class EesAdmListPkeyObj
{
  public String                                 org_id;
  public String                                 adm_req_id;
}