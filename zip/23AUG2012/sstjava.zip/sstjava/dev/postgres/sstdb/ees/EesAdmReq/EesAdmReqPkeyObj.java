package sstdb.ees.EesAdmReq;


public class EesAdmReqPkeyObj
{
  public String                                 org_id;
  public String                                 adm_req_id;
}