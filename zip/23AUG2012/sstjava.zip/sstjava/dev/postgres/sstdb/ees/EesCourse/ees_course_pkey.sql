ALTER TABLE           EES_COURSE
  ADD                 CONSTRAINT EES_COURSE_PK
  PRIMARY             KEY
  ( ORG_ID, COURSE_ID )
;
