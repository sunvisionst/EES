package sstdb.ees.EesExamClass;


public class EesExamClassTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 exam_id;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 exam_term;
  public String                                 exam_type;
  public short                                 year;
  public byte                                  month;
  public String                                 academic_session;
  public String                                 exam_status;
  public String                                 exam_status_date;





  public short                                  org_id_ind;
  public short                                  exam_id_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  exam_term_ind;
  public short                                  exam_type_ind;
  public short                                  year_ind;
  public short                                  month_ind;
  public short                                  academic_session_ind;
  public short                                  exam_status_ind;
  public short                                  exam_status_date_ind;


  public EesExamClassTabObj(){}


  public EesExamClassTabObj
  (
    String org_id,
    String exam_id,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream,
    String exam_term,
    String exam_type,
    short year,
    byte month,
    String academic_session,
    String exam_status,
    String exam_status_date
  )
  {
     this.org_id = org_id;
     this.exam_id = exam_id;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.exam_term = exam_term;
     this.exam_type = exam_type;
     this.year = year;
     this.month = month;
     this.academic_session = academic_session;
     this.exam_status = exam_status;
     this.exam_status_date = exam_status_date;
  }

  public String getorg_id()                           { return org_id; }
  public String getexam_id()                          { return exam_id; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getexam_term()                         { return exam_term; }
  public String getexam_type()                         { return exam_type; }
  public short getyear()                            { return year; }
  public byte getmonth()                            { return month; }
  public String getacademic_session()                      { return academic_session; }
  public String getexam_status()                        { return exam_status; }
  public String getexam_status_date()                      { return exam_status_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setexam_id(String exam_id )                   { this.exam_id = exam_id; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setexam_term(String exam_term )                 { this.exam_term = exam_term; }
  public void  setexam_type(String exam_type )                 { this.exam_type = exam_type; }
  public void  setyear(short year )                       { this.year = year; }
  public void  setmonth(byte month )                      { this.month = month; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setexam_status(String exam_status )               { this.exam_status = exam_status; }
  public void  setexam_status_date(String exam_status_date )          { this.exam_status_date = exam_status_date; }
}