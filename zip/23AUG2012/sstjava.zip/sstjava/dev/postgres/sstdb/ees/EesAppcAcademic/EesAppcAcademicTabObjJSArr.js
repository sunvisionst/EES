
var lEesAppcAcademicTabObjJSArr = new Array();
<%
{
   if ( lEesAppcAcademicTabObjArrCache != null && lEesAppcAcademicTabObjArrCache.size() > 0 )
   {
%>
       lEesAppcAcademicTabObjJSArr = new Array(<%=lEesAppcAcademicTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAppcAcademicTabObjArrCache.size(); lRecNum++ )
       {
          EesAppcAcademicTabObj lEesAppcAcademicTabObj    =    new EesAppcAcademicTabObj();
          lEesAppcAcademicTabObj = (EesAppcAcademicTabObj)lEesAppcAcademicTabObjArrCache.get(lRecNum);
%>
          lEesAppcAcademicTabObjJSArr[<%=lRecNum%>] = new constructorEesAppcAcademic
          (
          "<%=lEesAppcAcademicTabObj.org_id%>",
          "<%=lEesAppcAcademicTabObj.applicant_id%>",
          "<%=lEesAppcAcademicTabObj.seq_num%>",
          "<%=lEesAppcAcademicTabObj.class_num%>",
          "<%=lEesAppcAcademicTabObj.class_std%>",
          "<%=lEesAppcAcademicTabObj.course_id%>",
          "<%=lEesAppcAcademicTabObj.course_term%>",
          "<%=lEesAppcAcademicTabObj.course_stream%>",
          "<%=lEesAppcAcademicTabObj.full_part_time%>",
          "<%=lEesAppcAcademicTabObj.university_board_name%>",
          "<%=lEesAppcAcademicTabObj.college_school_name%>",
          "<%=lEesAppcAcademicTabObj.state%>",
          "<%=lEesAppcAcademicTabObj.country%>",
          "<%=lEesAppcAcademicTabObj.unv_rn%>",
          "<%=lEesAppcAcademicTabObj.subject_list%>",
          "<%=lEesAppcAcademicTabObj.year_of_passing%>",
          "<%=lEesAppcAcademicTabObj.percent_grade%>",
          "<%=lEesAppcAcademicTabObj.marks_in_percent%>",
          "<%=lEesAppcAcademicTabObj.grade%>",
          "<%=lEesAppcAcademicTabObj.adm_req_id_req%>",
          "<%=lEesAppcAcademicTabObj.adm_req_id_list%>"
          );
<%
       }
   }
}
%>


