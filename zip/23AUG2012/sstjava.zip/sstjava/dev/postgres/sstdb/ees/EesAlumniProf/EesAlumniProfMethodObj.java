package sstdb.ees.EesAlumniProf;

import sstdb.ees.EesAlumniProf.EesAlumniProfTabObj;
import sstdb.ees.EesAlumniProf.EesAlumniProfPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesAlumniProfMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesAlumniProfMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesAlumniProfMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesAlumniProfTabObj
               ( 
                 EesAlumniProfTabObj  outEesAlumniProfTabObj
               )
  {
  
     outEesAlumniProfTabObj.student_org_id = ""; 
     outEesAlumniProfTabObj.alumni_id = ""; 
     outEesAlumniProfTabObj.seq_num = (int)0; 
     outEesAlumniProfTabObj.occupation = ""; 
     outEesAlumniProfTabObj.designation = ""; 
     outEesAlumniProfTabObj.joining_date = ""; 
     outEesAlumniProfTabObj.org_name = ""; 
     outEesAlumniProfTabObj.working_tech = ""; 
     outEesAlumniProfTabObj.area_of_interest = ""; 
     outEesAlumniProfTabObj.web_page_ind = ""; 
     outEesAlumniProfTabObj.office_address1 = ""; 
     outEesAlumniProfTabObj.office_address2 = ""; 
     outEesAlumniProfTabObj.city = ""; 
     outEesAlumniProfTabObj.state = ""; 
     outEesAlumniProfTabObj.zip = ""; 
     outEesAlumniProfTabObj.country = ""; 
     outEesAlumniProfTabObj.phone_list = ""; 
     outEesAlumniProfTabObj.email_list = ""; 
     outEesAlumniProfTabObj.fax_list = ""; 
  }





  public void guiDateConvEesAlumniProfTabObj
               ( 
                 EesAlumniProfTabObj  inEesAlumniProfTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesAlumniProfTabObj.joining_date != null && inEesAlumniProfTabObj.joining_date.length() > 0 ) 
            inEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesAlumniProfByTabObj
               ( 
                 EesAlumniProfTabObj  inEesAlumniProfTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesAlumniProfTabObjArrCtx  = new ArrayList(); 
    lEesAlumniProfTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesAlumniProfTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesAlumniProfTabObjArrCtx.add(inEesAlumniProfTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesAlumniProfTabObjArrCtx.size();  lRecNum++ )
      {
        EesAlumniProfTabObj lEesAlumniProfTabObj = new EesAlumniProfTabObj();
        lEesAlumniProfTabObj = (EesAlumniProfTabObj)lEesAlumniProfTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesAlumniProfTabObj.student_org_id.equals(lEesAlumniProfTabObj.student_org_id) &&
              lEesAlumniProfTabObj.alumni_id.equals(lEesAlumniProfTabObj.alumni_id) &&
              (lEesAlumniProfTabObj.seq_num == lEesAlumniProfTabObj.seq_num) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesAlumniProfTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesAlumniProfTabObjArrCtx.set(lRecNum, inEesAlumniProfTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesAlumniProfTabObjArrCtx",lEesAlumniProfTabObjArrCtx);
  }





  public void sortEesAlumniProfTabObjArr
               ( 
                 ArrayList  inEesAlumniProfTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesAlumniProfTabObjArr  = new ArrayList(); 
     lEesAlumniProfTabObjArr = inEesAlumniProfTabObjArr; 
     List lEesAlumniProfTabObjList  = new ArrayList(lEesAlumniProfTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesAlumniProfTabObjArr.size();  lRecNum++ )
     {
       EesAlumniProfTabObj  lEesAlumniProfTabObj = new EesAlumniProfTabObj(); 
       lEesAlumniProfTabObj = (EesAlumniProfTabObj)lEesAlumniProfTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("student_org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniProfTabObj.student_org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.student_org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("alumni_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniProfTabObj.alumni_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.alumni_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("seq_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lEesAlumniProfTabObj.seq_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.seq_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("occupation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.occupation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.occupation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAlumniProfTabObj.designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("joining_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniProfTabObj.joining_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.joining_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.org_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.org_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("working_tech") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.working_tech.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.working_tech+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("area_of_interest") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.area_of_interest.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.area_of_interest+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("web_page_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAlumniProfTabObj.web_page_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.web_page_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("office_address1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.office_address1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.office_address1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("office_address2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.office_address2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.office_address2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAlumniProfTabObj.city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAlumniProfTabObj.state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniProfTabObj.zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAlumniProfTabObj.country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.email_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.email_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fax_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniProfTabObj.fax_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniProfTabObj.fax_list+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesAlumniProfTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesAlumniProfTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesAlumniProfTabObjList ); 
     ArrayList lEesAlumniProfTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesAlumniProfTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesAlumniProfTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesAlumniProfTabObjArrSorted.add( (EesAlumniProfTabObj)lEesAlumniProfTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesAlumniProfTabObjArr.size();  lRecNum++ )
     {
       inEesAlumniProfTabObjArr.set( lRecNum, (EesAlumniProfTabObj)lEesAlumniProfTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesAlumniProfTabObj
               ( 
                 EesAlumniProfTabObj  inEesAlumniProfTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesAlumniProfTabObj.joining_date != null && inEesAlumniProfTabObj.joining_date.length() > 0 ) 
            inEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniProfTabObj.joining_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeStudentOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAlumniId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALUMNI_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSeqNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SEQ_NUM";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOccupation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OCCUPATION";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeJoiningDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "JOINING_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWorkingTech
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WORKING_TECH";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAreaOfInterest
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AREA_OF_INTEREST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeWebPageInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "WEB_PAGE_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOfficeAddress1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OFFICE_ADDRESS1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOfficeAddress2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OFFICE_ADDRESS2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCity
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeState
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeZip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFaxList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FAX_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesAlumniProfCount
               ( String inEesAlumniProfWhereText
               )
  {
    sop("gtEesAlumniProfCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfCount
               ( String inEesAlumniProfWhereText
               , String inEesAlumniProfSelectFieldList
               )
  {
    sop("gtEesAlumniProfCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesAlumniProfSelectFieldList+" AS count "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfRecByPkey
               ( EesAlumniProfPkeyObj inEesAlumniProfPkeyObj
               , EesAlumniProfTabObj  outEesAlumniProfTabObj
               )
  {
    sop("gtEesAlumniProfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "student_org_id, "+
                                 "alumni_id, "+
                                 "seq_num, "+
                                 "occupation, "+
                                 "designation, "+
                                 "joining_date, "+
                                 "org_name, "+
                                 "working_tech, "+
                                 "area_of_interest, "+
                                 "web_page_ind, "+
                                 "office_address1, "+
                                 "office_address2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list "+
                         "FROM   EES_ALUMNI_PROF " + 
                         "WHERE "+
                              "student_org_id = "+"'"+inEesAlumniProfPkeyObj.student_org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniProfPkeyObj.alumni_id+"' and "+
                              "seq_num = "+inEesAlumniProfPkeyObj.seq_num+"";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesAlumniProfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAlumniProfTabObj.student_org_id  =  lResultSet.getString("STUDENT_ORG_ID");
          outEesAlumniProfTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          outEesAlumniProfTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          outEesAlumniProfTabObj.occupation  =  lResultSet.getString("OCCUPATION");
          outEesAlumniProfTabObj.designation  =  lResultSet.getString("DESIGNATION");
          outEesAlumniProfTabObj.joining_date  =  lResultSet.getString("JOINING_DATE");

          if ( outEesAlumniProfTabObj.joining_date != null && outEesAlumniProfTabObj.joining_date.length() > 0 ) 
            outEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
          outEesAlumniProfTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          outEesAlumniProfTabObj.working_tech  =  lResultSet.getString("WORKING_TECH");
          outEesAlumniProfTabObj.area_of_interest  =  lResultSet.getString("AREA_OF_INTEREST");
          outEesAlumniProfTabObj.web_page_ind  =  lResultSet.getString("WEB_PAGE_IND");
          outEesAlumniProfTabObj.office_address1  =  lResultSet.getString("OFFICE_ADDRESS1");
          outEesAlumniProfTabObj.office_address2  =  lResultSet.getString("OFFICE_ADDRESS2");
          outEesAlumniProfTabObj.city  =  lResultSet.getString("CITY");
          outEesAlumniProfTabObj.state  =  lResultSet.getString("STATE");
          outEesAlumniProfTabObj.zip  =  lResultSet.getString("ZIP");
          outEesAlumniProfTabObj.country  =  lResultSet.getString("COUNTRY");
          outEesAlumniProfTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAlumniProfTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAlumniProfTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAlumniProfTabObj( outEesAlumniProfTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfArr
               ( EesAlumniProfPkeyObj inEesAlumniProfPkeyObj
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {
    sop("gtEesAlumniProfArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "student_org_id, "+
                                 "alumni_id, "+
                                 "seq_num, "+
                                 "occupation, "+
                                 "designation, "+
                                 "joining_date, "+
                                 "org_name, "+
                                 "working_tech, "+
                                 "area_of_interest, "+
                                 "web_page_ind, "+
                                 "office_address1, "+
                                 "office_address2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list "+
                         "FROM   EES_ALUMNI_PROF";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAlumniProfTabObj  lEesAlumniProfTabObj = new EesAlumniProfTabObj();
          lEesAlumniProfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesAlumniProfTabObj.student_org_id  =  lResultSet.getString("STUDENT_ORG_ID");
          lEesAlumniProfTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          lEesAlumniProfTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          lEesAlumniProfTabObj.occupation  =  lResultSet.getString("OCCUPATION");
          lEesAlumniProfTabObj.designation  =  lResultSet.getString("DESIGNATION");
          lEesAlumniProfTabObj.joining_date  =  lResultSet.getString("JOINING_DATE");

          if ( lEesAlumniProfTabObj.joining_date != null && lEesAlumniProfTabObj.joining_date.length() > 0 ) 
            lEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
          lEesAlumniProfTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          lEesAlumniProfTabObj.working_tech  =  lResultSet.getString("WORKING_TECH");
          lEesAlumniProfTabObj.area_of_interest  =  lResultSet.getString("AREA_OF_INTEREST");
          lEesAlumniProfTabObj.web_page_ind  =  lResultSet.getString("WEB_PAGE_IND");
          lEesAlumniProfTabObj.office_address1  =  lResultSet.getString("OFFICE_ADDRESS1");
          lEesAlumniProfTabObj.office_address2  =  lResultSet.getString("OFFICE_ADDRESS2");
          lEesAlumniProfTabObj.city  =  lResultSet.getString("CITY");
          lEesAlumniProfTabObj.state  =  lResultSet.getString("STATE");
          lEesAlumniProfTabObj.zip  =  lResultSet.getString("ZIP");
          lEesAlumniProfTabObj.country  =  lResultSet.getString("COUNTRY");
          lEesAlumniProfTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAlumniProfTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAlumniProfTabObj.fax_list  =  lResultSet.getString("FAX_LIST");

          removeNullEesAlumniProfTabObj( lEesAlumniProfTabObj );

          outEesAlumniProfTabObjArr.add(  lEesAlumniProfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniProfTabObjArr != null && outEesAlumniProfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesAlumniProfArr2XML
               ( String inEesAlumniProfWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesAlumniProfArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesAlumniProf>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_org_id") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_ORG_ID>" +  lResultSet.getString("STUDENT_ORG_ID") +   "</STUDENT_ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("alumni_id") )
              lXmlBuffer = lXmlBuffer +   "<ALUMNI_ID>" +  lResultSet.getString("ALUMNI_ID") +   "</ALUMNI_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("seq_num") )
              lXmlBuffer = lXmlBuffer +   "<SEQ_NUM>" +  lResultSet.getInt("SEQ_NUM") +   "</SEQ_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("occupation") )
              lXmlBuffer = lXmlBuffer +   "<OCCUPATION>" +  lResultSet.getString("OCCUPATION") +   "</OCCUPATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("designation") )
              lXmlBuffer = lXmlBuffer +   "<DESIGNATION>" +  lResultSet.getString("DESIGNATION") +   "</DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("joining_date") )
              lXmlBuffer = lXmlBuffer +   "<JOINING_DATE>" +  lResultSet.getString("JOINING_DATE") +   "</JOINING_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_name") )
              lXmlBuffer = lXmlBuffer +   "<ORG_NAME>" +  lResultSet.getString("ORG_NAME") +   "</ORG_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("working_tech") )
              lXmlBuffer = lXmlBuffer +   "<WORKING_TECH>" +  lResultSet.getString("WORKING_TECH") +   "</WORKING_TECH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("area_of_interest") )
              lXmlBuffer = lXmlBuffer +   "<AREA_OF_INTEREST>" +  lResultSet.getString("AREA_OF_INTEREST") +   "</AREA_OF_INTEREST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("web_page_ind") )
              lXmlBuffer = lXmlBuffer +   "<WEB_PAGE_IND>" +  lResultSet.getString("WEB_PAGE_IND") +   "</WEB_PAGE_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("office_address1") )
              lXmlBuffer = lXmlBuffer +   "<OFFICE_ADDRESS1>" +  lResultSet.getString("OFFICE_ADDRESS1") +   "</OFFICE_ADDRESS1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("office_address2") )
              lXmlBuffer = lXmlBuffer +   "<OFFICE_ADDRESS2>" +  lResultSet.getString("OFFICE_ADDRESS2") +   "</OFFICE_ADDRESS2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("city") )
              lXmlBuffer = lXmlBuffer +   "<CITY>" +  lResultSet.getString("CITY") +   "</CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("state") )
              lXmlBuffer = lXmlBuffer +   "<STATE>" +  lResultSet.getString("STATE") +   "</STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("zip") )
              lXmlBuffer = lXmlBuffer +   "<ZIP>" +  lResultSet.getString("ZIP") +   "</ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY>" +  lResultSet.getString("COUNTRY") +   "</COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone_list") )
              lXmlBuffer = lXmlBuffer +   "<PHONE_LIST>" +  lResultSet.getString("PHONE_LIST") +   "</PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_list") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_LIST>" +  lResultSet.getString("EMAIL_LIST") +   "</EMAIL_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fax_list") )
              lXmlBuffer = lXmlBuffer +   "<FAX_LIST>" +  lResultSet.getString("FAX_LIST") +   "</FAX_LIST>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesAlumniProf>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesAlumniProfRecByRowid
               ( String inRowId
               , EesAlumniProfTabObj  outEesAlumniProfTabObj
               )
  {
    sop("gtEesAlumniProfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "student_org_id, "+
                                 "alumni_id, "+
                                 "seq_num, "+
                                 "occupation, "+
                                 "designation, "+
                                 "joining_date, "+
                                 "org_name, "+
                                 "working_tech, "+
                                 "area_of_interest, "+
                                 "web_page_ind, "+
                                 "office_address1, "+
                                 "office_address2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list "+
                         "FROM   EES_ALUMNI_PROF "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesAlumniProfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAlumniProfTabObj.student_org_id  =  lResultSet.getString("STUDENT_ORG_ID");
          outEesAlumniProfTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          outEesAlumniProfTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          outEesAlumniProfTabObj.occupation  =  lResultSet.getString("OCCUPATION");
          outEesAlumniProfTabObj.designation  =  lResultSet.getString("DESIGNATION");
          outEesAlumniProfTabObj.joining_date  =  lResultSet.getString("JOINING_DATE");

          if ( outEesAlumniProfTabObj.joining_date != null && outEesAlumniProfTabObj.joining_date.length() > 0 ) 
            outEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
          outEesAlumniProfTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          outEesAlumniProfTabObj.working_tech  =  lResultSet.getString("WORKING_TECH");
          outEesAlumniProfTabObj.area_of_interest  =  lResultSet.getString("AREA_OF_INTEREST");
          outEesAlumniProfTabObj.web_page_ind  =  lResultSet.getString("WEB_PAGE_IND");
          outEesAlumniProfTabObj.office_address1  =  lResultSet.getString("OFFICE_ADDRESS1");
          outEesAlumniProfTabObj.office_address2  =  lResultSet.getString("OFFICE_ADDRESS2");
          outEesAlumniProfTabObj.city  =  lResultSet.getString("CITY");
          outEesAlumniProfTabObj.state  =  lResultSet.getString("STATE");
          outEesAlumniProfTabObj.zip  =  lResultSet.getString("ZIP");
          outEesAlumniProfTabObj.country  =  lResultSet.getString("COUNTRY");
          outEesAlumniProfTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAlumniProfTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAlumniProfTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAlumniProfTabObj( outEesAlumniProfTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfArr
               ( String inEesAlumniProfWhereText
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {
    sop("gtEesAlumniProfArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "student_org_id, "+
                                 "alumni_id, "+
                                 "seq_num, "+
                                 "occupation, "+
                                 "designation, "+
                                 "joining_date, "+
                                 "org_name, "+
                                 "working_tech, "+
                                 "area_of_interest, "+
                                 "web_page_ind, "+
                                 "office_address1, "+
                                 "office_address2, "+
                                 "city, "+
                                 "state, "+
                                 "zip, "+
                                 "country, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAlumniProfTabObj  lEesAlumniProfTabObj = new EesAlumniProfTabObj();
          lEesAlumniProfTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesAlumniProfTabObj.student_org_id  =  lResultSet.getString("STUDENT_ORG_ID");
          lEesAlumniProfTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          lEesAlumniProfTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
          lEesAlumniProfTabObj.occupation  =  lResultSet.getString("OCCUPATION");
          lEesAlumniProfTabObj.designation  =  lResultSet.getString("DESIGNATION");
          lEesAlumniProfTabObj.joining_date  =  lResultSet.getString("JOINING_DATE");

          if ( lEesAlumniProfTabObj.joining_date != null && lEesAlumniProfTabObj.joining_date.length() > 0 ) 
            lEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
          lEesAlumniProfTabObj.org_name  =  lResultSet.getString("ORG_NAME");
          lEesAlumniProfTabObj.working_tech  =  lResultSet.getString("WORKING_TECH");
          lEesAlumniProfTabObj.area_of_interest  =  lResultSet.getString("AREA_OF_INTEREST");
          lEesAlumniProfTabObj.web_page_ind  =  lResultSet.getString("WEB_PAGE_IND");
          lEesAlumniProfTabObj.office_address1  =  lResultSet.getString("OFFICE_ADDRESS1");
          lEesAlumniProfTabObj.office_address2  =  lResultSet.getString("OFFICE_ADDRESS2");
          lEesAlumniProfTabObj.city  =  lResultSet.getString("CITY");
          lEesAlumniProfTabObj.state  =  lResultSet.getString("STATE");
          lEesAlumniProfTabObj.zip  =  lResultSet.getString("ZIP");
          lEesAlumniProfTabObj.country  =  lResultSet.getString("COUNTRY");
          lEesAlumniProfTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAlumniProfTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAlumniProfTabObj.fax_list  =  lResultSet.getString("FAX_LIST");

          removeNullEesAlumniProfTabObj( lEesAlumniProfTabObj );

          outEesAlumniProfTabObjArr.add(  lEesAlumniProfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniProfTabObjArr != null && outEesAlumniProfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfArrDist
               ( String inEesAlumniProfWhereText
               , String inDistEesAlumniProfField
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {

    sop("gtEesAlumniProfArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";
  

       String lDistEesAlumniProfFieldQry = inDistEesAlumniProfField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAlumniProfFieldQry+
                         " FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAlumniProfField.substring(inDistEesAlumniProfField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesAlumniProfTabObj  lEesAlumniProfTabObj = new EesAlumniProfTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_org_id") )
              lEesAlumniProfTabObj.student_org_id  =  lResultSet.getString("STUDENT_ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("alumni_id") )
              lEesAlumniProfTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("seq_num") )
              lEesAlumniProfTabObj.seq_num  =  lResultSet.getInt("SEQ_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("occupation") )
              lEesAlumniProfTabObj.occupation  =  lResultSet.getString("OCCUPATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("designation") )
              lEesAlumniProfTabObj.designation  =  lResultSet.getString("DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("joining_date") )
              {
              lEesAlumniProfTabObj.joining_date  =  lResultSet.getString("JOINING_DATE");
  
          if ( lEesAlumniProfTabObj.joining_date != null && lEesAlumniProfTabObj.joining_date.length() > 0 ) 
            lEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniProfTabObj.joining_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_name") )
              lEesAlumniProfTabObj.org_name  =  lResultSet.getString("ORG_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("working_tech") )
              lEesAlumniProfTabObj.working_tech  =  lResultSet.getString("WORKING_TECH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("area_of_interest") )
              lEesAlumniProfTabObj.area_of_interest  =  lResultSet.getString("AREA_OF_INTEREST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("web_page_ind") )
              lEesAlumniProfTabObj.web_page_ind  =  lResultSet.getString("WEB_PAGE_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("office_address1") )
              lEesAlumniProfTabObj.office_address1  =  lResultSet.getString("OFFICE_ADDRESS1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("office_address2") )
              lEesAlumniProfTabObj.office_address2  =  lResultSet.getString("OFFICE_ADDRESS2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("city") )
              lEesAlumniProfTabObj.city  =  lResultSet.getString("CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("state") )
              lEesAlumniProfTabObj.state  =  lResultSet.getString("STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("zip") )
              lEesAlumniProfTabObj.zip  =  lResultSet.getString("ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country") )
              lEesAlumniProfTabObj.country  =  lResultSet.getString("COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone_list") )
              lEesAlumniProfTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_list") )
              lEesAlumniProfTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fax_list") )
              lEesAlumniProfTabObj.fax_list  =  lResultSet.getString("FAX_LIST");

          }
          removeNullEesAlumniProfTabObj( lEesAlumniProfTabObj );

          outEesAlumniProfTabObjArr.add(  lEesAlumniProfTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniProfTabObjArr != null && outEesAlumniProfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniProfStrArrDist
               ( String inEesAlumniProfWhereText
               , String inDistEesAlumniProfField
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {

    sop("gtEesAlumniProfStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniProfStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";
  

       String lDistEesAlumniProfFieldQry = inDistEesAlumniProfField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAlumniProfFieldQry+
                         " FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAlumniProfField.substring(inDistEesAlumniProfField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesAlumniProfTabObjStr = "";
       while(lResultSet.next())
       {
          lEesAlumniProfTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesAlumniProfTabObjStr =   lEesAlumniProfTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesAlumniProfTabObjArr.add(  lEesAlumniProfTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniProfTabObjArr != null && outEesAlumniProfTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesAlumniProf
               ( String inEesAlumniProfWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesAlumniProf - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesAlumniProf";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesAlumniProfTabObj
               ( 
                 EesAlumniProfTabObj  outEesAlumniProfTabObj
               )
  {
  
    if ( outEesAlumniProfTabObj.student_org_id == null ) 
     outEesAlumniProfTabObj.student_org_id = ""; 
    if ( outEesAlumniProfTabObj.alumni_id == null ) 
     outEesAlumniProfTabObj.alumni_id = ""; 
    if ( outEesAlumniProfTabObj.seq_num == (int)0 ) 
     outEesAlumniProfTabObj.seq_num = (int)0; 
    if ( outEesAlumniProfTabObj.occupation == null ) 
     outEesAlumniProfTabObj.occupation = ""; 
    if ( outEesAlumniProfTabObj.designation == null ) 
     outEesAlumniProfTabObj.designation = ""; 
    if ( outEesAlumniProfTabObj.joining_date == null ) 
     outEesAlumniProfTabObj.joining_date = ""; 
    if ( outEesAlumniProfTabObj.org_name == null ) 
     outEesAlumniProfTabObj.org_name = ""; 
    if ( outEesAlumniProfTabObj.working_tech == null ) 
     outEesAlumniProfTabObj.working_tech = ""; 
    if ( outEesAlumniProfTabObj.area_of_interest == null ) 
     outEesAlumniProfTabObj.area_of_interest = ""; 
    if ( outEesAlumniProfTabObj.web_page_ind == null ) 
     outEesAlumniProfTabObj.web_page_ind = ""; 
    if ( outEesAlumniProfTabObj.office_address1 == null ) 
     outEesAlumniProfTabObj.office_address1 = ""; 
    if ( outEesAlumniProfTabObj.office_address2 == null ) 
     outEesAlumniProfTabObj.office_address2 = ""; 
    if ( outEesAlumniProfTabObj.city == null ) 
     outEesAlumniProfTabObj.city = ""; 
    if ( outEesAlumniProfTabObj.state == null ) 
     outEesAlumniProfTabObj.state = ""; 
    if ( outEesAlumniProfTabObj.zip == null ) 
     outEesAlumniProfTabObj.zip = ""; 
    if ( outEesAlumniProfTabObj.country == null ) 
     outEesAlumniProfTabObj.country = ""; 
    if ( outEesAlumniProfTabObj.phone_list == null ) 
     outEesAlumniProfTabObj.phone_list = ""; 
    if ( outEesAlumniProfTabObj.email_list == null ) 
     outEesAlumniProfTabObj.email_list = ""; 
    if ( outEesAlumniProfTabObj.fax_list == null ) 
     outEesAlumniProfTabObj.fax_list = ""; 
  }





  public int insEesAlumniProfRec
               ( EesAlumniProfTabObj  inEesAlumniProfTabObj )
  {
    int lUpdateCount;
    sop("insEesAlumniProfRec - Started");
    gSSTErrorObj.sourceMethod = "insEesAlumniProfRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniProfTabObj.joining_date != null && inEesAlumniProfTabObj.joining_date.length() > 0 ) 
            inEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniProfTabObj.joining_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ALUMNI_PROF"+
                        "("+
                                "student_org_id,"+
                                "alumni_id,"+
                                "seq_num,"+
                                "occupation,"+
                                "designation,"+
                                "joining_date,"+
                                "org_name,"+
                                "working_tech,"+
                                "area_of_interest,"+
                                "web_page_ind,"+
                                "office_address1,"+
                                "office_address2,"+
                                "city,"+
                                "state,"+
                                "zip,"+
                                "country,"+
                                "phone_list,"+
                                "email_list,"+
                                "fax_list"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.student_org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.alumni_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAlumniProfTabObj.seq_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.occupation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.joining_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.org_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.working_tech+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.area_of_interest+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.web_page_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.office_address1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.office_address2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniProfTabObj.email_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesAlumniProfTabObj.fax_list+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesAlumniProfTabObj.student_org_id);
        lPreparedStatement.setString(2, inEesAlumniProfTabObj.alumni_id);
          lPreparedStatement.setInt(3, inEesAlumniProfTabObj.seq_num);
        lPreparedStatement.setString(4, inEesAlumniProfTabObj.occupation);
        lPreparedStatement.setString(5, inEesAlumniProfTabObj.designation);
        lPreparedStatement.setString(6, inEesAlumniProfTabObj.joining_date);
        lPreparedStatement.setString(7, inEesAlumniProfTabObj.org_name);
        lPreparedStatement.setString(8, inEesAlumniProfTabObj.working_tech);
        lPreparedStatement.setString(9, inEesAlumniProfTabObj.area_of_interest);
        lPreparedStatement.setString(10, inEesAlumniProfTabObj.web_page_ind);
        lPreparedStatement.setString(11, inEesAlumniProfTabObj.office_address1);
        lPreparedStatement.setString(12, inEesAlumniProfTabObj.office_address2);
        lPreparedStatement.setString(13, inEesAlumniProfTabObj.city);
        lPreparedStatement.setString(14, inEesAlumniProfTabObj.state);
        lPreparedStatement.setString(15, inEesAlumniProfTabObj.zip);
        lPreparedStatement.setString(16, inEesAlumniProfTabObj.country);
        lPreparedStatement.setString(17, inEesAlumniProfTabObj.phone_list);
        lPreparedStatement.setString(18, inEesAlumniProfTabObj.email_list);
        lPreparedStatement.setString(19, inEesAlumniProfTabObj.fax_list);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesAlumniProfArr
               ( ArrayList  inEesAlumniProfTabObjArr 
               , String  inRowidFlag )
  {
    EesAlumniProfTabObj  lEesAlumniProfTabObj = new EesAlumniProfTabObj();
    int lUpdateCount;
    sop("insEesAlumniProfArr - Started");
    gSSTErrorObj.sourceMethod = "insEesAlumniProfArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesAlumniProfTabObjArr.size(); lNumRec++ )
      {
        lEesAlumniProfTabObj = (EesAlumniProfTabObj)inEesAlumniProfTabObjArr.get(lNumRec);

          if ( lEesAlumniProfTabObj.joining_date != null && lEesAlumniProfTabObj.joining_date.length() > 0 ) 
            lEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniProfTabObj.joining_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ALUMNI_PROF"+
                        "("+
                        "student_org_id,"+
                        "alumni_id,"+
                        "seq_num,"+
                        "occupation,"+
                        "designation,"+
                        "joining_date,"+
                        "org_name,"+
                        "working_tech,"+
                        "area_of_interest,"+
                        "web_page_ind,"+
                        "office_address1,"+
                        "office_address2,"+
                        "city,"+
                        "state,"+
                        "zip,"+
                        "country,"+
                        "phone_list,"+
                        "email_list,"+
                        "fax_list"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.student_org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.alumni_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAlumniProfTabObj.seq_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.occupation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.joining_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.org_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.working_tech+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.area_of_interest+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.web_page_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.office_address1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.office_address2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniProfTabObj.email_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesAlumniProfTabObj.fax_list+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesAlumniProfTabObj.student_org_id);
            lPreparedStatement.setString(2, lEesAlumniProfTabObj.alumni_id);
              lPreparedStatement.setInt(3, lEesAlumniProfTabObj.seq_num);
            lPreparedStatement.setString(4, lEesAlumniProfTabObj.occupation);
            lPreparedStatement.setString(5, lEesAlumniProfTabObj.designation);
            lPreparedStatement.setString(6, lEesAlumniProfTabObj.joining_date);
            lPreparedStatement.setString(7, lEesAlumniProfTabObj.org_name);
            lPreparedStatement.setString(8, lEesAlumniProfTabObj.working_tech);
            lPreparedStatement.setString(9, lEesAlumniProfTabObj.area_of_interest);
            lPreparedStatement.setString(10, lEesAlumniProfTabObj.web_page_ind);
            lPreparedStatement.setString(11, lEesAlumniProfTabObj.office_address1);
            lPreparedStatement.setString(12, lEesAlumniProfTabObj.office_address2);
            lPreparedStatement.setString(13, lEesAlumniProfTabObj.city);
            lPreparedStatement.setString(14, lEesAlumniProfTabObj.state);
            lPreparedStatement.setString(15, lEesAlumniProfTabObj.zip);
            lPreparedStatement.setString(16, lEesAlumniProfTabObj.country);
            lPreparedStatement.setString(17, lEesAlumniProfTabObj.phone_list);
            lPreparedStatement.setString(18, lEesAlumniProfTabObj.email_list);
            lPreparedStatement.setString(19, lEesAlumniProfTabObj.fax_list);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesAlumniProfReq2Obj
               ( HttpServletRequest inRequest
               , EesAlumniProfTabObj  outEesAlumniProfTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesAlumniProfTabObj.tab_rowid = lTabRowidValue;

    outEesAlumniProfTabObj.student_org_id = inRequest.getParameter("student_org_id");
    outEesAlumniProfTabObj.alumni_id = inRequest.getParameter("alumni_id");
    if ( inRequest.getParameter("seq_num") == null )
      outEesAlumniProfTabObj.seq_num = 0;
    else
    if ( inRequest.getParameter("seq_num").trim().length() == 0 )
      outEesAlumniProfTabObj.seq_num = 0;
    else
      outEesAlumniProfTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num"));
    outEesAlumniProfTabObj.occupation = inRequest.getParameter("occupation");
    outEesAlumniProfTabObj.designation = inRequest.getParameter("designation");
    outEesAlumniProfTabObj.joining_date = inRequest.getParameter("joining_date");
    outEesAlumniProfTabObj.org_name = inRequest.getParameter("org_name");
    outEesAlumniProfTabObj.working_tech = inRequest.getParameter("working_tech");
    outEesAlumniProfTabObj.area_of_interest = inRequest.getParameter("area_of_interest");
    outEesAlumniProfTabObj.web_page_ind = inRequest.getParameter("web_page_ind");
    outEesAlumniProfTabObj.office_address1 = inRequest.getParameter("office_address1");
    outEesAlumniProfTabObj.office_address2 = inRequest.getParameter("office_address2");
    outEesAlumniProfTabObj.city = inRequest.getParameter("city");
    outEesAlumniProfTabObj.state = inRequest.getParameter("state");
    outEesAlumniProfTabObj.zip = inRequest.getParameter("zip");
    outEesAlumniProfTabObj.country = inRequest.getParameter("country");
    outEesAlumniProfTabObj.phone_list = inRequest.getParameter("phone_list");
    outEesAlumniProfTabObj.email_list = inRequest.getParameter("email_list");
    outEesAlumniProfTabObj.fax_list = inRequest.getParameter("fax_list");
    return lReturnValue;
  }


  public int popEesAlumniProfReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAlumniProfTabObj lEesAlumniProfTabObj= new EesAlumniProfTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAlumniProfTabObj.tab_rowid = lTabRowidValue;

      lEesAlumniProfTabObj.student_org_id = inRequest.getParameter("student_org_id_r"+lNumRec);
      lEesAlumniProfTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
      if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
        lEesAlumniProfTabObj.seq_num = 0;
      else
      if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
        lEesAlumniProfTabObj.seq_num = 0;
      else
        lEesAlumniProfTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
      lEesAlumniProfTabObj.occupation = inRequest.getParameter("occupation_r"+lNumRec);
      lEesAlumniProfTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
      lEesAlumniProfTabObj.joining_date = inRequest.getParameter("joining_date_r"+lNumRec);
      lEesAlumniProfTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
      lEesAlumniProfTabObj.working_tech = inRequest.getParameter("working_tech_r"+lNumRec);
      lEesAlumniProfTabObj.area_of_interest = inRequest.getParameter("area_of_interest_r"+lNumRec);
      lEesAlumniProfTabObj.web_page_ind = inRequest.getParameter("web_page_ind_r"+lNumRec);
      lEesAlumniProfTabObj.office_address1 = inRequest.getParameter("office_address1_r"+lNumRec);
      lEesAlumniProfTabObj.office_address2 = inRequest.getParameter("office_address2_r"+lNumRec);
      lEesAlumniProfTabObj.city = inRequest.getParameter("city_r"+lNumRec);
      lEesAlumniProfTabObj.state = inRequest.getParameter("state_r"+lNumRec);
      lEesAlumniProfTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
      lEesAlumniProfTabObj.country = inRequest.getParameter("country_r"+lNumRec);
      lEesAlumniProfTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
      lEesAlumniProfTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
      lEesAlumniProfTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      outEesAlumniProfTabObjArr.add( lEesAlumniProfTabObj);
    }
    return lReturnValue;
  }


  public int popEesAlumniProfReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesAlumniProfTabObj outEesAlumniProfTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_alumni_prof_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesAlumniProfTabObj.tab_rowid = lTabRowidValue;

        outEesAlumniProfTabObj.student_org_id = inRequest.getParameter("student_org_id_r"+lNumRec);
        outEesAlumniProfTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
        if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
          outEesAlumniProfTabObj.seq_num = 0;
        else
        if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
          outEesAlumniProfTabObj.seq_num = 0;
        else
          outEesAlumniProfTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
        outEesAlumniProfTabObj.occupation = inRequest.getParameter("occupation_r"+lNumRec);
        outEesAlumniProfTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
        outEesAlumniProfTabObj.joining_date = inRequest.getParameter("joining_date_r"+lNumRec);
        outEesAlumniProfTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
        outEesAlumniProfTabObj.working_tech = inRequest.getParameter("working_tech_r"+lNumRec);
        outEesAlumniProfTabObj.area_of_interest = inRequest.getParameter("area_of_interest_r"+lNumRec);
        outEesAlumniProfTabObj.web_page_ind = inRequest.getParameter("web_page_ind_r"+lNumRec);
        outEesAlumniProfTabObj.office_address1 = inRequest.getParameter("office_address1_r"+lNumRec);
        outEesAlumniProfTabObj.office_address2 = inRequest.getParameter("office_address2_r"+lNumRec);
        outEesAlumniProfTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        outEesAlumniProfTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        outEesAlumniProfTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        outEesAlumniProfTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        outEesAlumniProfTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        outEesAlumniProfTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        outEesAlumniProfTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesAlumniProfReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAlumniProfTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAlumniProfTabObj lEesAlumniProfTabObj= new EesAlumniProfTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_alumni_prof_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAlumniProfTabObj.tab_rowid = lTabRowidValue;

        lEesAlumniProfTabObj.student_org_id = inRequest.getParameter("student_org_id_r"+lNumRec);
        lEesAlumniProfTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
        if ( inRequest.getParameter("seq_num_r"+lNumRec) == null )
          lEesAlumniProfTabObj.seq_num = 0;
        else
        if ( inRequest.getParameter("seq_num_r"+lNumRec).trim().length() == 0 )
          lEesAlumniProfTabObj.seq_num = 0;
        else
          lEesAlumniProfTabObj.seq_num = Integer.parseInt( inRequest.getParameter("seq_num_r"+lNumRec));
        lEesAlumniProfTabObj.occupation = inRequest.getParameter("occupation_r"+lNumRec);
        lEesAlumniProfTabObj.designation = inRequest.getParameter("designation_r"+lNumRec);
        lEesAlumniProfTabObj.joining_date = inRequest.getParameter("joining_date_r"+lNumRec);
        lEesAlumniProfTabObj.org_name = inRequest.getParameter("org_name_r"+lNumRec);
        lEesAlumniProfTabObj.working_tech = inRequest.getParameter("working_tech_r"+lNumRec);
        lEesAlumniProfTabObj.area_of_interest = inRequest.getParameter("area_of_interest_r"+lNumRec);
        lEesAlumniProfTabObj.web_page_ind = inRequest.getParameter("web_page_ind_r"+lNumRec);
        lEesAlumniProfTabObj.office_address1 = inRequest.getParameter("office_address1_r"+lNumRec);
        lEesAlumniProfTabObj.office_address2 = inRequest.getParameter("office_address2_r"+lNumRec);
        lEesAlumniProfTabObj.city = inRequest.getParameter("city_r"+lNumRec);
        lEesAlumniProfTabObj.state = inRequest.getParameter("state_r"+lNumRec);
        lEesAlumniProfTabObj.zip = inRequest.getParameter("zip_r"+lNumRec);
        lEesAlumniProfTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        lEesAlumniProfTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        lEesAlumniProfTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        lEesAlumniProfTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        outEesAlumniProfTabObjArr.add( lEesAlumniProfTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniProfRecByRowid
               ( String inRowId
               , EesAlumniProfTabObj  inEesAlumniProfTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAlumniProfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniProfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniProfTabObj.joining_date != null && inEesAlumniProfTabObj.joining_date.length() > 0 ) 
            inEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniProfTabObj.joining_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI_PROF ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesAlumniProfTabObj.student_org_id != null  )         lSqlStmt = lSqlStmt + "student_org_id = "+"'"+inEesAlumniProfTabObj.student_org_id+"', ";
      if ( inEesAlumniProfTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = "+"'"+inEesAlumniProfTabObj.alumni_id+"', ";
             lSqlStmt = lSqlStmt + "seq_num = "+inEesAlumniProfTabObj.seq_num+", ";
      if ( inEesAlumniProfTabObj.occupation != null  )         lSqlStmt = lSqlStmt + "occupation = "+"'"+inEesAlumniProfTabObj.occupation+"', ";
      if ( inEesAlumniProfTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = "+"'"+inEesAlumniProfTabObj.designation+"', ";
      if ( inEesAlumniProfTabObj.joining_date != null  )         lSqlStmt = lSqlStmt + "joining_date = "+"'"+inEesAlumniProfTabObj.joining_date+"', ";
      if ( inEesAlumniProfTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = "+"'"+inEesAlumniProfTabObj.org_name+"', ";
      if ( inEesAlumniProfTabObj.working_tech != null  )         lSqlStmt = lSqlStmt + "working_tech = "+"'"+inEesAlumniProfTabObj.working_tech+"', ";
      if ( inEesAlumniProfTabObj.area_of_interest != null  )         lSqlStmt = lSqlStmt + "area_of_interest = "+"'"+inEesAlumniProfTabObj.area_of_interest+"', ";
      if ( inEesAlumniProfTabObj.web_page_ind != null  )         lSqlStmt = lSqlStmt + "web_page_ind = "+"'"+inEesAlumniProfTabObj.web_page_ind+"', ";
      if ( inEesAlumniProfTabObj.office_address1 != null  )         lSqlStmt = lSqlStmt + "office_address1 = "+"'"+inEesAlumniProfTabObj.office_address1+"', ";
      if ( inEesAlumniProfTabObj.office_address2 != null  )         lSqlStmt = lSqlStmt + "office_address2 = "+"'"+inEesAlumniProfTabObj.office_address2+"', ";
      if ( inEesAlumniProfTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inEesAlumniProfTabObj.city+"', ";
      if ( inEesAlumniProfTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inEesAlumniProfTabObj.state+"', ";
      if ( inEesAlumniProfTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inEesAlumniProfTabObj.zip+"', ";
      if ( inEesAlumniProfTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inEesAlumniProfTabObj.country+"', ";
      if ( inEesAlumniProfTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAlumniProfTabObj.phone_list+"', ";
      if ( inEesAlumniProfTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAlumniProfTabObj.email_list+"', ";
      if ( inEesAlumniProfTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAlumniProfTabObj.fax_list+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniProfRecByPkey
               ( EesAlumniProfPkeyObj inEesAlumniProfPkeyObj
               , EesAlumniProfTabObj  inEesAlumniProfTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAlumniProfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniProfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniProfTabObj.joining_date != null && inEesAlumniProfTabObj.joining_date.length() > 0 ) 
            inEesAlumniProfTabObj.joining_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniProfTabObj.joining_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI_PROF ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesAlumniProfTabObj.student_org_id != null  )         lSqlStmt = lSqlStmt + "student_org_id = ? , ";
        if ( inEesAlumniProfTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = ? , ";
               lSqlStmt = lSqlStmt + "seq_num = ? , ";
        if ( inEesAlumniProfTabObj.occupation != null  )         lSqlStmt = lSqlStmt + "occupation = ? , ";
        if ( inEesAlumniProfTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = ? , ";
        if ( inEesAlumniProfTabObj.joining_date != null  )         lSqlStmt = lSqlStmt + "joining_date = ? , ";
        if ( inEesAlumniProfTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = ? , ";
        if ( inEesAlumniProfTabObj.working_tech != null  )         lSqlStmt = lSqlStmt + "working_tech = ? , ";
        if ( inEesAlumniProfTabObj.area_of_interest != null  )         lSqlStmt = lSqlStmt + "area_of_interest = ? , ";
        if ( inEesAlumniProfTabObj.web_page_ind != null  )         lSqlStmt = lSqlStmt + "web_page_ind = ? , ";
        if ( inEesAlumniProfTabObj.office_address1 != null  )         lSqlStmt = lSqlStmt + "office_address1 = ? , ";
        if ( inEesAlumniProfTabObj.office_address2 != null  )         lSqlStmt = lSqlStmt + "office_address2 = ? , ";
        if ( inEesAlumniProfTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = ? , ";
        if ( inEesAlumniProfTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = ? , ";
        if ( inEesAlumniProfTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = ? , ";
        if ( inEesAlumniProfTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = ? , ";
        if ( inEesAlumniProfTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = ? , ";
        if ( inEesAlumniProfTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = ? , ";
        if ( inEesAlumniProfTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesAlumniProfTabObj.student_org_id != null  )         lSqlStmt = lSqlStmt + "student_org_id = "+"'"+inEesAlumniProfTabObj.student_org_id+"', ";
        if ( inEesAlumniProfTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = "+"'"+inEesAlumniProfTabObj.alumni_id+"', ";
               lSqlStmt = lSqlStmt + "seq_num = "+inEesAlumniProfTabObj.seq_num+", ";
        if ( inEesAlumniProfTabObj.occupation != null  )         lSqlStmt = lSqlStmt + "occupation = "+"'"+inEesAlumniProfTabObj.occupation+"', ";
        if ( inEesAlumniProfTabObj.designation != null  )         lSqlStmt = lSqlStmt + "designation = "+"'"+inEesAlumniProfTabObj.designation+"', ";
        if ( inEesAlumniProfTabObj.joining_date != null  )         lSqlStmt = lSqlStmt + "joining_date = "+"'"+inEesAlumniProfTabObj.joining_date+"', ";
        if ( inEesAlumniProfTabObj.org_name != null  )         lSqlStmt = lSqlStmt + "org_name = "+"'"+inEesAlumniProfTabObj.org_name+"', ";
        if ( inEesAlumniProfTabObj.working_tech != null  )         lSqlStmt = lSqlStmt + "working_tech = "+"'"+inEesAlumniProfTabObj.working_tech+"', ";
        if ( inEesAlumniProfTabObj.area_of_interest != null  )         lSqlStmt = lSqlStmt + "area_of_interest = "+"'"+inEesAlumniProfTabObj.area_of_interest+"', ";
        if ( inEesAlumniProfTabObj.web_page_ind != null  )         lSqlStmt = lSqlStmt + "web_page_ind = "+"'"+inEesAlumniProfTabObj.web_page_ind+"', ";
        if ( inEesAlumniProfTabObj.office_address1 != null  )         lSqlStmt = lSqlStmt + "office_address1 = "+"'"+inEesAlumniProfTabObj.office_address1+"', ";
        if ( inEesAlumniProfTabObj.office_address2 != null  )         lSqlStmt = lSqlStmt + "office_address2 = "+"'"+inEesAlumniProfTabObj.office_address2+"', ";
        if ( inEesAlumniProfTabObj.city != null  )         lSqlStmt = lSqlStmt + "city = "+"'"+inEesAlumniProfTabObj.city+"', ";
        if ( inEesAlumniProfTabObj.state != null  )         lSqlStmt = lSqlStmt + "state = "+"'"+inEesAlumniProfTabObj.state+"', ";
        if ( inEesAlumniProfTabObj.zip != null  )         lSqlStmt = lSqlStmt + "zip = "+"'"+inEesAlumniProfTabObj.zip+"', ";
        if ( inEesAlumniProfTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inEesAlumniProfTabObj.country+"', ";
        if ( inEesAlumniProfTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAlumniProfTabObj.phone_list+"', ";
        if ( inEesAlumniProfTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAlumniProfTabObj.email_list+"', ";
        if ( inEesAlumniProfTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAlumniProfTabObj.fax_list+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "student_org_id = "+"'"+inEesAlumniProfPkeyObj.student_org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniProfPkeyObj.alumni_id+"' and "+
                              "seq_num = "+inEesAlumniProfPkeyObj.seq_num+"";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesAlumniProfTabObj.student_org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.student_org_id); } 
         if ( inEesAlumniProfTabObj.alumni_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.alumni_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(3, inEesAlumniProfTabObj.seq_num);
         if ( inEesAlumniProfTabObj.occupation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.occupation); } 
         if ( inEesAlumniProfTabObj.designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.designation); } 
         if ( inEesAlumniProfTabObj.joining_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.joining_date); } 
         if ( inEesAlumniProfTabObj.org_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.org_name); } 
         if ( inEesAlumniProfTabObj.working_tech != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.working_tech); } 
         if ( inEesAlumniProfTabObj.area_of_interest != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.area_of_interest); } 
         if ( inEesAlumniProfTabObj.web_page_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.web_page_ind); } 
         if ( inEesAlumniProfTabObj.office_address1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.office_address1); } 
         if ( inEesAlumniProfTabObj.office_address2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.office_address2); } 
         if ( inEesAlumniProfTabObj.city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.city); } 
         if ( inEesAlumniProfTabObj.state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.state); } 
         if ( inEesAlumniProfTabObj.zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.zip); } 
         if ( inEesAlumniProfTabObj.country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.country); } 
         if ( inEesAlumniProfTabObj.phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.phone_list); } 
         if ( inEesAlumniProfTabObj.email_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.email_list); } 
         if ( inEesAlumniProfTabObj.fax_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniProfTabObj.fax_list); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniProfRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesAlumniProfRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniProfRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_ALUMNI_PROF "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniProfRecByPkeyWithSet
               ( EesAlumniProfPkeyObj inEesAlumniProfPkeyObj
               , String  inEesAlumniProfSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniProfRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniProfRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI_PROF ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAlumniProfSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "student_org_id = "+"'"+inEesAlumniProfPkeyObj.student_org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniProfPkeyObj.alumni_id+"' and "+
                              "seq_num = "+inEesAlumniProfPkeyObj.seq_num+"";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniProfRecByRowidWithSet
               ( String inRowId
               , String  inEesAlumniProfSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniProfRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniProfRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI_PROF ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAlumniProfSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniProfRecByWhereWithSet
               ( String inEesAlumniProfWhereText
               , String  inEesAlumniProfSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniProfRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniProfRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI_PROF ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesAlumniProfSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniProfRecByPkey
               ( EesAlumniProfPkeyObj  inEesAlumniProfPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesAlumniProfRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniProfRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_ALUMNI_PROF " + 
                         "WHERE "+
                              "student_org_id = "+"'"+inEesAlumniProfPkeyObj.student_org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniProfPkeyObj.alumni_id+"' and "+
                              "seq_num = "+inEesAlumniProfPkeyObj.seq_num+"";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniProfByWhere
               ( String inEesAlumniProfWhereText
               )
  {
    int lUpdateCount;
    sop("delEesAlumniProfByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniProfByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniProfWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniProfWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_ALUMNI_PROF "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
