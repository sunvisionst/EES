package sstdb.ees.EesAdmSub;


public class EesAdmSubTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 academic_session;
  public String                                 subject_code;
  public String                                 class_num;
  public String                                 course_id;
  public String                                 class_std;
  public String                                 course_term;
  public String                                 course_stream;
  public int                                  max_mark;
  public int                                  min_mark;
  public String                                 description;





  public short                                  org_id_ind;
  public short                                  academic_session_ind;
  public short                                  subject_code_ind;
  public short                                  class_num_ind;
  public short                                  course_id_ind;
  public short                                  class_std_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  max_mark_ind;
  public short                                  min_mark_ind;
  public short                                  description_ind;


  public EesAdmSubTabObj(){}


  public EesAdmSubTabObj
  (
    String org_id,
    String academic_session,
    String subject_code,
    String class_num,
    String course_id,
    String class_std,
    String course_term,
    String course_stream,
    int max_mark,
    int min_mark,
    String description
  )
  {
     this.org_id = org_id;
     this.academic_session = academic_session;
     this.subject_code = subject_code;
     this.class_num = class_num;
     this.course_id = course_id;
     this.class_std = class_std;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.max_mark = max_mark;
     this.min_mark = min_mark;
     this.description = description;
  }

  public String getorg_id()                           { return org_id; }
  public String getacademic_session()                      { return academic_session; }
  public String getsubject_code()                        { return subject_code; }
  public String getclass_num()                         { return class_num; }
  public String getcourse_id()                         { return course_id; }
  public String getclass_std()                         { return class_std; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public int getmax_mark()                           { return max_mark; }
  public int getmin_mark()                           { return min_mark; }
  public String getdescription()                        { return description; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setsubject_code(String subject_code )              { this.subject_code = subject_code; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setmax_mark(int max_mark )                    { this.max_mark = max_mark; }
  public void  setmin_mark(int min_mark )                    { this.min_mark = min_mark; }
  public void  setdescription(String description )               { this.description = description; }
}