package sstdb.ees.EesAppcAcademic;


public class EesAppcAcademicPkeyObj
{
  public String                                 org_id;
  public String                                 applicant_id;
  public int                                  seq_num;
}