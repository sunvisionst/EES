package sstdb.ees.EesAdmSub;


public class EesAdmSubPkeyObj
{
  public String                                 org_id;
  public String                                 academic_session;
  public String                                 subject_code;
  public String                                 class_num;
  public String                                 course_id;
}