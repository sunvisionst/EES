
var lEesClassTabObjJSArr = new Array();
<%
{
   if ( lEesClassTabObjArrCache != null && lEesClassTabObjArrCache.size() > 0 )
   {
%>
       lEesClassTabObjJSArr = new Array(<%=lEesClassTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesClassTabObjArrCache.size(); lRecNum++ )
       {
          EesClassTabObj lEesClassTabObj    =    new EesClassTabObj();
          lEesClassTabObj = (EesClassTabObj)lEesClassTabObjArrCache.get(lRecNum);
%>
          lEesClassTabObjJSArr[<%=lRecNum%>] = new constructorEesClass
          (
          "<%=lEesClassTabObj.org_id%>",
          "<%=lEesClassTabObj.class_id%>",
          "<%=lEesClassTabObj.class_num%>",
          "<%=lEesClassTabObj.class_std%>",
          "<%=lEesClassTabObj.class_section%>",
          "<%=lEesClassTabObj.course_id%>",
          "<%=lEesClassTabObj.course_term%>",
          "<%=lEesClassTabObj.course_stream%>",
          "<%=lEesClassTabObj.description%>",
          "<%=lEesClassTabObj.duration_type%>",
          "<%=lEesClassTabObj.course_duration%>",
          "<%=lEesClassTabObj.remark%>",
          "<%=lEesClassTabObj.upgrade_ind%>",
          "<%=lEesClassTabObj.run_ind%>",
          "<%=lEesClassTabObj.room_num%>",
          "<%=lEesClassTabObj.building_id%>",
          "<%=lEesClassTabObj.room_share_ind%>",
          "<%=lEesClassTabObj.class_teacher%>",
          "<%=lEesClassTabObj.stream_ind%>",
          "<%=lEesClassTabObj.shift_code%>"
          );
<%
       }
   }
}
%>


