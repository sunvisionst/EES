CREATE TABLE EES_APPC_REF
(
  ORG_ID                                                                                              VARCHAR(10),
  APPLICANT_ID                                                                                        VARCHAR(25),
  SEQ_NUM                                                                                             NUMERIC(2),
  APPLICATION_FORM_NUM                                                                                VARCHAR(20),
  STUDENT_ID                                                                                          VARCHAR(25),
  ROLL_NUM                                                                                            VARCHAR(20),
  REF_NAME                                                                                            VARCHAR(100),
  ADDRESS_1                                                                                           VARCHAR(100),
  ADDRESS_2                                                                                           VARCHAR(100),
  PHONE_LIST                                                                                          VARCHAR(100),
  EMAIL_LIST                                                                                          VARCHAR(100),
  FAX_LIST                                                                                            VARCHAR(100),
  ADM_REQ_ID_REQ                                                                                      VARCHAR(30),
  ADM_REQ_ID_LIST                                                                                     VARCHAR(30)
)
 WITH OIDS;
