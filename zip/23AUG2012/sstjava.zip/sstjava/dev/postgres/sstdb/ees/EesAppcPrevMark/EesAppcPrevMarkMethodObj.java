package sstdb.ees.EesAppcPrevMark;

import sstdb.ees.EesAppcPrevMark.EesAppcPrevMarkTabObj;
import sstdb.ees.EesAppcPrevMark.EesAppcPrevMarkPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesAppcPrevMarkMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesAppcPrevMarkMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesAppcPrevMarkMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesAppcPrevMarkTabObj
               ( 
                 EesAppcPrevMarkTabObj  outEesAppcPrevMarkTabObj
               )
  {
  
     outEesAppcPrevMarkTabObj.org_id = ""; 
     outEesAppcPrevMarkTabObj.applicant_id = ""; 
     outEesAppcPrevMarkTabObj.stmm_1 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmo_1 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmm_1 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmo_1 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmm_2 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmo_2 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmm_2 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmo_2 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmm_3 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmo_3 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmm_3 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmo_3 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmm_4 = (float)0.00; 
     outEesAppcPrevMarkTabObj.stmo_4 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmm_4 = (float)0.00; 
     outEesAppcPrevMarkTabObj.spmo_4 = (float)0.00; 
     outEesAppcPrevMarkTabObj.adm_req_id_req = ""; 
     outEesAppcPrevMarkTabObj.adm_req_id_list = ""; 
  }





  public void guiDateConvEesAppcPrevMarkTabObj
               ( 
                 EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;
  }





  public void refreshCtxEesAppcPrevMarkByTabObj
               ( 
                 EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesAppcPrevMarkTabObjArrCtx  = new ArrayList(); 
    lEesAppcPrevMarkTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesAppcPrevMarkTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesAppcPrevMarkTabObjArrCtx.add(inEesAppcPrevMarkTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesAppcPrevMarkTabObjArrCtx.size();  lRecNum++ )
      {
        EesAppcPrevMarkTabObj lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj();
        lEesAppcPrevMarkTabObj = (EesAppcPrevMarkTabObj)lEesAppcPrevMarkTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesAppcPrevMarkTabObj.org_id.equals(lEesAppcPrevMarkTabObj.org_id) &&
              lEesAppcPrevMarkTabObj.applicant_id.equals(lEesAppcPrevMarkTabObj.applicant_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesAppcPrevMarkTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesAppcPrevMarkTabObjArrCtx.set(lRecNum, inEesAppcPrevMarkTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesAppcPrevMarkTabObjArrCtx",lEesAppcPrevMarkTabObjArrCtx);
  }





  public void sortEesAppcPrevMarkTabObjArr
               ( 
                 ArrayList  inEesAppcPrevMarkTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesAppcPrevMarkTabObjArr  = new ArrayList(); 
     lEesAppcPrevMarkTabObjArr = inEesAppcPrevMarkTabObjArr; 
     List lEesAppcPrevMarkTabObjList  = new ArrayList(lEesAppcPrevMarkTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesAppcPrevMarkTabObjArr.size();  lRecNum++ )
     {
       EesAppcPrevMarkTabObj  lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj(); 
       lEesAppcPrevMarkTabObj = (EesAppcPrevMarkTabObj)lEesAppcPrevMarkTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAppcPrevMarkTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("applicant_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (25 - lEesAppcPrevMarkTabObj.applicant_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.applicant_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmm_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmm_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmm_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmo_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmo_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmo_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmm_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmm_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmm_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmo_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmo_1).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmo_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmm_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmm_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmm_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmo_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmo_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmo_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmm_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmm_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmm_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmo_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmo_2).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmo_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmm_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmm_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmm_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmo_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmo_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmo_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmm_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmm_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmm_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmo_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmo_3).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmo_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmm_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmm_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmm_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stmo_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.stmo_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.stmo_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmm_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmm_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmm_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("spmo_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Float.toString(lEesAppcPrevMarkTabObj.spmo_4).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.spmo_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_req") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAppcPrevMarkTabObj.adm_req_id_req.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.adm_req_id_req+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAppcPrevMarkTabObj.adm_req_id_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAppcPrevMarkTabObj.adm_req_id_list+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesAppcPrevMarkTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesAppcPrevMarkTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesAppcPrevMarkTabObjList ); 
     ArrayList lEesAppcPrevMarkTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesAppcPrevMarkTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesAppcPrevMarkTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesAppcPrevMarkTabObjArrSorted.add( (EesAppcPrevMarkTabObj)lEesAppcPrevMarkTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesAppcPrevMarkTabObjArr.size();  lRecNum++ )
     {
       inEesAppcPrevMarkTabObjArr.set( lRecNum, (EesAppcPrevMarkTabObj)lEesAppcPrevMarkTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesAppcPrevMarkTabObj
               ( 
                 EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicantId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 25 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICANT_ID";
      String lErrorReason = "Size Greater Than 25";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmm1
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMM_1";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmo1
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMO_1";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmm1
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMM_1";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmo1
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMO_1";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmm2
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMM_2";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmo2
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMO_2";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmm2
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMM_2";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmo2
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMO_2";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmm3
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMM_3";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmo3
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMO_3";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmm3
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMM_3";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmo3
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMO_3";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmm4
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMM_4";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStmo4
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STMO_4";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmm4
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMM_4";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSpmo4
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SPMO_4";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdReq
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_REQ";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_LIST";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesAppcPrevMarkCount
               ( String inEesAppcPrevMarkWhereText
               )
  {
    sop("gtEesAppcPrevMarkCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkCount
               ( String inEesAppcPrevMarkWhereText
               , String inEesAppcPrevMarkSelectFieldList
               )
  {
    sop("gtEesAppcPrevMarkCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesAppcPrevMarkSelectFieldList+" AS count "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkRecByPkey
               ( EesAppcPrevMarkPkeyObj inEesAppcPrevMarkPkeyObj
               , EesAppcPrevMarkTabObj  outEesAppcPrevMarkTabObj
               )
  {
    sop("gtEesAppcPrevMarkRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "applicant_id, "+
                                 "stmm_1, "+
                                 "stmo_1, "+
                                 "spmm_1, "+
                                 "spmo_1, "+
                                 "stmm_2, "+
                                 "stmo_2, "+
                                 "spmm_2, "+
                                 "spmo_2, "+
                                 "stmm_3, "+
                                 "stmo_3, "+
                                 "spmm_3, "+
                                 "spmo_3, "+
                                 "stmm_4, "+
                                 "stmo_4, "+
                                 "spmm_4, "+
                                 "spmo_4, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_APPC_PREV_MARK " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAppcPrevMarkPkeyObj.org_id+"' and "+
                              "applicant_id = "+"'"+inEesAppcPrevMarkPkeyObj.applicant_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesAppcPrevMarkTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAppcPrevMarkTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAppcPrevMarkTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAppcPrevMarkTabObj.stmm_1  =  lResultSet.getFloat("STMM_1");
          outEesAppcPrevMarkTabObj.stmo_1  =  lResultSet.getFloat("STMO_1");
          outEesAppcPrevMarkTabObj.spmm_1  =  lResultSet.getFloat("SPMM_1");
          outEesAppcPrevMarkTabObj.spmo_1  =  lResultSet.getFloat("SPMO_1");
          outEesAppcPrevMarkTabObj.stmm_2  =  lResultSet.getFloat("STMM_2");
          outEesAppcPrevMarkTabObj.stmo_2  =  lResultSet.getFloat("STMO_2");
          outEesAppcPrevMarkTabObj.spmm_2  =  lResultSet.getFloat("SPMM_2");
          outEesAppcPrevMarkTabObj.spmo_2  =  lResultSet.getFloat("SPMO_2");
          outEesAppcPrevMarkTabObj.stmm_3  =  lResultSet.getFloat("STMM_3");
          outEesAppcPrevMarkTabObj.stmo_3  =  lResultSet.getFloat("STMO_3");
          outEesAppcPrevMarkTabObj.spmm_3  =  lResultSet.getFloat("SPMM_3");
          outEesAppcPrevMarkTabObj.spmo_3  =  lResultSet.getFloat("SPMO_3");
          outEesAppcPrevMarkTabObj.stmm_4  =  lResultSet.getFloat("STMM_4");
          outEesAppcPrevMarkTabObj.stmo_4  =  lResultSet.getFloat("STMO_4");
          outEesAppcPrevMarkTabObj.spmm_4  =  lResultSet.getFloat("SPMM_4");
          outEesAppcPrevMarkTabObj.spmo_4  =  lResultSet.getFloat("SPMO_4");
          outEesAppcPrevMarkTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAppcPrevMarkTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAppcPrevMarkTabObj( outEesAppcPrevMarkTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkArr
               ( EesAppcPrevMarkPkeyObj inEesAppcPrevMarkPkeyObj
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {
    sop("gtEesAppcPrevMarkArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "applicant_id, "+
                                 "stmm_1, "+
                                 "stmo_1, "+
                                 "spmm_1, "+
                                 "spmo_1, "+
                                 "stmm_2, "+
                                 "stmo_2, "+
                                 "spmm_2, "+
                                 "spmo_2, "+
                                 "stmm_3, "+
                                 "stmo_3, "+
                                 "spmm_3, "+
                                 "spmo_3, "+
                                 "stmm_4, "+
                                 "stmo_4, "+
                                 "spmm_4, "+
                                 "spmo_4, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_APPC_PREV_MARK";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAppcPrevMarkTabObj  lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj();
          lEesAppcPrevMarkTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesAppcPrevMarkTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAppcPrevMarkTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAppcPrevMarkTabObj.stmm_1  =  lResultSet.getFloat("STMM_1");
          lEesAppcPrevMarkTabObj.stmo_1  =  lResultSet.getFloat("STMO_1");
          lEesAppcPrevMarkTabObj.spmm_1  =  lResultSet.getFloat("SPMM_1");
          lEesAppcPrevMarkTabObj.spmo_1  =  lResultSet.getFloat("SPMO_1");
          lEesAppcPrevMarkTabObj.stmm_2  =  lResultSet.getFloat("STMM_2");
          lEesAppcPrevMarkTabObj.stmo_2  =  lResultSet.getFloat("STMO_2");
          lEesAppcPrevMarkTabObj.spmm_2  =  lResultSet.getFloat("SPMM_2");
          lEesAppcPrevMarkTabObj.spmo_2  =  lResultSet.getFloat("SPMO_2");
          lEesAppcPrevMarkTabObj.stmm_3  =  lResultSet.getFloat("STMM_3");
          lEesAppcPrevMarkTabObj.stmo_3  =  lResultSet.getFloat("STMO_3");
          lEesAppcPrevMarkTabObj.spmm_3  =  lResultSet.getFloat("SPMM_3");
          lEesAppcPrevMarkTabObj.spmo_3  =  lResultSet.getFloat("SPMO_3");
          lEesAppcPrevMarkTabObj.stmm_4  =  lResultSet.getFloat("STMM_4");
          lEesAppcPrevMarkTabObj.stmo_4  =  lResultSet.getFloat("STMO_4");
          lEesAppcPrevMarkTabObj.spmm_4  =  lResultSet.getFloat("SPMM_4");
          lEesAppcPrevMarkTabObj.spmo_4  =  lResultSet.getFloat("SPMO_4");
          lEesAppcPrevMarkTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAppcPrevMarkTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAppcPrevMarkTabObj( lEesAppcPrevMarkTabObj );

          outEesAppcPrevMarkTabObjArr.add(  lEesAppcPrevMarkTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAppcPrevMarkTabObjArr != null && outEesAppcPrevMarkTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesAppcPrevMarkArr2XML
               ( String inEesAppcPrevMarkWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesAppcPrevMarkArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesAppcPrevMark>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("applicant_id") )
              lXmlBuffer = lXmlBuffer +   "<APPLICANT_ID>" +  lResultSet.getString("APPLICANT_ID") +   "</APPLICANT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmm_1") )
              lXmlBuffer = lXmlBuffer +   "<STMM_1>" +  lResultSet.getFloat("STMM_1") +   "</STMM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmo_1") )
              lXmlBuffer = lXmlBuffer +   "<STMO_1>" +  lResultSet.getFloat("STMO_1") +   "</STMO_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmm_1") )
              lXmlBuffer = lXmlBuffer +   "<SPMM_1>" +  lResultSet.getFloat("SPMM_1") +   "</SPMM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmo_1") )
              lXmlBuffer = lXmlBuffer +   "<SPMO_1>" +  lResultSet.getFloat("SPMO_1") +   "</SPMO_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmm_2") )
              lXmlBuffer = lXmlBuffer +   "<STMM_2>" +  lResultSet.getFloat("STMM_2") +   "</STMM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmo_2") )
              lXmlBuffer = lXmlBuffer +   "<STMO_2>" +  lResultSet.getFloat("STMO_2") +   "</STMO_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmm_2") )
              lXmlBuffer = lXmlBuffer +   "<SPMM_2>" +  lResultSet.getFloat("SPMM_2") +   "</SPMM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmo_2") )
              lXmlBuffer = lXmlBuffer +   "<SPMO_2>" +  lResultSet.getFloat("SPMO_2") +   "</SPMO_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmm_3") )
              lXmlBuffer = lXmlBuffer +   "<STMM_3>" +  lResultSet.getFloat("STMM_3") +   "</STMM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmo_3") )
              lXmlBuffer = lXmlBuffer +   "<STMO_3>" +  lResultSet.getFloat("STMO_3") +   "</STMO_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmm_3") )
              lXmlBuffer = lXmlBuffer +   "<SPMM_3>" +  lResultSet.getFloat("SPMM_3") +   "</SPMM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmo_3") )
              lXmlBuffer = lXmlBuffer +   "<SPMO_3>" +  lResultSet.getFloat("SPMO_3") +   "</SPMO_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmm_4") )
              lXmlBuffer = lXmlBuffer +   "<STMM_4>" +  lResultSet.getFloat("STMM_4") +   "</STMM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stmo_4") )
              lXmlBuffer = lXmlBuffer +   "<STMO_4>" +  lResultSet.getFloat("STMO_4") +   "</STMO_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmm_4") )
              lXmlBuffer = lXmlBuffer +   "<SPMM_4>" +  lResultSet.getFloat("SPMM_4") +   "</SPMM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("spmo_4") )
              lXmlBuffer = lXmlBuffer +   "<SPMO_4>" +  lResultSet.getFloat("SPMO_4") +   "</SPMO_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_req") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_REQ>" +  lResultSet.getString("ADM_REQ_ID_REQ") +   "</ADM_REQ_ID_REQ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_list") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_LIST>" +  lResultSet.getString("ADM_REQ_ID_LIST") +   "</ADM_REQ_ID_LIST>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesAppcPrevMark>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesAppcPrevMarkRecByRowid
               ( String inRowId
               , EesAppcPrevMarkTabObj  outEesAppcPrevMarkTabObj
               )
  {
    sop("gtEesAppcPrevMarkRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "applicant_id, "+
                                 "stmm_1, "+
                                 "stmo_1, "+
                                 "spmm_1, "+
                                 "spmo_1, "+
                                 "stmm_2, "+
                                 "stmo_2, "+
                                 "spmm_2, "+
                                 "spmo_2, "+
                                 "stmm_3, "+
                                 "stmo_3, "+
                                 "spmm_3, "+
                                 "spmo_3, "+
                                 "stmm_4, "+
                                 "stmo_4, "+
                                 "spmm_4, "+
                                 "spmo_4, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_APPC_PREV_MARK "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesAppcPrevMarkTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAppcPrevMarkTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAppcPrevMarkTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAppcPrevMarkTabObj.stmm_1  =  lResultSet.getFloat("STMM_1");
          outEesAppcPrevMarkTabObj.stmo_1  =  lResultSet.getFloat("STMO_1");
          outEesAppcPrevMarkTabObj.spmm_1  =  lResultSet.getFloat("SPMM_1");
          outEesAppcPrevMarkTabObj.spmo_1  =  lResultSet.getFloat("SPMO_1");
          outEesAppcPrevMarkTabObj.stmm_2  =  lResultSet.getFloat("STMM_2");
          outEesAppcPrevMarkTabObj.stmo_2  =  lResultSet.getFloat("STMO_2");
          outEesAppcPrevMarkTabObj.spmm_2  =  lResultSet.getFloat("SPMM_2");
          outEesAppcPrevMarkTabObj.spmo_2  =  lResultSet.getFloat("SPMO_2");
          outEesAppcPrevMarkTabObj.stmm_3  =  lResultSet.getFloat("STMM_3");
          outEesAppcPrevMarkTabObj.stmo_3  =  lResultSet.getFloat("STMO_3");
          outEesAppcPrevMarkTabObj.spmm_3  =  lResultSet.getFloat("SPMM_3");
          outEesAppcPrevMarkTabObj.spmo_3  =  lResultSet.getFloat("SPMO_3");
          outEesAppcPrevMarkTabObj.stmm_4  =  lResultSet.getFloat("STMM_4");
          outEesAppcPrevMarkTabObj.stmo_4  =  lResultSet.getFloat("STMO_4");
          outEesAppcPrevMarkTabObj.spmm_4  =  lResultSet.getFloat("SPMM_4");
          outEesAppcPrevMarkTabObj.spmo_4  =  lResultSet.getFloat("SPMO_4");
          outEesAppcPrevMarkTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAppcPrevMarkTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAppcPrevMarkTabObj( outEesAppcPrevMarkTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkArr
               ( String inEesAppcPrevMarkWhereText
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {
    sop("gtEesAppcPrevMarkArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "applicant_id, "+
                                 "stmm_1, "+
                                 "stmo_1, "+
                                 "spmm_1, "+
                                 "spmo_1, "+
                                 "stmm_2, "+
                                 "stmo_2, "+
                                 "spmm_2, "+
                                 "spmo_2, "+
                                 "stmm_3, "+
                                 "stmo_3, "+
                                 "spmm_3, "+
                                 "spmo_3, "+
                                 "stmm_4, "+
                                 "stmo_4, "+
                                 "spmm_4, "+
                                 "spmo_4, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAppcPrevMarkTabObj  lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj();
          lEesAppcPrevMarkTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesAppcPrevMarkTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAppcPrevMarkTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAppcPrevMarkTabObj.stmm_1  =  lResultSet.getFloat("STMM_1");
          lEesAppcPrevMarkTabObj.stmo_1  =  lResultSet.getFloat("STMO_1");
          lEesAppcPrevMarkTabObj.spmm_1  =  lResultSet.getFloat("SPMM_1");
          lEesAppcPrevMarkTabObj.spmo_1  =  lResultSet.getFloat("SPMO_1");
          lEesAppcPrevMarkTabObj.stmm_2  =  lResultSet.getFloat("STMM_2");
          lEesAppcPrevMarkTabObj.stmo_2  =  lResultSet.getFloat("STMO_2");
          lEesAppcPrevMarkTabObj.spmm_2  =  lResultSet.getFloat("SPMM_2");
          lEesAppcPrevMarkTabObj.spmo_2  =  lResultSet.getFloat("SPMO_2");
          lEesAppcPrevMarkTabObj.stmm_3  =  lResultSet.getFloat("STMM_3");
          lEesAppcPrevMarkTabObj.stmo_3  =  lResultSet.getFloat("STMO_3");
          lEesAppcPrevMarkTabObj.spmm_3  =  lResultSet.getFloat("SPMM_3");
          lEesAppcPrevMarkTabObj.spmo_3  =  lResultSet.getFloat("SPMO_3");
          lEesAppcPrevMarkTabObj.stmm_4  =  lResultSet.getFloat("STMM_4");
          lEesAppcPrevMarkTabObj.stmo_4  =  lResultSet.getFloat("STMO_4");
          lEesAppcPrevMarkTabObj.spmm_4  =  lResultSet.getFloat("SPMM_4");
          lEesAppcPrevMarkTabObj.spmo_4  =  lResultSet.getFloat("SPMO_4");
          lEesAppcPrevMarkTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAppcPrevMarkTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAppcPrevMarkTabObj( lEesAppcPrevMarkTabObj );

          outEesAppcPrevMarkTabObjArr.add(  lEesAppcPrevMarkTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAppcPrevMarkTabObjArr != null && outEesAppcPrevMarkTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkArrDist
               ( String inEesAppcPrevMarkWhereText
               , String inDistEesAppcPrevMarkField
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {

    sop("gtEesAppcPrevMarkArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";
  

       String lDistEesAppcPrevMarkFieldQry = inDistEesAppcPrevMarkField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAppcPrevMarkFieldQry+
                         " FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAppcPrevMarkField.substring(inDistEesAppcPrevMarkField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesAppcPrevMarkTabObj  lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesAppcPrevMarkTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("applicant_id") )
              lEesAppcPrevMarkTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmm_1") )
              lEesAppcPrevMarkTabObj.stmm_1  =  lResultSet.getFloat("STMM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmo_1") )
              lEesAppcPrevMarkTabObj.stmo_1  =  lResultSet.getFloat("STMO_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmm_1") )
              lEesAppcPrevMarkTabObj.spmm_1  =  lResultSet.getFloat("SPMM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmo_1") )
              lEesAppcPrevMarkTabObj.spmo_1  =  lResultSet.getFloat("SPMO_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmm_2") )
              lEesAppcPrevMarkTabObj.stmm_2  =  lResultSet.getFloat("STMM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmo_2") )
              lEesAppcPrevMarkTabObj.stmo_2  =  lResultSet.getFloat("STMO_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmm_2") )
              lEesAppcPrevMarkTabObj.spmm_2  =  lResultSet.getFloat("SPMM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmo_2") )
              lEesAppcPrevMarkTabObj.spmo_2  =  lResultSet.getFloat("SPMO_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmm_3") )
              lEesAppcPrevMarkTabObj.stmm_3  =  lResultSet.getFloat("STMM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmo_3") )
              lEesAppcPrevMarkTabObj.stmo_3  =  lResultSet.getFloat("STMO_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmm_3") )
              lEesAppcPrevMarkTabObj.spmm_3  =  lResultSet.getFloat("SPMM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmo_3") )
              lEesAppcPrevMarkTabObj.spmo_3  =  lResultSet.getFloat("SPMO_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmm_4") )
              lEesAppcPrevMarkTabObj.stmm_4  =  lResultSet.getFloat("STMM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stmo_4") )
              lEesAppcPrevMarkTabObj.stmo_4  =  lResultSet.getFloat("STMO_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmm_4") )
              lEesAppcPrevMarkTabObj.spmm_4  =  lResultSet.getFloat("SPMM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("spmo_4") )
              lEesAppcPrevMarkTabObj.spmo_4  =  lResultSet.getFloat("SPMO_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_req") )
              lEesAppcPrevMarkTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_list") )
              lEesAppcPrevMarkTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          }
          removeNullEesAppcPrevMarkTabObj( lEesAppcPrevMarkTabObj );

          outEesAppcPrevMarkTabObjArr.add(  lEesAppcPrevMarkTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAppcPrevMarkTabObjArr != null && outEesAppcPrevMarkTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAppcPrevMarkStrArrDist
               ( String inEesAppcPrevMarkWhereText
               , String inDistEesAppcPrevMarkField
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {

    sop("gtEesAppcPrevMarkStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAppcPrevMarkStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";
  

       String lDistEesAppcPrevMarkFieldQry = inDistEesAppcPrevMarkField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAppcPrevMarkFieldQry+
                         " FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAppcPrevMarkField.substring(inDistEesAppcPrevMarkField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesAppcPrevMarkTabObjStr = "";
       while(lResultSet.next())
       {
          lEesAppcPrevMarkTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesAppcPrevMarkTabObjStr =   lEesAppcPrevMarkTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesAppcPrevMarkTabObjArr.add(  lEesAppcPrevMarkTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAppcPrevMarkTabObjArr != null && outEesAppcPrevMarkTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesAppcPrevMark
               ( String inEesAppcPrevMarkWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesAppcPrevMark - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesAppcPrevMark";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesAppcPrevMarkTabObj
               ( 
                 EesAppcPrevMarkTabObj  outEesAppcPrevMarkTabObj
               )
  {
  
    if ( outEesAppcPrevMarkTabObj.org_id == null ) 
     outEesAppcPrevMarkTabObj.org_id = ""; 
    if ( outEesAppcPrevMarkTabObj.applicant_id == null ) 
     outEesAppcPrevMarkTabObj.applicant_id = ""; 
    if ( outEesAppcPrevMarkTabObj.stmm_1 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmm_1 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmo_1 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmo_1 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmm_1 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmm_1 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmo_1 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmo_1 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmm_2 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmm_2 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmo_2 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmo_2 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmm_2 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmm_2 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmo_2 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmo_2 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmm_3 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmm_3 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmo_3 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmo_3 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmm_3 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmm_3 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmo_3 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmo_3 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmm_4 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmm_4 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.stmo_4 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.stmo_4 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmm_4 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmm_4 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.spmo_4 == (float)0.00 ) 
     outEesAppcPrevMarkTabObj.spmo_4 = (float)0.00; 
    if ( outEesAppcPrevMarkTabObj.adm_req_id_req == null ) 
     outEesAppcPrevMarkTabObj.adm_req_id_req = ""; 
    if ( outEesAppcPrevMarkTabObj.adm_req_id_list == null ) 
     outEesAppcPrevMarkTabObj.adm_req_id_list = ""; 
  }





  public int insEesAppcPrevMarkRec
               ( EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj )
  {
    int lUpdateCount;
    sop("insEesAppcPrevMarkRec - Started");
    gSSTErrorObj.sourceMethod = "insEesAppcPrevMarkRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



          String lSqlStmt = "INSERT INTO EES_APPC_PREV_MARK"+
                        "("+
                                "org_id,"+
                                "applicant_id,"+
                                "stmm_1,"+
                                "stmo_1,"+
                                "spmm_1,"+
                                "spmo_1,"+
                                "stmm_2,"+
                                "stmo_2,"+
                                "spmm_2,"+
                                "spmo_2,"+
                                "stmm_3,"+
                                "stmo_3,"+
                                "spmm_3,"+
                                "spmo_3,"+
                                "stmm_4,"+
                                "stmo_4,"+
                                "spmm_4,"+
                                "spmo_4,"+
                                "adm_req_id_req,"+
                                "adm_req_id_list"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAppcPrevMarkTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAppcPrevMarkTabObj.applicant_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmm_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmo_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmm_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmo_1+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmm_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmo_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmm_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmo_2+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmm_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmo_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmm_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmo_3+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmm_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.stmo_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmm_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAppcPrevMarkTabObj.spmo_4+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAppcPrevMarkTabObj.adm_req_id_req+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesAppcPrevMarkTabObj.adm_req_id_list+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesAppcPrevMarkTabObj.org_id);
        lPreparedStatement.setString(2, inEesAppcPrevMarkTabObj.applicant_id);
          lPreparedStatement.setFloat(3, inEesAppcPrevMarkTabObj.stmm_1);
          lPreparedStatement.setFloat(4, inEesAppcPrevMarkTabObj.stmo_1);
          lPreparedStatement.setFloat(5, inEesAppcPrevMarkTabObj.spmm_1);
          lPreparedStatement.setFloat(6, inEesAppcPrevMarkTabObj.spmo_1);
          lPreparedStatement.setFloat(7, inEesAppcPrevMarkTabObj.stmm_2);
          lPreparedStatement.setFloat(8, inEesAppcPrevMarkTabObj.stmo_2);
          lPreparedStatement.setFloat(9, inEesAppcPrevMarkTabObj.spmm_2);
          lPreparedStatement.setFloat(10, inEesAppcPrevMarkTabObj.spmo_2);
          lPreparedStatement.setFloat(11, inEesAppcPrevMarkTabObj.stmm_3);
          lPreparedStatement.setFloat(12, inEesAppcPrevMarkTabObj.stmo_3);
          lPreparedStatement.setFloat(13, inEesAppcPrevMarkTabObj.spmm_3);
          lPreparedStatement.setFloat(14, inEesAppcPrevMarkTabObj.spmo_3);
          lPreparedStatement.setFloat(15, inEesAppcPrevMarkTabObj.stmm_4);
          lPreparedStatement.setFloat(16, inEesAppcPrevMarkTabObj.stmo_4);
          lPreparedStatement.setFloat(17, inEesAppcPrevMarkTabObj.spmm_4);
          lPreparedStatement.setFloat(18, inEesAppcPrevMarkTabObj.spmo_4);
        lPreparedStatement.setString(19, inEesAppcPrevMarkTabObj.adm_req_id_req);
        lPreparedStatement.setString(20, inEesAppcPrevMarkTabObj.adm_req_id_list);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesAppcPrevMarkArr
               ( ArrayList  inEesAppcPrevMarkTabObjArr 
               , String  inRowidFlag )
  {
    EesAppcPrevMarkTabObj  lEesAppcPrevMarkTabObj = new EesAppcPrevMarkTabObj();
    int lUpdateCount;
    sop("insEesAppcPrevMarkArr - Started");
    gSSTErrorObj.sourceMethod = "insEesAppcPrevMarkArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesAppcPrevMarkTabObjArr.size(); lNumRec++ )
      {
        lEesAppcPrevMarkTabObj = (EesAppcPrevMarkTabObj)inEesAppcPrevMarkTabObjArr.get(lNumRec);
          String lSqlStmt = "INSERT INTO EES_APPC_PREV_MARK"+
                        "("+
                        "org_id,"+
                        "applicant_id,"+
                        "stmm_1,"+
                        "stmo_1,"+
                        "spmm_1,"+
                        "spmo_1,"+
                        "stmm_2,"+
                        "stmo_2,"+
                        "spmm_2,"+
                        "spmo_2,"+
                        "stmm_3,"+
                        "stmo_3,"+
                        "spmm_3,"+
                        "spmo_3,"+
                        "stmm_4,"+
                        "stmo_4,"+
                        "spmm_4,"+
                        "spmo_4,"+
                        "adm_req_id_req,"+
                        "adm_req_id_list"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAppcPrevMarkTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAppcPrevMarkTabObj.applicant_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmm_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmo_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmm_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmo_1+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmm_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmo_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmm_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmo_2+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmm_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmo_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmm_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmo_3+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmm_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.stmo_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmm_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAppcPrevMarkTabObj.spmo_4+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAppcPrevMarkTabObj.adm_req_id_req+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesAppcPrevMarkTabObj.adm_req_id_list+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesAppcPrevMarkTabObj.org_id);
            lPreparedStatement.setString(2, lEesAppcPrevMarkTabObj.applicant_id);
              lPreparedStatement.setFloat(3, lEesAppcPrevMarkTabObj.stmm_1);
              lPreparedStatement.setFloat(4, lEesAppcPrevMarkTabObj.stmo_1);
              lPreparedStatement.setFloat(5, lEesAppcPrevMarkTabObj.spmm_1);
              lPreparedStatement.setFloat(6, lEesAppcPrevMarkTabObj.spmo_1);
              lPreparedStatement.setFloat(7, lEesAppcPrevMarkTabObj.stmm_2);
              lPreparedStatement.setFloat(8, lEesAppcPrevMarkTabObj.stmo_2);
              lPreparedStatement.setFloat(9, lEesAppcPrevMarkTabObj.spmm_2);
              lPreparedStatement.setFloat(10, lEesAppcPrevMarkTabObj.spmo_2);
              lPreparedStatement.setFloat(11, lEesAppcPrevMarkTabObj.stmm_3);
              lPreparedStatement.setFloat(12, lEesAppcPrevMarkTabObj.stmo_3);
              lPreparedStatement.setFloat(13, lEesAppcPrevMarkTabObj.spmm_3);
              lPreparedStatement.setFloat(14, lEesAppcPrevMarkTabObj.spmo_3);
              lPreparedStatement.setFloat(15, lEesAppcPrevMarkTabObj.stmm_4);
              lPreparedStatement.setFloat(16, lEesAppcPrevMarkTabObj.stmo_4);
              lPreparedStatement.setFloat(17, lEesAppcPrevMarkTabObj.spmm_4);
              lPreparedStatement.setFloat(18, lEesAppcPrevMarkTabObj.spmo_4);
            lPreparedStatement.setString(19, lEesAppcPrevMarkTabObj.adm_req_id_req);
            lPreparedStatement.setString(20, lEesAppcPrevMarkTabObj.adm_req_id_list);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesAppcPrevMarkReq2Obj
               ( HttpServletRequest inRequest
               , EesAppcPrevMarkTabObj  outEesAppcPrevMarkTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesAppcPrevMarkTabObj.tab_rowid = lTabRowidValue;

    outEesAppcPrevMarkTabObj.org_id = inRequest.getParameter("org_id");
    outEesAppcPrevMarkTabObj.applicant_id = inRequest.getParameter("applicant_id");
    if ( inRequest.getParameter("stmm_1") == null )
      outEesAppcPrevMarkTabObj.stmm_1 = 0;
    else
    if ( inRequest.getParameter("stmm_1").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmm_1 = 0;
    else
      outEesAppcPrevMarkTabObj.stmm_1 = Float.parseFloat( inRequest.getParameter("stmm_1"));
    if ( inRequest.getParameter("stmo_1") == null )
      outEesAppcPrevMarkTabObj.stmo_1 = 0;
    else
    if ( inRequest.getParameter("stmo_1").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmo_1 = 0;
    else
      outEesAppcPrevMarkTabObj.stmo_1 = Float.parseFloat( inRequest.getParameter("stmo_1"));
    if ( inRequest.getParameter("spmm_1") == null )
      outEesAppcPrevMarkTabObj.spmm_1 = 0;
    else
    if ( inRequest.getParameter("spmm_1").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmm_1 = 0;
    else
      outEesAppcPrevMarkTabObj.spmm_1 = Float.parseFloat( inRequest.getParameter("spmm_1"));
    if ( inRequest.getParameter("spmo_1") == null )
      outEesAppcPrevMarkTabObj.spmo_1 = 0;
    else
    if ( inRequest.getParameter("spmo_1").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmo_1 = 0;
    else
      outEesAppcPrevMarkTabObj.spmo_1 = Float.parseFloat( inRequest.getParameter("spmo_1"));
    if ( inRequest.getParameter("stmm_2") == null )
      outEesAppcPrevMarkTabObj.stmm_2 = 0;
    else
    if ( inRequest.getParameter("stmm_2").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmm_2 = 0;
    else
      outEesAppcPrevMarkTabObj.stmm_2 = Float.parseFloat( inRequest.getParameter("stmm_2"));
    if ( inRequest.getParameter("stmo_2") == null )
      outEesAppcPrevMarkTabObj.stmo_2 = 0;
    else
    if ( inRequest.getParameter("stmo_2").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmo_2 = 0;
    else
      outEesAppcPrevMarkTabObj.stmo_2 = Float.parseFloat( inRequest.getParameter("stmo_2"));
    if ( inRequest.getParameter("spmm_2") == null )
      outEesAppcPrevMarkTabObj.spmm_2 = 0;
    else
    if ( inRequest.getParameter("spmm_2").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmm_2 = 0;
    else
      outEesAppcPrevMarkTabObj.spmm_2 = Float.parseFloat( inRequest.getParameter("spmm_2"));
    if ( inRequest.getParameter("spmo_2") == null )
      outEesAppcPrevMarkTabObj.spmo_2 = 0;
    else
    if ( inRequest.getParameter("spmo_2").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmo_2 = 0;
    else
      outEesAppcPrevMarkTabObj.spmo_2 = Float.parseFloat( inRequest.getParameter("spmo_2"));
    if ( inRequest.getParameter("stmm_3") == null )
      outEesAppcPrevMarkTabObj.stmm_3 = 0;
    else
    if ( inRequest.getParameter("stmm_3").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmm_3 = 0;
    else
      outEesAppcPrevMarkTabObj.stmm_3 = Float.parseFloat( inRequest.getParameter("stmm_3"));
    if ( inRequest.getParameter("stmo_3") == null )
      outEesAppcPrevMarkTabObj.stmo_3 = 0;
    else
    if ( inRequest.getParameter("stmo_3").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmo_3 = 0;
    else
      outEesAppcPrevMarkTabObj.stmo_3 = Float.parseFloat( inRequest.getParameter("stmo_3"));
    if ( inRequest.getParameter("spmm_3") == null )
      outEesAppcPrevMarkTabObj.spmm_3 = 0;
    else
    if ( inRequest.getParameter("spmm_3").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmm_3 = 0;
    else
      outEesAppcPrevMarkTabObj.spmm_3 = Float.parseFloat( inRequest.getParameter("spmm_3"));
    if ( inRequest.getParameter("spmo_3") == null )
      outEesAppcPrevMarkTabObj.spmo_3 = 0;
    else
    if ( inRequest.getParameter("spmo_3").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmo_3 = 0;
    else
      outEesAppcPrevMarkTabObj.spmo_3 = Float.parseFloat( inRequest.getParameter("spmo_3"));
    if ( inRequest.getParameter("stmm_4") == null )
      outEesAppcPrevMarkTabObj.stmm_4 = 0;
    else
    if ( inRequest.getParameter("stmm_4").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmm_4 = 0;
    else
      outEesAppcPrevMarkTabObj.stmm_4 = Float.parseFloat( inRequest.getParameter("stmm_4"));
    if ( inRequest.getParameter("stmo_4") == null )
      outEesAppcPrevMarkTabObj.stmo_4 = 0;
    else
    if ( inRequest.getParameter("stmo_4").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.stmo_4 = 0;
    else
      outEesAppcPrevMarkTabObj.stmo_4 = Float.parseFloat( inRequest.getParameter("stmo_4"));
    if ( inRequest.getParameter("spmm_4") == null )
      outEesAppcPrevMarkTabObj.spmm_4 = 0;
    else
    if ( inRequest.getParameter("spmm_4").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmm_4 = 0;
    else
      outEesAppcPrevMarkTabObj.spmm_4 = Float.parseFloat( inRequest.getParameter("spmm_4"));
    if ( inRequest.getParameter("spmo_4") == null )
      outEesAppcPrevMarkTabObj.spmo_4 = 0;
    else
    if ( inRequest.getParameter("spmo_4").trim().length() == 0 )
      outEesAppcPrevMarkTabObj.spmo_4 = 0;
    else
      outEesAppcPrevMarkTabObj.spmo_4 = Float.parseFloat( inRequest.getParameter("spmo_4"));
    outEesAppcPrevMarkTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req");
    outEesAppcPrevMarkTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list");
    return lReturnValue;
  }


  public int popEesAppcPrevMarkReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAppcPrevMarkTabObj lEesAppcPrevMarkTabObj= new EesAppcPrevMarkTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAppcPrevMarkTabObj.tab_rowid = lTabRowidValue;

      lEesAppcPrevMarkTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesAppcPrevMarkTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
      if ( inRequest.getParameter("stmm_1_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmm_1 = 0;
      else
      if ( inRequest.getParameter("stmm_1_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmm_1 = 0;
      else
        lEesAppcPrevMarkTabObj.stmm_1 = Float.parseFloat( inRequest.getParameter("stmm_1_r"+lNumRec));
      if ( inRequest.getParameter("stmo_1_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmo_1 = 0;
      else
      if ( inRequest.getParameter("stmo_1_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmo_1 = 0;
      else
        lEesAppcPrevMarkTabObj.stmo_1 = Float.parseFloat( inRequest.getParameter("stmo_1_r"+lNumRec));
      if ( inRequest.getParameter("spmm_1_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmm_1 = 0;
      else
      if ( inRequest.getParameter("spmm_1_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmm_1 = 0;
      else
        lEesAppcPrevMarkTabObj.spmm_1 = Float.parseFloat( inRequest.getParameter("spmm_1_r"+lNumRec));
      if ( inRequest.getParameter("spmo_1_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmo_1 = 0;
      else
      if ( inRequest.getParameter("spmo_1_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmo_1 = 0;
      else
        lEesAppcPrevMarkTabObj.spmo_1 = Float.parseFloat( inRequest.getParameter("spmo_1_r"+lNumRec));
      if ( inRequest.getParameter("stmm_2_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmm_2 = 0;
      else
      if ( inRequest.getParameter("stmm_2_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmm_2 = 0;
      else
        lEesAppcPrevMarkTabObj.stmm_2 = Float.parseFloat( inRequest.getParameter("stmm_2_r"+lNumRec));
      if ( inRequest.getParameter("stmo_2_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmo_2 = 0;
      else
      if ( inRequest.getParameter("stmo_2_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmo_2 = 0;
      else
        lEesAppcPrevMarkTabObj.stmo_2 = Float.parseFloat( inRequest.getParameter("stmo_2_r"+lNumRec));
      if ( inRequest.getParameter("spmm_2_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmm_2 = 0;
      else
      if ( inRequest.getParameter("spmm_2_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmm_2 = 0;
      else
        lEesAppcPrevMarkTabObj.spmm_2 = Float.parseFloat( inRequest.getParameter("spmm_2_r"+lNumRec));
      if ( inRequest.getParameter("spmo_2_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmo_2 = 0;
      else
      if ( inRequest.getParameter("spmo_2_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmo_2 = 0;
      else
        lEesAppcPrevMarkTabObj.spmo_2 = Float.parseFloat( inRequest.getParameter("spmo_2_r"+lNumRec));
      if ( inRequest.getParameter("stmm_3_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmm_3 = 0;
      else
      if ( inRequest.getParameter("stmm_3_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmm_3 = 0;
      else
        lEesAppcPrevMarkTabObj.stmm_3 = Float.parseFloat( inRequest.getParameter("stmm_3_r"+lNumRec));
      if ( inRequest.getParameter("stmo_3_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmo_3 = 0;
      else
      if ( inRequest.getParameter("stmo_3_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmo_3 = 0;
      else
        lEesAppcPrevMarkTabObj.stmo_3 = Float.parseFloat( inRequest.getParameter("stmo_3_r"+lNumRec));
      if ( inRequest.getParameter("spmm_3_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmm_3 = 0;
      else
      if ( inRequest.getParameter("spmm_3_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmm_3 = 0;
      else
        lEesAppcPrevMarkTabObj.spmm_3 = Float.parseFloat( inRequest.getParameter("spmm_3_r"+lNumRec));
      if ( inRequest.getParameter("spmo_3_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmo_3 = 0;
      else
      if ( inRequest.getParameter("spmo_3_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmo_3 = 0;
      else
        lEesAppcPrevMarkTabObj.spmo_3 = Float.parseFloat( inRequest.getParameter("spmo_3_r"+lNumRec));
      if ( inRequest.getParameter("stmm_4_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmm_4 = 0;
      else
      if ( inRequest.getParameter("stmm_4_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmm_4 = 0;
      else
        lEesAppcPrevMarkTabObj.stmm_4 = Float.parseFloat( inRequest.getParameter("stmm_4_r"+lNumRec));
      if ( inRequest.getParameter("stmo_4_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.stmo_4 = 0;
      else
      if ( inRequest.getParameter("stmo_4_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.stmo_4 = 0;
      else
        lEesAppcPrevMarkTabObj.stmo_4 = Float.parseFloat( inRequest.getParameter("stmo_4_r"+lNumRec));
      if ( inRequest.getParameter("spmm_4_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmm_4 = 0;
      else
      if ( inRequest.getParameter("spmm_4_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmm_4 = 0;
      else
        lEesAppcPrevMarkTabObj.spmm_4 = Float.parseFloat( inRequest.getParameter("spmm_4_r"+lNumRec));
      if ( inRequest.getParameter("spmo_4_r"+lNumRec) == null )
        lEesAppcPrevMarkTabObj.spmo_4 = 0;
      else
      if ( inRequest.getParameter("spmo_4_r"+lNumRec).trim().length() == 0 )
        lEesAppcPrevMarkTabObj.spmo_4 = 0;
      else
        lEesAppcPrevMarkTabObj.spmo_4 = Float.parseFloat( inRequest.getParameter("spmo_4_r"+lNumRec));
      lEesAppcPrevMarkTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
      lEesAppcPrevMarkTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      outEesAppcPrevMarkTabObjArr.add( lEesAppcPrevMarkTabObj);
    }
    return lReturnValue;
  }


  public int popEesAppcPrevMarkReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesAppcPrevMarkTabObj outEesAppcPrevMarkTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_appc_prev_mark_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesAppcPrevMarkTabObj.tab_rowid = lTabRowidValue;

        outEesAppcPrevMarkTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesAppcPrevMarkTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        if ( inRequest.getParameter("stmm_1_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmm_1 = 0;
        else
        if ( inRequest.getParameter("stmm_1_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmm_1 = 0;
        else
          outEesAppcPrevMarkTabObj.stmm_1 = Float.parseFloat( inRequest.getParameter("stmm_1_r"+lNumRec));
        if ( inRequest.getParameter("stmo_1_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmo_1 = 0;
        else
        if ( inRequest.getParameter("stmo_1_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmo_1 = 0;
        else
          outEesAppcPrevMarkTabObj.stmo_1 = Float.parseFloat( inRequest.getParameter("stmo_1_r"+lNumRec));
        if ( inRequest.getParameter("spmm_1_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmm_1 = 0;
        else
        if ( inRequest.getParameter("spmm_1_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmm_1 = 0;
        else
          outEesAppcPrevMarkTabObj.spmm_1 = Float.parseFloat( inRequest.getParameter("spmm_1_r"+lNumRec));
        if ( inRequest.getParameter("spmo_1_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmo_1 = 0;
        else
        if ( inRequest.getParameter("spmo_1_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmo_1 = 0;
        else
          outEesAppcPrevMarkTabObj.spmo_1 = Float.parseFloat( inRequest.getParameter("spmo_1_r"+lNumRec));
        if ( inRequest.getParameter("stmm_2_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmm_2 = 0;
        else
        if ( inRequest.getParameter("stmm_2_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmm_2 = 0;
        else
          outEesAppcPrevMarkTabObj.stmm_2 = Float.parseFloat( inRequest.getParameter("stmm_2_r"+lNumRec));
        if ( inRequest.getParameter("stmo_2_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmo_2 = 0;
        else
        if ( inRequest.getParameter("stmo_2_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmo_2 = 0;
        else
          outEesAppcPrevMarkTabObj.stmo_2 = Float.parseFloat( inRequest.getParameter("stmo_2_r"+lNumRec));
        if ( inRequest.getParameter("spmm_2_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmm_2 = 0;
        else
        if ( inRequest.getParameter("spmm_2_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmm_2 = 0;
        else
          outEesAppcPrevMarkTabObj.spmm_2 = Float.parseFloat( inRequest.getParameter("spmm_2_r"+lNumRec));
        if ( inRequest.getParameter("spmo_2_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmo_2 = 0;
        else
        if ( inRequest.getParameter("spmo_2_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmo_2 = 0;
        else
          outEesAppcPrevMarkTabObj.spmo_2 = Float.parseFloat( inRequest.getParameter("spmo_2_r"+lNumRec));
        if ( inRequest.getParameter("stmm_3_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmm_3 = 0;
        else
        if ( inRequest.getParameter("stmm_3_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmm_3 = 0;
        else
          outEesAppcPrevMarkTabObj.stmm_3 = Float.parseFloat( inRequest.getParameter("stmm_3_r"+lNumRec));
        if ( inRequest.getParameter("stmo_3_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmo_3 = 0;
        else
        if ( inRequest.getParameter("stmo_3_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmo_3 = 0;
        else
          outEesAppcPrevMarkTabObj.stmo_3 = Float.parseFloat( inRequest.getParameter("stmo_3_r"+lNumRec));
        if ( inRequest.getParameter("spmm_3_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmm_3 = 0;
        else
        if ( inRequest.getParameter("spmm_3_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmm_3 = 0;
        else
          outEesAppcPrevMarkTabObj.spmm_3 = Float.parseFloat( inRequest.getParameter("spmm_3_r"+lNumRec));
        if ( inRequest.getParameter("spmo_3_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmo_3 = 0;
        else
        if ( inRequest.getParameter("spmo_3_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmo_3 = 0;
        else
          outEesAppcPrevMarkTabObj.spmo_3 = Float.parseFloat( inRequest.getParameter("spmo_3_r"+lNumRec));
        if ( inRequest.getParameter("stmm_4_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmm_4 = 0;
        else
        if ( inRequest.getParameter("stmm_4_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmm_4 = 0;
        else
          outEesAppcPrevMarkTabObj.stmm_4 = Float.parseFloat( inRequest.getParameter("stmm_4_r"+lNumRec));
        if ( inRequest.getParameter("stmo_4_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.stmo_4 = 0;
        else
        if ( inRequest.getParameter("stmo_4_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.stmo_4 = 0;
        else
          outEesAppcPrevMarkTabObj.stmo_4 = Float.parseFloat( inRequest.getParameter("stmo_4_r"+lNumRec));
        if ( inRequest.getParameter("spmm_4_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmm_4 = 0;
        else
        if ( inRequest.getParameter("spmm_4_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmm_4 = 0;
        else
          outEesAppcPrevMarkTabObj.spmm_4 = Float.parseFloat( inRequest.getParameter("spmm_4_r"+lNumRec));
        if ( inRequest.getParameter("spmo_4_r"+lNumRec) == null )
          outEesAppcPrevMarkTabObj.spmo_4 = 0;
        else
        if ( inRequest.getParameter("spmo_4_r"+lNumRec).trim().length() == 0 )
          outEesAppcPrevMarkTabObj.spmo_4 = 0;
        else
          outEesAppcPrevMarkTabObj.spmo_4 = Float.parseFloat( inRequest.getParameter("spmo_4_r"+lNumRec));
        outEesAppcPrevMarkTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        outEesAppcPrevMarkTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesAppcPrevMarkReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAppcPrevMarkTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAppcPrevMarkTabObj lEesAppcPrevMarkTabObj= new EesAppcPrevMarkTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_appc_prev_mark_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAppcPrevMarkTabObj.tab_rowid = lTabRowidValue;

        lEesAppcPrevMarkTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesAppcPrevMarkTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        if ( inRequest.getParameter("stmm_1_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmm_1 = 0;
        else
        if ( inRequest.getParameter("stmm_1_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmm_1 = 0;
        else
            lEesAppcPrevMarkTabObj.stmm_1 = Float.parseFloat( inRequest.getParameter("stmm_1_r"+lNumRec));
        if ( inRequest.getParameter("stmo_1_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmo_1 = 0;
        else
        if ( inRequest.getParameter("stmo_1_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmo_1 = 0;
        else
            lEesAppcPrevMarkTabObj.stmo_1 = Float.parseFloat( inRequest.getParameter("stmo_1_r"+lNumRec));
        if ( inRequest.getParameter("spmm_1_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmm_1 = 0;
        else
        if ( inRequest.getParameter("spmm_1_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmm_1 = 0;
        else
            lEesAppcPrevMarkTabObj.spmm_1 = Float.parseFloat( inRequest.getParameter("spmm_1_r"+lNumRec));
        if ( inRequest.getParameter("spmo_1_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmo_1 = 0;
        else
        if ( inRequest.getParameter("spmo_1_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmo_1 = 0;
        else
            lEesAppcPrevMarkTabObj.spmo_1 = Float.parseFloat( inRequest.getParameter("spmo_1_r"+lNumRec));
        if ( inRequest.getParameter("stmm_2_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmm_2 = 0;
        else
        if ( inRequest.getParameter("stmm_2_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmm_2 = 0;
        else
            lEesAppcPrevMarkTabObj.stmm_2 = Float.parseFloat( inRequest.getParameter("stmm_2_r"+lNumRec));
        if ( inRequest.getParameter("stmo_2_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmo_2 = 0;
        else
        if ( inRequest.getParameter("stmo_2_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmo_2 = 0;
        else
            lEesAppcPrevMarkTabObj.stmo_2 = Float.parseFloat( inRequest.getParameter("stmo_2_r"+lNumRec));
        if ( inRequest.getParameter("spmm_2_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmm_2 = 0;
        else
        if ( inRequest.getParameter("spmm_2_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmm_2 = 0;
        else
            lEesAppcPrevMarkTabObj.spmm_2 = Float.parseFloat( inRequest.getParameter("spmm_2_r"+lNumRec));
        if ( inRequest.getParameter("spmo_2_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmo_2 = 0;
        else
        if ( inRequest.getParameter("spmo_2_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmo_2 = 0;
        else
            lEesAppcPrevMarkTabObj.spmo_2 = Float.parseFloat( inRequest.getParameter("spmo_2_r"+lNumRec));
        if ( inRequest.getParameter("stmm_3_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmm_3 = 0;
        else
        if ( inRequest.getParameter("stmm_3_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmm_3 = 0;
        else
            lEesAppcPrevMarkTabObj.stmm_3 = Float.parseFloat( inRequest.getParameter("stmm_3_r"+lNumRec));
        if ( inRequest.getParameter("stmo_3_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmo_3 = 0;
        else
        if ( inRequest.getParameter("stmo_3_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmo_3 = 0;
        else
            lEesAppcPrevMarkTabObj.stmo_3 = Float.parseFloat( inRequest.getParameter("stmo_3_r"+lNumRec));
        if ( inRequest.getParameter("spmm_3_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmm_3 = 0;
        else
        if ( inRequest.getParameter("spmm_3_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmm_3 = 0;
        else
            lEesAppcPrevMarkTabObj.spmm_3 = Float.parseFloat( inRequest.getParameter("spmm_3_r"+lNumRec));
        if ( inRequest.getParameter("spmo_3_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmo_3 = 0;
        else
        if ( inRequest.getParameter("spmo_3_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmo_3 = 0;
        else
            lEesAppcPrevMarkTabObj.spmo_3 = Float.parseFloat( inRequest.getParameter("spmo_3_r"+lNumRec));
        if ( inRequest.getParameter("stmm_4_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmm_4 = 0;
        else
        if ( inRequest.getParameter("stmm_4_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmm_4 = 0;
        else
            lEesAppcPrevMarkTabObj.stmm_4 = Float.parseFloat( inRequest.getParameter("stmm_4_r"+lNumRec));
        if ( inRequest.getParameter("stmo_4_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.stmo_4 = 0;
        else
        if ( inRequest.getParameter("stmo_4_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.stmo_4 = 0;
        else
            lEesAppcPrevMarkTabObj.stmo_4 = Float.parseFloat( inRequest.getParameter("stmo_4_r"+lNumRec));
        if ( inRequest.getParameter("spmm_4_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmm_4 = 0;
        else
        if ( inRequest.getParameter("spmm_4_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmm_4 = 0;
        else
            lEesAppcPrevMarkTabObj.spmm_4 = Float.parseFloat( inRequest.getParameter("spmm_4_r"+lNumRec));
        if ( inRequest.getParameter("spmo_4_r"+lNumRec) == null )
          lEesAppcPrevMarkTabObj.spmo_4 = 0;
        else
        if ( inRequest.getParameter("spmo_4_r"+lNumRec).trim().length() == 0 )
          lEesAppcPrevMarkTabObj.spmo_4 = 0;
        else
            lEesAppcPrevMarkTabObj.spmo_4 = Float.parseFloat( inRequest.getParameter("spmo_4_r"+lNumRec));
        lEesAppcPrevMarkTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        lEesAppcPrevMarkTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
        outEesAppcPrevMarkTabObjArr.add( lEesAppcPrevMarkTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesAppcPrevMarkRecByRowid
               ( String inRowId
               , EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAppcPrevMarkRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesAppcPrevMarkRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_APPC_PREV_MARK ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesAppcPrevMarkTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAppcPrevMarkTabObj.org_id+"', ";
      if ( inEesAppcPrevMarkTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAppcPrevMarkTabObj.applicant_id+"', ";
             lSqlStmt = lSqlStmt + "stmm_1 = "+inEesAppcPrevMarkTabObj.stmm_1+", ";
             lSqlStmt = lSqlStmt + "stmo_1 = "+inEesAppcPrevMarkTabObj.stmo_1+", ";
             lSqlStmt = lSqlStmt + "spmm_1 = "+inEesAppcPrevMarkTabObj.spmm_1+", ";
             lSqlStmt = lSqlStmt + "spmo_1 = "+inEesAppcPrevMarkTabObj.spmo_1+", ";
             lSqlStmt = lSqlStmt + "stmm_2 = "+inEesAppcPrevMarkTabObj.stmm_2+", ";
             lSqlStmt = lSqlStmt + "stmo_2 = "+inEesAppcPrevMarkTabObj.stmo_2+", ";
             lSqlStmt = lSqlStmt + "spmm_2 = "+inEesAppcPrevMarkTabObj.spmm_2+", ";
             lSqlStmt = lSqlStmt + "spmo_2 = "+inEesAppcPrevMarkTabObj.spmo_2+", ";
             lSqlStmt = lSqlStmt + "stmm_3 = "+inEesAppcPrevMarkTabObj.stmm_3+", ";
             lSqlStmt = lSqlStmt + "stmo_3 = "+inEesAppcPrevMarkTabObj.stmo_3+", ";
             lSqlStmt = lSqlStmt + "spmm_3 = "+inEesAppcPrevMarkTabObj.spmm_3+", ";
             lSqlStmt = lSqlStmt + "spmo_3 = "+inEesAppcPrevMarkTabObj.spmo_3+", ";
             lSqlStmt = lSqlStmt + "stmm_4 = "+inEesAppcPrevMarkTabObj.stmm_4+", ";
             lSqlStmt = lSqlStmt + "stmo_4 = "+inEesAppcPrevMarkTabObj.stmo_4+", ";
             lSqlStmt = lSqlStmt + "spmm_4 = "+inEesAppcPrevMarkTabObj.spmm_4+", ";
             lSqlStmt = lSqlStmt + "spmo_4 = "+inEesAppcPrevMarkTabObj.spmo_4+", ";
      if ( inEesAppcPrevMarkTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAppcPrevMarkTabObj.adm_req_id_req+"', ";
      if ( inEesAppcPrevMarkTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAppcPrevMarkTabObj.adm_req_id_list+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAppcPrevMarkRecByPkey
               ( EesAppcPrevMarkPkeyObj inEesAppcPrevMarkPkeyObj
               , EesAppcPrevMarkTabObj  inEesAppcPrevMarkTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAppcPrevMarkRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesAppcPrevMarkRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_APPC_PREV_MARK ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesAppcPrevMarkTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesAppcPrevMarkTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = ? , ";
               lSqlStmt = lSqlStmt + "stmm_1 = ? , ";
               lSqlStmt = lSqlStmt + "stmo_1 = ? , ";
               lSqlStmt = lSqlStmt + "spmm_1 = ? , ";
               lSqlStmt = lSqlStmt + "spmo_1 = ? , ";
               lSqlStmt = lSqlStmt + "stmm_2 = ? , ";
               lSqlStmt = lSqlStmt + "stmo_2 = ? , ";
               lSqlStmt = lSqlStmt + "spmm_2 = ? , ";
               lSqlStmt = lSqlStmt + "spmo_2 = ? , ";
               lSqlStmt = lSqlStmt + "stmm_3 = ? , ";
               lSqlStmt = lSqlStmt + "stmo_3 = ? , ";
               lSqlStmt = lSqlStmt + "spmm_3 = ? , ";
               lSqlStmt = lSqlStmt + "spmo_3 = ? , ";
               lSqlStmt = lSqlStmt + "stmm_4 = ? , ";
               lSqlStmt = lSqlStmt + "stmo_4 = ? , ";
               lSqlStmt = lSqlStmt + "spmm_4 = ? , ";
               lSqlStmt = lSqlStmt + "spmo_4 = ? , ";
        if ( inEesAppcPrevMarkTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = ? , ";
        if ( inEesAppcPrevMarkTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesAppcPrevMarkTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAppcPrevMarkTabObj.org_id+"', ";
        if ( inEesAppcPrevMarkTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAppcPrevMarkTabObj.applicant_id+"', ";
               lSqlStmt = lSqlStmt + "stmm_1 = "+inEesAppcPrevMarkTabObj.stmm_1+", ";
               lSqlStmt = lSqlStmt + "stmo_1 = "+inEesAppcPrevMarkTabObj.stmo_1+", ";
               lSqlStmt = lSqlStmt + "spmm_1 = "+inEesAppcPrevMarkTabObj.spmm_1+", ";
               lSqlStmt = lSqlStmt + "spmo_1 = "+inEesAppcPrevMarkTabObj.spmo_1+", ";
               lSqlStmt = lSqlStmt + "stmm_2 = "+inEesAppcPrevMarkTabObj.stmm_2+", ";
               lSqlStmt = lSqlStmt + "stmo_2 = "+inEesAppcPrevMarkTabObj.stmo_2+", ";
               lSqlStmt = lSqlStmt + "spmm_2 = "+inEesAppcPrevMarkTabObj.spmm_2+", ";
               lSqlStmt = lSqlStmt + "spmo_2 = "+inEesAppcPrevMarkTabObj.spmo_2+", ";
               lSqlStmt = lSqlStmt + "stmm_3 = "+inEesAppcPrevMarkTabObj.stmm_3+", ";
               lSqlStmt = lSqlStmt + "stmo_3 = "+inEesAppcPrevMarkTabObj.stmo_3+", ";
               lSqlStmt = lSqlStmt + "spmm_3 = "+inEesAppcPrevMarkTabObj.spmm_3+", ";
               lSqlStmt = lSqlStmt + "spmo_3 = "+inEesAppcPrevMarkTabObj.spmo_3+", ";
               lSqlStmt = lSqlStmt + "stmm_4 = "+inEesAppcPrevMarkTabObj.stmm_4+", ";
               lSqlStmt = lSqlStmt + "stmo_4 = "+inEesAppcPrevMarkTabObj.stmo_4+", ";
               lSqlStmt = lSqlStmt + "spmm_4 = "+inEesAppcPrevMarkTabObj.spmm_4+", ";
               lSqlStmt = lSqlStmt + "spmo_4 = "+inEesAppcPrevMarkTabObj.spmo_4+", ";
        if ( inEesAppcPrevMarkTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAppcPrevMarkTabObj.adm_req_id_req+"', ";
        if ( inEesAppcPrevMarkTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAppcPrevMarkTabObj.adm_req_id_list+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAppcPrevMarkPkeyObj.org_id+"' and "+
                              "applicant_id = "+"'"+inEesAppcPrevMarkPkeyObj.applicant_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesAppcPrevMarkTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAppcPrevMarkTabObj.org_id); } 
         if ( inEesAppcPrevMarkTabObj.applicant_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAppcPrevMarkTabObj.applicant_id); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(3, inEesAppcPrevMarkTabObj.stmm_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(4, inEesAppcPrevMarkTabObj.stmo_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(5, inEesAppcPrevMarkTabObj.spmm_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(6, inEesAppcPrevMarkTabObj.spmo_1);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(7, inEesAppcPrevMarkTabObj.stmm_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(8, inEesAppcPrevMarkTabObj.stmo_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(9, inEesAppcPrevMarkTabObj.spmm_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(10, inEesAppcPrevMarkTabObj.spmo_2);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(11, inEesAppcPrevMarkTabObj.stmm_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(12, inEesAppcPrevMarkTabObj.stmo_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(13, inEesAppcPrevMarkTabObj.spmm_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(14, inEesAppcPrevMarkTabObj.spmo_3);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(15, inEesAppcPrevMarkTabObj.stmm_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(16, inEesAppcPrevMarkTabObj.stmo_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(17, inEesAppcPrevMarkTabObj.spmm_4);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(18, inEesAppcPrevMarkTabObj.spmo_4);
         if ( inEesAppcPrevMarkTabObj.adm_req_id_req != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAppcPrevMarkTabObj.adm_req_id_req); } 
         if ( inEesAppcPrevMarkTabObj.adm_req_id_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAppcPrevMarkTabObj.adm_req_id_list); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAppcPrevMarkRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesAppcPrevMarkRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesAppcPrevMarkRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_APPC_PREV_MARK "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAppcPrevMarkRecByPkeyWithSet
               ( EesAppcPrevMarkPkeyObj inEesAppcPrevMarkPkeyObj
               , String  inEesAppcPrevMarkSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAppcPrevMarkRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAppcPrevMarkRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_APPC_PREV_MARK ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAppcPrevMarkSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAppcPrevMarkPkeyObj.org_id+"' and "+
                              "applicant_id = "+"'"+inEesAppcPrevMarkPkeyObj.applicant_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAppcPrevMarkRecByRowidWithSet
               ( String inRowId
               , String  inEesAppcPrevMarkSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAppcPrevMarkRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAppcPrevMarkRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_APPC_PREV_MARK ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAppcPrevMarkSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAppcPrevMarkRecByWhereWithSet
               ( String inEesAppcPrevMarkWhereText
               , String  inEesAppcPrevMarkSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAppcPrevMarkRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAppcPrevMarkRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_APPC_PREV_MARK ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesAppcPrevMarkSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAppcPrevMarkRecByPkey
               ( EesAppcPrevMarkPkeyObj  inEesAppcPrevMarkPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesAppcPrevMarkRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesAppcPrevMarkRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_APPC_PREV_MARK " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAppcPrevMarkPkeyObj.org_id+"' and "+
                              "applicant_id = "+"'"+inEesAppcPrevMarkPkeyObj.applicant_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAppcPrevMarkByWhere
               ( String inEesAppcPrevMarkWhereText
               )
  {
    int lUpdateCount;
    sop("delEesAppcPrevMarkByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesAppcPrevMarkByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAppcPrevMarkWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAppcPrevMarkWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_APPC_PREV_MARK "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
