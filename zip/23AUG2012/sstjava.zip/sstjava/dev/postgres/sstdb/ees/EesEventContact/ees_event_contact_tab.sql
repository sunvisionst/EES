CREATE TABLE EES_EVENT_CONTACT
(
  ORG_ID                                                                                              VARCHAR(10),
  ACTIVITY_ID                                                                                         VARCHAR(10),
  SEQ_NUM                                                                                             NUMERIC(9),
  EVENT_ID                                                                                            VARCHAR(10),
  CONTACT_TYPE                                                                                        VARCHAR(1),
  POC_TYPE                                                                                            VARCHAR(10),
  POC_ID                                                                                              VARCHAR(10),
  POC_NAME                                                                                            VARCHAR(100),
  PHONE_LIST                                                                                          VARCHAR(100),
  EMAIL_LIST                                                                                          VARCHAR(100),
  FAX_LIST                                                                                            VARCHAR(100),
  ADDRESS_1                                                                                           VARCHAR(150),
  ADDRESS_2                                                                                           VARCHAR(150),
  COUNTRY                                                                                             VARCHAR(10),
  STATE                                                                                               VARCHAR(50),
  CITY                                                                                                VARCHAR(50),
  DISTRICT                                                                                            VARCHAR(50),
  ZIP                                                                                                 VARCHAR(10)
)
 WITH OIDS;
