
var lEesAppcRefTabObjJSArr = new Array();
<%
{
   if ( lEesAppcRefTabObjArrCache != null && lEesAppcRefTabObjArrCache.size() > 0 )
   {
%>
       lEesAppcRefTabObjJSArr = new Array(<%=lEesAppcRefTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAppcRefTabObjArrCache.size(); lRecNum++ )
       {
          EesAppcRefTabObj lEesAppcRefTabObj    =    new EesAppcRefTabObj();
          lEesAppcRefTabObj = (EesAppcRefTabObj)lEesAppcRefTabObjArrCache.get(lRecNum);
%>
          lEesAppcRefTabObjJSArr[<%=lRecNum%>] = new constructorEesAppcRef
          (
          "<%=lEesAppcRefTabObj.org_id%>",
          "<%=lEesAppcRefTabObj.applicant_id%>",
          "<%=lEesAppcRefTabObj.seq_num%>",
          "<%=lEesAppcRefTabObj.application_form_num%>",
          "<%=lEesAppcRefTabObj.student_id%>",
          "<%=lEesAppcRefTabObj.roll_num%>",
          "<%=lEesAppcRefTabObj.ref_name%>",
          "<%=lEesAppcRefTabObj.address_1%>",
          "<%=lEesAppcRefTabObj.address_2%>",
          "<%=lEesAppcRefTabObj.phone_list%>",
          "<%=lEesAppcRefTabObj.email_list%>",
          "<%=lEesAppcRefTabObj.fax_list%>",
          "<%=lEesAppcRefTabObj.adm_req_id_req%>",
          "<%=lEesAppcRefTabObj.adm_req_id_list%>"
          );
<%
       }
   }
}
%>


