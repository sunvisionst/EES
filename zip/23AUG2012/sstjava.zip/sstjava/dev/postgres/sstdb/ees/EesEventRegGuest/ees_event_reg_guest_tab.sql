CREATE TABLE EES_EVENT_REG_GUEST
(
  ORG_ID                                                                                              VARCHAR(10),
  ACTIVITY_ID                                                                                         VARCHAR(10),
  EVENT_ID                                                                                            VARCHAR(10),
  SPEAKER_IND                                                                                         VARCHAR(1),
  ATTENDEE_NAME                                                                                       VARCHAR(100),
  ATTENDEE_EMAIL                                                                                      VARCHAR(50),
  ATTENDEE_PHONE                                                                                      VARCHAR(30),
  ATTENDEE_FAX                                                                                        VARCHAR(30),
  STATUS                                                                                              VARCHAR(1),
  STATUS_DATE                                                                                         VARCHAR(8)
)
 WITH OIDS;
