
var lEesCourseStreamTabObjJSArr = new Array();
<%
{
   if ( lEesCourseStreamTabObjArrCache != null && lEesCourseStreamTabObjArrCache.size() > 0 )
   {
%>
       lEesCourseStreamTabObjJSArr = new Array(<%=lEesCourseStreamTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesCourseStreamTabObjArrCache.size(); lRecNum++ )
       {
          EesCourseStreamTabObj lEesCourseStreamTabObj    =    new EesCourseStreamTabObj();
          lEesCourseStreamTabObj = (EesCourseStreamTabObj)lEesCourseStreamTabObjArrCache.get(lRecNum);
%>
          lEesCourseStreamTabObjJSArr[<%=lRecNum%>] = new constructorEesCourseStream
          (
          "<%=lEesCourseStreamTabObj.org_id%>",
          "<%=lEesCourseStreamTabObj.course_id%>",
          "<%=lEesCourseStreamTabObj.course_stream%>",
          "<%=lEesCourseStreamTabObj.description%>",
          "<%=lEesCourseStreamTabObj.stream_strength%>",
          "<%=lEesCourseStreamTabObj.quota_qty%>",
          "<%=lEesCourseStreamTabObj.course_code%>",
          "<%=lEesCourseStreamTabObj.short_code%>",
          "<%=lEesCourseStreamTabObj.sst_stream_id%>",
          "<%=lEesCourseStreamTabObj.course_coord%>",
          "<%=lEesCourseStreamTabObj.board_university%>",
          "<%=lEesCourseStreamTabObj.min_fee_amt%>",
          "<%=lEesCourseStreamTabObj.cc_ptl_user_id%>",
          "<%=lEesCourseStreamTabObj.class_std%>"
          );
<%
       }
   }
}
%>


