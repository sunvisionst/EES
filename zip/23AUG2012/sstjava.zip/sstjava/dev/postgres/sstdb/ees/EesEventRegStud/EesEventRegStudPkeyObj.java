package sstdb.ees.EesEventRegStud;


public class EesEventRegStudPkeyObj
{
  public String                                 org_id;
  public String                                 activity_id;
  public String                                 student_id;
}