
var lEesEventActivityTabObjJSArr = new Array();
<%
{
   if ( lEesEventActivityTabObjArrCache != null && lEesEventActivityTabObjArrCache.size() > 0 )
   {
%>
       lEesEventActivityTabObjJSArr = new Array(<%=lEesEventActivityTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesEventActivityTabObjArrCache.size(); lRecNum++ )
       {
          EesEventActivityTabObj lEesEventActivityTabObj    =    new EesEventActivityTabObj();
          lEesEventActivityTabObj = (EesEventActivityTabObj)lEesEventActivityTabObjArrCache.get(lRecNum);
%>
          lEesEventActivityTabObjJSArr[<%=lRecNum%>] = new constructorEesEventActivity
          (
          "<%=lEesEventActivityTabObj.org_id%>",
          "<%=lEesEventActivityTabObj.activity_id%>",
          "<%=lEesEventActivityTabObj.event_act_type%>",
          "<%=lEesEventActivityTabObj.activity_date%>",
          "<%=lEesEventActivityTabObj.act_start_time%>",
          "<%=lEesEventActivityTabObj.act_end_time%>",
          "<%=lEesEventActivityTabObj.reg_date%>",
          "<%=lEesEventActivityTabObj.event_id%>",
          "<%=lEesEventActivityTabObj.activity_desc%>",
          "<%=lEesEventActivityTabObj.activity_location%>",
          "<%=lEesEventActivityTabObj.sponsor_flag%>",
          "<%=lEesEventActivityTabObj.sponsored_by%>"
          );
<%
       }
   }
}
%>


