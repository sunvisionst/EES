CREATE TABLE EES_EVENT_ACTIVITY
(
  ORG_ID                                                                                              VARCHAR(10),
  ACTIVITY_ID                                                                                         VARCHAR(10),
  EVENT_ACT_TYPE                                                                                      VARCHAR(1),
  ACTIVITY_DATE                                                                                       VARCHAR(8),
  ACT_START_TIME                                                                                      VARCHAR(6),
  ACT_END_TIME                                                                                        VARCHAR(6),
  REG_DATE                                                                                            VARCHAR(8),
  EVENT_ID                                                                                            VARCHAR(10),
  ACTIVITY_DESC                                                                                       VARCHAR(100),
  ACTIVITY_LOCATION                                                                                   VARCHAR(100),
  SPONSOR_FLAG                                                                                        VARCHAR(1),
  SPONSORED_BY                                                                                        VARCHAR(100)
)
 WITH OIDS;
