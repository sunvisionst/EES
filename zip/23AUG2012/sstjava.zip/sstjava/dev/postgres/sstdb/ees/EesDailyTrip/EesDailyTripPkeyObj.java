package sstdb.ees.EesDailyTrip;


public class EesDailyTripPkeyObj
{
  public String                                 org_id;
  public String                                 wo_num;
}