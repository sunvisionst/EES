CREATE TABLE EES_ALUMNI_PROF_EXT
(
  student_org_id                                                                                      VARCHAR(10),
  alumni_id                                                                                           VARCHAR(10),
  seq_num                                                                                             NUMERIC(9),
  occupation                                                                                          VARCHAR(100),
  designation                                                                                         VARCHAR(60),
  joining_date                                                                                        VARCHAR(8),
  org_name                                                                                            VARCHAR(100),
  working_tech                                                                                        VARCHAR(100),
  area_of_interest                                                                                    VARCHAR(100),
  web_page_ind                                                                                        VARCHAR(1),
  office_address1                                                                                     VARCHAR(100),
  office_address2                                                                                     VARCHAR(100),
  city                                                                                                VARCHAR(50),
  state                                                                                               VARCHAR(50),
  zip                                                                                                 VARCHAR(10),
  country                                                                                             VARCHAR(50),
  phone_list                                                                                          VARCHAR(100),
  email_list                                                                                          VARCHAR(100),
  fax_list                                                                                            VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       STUDENT_ORG_ID                                                                                      CHAR(10),
       ALUMNI_ID                                                                                           CHAR(10),
       SEQ_NUM                                                                                             CHAR(9),
       OCCUPATION                                                                                          CHAR(100),
       DESIGNATION                                                                                         CHAR(60),
       JOINING_DATE                                                                                        CHAR(8),
       ORG_NAME                                                                                            CHAR(100),
       WORKING_TECH                                                                                        CHAR(100),
       AREA_OF_INTEREST                                                                                    CHAR(100),
       WEB_PAGE_IND                                                                                        CHAR(1),
       OFFICE_ADDRESS1                                                                                     CHAR(100),
       OFFICE_ADDRESS2                                                                                     CHAR(100),
       CITY                                                                                                CHAR(50),
       STATE                                                                                               CHAR(50),
       ZIP                                                                                                 CHAR(10),
       COUNTRY                                                                                             CHAR(50),
       PHONE_LIST                                                                                          CHAR(100),
       EMAIL_LIST                                                                                          CHAR(100),
       FAX_LIST                                                                                            CHAR(100)
    )
  )
  LOCATION ('ees_alumni_prof_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
