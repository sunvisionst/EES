{


   function vldDBSizeEnvEesAward
          (
            inTableName
          , inFieldName
          )
   {
      vldFieldDBSizeOrgId ( inTableName, inFieldName );
      vldFieldDBSizeAwardId ( inTableName, inFieldName );
      vldFieldDBSizeAwardName ( inTableName, inFieldName );
      vldFieldDBSizeAwardType ( inTableName, inFieldName );
      vldFieldDBSizeAwardDesc ( inTableName, inFieldName );
      vldFieldDBSizeAwardStartDate ( inTableName, inFieldName );
      vldFieldDBSizeAwardStartedBy ( inTableName, inFieldName );
   }



   function constructorEesAward
   (
      org_id,
      award_id,
      award_name,
      award_type,
      award_desc,
      award_start_date,
      award_started_by
   )
   {
      this.org_id = org_id;
      this.award_id = award_id;
      this.award_name = award_name;
      this.award_type = award_type;
      this.award_desc = award_desc;
      this.award_start_date = award_start_date;
      this.award_started_by = award_started_by;
   }



   function EesAwardFindByPkey()
   {
      var lRecNum = 0;
      while ( lRecNum < lEesAwardTabObjJSArr.length )
      {
         if
         ( 
           ( lEesAwardTabObjJSArr[lRecNum].org_id != document.form.org_id.value ) &&
           ( lEesAwardTabObjJSArr[lRecNum].award_id != document.form.award_id.value ) 
         )
           lRecNum++;
         else
           break;
      }
      return lRecNum;
   }



   function vldFieldDBSizeEesAwardTabObjOrgId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardId
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardName
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardType
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardDesc
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardStartDate
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         lJSFieldObj.focus();
      }
   }



   function vldFieldDBSizeEesAwardTabObjAwardStartedBy
          (
            inTableName
          , inFieldName
          )
   {
      var lJSFieldObj = document.getElementById(inFieldName);
      if ( lJSFieldObj != null && lJSFieldObj.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         lJSFieldObj.focus();
      }
      if ( lJSFieldObj != null && lJSFieldObj.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         lJSFieldObj.focus();
      }
   }






   function vldFieldDBSizeThisOrgId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardId
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardName
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >20 )
      {
         alert("Data base field size error. Size should be <= 20");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardType
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >10 )
      {
         alert("Data base field size error. Size should be <= 10");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardDesc
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >50 )
      {
         alert("Data base field size error. Size should be <= 50");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardStartDate
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >8 )
      {
         alert("Data base field size error. Size should be <= 8");
         inFieldName.focus();
      }
   }



   function vldFieldDBSizeThisAwardStartedBy
          (
            inTableName
          , inFieldName
          )
   {
      if ( inFieldName != null && inFieldName.value.indexOf("'") >= 0 )
      {
         alert("Single quote is not allowed");
         inFieldName.focus();
      }
      if ( inFieldName != null && inFieldName.value.length >100 )
      {
         alert("Data base field size error. Size should be <= 100");
         inFieldName.focus();
      }
   }



}