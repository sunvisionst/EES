package sstdb.ees.EesContract;


public class EesContractPkeyObj
{
  public String                                 org_id;
  public String                                 contract_id;
}