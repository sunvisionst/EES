
var lEesAdmMarkTabObjJSArr = new Array();
<%
{
   if ( lEesAdmMarkTabObjArrCache != null && lEesAdmMarkTabObjArrCache.size() > 0 )
   {
%>
       lEesAdmMarkTabObjJSArr = new Array(<%=lEesAdmMarkTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAdmMarkTabObjArrCache.size(); lRecNum++ )
       {
          EesAdmMarkTabObj lEesAdmMarkTabObj    =    new EesAdmMarkTabObj();
          lEesAdmMarkTabObj = (EesAdmMarkTabObj)lEesAdmMarkTabObjArrCache.get(lRecNum);
%>
          lEesAdmMarkTabObjJSArr[<%=lRecNum%>] = new constructorEesAdmMark
          (
          "<%=lEesAdmMarkTabObj.org_id%>",
          "<%=lEesAdmMarkTabObj.adm_req_id%>",
          "<%=lEesAdmMarkTabObj.academic_session%>",
          "<%=lEesAdmMarkTabObj.subject_code%>",
          "<%=lEesAdmMarkTabObj.class_num%>",
          "<%=lEesAdmMarkTabObj.class_std%>",
          "<%=lEesAdmMarkTabObj.course_id%>",
          "<%=lEesAdmMarkTabObj.course_term%>",
          "<%=lEesAdmMarkTabObj.course_stream%>",
          "<%=lEesAdmMarkTabObj.obtained_mark%>",
          "<%=lEesAdmMarkTabObj.max_mark%>"
          );
<%
       }
   }
}
%>


