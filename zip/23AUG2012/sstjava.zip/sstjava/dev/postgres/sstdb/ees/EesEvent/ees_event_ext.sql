CREATE TABLE EES_EVENT_EXT
(
  org_id                                                                                              VARCHAR(10),
  event_id                                                                                            VARCHAR(10),
  event_type                                                                                          VARCHAR(10),
  event_desc                                                                                          VARCHAR(100),
  status                                                                                              VARCHAR(5),
  event_start_date                                                                                    VARCHAR(8),
  event_close_date                                                                                    VARCHAR(8),
  ptl_publish_ind                                                                                     VARCHAR(5),
  ptl_publish_start_date                                                                              VARCHAR(8),
  ptl_publish_close_date                                                                              VARCHAR(8),
  ptl_user_id                                                                                         VARCHAR(50),
  rec_cre_by                                                                                          VARCHAR(50),
  rec_cre_date                                                                                        VARCHAR(8),
  rec_cre_time                                                                                        VARCHAR(6),
  rec_upd_by                                                                                          VARCHAR(50),
  rec_upd_date                                                                                        VARCHAR(8),
  rec_upd_time                                                                                        VARCHAR(6)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       EVENT_ID                                                                                            CHAR(10),
       EVENT_TYPE                                                                                          CHAR(10),
       EVENT_DESC                                                                                          CHAR(100),
       STATUS                                                                                              CHAR(5),
       EVENT_START_DATE                                                                                    CHAR(8),
       EVENT_CLOSE_DATE                                                                                    CHAR(8),
       PTL_PUBLISH_IND                                                                                     CHAR(5),
       PTL_PUBLISH_START_DATE                                                                              CHAR(8),
       PTL_PUBLISH_CLOSE_DATE                                                                              CHAR(8),
       PTL_USER_ID                                                                                         CHAR(50),
       REC_CRE_BY                                                                                          CHAR(50),
       REC_CRE_DATE                                                                                        CHAR(8),
       REC_CRE_TIME                                                                                        CHAR(6),
       REC_UPD_BY                                                                                          CHAR(50),
       REC_UPD_DATE                                                                                        CHAR(8),
       REC_UPD_TIME                                                                                        CHAR(6)
    )
  )
  LOCATION ('ees_event_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
