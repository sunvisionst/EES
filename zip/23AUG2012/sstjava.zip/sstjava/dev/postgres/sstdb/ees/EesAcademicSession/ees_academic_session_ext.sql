CREATE TABLE EES_ACADEMIC_SESSION_EXT
(
  org_id                                                                                              VARCHAR(10),
  academic_session                                                                                    VARCHAR(11),
  start_date                                                                                          VARCHAR(8),
  end_date                                                                                            VARCHAR(8),
  close_date                                                                                          VARCHAR(8),
  academic_session_sts                                                                                VARCHAR(1),
  semester_start_date                                                                                 VARCHAR(8),
  semester_end_date                                                                                   VARCHAR(8),
  semester_close_date                                                                                 VARCHAR(8)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACADEMIC_SESSION                                                                                    CHAR(11),
       START_DATE                                                                                          CHAR(8),
       END_DATE                                                                                            CHAR(8),
       CLOSE_DATE                                                                                          CHAR(8),
       ACADEMIC_SESSION_STS                                                                                CHAR(1),
       SEMESTER_START_DATE                                                                                 CHAR(8),
       SEMESTER_END_DATE                                                                                   CHAR(8),
       SEMESTER_CLOSE_DATE                                                                                 CHAR(8)
    )
  )
  LOCATION ('ees_academic_session_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
