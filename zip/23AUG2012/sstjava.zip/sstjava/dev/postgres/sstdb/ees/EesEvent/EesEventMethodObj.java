package sstdb.ees.EesEvent;

import sstdb.ees.EesEvent.EesEventTabObj;
import sstdb.ees.EesEvent.EesEventPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesEventMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesEventMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesEventMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesEventTabObj
               ( 
                 EesEventTabObj  outEesEventTabObj
               )
  {
  
     outEesEventTabObj.org_id = ""; 
     outEesEventTabObj.event_id = ""; 
     outEesEventTabObj.event_type = ""; 
     outEesEventTabObj.event_desc = ""; 
     outEesEventTabObj.status = ""; 
     outEesEventTabObj.event_start_date = ""; 
     outEesEventTabObj.event_close_date = ""; 
     outEesEventTabObj.ptl_publish_ind = ""; 
     outEesEventTabObj.ptl_publish_start_date = ""; 
     outEesEventTabObj.ptl_publish_close_date = ""; 
     outEesEventTabObj.ptl_user_id = ""; 
     outEesEventTabObj.rec_cre_by = ""; 
     outEesEventTabObj.rec_cre_date = ""; 
     outEesEventTabObj.rec_cre_time = ""; 
     outEesEventTabObj.rec_upd_by = ""; 
     outEesEventTabObj.rec_upd_date = ""; 
     outEesEventTabObj.rec_upd_time = ""; 
  }





  public void guiDateConvEesEventTabObj
               ( 
                 EesEventTabObj  inEesEventTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesEventTabObj.event_start_date != null && inEesEventTabObj.event_start_date.length() > 0 ) 
            inEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.event_start_date, lDateTimeTrgFmt);

          if ( inEesEventTabObj.event_close_date != null && inEesEventTabObj.event_close_date.length() > 0 ) 
            inEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.event_close_date, lDateTimeTrgFmt);

          if ( inEesEventTabObj.ptl_publish_start_date != null && inEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);

          if ( inEesEventTabObj.ptl_publish_close_date != null && inEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);

          if ( inEesEventTabObj.rec_cre_date != null && inEesEventTabObj.rec_cre_date.length() > 0 ) 
            inEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);

          if ( inEesEventTabObj.rec_upd_date != null && inEesEventTabObj.rec_upd_date.length() > 0 ) 
            inEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesEventByTabObj
               ( 
                 EesEventTabObj  inEesEventTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesEventTabObjArrCtx  = new ArrayList(); 
    lEesEventTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesEventTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesEventTabObjArrCtx.add(inEesEventTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesEventTabObjArrCtx.size();  lRecNum++ )
      {
        EesEventTabObj lEesEventTabObj = new EesEventTabObj();
        lEesEventTabObj = (EesEventTabObj)lEesEventTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesEventTabObj.org_id.equals(lEesEventTabObj.org_id) &&
              lEesEventTabObj.event_id.equals(lEesEventTabObj.event_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesEventTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesEventTabObjArrCtx.set(lRecNum, inEesEventTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesEventTabObjArrCtx",lEesEventTabObjArrCtx);
  }





  public void sortEesEventTabObjArr
               ( 
                 ArrayList  inEesEventTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesEventTabObjArr  = new ArrayList(); 
     lEesEventTabObjArr = inEesEventTabObjArr; 
     List lEesEventTabObjList  = new ArrayList(lEesEventTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesEventTabObjArr.size();  lRecNum++ )
     {
       EesEventTabObj  lEesEventTabObj = new EesEventTabObj(); 
       lEesEventTabObj = (EesEventTabObj)lEesEventTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesEventTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("event_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesEventTabObj.event_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.event_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("event_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesEventTabObj.event_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.event_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("event_desc") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesEventTabObj.event_desc.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.event_desc+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesEventTabObj.status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("event_start_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.event_start_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.event_start_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("event_close_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.event_close_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.event_close_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ptl_publish_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesEventTabObj.ptl_publish_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.ptl_publish_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ptl_publish_start_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.ptl_publish_start_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.ptl_publish_start_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ptl_publish_close_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.ptl_publish_close_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.ptl_publish_close_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ptl_user_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesEventTabObj.ptl_user_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.ptl_user_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesEventTabObj.rec_cre_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_cre_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.rec_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_cre_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesEventTabObj.rec_cre_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_cre_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesEventTabObj.rec_upd_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_upd_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesEventTabObj.rec_upd_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_upd_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("rec_upd_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesEventTabObj.rec_upd_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesEventTabObj.rec_upd_time+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesEventTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesEventTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesEventTabObjList ); 
     ArrayList lEesEventTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesEventTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesEventTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesEventTabObjArrSorted.add( (EesEventTabObj)lEesEventTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesEventTabObjArr.size();  lRecNum++ )
     {
       inEesEventTabObjArr.set( lRecNum, (EesEventTabObj)lEesEventTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesEventTabObj
               ( 
                 EesEventTabObj  inEesEventTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesEventTabObj.event_start_date != null && inEesEventTabObj.event_start_date.length() > 0 ) 
            inEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.event_close_date != null && inEesEventTabObj.event_close_date.length() > 0 ) 
            inEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_start_date != null && inEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_close_date != null && inEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_cre_date != null && inEesEventTabObj.rec_cre_date.length() > 0 ) 
            inEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_upd_date != null && inEesEventTabObj.rec_upd_date.length() > 0 ) 
            inEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_upd_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEventId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EVENT_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEventType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EVENT_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEventDesc
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EVENT_DESC";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STATUS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEventStartDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EVENT_START_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEventCloseDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EVENT_CLOSE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePtlPublishInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PTL_PUBLISH_IND";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePtlPublishStartDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PTL_PUBLISH_START_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePtlPublishCloseDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PTL_PUBLISH_CLOSE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePtlUserId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PTL_USER_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_BY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecCreTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_CRE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_BY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRecUpdTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REC_UPD_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesEventCount
               ( String inEesEventWhereText
               )
  {
    sop("gtEesEventCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventCount
               ( String inEesEventWhereText
               , String inEesEventSelectFieldList
               )
  {
    sop("gtEesEventCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesEventSelectFieldList+" AS count "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventRecByPkey
               ( EesEventPkeyObj inEesEventPkeyObj
               , EesEventTabObj  outEesEventTabObj
               )
  {
    sop("gtEesEventRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "event_id, "+
                                 "event_type, "+
                                 "event_desc, "+
                                 "status, "+
                                 "event_start_date, "+
                                 "event_close_date, "+
                                 "ptl_publish_ind, "+
                                 "ptl_publish_start_date, "+
                                 "ptl_publish_close_date, "+
                                 "ptl_user_id, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   EES_EVENT " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesEventPkeyObj.org_id+"' and "+
                              "event_id = "+"'"+inEesEventPkeyObj.event_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesEventTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesEventTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesEventTabObj.event_id  =  lResultSet.getString("EVENT_ID");
          outEesEventTabObj.event_type  =  lResultSet.getString("EVENT_TYPE");
          outEesEventTabObj.event_desc  =  lResultSet.getString("EVENT_DESC");
          outEesEventTabObj.status  =  lResultSet.getString("STATUS");
          outEesEventTabObj.event_start_date  =  lResultSet.getString("EVENT_START_DATE");

          if ( outEesEventTabObj.event_start_date != null && outEesEventTabObj.event_start_date.length() > 0 ) 
            outEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.event_start_date, lDateTimeTrgFmt);
          outEesEventTabObj.event_close_date  =  lResultSet.getString("EVENT_CLOSE_DATE");

          if ( outEesEventTabObj.event_close_date != null && outEesEventTabObj.event_close_date.length() > 0 ) 
            outEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.event_close_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_publish_ind  =  lResultSet.getString("PTL_PUBLISH_IND");
          outEesEventTabObj.ptl_publish_start_date  =  lResultSet.getString("PTL_PUBLISH_START_DATE");

          if ( outEesEventTabObj.ptl_publish_start_date != null && outEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            outEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_publish_close_date  =  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE");

          if ( outEesEventTabObj.ptl_publish_close_date != null && outEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            outEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_user_id  =  lResultSet.getString("PTL_USER_ID");
          outEesEventTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          outEesEventTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outEesEventTabObj.rec_cre_date != null && outEesEventTabObj.rec_cre_date.length() > 0 ) 
            outEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);
          outEesEventTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outEesEventTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          outEesEventTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outEesEventTabObj.rec_upd_date != null && outEesEventTabObj.rec_upd_date.length() > 0 ) 
            outEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
          outEesEventTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesEventTabObj( outEesEventTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventArr
               ( EesEventPkeyObj inEesEventPkeyObj
               , ArrayList  outEesEventTabObjArr
               )
  {
    sop("gtEesEventArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "event_id, "+
                                 "event_type, "+
                                 "event_desc, "+
                                 "status, "+
                                 "event_start_date, "+
                                 "event_close_date, "+
                                 "ptl_publish_ind, "+
                                 "ptl_publish_start_date, "+
                                 "ptl_publish_close_date, "+
                                 "ptl_user_id, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   EES_EVENT";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesEventTabObj  lEesEventTabObj = new EesEventTabObj();
          lEesEventTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesEventTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesEventTabObj.event_id  =  lResultSet.getString("EVENT_ID");
          lEesEventTabObj.event_type  =  lResultSet.getString("EVENT_TYPE");
          lEesEventTabObj.event_desc  =  lResultSet.getString("EVENT_DESC");
          lEesEventTabObj.status  =  lResultSet.getString("STATUS");
          lEesEventTabObj.event_start_date  =  lResultSet.getString("EVENT_START_DATE");

          if ( lEesEventTabObj.event_start_date != null && lEesEventTabObj.event_start_date.length() > 0 ) 
            lEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_start_date, lDateTimeTrgFmt);
          lEesEventTabObj.event_close_date  =  lResultSet.getString("EVENT_CLOSE_DATE");

          if ( lEesEventTabObj.event_close_date != null && lEesEventTabObj.event_close_date.length() > 0 ) 
            lEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_close_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_publish_ind  =  lResultSet.getString("PTL_PUBLISH_IND");
          lEesEventTabObj.ptl_publish_start_date  =  lResultSet.getString("PTL_PUBLISH_START_DATE");

          if ( lEesEventTabObj.ptl_publish_start_date != null && lEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_publish_close_date  =  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE");

          if ( lEesEventTabObj.ptl_publish_close_date != null && lEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_user_id  =  lResultSet.getString("PTL_USER_ID");
          lEesEventTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          lEesEventTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lEesEventTabObj.rec_cre_date != null && lEesEventTabObj.rec_cre_date.length() > 0 ) 
            lEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);
          lEesEventTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lEesEventTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          lEesEventTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lEesEventTabObj.rec_upd_date != null && lEesEventTabObj.rec_upd_date.length() > 0 ) 
            lEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
          lEesEventTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullEesEventTabObj( lEesEventTabObj );

          outEesEventTabObjArr.add(  lEesEventTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesEventTabObjArr != null && outEesEventTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesEventArr2XML
               ( String inEesEventWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesEventArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesEvent>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("event_id") )
              lXmlBuffer = lXmlBuffer +   "<EVENT_ID>" +  lResultSet.getString("EVENT_ID") +   "</EVENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("event_type") )
              lXmlBuffer = lXmlBuffer +   "<EVENT_TYPE>" +  lResultSet.getString("EVENT_TYPE") +   "</EVENT_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("event_desc") )
              lXmlBuffer = lXmlBuffer +   "<EVENT_DESC>" +  lResultSet.getString("EVENT_DESC") +   "</EVENT_DESC>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("status") )
              lXmlBuffer = lXmlBuffer +   "<STATUS>" +  lResultSet.getString("STATUS") +   "</STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("event_start_date") )
              lXmlBuffer = lXmlBuffer +   "<EVENT_START_DATE>" +  lResultSet.getString("EVENT_START_DATE") +   "</EVENT_START_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("event_close_date") )
              lXmlBuffer = lXmlBuffer +   "<EVENT_CLOSE_DATE>" +  lResultSet.getString("EVENT_CLOSE_DATE") +   "</EVENT_CLOSE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ptl_publish_ind") )
              lXmlBuffer = lXmlBuffer +   "<PTL_PUBLISH_IND>" +  lResultSet.getString("PTL_PUBLISH_IND") +   "</PTL_PUBLISH_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ptl_publish_start_date") )
              lXmlBuffer = lXmlBuffer +   "<PTL_PUBLISH_START_DATE>" +  lResultSet.getString("PTL_PUBLISH_START_DATE") +   "</PTL_PUBLISH_START_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ptl_publish_close_date") )
              lXmlBuffer = lXmlBuffer +   "<PTL_PUBLISH_CLOSE_DATE>" +  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE") +   "</PTL_PUBLISH_CLOSE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ptl_user_id") )
              lXmlBuffer = lXmlBuffer +   "<PTL_USER_ID>" +  lResultSet.getString("PTL_USER_ID") +   "</PTL_USER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_by") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_BY>" +  lResultSet.getString("REC_CRE_BY") +   "</REC_CRE_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_DATE>" +  lResultSet.getString("REC_CRE_DATE") +   "</REC_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_cre_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_CRE_TIME>" +  lResultSet.getString("REC_CRE_TIME") +   "</REC_CRE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_by") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_BY>" +  lResultSet.getString("REC_UPD_BY") +   "</REC_UPD_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_date") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_DATE>" +  lResultSet.getString("REC_UPD_DATE") +   "</REC_UPD_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("rec_upd_time") )
              lXmlBuffer = lXmlBuffer +   "<REC_UPD_TIME>" +  lResultSet.getString("REC_UPD_TIME") +   "</REC_UPD_TIME>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesEvent>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesEventRecByRowid
               ( String inRowId
               , EesEventTabObj  outEesEventTabObj
               )
  {
    sop("gtEesEventRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "event_id, "+
                                 "event_type, "+
                                 "event_desc, "+
                                 "status, "+
                                 "event_start_date, "+
                                 "event_close_date, "+
                                 "ptl_publish_ind, "+
                                 "ptl_publish_start_date, "+
                                 "ptl_publish_close_date, "+
                                 "ptl_user_id, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   EES_EVENT "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesEventTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesEventTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesEventTabObj.event_id  =  lResultSet.getString("EVENT_ID");
          outEesEventTabObj.event_type  =  lResultSet.getString("EVENT_TYPE");
          outEesEventTabObj.event_desc  =  lResultSet.getString("EVENT_DESC");
          outEesEventTabObj.status  =  lResultSet.getString("STATUS");
          outEesEventTabObj.event_start_date  =  lResultSet.getString("EVENT_START_DATE");

          if ( outEesEventTabObj.event_start_date != null && outEesEventTabObj.event_start_date.length() > 0 ) 
            outEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.event_start_date, lDateTimeTrgFmt);
          outEesEventTabObj.event_close_date  =  lResultSet.getString("EVENT_CLOSE_DATE");

          if ( outEesEventTabObj.event_close_date != null && outEesEventTabObj.event_close_date.length() > 0 ) 
            outEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.event_close_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_publish_ind  =  lResultSet.getString("PTL_PUBLISH_IND");
          outEesEventTabObj.ptl_publish_start_date  =  lResultSet.getString("PTL_PUBLISH_START_DATE");

          if ( outEesEventTabObj.ptl_publish_start_date != null && outEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            outEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_publish_close_date  =  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE");

          if ( outEesEventTabObj.ptl_publish_close_date != null && outEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            outEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);
          outEesEventTabObj.ptl_user_id  =  lResultSet.getString("PTL_USER_ID");
          outEesEventTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          outEesEventTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( outEesEventTabObj.rec_cre_date != null && outEesEventTabObj.rec_cre_date.length() > 0 ) 
            outEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);
          outEesEventTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          outEesEventTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          outEesEventTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( outEesEventTabObj.rec_upd_date != null && outEesEventTabObj.rec_upd_date.length() > 0 ) 
            outEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
          outEesEventTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesEventTabObj( outEesEventTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventArr
               ( String inEesEventWhereText
               , ArrayList  outEesEventTabObjArr
               )
  {
    sop("gtEesEventArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "event_id, "+
                                 "event_type, "+
                                 "event_desc, "+
                                 "status, "+
                                 "event_start_date, "+
                                 "event_close_date, "+
                                 "ptl_publish_ind, "+
                                 "ptl_publish_start_date, "+
                                 "ptl_publish_close_date, "+
                                 "ptl_user_id, "+
                                 "rec_cre_by, "+
                                 "rec_cre_date, "+
                                 "rec_cre_time, "+
                                 "rec_upd_by, "+
                                 "rec_upd_date, "+
                                 "rec_upd_time "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesEventTabObj  lEesEventTabObj = new EesEventTabObj();
          lEesEventTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesEventTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesEventTabObj.event_id  =  lResultSet.getString("EVENT_ID");
          lEesEventTabObj.event_type  =  lResultSet.getString("EVENT_TYPE");
          lEesEventTabObj.event_desc  =  lResultSet.getString("EVENT_DESC");
          lEesEventTabObj.status  =  lResultSet.getString("STATUS");
          lEesEventTabObj.event_start_date  =  lResultSet.getString("EVENT_START_DATE");

          if ( lEesEventTabObj.event_start_date != null && lEesEventTabObj.event_start_date.length() > 0 ) 
            lEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_start_date, lDateTimeTrgFmt);
          lEesEventTabObj.event_close_date  =  lResultSet.getString("EVENT_CLOSE_DATE");

          if ( lEesEventTabObj.event_close_date != null && lEesEventTabObj.event_close_date.length() > 0 ) 
            lEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_close_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_publish_ind  =  lResultSet.getString("PTL_PUBLISH_IND");
          lEesEventTabObj.ptl_publish_start_date  =  lResultSet.getString("PTL_PUBLISH_START_DATE");

          if ( lEesEventTabObj.ptl_publish_start_date != null && lEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_publish_close_date  =  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE");

          if ( lEesEventTabObj.ptl_publish_close_date != null && lEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);
          lEesEventTabObj.ptl_user_id  =  lResultSet.getString("PTL_USER_ID");
          lEesEventTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
          lEesEventTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");

          if ( lEesEventTabObj.rec_cre_date != null && lEesEventTabObj.rec_cre_date.length() > 0 ) 
            lEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);
          lEesEventTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
          lEesEventTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
          lEesEventTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");

          if ( lEesEventTabObj.rec_upd_date != null && lEesEventTabObj.rec_upd_date.length() > 0 ) 
            lEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
          lEesEventTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          removeNullEesEventTabObj( lEesEventTabObj );

          outEesEventTabObjArr.add(  lEesEventTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesEventTabObjArr != null && outEesEventTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventArrDist
               ( String inEesEventWhereText
               , String inDistEesEventField
               , ArrayList  outEesEventTabObjArr
               )
  {

    sop("gtEesEventArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";
  

       String lDistEesEventFieldQry = inDistEesEventField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesEventFieldQry+
                         " FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesEventField.substring(inDistEesEventField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesEventTabObj  lEesEventTabObj = new EesEventTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesEventTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("event_id") )
              lEesEventTabObj.event_id  =  lResultSet.getString("EVENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("event_type") )
              lEesEventTabObj.event_type  =  lResultSet.getString("EVENT_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("event_desc") )
              lEesEventTabObj.event_desc  =  lResultSet.getString("EVENT_DESC");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("status") )
              lEesEventTabObj.status  =  lResultSet.getString("STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("event_start_date") )
              {
              lEesEventTabObj.event_start_date  =  lResultSet.getString("EVENT_START_DATE");
  
          if ( lEesEventTabObj.event_start_date != null && lEesEventTabObj.event_start_date.length() > 0 ) 
            lEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_start_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("event_close_date") )
              {
              lEesEventTabObj.event_close_date  =  lResultSet.getString("EVENT_CLOSE_DATE");
  
          if ( lEesEventTabObj.event_close_date != null && lEesEventTabObj.event_close_date.length() > 0 ) 
            lEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.event_close_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ptl_publish_ind") )
              lEesEventTabObj.ptl_publish_ind  =  lResultSet.getString("PTL_PUBLISH_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ptl_publish_start_date") )
              {
              lEesEventTabObj.ptl_publish_start_date  =  lResultSet.getString("PTL_PUBLISH_START_DATE");
  
          if ( lEesEventTabObj.ptl_publish_start_date != null && lEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_start_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ptl_publish_close_date") )
              {
              lEesEventTabObj.ptl_publish_close_date  =  lResultSet.getString("PTL_PUBLISH_CLOSE_DATE");
  
          if ( lEesEventTabObj.ptl_publish_close_date != null && lEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.ptl_publish_close_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ptl_user_id") )
              lEesEventTabObj.ptl_user_id  =  lResultSet.getString("PTL_USER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_by") )
              lEesEventTabObj.rec_cre_by  =  lResultSet.getString("REC_CRE_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_date") )
              {
              lEesEventTabObj.rec_cre_date  =  lResultSet.getString("REC_CRE_DATE");
  
          if ( lEesEventTabObj.rec_cre_date != null && lEesEventTabObj.rec_cre_date.length() > 0 ) 
            lEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_cre_time") )
              lEesEventTabObj.rec_cre_time  =  lResultSet.getString("REC_CRE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_by") )
              lEesEventTabObj.rec_upd_by  =  lResultSet.getString("REC_UPD_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_date") )
              {
              lEesEventTabObj.rec_upd_date  =  lResultSet.getString("REC_UPD_DATE");
  
          if ( lEesEventTabObj.rec_upd_date != null && lEesEventTabObj.rec_upd_date.length() > 0 ) 
            lEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesEventTabObj.rec_upd_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("rec_upd_time") )
              lEesEventTabObj.rec_upd_time  =  lResultSet.getString("REC_UPD_TIME");

          }
          removeNullEesEventTabObj( lEesEventTabObj );

          outEesEventTabObjArr.add(  lEesEventTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesEventTabObjArr != null && outEesEventTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesEventStrArrDist
               ( String inEesEventWhereText
               , String inDistEesEventField
               , ArrayList  outEesEventTabObjArr
               )
  {

    sop("gtEesEventStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesEventStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";
  

       String lDistEesEventFieldQry = inDistEesEventField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesEventFieldQry+
                         " FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesEventField.substring(inDistEesEventField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesEventTabObjStr = "";
       while(lResultSet.next())
       {
          lEesEventTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesEventTabObjStr =   lEesEventTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesEventTabObjArr.add(  lEesEventTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesEventTabObjArr != null && outEesEventTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesEvent
               ( String inEesEventWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesEvent - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesEvent";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesEventTabObj
               ( 
                 EesEventTabObj  outEesEventTabObj
               )
  {
  
    if ( outEesEventTabObj.org_id == null ) 
     outEesEventTabObj.org_id = ""; 
    if ( outEesEventTabObj.event_id == null ) 
     outEesEventTabObj.event_id = ""; 
    if ( outEesEventTabObj.event_type == null ) 
     outEesEventTabObj.event_type = ""; 
    if ( outEesEventTabObj.event_desc == null ) 
     outEesEventTabObj.event_desc = ""; 
    if ( outEesEventTabObj.status == null ) 
     outEesEventTabObj.status = ""; 
    if ( outEesEventTabObj.event_start_date == null ) 
     outEesEventTabObj.event_start_date = ""; 
    if ( outEesEventTabObj.event_close_date == null ) 
     outEesEventTabObj.event_close_date = ""; 
    if ( outEesEventTabObj.ptl_publish_ind == null ) 
     outEesEventTabObj.ptl_publish_ind = ""; 
    if ( outEesEventTabObj.ptl_publish_start_date == null ) 
     outEesEventTabObj.ptl_publish_start_date = ""; 
    if ( outEesEventTabObj.ptl_publish_close_date == null ) 
     outEesEventTabObj.ptl_publish_close_date = ""; 
    if ( outEesEventTabObj.ptl_user_id == null ) 
     outEesEventTabObj.ptl_user_id = ""; 
    if ( outEesEventTabObj.rec_cre_by == null ) 
     outEesEventTabObj.rec_cre_by = ""; 
    if ( outEesEventTabObj.rec_cre_date == null ) 
     outEesEventTabObj.rec_cre_date = ""; 
    if ( outEesEventTabObj.rec_cre_time == null ) 
     outEesEventTabObj.rec_cre_time = ""; 
    if ( outEesEventTabObj.rec_upd_by == null ) 
     outEesEventTabObj.rec_upd_by = ""; 
    if ( outEesEventTabObj.rec_upd_date == null ) 
     outEesEventTabObj.rec_upd_date = ""; 
    if ( outEesEventTabObj.rec_upd_time == null ) 
     outEesEventTabObj.rec_upd_time = ""; 
  }





  public int insEesEventRec
               ( EesEventTabObj  inEesEventTabObj )
  {
    int lUpdateCount;
    sop("insEesEventRec - Started");
    gSSTErrorObj.sourceMethod = "insEesEventRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesEventTabObj.event_start_date != null && inEesEventTabObj.event_start_date.length() > 0 ) 
            inEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.event_close_date != null && inEesEventTabObj.event_close_date.length() > 0 ) 
            inEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_start_date != null && inEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_close_date != null && inEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_cre_date != null && inEesEventTabObj.rec_cre_date.length() > 0 ) 
            inEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_upd_date != null && inEesEventTabObj.rec_upd_date.length() > 0 ) 
            inEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_EVENT"+
                        "("+
                                "org_id,"+
                                "event_id,"+
                                "event_type,"+
                                "event_desc,"+
                                "status,"+
                                "event_start_date,"+
                                "event_close_date,"+
                                "ptl_publish_ind,"+
                                "ptl_publish_start_date,"+
                                "ptl_publish_close_date,"+
                                "ptl_user_id,"+
                                "rec_cre_by,"+
                                "rec_cre_date,"+
                                "rec_cre_time,"+
                                "rec_upd_by,"+
                                "rec_upd_date,"+
                                "rec_upd_time"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.event_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.event_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.event_desc+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.event_start_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.event_close_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.ptl_publish_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.ptl_publish_start_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.ptl_publish_close_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.ptl_user_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.rec_cre_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.rec_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.rec_cre_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.rec_upd_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesEventTabObj.rec_upd_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesEventTabObj.rec_upd_time+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesEventTabObj.org_id);
        lPreparedStatement.setString(2, inEesEventTabObj.event_id);
        lPreparedStatement.setString(3, inEesEventTabObj.event_type);
        lPreparedStatement.setString(4, inEesEventTabObj.event_desc);
        lPreparedStatement.setString(5, inEesEventTabObj.status);
        lPreparedStatement.setString(6, inEesEventTabObj.event_start_date);
        lPreparedStatement.setString(7, inEesEventTabObj.event_close_date);
        lPreparedStatement.setString(8, inEesEventTabObj.ptl_publish_ind);
        lPreparedStatement.setString(9, inEesEventTabObj.ptl_publish_start_date);
        lPreparedStatement.setString(10, inEesEventTabObj.ptl_publish_close_date);
        lPreparedStatement.setString(11, inEesEventTabObj.ptl_user_id);
        lPreparedStatement.setString(12, inEesEventTabObj.rec_cre_by);
        lPreparedStatement.setString(13, inEesEventTabObj.rec_cre_date);
        lPreparedStatement.setString(14, inEesEventTabObj.rec_cre_time);
        lPreparedStatement.setString(15, inEesEventTabObj.rec_upd_by);
        lPreparedStatement.setString(16, inEesEventTabObj.rec_upd_date);
        lPreparedStatement.setString(17, inEesEventTabObj.rec_upd_time);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesEventArr
               ( ArrayList  inEesEventTabObjArr 
               , String  inRowidFlag )
  {
    EesEventTabObj  lEesEventTabObj = new EesEventTabObj();
    int lUpdateCount;
    sop("insEesEventArr - Started");
    gSSTErrorObj.sourceMethod = "insEesEventArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesEventTabObjArr.size(); lNumRec++ )
      {
        lEesEventTabObj = (EesEventTabObj)inEesEventTabObjArr.get(lNumRec);

          if ( lEesEventTabObj.event_start_date != null && lEesEventTabObj.event_start_date.length() > 0 ) 
            lEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.event_start_date, lDateTimeSrcFmt);

          if ( lEesEventTabObj.event_close_date != null && lEesEventTabObj.event_close_date.length() > 0 ) 
            lEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.event_close_date, lDateTimeSrcFmt);

          if ( lEesEventTabObj.ptl_publish_start_date != null && lEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.ptl_publish_start_date, lDateTimeSrcFmt);

          if ( lEesEventTabObj.ptl_publish_close_date != null && lEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            lEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.ptl_publish_close_date, lDateTimeSrcFmt);

          if ( lEesEventTabObj.rec_cre_date != null && lEesEventTabObj.rec_cre_date.length() > 0 ) 
            lEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( lEesEventTabObj.rec_upd_date != null && lEesEventTabObj.rec_upd_date.length() > 0 ) 
            lEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesEventTabObj.rec_upd_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_EVENT"+
                        "("+
                        "org_id,"+
                        "event_id,"+
                        "event_type,"+
                        "event_desc,"+
                        "status,"+
                        "event_start_date,"+
                        "event_close_date,"+
                        "ptl_publish_ind,"+
                        "ptl_publish_start_date,"+
                        "ptl_publish_close_date,"+
                        "ptl_user_id,"+
                        "rec_cre_by,"+
                        "rec_cre_date,"+
                        "rec_cre_time,"+
                        "rec_upd_by,"+
                        "rec_upd_date,"+
                        "rec_upd_time"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.event_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.event_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.event_desc+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.event_start_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.event_close_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.ptl_publish_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.ptl_publish_start_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.ptl_publish_close_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.ptl_user_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.rec_cre_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.rec_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.rec_cre_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.rec_upd_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesEventTabObj.rec_upd_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesEventTabObj.rec_upd_time+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesEventTabObj.org_id);
            lPreparedStatement.setString(2, lEesEventTabObj.event_id);
            lPreparedStatement.setString(3, lEesEventTabObj.event_type);
            lPreparedStatement.setString(4, lEesEventTabObj.event_desc);
            lPreparedStatement.setString(5, lEesEventTabObj.status);
            lPreparedStatement.setString(6, lEesEventTabObj.event_start_date);
            lPreparedStatement.setString(7, lEesEventTabObj.event_close_date);
            lPreparedStatement.setString(8, lEesEventTabObj.ptl_publish_ind);
            lPreparedStatement.setString(9, lEesEventTabObj.ptl_publish_start_date);
            lPreparedStatement.setString(10, lEesEventTabObj.ptl_publish_close_date);
            lPreparedStatement.setString(11, lEesEventTabObj.ptl_user_id);
            lPreparedStatement.setString(12, lEesEventTabObj.rec_cre_by);
            lPreparedStatement.setString(13, lEesEventTabObj.rec_cre_date);
            lPreparedStatement.setString(14, lEesEventTabObj.rec_cre_time);
            lPreparedStatement.setString(15, lEesEventTabObj.rec_upd_by);
            lPreparedStatement.setString(16, lEesEventTabObj.rec_upd_date);
            lPreparedStatement.setString(17, lEesEventTabObj.rec_upd_time);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesEventReq2Obj
               ( HttpServletRequest inRequest
               , EesEventTabObj  outEesEventTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesEventTabObj.tab_rowid = lTabRowidValue;

    outEesEventTabObj.org_id = inRequest.getParameter("org_id");
    outEesEventTabObj.event_id = inRequest.getParameter("event_id");
    outEesEventTabObj.event_type = inRequest.getParameter("event_type");
    outEesEventTabObj.event_desc = inRequest.getParameter("event_desc");
    outEesEventTabObj.status = inRequest.getParameter("status");
    outEesEventTabObj.event_start_date = inRequest.getParameter("event_start_date");
    outEesEventTabObj.event_close_date = inRequest.getParameter("event_close_date");
    outEesEventTabObj.ptl_publish_ind = inRequest.getParameter("ptl_publish_ind");
    outEesEventTabObj.ptl_publish_start_date = inRequest.getParameter("ptl_publish_start_date");
    outEesEventTabObj.ptl_publish_close_date = inRequest.getParameter("ptl_publish_close_date");
    outEesEventTabObj.ptl_user_id = inRequest.getParameter("ptl_user_id");
    outEesEventTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by");
    outEesEventTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date");
    outEesEventTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time");
    outEesEventTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by");
    outEesEventTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date");
    outEesEventTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time");
    return lReturnValue;
  }


  public int popEesEventReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesEventTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesEventTabObj lEesEventTabObj= new EesEventTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesEventTabObj.tab_rowid = lTabRowidValue;

      lEesEventTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesEventTabObj.event_id = inRequest.getParameter("event_id_r"+lNumRec);
      lEesEventTabObj.event_type = inRequest.getParameter("event_type_r"+lNumRec);
      lEesEventTabObj.event_desc = inRequest.getParameter("event_desc_r"+lNumRec);
      lEesEventTabObj.status = inRequest.getParameter("status_r"+lNumRec);
      lEesEventTabObj.event_start_date = inRequest.getParameter("event_start_date_r"+lNumRec);
      lEesEventTabObj.event_close_date = inRequest.getParameter("event_close_date_r"+lNumRec);
      lEesEventTabObj.ptl_publish_ind = inRequest.getParameter("ptl_publish_ind_r"+lNumRec);
      lEesEventTabObj.ptl_publish_start_date = inRequest.getParameter("ptl_publish_start_date_r"+lNumRec);
      lEesEventTabObj.ptl_publish_close_date = inRequest.getParameter("ptl_publish_close_date_r"+lNumRec);
      lEesEventTabObj.ptl_user_id = inRequest.getParameter("ptl_user_id_r"+lNumRec);
      lEesEventTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
      lEesEventTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
      lEesEventTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
      lEesEventTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
      lEesEventTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
      lEesEventTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      outEesEventTabObjArr.add( lEesEventTabObj);
    }
    return lReturnValue;
  }


  public int popEesEventReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesEventTabObj outEesEventTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_event_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesEventTabObj.tab_rowid = lTabRowidValue;

        outEesEventTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesEventTabObj.event_id = inRequest.getParameter("event_id_r"+lNumRec);
        outEesEventTabObj.event_type = inRequest.getParameter("event_type_r"+lNumRec);
        outEesEventTabObj.event_desc = inRequest.getParameter("event_desc_r"+lNumRec);
        outEesEventTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        outEesEventTabObj.event_start_date = inRequest.getParameter("event_start_date_r"+lNumRec);
        outEesEventTabObj.event_close_date = inRequest.getParameter("event_close_date_r"+lNumRec);
        outEesEventTabObj.ptl_publish_ind = inRequest.getParameter("ptl_publish_ind_r"+lNumRec);
        outEesEventTabObj.ptl_publish_start_date = inRequest.getParameter("ptl_publish_start_date_r"+lNumRec);
        outEesEventTabObj.ptl_publish_close_date = inRequest.getParameter("ptl_publish_close_date_r"+lNumRec);
        outEesEventTabObj.ptl_user_id = inRequest.getParameter("ptl_user_id_r"+lNumRec);
        outEesEventTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
        outEesEventTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        outEesEventTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        outEesEventTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
        outEesEventTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        outEesEventTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesEventReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesEventTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesEventTabObj lEesEventTabObj= new EesEventTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_event_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesEventTabObj.tab_rowid = lTabRowidValue;

        lEesEventTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesEventTabObj.event_id = inRequest.getParameter("event_id_r"+lNumRec);
        lEesEventTabObj.event_type = inRequest.getParameter("event_type_r"+lNumRec);
        lEesEventTabObj.event_desc = inRequest.getParameter("event_desc_r"+lNumRec);
        lEesEventTabObj.status = inRequest.getParameter("status_r"+lNumRec);
        lEesEventTabObj.event_start_date = inRequest.getParameter("event_start_date_r"+lNumRec);
        lEesEventTabObj.event_close_date = inRequest.getParameter("event_close_date_r"+lNumRec);
        lEesEventTabObj.ptl_publish_ind = inRequest.getParameter("ptl_publish_ind_r"+lNumRec);
        lEesEventTabObj.ptl_publish_start_date = inRequest.getParameter("ptl_publish_start_date_r"+lNumRec);
        lEesEventTabObj.ptl_publish_close_date = inRequest.getParameter("ptl_publish_close_date_r"+lNumRec);
        lEesEventTabObj.ptl_user_id = inRequest.getParameter("ptl_user_id_r"+lNumRec);
        lEesEventTabObj.rec_cre_by = inRequest.getParameter("rec_cre_by_r"+lNumRec);
        lEesEventTabObj.rec_cre_date = inRequest.getParameter("rec_cre_date_r"+lNumRec);
        lEesEventTabObj.rec_cre_time = inRequest.getParameter("rec_cre_time_r"+lNumRec);
        lEesEventTabObj.rec_upd_by = inRequest.getParameter("rec_upd_by_r"+lNumRec);
        lEesEventTabObj.rec_upd_date = inRequest.getParameter("rec_upd_date_r"+lNumRec);
        lEesEventTabObj.rec_upd_time = inRequest.getParameter("rec_upd_time_r"+lNumRec);
        outEesEventTabObjArr.add( lEesEventTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesEventRecByRowid
               ( String inRowId
               , EesEventTabObj  inEesEventTabObj
               )
  {
    int lUpdateCount;
    sop("updEesEventRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesEventRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesEventTabObj.event_start_date != null && inEesEventTabObj.event_start_date.length() > 0 ) 
            inEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.event_close_date != null && inEesEventTabObj.event_close_date.length() > 0 ) 
            inEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_start_date != null && inEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_close_date != null && inEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_cre_date != null && inEesEventTabObj.rec_cre_date.length() > 0 ) 
            inEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_upd_date != null && inEesEventTabObj.rec_upd_date.length() > 0 ) 
            inEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EVENT ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesEventTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesEventTabObj.org_id+"', ";
      if ( inEesEventTabObj.event_id != null  )         lSqlStmt = lSqlStmt + "event_id = "+"'"+inEesEventTabObj.event_id+"', ";
      if ( inEesEventTabObj.event_type != null  )         lSqlStmt = lSqlStmt + "event_type = "+"'"+inEesEventTabObj.event_type+"', ";
      if ( inEesEventTabObj.event_desc != null  )         lSqlStmt = lSqlStmt + "event_desc = "+"'"+inEesEventTabObj.event_desc+"', ";
      if ( inEesEventTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inEesEventTabObj.status+"', ";
      if ( inEesEventTabObj.event_start_date != null  )         lSqlStmt = lSqlStmt + "event_start_date = "+"'"+inEesEventTabObj.event_start_date+"', ";
      if ( inEesEventTabObj.event_close_date != null  )         lSqlStmt = lSqlStmt + "event_close_date = "+"'"+inEesEventTabObj.event_close_date+"', ";
      if ( inEesEventTabObj.ptl_publish_ind != null  )         lSqlStmt = lSqlStmt + "ptl_publish_ind = "+"'"+inEesEventTabObj.ptl_publish_ind+"', ";
      if ( inEesEventTabObj.ptl_publish_start_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_start_date = "+"'"+inEesEventTabObj.ptl_publish_start_date+"', ";
      if ( inEesEventTabObj.ptl_publish_close_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_close_date = "+"'"+inEesEventTabObj.ptl_publish_close_date+"', ";
      if ( inEesEventTabObj.ptl_user_id != null  )         lSqlStmt = lSqlStmt + "ptl_user_id = "+"'"+inEesEventTabObj.ptl_user_id+"', ";
      if ( inEesEventTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = "+"'"+inEesEventTabObj.rec_cre_by+"', ";
      if ( inEesEventTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inEesEventTabObj.rec_cre_date+"', ";
      if ( inEesEventTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inEesEventTabObj.rec_cre_time+"', ";
      if ( inEesEventTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = "+"'"+inEesEventTabObj.rec_upd_by+"', ";
      if ( inEesEventTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inEesEventTabObj.rec_upd_date+"', ";
      if ( inEesEventTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inEesEventTabObj.rec_upd_time+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesEventRecByPkey
               ( EesEventPkeyObj inEesEventPkeyObj
               , EesEventTabObj  inEesEventTabObj
               )
  {
    int lUpdateCount;
    sop("updEesEventRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesEventRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesEventTabObj.event_start_date != null && inEesEventTabObj.event_start_date.length() > 0 ) 
            inEesEventTabObj.event_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.event_close_date != null && inEesEventTabObj.event_close_date.length() > 0 ) 
            inEesEventTabObj.event_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.event_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_start_date != null && inEesEventTabObj.ptl_publish_start_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_start_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.ptl_publish_close_date != null && inEesEventTabObj.ptl_publish_close_date.length() > 0 ) 
            inEesEventTabObj.ptl_publish_close_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.ptl_publish_close_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_cre_date != null && inEesEventTabObj.rec_cre_date.length() > 0 ) 
            inEesEventTabObj.rec_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_cre_date, lDateTimeSrcFmt);

          if ( inEesEventTabObj.rec_upd_date != null && inEesEventTabObj.rec_upd_date.length() > 0 ) 
            inEesEventTabObj.rec_upd_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesEventTabObj.rec_upd_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EVENT ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesEventTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesEventTabObj.event_id != null  )         lSqlStmt = lSqlStmt + "event_id = ? , ";
        if ( inEesEventTabObj.event_type != null  )         lSqlStmt = lSqlStmt + "event_type = ? , ";
        if ( inEesEventTabObj.event_desc != null  )         lSqlStmt = lSqlStmt + "event_desc = ? , ";
        if ( inEesEventTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = ? , ";
        if ( inEesEventTabObj.event_start_date != null  )         lSqlStmt = lSqlStmt + "event_start_date = ? , ";
        if ( inEesEventTabObj.event_close_date != null  )         lSqlStmt = lSqlStmt + "event_close_date = ? , ";
        if ( inEesEventTabObj.ptl_publish_ind != null  )         lSqlStmt = lSqlStmt + "ptl_publish_ind = ? , ";
        if ( inEesEventTabObj.ptl_publish_start_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_start_date = ? , ";
        if ( inEesEventTabObj.ptl_publish_close_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_close_date = ? , ";
        if ( inEesEventTabObj.ptl_user_id != null  )         lSqlStmt = lSqlStmt + "ptl_user_id = ? , ";
        if ( inEesEventTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = ? , ";
        if ( inEesEventTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = ? , ";
        if ( inEesEventTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = ? , ";
        if ( inEesEventTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = ? , ";
        if ( inEesEventTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = ? , ";
        if ( inEesEventTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesEventTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesEventTabObj.org_id+"', ";
        if ( inEesEventTabObj.event_id != null  )         lSqlStmt = lSqlStmt + "event_id = "+"'"+inEesEventTabObj.event_id+"', ";
        if ( inEesEventTabObj.event_type != null  )         lSqlStmt = lSqlStmt + "event_type = "+"'"+inEesEventTabObj.event_type+"', ";
        if ( inEesEventTabObj.event_desc != null  )         lSqlStmt = lSqlStmt + "event_desc = "+"'"+inEesEventTabObj.event_desc+"', ";
        if ( inEesEventTabObj.status != null  )         lSqlStmt = lSqlStmt + "status = "+"'"+inEesEventTabObj.status+"', ";
        if ( inEesEventTabObj.event_start_date != null  )         lSqlStmt = lSqlStmt + "event_start_date = "+"'"+inEesEventTabObj.event_start_date+"', ";
        if ( inEesEventTabObj.event_close_date != null  )         lSqlStmt = lSqlStmt + "event_close_date = "+"'"+inEesEventTabObj.event_close_date+"', ";
        if ( inEesEventTabObj.ptl_publish_ind != null  )         lSqlStmt = lSqlStmt + "ptl_publish_ind = "+"'"+inEesEventTabObj.ptl_publish_ind+"', ";
        if ( inEesEventTabObj.ptl_publish_start_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_start_date = "+"'"+inEesEventTabObj.ptl_publish_start_date+"', ";
        if ( inEesEventTabObj.ptl_publish_close_date != null  )         lSqlStmt = lSqlStmt + "ptl_publish_close_date = "+"'"+inEesEventTabObj.ptl_publish_close_date+"', ";
        if ( inEesEventTabObj.ptl_user_id != null  )         lSqlStmt = lSqlStmt + "ptl_user_id = "+"'"+inEesEventTabObj.ptl_user_id+"', ";
        if ( inEesEventTabObj.rec_cre_by != null  )         lSqlStmt = lSqlStmt + "rec_cre_by = "+"'"+inEesEventTabObj.rec_cre_by+"', ";
        if ( inEesEventTabObj.rec_cre_date != null  )         lSqlStmt = lSqlStmt + "rec_cre_date = "+"'"+inEesEventTabObj.rec_cre_date+"', ";
        if ( inEesEventTabObj.rec_cre_time != null  )         lSqlStmt = lSqlStmt + "rec_cre_time = "+"'"+inEesEventTabObj.rec_cre_time+"', ";
        if ( inEesEventTabObj.rec_upd_by != null  )         lSqlStmt = lSqlStmt + "rec_upd_by = "+"'"+inEesEventTabObj.rec_upd_by+"', ";
        if ( inEesEventTabObj.rec_upd_date != null  )         lSqlStmt = lSqlStmt + "rec_upd_date = "+"'"+inEesEventTabObj.rec_upd_date+"', ";
        if ( inEesEventTabObj.rec_upd_time != null  )         lSqlStmt = lSqlStmt + "rec_upd_time = "+"'"+inEesEventTabObj.rec_upd_time+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesEventPkeyObj.org_id+"' and "+
                              "event_id = "+"'"+inEesEventPkeyObj.event_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesEventTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.org_id); } 
         if ( inEesEventTabObj.event_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.event_id); } 
         if ( inEesEventTabObj.event_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.event_type); } 
         if ( inEesEventTabObj.event_desc != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.event_desc); } 
         if ( inEesEventTabObj.status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.status); } 
         if ( inEesEventTabObj.event_start_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.event_start_date); } 
         if ( inEesEventTabObj.event_close_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.event_close_date); } 
         if ( inEesEventTabObj.ptl_publish_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.ptl_publish_ind); } 
         if ( inEesEventTabObj.ptl_publish_start_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.ptl_publish_start_date); } 
         if ( inEesEventTabObj.ptl_publish_close_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.ptl_publish_close_date); } 
         if ( inEesEventTabObj.ptl_user_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.ptl_user_id); } 
         if ( inEesEventTabObj.rec_cre_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_cre_by); } 
         if ( inEesEventTabObj.rec_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_cre_date); } 
         if ( inEesEventTabObj.rec_cre_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_cre_time); } 
         if ( inEesEventTabObj.rec_upd_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_upd_by); } 
         if ( inEesEventTabObj.rec_upd_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_upd_date); } 
         if ( inEesEventTabObj.rec_upd_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesEventTabObj.rec_upd_time); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesEventRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesEventRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesEventRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_EVENT "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesEventRecByPkeyWithSet
               ( EesEventPkeyObj inEesEventPkeyObj
               , String  inEesEventSetlist
               )
  {
    int lUpdateCount;
    sop("updEesEventRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesEventRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EVENT ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesEventSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesEventPkeyObj.org_id+"' and "+
                              "event_id = "+"'"+inEesEventPkeyObj.event_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesEventRecByRowidWithSet
               ( String inRowId
               , String  inEesEventSetlist
               )
  {
    int lUpdateCount;
    sop("updEesEventRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesEventRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EVENT ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesEventSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesEventRecByWhereWithSet
               ( String inEesEventWhereText
               , String  inEesEventSetlist
               )
  {
    int lUpdateCount;
    sop("updEesEventRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesEventRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EVENT ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesEventSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesEventRecByPkey
               ( EesEventPkeyObj  inEesEventPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesEventRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesEventRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_EVENT " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesEventPkeyObj.org_id+"' and "+
                              "event_id = "+"'"+inEesEventPkeyObj.event_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesEventByWhere
               ( String inEesEventWhereText
               )
  {
    int lUpdateCount;
    sop("delEesEventByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesEventByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesEventWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesEventWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_EVENT "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
