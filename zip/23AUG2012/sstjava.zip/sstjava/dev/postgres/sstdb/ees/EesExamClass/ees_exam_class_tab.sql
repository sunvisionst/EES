CREATE TABLE EES_EXAM_CLASS
(
  ORG_ID                                                                                              VARCHAR(10),
  EXAM_ID                                                                                             VARCHAR(10),
  CLASS_ID                                                                                            VARCHAR(20),
  CLASS_NUM                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  CLASS_SECTION                                                                                       VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  EXAM_TERM                                                                                           VARCHAR(10),
  EXAM_TYPE                                                                                           VARCHAR(10),
  YEAR                                                                                                NUMERIC(4),
  MONTH                                                                                               NUMERIC(2),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  EXAM_STATUS                                                                                         VARCHAR(1),
  EXAM_STATUS_DATE                                                                                    VARCHAR(8)
)
 WITH OIDS;
