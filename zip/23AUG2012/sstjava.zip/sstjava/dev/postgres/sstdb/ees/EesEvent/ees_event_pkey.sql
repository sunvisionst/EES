ALTER TABLE           EES_EVENT
  ADD                 CONSTRAINT EES_EVENT_PK
  PRIMARY             KEY
  ( ORG_ID, EVENT_ID )
;
