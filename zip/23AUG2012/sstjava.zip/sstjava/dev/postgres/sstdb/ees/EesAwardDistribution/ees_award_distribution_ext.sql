CREATE TABLE EES_AWARD_DISTRIBUTION_EXT
(
  org_id                                                                                              VARCHAR(10),
  event_id                                                                                            VARCHAR(10),
  awardee_id                                                                                          VARCHAR(10),
  awardee_type                                                                                        VARCHAR(1),
  award_id                                                                                            VARCHAR(10),
  distribution_date                                                                                   VARCHAR(8),
  distributed_by                                                                                      VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       EVENT_ID                                                                                            CHAR(10),
       AWARDEE_ID                                                                                          CHAR(10),
       AWARDEE_TYPE                                                                                        CHAR(1),
       AWARD_ID                                                                                            CHAR(10),
       DISTRIBUTION_DATE                                                                                   CHAR(8),
       DISTRIBUTED_BY                                                                                      CHAR(100)
    )
  )
  LOCATION ('ees_award_distribution_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
