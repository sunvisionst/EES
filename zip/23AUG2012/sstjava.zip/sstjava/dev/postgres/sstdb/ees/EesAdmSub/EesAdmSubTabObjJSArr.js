
var lEesAdmSubTabObjJSArr = new Array();
<%
{
   if ( lEesAdmSubTabObjArrCache != null && lEesAdmSubTabObjArrCache.size() > 0 )
   {
%>
       lEesAdmSubTabObjJSArr = new Array(<%=lEesAdmSubTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAdmSubTabObjArrCache.size(); lRecNum++ )
       {
          EesAdmSubTabObj lEesAdmSubTabObj    =    new EesAdmSubTabObj();
          lEesAdmSubTabObj = (EesAdmSubTabObj)lEesAdmSubTabObjArrCache.get(lRecNum);
%>
          lEesAdmSubTabObjJSArr[<%=lRecNum%>] = new constructorEesAdmSub
          (
          "<%=lEesAdmSubTabObj.org_id%>",
          "<%=lEesAdmSubTabObj.academic_session%>",
          "<%=lEesAdmSubTabObj.subject_code%>",
          "<%=lEesAdmSubTabObj.class_num%>",
          "<%=lEesAdmSubTabObj.course_id%>",
          "<%=lEesAdmSubTabObj.class_std%>",
          "<%=lEesAdmSubTabObj.course_term%>",
          "<%=lEesAdmSubTabObj.course_stream%>",
          "<%=lEesAdmSubTabObj.max_mark%>",
          "<%=lEesAdmSubTabObj.min_mark%>",
          "<%=lEesAdmSubTabObj.description%>"
          );
<%
       }
   }
}
%>


