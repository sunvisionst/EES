CREATE TABLE EES_DAILY_TRIP_EXT
(
  org_id                                                                                              VARCHAR(10),
  wo_num                                                                                              VARCHAR(10),
  wo_date                                                                                             VARCHAR(8),
  route_id                                                                                            VARCHAR(10),
  trip_id                                                                                             VARCHAR(10),
  trip_num                                                                                            VARCHAR(5),
  vehicle_id                                                                                          VARCHAR(10),
  driver_id                                                                                           VARCHAR(10),
  start_time                                                                                          VARCHAR(6),
  end_time                                                                                            VARCHAR(6),
  omr                                                                                                 NUMERIC(9),
  cmr                                                                                                 NUMERIC(9),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       WO_NUM                                                                                              CHAR(10),
       WO_DATE                                                                                             CHAR(8),
       ROUTE_ID                                                                                            CHAR(10),
       TRIP_ID                                                                                             CHAR(10),
       TRIP_NUM                                                                                            CHAR(5),
       VEHICLE_ID                                                                                          CHAR(10),
       DRIVER_ID                                                                                           CHAR(10),
       START_TIME                                                                                          CHAR(6),
       END_TIME                                                                                            CHAR(6),
       OMR                                                                                                 CHAR(9),
       CMR                                                                                                 CHAR(9),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('ees_daily_trip_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
