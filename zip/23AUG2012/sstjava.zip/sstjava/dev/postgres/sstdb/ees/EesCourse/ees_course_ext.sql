CREATE TABLE EES_COURSE_EXT
(
  org_id                                                                                              VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  description                                                                                         VARCHAR(60),
  dept_id                                                                                             VARCHAR(10),
  course_code                                                                                         VARCHAR(10),
  short_code                                                                                          VARCHAR(10),
  sst_course_id                                                                                       VARCHAR(10),
  duration_type                                                                                       VARCHAR(1),
  course_duration                                                                                     NUMERIC(9),
  class_id_pattern                                                                                    VARCHAR(100),
  remark                                                                                              VARCHAR(100),
  board_university                                                                                    VARCHAR(100),
  stream_ind                                                                                          VARCHAR(1),
  course_strength                                                                                     NUMERIC(9),
  quota_qty                                                                                           NUMERIC(9),
  course_coord                                                                                        VARCHAR(20),
  min_fee_amt                                                                                         NUMERIC(13,2),
  cc_ptl_user_id                                                                                      VARCHAR(50),
  class_std                                                                                           VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       DESCRIPTION                                                                                         CHAR(60),
       DEPT_ID                                                                                             CHAR(10),
       COURSE_CODE                                                                                         CHAR(10),
       SHORT_CODE                                                                                          CHAR(10),
       SST_COURSE_ID                                                                                       CHAR(10),
       DURATION_TYPE                                                                                       CHAR(1),
       COURSE_DURATION                                                                                     CHAR(9),
       CLASS_ID_PATTERN                                                                                    CHAR(100),
       REMARK                                                                                              CHAR(100),
       BOARD_UNIVERSITY                                                                                    CHAR(100),
       STREAM_IND                                                                                          CHAR(1),
       COURSE_STRENGTH                                                                                     CHAR(9),
       QUOTA_QTY                                                                                           CHAR(9),
       COURSE_COORD                                                                                        CHAR(20),
       MIN_FEE_AMT                                                                                         CHAR(13),
       CC_PTL_USER_ID                                                                                      CHAR(50),
       CLASS_STD                                                                                           CHAR(10)
    )
  )
  LOCATION ('ees_course_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
