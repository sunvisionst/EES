CREATE TABLE EES_EVENT_REG_STUD_EXT
(
  org_id                                                                                              VARCHAR(10),
  activity_id                                                                                         VARCHAR(10),
  student_id                                                                                          VARCHAR(25),
  event_id                                                                                            VARCHAR(10),
  status                                                                                              VARCHAR(1),
  status_date                                                                                         VARCHAR(8)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACTIVITY_ID                                                                                         CHAR(10),
       STUDENT_ID                                                                                          CHAR(25),
       EVENT_ID                                                                                            CHAR(10),
       STATUS                                                                                              CHAR(1),
       STATUS_DATE                                                                                         CHAR(8)
    )
  )
  LOCATION ('ees_event_reg_stud_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
