package sstdb.ees.EesAcademicSession;


public class EesAcademicSessionTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 academic_session;
  public String                                 start_date;
  public String                                 end_date;
  public String                                 close_date;
  public String                                 academic_session_sts;
  public String                                 semester_start_date;
  public String                                 semester_end_date;
  public String                                 semester_close_date;





  public short                                  org_id_ind;
  public short                                  academic_session_ind;
  public short                                  start_date_ind;
  public short                                  end_date_ind;
  public short                                  close_date_ind;
  public short                                  academic_session_sts_ind;
  public short                                  semester_start_date_ind;
  public short                                  semester_end_date_ind;
  public short                                  semester_close_date_ind;


  public EesAcademicSessionTabObj(){}


  public EesAcademicSessionTabObj
  (
    String org_id,
    String academic_session,
    String start_date,
    String end_date,
    String close_date,
    String academic_session_sts,
    String semester_start_date,
    String semester_end_date,
    String semester_close_date
  )
  {
     this.org_id = org_id;
     this.academic_session = academic_session;
     this.start_date = start_date;
     this.end_date = end_date;
     this.close_date = close_date;
     this.academic_session_sts = academic_session_sts;
     this.semester_start_date = semester_start_date;
     this.semester_end_date = semester_end_date;
     this.semester_close_date = semester_close_date;
  }

  public String getorg_id()                           { return org_id; }
  public String getacademic_session()                      { return academic_session; }
  public String getstart_date()                         { return start_date; }
  public String getend_date()                          { return end_date; }
  public String getclose_date()                         { return close_date; }
  public String getacademic_session_sts()                    { return academic_session_sts; }
  public String getsemester_start_date()                    { return semester_start_date; }
  public String getsemester_end_date()                     { return semester_end_date; }
  public String getsemester_close_date()                    { return semester_close_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setstart_date(String start_date )                { this.start_date = start_date; }
  public void  setend_date(String end_date )                  { this.end_date = end_date; }
  public void  setclose_date(String close_date )                { this.close_date = close_date; }
  public void  setacademic_session_sts(String academic_session_sts )      { this.academic_session_sts = academic_session_sts; }
  public void  setsemester_start_date(String semester_start_date )       { this.semester_start_date = semester_start_date; }
  public void  setsemester_end_date(String semester_end_date )         { this.semester_end_date = semester_end_date; }
  public void  setsemester_close_date(String semester_close_date )       { this.semester_close_date = semester_close_date; }
}