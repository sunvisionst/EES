CREATE TABLE EES_APPC_PREV_MARK
(
  ORG_ID                                                                                              VARCHAR(10),
  APPLICANT_ID                                                                                        VARCHAR(25),
  STMM_1                                                                                              NUMERIC(9,2),
  STMO_1                                                                                              NUMERIC(9,2),
  SPMM_1                                                                                              NUMERIC(9,2),
  SPMO_1                                                                                              NUMERIC(9,2),
  STMM_2                                                                                              NUMERIC(9,2),
  STMO_2                                                                                              NUMERIC(9,2),
  SPMM_2                                                                                              NUMERIC(9,2),
  SPMO_2                                                                                              NUMERIC(9,2),
  STMM_3                                                                                              NUMERIC(9,2),
  STMO_3                                                                                              NUMERIC(9,2),
  SPMM_3                                                                                              NUMERIC(9,2),
  SPMO_3                                                                                              NUMERIC(9,2),
  STMM_4                                                                                              NUMERIC(9,2),
  STMO_4                                                                                              NUMERIC(9,2),
  SPMM_4                                                                                              NUMERIC(9,2),
  SPMO_4                                                                                              NUMERIC(9,2),
  ADM_REQ_ID_REQ                                                                                      VARCHAR(30),
  ADM_REQ_ID_LIST                                                                                     VARCHAR(30)
)
 WITH OIDS;
