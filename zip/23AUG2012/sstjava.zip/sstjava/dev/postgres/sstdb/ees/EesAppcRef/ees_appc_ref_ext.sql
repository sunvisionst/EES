CREATE TABLE EES_APPC_REF_EXT
(
  org_id                                                                                              VARCHAR(10),
  applicant_id                                                                                        VARCHAR(25),
  seq_num                                                                                             NUMERIC(2),
  application_form_num                                                                                VARCHAR(20),
  student_id                                                                                          VARCHAR(25),
  roll_num                                                                                            VARCHAR(20),
  ref_name                                                                                            VARCHAR(100),
  address_1                                                                                           VARCHAR(100),
  address_2                                                                                           VARCHAR(100),
  phone_list                                                                                          VARCHAR(100),
  email_list                                                                                          VARCHAR(100),
  fax_list                                                                                            VARCHAR(100),
  adm_req_id_req                                                                                      VARCHAR(30),
  adm_req_id_list                                                                                     VARCHAR(30)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       APPLICANT_ID                                                                                        CHAR(25),
       SEQ_NUM                                                                                             CHAR(2),
       APPLICATION_FORM_NUM                                                                                CHAR(20),
       STUDENT_ID                                                                                          CHAR(25),
       ROLL_NUM                                                                                            CHAR(20),
       REF_NAME                                                                                            CHAR(100),
       ADDRESS_1                                                                                           CHAR(100),
       ADDRESS_2                                                                                           CHAR(100),
       PHONE_LIST                                                                                          CHAR(100),
       EMAIL_LIST                                                                                          CHAR(100),
       FAX_LIST                                                                                            CHAR(100),
       ADM_REQ_ID_REQ                                                                                      CHAR(30),
       ADM_REQ_ID_LIST                                                                                     CHAR(30)
    )
  )
  LOCATION ('ees_appc_ref_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
