CREATE TABLE EES_CLASS_SCH_SHIP_EXT
(
  org_id                                                                                              VARCHAR(10),
  scholorship_id                                                                                      VARCHAR(10),
  class_id                                                                                            VARCHAR(20),
  scholorship_amt                                                                                     NUMERIC(13,2),
  start_date                                                                                          VARCHAR(8),
  end_date                                                                                            VARCHAR(8),
  scholorship_status                                                                                  VARCHAR(1)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       SCHOLORSHIP_ID                                                                                      CHAR(10),
       CLASS_ID                                                                                            CHAR(20),
       SCHOLORSHIP_AMT                                                                                     CHAR(13),
       START_DATE                                                                                          CHAR(8),
       END_DATE                                                                                            CHAR(8),
       SCHOLORSHIP_STATUS                                                                                  CHAR(1)
    )
  )
  LOCATION ('ees_class_sch_ship_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
