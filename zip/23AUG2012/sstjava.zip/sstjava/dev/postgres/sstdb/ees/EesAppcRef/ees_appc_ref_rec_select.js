function EesAppcRefRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("applicant_id").value  = document.getElementById("applicant_id"+"_r"+inRecNum).value;
    document.getElementById("applicant_id").readOnly = true;
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("seq_num").readOnly = true;
    document.getElementById("application_form_num").value  = document.getElementById("application_form_num"+"_r"+inRecNum).value;
    document.getElementById("student_id").value  = document.getElementById("student_id"+"_r"+inRecNum).value;
    document.getElementById("roll_num").value  = document.getElementById("roll_num"+"_r"+inRecNum).value;
    document.getElementById("ref_name").value  = document.getElementById("ref_name"+"_r"+inRecNum).value;
    document.getElementById("address_1").value  = document.getElementById("address_1"+"_r"+inRecNum).value;
    document.getElementById("address_2").value  = document.getElementById("address_2"+"_r"+inRecNum).value;
    document.getElementById("phone_list").value  = document.getElementById("phone_list"+"_r"+inRecNum).value;
    document.getElementById("email_list").value  = document.getElementById("email_list"+"_r"+inRecNum).value;
    document.getElementById("fax_list").value  = document.getElementById("fax_list"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_req").value  = document.getElementById("adm_req_id_req"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_list").value  = document.getElementById("adm_req_id_list"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("applicant_id").value = '';
    document.getElementById("applicant_id").readOnly = false;
    document.getElementById("seq_num").value = '';
    document.getElementById("seq_num").readOnly = false;
    document.getElementById("application_form_num").value = '';
    document.getElementById("student_id").value = '';
    document.getElementById("roll_num").value = '';
    document.getElementById("ref_name").value = '';
    document.getElementById("address_1").value = '';
    document.getElementById("address_2").value = '';
    document.getElementById("phone_list").value = '';
    document.getElementById("email_list").value = '';
    document.getElementById("fax_list").value = '';
    document.getElementById("adm_req_id_req").value = '';
    document.getElementById("adm_req_id_list").value = '';
  }
}
