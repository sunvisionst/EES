function EesAdrRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("employee_id").value  = document.getElementById("employee_id"+"_r"+inRecNum).value;
    document.getElementById("employee_id").readOnly = true;
    document.getElementById("period_num").value  = document.getElementById("period_num"+"_r"+inRecNum).value;
    document.getElementById("period_num").readOnly = true;
    document.getElementById("adr_date").value  = document.getElementById("adr_date"+"_r"+inRecNum).value;
    document.getElementById("adr_date").readOnly = true;
    document.getElementById("topic_id").value  = document.getElementById("topic_id"+"_r"+inRecNum).value;
    document.getElementById("topic_id").readOnly = true;
    document.getElementById("adr_start_time").value  = document.getElementById("adr_start_time"+"_r"+inRecNum).value;
    document.getElementById("adr_end_time").value  = document.getElementById("adr_end_time"+"_r"+inRecNum).value;
    document.getElementById("lecture_num").value  = document.getElementById("lecture_num"+"_r"+inRecNum).value;
    document.getElementById("subject_code").value  = document.getElementById("subject_code"+"_r"+inRecNum).value;
    document.getElementById("topic_percent_covered").value  = document.getElementById("topic_percent_covered"+"_r"+inRecNum).value;
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value;
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value;
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("employee_id").value = '';
    document.getElementById("employee_id").readOnly = false;
    document.getElementById("period_num").value = '';
    document.getElementById("period_num").readOnly = false;
    document.getElementById("adr_date").value = '';
    document.getElementById("adr_date").readOnly = false;
    document.getElementById("topic_id").value = '';
    document.getElementById("topic_id").readOnly = false;
    document.getElementById("adr_start_time").value = '';
    document.getElementById("adr_end_time").value = '';
    document.getElementById("lecture_num").value = '';
    document.getElementById("subject_code").value = '';
    document.getElementById("topic_percent_covered").value = '';
    document.getElementById("class_id").value = '';
    document.getElementById("class_num").value = '';
    document.getElementById("class_std").value = '';
    document.getElementById("class_section").value = '';
    document.getElementById("course_id").value = '';
    document.getElementById("course_term").value = '';
    document.getElementById("course_stream").value = '';
  }
}
