
var lEesCourseTabObjJSArr = new Array();
<%
{
   if ( lEesCourseTabObjArrCache != null && lEesCourseTabObjArrCache.size() > 0 )
   {
%>
       lEesCourseTabObjJSArr = new Array(<%=lEesCourseTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesCourseTabObjArrCache.size(); lRecNum++ )
       {
          EesCourseTabObj lEesCourseTabObj    =    new EesCourseTabObj();
          lEesCourseTabObj = (EesCourseTabObj)lEesCourseTabObjArrCache.get(lRecNum);
%>
          lEesCourseTabObjJSArr[<%=lRecNum%>] = new constructorEesCourse
          (
          "<%=lEesCourseTabObj.org_id%>",
          "<%=lEesCourseTabObj.course_id%>",
          "<%=lEesCourseTabObj.description%>",
          "<%=lEesCourseTabObj.dept_id%>",
          "<%=lEesCourseTabObj.course_code%>",
          "<%=lEesCourseTabObj.short_code%>",
          "<%=lEesCourseTabObj.sst_course_id%>",
          "<%=lEesCourseTabObj.duration_type%>",
          "<%=lEesCourseTabObj.course_duration%>",
          "<%=lEesCourseTabObj.class_id_pattern%>",
          "<%=lEesCourseTabObj.remark%>",
          "<%=lEesCourseTabObj.board_university%>",
          "<%=lEesCourseTabObj.stream_ind%>",
          "<%=lEesCourseTabObj.course_strength%>",
          "<%=lEesCourseTabObj.quota_qty%>",
          "<%=lEesCourseTabObj.course_coord%>",
          "<%=lEesCourseTabObj.min_fee_amt%>",
          "<%=lEesCourseTabObj.cc_ptl_user_id%>",
          "<%=lEesCourseTabObj.class_std%>"
          );
<%
       }
   }
}
%>


