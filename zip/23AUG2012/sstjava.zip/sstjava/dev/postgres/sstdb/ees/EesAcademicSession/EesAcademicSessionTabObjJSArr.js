
var lEesAcademicSessionTabObjJSArr = new Array();
<%
{
   if ( lEesAcademicSessionTabObjArrCache != null && lEesAcademicSessionTabObjArrCache.size() > 0 )
   {
%>
       lEesAcademicSessionTabObjJSArr = new Array(<%=lEesAcademicSessionTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAcademicSessionTabObjArrCache.size(); lRecNum++ )
       {
          EesAcademicSessionTabObj lEesAcademicSessionTabObj    =    new EesAcademicSessionTabObj();
          lEesAcademicSessionTabObj = (EesAcademicSessionTabObj)lEesAcademicSessionTabObjArrCache.get(lRecNum);
%>
          lEesAcademicSessionTabObjJSArr[<%=lRecNum%>] = new constructorEesAcademicSession
          (
          "<%=lEesAcademicSessionTabObj.org_id%>",
          "<%=lEesAcademicSessionTabObj.academic_session%>",
          "<%=lEesAcademicSessionTabObj.start_date%>",
          "<%=lEesAcademicSessionTabObj.end_date%>",
          "<%=lEesAcademicSessionTabObj.close_date%>",
          "<%=lEesAcademicSessionTabObj.academic_session_sts%>",
          "<%=lEesAcademicSessionTabObj.semester_start_date%>",
          "<%=lEesAcademicSessionTabObj.semester_end_date%>",
          "<%=lEesAcademicSessionTabObj.semester_close_date%>"
          );
<%
       }
   }
}
%>


