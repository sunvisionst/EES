ALTER TABLE           EES_EXAM
  ADD                 CONSTRAINT EES_EXAM_PK
  PRIMARY             KEY
  ( ORG_ID, EXAM_ID )
;
