CREATE TABLE EES_EXAM
(
  ORG_ID                                                                                              VARCHAR(10),
  EXAM_ID                                                                                             VARCHAR(10),
  EXAM_TERM                                                                                           VARCHAR(10),
  EXAM_TYPE                                                                                           VARCHAR(10),
  YEAR                                                                                                NUMERIC(4),
  MONTH                                                                                               NUMERIC(2),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  EXAM_START_DATE                                                                                     VARCHAR(8),
  EXAM_END_DATE                                                                                       VARCHAR(8),
  EXAM_STATUS                                                                                         VARCHAR(1),
  EXAM_STATUS_DATE                                                                                    VARCHAR(8),
  EXAM_SCH_STATUS                                                                                     VARCHAR(1),
  SITTING_PLAN_STATUS                                                                                 VARCHAR(1),
  SEAT_ALLOC_STATUS                                                                                   VARCHAR(1),
  EXAM_ATTN_STATUS                                                                                    VARCHAR(1),
  MARK_ENTRY_STATUS                                                                                   VARCHAR(1)
)
 WITH OIDS;
