
var lEesAlumniTabObjJSArr = new Array();
<%
{
   if ( lEesAlumniTabObjArrCache != null && lEesAlumniTabObjArrCache.size() > 0 )
   {
%>
       lEesAlumniTabObjJSArr = new Array(<%=lEesAlumniTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAlumniTabObjArrCache.size(); lRecNum++ )
       {
          EesAlumniTabObj lEesAlumniTabObj    =    new EesAlumniTabObj();
          lEesAlumniTabObj = (EesAlumniTabObj)lEesAlumniTabObjArrCache.get(lRecNum);
%>
          lEesAlumniTabObjJSArr[<%=lRecNum%>] = new constructorEesAlumni
          (
          "<%=lEesAlumniTabObj.org_id%>",
          "<%=lEesAlumniTabObj.alumni_id%>",
          "<%=lEesAlumniTabObj.alumni_cre_date%>",
          "<%=lEesAlumniTabObj.barcode%>",
          "<%=lEesAlumniTabObj.user_id%>",
          "<%=lEesAlumniTabObj.pswd_0%>",
          "<%=lEesAlumniTabObj.student_name%>",
          "<%=lEesAlumniTabObj.father_name%>",
          "<%=lEesAlumniTabObj.mother_name%>",
          "<%=lEesAlumniTabObj.student_ctg%>",
          "<%=lEesAlumniTabObj.gender_flag%>",
          "<%=lEesAlumniTabObj.dob%>",
          "<%=lEesAlumniTabObj.doj%>",
          "<%=lEesAlumniTabObj.dot%>",
          "<%=lEesAlumniTabObj.address_1%>",
          "<%=lEesAlumniTabObj.address_2%>",
          "<%=lEesAlumniTabObj.class_id%>",
          "<%=lEesAlumniTabObj.class_num%>",
          "<%=lEesAlumniTabObj.class_std%>",
          "<%=lEesAlumniTabObj.class_section%>",
          "<%=lEesAlumniTabObj.course_id%>",
          "<%=lEesAlumniTabObj.course_term%>",
          "<%=lEesAlumniTabObj.course_stream%>",
          "<%=lEesAlumniTabObj.roll_num%>",
          "<%=lEesAlumniTabObj.enrollment_num%>",
          "<%=lEesAlumniTabObj.shift_code%>",
          "<%=lEesAlumniTabObj.prev_org_id%>",
          "<%=lEesAlumniTabObj.prev_class_id%>",
          "<%=lEesAlumniTabObj.prev_class_num%>",
          "<%=lEesAlumniTabObj.prev_class_std%>",
          "<%=lEesAlumniTabObj.prev_class_section%>",
          "<%=lEesAlumniTabObj.prev_course_id%>",
          "<%=lEesAlumniTabObj.prev_course_term%>",
          "<%=lEesAlumniTabObj.prev_course_stream%>",
          "<%=lEesAlumniTabObj.prev_shift_code%>",
          "<%=lEesAlumniTabObj.promotion_sts%>",
          "<%=lEesAlumniTabObj.promotion_date%>",
          "<%=lEesAlumniTabObj.phone%>",
          "<%=lEesAlumniTabObj.email_id%>",
          "<%=lEesAlumniTabObj.student_sts%>",
          "<%=lEesAlumniTabObj.student_sts_date%>",
          "<%=lEesAlumniTabObj.country%>",
          "<%=lEesAlumniTabObj.photo_file_name%>",
          "<%=lEesAlumniTabObj.batch_number%>",
          "<%=lEesAlumniTabObj.num_of_yr_in_class%>",
          "<%=lEesAlumniTabObj.passing_year%>",
          "<%=lEesAlumniTabObj.stud_seq_num%>"
          );
<%
       }
   }
}
%>


