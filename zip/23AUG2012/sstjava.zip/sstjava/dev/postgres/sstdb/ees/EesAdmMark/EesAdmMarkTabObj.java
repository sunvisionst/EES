package sstdb.ees.EesAdmMark;


public class EesAdmMarkTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 adm_req_id;
  public String                                 academic_session;
  public String                                 subject_code;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public int                                  obtained_mark;
  public int                                  max_mark;





  public short                                  org_id_ind;
  public short                                  adm_req_id_ind;
  public short                                  academic_session_ind;
  public short                                  subject_code_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  obtained_mark_ind;
  public short                                  max_mark_ind;


  public EesAdmMarkTabObj(){}


  public EesAdmMarkTabObj
  (
    String org_id,
    String adm_req_id,
    String academic_session,
    String subject_code,
    String class_num,
    String class_std,
    String course_id,
    String course_term,
    String course_stream,
    int obtained_mark,
    int max_mark
  )
  {
     this.org_id = org_id;
     this.adm_req_id = adm_req_id;
     this.academic_session = academic_session;
     this.subject_code = subject_code;
     this.class_num = class_num;
     this.class_std = class_std;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.obtained_mark = obtained_mark;
     this.max_mark = max_mark;
  }

  public String getorg_id()                           { return org_id; }
  public String getadm_req_id()                         { return adm_req_id; }
  public String getacademic_session()                      { return academic_session; }
  public String getsubject_code()                        { return subject_code; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public int getobtained_mark()                         { return obtained_mark; }
  public int getmax_mark()                           { return max_mark; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setadm_req_id(String adm_req_id )                { this.adm_req_id = adm_req_id; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setsubject_code(String subject_code )              { this.subject_code = subject_code; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setobtained_mark(int obtained_mark )               { this.obtained_mark = obtained_mark; }
  public void  setmax_mark(int max_mark )                    { this.max_mark = max_mark; }
}