CREATE TABLE EES_EVENT_REG_STUD
(
  ORG_ID                                                                                              VARCHAR(10),
  ACTIVITY_ID                                                                                         VARCHAR(10),
  STUDENT_ID                                                                                          VARCHAR(25),
  EVENT_ID                                                                                            VARCHAR(10),
  STATUS                                                                                              VARCHAR(1),
  STATUS_DATE                                                                                         VARCHAR(8)
)
 WITH OIDS;
