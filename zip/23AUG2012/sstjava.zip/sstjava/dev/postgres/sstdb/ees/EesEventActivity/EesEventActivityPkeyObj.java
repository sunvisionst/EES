package sstdb.ees.EesEventActivity;


public class EesEventActivityPkeyObj
{
  public String                                 org_id;
  public String                                 activity_id;
}