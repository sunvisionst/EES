package sstdb.ees.EesEventContact;


public class EesEventContactPkeyObj
{
  public String                                 org_id;
  public String                                 activity_id;
  public int                                  seq_num;
}