package sstdb.ees.EesAward;


public class EesAwardTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 award_id;
  public String                                 award_name;
  public String                                 award_type;
  public String                                 award_desc;
  public String                                 award_start_date;
  public String                                 award_started_by;





  public short                                  org_id_ind;
  public short                                  award_id_ind;
  public short                                  award_name_ind;
  public short                                  award_type_ind;
  public short                                  award_desc_ind;
  public short                                  award_start_date_ind;
  public short                                  award_started_by_ind;


  public EesAwardTabObj(){}


  public EesAwardTabObj
  (
    String org_id,
    String award_id,
    String award_name,
    String award_type,
    String award_desc,
    String award_start_date,
    String award_started_by
  )
  {
     this.org_id = org_id;
     this.award_id = award_id;
     this.award_name = award_name;
     this.award_type = award_type;
     this.award_desc = award_desc;
     this.award_start_date = award_start_date;
     this.award_started_by = award_started_by;
  }

  public String getorg_id()                           { return org_id; }
  public String getaward_id()                          { return award_id; }
  public String getaward_name()                         { return award_name; }
  public String getaward_type()                         { return award_type; }
  public String getaward_desc()                         { return award_desc; }
  public String getaward_start_date()                      { return award_start_date; }
  public String getaward_started_by()                      { return award_started_by; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setaward_id(String award_id )                  { this.award_id = award_id; }
  public void  setaward_name(String award_name )                { this.award_name = award_name; }
  public void  setaward_type(String award_type )                { this.award_type = award_type; }
  public void  setaward_desc(String award_desc )                { this.award_desc = award_desc; }
  public void  setaward_start_date(String award_start_date )          { this.award_start_date = award_start_date; }
  public void  setaward_started_by(String award_started_by )          { this.award_started_by = award_started_by; }
}