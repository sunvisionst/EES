package sstdb.ees.EesAdr;


public class EesAdrPkeyObj
{
  public String                                 org_id;
  public String                                 employee_id;
  public byte                                  period_num;
  public String                                 adr_date;
  public String                                 topic_id;
}