ALTER TABLE           EES_ADM_LIST
  ADD                 CONSTRAINT EES_ADM_LIST_PK
  PRIMARY             KEY
  ( ORG_ID, ADM_REQ_ID )
;
