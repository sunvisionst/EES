CREATE TABLE EES_EVENT_REG_GUEST_EXT
(
  org_id                                                                                              VARCHAR(10),
  activity_id                                                                                         VARCHAR(10),
  event_id                                                                                            VARCHAR(10),
  speaker_ind                                                                                         VARCHAR(1),
  attendee_name                                                                                       VARCHAR(100),
  attendee_email                                                                                      VARCHAR(50),
  attendee_phone                                                                                      VARCHAR(30),
  attendee_fax                                                                                        VARCHAR(30),
  status                                                                                              VARCHAR(1),
  status_date                                                                                         VARCHAR(8)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACTIVITY_ID                                                                                         CHAR(10),
       EVENT_ID                                                                                            CHAR(10),
       SPEAKER_IND                                                                                         CHAR(1),
       ATTENDEE_NAME                                                                                       CHAR(100),
       ATTENDEE_EMAIL                                                                                      CHAR(50),
       ATTENDEE_PHONE                                                                                      CHAR(30),
       ATTENDEE_FAX                                                                                        CHAR(30),
       STATUS                                                                                              CHAR(1),
       STATUS_DATE                                                                                         CHAR(8)
    )
  )
  LOCATION ('ees_event_reg_guest_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
