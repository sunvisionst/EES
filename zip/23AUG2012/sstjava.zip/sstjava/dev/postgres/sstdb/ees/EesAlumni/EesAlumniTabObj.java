package sstdb.ees.EesAlumni;


public class EesAlumniTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 alumni_id;
  public String                                 alumni_cre_date;
  public String                                 barcode;
  public String                                 user_id;
  public String                                 pswd_0;
  public String                                 student_name;
  public String                                 father_name;
  public String                                 mother_name;
  public String                                 student_ctg;
  public String                                 gender_flag;
  public String                                 dob;
  public String                                 doj;
  public String                                 dot;
  public String                                 address_1;
  public String                                 address_2;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 roll_num;
  public String                                 enrollment_num;
  public String                                 shift_code;
  public String                                 prev_org_id;
  public String                                 prev_class_id;
  public String                                 prev_class_num;
  public String                                 prev_class_std;
  public String                                 prev_class_section;
  public String                                 prev_course_id;
  public String                                 prev_course_term;
  public String                                 prev_course_stream;
  public String                                 prev_shift_code;
  public String                                 promotion_sts;
  public String                                 promotion_date;
  public String                                 phone;
  public String                                 email_id;
  public String                                 student_sts;
  public String                                 student_sts_date;
  public String                                 country;
  public String                                 photo_file_name;
  public String                                 batch_number;
  public byte                                  num_of_yr_in_class;
  public byte                                  passing_year;
  public int                                  stud_seq_num;





  public short                                  org_id_ind;
  public short                                  alumni_id_ind;
  public short                                  alumni_cre_date_ind;
  public short                                  barcode_ind;
  public short                                  user_id_ind;
  public short                                  pswd_0_ind;
  public short                                  student_name_ind;
  public short                                  father_name_ind;
  public short                                  mother_name_ind;
  public short                                  student_ctg_ind;
  public short                                  gender_flag_ind;
  public short                                  dob_ind;
  public short                                  doj_ind;
  public short                                  dot_ind;
  public short                                  address_1_ind;
  public short                                  address_2_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  roll_num_ind;
  public short                                  enrollment_num_ind;
  public short                                  shift_code_ind;
  public short                                  prev_org_id_ind;
  public short                                  prev_class_id_ind;
  public short                                  prev_class_num_ind;
  public short                                  prev_class_std_ind;
  public short                                  prev_class_section_ind;
  public short                                  prev_course_id_ind;
  public short                                  prev_course_term_ind;
  public short                                  prev_course_stream_ind;
  public short                                  prev_shift_code_ind;
  public short                                  promotion_sts_ind;
  public short                                  promotion_date_ind;
  public short                                  phone_ind;
  public short                                  email_id_ind;
  public short                                  student_sts_ind;
  public short                                  student_sts_date_ind;
  public short                                  country_ind;
  public short                                  photo_file_name_ind;
  public short                                  batch_number_ind;
  public short                                  num_of_yr_in_class_ind;
  public short                                  passing_year_ind;
  public short                                  stud_seq_num_ind;


  public EesAlumniTabObj(){}


  public EesAlumniTabObj
  (
    String org_id,
    String alumni_id,
    String alumni_cre_date,
    String barcode,
    String user_id,
    String pswd_0,
    String student_name,
    String father_name,
    String mother_name,
    String student_ctg,
    String gender_flag,
    String dob,
    String doj,
    String dot,
    String address_1,
    String address_2,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream,
    String roll_num,
    String enrollment_num,
    String shift_code,
    String prev_org_id,
    String prev_class_id,
    String prev_class_num,
    String prev_class_std,
    String prev_class_section,
    String prev_course_id,
    String prev_course_term,
    String prev_course_stream,
    String prev_shift_code,
    String promotion_sts,
    String promotion_date,
    String phone,
    String email_id,
    String student_sts,
    String student_sts_date,
    String country,
    String photo_file_name,
    String batch_number,
    byte num_of_yr_in_class,
    byte passing_year,
    int stud_seq_num
  )
  {
     this.org_id = org_id;
     this.alumni_id = alumni_id;
     this.alumni_cre_date = alumni_cre_date;
     this.barcode = barcode;
     this.user_id = user_id;
     this.pswd_0 = pswd_0;
     this.student_name = student_name;
     this.father_name = father_name;
     this.mother_name = mother_name;
     this.student_ctg = student_ctg;
     this.gender_flag = gender_flag;
     this.dob = dob;
     this.doj = doj;
     this.dot = dot;
     this.address_1 = address_1;
     this.address_2 = address_2;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.roll_num = roll_num;
     this.enrollment_num = enrollment_num;
     this.shift_code = shift_code;
     this.prev_org_id = prev_org_id;
     this.prev_class_id = prev_class_id;
     this.prev_class_num = prev_class_num;
     this.prev_class_std = prev_class_std;
     this.prev_class_section = prev_class_section;
     this.prev_course_id = prev_course_id;
     this.prev_course_term = prev_course_term;
     this.prev_course_stream = prev_course_stream;
     this.prev_shift_code = prev_shift_code;
     this.promotion_sts = promotion_sts;
     this.promotion_date = promotion_date;
     this.phone = phone;
     this.email_id = email_id;
     this.student_sts = student_sts;
     this.student_sts_date = student_sts_date;
     this.country = country;
     this.photo_file_name = photo_file_name;
     this.batch_number = batch_number;
     this.num_of_yr_in_class = num_of_yr_in_class;
     this.passing_year = passing_year;
     this.stud_seq_num = stud_seq_num;
  }

  public String getorg_id()                           { return org_id; }
  public String getalumni_id()                         { return alumni_id; }
  public String getalumni_cre_date()                      { return alumni_cre_date; }
  public String getbarcode()                          { return barcode; }
  public String getuser_id()                          { return user_id; }
  public String getpswd_0()                           { return pswd_0; }
  public String getstudent_name()                        { return student_name; }
  public String getfather_name()                        { return father_name; }
  public String getmother_name()                        { return mother_name; }
  public String getstudent_ctg()                        { return student_ctg; }
  public String getgender_flag()                        { return gender_flag; }
  public String getdob()                            { return dob; }
  public String getdoj()                            { return doj; }
  public String getdot()                            { return dot; }
  public String getaddress_1()                         { return address_1; }
  public String getaddress_2()                         { return address_2; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getroll_num()                          { return roll_num; }
  public String getenrollment_num()                       { return enrollment_num; }
  public String getshift_code()                         { return shift_code; }
  public String getprev_org_id()                        { return prev_org_id; }
  public String getprev_class_id()                       { return prev_class_id; }
  public String getprev_class_num()                       { return prev_class_num; }
  public String getprev_class_std()                       { return prev_class_std; }
  public String getprev_class_section()                     { return prev_class_section; }
  public String getprev_course_id()                       { return prev_course_id; }
  public String getprev_course_term()                      { return prev_course_term; }
  public String getprev_course_stream()                     { return prev_course_stream; }
  public String getprev_shift_code()                      { return prev_shift_code; }
  public String getpromotion_sts()                       { return promotion_sts; }
  public String getpromotion_date()                       { return promotion_date; }
  public String getphone()                           { return phone; }
  public String getemail_id()                          { return email_id; }
  public String getstudent_sts()                        { return student_sts; }
  public String getstudent_sts_date()                      { return student_sts_date; }
  public String getcountry()                          { return country; }
  public String getphoto_file_name()                      { return photo_file_name; }
  public String getbatch_number()                        { return batch_number; }
  public byte getnum_of_yr_in_class()                      { return num_of_yr_in_class; }
  public byte getpassing_year()                         { return passing_year; }
  public int getstud_seq_num()                         { return stud_seq_num; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setalumni_id(String alumni_id )                 { this.alumni_id = alumni_id; }
  public void  setalumni_cre_date(String alumni_cre_date )           { this.alumni_cre_date = alumni_cre_date; }
  public void  setbarcode(String barcode )                   { this.barcode = barcode; }
  public void  setuser_id(String user_id )                   { this.user_id = user_id; }
  public void  setpswd_0(String pswd_0 )                    { this.pswd_0 = pswd_0; }
  public void  setstudent_name(String student_name )              { this.student_name = student_name; }
  public void  setfather_name(String father_name )               { this.father_name = father_name; }
  public void  setmother_name(String mother_name )               { this.mother_name = mother_name; }
  public void  setstudent_ctg(String student_ctg )               { this.student_ctg = student_ctg; }
  public void  setgender_flag(String gender_flag )               { this.gender_flag = gender_flag; }
  public void  setdob(String dob )                       { this.dob = dob; }
  public void  setdoj(String doj )                       { this.doj = doj; }
  public void  setdot(String dot )                       { this.dot = dot; }
  public void  setaddress_1(String address_1 )                 { this.address_1 = address_1; }
  public void  setaddress_2(String address_2 )                 { this.address_2 = address_2; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setroll_num(String roll_num )                  { this.roll_num = roll_num; }
  public void  setenrollment_num(String enrollment_num )            { this.enrollment_num = enrollment_num; }
  public void  setshift_code(String shift_code )                { this.shift_code = shift_code; }
  public void  setprev_org_id(String prev_org_id )               { this.prev_org_id = prev_org_id; }
  public void  setprev_class_id(String prev_class_id )             { this.prev_class_id = prev_class_id; }
  public void  setprev_class_num(String prev_class_num )            { this.prev_class_num = prev_class_num; }
  public void  setprev_class_std(String prev_class_std )            { this.prev_class_std = prev_class_std; }
  public void  setprev_class_section(String prev_class_section )        { this.prev_class_section = prev_class_section; }
  public void  setprev_course_id(String prev_course_id )            { this.prev_course_id = prev_course_id; }
  public void  setprev_course_term(String prev_course_term )          { this.prev_course_term = prev_course_term; }
  public void  setprev_course_stream(String prev_course_stream )        { this.prev_course_stream = prev_course_stream; }
  public void  setprev_shift_code(String prev_shift_code )           { this.prev_shift_code = prev_shift_code; }
  public void  setpromotion_sts(String promotion_sts )             { this.promotion_sts = promotion_sts; }
  public void  setpromotion_date(String promotion_date )            { this.promotion_date = promotion_date; }
  public void  setphone(String phone )                     { this.phone = phone; }
  public void  setemail_id(String email_id )                  { this.email_id = email_id; }
  public void  setstudent_sts(String student_sts )               { this.student_sts = student_sts; }
  public void  setstudent_sts_date(String student_sts_date )          { this.student_sts_date = student_sts_date; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setphoto_file_name(String photo_file_name )           { this.photo_file_name = photo_file_name; }
  public void  setbatch_number(String batch_number )              { this.batch_number = batch_number; }
  public void  setnum_of_yr_in_class(byte num_of_yr_in_class )         { this.num_of_yr_in_class = num_of_yr_in_class; }
  public void  setpassing_year(byte passing_year )               { this.passing_year = passing_year; }
  public void  setstud_seq_num(int stud_seq_num )                { this.stud_seq_num = stud_seq_num; }
}