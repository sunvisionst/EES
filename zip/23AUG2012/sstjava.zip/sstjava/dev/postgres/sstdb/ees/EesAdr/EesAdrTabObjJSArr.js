
var lEesAdrTabObjJSArr = new Array();
<%
{
   if ( lEesAdrTabObjArrCache != null && lEesAdrTabObjArrCache.size() > 0 )
   {
%>
       lEesAdrTabObjJSArr = new Array(<%=lEesAdrTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAdrTabObjArrCache.size(); lRecNum++ )
       {
          EesAdrTabObj lEesAdrTabObj    =    new EesAdrTabObj();
          lEesAdrTabObj = (EesAdrTabObj)lEesAdrTabObjArrCache.get(lRecNum);
%>
          lEesAdrTabObjJSArr[<%=lRecNum%>] = new constructorEesAdr
          (
          "<%=lEesAdrTabObj.org_id%>",
          "<%=lEesAdrTabObj.employee_id%>",
          "<%=lEesAdrTabObj.period_num%>",
          "<%=lEesAdrTabObj.adr_date%>",
          "<%=lEesAdrTabObj.topic_id%>",
          "<%=lEesAdrTabObj.adr_start_time%>",
          "<%=lEesAdrTabObj.adr_end_time%>",
          "<%=lEesAdrTabObj.lecture_num%>",
          "<%=lEesAdrTabObj.subject_code%>",
          "<%=lEesAdrTabObj.topic_percent_covered%>",
          "<%=lEesAdrTabObj.class_id%>",
          "<%=lEesAdrTabObj.class_num%>",
          "<%=lEesAdrTabObj.class_std%>",
          "<%=lEesAdrTabObj.class_section%>",
          "<%=lEesAdrTabObj.course_id%>",
          "<%=lEesAdrTabObj.course_term%>",
          "<%=lEesAdrTabObj.course_stream%>"
          );
<%
       }
   }
}
%>


