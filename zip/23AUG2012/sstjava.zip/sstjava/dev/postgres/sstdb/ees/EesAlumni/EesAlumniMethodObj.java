package sstdb.ees.EesAlumni;

import sstdb.ees.EesAlumni.EesAlumniTabObj;
import sstdb.ees.EesAlumni.EesAlumniPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesAlumniMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesAlumniMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesAlumniMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesAlumniTabObj
               ( 
                 EesAlumniTabObj  outEesAlumniTabObj
               )
  {
  
     outEesAlumniTabObj.org_id = ""; 
     outEesAlumniTabObj.alumni_id = ""; 
     outEesAlumniTabObj.alumni_cre_date = ""; 
     outEesAlumniTabObj.barcode = ""; 
     outEesAlumniTabObj.user_id = ""; 
     outEesAlumniTabObj.pswd_0 = ""; 
     outEesAlumniTabObj.student_name = ""; 
     outEesAlumniTabObj.father_name = ""; 
     outEesAlumniTabObj.mother_name = ""; 
     outEesAlumniTabObj.student_ctg = ""; 
     outEesAlumniTabObj.gender_flag = ""; 
     outEesAlumniTabObj.dob = ""; 
     outEesAlumniTabObj.doj = ""; 
     outEesAlumniTabObj.dot = ""; 
     outEesAlumniTabObj.address_1 = ""; 
     outEesAlumniTabObj.address_2 = ""; 
     outEesAlumniTabObj.class_id = ""; 
     outEesAlumniTabObj.class_num = ""; 
     outEesAlumniTabObj.class_std = ""; 
     outEesAlumniTabObj.class_section = ""; 
     outEesAlumniTabObj.course_id = ""; 
     outEesAlumniTabObj.course_term = ""; 
     outEesAlumniTabObj.course_stream = ""; 
     outEesAlumniTabObj.roll_num = ""; 
     outEesAlumniTabObj.enrollment_num = ""; 
     outEesAlumniTabObj.shift_code = ""; 
     outEesAlumniTabObj.prev_org_id = ""; 
     outEesAlumniTabObj.prev_class_id = ""; 
     outEesAlumniTabObj.prev_class_num = ""; 
     outEesAlumniTabObj.prev_class_std = ""; 
     outEesAlumniTabObj.prev_class_section = ""; 
     outEesAlumniTabObj.prev_course_id = ""; 
     outEesAlumniTabObj.prev_course_term = ""; 
     outEesAlumniTabObj.prev_course_stream = ""; 
     outEesAlumniTabObj.prev_shift_code = ""; 
     outEesAlumniTabObj.promotion_sts = ""; 
     outEesAlumniTabObj.promotion_date = ""; 
     outEesAlumniTabObj.phone = ""; 
     outEesAlumniTabObj.email_id = ""; 
     outEesAlumniTabObj.student_sts = ""; 
     outEesAlumniTabObj.student_sts_date = ""; 
     outEesAlumniTabObj.country = ""; 
     outEesAlumniTabObj.photo_file_name = ""; 
     outEesAlumniTabObj.batch_number = ""; 
     outEesAlumniTabObj.num_of_yr_in_class = (int)0; 
     outEesAlumniTabObj.passing_year = (int)0; 
     outEesAlumniTabObj.stud_seq_num = (int)0; 
  }





  public void guiDateConvEesAlumniTabObj
               ( 
                 EesAlumniTabObj  inEesAlumniTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesAlumniTabObj.alumni_cre_date != null && inEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            inEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);

          if ( inEesAlumniTabObj.dob != null && inEesAlumniTabObj.dob.length() > 0 ) 
            inEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.dob, lDateTimeTrgFmt);

          if ( inEesAlumniTabObj.doj != null && inEesAlumniTabObj.doj.length() > 0 ) 
            inEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.doj, lDateTimeTrgFmt);

          if ( inEesAlumniTabObj.dot != null && inEesAlumniTabObj.dot.length() > 0 ) 
            inEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.dot, lDateTimeTrgFmt);

          if ( inEesAlumniTabObj.promotion_date != null && inEesAlumniTabObj.promotion_date.length() > 0 ) 
            inEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);

          if ( inEesAlumniTabObj.student_sts_date != null && inEesAlumniTabObj.student_sts_date.length() > 0 ) 
            inEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesAlumniByTabObj
               ( 
                 EesAlumniTabObj  inEesAlumniTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesAlumniTabObjArrCtx  = new ArrayList(); 
    lEesAlumniTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesAlumniTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesAlumniTabObjArrCtx.add(inEesAlumniTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesAlumniTabObjArrCtx.size();  lRecNum++ )
      {
        EesAlumniTabObj lEesAlumniTabObj = new EesAlumniTabObj();
        lEesAlumniTabObj = (EesAlumniTabObj)lEesAlumniTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesAlumniTabObj.org_id.equals(lEesAlumniTabObj.org_id) &&
              lEesAlumniTabObj.alumni_id.equals(lEesAlumniTabObj.alumni_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesAlumniTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesAlumniTabObjArrCtx.set(lRecNum, inEesAlumniTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesAlumniTabObjArrCtx",lEesAlumniTabObjArrCtx);
  }





  public void sortEesAlumniTabObjArr
               ( 
                 ArrayList  inEesAlumniTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesAlumniTabObjArr  = new ArrayList(); 
     lEesAlumniTabObjArr = inEesAlumniTabObjArr; 
     List lEesAlumniTabObjList  = new ArrayList(lEesAlumniTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesAlumniTabObjArr.size();  lRecNum++ )
     {
       EesAlumniTabObj  lEesAlumniTabObj = new EesAlumniTabObj(); 
       lEesAlumniTabObj = (EesAlumniTabObj)lEesAlumniTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("alumni_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.alumni_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.alumni_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("alumni_cre_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.alumni_cre_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.alumni_cre_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("barcode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.barcode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.barcode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("user_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.user_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.user_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("pswd_0") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (12 - lEesAlumniTabObj.pswd_0.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.pswd_0+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniTabObj.student_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.student_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniTabObj.father_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.father_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniTabObj.mother_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.mother_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAlumniTabObj.student_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.student_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gender_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAlumniTabObj.gender_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.gender_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dob") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.dob.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.dob+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("doj") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.doj.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.doj+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dot") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.dot.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.dot+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniTabObj.address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAlumniTabObj.address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("roll_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.roll_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.roll_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enrollment_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.enrollment_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.enrollment_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("shift_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.shift_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.shift_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAlumniTabObj.prev_class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_shift_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.prev_shift_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.prev_shift_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("promotion_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.promotion_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.promotion_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("promotion_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.promotion_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.promotion_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAlumniTabObj.phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAlumniTabObj.email_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.email_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.student_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.student_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAlumniTabObj.student_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.student_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAlumniTabObj.country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("photo_file_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAlumniTabObj.photo_file_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.photo_file_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("batch_number") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAlumniTabObj.batch_number.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.batch_number+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("num_of_yr_in_class") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAlumniTabObj.num_of_yr_in_class).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.num_of_yr_in_class+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("passing_year") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAlumniTabObj.passing_year).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.passing_year+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stud_seq_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (9 - Integer.toString(lEesAlumniTabObj.stud_seq_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAlumniTabObj.stud_seq_num+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesAlumniTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesAlumniTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesAlumniTabObjList ); 
     ArrayList lEesAlumniTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesAlumniTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesAlumniTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesAlumniTabObjArrSorted.add( (EesAlumniTabObj)lEesAlumniTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesAlumniTabObjArr.size();  lRecNum++ )
     {
       inEesAlumniTabObjArr.set( lRecNum, (EesAlumniTabObj)lEesAlumniTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesAlumniTabObj
               ( 
                 EesAlumniTabObj  inEesAlumniTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesAlumniTabObj.alumni_cre_date != null && inEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            inEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.alumni_cre_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dob != null && inEesAlumniTabObj.dob.length() > 0 ) 
            inEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.doj != null && inEesAlumniTabObj.doj.length() > 0 ) 
            inEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.doj, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dot != null && inEesAlumniTabObj.dot.length() > 0 ) 
            inEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dot, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.promotion_date != null && inEesAlumniTabObj.promotion_date.length() > 0 ) 
            inEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.promotion_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.student_sts_date != null && inEesAlumniTabObj.student_sts_date.length() > 0 ) 
            inEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.student_sts_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAlumniId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALUMNI_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAlumniCreDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALUMNI_CRE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBarcode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BARCODE";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUserId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "USER_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePswd0
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 12 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PSWD_0";
      String lErrorReason = "Size Greater Than 12";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_CTG";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenderFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GENDER_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDob
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOB";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDoj
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOJ";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDot
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOT";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAddress2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRollNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROLL_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnrollmentNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENROLLMENT_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeShiftCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SHIFT_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevShiftCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_SHIFT_CODE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePromotionSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROMOTION_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePromotionDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROMOTION_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCountry
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhotoFileName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHOTO_FILE_NAME";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBatchNumber
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BATCH_NUMBER";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNumOfYrInClass
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NUM_OF_YR_IN_CLASS";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePassingYear
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PASSING_YEAR";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudSeqNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 9 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUD_SEQ_NUM";
      String lErrorReason = "Size Greater Than 9";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesAlumniCount
               ( String inEesAlumniWhereText
               )
  {
    sop("gtEesAlumniCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniCount
               ( String inEesAlumniWhereText
               , String inEesAlumniSelectFieldList
               )
  {
    sop("gtEesAlumniCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesAlumniSelectFieldList+" AS count "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniRecByPkey
               ( EesAlumniPkeyObj inEesAlumniPkeyObj
               , EesAlumniTabObj  outEesAlumniTabObj
               )
  {
    sop("gtEesAlumniRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "alumni_id, "+
                                 "alumni_cre_date, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "student_name, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "dob, "+
                                 "doj, "+
                                 "dot, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "roll_num, "+
                                 "enrollment_num, "+
                                 "shift_code, "+
                                 "prev_org_id, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "prev_shift_code, "+
                                 "promotion_sts, "+
                                 "promotion_date, "+
                                 "phone, "+
                                 "email_id, "+
                                 "student_sts, "+
                                 "student_sts_date, "+
                                 "country, "+
                                 "photo_file_name, "+
                                 "batch_number, "+
                                 "num_of_yr_in_class, "+
                                 "passing_year, "+
                                 "stud_seq_num "+
                         "FROM   EES_ALUMNI " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAlumniPkeyObj.org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniPkeyObj.alumni_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesAlumniTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAlumniTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAlumniTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          outEesAlumniTabObj.alumni_cre_date  =  lResultSet.getString("ALUMNI_CRE_DATE");

          if ( outEesAlumniTabObj.alumni_cre_date != null && outEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            outEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.barcode  =  lResultSet.getString("BARCODE");
          outEesAlumniTabObj.user_id  =  lResultSet.getString("USER_ID");
          outEesAlumniTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outEesAlumniTabObj.student_name  =  lResultSet.getString("STUDENT_NAME");
          outEesAlumniTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAlumniTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAlumniTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAlumniTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAlumniTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAlumniTabObj.dob != null && outEesAlumniTabObj.dob.length() > 0 ) 
            outEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.dob, lDateTimeTrgFmt);
          outEesAlumniTabObj.doj  =  lResultSet.getString("DOJ");

          if ( outEesAlumniTabObj.doj != null && outEesAlumniTabObj.doj.length() > 0 ) 
            outEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.doj, lDateTimeTrgFmt);
          outEesAlumniTabObj.dot  =  lResultSet.getString("DOT");

          if ( outEesAlumniTabObj.dot != null && outEesAlumniTabObj.dot.length() > 0 ) 
            outEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.dot, lDateTimeTrgFmt);
          outEesAlumniTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outEesAlumniTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outEesAlumniTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAlumniTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAlumniTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAlumniTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAlumniTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAlumniTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAlumniTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAlumniTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAlumniTabObj.enrollment_num  =  lResultSet.getString("ENROLLMENT_NUM");
          outEesAlumniTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          outEesAlumniTabObj.prev_org_id  =  lResultSet.getString("PREV_ORG_ID");
          outEesAlumniTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAlumniTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAlumniTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAlumniTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAlumniTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAlumniTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAlumniTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAlumniTabObj.prev_shift_code  =  lResultSet.getString("PREV_SHIFT_CODE");
          outEesAlumniTabObj.promotion_sts  =  lResultSet.getString("PROMOTION_STS");
          outEesAlumniTabObj.promotion_date  =  lResultSet.getString("PROMOTION_DATE");

          if ( outEesAlumniTabObj.promotion_date != null && outEesAlumniTabObj.promotion_date.length() > 0 ) 
            outEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.phone  =  lResultSet.getString("PHONE");
          outEesAlumniTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outEesAlumniTabObj.student_sts  =  lResultSet.getString("STUDENT_STS");
          outEesAlumniTabObj.student_sts_date  =  lResultSet.getString("STUDENT_STS_DATE");

          if ( outEesAlumniTabObj.student_sts_date != null && outEesAlumniTabObj.student_sts_date.length() > 0 ) 
            outEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.country  =  lResultSet.getString("COUNTRY");
          outEesAlumniTabObj.photo_file_name  =  lResultSet.getString("PHOTO_FILE_NAME");
          outEesAlumniTabObj.batch_number  =  lResultSet.getString("BATCH_NUMBER");
          outEesAlumniTabObj.num_of_yr_in_class  =  lResultSet.getByte("NUM_OF_YR_IN_CLASS");
          outEesAlumniTabObj.passing_year  =  lResultSet.getByte("PASSING_YEAR");
          outEesAlumniTabObj.stud_seq_num  =  lResultSet.getInt("STUD_SEQ_NUM");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAlumniTabObj( outEesAlumniTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniArr
               ( EesAlumniPkeyObj inEesAlumniPkeyObj
               , ArrayList  outEesAlumniTabObjArr
               )
  {
    sop("gtEesAlumniArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "alumni_id, "+
                                 "alumni_cre_date, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "student_name, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "dob, "+
                                 "doj, "+
                                 "dot, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "roll_num, "+
                                 "enrollment_num, "+
                                 "shift_code, "+
                                 "prev_org_id, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "prev_shift_code, "+
                                 "promotion_sts, "+
                                 "promotion_date, "+
                                 "phone, "+
                                 "email_id, "+
                                 "student_sts, "+
                                 "student_sts_date, "+
                                 "country, "+
                                 "photo_file_name, "+
                                 "batch_number, "+
                                 "num_of_yr_in_class, "+
                                 "passing_year, "+
                                 "stud_seq_num "+
                         "FROM   EES_ALUMNI";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAlumniTabObj  lEesAlumniTabObj = new EesAlumniTabObj();
          lEesAlumniTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesAlumniTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAlumniTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          lEesAlumniTabObj.alumni_cre_date  =  lResultSet.getString("ALUMNI_CRE_DATE");

          if ( lEesAlumniTabObj.alumni_cre_date != null && lEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            lEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.barcode  =  lResultSet.getString("BARCODE");
          lEesAlumniTabObj.user_id  =  lResultSet.getString("USER_ID");
          lEesAlumniTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lEesAlumniTabObj.student_name  =  lResultSet.getString("STUDENT_NAME");
          lEesAlumniTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAlumniTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAlumniTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAlumniTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAlumniTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAlumniTabObj.dob != null && lEesAlumniTabObj.dob.length() > 0 ) 
            lEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dob, lDateTimeTrgFmt);
          lEesAlumniTabObj.doj  =  lResultSet.getString("DOJ");

          if ( lEesAlumniTabObj.doj != null && lEesAlumniTabObj.doj.length() > 0 ) 
            lEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.doj, lDateTimeTrgFmt);
          lEesAlumniTabObj.dot  =  lResultSet.getString("DOT");

          if ( lEesAlumniTabObj.dot != null && lEesAlumniTabObj.dot.length() > 0 ) 
            lEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dot, lDateTimeTrgFmt);
          lEesAlumniTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lEesAlumniTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lEesAlumniTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAlumniTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAlumniTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAlumniTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAlumniTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAlumniTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAlumniTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAlumniTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAlumniTabObj.enrollment_num  =  lResultSet.getString("ENROLLMENT_NUM");
          lEesAlumniTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          lEesAlumniTabObj.prev_org_id  =  lResultSet.getString("PREV_ORG_ID");
          lEesAlumniTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAlumniTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAlumniTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAlumniTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAlumniTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAlumniTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAlumniTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAlumniTabObj.prev_shift_code  =  lResultSet.getString("PREV_SHIFT_CODE");
          lEesAlumniTabObj.promotion_sts  =  lResultSet.getString("PROMOTION_STS");
          lEesAlumniTabObj.promotion_date  =  lResultSet.getString("PROMOTION_DATE");

          if ( lEesAlumniTabObj.promotion_date != null && lEesAlumniTabObj.promotion_date.length() > 0 ) 
            lEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.phone  =  lResultSet.getString("PHONE");
          lEesAlumniTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lEesAlumniTabObj.student_sts  =  lResultSet.getString("STUDENT_STS");
          lEesAlumniTabObj.student_sts_date  =  lResultSet.getString("STUDENT_STS_DATE");

          if ( lEesAlumniTabObj.student_sts_date != null && lEesAlumniTabObj.student_sts_date.length() > 0 ) 
            lEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.country  =  lResultSet.getString("COUNTRY");
          lEesAlumniTabObj.photo_file_name  =  lResultSet.getString("PHOTO_FILE_NAME");
          lEesAlumniTabObj.batch_number  =  lResultSet.getString("BATCH_NUMBER");
          lEesAlumniTabObj.num_of_yr_in_class  =  lResultSet.getByte("NUM_OF_YR_IN_CLASS");
          lEesAlumniTabObj.passing_year  =  lResultSet.getByte("PASSING_YEAR");
          lEesAlumniTabObj.stud_seq_num  =  lResultSet.getInt("STUD_SEQ_NUM");

          removeNullEesAlumniTabObj( lEesAlumniTabObj );

          outEesAlumniTabObjArr.add(  lEesAlumniTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniTabObjArr != null && outEesAlumniTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesAlumniArr2XML
               ( String inEesAlumniWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesAlumniArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesAlumni>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("alumni_id") )
              lXmlBuffer = lXmlBuffer +   "<ALUMNI_ID>" +  lResultSet.getString("ALUMNI_ID") +   "</ALUMNI_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("alumni_cre_date") )
              lXmlBuffer = lXmlBuffer +   "<ALUMNI_CRE_DATE>" +  lResultSet.getString("ALUMNI_CRE_DATE") +   "</ALUMNI_CRE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("barcode") )
              lXmlBuffer = lXmlBuffer +   "<BARCODE>" +  lResultSet.getString("BARCODE") +   "</BARCODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("user_id") )
              lXmlBuffer = lXmlBuffer +   "<USER_ID>" +  lResultSet.getString("USER_ID") +   "</USER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("pswd_0") )
              lXmlBuffer = lXmlBuffer +   "<PSWD_0>" +  lResultSet.getString("PSWD_0") +   "</PSWD_0>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_NAME>" +  lResultSet.getString("STUDENT_NAME") +   "</STUDENT_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_name") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_NAME>" +  lResultSet.getString("FATHER_NAME") +   "</FATHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_name") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_NAME>" +  lResultSet.getString("MOTHER_NAME") +   "</MOTHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_ctg") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_CTG>" +  lResultSet.getString("STUDENT_CTG") +   "</STUDENT_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gender_flag") )
              lXmlBuffer = lXmlBuffer +   "<GENDER_FLAG>" +  lResultSet.getString("GENDER_FLAG") +   "</GENDER_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dob") )
              lXmlBuffer = lXmlBuffer +   "<DOB>" +  lResultSet.getString("DOB") +   "</DOB>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("doj") )
              lXmlBuffer = lXmlBuffer +   "<DOJ>" +  lResultSet.getString("DOJ") +   "</DOJ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dot") )
              lXmlBuffer = lXmlBuffer +   "<DOT>" +  lResultSet.getString("DOT") +   "</DOT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_1") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_1>" +  lResultSet.getString("ADDRESS_1") +   "</ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("address_2") )
              lXmlBuffer = lXmlBuffer +   "<ADDRESS_2>" +  lResultSet.getString("ADDRESS_2") +   "</ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_id") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_ID>" +  lResultSet.getString("CLASS_ID") +   "</CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_num") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_NUM>" +  lResultSet.getString("CLASS_NUM") +   "</CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_std") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_STD>" +  lResultSet.getString("CLASS_STD") +   "</CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_section") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_SECTION>" +  lResultSet.getString("CLASS_SECTION") +   "</CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_id") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_ID>" +  lResultSet.getString("COURSE_ID") +   "</COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_term") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_TERM>" +  lResultSet.getString("COURSE_TERM") +   "</COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM>" +  lResultSet.getString("COURSE_STREAM") +   "</COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("roll_num") )
              lXmlBuffer = lXmlBuffer +   "<ROLL_NUM>" +  lResultSet.getString("ROLL_NUM") +   "</ROLL_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enrollment_num") )
              lXmlBuffer = lXmlBuffer +   "<ENROLLMENT_NUM>" +  lResultSet.getString("ENROLLMENT_NUM") +   "</ENROLLMENT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("shift_code") )
              lXmlBuffer = lXmlBuffer +   "<SHIFT_CODE>" +  lResultSet.getString("SHIFT_CODE") +   "</SHIFT_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_org_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ORG_ID>" +  lResultSet.getString("PREV_ORG_ID") +   "</PREV_ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_ID>" +  lResultSet.getString("PREV_CLASS_ID") +   "</PREV_CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_num") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_NUM>" +  lResultSet.getString("PREV_CLASS_NUM") +   "</PREV_CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_std") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_STD>" +  lResultSet.getString("PREV_CLASS_STD") +   "</PREV_CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_section") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_SECTION>" +  lResultSet.getString("PREV_CLASS_SECTION") +   "</PREV_CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_ID>" +  lResultSet.getString("PREV_COURSE_ID") +   "</PREV_COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_term") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_TERM>" +  lResultSet.getString("PREV_COURSE_TERM") +   "</PREV_COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_stream") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_STREAM>" +  lResultSet.getString("PREV_COURSE_STREAM") +   "</PREV_COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_shift_code") )
              lXmlBuffer = lXmlBuffer +   "<PREV_SHIFT_CODE>" +  lResultSet.getString("PREV_SHIFT_CODE") +   "</PREV_SHIFT_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("promotion_sts") )
              lXmlBuffer = lXmlBuffer +   "<PROMOTION_STS>" +  lResultSet.getString("PROMOTION_STS") +   "</PROMOTION_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("promotion_date") )
              lXmlBuffer = lXmlBuffer +   "<PROMOTION_DATE>" +  lResultSet.getString("PROMOTION_DATE") +   "</PROMOTION_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone") )
              lXmlBuffer = lXmlBuffer +   "<PHONE>" +  lResultSet.getString("PHONE") +   "</PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_id") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_ID>" +  lResultSet.getString("EMAIL_ID") +   "</EMAIL_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_sts") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_STS>" +  lResultSet.getString("STUDENT_STS") +   "</STUDENT_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_STS_DATE>" +  lResultSet.getString("STUDENT_STS_DATE") +   "</STUDENT_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("country") )
              lXmlBuffer = lXmlBuffer +   "<COUNTRY>" +  lResultSet.getString("COUNTRY") +   "</COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("photo_file_name") )
              lXmlBuffer = lXmlBuffer +   "<PHOTO_FILE_NAME>" +  lResultSet.getString("PHOTO_FILE_NAME") +   "</PHOTO_FILE_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("batch_number") )
              lXmlBuffer = lXmlBuffer +   "<BATCH_NUMBER>" +  lResultSet.getString("BATCH_NUMBER") +   "</BATCH_NUMBER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("num_of_yr_in_class") )
              lXmlBuffer = lXmlBuffer +   "<NUM_OF_YR_IN_CLASS>" +  lResultSet.getByte("NUM_OF_YR_IN_CLASS") +   "</NUM_OF_YR_IN_CLASS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("passing_year") )
              lXmlBuffer = lXmlBuffer +   "<PASSING_YEAR>" +  lResultSet.getByte("PASSING_YEAR") +   "</PASSING_YEAR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stud_seq_num") )
              lXmlBuffer = lXmlBuffer +   "<STUD_SEQ_NUM>" +  lResultSet.getInt("STUD_SEQ_NUM") +   "</STUD_SEQ_NUM>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesAlumni>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesAlumniRecByRowid
               ( String inRowId
               , EesAlumniTabObj  outEesAlumniTabObj
               )
  {
    sop("gtEesAlumniRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "alumni_id, "+
                                 "alumni_cre_date, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "student_name, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "dob, "+
                                 "doj, "+
                                 "dot, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "roll_num, "+
                                 "enrollment_num, "+
                                 "shift_code, "+
                                 "prev_org_id, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "prev_shift_code, "+
                                 "promotion_sts, "+
                                 "promotion_date, "+
                                 "phone, "+
                                 "email_id, "+
                                 "student_sts, "+
                                 "student_sts_date, "+
                                 "country, "+
                                 "photo_file_name, "+
                                 "batch_number, "+
                                 "num_of_yr_in_class, "+
                                 "passing_year, "+
                                 "stud_seq_num "+
                         "FROM   EES_ALUMNI "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesAlumniTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAlumniTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAlumniTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          outEesAlumniTabObj.alumni_cre_date  =  lResultSet.getString("ALUMNI_CRE_DATE");

          if ( outEesAlumniTabObj.alumni_cre_date != null && outEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            outEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.barcode  =  lResultSet.getString("BARCODE");
          outEesAlumniTabObj.user_id  =  lResultSet.getString("USER_ID");
          outEesAlumniTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          outEesAlumniTabObj.student_name  =  lResultSet.getString("STUDENT_NAME");
          outEesAlumniTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAlumniTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAlumniTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAlumniTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAlumniTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAlumniTabObj.dob != null && outEesAlumniTabObj.dob.length() > 0 ) 
            outEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.dob, lDateTimeTrgFmt);
          outEesAlumniTabObj.doj  =  lResultSet.getString("DOJ");

          if ( outEesAlumniTabObj.doj != null && outEesAlumniTabObj.doj.length() > 0 ) 
            outEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.doj, lDateTimeTrgFmt);
          outEesAlumniTabObj.dot  =  lResultSet.getString("DOT");

          if ( outEesAlumniTabObj.dot != null && outEesAlumniTabObj.dot.length() > 0 ) 
            outEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.dot, lDateTimeTrgFmt);
          outEesAlumniTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          outEesAlumniTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          outEesAlumniTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAlumniTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAlumniTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAlumniTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAlumniTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAlumniTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAlumniTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAlumniTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAlumniTabObj.enrollment_num  =  lResultSet.getString("ENROLLMENT_NUM");
          outEesAlumniTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          outEesAlumniTabObj.prev_org_id  =  lResultSet.getString("PREV_ORG_ID");
          outEesAlumniTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAlumniTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAlumniTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAlumniTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAlumniTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAlumniTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAlumniTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAlumniTabObj.prev_shift_code  =  lResultSet.getString("PREV_SHIFT_CODE");
          outEesAlumniTabObj.promotion_sts  =  lResultSet.getString("PROMOTION_STS");
          outEesAlumniTabObj.promotion_date  =  lResultSet.getString("PROMOTION_DATE");

          if ( outEesAlumniTabObj.promotion_date != null && outEesAlumniTabObj.promotion_date.length() > 0 ) 
            outEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.phone  =  lResultSet.getString("PHONE");
          outEesAlumniTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          outEesAlumniTabObj.student_sts  =  lResultSet.getString("STUDENT_STS");
          outEesAlumniTabObj.student_sts_date  =  lResultSet.getString("STUDENT_STS_DATE");

          if ( outEesAlumniTabObj.student_sts_date != null && outEesAlumniTabObj.student_sts_date.length() > 0 ) 
            outEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
          outEesAlumniTabObj.country  =  lResultSet.getString("COUNTRY");
          outEesAlumniTabObj.photo_file_name  =  lResultSet.getString("PHOTO_FILE_NAME");
          outEesAlumniTabObj.batch_number  =  lResultSet.getString("BATCH_NUMBER");
          outEesAlumniTabObj.num_of_yr_in_class  =  lResultSet.getByte("NUM_OF_YR_IN_CLASS");
          outEesAlumniTabObj.passing_year  =  lResultSet.getByte("PASSING_YEAR");
          outEesAlumniTabObj.stud_seq_num  =  lResultSet.getInt("STUD_SEQ_NUM");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAlumniTabObj( outEesAlumniTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniArr
               ( String inEesAlumniWhereText
               , ArrayList  outEesAlumniTabObjArr
               )
  {
    sop("gtEesAlumniArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "alumni_id, "+
                                 "alumni_cre_date, "+
                                 "barcode, "+
                                 "user_id, "+
                                 "pswd_0, "+
                                 "student_name, "+
                                 "father_name, "+
                                 "mother_name, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "dob, "+
                                 "doj, "+
                                 "dot, "+
                                 "address_1, "+
                                 "address_2, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "roll_num, "+
                                 "enrollment_num, "+
                                 "shift_code, "+
                                 "prev_org_id, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "prev_shift_code, "+
                                 "promotion_sts, "+
                                 "promotion_date, "+
                                 "phone, "+
                                 "email_id, "+
                                 "student_sts, "+
                                 "student_sts_date, "+
                                 "country, "+
                                 "photo_file_name, "+
                                 "batch_number, "+
                                 "num_of_yr_in_class, "+
                                 "passing_year, "+
                                 "stud_seq_num "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAlumniTabObj  lEesAlumniTabObj = new EesAlumniTabObj();
          lEesAlumniTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesAlumniTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAlumniTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
          lEesAlumniTabObj.alumni_cre_date  =  lResultSet.getString("ALUMNI_CRE_DATE");

          if ( lEesAlumniTabObj.alumni_cre_date != null && lEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            lEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.barcode  =  lResultSet.getString("BARCODE");
          lEesAlumniTabObj.user_id  =  lResultSet.getString("USER_ID");
          lEesAlumniTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
          lEesAlumniTabObj.student_name  =  lResultSet.getString("STUDENT_NAME");
          lEesAlumniTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAlumniTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAlumniTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAlumniTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAlumniTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAlumniTabObj.dob != null && lEesAlumniTabObj.dob.length() > 0 ) 
            lEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dob, lDateTimeTrgFmt);
          lEesAlumniTabObj.doj  =  lResultSet.getString("DOJ");

          if ( lEesAlumniTabObj.doj != null && lEesAlumniTabObj.doj.length() > 0 ) 
            lEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.doj, lDateTimeTrgFmt);
          lEesAlumniTabObj.dot  =  lResultSet.getString("DOT");

          if ( lEesAlumniTabObj.dot != null && lEesAlumniTabObj.dot.length() > 0 ) 
            lEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dot, lDateTimeTrgFmt);
          lEesAlumniTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
          lEesAlumniTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
          lEesAlumniTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAlumniTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAlumniTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAlumniTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAlumniTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAlumniTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAlumniTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAlumniTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAlumniTabObj.enrollment_num  =  lResultSet.getString("ENROLLMENT_NUM");
          lEesAlumniTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
          lEesAlumniTabObj.prev_org_id  =  lResultSet.getString("PREV_ORG_ID");
          lEesAlumniTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAlumniTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAlumniTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAlumniTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAlumniTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAlumniTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAlumniTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAlumniTabObj.prev_shift_code  =  lResultSet.getString("PREV_SHIFT_CODE");
          lEesAlumniTabObj.promotion_sts  =  lResultSet.getString("PROMOTION_STS");
          lEesAlumniTabObj.promotion_date  =  lResultSet.getString("PROMOTION_DATE");

          if ( lEesAlumniTabObj.promotion_date != null && lEesAlumniTabObj.promotion_date.length() > 0 ) 
            lEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.phone  =  lResultSet.getString("PHONE");
          lEesAlumniTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
          lEesAlumniTabObj.student_sts  =  lResultSet.getString("STUDENT_STS");
          lEesAlumniTabObj.student_sts_date  =  lResultSet.getString("STUDENT_STS_DATE");

          if ( lEesAlumniTabObj.student_sts_date != null && lEesAlumniTabObj.student_sts_date.length() > 0 ) 
            lEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
          lEesAlumniTabObj.country  =  lResultSet.getString("COUNTRY");
          lEesAlumniTabObj.photo_file_name  =  lResultSet.getString("PHOTO_FILE_NAME");
          lEesAlumniTabObj.batch_number  =  lResultSet.getString("BATCH_NUMBER");
          lEesAlumniTabObj.num_of_yr_in_class  =  lResultSet.getByte("NUM_OF_YR_IN_CLASS");
          lEesAlumniTabObj.passing_year  =  lResultSet.getByte("PASSING_YEAR");
          lEesAlumniTabObj.stud_seq_num  =  lResultSet.getInt("STUD_SEQ_NUM");

          removeNullEesAlumniTabObj( lEesAlumniTabObj );

          outEesAlumniTabObjArr.add(  lEesAlumniTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniTabObjArr != null && outEesAlumniTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniArrDist
               ( String inEesAlumniWhereText
               , String inDistEesAlumniField
               , ArrayList  outEesAlumniTabObjArr
               )
  {

    sop("gtEesAlumniArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";
  

       String lDistEesAlumniFieldQry = inDistEesAlumniField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAlumniFieldQry+
                         " FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAlumniField.substring(inDistEesAlumniField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesAlumniTabObj  lEesAlumniTabObj = new EesAlumniTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesAlumniTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("alumni_id") )
              lEesAlumniTabObj.alumni_id  =  lResultSet.getString("ALUMNI_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("alumni_cre_date") )
              {
              lEesAlumniTabObj.alumni_cre_date  =  lResultSet.getString("ALUMNI_CRE_DATE");
  
          if ( lEesAlumniTabObj.alumni_cre_date != null && lEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            lEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.alumni_cre_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("barcode") )
              lEesAlumniTabObj.barcode  =  lResultSet.getString("BARCODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("user_id") )
              lEesAlumniTabObj.user_id  =  lResultSet.getString("USER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("pswd_0") )
              lEesAlumniTabObj.pswd_0  =  lResultSet.getString("PSWD_0");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_name") )
              lEesAlumniTabObj.student_name  =  lResultSet.getString("STUDENT_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_name") )
              lEesAlumniTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_name") )
              lEesAlumniTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_ctg") )
              lEesAlumniTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gender_flag") )
              lEesAlumniTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dob") )
              {
              lEesAlumniTabObj.dob  =  lResultSet.getString("DOB");
  
          if ( lEesAlumniTabObj.dob != null && lEesAlumniTabObj.dob.length() > 0 ) 
            lEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dob, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("doj") )
              {
              lEesAlumniTabObj.doj  =  lResultSet.getString("DOJ");
  
          if ( lEesAlumniTabObj.doj != null && lEesAlumniTabObj.doj.length() > 0 ) 
            lEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.doj, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dot") )
              {
              lEesAlumniTabObj.dot  =  lResultSet.getString("DOT");
  
          if ( lEesAlumniTabObj.dot != null && lEesAlumniTabObj.dot.length() > 0 ) 
            lEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.dot, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_1") )
              lEesAlumniTabObj.address_1  =  lResultSet.getString("ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("address_2") )
              lEesAlumniTabObj.address_2  =  lResultSet.getString("ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_id") )
              lEesAlumniTabObj.class_id  =  lResultSet.getString("CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_num") )
              lEesAlumniTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_std") )
              lEesAlumniTabObj.class_std  =  lResultSet.getString("CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_section") )
              lEesAlumniTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_id") )
              lEesAlumniTabObj.course_id  =  lResultSet.getString("COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_term") )
              lEesAlumniTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream") )
              lEesAlumniTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("roll_num") )
              lEesAlumniTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enrollment_num") )
              lEesAlumniTabObj.enrollment_num  =  lResultSet.getString("ENROLLMENT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("shift_code") )
              lEesAlumniTabObj.shift_code  =  lResultSet.getString("SHIFT_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_org_id") )
              lEesAlumniTabObj.prev_org_id  =  lResultSet.getString("PREV_ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_id") )
              lEesAlumniTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_num") )
              lEesAlumniTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_std") )
              lEesAlumniTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_section") )
              lEesAlumniTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_id") )
              lEesAlumniTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_term") )
              lEesAlumniTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_stream") )
              lEesAlumniTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_shift_code") )
              lEesAlumniTabObj.prev_shift_code  =  lResultSet.getString("PREV_SHIFT_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("promotion_sts") )
              lEesAlumniTabObj.promotion_sts  =  lResultSet.getString("PROMOTION_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("promotion_date") )
              {
              lEesAlumniTabObj.promotion_date  =  lResultSet.getString("PROMOTION_DATE");
  
          if ( lEesAlumniTabObj.promotion_date != null && lEesAlumniTabObj.promotion_date.length() > 0 ) 
            lEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.promotion_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone") )
              lEesAlumniTabObj.phone  =  lResultSet.getString("PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_id") )
              lEesAlumniTabObj.email_id  =  lResultSet.getString("EMAIL_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_sts") )
              lEesAlumniTabObj.student_sts  =  lResultSet.getString("STUDENT_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_sts_date") )
              {
              lEesAlumniTabObj.student_sts_date  =  lResultSet.getString("STUDENT_STS_DATE");
  
          if ( lEesAlumniTabObj.student_sts_date != null && lEesAlumniTabObj.student_sts_date.length() > 0 ) 
            lEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAlumniTabObj.student_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("country") )
              lEesAlumniTabObj.country  =  lResultSet.getString("COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("photo_file_name") )
              lEesAlumniTabObj.photo_file_name  =  lResultSet.getString("PHOTO_FILE_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("batch_number") )
              lEesAlumniTabObj.batch_number  =  lResultSet.getString("BATCH_NUMBER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("num_of_yr_in_class") )
              lEesAlumniTabObj.num_of_yr_in_class  =  lResultSet.getByte("NUM_OF_YR_IN_CLASS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("passing_year") )
              lEesAlumniTabObj.passing_year  =  lResultSet.getByte("PASSING_YEAR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stud_seq_num") )
              lEesAlumniTabObj.stud_seq_num  =  lResultSet.getInt("STUD_SEQ_NUM");

          }
          removeNullEesAlumniTabObj( lEesAlumniTabObj );

          outEesAlumniTabObjArr.add(  lEesAlumniTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniTabObjArr != null && outEesAlumniTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAlumniStrArrDist
               ( String inEesAlumniWhereText
               , String inDistEesAlumniField
               , ArrayList  outEesAlumniTabObjArr
               )
  {

    sop("gtEesAlumniStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAlumniStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";
  

       String lDistEesAlumniFieldQry = inDistEesAlumniField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAlumniFieldQry+
                         " FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAlumniField.substring(inDistEesAlumniField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesAlumniTabObjStr = "";
       while(lResultSet.next())
       {
          lEesAlumniTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesAlumniTabObjStr =   lEesAlumniTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesAlumniTabObjArr.add(  lEesAlumniTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAlumniTabObjArr != null && outEesAlumniTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesAlumni
               ( String inEesAlumniWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesAlumni - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesAlumni";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesAlumniTabObj
               ( 
                 EesAlumniTabObj  outEesAlumniTabObj
               )
  {
  
    if ( outEesAlumniTabObj.org_id == null ) 
     outEesAlumniTabObj.org_id = ""; 
    if ( outEesAlumniTabObj.alumni_id == null ) 
     outEesAlumniTabObj.alumni_id = ""; 
    if ( outEesAlumniTabObj.alumni_cre_date == null ) 
     outEesAlumniTabObj.alumni_cre_date = ""; 
    if ( outEesAlumniTabObj.barcode == null ) 
     outEesAlumniTabObj.barcode = ""; 
    if ( outEesAlumniTabObj.user_id == null ) 
     outEesAlumniTabObj.user_id = ""; 
    if ( outEesAlumniTabObj.pswd_0 == null ) 
     outEesAlumniTabObj.pswd_0 = ""; 
    if ( outEesAlumniTabObj.student_name == null ) 
     outEesAlumniTabObj.student_name = ""; 
    if ( outEesAlumniTabObj.father_name == null ) 
     outEesAlumniTabObj.father_name = ""; 
    if ( outEesAlumniTabObj.mother_name == null ) 
     outEesAlumniTabObj.mother_name = ""; 
    if ( outEesAlumniTabObj.student_ctg == null ) 
     outEesAlumniTabObj.student_ctg = ""; 
    if ( outEesAlumniTabObj.gender_flag == null ) 
     outEesAlumniTabObj.gender_flag = ""; 
    if ( outEesAlumniTabObj.dob == null ) 
     outEesAlumniTabObj.dob = ""; 
    if ( outEesAlumniTabObj.doj == null ) 
     outEesAlumniTabObj.doj = ""; 
    if ( outEesAlumniTabObj.dot == null ) 
     outEesAlumniTabObj.dot = ""; 
    if ( outEesAlumniTabObj.address_1 == null ) 
     outEesAlumniTabObj.address_1 = ""; 
    if ( outEesAlumniTabObj.address_2 == null ) 
     outEesAlumniTabObj.address_2 = ""; 
    if ( outEesAlumniTabObj.class_id == null ) 
     outEesAlumniTabObj.class_id = ""; 
    if ( outEesAlumniTabObj.class_num == null ) 
     outEesAlumniTabObj.class_num = ""; 
    if ( outEesAlumniTabObj.class_std == null ) 
     outEesAlumniTabObj.class_std = ""; 
    if ( outEesAlumniTabObj.class_section == null ) 
     outEesAlumniTabObj.class_section = ""; 
    if ( outEesAlumniTabObj.course_id == null ) 
     outEesAlumniTabObj.course_id = ""; 
    if ( outEesAlumniTabObj.course_term == null ) 
     outEesAlumniTabObj.course_term = ""; 
    if ( outEesAlumniTabObj.course_stream == null ) 
     outEesAlumniTabObj.course_stream = ""; 
    if ( outEesAlumniTabObj.roll_num == null ) 
     outEesAlumniTabObj.roll_num = ""; 
    if ( outEesAlumniTabObj.enrollment_num == null ) 
     outEesAlumniTabObj.enrollment_num = ""; 
    if ( outEesAlumniTabObj.shift_code == null ) 
     outEesAlumniTabObj.shift_code = ""; 
    if ( outEesAlumniTabObj.prev_org_id == null ) 
     outEesAlumniTabObj.prev_org_id = ""; 
    if ( outEesAlumniTabObj.prev_class_id == null ) 
     outEesAlumniTabObj.prev_class_id = ""; 
    if ( outEesAlumniTabObj.prev_class_num == null ) 
     outEesAlumniTabObj.prev_class_num = ""; 
    if ( outEesAlumniTabObj.prev_class_std == null ) 
     outEesAlumniTabObj.prev_class_std = ""; 
    if ( outEesAlumniTabObj.prev_class_section == null ) 
     outEesAlumniTabObj.prev_class_section = ""; 
    if ( outEesAlumniTabObj.prev_course_id == null ) 
     outEesAlumniTabObj.prev_course_id = ""; 
    if ( outEesAlumniTabObj.prev_course_term == null ) 
     outEesAlumniTabObj.prev_course_term = ""; 
    if ( outEesAlumniTabObj.prev_course_stream == null ) 
     outEesAlumniTabObj.prev_course_stream = ""; 
    if ( outEesAlumniTabObj.prev_shift_code == null ) 
     outEesAlumniTabObj.prev_shift_code = ""; 
    if ( outEesAlumniTabObj.promotion_sts == null ) 
     outEesAlumniTabObj.promotion_sts = ""; 
    if ( outEesAlumniTabObj.promotion_date == null ) 
     outEesAlumniTabObj.promotion_date = ""; 
    if ( outEesAlumniTabObj.phone == null ) 
     outEesAlumniTabObj.phone = ""; 
    if ( outEesAlumniTabObj.email_id == null ) 
     outEesAlumniTabObj.email_id = ""; 
    if ( outEesAlumniTabObj.student_sts == null ) 
     outEesAlumniTabObj.student_sts = ""; 
    if ( outEesAlumniTabObj.student_sts_date == null ) 
     outEesAlumniTabObj.student_sts_date = ""; 
    if ( outEesAlumniTabObj.country == null ) 
     outEesAlumniTabObj.country = ""; 
    if ( outEesAlumniTabObj.photo_file_name == null ) 
     outEesAlumniTabObj.photo_file_name = ""; 
    if ( outEesAlumniTabObj.batch_number == null ) 
     outEesAlumniTabObj.batch_number = ""; 
    if ( outEesAlumniTabObj.num_of_yr_in_class == (int)0 ) 
     outEesAlumniTabObj.num_of_yr_in_class = (int)0; 
    if ( outEesAlumniTabObj.passing_year == (int)0 ) 
     outEesAlumniTabObj.passing_year = (int)0; 
    if ( outEesAlumniTabObj.stud_seq_num == (int)0 ) 
     outEesAlumniTabObj.stud_seq_num = (int)0; 
  }





  public int insEesAlumniRec
               ( EesAlumniTabObj  inEesAlumniTabObj )
  {
    int lUpdateCount;
    sop("insEesAlumniRec - Started");
    gSSTErrorObj.sourceMethod = "insEesAlumniRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniTabObj.alumni_cre_date != null && inEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            inEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.alumni_cre_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dob != null && inEesAlumniTabObj.dob.length() > 0 ) 
            inEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.doj != null && inEesAlumniTabObj.doj.length() > 0 ) 
            inEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.doj, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dot != null && inEesAlumniTabObj.dot.length() > 0 ) 
            inEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dot, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.promotion_date != null && inEesAlumniTabObj.promotion_date.length() > 0 ) 
            inEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.promotion_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.student_sts_date != null && inEesAlumniTabObj.student_sts_date.length() > 0 ) 
            inEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.student_sts_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ALUMNI"+
                        "("+
                                "org_id,"+
                                "alumni_id,"+
                                "alumni_cre_date,"+
                                "barcode,"+
                                "user_id,"+
                                "pswd_0,"+
                                "student_name,"+
                                "father_name,"+
                                "mother_name,"+
                                "student_ctg,"+
                                "gender_flag,"+
                                "dob,"+
                                "doj,"+
                                "dot,"+
                                "address_1,"+
                                "address_2,"+
                                "class_id,"+
                                "class_num,"+
                                "class_std,"+
                                "class_section,"+
                                "course_id,"+
                                "course_term,"+
                                "course_stream,"+
                                "roll_num,"+
                                "enrollment_num,"+
                                "shift_code,"+
                                "prev_org_id,"+
                                "prev_class_id,"+
                                "prev_class_num,"+
                                "prev_class_std,"+
                                "prev_class_section,"+
                                "prev_course_id,"+
                                "prev_course_term,"+
                                "prev_course_stream,"+
                                "prev_shift_code,"+
                                "promotion_sts,"+
                                "promotion_date,"+
                                "phone,"+
                                "email_id,"+
                                "student_sts,"+
                                "student_sts_date,"+
                                "country,"+
                                "photo_file_name,"+
                                "batch_number,"+
                                "num_of_yr_in_class,"+
                                "passing_year,"+
                                "stud_seq_num"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.alumni_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.alumni_cre_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.barcode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.user_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.pswd_0+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.student_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.father_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.mother_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.student_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.gender_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.dob+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.doj+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.dot+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.roll_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.enrollment_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.shift_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.prev_shift_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.promotion_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.promotion_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.email_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.student_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.student_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.photo_file_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAlumniTabObj.batch_number+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAlumniTabObj.num_of_yr_in_class+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAlumniTabObj.passing_year+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += inEesAlumniTabObj.stud_seq_num+"";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesAlumniTabObj.org_id);
        lPreparedStatement.setString(2, inEesAlumniTabObj.alumni_id);
        lPreparedStatement.setString(3, inEesAlumniTabObj.alumni_cre_date);
        lPreparedStatement.setString(4, inEesAlumniTabObj.barcode);
        lPreparedStatement.setString(5, inEesAlumniTabObj.user_id);
        lPreparedStatement.setString(6, inEesAlumniTabObj.pswd_0);
        lPreparedStatement.setString(7, inEesAlumniTabObj.student_name);
        lPreparedStatement.setString(8, inEesAlumniTabObj.father_name);
        lPreparedStatement.setString(9, inEesAlumniTabObj.mother_name);
        lPreparedStatement.setString(10, inEesAlumniTabObj.student_ctg);
        lPreparedStatement.setString(11, inEesAlumniTabObj.gender_flag);
        lPreparedStatement.setString(12, inEesAlumniTabObj.dob);
        lPreparedStatement.setString(13, inEesAlumniTabObj.doj);
        lPreparedStatement.setString(14, inEesAlumniTabObj.dot);
        lPreparedStatement.setString(15, inEesAlumniTabObj.address_1);
        lPreparedStatement.setString(16, inEesAlumniTabObj.address_2);
        lPreparedStatement.setString(17, inEesAlumniTabObj.class_id);
        lPreparedStatement.setString(18, inEesAlumniTabObj.class_num);
        lPreparedStatement.setString(19, inEesAlumniTabObj.class_std);
        lPreparedStatement.setString(20, inEesAlumniTabObj.class_section);
        lPreparedStatement.setString(21, inEesAlumniTabObj.course_id);
        lPreparedStatement.setString(22, inEesAlumniTabObj.course_term);
        lPreparedStatement.setString(23, inEesAlumniTabObj.course_stream);
        lPreparedStatement.setString(24, inEesAlumniTabObj.roll_num);
        lPreparedStatement.setString(25, inEesAlumniTabObj.enrollment_num);
        lPreparedStatement.setString(26, inEesAlumniTabObj.shift_code);
        lPreparedStatement.setString(27, inEesAlumniTabObj.prev_org_id);
        lPreparedStatement.setString(28, inEesAlumniTabObj.prev_class_id);
        lPreparedStatement.setString(29, inEesAlumniTabObj.prev_class_num);
        lPreparedStatement.setString(30, inEesAlumniTabObj.prev_class_std);
        lPreparedStatement.setString(31, inEesAlumniTabObj.prev_class_section);
        lPreparedStatement.setString(32, inEesAlumniTabObj.prev_course_id);
        lPreparedStatement.setString(33, inEesAlumniTabObj.prev_course_term);
        lPreparedStatement.setString(34, inEesAlumniTabObj.prev_course_stream);
        lPreparedStatement.setString(35, inEesAlumniTabObj.prev_shift_code);
        lPreparedStatement.setString(36, inEesAlumniTabObj.promotion_sts);
        lPreparedStatement.setString(37, inEesAlumniTabObj.promotion_date);
        lPreparedStatement.setString(38, inEesAlumniTabObj.phone);
        lPreparedStatement.setString(39, inEesAlumniTabObj.email_id);
        lPreparedStatement.setString(40, inEesAlumniTabObj.student_sts);
        lPreparedStatement.setString(41, inEesAlumniTabObj.student_sts_date);
        lPreparedStatement.setString(42, inEesAlumniTabObj.country);
        lPreparedStatement.setString(43, inEesAlumniTabObj.photo_file_name);
        lPreparedStatement.setString(44, inEesAlumniTabObj.batch_number);
          lPreparedStatement.setByte(45, inEesAlumniTabObj.num_of_yr_in_class);
          lPreparedStatement.setByte(46, inEesAlumniTabObj.passing_year);
          lPreparedStatement.setInt(47, inEesAlumniTabObj.stud_seq_num);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesAlumniArr
               ( ArrayList  inEesAlumniTabObjArr 
               , String  inRowidFlag )
  {
    EesAlumniTabObj  lEesAlumniTabObj = new EesAlumniTabObj();
    int lUpdateCount;
    sop("insEesAlumniArr - Started");
    gSSTErrorObj.sourceMethod = "insEesAlumniArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesAlumniTabObjArr.size(); lNumRec++ )
      {
        lEesAlumniTabObj = (EesAlumniTabObj)inEesAlumniTabObjArr.get(lNumRec);

          if ( lEesAlumniTabObj.alumni_cre_date != null && lEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            lEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.alumni_cre_date, lDateTimeSrcFmt);

          if ( lEesAlumniTabObj.dob != null && lEesAlumniTabObj.dob.length() > 0 ) 
            lEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.dob, lDateTimeSrcFmt);

          if ( lEesAlumniTabObj.doj != null && lEesAlumniTabObj.doj.length() > 0 ) 
            lEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.doj, lDateTimeSrcFmt);

          if ( lEesAlumniTabObj.dot != null && lEesAlumniTabObj.dot.length() > 0 ) 
            lEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.dot, lDateTimeSrcFmt);

          if ( lEesAlumniTabObj.promotion_date != null && lEesAlumniTabObj.promotion_date.length() > 0 ) 
            lEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.promotion_date, lDateTimeSrcFmt);

          if ( lEesAlumniTabObj.student_sts_date != null && lEesAlumniTabObj.student_sts_date.length() > 0 ) 
            lEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAlumniTabObj.student_sts_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ALUMNI"+
                        "("+
                        "org_id,"+
                        "alumni_id,"+
                        "alumni_cre_date,"+
                        "barcode,"+
                        "user_id,"+
                        "pswd_0,"+
                        "student_name,"+
                        "father_name,"+
                        "mother_name,"+
                        "student_ctg,"+
                        "gender_flag,"+
                        "dob,"+
                        "doj,"+
                        "dot,"+
                        "address_1,"+
                        "address_2,"+
                        "class_id,"+
                        "class_num,"+
                        "class_std,"+
                        "class_section,"+
                        "course_id,"+
                        "course_term,"+
                        "course_stream,"+
                        "roll_num,"+
                        "enrollment_num,"+
                        "shift_code,"+
                        "prev_org_id,"+
                        "prev_class_id,"+
                        "prev_class_num,"+
                        "prev_class_std,"+
                        "prev_class_section,"+
                        "prev_course_id,"+
                        "prev_course_term,"+
                        "prev_course_stream,"+
                        "prev_shift_code,"+
                        "promotion_sts,"+
                        "promotion_date,"+
                        "phone,"+
                        "email_id,"+
                        "student_sts,"+
                        "student_sts_date,"+
                        "country,"+
                        "photo_file_name,"+
                        "batch_number,"+
                        "num_of_yr_in_class,"+
                        "passing_year,"+
                        "stud_seq_num"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.alumni_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.alumni_cre_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.barcode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.user_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.pswd_0+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.student_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.father_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.mother_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.student_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.gender_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.dob+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.doj+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.dot+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.roll_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.enrollment_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.shift_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.prev_shift_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.promotion_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.promotion_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.email_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.student_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.student_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.photo_file_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAlumniTabObj.batch_number+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAlumniTabObj.num_of_yr_in_class+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAlumniTabObj.passing_year+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += lEesAlumniTabObj.stud_seq_num+"";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesAlumniTabObj.org_id);
            lPreparedStatement.setString(2, lEesAlumniTabObj.alumni_id);
            lPreparedStatement.setString(3, lEesAlumniTabObj.alumni_cre_date);
            lPreparedStatement.setString(4, lEesAlumniTabObj.barcode);
            lPreparedStatement.setString(5, lEesAlumniTabObj.user_id);
            lPreparedStatement.setString(6, lEesAlumniTabObj.pswd_0);
            lPreparedStatement.setString(7, lEesAlumniTabObj.student_name);
            lPreparedStatement.setString(8, lEesAlumniTabObj.father_name);
            lPreparedStatement.setString(9, lEesAlumniTabObj.mother_name);
            lPreparedStatement.setString(10, lEesAlumniTabObj.student_ctg);
            lPreparedStatement.setString(11, lEesAlumniTabObj.gender_flag);
            lPreparedStatement.setString(12, lEesAlumniTabObj.dob);
            lPreparedStatement.setString(13, lEesAlumniTabObj.doj);
            lPreparedStatement.setString(14, lEesAlumniTabObj.dot);
            lPreparedStatement.setString(15, lEesAlumniTabObj.address_1);
            lPreparedStatement.setString(16, lEesAlumniTabObj.address_2);
            lPreparedStatement.setString(17, lEesAlumniTabObj.class_id);
            lPreparedStatement.setString(18, lEesAlumniTabObj.class_num);
            lPreparedStatement.setString(19, lEesAlumniTabObj.class_std);
            lPreparedStatement.setString(20, lEesAlumniTabObj.class_section);
            lPreparedStatement.setString(21, lEesAlumniTabObj.course_id);
            lPreparedStatement.setString(22, lEesAlumniTabObj.course_term);
            lPreparedStatement.setString(23, lEesAlumniTabObj.course_stream);
            lPreparedStatement.setString(24, lEesAlumniTabObj.roll_num);
            lPreparedStatement.setString(25, lEesAlumniTabObj.enrollment_num);
            lPreparedStatement.setString(26, lEesAlumniTabObj.shift_code);
            lPreparedStatement.setString(27, lEesAlumniTabObj.prev_org_id);
            lPreparedStatement.setString(28, lEesAlumniTabObj.prev_class_id);
            lPreparedStatement.setString(29, lEesAlumniTabObj.prev_class_num);
            lPreparedStatement.setString(30, lEesAlumniTabObj.prev_class_std);
            lPreparedStatement.setString(31, lEesAlumniTabObj.prev_class_section);
            lPreparedStatement.setString(32, lEesAlumniTabObj.prev_course_id);
            lPreparedStatement.setString(33, lEesAlumniTabObj.prev_course_term);
            lPreparedStatement.setString(34, lEesAlumniTabObj.prev_course_stream);
            lPreparedStatement.setString(35, lEesAlumniTabObj.prev_shift_code);
            lPreparedStatement.setString(36, lEesAlumniTabObj.promotion_sts);
            lPreparedStatement.setString(37, lEesAlumniTabObj.promotion_date);
            lPreparedStatement.setString(38, lEesAlumniTabObj.phone);
            lPreparedStatement.setString(39, lEesAlumniTabObj.email_id);
            lPreparedStatement.setString(40, lEesAlumniTabObj.student_sts);
            lPreparedStatement.setString(41, lEesAlumniTabObj.student_sts_date);
            lPreparedStatement.setString(42, lEesAlumniTabObj.country);
            lPreparedStatement.setString(43, lEesAlumniTabObj.photo_file_name);
            lPreparedStatement.setString(44, lEesAlumniTabObj.batch_number);
              lPreparedStatement.setByte(45, lEesAlumniTabObj.num_of_yr_in_class);
              lPreparedStatement.setByte(46, lEesAlumniTabObj.passing_year);
              lPreparedStatement.setInt(47, lEesAlumniTabObj.stud_seq_num);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesAlumniReq2Obj
               ( HttpServletRequest inRequest
               , EesAlumniTabObj  outEesAlumniTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesAlumniTabObj.tab_rowid = lTabRowidValue;

    outEesAlumniTabObj.org_id = inRequest.getParameter("org_id");
    outEesAlumniTabObj.alumni_id = inRequest.getParameter("alumni_id");
    outEesAlumniTabObj.alumni_cre_date = inRequest.getParameter("alumni_cre_date");
    outEesAlumniTabObj.barcode = inRequest.getParameter("barcode");
    outEesAlumniTabObj.user_id = inRequest.getParameter("user_id");
    outEesAlumniTabObj.pswd_0 = inRequest.getParameter("pswd_0");
    outEesAlumniTabObj.student_name = inRequest.getParameter("student_name");
    outEesAlumniTabObj.father_name = inRequest.getParameter("father_name");
    outEesAlumniTabObj.mother_name = inRequest.getParameter("mother_name");
    outEesAlumniTabObj.student_ctg = inRequest.getParameter("student_ctg");
    outEesAlumniTabObj.gender_flag = inRequest.getParameter("gender_flag");
    outEesAlumniTabObj.dob = inRequest.getParameter("dob");
    outEesAlumniTabObj.doj = inRequest.getParameter("doj");
    outEesAlumniTabObj.dot = inRequest.getParameter("dot");
    outEesAlumniTabObj.address_1 = inRequest.getParameter("address_1");
    outEesAlumniTabObj.address_2 = inRequest.getParameter("address_2");
    outEesAlumniTabObj.class_id = inRequest.getParameter("class_id");
    outEesAlumniTabObj.class_num = inRequest.getParameter("class_num");
    outEesAlumniTabObj.class_std = inRequest.getParameter("class_std");
    outEesAlumniTabObj.class_section = inRequest.getParameter("class_section");
    outEesAlumniTabObj.course_id = inRequest.getParameter("course_id");
    outEesAlumniTabObj.course_term = inRequest.getParameter("course_term");
    outEesAlumniTabObj.course_stream = inRequest.getParameter("course_stream");
    outEesAlumniTabObj.roll_num = inRequest.getParameter("roll_num");
    outEesAlumniTabObj.enrollment_num = inRequest.getParameter("enrollment_num");
    outEesAlumniTabObj.shift_code = inRequest.getParameter("shift_code");
    outEesAlumniTabObj.prev_org_id = inRequest.getParameter("prev_org_id");
    outEesAlumniTabObj.prev_class_id = inRequest.getParameter("prev_class_id");
    outEesAlumniTabObj.prev_class_num = inRequest.getParameter("prev_class_num");
    outEesAlumniTabObj.prev_class_std = inRequest.getParameter("prev_class_std");
    outEesAlumniTabObj.prev_class_section = inRequest.getParameter("prev_class_section");
    outEesAlumniTabObj.prev_course_id = inRequest.getParameter("prev_course_id");
    outEesAlumniTabObj.prev_course_term = inRequest.getParameter("prev_course_term");
    outEesAlumniTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream");
    outEesAlumniTabObj.prev_shift_code = inRequest.getParameter("prev_shift_code");
    outEesAlumniTabObj.promotion_sts = inRequest.getParameter("promotion_sts");
    outEesAlumniTabObj.promotion_date = inRequest.getParameter("promotion_date");
    outEesAlumniTabObj.phone = inRequest.getParameter("phone");
    outEesAlumniTabObj.email_id = inRequest.getParameter("email_id");
    outEesAlumniTabObj.student_sts = inRequest.getParameter("student_sts");
    outEesAlumniTabObj.student_sts_date = inRequest.getParameter("student_sts_date");
    outEesAlumniTabObj.country = inRequest.getParameter("country");
    outEesAlumniTabObj.photo_file_name = inRequest.getParameter("photo_file_name");
    outEesAlumniTabObj.batch_number = inRequest.getParameter("batch_number");
    if ( inRequest.getParameter("num_of_yr_in_class") == null )
      outEesAlumniTabObj.num_of_yr_in_class = 0;
    else
    if ( inRequest.getParameter("num_of_yr_in_class").trim().length() == 0 )
      outEesAlumniTabObj.num_of_yr_in_class = 0;
    else
      outEesAlumniTabObj.num_of_yr_in_class = Byte.parseByte( inRequest.getParameter("num_of_yr_in_class"));
    if ( inRequest.getParameter("passing_year") == null )
      outEesAlumniTabObj.passing_year = 0;
    else
    if ( inRequest.getParameter("passing_year").trim().length() == 0 )
      outEesAlumniTabObj.passing_year = 0;
    else
      outEesAlumniTabObj.passing_year = Byte.parseByte( inRequest.getParameter("passing_year"));
    if ( inRequest.getParameter("stud_seq_num") == null )
      outEesAlumniTabObj.stud_seq_num = 0;
    else
    if ( inRequest.getParameter("stud_seq_num").trim().length() == 0 )
      outEesAlumniTabObj.stud_seq_num = 0;
    else
      outEesAlumniTabObj.stud_seq_num = Integer.parseInt( inRequest.getParameter("stud_seq_num"));
    return lReturnValue;
  }


  public int popEesAlumniReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAlumniTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAlumniTabObj lEesAlumniTabObj= new EesAlumniTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAlumniTabObj.tab_rowid = lTabRowidValue;

      lEesAlumniTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesAlumniTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
      lEesAlumniTabObj.alumni_cre_date = inRequest.getParameter("alumni_cre_date_r"+lNumRec);
      lEesAlumniTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
      lEesAlumniTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
      lEesAlumniTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
      lEesAlumniTabObj.student_name = inRequest.getParameter("student_name_r"+lNumRec);
      lEesAlumniTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
      lEesAlumniTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
      lEesAlumniTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
      lEesAlumniTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
      lEesAlumniTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
      lEesAlumniTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
      lEesAlumniTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
      lEesAlumniTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
      lEesAlumniTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
      lEesAlumniTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
      lEesAlumniTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
      lEesAlumniTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
      lEesAlumniTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
      lEesAlumniTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
      lEesAlumniTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
      lEesAlumniTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
      lEesAlumniTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
      lEesAlumniTabObj.enrollment_num = inRequest.getParameter("enrollment_num_r"+lNumRec);
      lEesAlumniTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
      lEesAlumniTabObj.prev_org_id = inRequest.getParameter("prev_org_id_r"+lNumRec);
      lEesAlumniTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
      lEesAlumniTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
      lEesAlumniTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
      lEesAlumniTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
      lEesAlumniTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
      lEesAlumniTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
      lEesAlumniTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
      lEesAlumniTabObj.prev_shift_code = inRequest.getParameter("prev_shift_code_r"+lNumRec);
      lEesAlumniTabObj.promotion_sts = inRequest.getParameter("promotion_sts_r"+lNumRec);
      lEesAlumniTabObj.promotion_date = inRequest.getParameter("promotion_date_r"+lNumRec);
      lEesAlumniTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
      lEesAlumniTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
      lEesAlumniTabObj.student_sts = inRequest.getParameter("student_sts_r"+lNumRec);
      lEesAlumniTabObj.student_sts_date = inRequest.getParameter("student_sts_date_r"+lNumRec);
      lEesAlumniTabObj.country = inRequest.getParameter("country_r"+lNumRec);
      lEesAlumniTabObj.photo_file_name = inRequest.getParameter("photo_file_name_r"+lNumRec);
      lEesAlumniTabObj.batch_number = inRequest.getParameter("batch_number_r"+lNumRec);
      if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec) == null )
        lEesAlumniTabObj.num_of_yr_in_class = 0;
      else
      if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec).trim().length() == 0 )
        lEesAlumniTabObj.num_of_yr_in_class = 0;
      else
        lEesAlumniTabObj.num_of_yr_in_class = Byte.parseByte( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec));
      if ( inRequest.getParameter("passing_year_r"+lNumRec) == null )
        lEesAlumniTabObj.passing_year = 0;
      else
      if ( inRequest.getParameter("passing_year_r"+lNumRec).trim().length() == 0 )
        lEesAlumniTabObj.passing_year = 0;
      else
        lEesAlumniTabObj.passing_year = Byte.parseByte( inRequest.getParameter("passing_year_r"+lNumRec));
      if ( inRequest.getParameter("stud_seq_num_r"+lNumRec) == null )
        lEesAlumniTabObj.stud_seq_num = 0;
      else
      if ( inRequest.getParameter("stud_seq_num_r"+lNumRec).trim().length() == 0 )
        lEesAlumniTabObj.stud_seq_num = 0;
      else
        lEesAlumniTabObj.stud_seq_num = Integer.parseInt( inRequest.getParameter("stud_seq_num_r"+lNumRec));
      outEesAlumniTabObjArr.add( lEesAlumniTabObj);
    }
    return lReturnValue;
  }


  public int popEesAlumniReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesAlumniTabObj outEesAlumniTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_alumni_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesAlumniTabObj.tab_rowid = lTabRowidValue;

        outEesAlumniTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesAlumniTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
        outEesAlumniTabObj.alumni_cre_date = inRequest.getParameter("alumni_cre_date_r"+lNumRec);
        outEesAlumniTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
        outEesAlumniTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
        outEesAlumniTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        outEesAlumniTabObj.student_name = inRequest.getParameter("student_name_r"+lNumRec);
        outEesAlumniTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        outEesAlumniTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        outEesAlumniTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        outEesAlumniTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        outEesAlumniTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        outEesAlumniTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
        outEesAlumniTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
        outEesAlumniTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        outEesAlumniTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        outEesAlumniTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        outEesAlumniTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        outEesAlumniTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        outEesAlumniTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        outEesAlumniTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        outEesAlumniTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        outEesAlumniTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        outEesAlumniTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        outEesAlumniTabObj.enrollment_num = inRequest.getParameter("enrollment_num_r"+lNumRec);
        outEesAlumniTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
        outEesAlumniTabObj.prev_org_id = inRequest.getParameter("prev_org_id_r"+lNumRec);
        outEesAlumniTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        outEesAlumniTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        outEesAlumniTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        outEesAlumniTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        outEesAlumniTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        outEesAlumniTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        outEesAlumniTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        outEesAlumniTabObj.prev_shift_code = inRequest.getParameter("prev_shift_code_r"+lNumRec);
        outEesAlumniTabObj.promotion_sts = inRequest.getParameter("promotion_sts_r"+lNumRec);
        outEesAlumniTabObj.promotion_date = inRequest.getParameter("promotion_date_r"+lNumRec);
        outEesAlumniTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
        outEesAlumniTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        outEesAlumniTabObj.student_sts = inRequest.getParameter("student_sts_r"+lNumRec);
        outEesAlumniTabObj.student_sts_date = inRequest.getParameter("student_sts_date_r"+lNumRec);
        outEesAlumniTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        outEesAlumniTabObj.photo_file_name = inRequest.getParameter("photo_file_name_r"+lNumRec);
        outEesAlumniTabObj.batch_number = inRequest.getParameter("batch_number_r"+lNumRec);
        if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec) == null )
          outEesAlumniTabObj.num_of_yr_in_class = 0;
        else
        if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec).trim().length() == 0 )
          outEesAlumniTabObj.num_of_yr_in_class = 0;
        else
          outEesAlumniTabObj.num_of_yr_in_class = Byte.parseByte( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec));
        if ( inRequest.getParameter("passing_year_r"+lNumRec) == null )
          outEesAlumniTabObj.passing_year = 0;
        else
        if ( inRequest.getParameter("passing_year_r"+lNumRec).trim().length() == 0 )
          outEesAlumniTabObj.passing_year = 0;
        else
          outEesAlumniTabObj.passing_year = Byte.parseByte( inRequest.getParameter("passing_year_r"+lNumRec));
        if ( inRequest.getParameter("stud_seq_num_r"+lNumRec) == null )
          outEesAlumniTabObj.stud_seq_num = 0;
        else
        if ( inRequest.getParameter("stud_seq_num_r"+lNumRec).trim().length() == 0 )
          outEesAlumniTabObj.stud_seq_num = 0;
        else
          outEesAlumniTabObj.stud_seq_num = Integer.parseInt( inRequest.getParameter("stud_seq_num_r"+lNumRec));
      }
    }
    return lReturnValue;
  }


  public int popEesAlumniReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAlumniTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAlumniTabObj lEesAlumniTabObj= new EesAlumniTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_alumni_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAlumniTabObj.tab_rowid = lTabRowidValue;

        lEesAlumniTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesAlumniTabObj.alumni_id = inRequest.getParameter("alumni_id_r"+lNumRec);
        lEesAlumniTabObj.alumni_cre_date = inRequest.getParameter("alumni_cre_date_r"+lNumRec);
        lEesAlumniTabObj.barcode = inRequest.getParameter("barcode_r"+lNumRec);
        lEesAlumniTabObj.user_id = inRequest.getParameter("user_id_r"+lNumRec);
        lEesAlumniTabObj.pswd_0 = inRequest.getParameter("pswd_0_r"+lNumRec);
        lEesAlumniTabObj.student_name = inRequest.getParameter("student_name_r"+lNumRec);
        lEesAlumniTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        lEesAlumniTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        lEesAlumniTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        lEesAlumniTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        lEesAlumniTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        lEesAlumniTabObj.doj = inRequest.getParameter("doj_r"+lNumRec);
        lEesAlumniTabObj.dot = inRequest.getParameter("dot_r"+lNumRec);
        lEesAlumniTabObj.address_1 = inRequest.getParameter("address_1_r"+lNumRec);
        lEesAlumniTabObj.address_2 = inRequest.getParameter("address_2_r"+lNumRec);
        lEesAlumniTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        lEesAlumniTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        lEesAlumniTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        lEesAlumniTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        lEesAlumniTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        lEesAlumniTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        lEesAlumniTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        lEesAlumniTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        lEesAlumniTabObj.enrollment_num = inRequest.getParameter("enrollment_num_r"+lNumRec);
        lEesAlumniTabObj.shift_code = inRequest.getParameter("shift_code_r"+lNumRec);
        lEesAlumniTabObj.prev_org_id = inRequest.getParameter("prev_org_id_r"+lNumRec);
        lEesAlumniTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        lEesAlumniTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        lEesAlumniTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        lEesAlumniTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        lEesAlumniTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        lEesAlumniTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        lEesAlumniTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        lEesAlumniTabObj.prev_shift_code = inRequest.getParameter("prev_shift_code_r"+lNumRec);
        lEesAlumniTabObj.promotion_sts = inRequest.getParameter("promotion_sts_r"+lNumRec);
        lEesAlumniTabObj.promotion_date = inRequest.getParameter("promotion_date_r"+lNumRec);
        lEesAlumniTabObj.phone = inRequest.getParameter("phone_r"+lNumRec);
        lEesAlumniTabObj.email_id = inRequest.getParameter("email_id_r"+lNumRec);
        lEesAlumniTabObj.student_sts = inRequest.getParameter("student_sts_r"+lNumRec);
        lEesAlumniTabObj.student_sts_date = inRequest.getParameter("student_sts_date_r"+lNumRec);
        lEesAlumniTabObj.country = inRequest.getParameter("country_r"+lNumRec);
        lEesAlumniTabObj.photo_file_name = inRequest.getParameter("photo_file_name_r"+lNumRec);
        lEesAlumniTabObj.batch_number = inRequest.getParameter("batch_number_r"+lNumRec);
        if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec) == null )
          lEesAlumniTabObj.num_of_yr_in_class = 0;
        else
        if ( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec).trim().length() == 0 )
          lEesAlumniTabObj.num_of_yr_in_class = 0;
        else
          lEesAlumniTabObj.num_of_yr_in_class = Byte.parseByte( inRequest.getParameter("num_of_yr_in_class_r"+lNumRec));
        if ( inRequest.getParameter("passing_year_r"+lNumRec) == null )
          lEesAlumniTabObj.passing_year = 0;
        else
        if ( inRequest.getParameter("passing_year_r"+lNumRec).trim().length() == 0 )
          lEesAlumniTabObj.passing_year = 0;
        else
          lEesAlumniTabObj.passing_year = Byte.parseByte( inRequest.getParameter("passing_year_r"+lNumRec));
        if ( inRequest.getParameter("stud_seq_num_r"+lNumRec) == null )
          lEesAlumniTabObj.stud_seq_num = 0;
        else
        if ( inRequest.getParameter("stud_seq_num_r"+lNumRec).trim().length() == 0 )
          lEesAlumniTabObj.stud_seq_num = 0;
        else
          lEesAlumniTabObj.stud_seq_num = Integer.parseInt( inRequest.getParameter("stud_seq_num_r"+lNumRec));
        outEesAlumniTabObjArr.add( lEesAlumniTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniRecByRowid
               ( String inRowId
               , EesAlumniTabObj  inEesAlumniTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAlumniRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniTabObj.alumni_cre_date != null && inEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            inEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.alumni_cre_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dob != null && inEesAlumniTabObj.dob.length() > 0 ) 
            inEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.doj != null && inEesAlumniTabObj.doj.length() > 0 ) 
            inEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.doj, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dot != null && inEesAlumniTabObj.dot.length() > 0 ) 
            inEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dot, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.promotion_date != null && inEesAlumniTabObj.promotion_date.length() > 0 ) 
            inEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.promotion_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.student_sts_date != null && inEesAlumniTabObj.student_sts_date.length() > 0 ) 
            inEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.student_sts_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesAlumniTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAlumniTabObj.org_id+"', ";
      if ( inEesAlumniTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = "+"'"+inEesAlumniTabObj.alumni_id+"', ";
      if ( inEesAlumniTabObj.alumni_cre_date != null  )         lSqlStmt = lSqlStmt + "alumni_cre_date = "+"'"+inEesAlumniTabObj.alumni_cre_date+"', ";
      if ( inEesAlumniTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = "+"'"+inEesAlumniTabObj.barcode+"', ";
      if ( inEesAlumniTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = "+"'"+inEesAlumniTabObj.user_id+"', ";
      if ( inEesAlumniTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inEesAlumniTabObj.pswd_0+"', ";
      if ( inEesAlumniTabObj.student_name != null  )         lSqlStmt = lSqlStmt + "student_name = "+"'"+inEesAlumniTabObj.student_name+"', ";
      if ( inEesAlumniTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAlumniTabObj.father_name+"', ";
      if ( inEesAlumniTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAlumniTabObj.mother_name+"', ";
      if ( inEesAlumniTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAlumniTabObj.student_ctg+"', ";
      if ( inEesAlumniTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAlumniTabObj.gender_flag+"', ";
      if ( inEesAlumniTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAlumniTabObj.dob+"', ";
      if ( inEesAlumniTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = "+"'"+inEesAlumniTabObj.doj+"', ";
      if ( inEesAlumniTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = "+"'"+inEesAlumniTabObj.dot+"', ";
      if ( inEesAlumniTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inEesAlumniTabObj.address_1+"', ";
      if ( inEesAlumniTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inEesAlumniTabObj.address_2+"', ";
      if ( inEesAlumniTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAlumniTabObj.class_id+"', ";
      if ( inEesAlumniTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAlumniTabObj.class_num+"', ";
      if ( inEesAlumniTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAlumniTabObj.class_std+"', ";
      if ( inEesAlumniTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAlumniTabObj.class_section+"', ";
      if ( inEesAlumniTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAlumniTabObj.course_id+"', ";
      if ( inEesAlumniTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAlumniTabObj.course_term+"', ";
      if ( inEesAlumniTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAlumniTabObj.course_stream+"', ";
      if ( inEesAlumniTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAlumniTabObj.roll_num+"', ";
      if ( inEesAlumniTabObj.enrollment_num != null  )         lSqlStmt = lSqlStmt + "enrollment_num = "+"'"+inEesAlumniTabObj.enrollment_num+"', ";
      if ( inEesAlumniTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = "+"'"+inEesAlumniTabObj.shift_code+"', ";
      if ( inEesAlumniTabObj.prev_org_id != null  )         lSqlStmt = lSqlStmt + "prev_org_id = "+"'"+inEesAlumniTabObj.prev_org_id+"', ";
      if ( inEesAlumniTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAlumniTabObj.prev_class_id+"', ";
      if ( inEesAlumniTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAlumniTabObj.prev_class_num+"', ";
      if ( inEesAlumniTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAlumniTabObj.prev_class_std+"', ";
      if ( inEesAlumniTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAlumniTabObj.prev_class_section+"', ";
      if ( inEesAlumniTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAlumniTabObj.prev_course_id+"', ";
      if ( inEesAlumniTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAlumniTabObj.prev_course_term+"', ";
      if ( inEesAlumniTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAlumniTabObj.prev_course_stream+"', ";
      if ( inEesAlumniTabObj.prev_shift_code != null  )         lSqlStmt = lSqlStmt + "prev_shift_code = "+"'"+inEesAlumniTabObj.prev_shift_code+"', ";
      if ( inEesAlumniTabObj.promotion_sts != null  )         lSqlStmt = lSqlStmt + "promotion_sts = "+"'"+inEesAlumniTabObj.promotion_sts+"', ";
      if ( inEesAlumniTabObj.promotion_date != null  )         lSqlStmt = lSqlStmt + "promotion_date = "+"'"+inEesAlumniTabObj.promotion_date+"', ";
      if ( inEesAlumniTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = "+"'"+inEesAlumniTabObj.phone+"', ";
      if ( inEesAlumniTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inEesAlumniTabObj.email_id+"', ";
      if ( inEesAlumniTabObj.student_sts != null  )         lSqlStmt = lSqlStmt + "student_sts = "+"'"+inEesAlumniTabObj.student_sts+"', ";
      if ( inEesAlumniTabObj.student_sts_date != null  )         lSqlStmt = lSqlStmt + "student_sts_date = "+"'"+inEesAlumniTabObj.student_sts_date+"', ";
      if ( inEesAlumniTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inEesAlumniTabObj.country+"', ";
      if ( inEesAlumniTabObj.photo_file_name != null  )         lSqlStmt = lSqlStmt + "photo_file_name = "+"'"+inEesAlumniTabObj.photo_file_name+"', ";
      if ( inEesAlumniTabObj.batch_number != null  )         lSqlStmt = lSqlStmt + "batch_number = "+"'"+inEesAlumniTabObj.batch_number+"', ";
             lSqlStmt = lSqlStmt + "num_of_yr_in_class = "+inEesAlumniTabObj.num_of_yr_in_class+", ";
             lSqlStmt = lSqlStmt + "passing_year = "+inEesAlumniTabObj.passing_year+", ";
             lSqlStmt = lSqlStmt + "stud_seq_num = "+inEesAlumniTabObj.stud_seq_num+", ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniRecByPkey
               ( EesAlumniPkeyObj inEesAlumniPkeyObj
               , EesAlumniTabObj  inEesAlumniTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAlumniRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAlumniTabObj.alumni_cre_date != null && inEesAlumniTabObj.alumni_cre_date.length() > 0 ) 
            inEesAlumniTabObj.alumni_cre_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.alumni_cre_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dob != null && inEesAlumniTabObj.dob.length() > 0 ) 
            inEesAlumniTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.doj != null && inEesAlumniTabObj.doj.length() > 0 ) 
            inEesAlumniTabObj.doj  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.doj, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.dot != null && inEesAlumniTabObj.dot.length() > 0 ) 
            inEesAlumniTabObj.dot  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.dot, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.promotion_date != null && inEesAlumniTabObj.promotion_date.length() > 0 ) 
            inEesAlumniTabObj.promotion_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.promotion_date, lDateTimeSrcFmt);

          if ( inEesAlumniTabObj.student_sts_date != null && inEesAlumniTabObj.student_sts_date.length() > 0 ) 
            inEesAlumniTabObj.student_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAlumniTabObj.student_sts_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesAlumniTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesAlumniTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = ? , ";
        if ( inEesAlumniTabObj.alumni_cre_date != null  )         lSqlStmt = lSqlStmt + "alumni_cre_date = ? , ";
        if ( inEesAlumniTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = ? , ";
        if ( inEesAlumniTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = ? , ";
        if ( inEesAlumniTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = ? , ";
        if ( inEesAlumniTabObj.student_name != null  )         lSqlStmt = lSqlStmt + "student_name = ? , ";
        if ( inEesAlumniTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = ? , ";
        if ( inEesAlumniTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = ? , ";
        if ( inEesAlumniTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = ? , ";
        if ( inEesAlumniTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = ? , ";
        if ( inEesAlumniTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = ? , ";
        if ( inEesAlumniTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = ? , ";
        if ( inEesAlumniTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = ? , ";
        if ( inEesAlumniTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = ? , ";
        if ( inEesAlumniTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = ? , ";
        if ( inEesAlumniTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = ? , ";
        if ( inEesAlumniTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = ? , ";
        if ( inEesAlumniTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = ? , ";
        if ( inEesAlumniTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = ? , ";
        if ( inEesAlumniTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = ? , ";
        if ( inEesAlumniTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = ? , ";
        if ( inEesAlumniTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = ? , ";
        if ( inEesAlumniTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = ? , ";
        if ( inEesAlumniTabObj.enrollment_num != null  )         lSqlStmt = lSqlStmt + "enrollment_num = ? , ";
        if ( inEesAlumniTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = ? , ";
        if ( inEesAlumniTabObj.prev_org_id != null  )         lSqlStmt = lSqlStmt + "prev_org_id = ? , ";
        if ( inEesAlumniTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = ? , ";
        if ( inEesAlumniTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = ? , ";
        if ( inEesAlumniTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = ? , ";
        if ( inEesAlumniTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = ? , ";
        if ( inEesAlumniTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = ? , ";
        if ( inEesAlumniTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = ? , ";
        if ( inEesAlumniTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = ? , ";
        if ( inEesAlumniTabObj.prev_shift_code != null  )         lSqlStmt = lSqlStmt + "prev_shift_code = ? , ";
        if ( inEesAlumniTabObj.promotion_sts != null  )         lSqlStmt = lSqlStmt + "promotion_sts = ? , ";
        if ( inEesAlumniTabObj.promotion_date != null  )         lSqlStmt = lSqlStmt + "promotion_date = ? , ";
        if ( inEesAlumniTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = ? , ";
        if ( inEesAlumniTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = ? , ";
        if ( inEesAlumniTabObj.student_sts != null  )         lSqlStmt = lSqlStmt + "student_sts = ? , ";
        if ( inEesAlumniTabObj.student_sts_date != null  )         lSqlStmt = lSqlStmt + "student_sts_date = ? , ";
        if ( inEesAlumniTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = ? , ";
        if ( inEesAlumniTabObj.photo_file_name != null  )         lSqlStmt = lSqlStmt + "photo_file_name = ? , ";
        if ( inEesAlumniTabObj.batch_number != null  )         lSqlStmt = lSqlStmt + "batch_number = ? , ";
               lSqlStmt = lSqlStmt + "num_of_yr_in_class = ? , ";
               lSqlStmt = lSqlStmt + "passing_year = ? , ";
               lSqlStmt = lSqlStmt + "stud_seq_num = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesAlumniTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAlumniTabObj.org_id+"', ";
        if ( inEesAlumniTabObj.alumni_id != null  )         lSqlStmt = lSqlStmt + "alumni_id = "+"'"+inEesAlumniTabObj.alumni_id+"', ";
        if ( inEesAlumniTabObj.alumni_cre_date != null  )         lSqlStmt = lSqlStmt + "alumni_cre_date = "+"'"+inEesAlumniTabObj.alumni_cre_date+"', ";
        if ( inEesAlumniTabObj.barcode != null  )         lSqlStmt = lSqlStmt + "barcode = "+"'"+inEesAlumniTabObj.barcode+"', ";
        if ( inEesAlumniTabObj.user_id != null  )         lSqlStmt = lSqlStmt + "user_id = "+"'"+inEesAlumniTabObj.user_id+"', ";
        if ( inEesAlumniTabObj.pswd_0 != null  )         lSqlStmt = lSqlStmt + "pswd_0 = "+"'"+inEesAlumniTabObj.pswd_0+"', ";
        if ( inEesAlumniTabObj.student_name != null  )         lSqlStmt = lSqlStmt + "student_name = "+"'"+inEesAlumniTabObj.student_name+"', ";
        if ( inEesAlumniTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAlumniTabObj.father_name+"', ";
        if ( inEesAlumniTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAlumniTabObj.mother_name+"', ";
        if ( inEesAlumniTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAlumniTabObj.student_ctg+"', ";
        if ( inEesAlumniTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAlumniTabObj.gender_flag+"', ";
        if ( inEesAlumniTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAlumniTabObj.dob+"', ";
        if ( inEesAlumniTabObj.doj != null  )         lSqlStmt = lSqlStmt + "doj = "+"'"+inEesAlumniTabObj.doj+"', ";
        if ( inEesAlumniTabObj.dot != null  )         lSqlStmt = lSqlStmt + "dot = "+"'"+inEesAlumniTabObj.dot+"', ";
        if ( inEesAlumniTabObj.address_1 != null  )         lSqlStmt = lSqlStmt + "address_1 = "+"'"+inEesAlumniTabObj.address_1+"', ";
        if ( inEesAlumniTabObj.address_2 != null  )         lSqlStmt = lSqlStmt + "address_2 = "+"'"+inEesAlumniTabObj.address_2+"', ";
        if ( inEesAlumniTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAlumniTabObj.class_id+"', ";
        if ( inEesAlumniTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAlumniTabObj.class_num+"', ";
        if ( inEesAlumniTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAlumniTabObj.class_std+"', ";
        if ( inEesAlumniTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAlumniTabObj.class_section+"', ";
        if ( inEesAlumniTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAlumniTabObj.course_id+"', ";
        if ( inEesAlumniTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAlumniTabObj.course_term+"', ";
        if ( inEesAlumniTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAlumniTabObj.course_stream+"', ";
        if ( inEesAlumniTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAlumniTabObj.roll_num+"', ";
        if ( inEesAlumniTabObj.enrollment_num != null  )         lSqlStmt = lSqlStmt + "enrollment_num = "+"'"+inEesAlumniTabObj.enrollment_num+"', ";
        if ( inEesAlumniTabObj.shift_code != null  )         lSqlStmt = lSqlStmt + "shift_code = "+"'"+inEesAlumniTabObj.shift_code+"', ";
        if ( inEesAlumniTabObj.prev_org_id != null  )         lSqlStmt = lSqlStmt + "prev_org_id = "+"'"+inEesAlumniTabObj.prev_org_id+"', ";
        if ( inEesAlumniTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAlumniTabObj.prev_class_id+"', ";
        if ( inEesAlumniTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAlumniTabObj.prev_class_num+"', ";
        if ( inEesAlumniTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAlumniTabObj.prev_class_std+"', ";
        if ( inEesAlumniTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAlumniTabObj.prev_class_section+"', ";
        if ( inEesAlumniTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAlumniTabObj.prev_course_id+"', ";
        if ( inEesAlumniTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAlumniTabObj.prev_course_term+"', ";
        if ( inEesAlumniTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAlumniTabObj.prev_course_stream+"', ";
        if ( inEesAlumniTabObj.prev_shift_code != null  )         lSqlStmt = lSqlStmt + "prev_shift_code = "+"'"+inEesAlumniTabObj.prev_shift_code+"', ";
        if ( inEesAlumniTabObj.promotion_sts != null  )         lSqlStmt = lSqlStmt + "promotion_sts = "+"'"+inEesAlumniTabObj.promotion_sts+"', ";
        if ( inEesAlumniTabObj.promotion_date != null  )         lSqlStmt = lSqlStmt + "promotion_date = "+"'"+inEesAlumniTabObj.promotion_date+"', ";
        if ( inEesAlumniTabObj.phone != null  )         lSqlStmt = lSqlStmt + "phone = "+"'"+inEesAlumniTabObj.phone+"', ";
        if ( inEesAlumniTabObj.email_id != null  )         lSqlStmt = lSqlStmt + "email_id = "+"'"+inEesAlumniTabObj.email_id+"', ";
        if ( inEesAlumniTabObj.student_sts != null  )         lSqlStmt = lSqlStmt + "student_sts = "+"'"+inEesAlumniTabObj.student_sts+"', ";
        if ( inEesAlumniTabObj.student_sts_date != null  )         lSqlStmt = lSqlStmt + "student_sts_date = "+"'"+inEesAlumniTabObj.student_sts_date+"', ";
        if ( inEesAlumniTabObj.country != null  )         lSqlStmt = lSqlStmt + "country = "+"'"+inEesAlumniTabObj.country+"', ";
        if ( inEesAlumniTabObj.photo_file_name != null  )         lSqlStmt = lSqlStmt + "photo_file_name = "+"'"+inEesAlumniTabObj.photo_file_name+"', ";
        if ( inEesAlumniTabObj.batch_number != null  )         lSqlStmt = lSqlStmt + "batch_number = "+"'"+inEesAlumniTabObj.batch_number+"', ";
               lSqlStmt = lSqlStmt + "num_of_yr_in_class = "+inEesAlumniTabObj.num_of_yr_in_class+", ";
               lSqlStmt = lSqlStmt + "passing_year = "+inEesAlumniTabObj.passing_year+", ";
               lSqlStmt = lSqlStmt + "stud_seq_num = "+inEesAlumniTabObj.stud_seq_num+", ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAlumniPkeyObj.org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniPkeyObj.alumni_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesAlumniTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.org_id); } 
         if ( inEesAlumniTabObj.alumni_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.alumni_id); } 
         if ( inEesAlumniTabObj.alumni_cre_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.alumni_cre_date); } 
         if ( inEesAlumniTabObj.barcode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.barcode); } 
         if ( inEesAlumniTabObj.user_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.user_id); } 
         if ( inEesAlumniTabObj.pswd_0 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.pswd_0); } 
         if ( inEesAlumniTabObj.student_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.student_name); } 
         if ( inEesAlumniTabObj.father_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.father_name); } 
         if ( inEesAlumniTabObj.mother_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.mother_name); } 
         if ( inEesAlumniTabObj.student_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.student_ctg); } 
         if ( inEesAlumniTabObj.gender_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.gender_flag); } 
         if ( inEesAlumniTabObj.dob != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.dob); } 
         if ( inEesAlumniTabObj.doj != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.doj); } 
         if ( inEesAlumniTabObj.dot != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.dot); } 
         if ( inEesAlumniTabObj.address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.address_1); } 
         if ( inEesAlumniTabObj.address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.address_2); } 
         if ( inEesAlumniTabObj.class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.class_id); } 
         if ( inEesAlumniTabObj.class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.class_num); } 
         if ( inEesAlumniTabObj.class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.class_std); } 
         if ( inEesAlumniTabObj.class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.class_section); } 
         if ( inEesAlumniTabObj.course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.course_id); } 
         if ( inEesAlumniTabObj.course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.course_term); } 
         if ( inEesAlumniTabObj.course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.course_stream); } 
         if ( inEesAlumniTabObj.roll_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.roll_num); } 
         if ( inEesAlumniTabObj.enrollment_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.enrollment_num); } 
         if ( inEesAlumniTabObj.shift_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.shift_code); } 
         if ( inEesAlumniTabObj.prev_org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_org_id); } 
         if ( inEesAlumniTabObj.prev_class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_class_id); } 
         if ( inEesAlumniTabObj.prev_class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_class_num); } 
         if ( inEesAlumniTabObj.prev_class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_class_std); } 
         if ( inEesAlumniTabObj.prev_class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_class_section); } 
         if ( inEesAlumniTabObj.prev_course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_course_id); } 
         if ( inEesAlumniTabObj.prev_course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_course_term); } 
         if ( inEesAlumniTabObj.prev_course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_course_stream); } 
         if ( inEesAlumniTabObj.prev_shift_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.prev_shift_code); } 
         if ( inEesAlumniTabObj.promotion_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.promotion_sts); } 
         if ( inEesAlumniTabObj.promotion_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.promotion_date); } 
         if ( inEesAlumniTabObj.phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.phone); } 
         if ( inEesAlumniTabObj.email_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.email_id); } 
         if ( inEesAlumniTabObj.student_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.student_sts); } 
         if ( inEesAlumniTabObj.student_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.student_sts_date); } 
         if ( inEesAlumniTabObj.country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.country); } 
         if ( inEesAlumniTabObj.photo_file_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.photo_file_name); } 
         if ( inEesAlumniTabObj.batch_number != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAlumniTabObj.batch_number); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(45, inEesAlumniTabObj.num_of_yr_in_class);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(46, inEesAlumniTabObj.passing_year);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setInt(47, inEesAlumniTabObj.stud_seq_num);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesAlumniRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_ALUMNI "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniRecByPkeyWithSet
               ( EesAlumniPkeyObj inEesAlumniPkeyObj
               , String  inEesAlumniSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAlumniSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAlumniPkeyObj.org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniPkeyObj.alumni_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniRecByRowidWithSet
               ( String inRowId
               , String  inEesAlumniSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAlumniSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAlumniRecByWhereWithSet
               ( String inEesAlumniWhereText
               , String  inEesAlumniSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAlumniRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAlumniRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ALUMNI ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesAlumniSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniRecByPkey
               ( EesAlumniPkeyObj  inEesAlumniPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesAlumniRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_ALUMNI " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAlumniPkeyObj.org_id+"' and "+
                              "alumni_id = "+"'"+inEesAlumniPkeyObj.alumni_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAlumniByWhere
               ( String inEesAlumniWhereText
               )
  {
    int lUpdateCount;
    sop("delEesAlumniByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesAlumniByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAlumniWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAlumniWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_ALUMNI "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
