CREATE TABLE EES_CONTRACT_EXT
(
  org_id                                                                                              VARCHAR(10),
  contract_id                                                                                         VARCHAR(20),
  contract_num                                                                                        VARCHAR(20),
  tender_num                                                                                          VARCHAR(20),
  vendor_id                                                                                           VARCHAR(10),
  tender_date                                                                                         VARCHAR(8),
  effective_date                                                                                      VARCHAR(8),
  expiry_date                                                                                         VARCHAR(8),
  poc                                                                                                 VARCHAR(100),
  remark                                                                                              VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       CONTRACT_ID                                                                                         CHAR(20),
       CONTRACT_NUM                                                                                        CHAR(20),
       TENDER_NUM                                                                                          CHAR(20),
       VENDOR_ID                                                                                           CHAR(10),
       TENDER_DATE                                                                                         CHAR(8),
       EFFECTIVE_DATE                                                                                      CHAR(8),
       EXPIRY_DATE                                                                                         CHAR(8),
       POC                                                                                                 CHAR(100),
       REMARK                                                                                              CHAR(100)
    )
  )
  LOCATION ('ees_contract_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
