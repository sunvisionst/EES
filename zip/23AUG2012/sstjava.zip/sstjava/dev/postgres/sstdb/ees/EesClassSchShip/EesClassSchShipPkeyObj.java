package sstdb.ees.EesClassSchShip;


public class EesClassSchShipPkeyObj
{
  public String                                 org_id;
  public String                                 scholorship_id;
  public String                                 class_id;
}