CREATE TABLE EES_CONTRACT
(
  ORG_ID                                                                                              VARCHAR(10),
  CONTRACT_ID                                                                                         VARCHAR(20),
  CONTRACT_NUM                                                                                        VARCHAR(20),
  TENDER_NUM                                                                                          VARCHAR(20),
  VENDOR_ID                                                                                           VARCHAR(10),
  TENDER_DATE                                                                                         VARCHAR(8),
  EFFECTIVE_DATE                                                                                      VARCHAR(8),
  EXPIRY_DATE                                                                                         VARCHAR(8),
  POC                                                                                                 VARCHAR(100),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
