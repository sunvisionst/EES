function EesAppcAcademicRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("applicant_id").value  = document.getElementById("applicant_id"+"_r"+inRecNum).value;
    document.getElementById("applicant_id").readOnly = true;
    document.getElementById("seq_num").value  = document.getElementById("seq_num"+"_r"+inRecNum).value;
    document.getElementById("seq_num").readOnly = true;
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value;
    document.getElementById("full_part_time").value  = document.getElementById("full_part_time"+"_r"+inRecNum).value;
    document.getElementById("university_board_name").value  = document.getElementById("university_board_name"+"_r"+inRecNum).value;
    document.getElementById("college_school_name").value  = document.getElementById("college_school_name"+"_r"+inRecNum).value;
    document.getElementById("state").value  = document.getElementById("state"+"_r"+inRecNum).value;
    document.getElementById("country").value  = document.getElementById("country"+"_r"+inRecNum).value;
    document.getElementById("unv_rn").value  = document.getElementById("unv_rn"+"_r"+inRecNum).value;
    document.getElementById("subject_list").value  = document.getElementById("subject_list"+"_r"+inRecNum).value;
    document.getElementById("year_of_passing").value  = document.getElementById("year_of_passing"+"_r"+inRecNum).value;
    document.getElementById("percent_grade").value  = document.getElementById("percent_grade"+"_r"+inRecNum).value;
    document.getElementById("marks_in_percent").value  = document.getElementById("marks_in_percent"+"_r"+inRecNum).value;
    document.getElementById("grade").value  = document.getElementById("grade"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_req").value  = document.getElementById("adm_req_id_req"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_list").value  = document.getElementById("adm_req_id_list"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("applicant_id").value = '';
    document.getElementById("applicant_id").readOnly = false;
    document.getElementById("seq_num").value = '';
    document.getElementById("seq_num").readOnly = false;
    document.getElementById("class_num").value = '';
    document.getElementById("class_std").value = '';
    document.getElementById("course_id").value = '';
    document.getElementById("course_term").value = '';
    document.getElementById("course_stream").value = '';
    document.getElementById("full_part_time").value = '';
    document.getElementById("university_board_name").value = '';
    document.getElementById("college_school_name").value = '';
    document.getElementById("state").value = '';
    document.getElementById("country").value = '';
    document.getElementById("unv_rn").value = '';
    document.getElementById("subject_list").value = '';
    document.getElementById("year_of_passing").value = '';
    document.getElementById("percent_grade").value = '';
    document.getElementById("marks_in_percent").value = '';
    document.getElementById("grade").value = '';
    document.getElementById("adm_req_id_req").value = '';
    document.getElementById("adm_req_id_list").value = '';
  }
}
