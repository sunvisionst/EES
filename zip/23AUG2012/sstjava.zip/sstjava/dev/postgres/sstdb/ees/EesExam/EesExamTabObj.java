package sstdb.ees.EesExam;


public class EesExamTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 exam_id;
  public String                                 exam_term;
  public String                                 exam_type;
  public short                                 year;
  public byte                                  month;
  public String                                 academic_session;
  public String                                 exam_start_date;
  public String                                 exam_end_date;
  public String                                 exam_status;
  public String                                 exam_status_date;
  public String                                 exam_sch_status;
  public String                                 sitting_plan_status;
  public String                                 seat_alloc_status;
  public String                                 exam_attn_status;
  public String                                 mark_entry_status;





  public short                                  org_id_ind;
  public short                                  exam_id_ind;
  public short                                  exam_term_ind;
  public short                                  exam_type_ind;
  public short                                  year_ind;
  public short                                  month_ind;
  public short                                  academic_session_ind;
  public short                                  exam_start_date_ind;
  public short                                  exam_end_date_ind;
  public short                                  exam_status_ind;
  public short                                  exam_status_date_ind;
  public short                                  exam_sch_status_ind;
  public short                                  sitting_plan_status_ind;
  public short                                  seat_alloc_status_ind;
  public short                                  exam_attn_status_ind;
  public short                                  mark_entry_status_ind;


  public EesExamTabObj(){}


  public EesExamTabObj
  (
    String org_id,
    String exam_id,
    String exam_term,
    String exam_type,
    short year,
    byte month,
    String academic_session,
    String exam_start_date,
    String exam_end_date,
    String exam_status,
    String exam_status_date,
    String exam_sch_status,
    String sitting_plan_status,
    String seat_alloc_status,
    String exam_attn_status,
    String mark_entry_status
  )
  {
     this.org_id = org_id;
     this.exam_id = exam_id;
     this.exam_term = exam_term;
     this.exam_type = exam_type;
     this.year = year;
     this.month = month;
     this.academic_session = academic_session;
     this.exam_start_date = exam_start_date;
     this.exam_end_date = exam_end_date;
     this.exam_status = exam_status;
     this.exam_status_date = exam_status_date;
     this.exam_sch_status = exam_sch_status;
     this.sitting_plan_status = sitting_plan_status;
     this.seat_alloc_status = seat_alloc_status;
     this.exam_attn_status = exam_attn_status;
     this.mark_entry_status = mark_entry_status;
  }

  public String getorg_id()                           { return org_id; }
  public String getexam_id()                          { return exam_id; }
  public String getexam_term()                         { return exam_term; }
  public String getexam_type()                         { return exam_type; }
  public short getyear()                            { return year; }
  public byte getmonth()                            { return month; }
  public String getacademic_session()                      { return academic_session; }
  public String getexam_start_date()                      { return exam_start_date; }
  public String getexam_end_date()                       { return exam_end_date; }
  public String getexam_status()                        { return exam_status; }
  public String getexam_status_date()                      { return exam_status_date; }
  public String getexam_sch_status()                      { return exam_sch_status; }
  public String getsitting_plan_status()                    { return sitting_plan_status; }
  public String getseat_alloc_status()                     { return seat_alloc_status; }
  public String getexam_attn_status()                      { return exam_attn_status; }
  public String getmark_entry_status()                     { return mark_entry_status; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setexam_id(String exam_id )                   { this.exam_id = exam_id; }
  public void  setexam_term(String exam_term )                 { this.exam_term = exam_term; }
  public void  setexam_type(String exam_type )                 { this.exam_type = exam_type; }
  public void  setyear(short year )                       { this.year = year; }
  public void  setmonth(byte month )                      { this.month = month; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setexam_start_date(String exam_start_date )           { this.exam_start_date = exam_start_date; }
  public void  setexam_end_date(String exam_end_date )             { this.exam_end_date = exam_end_date; }
  public void  setexam_status(String exam_status )               { this.exam_status = exam_status; }
  public void  setexam_status_date(String exam_status_date )          { this.exam_status_date = exam_status_date; }
  public void  setexam_sch_status(String exam_sch_status )           { this.exam_sch_status = exam_sch_status; }
  public void  setsitting_plan_status(String sitting_plan_status )       { this.sitting_plan_status = sitting_plan_status; }
  public void  setseat_alloc_status(String seat_alloc_status )         { this.seat_alloc_status = seat_alloc_status; }
  public void  setexam_attn_status(String exam_attn_status )          { this.exam_attn_status = exam_attn_status; }
  public void  setmark_entry_status(String mark_entry_status )         { this.mark_entry_status = mark_entry_status; }
}