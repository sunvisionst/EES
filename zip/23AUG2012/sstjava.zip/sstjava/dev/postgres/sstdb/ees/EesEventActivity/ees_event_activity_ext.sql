CREATE TABLE EES_EVENT_ACTIVITY_EXT
(
  org_id                                                                                              VARCHAR(10),
  activity_id                                                                                         VARCHAR(10),
  event_act_type                                                                                      VARCHAR(1),
  activity_date                                                                                       VARCHAR(8),
  act_start_time                                                                                      VARCHAR(6),
  act_end_time                                                                                        VARCHAR(6),
  reg_date                                                                                            VARCHAR(8),
  event_id                                                                                            VARCHAR(10),
  activity_desc                                                                                       VARCHAR(100),
  activity_location                                                                                   VARCHAR(100),
  sponsor_flag                                                                                        VARCHAR(1),
  sponsored_by                                                                                        VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACTIVITY_ID                                                                                         CHAR(10),
       EVENT_ACT_TYPE                                                                                      CHAR(1),
       ACTIVITY_DATE                                                                                       CHAR(8),
       ACT_START_TIME                                                                                      CHAR(6),
       ACT_END_TIME                                                                                        CHAR(6),
       REG_DATE                                                                                            CHAR(8),
       EVENT_ID                                                                                            CHAR(10),
       ACTIVITY_DESC                                                                                       CHAR(100),
       ACTIVITY_LOCATION                                                                                   CHAR(100),
       SPONSOR_FLAG                                                                                        CHAR(1),
       SPONSORED_BY                                                                                        CHAR(100)
    )
  )
  LOCATION ('ees_event_activity_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
