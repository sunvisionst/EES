CREATE TABLE EES_AS_CHECKLIST_EXT
(
  org_id                                                                                              VARCHAR(10),
  academic_session                                                                                    VARCHAR(11),
  checklist_id                                                                                        VARCHAR(20),
  description                                                                                         VARCHAR(100),
  checklist_sts                                                                                       VARCHAR(20),
  checklist_sts_date                                                                                  VARCHAR(8),
  apr_sts_date                                                                                        VARCHAR(8),
  apr_remark                                                                                          VARCHAR(100),
  rej_remark                                                                                          VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACADEMIC_SESSION                                                                                    CHAR(11),
       CHECKLIST_ID                                                                                        CHAR(20),
       DESCRIPTION                                                                                         CHAR(100),
       CHECKLIST_STS                                                                                       CHAR(20),
       CHECKLIST_STS_DATE                                                                                  CHAR(8),
       APR_STS_DATE                                                                                        CHAR(8),
       APR_REMARK                                                                                          CHAR(100),
       REJ_REMARK                                                                                          CHAR(100)
    )
  )
  LOCATION ('ees_as_checklist_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
