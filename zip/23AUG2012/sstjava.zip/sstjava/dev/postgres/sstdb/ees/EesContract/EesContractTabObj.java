package sstdb.ees.EesContract;


public class EesContractTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 contract_id;
  public String                                 contract_num;
  public String                                 tender_num;
  public String                                 vendor_id;
  public String                                 tender_date;
  public String                                 effective_date;
  public String                                 expiry_date;
  public String                                 poc;
  public String                                 remark;





  public short                                  org_id_ind;
  public short                                  contract_id_ind;
  public short                                  contract_num_ind;
  public short                                  tender_num_ind;
  public short                                  vendor_id_ind;
  public short                                  tender_date_ind;
  public short                                  effective_date_ind;
  public short                                  expiry_date_ind;
  public short                                  poc_ind;
  public short                                  remark_ind;


  public EesContractTabObj(){}


  public EesContractTabObj
  (
    String org_id,
    String contract_id,
    String contract_num,
    String tender_num,
    String vendor_id,
    String tender_date,
    String effective_date,
    String expiry_date,
    String poc,
    String remark
  )
  {
     this.org_id = org_id;
     this.contract_id = contract_id;
     this.contract_num = contract_num;
     this.tender_num = tender_num;
     this.vendor_id = vendor_id;
     this.tender_date = tender_date;
     this.effective_date = effective_date;
     this.expiry_date = expiry_date;
     this.poc = poc;
     this.remark = remark;
  }

  public String getorg_id()                           { return org_id; }
  public String getcontract_id()                        { return contract_id; }
  public String getcontract_num()                        { return contract_num; }
  public String gettender_num()                         { return tender_num; }
  public String getvendor_id()                         { return vendor_id; }
  public String gettender_date()                        { return tender_date; }
  public String geteffective_date()                       { return effective_date; }
  public String getexpiry_date()                        { return expiry_date; }
  public String getpoc()                            { return poc; }
  public String getremark()                           { return remark; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcontract_id(String contract_id )               { this.contract_id = contract_id; }
  public void  setcontract_num(String contract_num )              { this.contract_num = contract_num; }
  public void  settender_num(String tender_num )                { this.tender_num = tender_num; }
  public void  setvendor_id(String vendor_id )                 { this.vendor_id = vendor_id; }
  public void  settender_date(String tender_date )               { this.tender_date = tender_date; }
  public void  seteffective_date(String effective_date )            { this.effective_date = effective_date; }
  public void  setexpiry_date(String expiry_date )               { this.expiry_date = expiry_date; }
  public void  setpoc(String poc )                       { this.poc = poc; }
  public void  setremark(String remark )                    { this.remark = remark; }
}