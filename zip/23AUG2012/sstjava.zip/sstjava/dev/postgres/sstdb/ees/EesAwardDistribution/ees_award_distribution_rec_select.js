function EesAwardDistributionRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("event_id").value  = document.getElementById("event_id"+"_r"+inRecNum).value;
    document.getElementById("event_id").readOnly = true;
    document.getElementById("awardee_id").value  = document.getElementById("awardee_id"+"_r"+inRecNum).value;
    document.getElementById("awardee_id").readOnly = true;
    document.getElementById("awardee_type").value  = document.getElementById("awardee_type"+"_r"+inRecNum).value;
    document.getElementById("award_id").value  = document.getElementById("award_id"+"_r"+inRecNum).value;
    document.getElementById("distribution_date").value  = document.getElementById("distribution_date"+"_r"+inRecNum).value;
    document.getElementById("distributed_by").value  = document.getElementById("distributed_by"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("event_id").value = '';
    document.getElementById("event_id").readOnly = false;
    document.getElementById("awardee_id").value = '';
    document.getElementById("awardee_id").readOnly = false;
    document.getElementById("awardee_type").value = '';
    document.getElementById("award_id").value = '';
    document.getElementById("distribution_date").value = '';
    document.getElementById("distributed_by").value = '';
  }
}
