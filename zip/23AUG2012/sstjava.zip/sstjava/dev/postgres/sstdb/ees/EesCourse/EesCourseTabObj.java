package sstdb.ees.EesCourse;


public class EesCourseTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 course_id;
  public String                                 description;
  public String                                 dept_id;
  public String                                 course_code;
  public String                                 short_code;
  public String                                 sst_course_id;
  public String                                 duration_type;
  public int                                  course_duration;
  public String                                 class_id_pattern;
  public String                                 remark;
  public String                                 board_university;
  public String                                 stream_ind;
  public int                                  course_strength;
  public int                                  quota_qty;
  public String                                 course_coord;
  public double                                 min_fee_amt;
  public String                                 cc_ptl_user_id;
  public String                                 class_std;





  public short                                  org_id_ind;
  public short                                  course_id_ind;
  public short                                  description_ind;
  public short                                  dept_id_ind;
  public short                                  course_code_ind;
  public short                                  short_code_ind;
  public short                                  sst_course_id_ind;
  public short                                  duration_type_ind;
  public short                                  course_duration_ind;
  public short                                  class_id_pattern_ind;
  public short                                  remark_ind;
  public short                                  board_university_ind;
  public short                                  stream_ind_ind;
  public short                                  course_strength_ind;
  public short                                  quota_qty_ind;
  public short                                  course_coord_ind;
  public short                                  min_fee_amt_ind;
  public short                                  cc_ptl_user_id_ind;
  public short                                  class_std_ind;


  public EesCourseTabObj(){}


  public EesCourseTabObj
  (
    String org_id,
    String course_id,
    String description,
    String dept_id,
    String course_code,
    String short_code,
    String sst_course_id,
    String duration_type,
    int course_duration,
    String class_id_pattern,
    String remark,
    String board_university,
    String stream_ind,
    int course_strength,
    int quota_qty,
    String course_coord,
    double min_fee_amt,
    String cc_ptl_user_id,
    String class_std
  )
  {
     this.org_id = org_id;
     this.course_id = course_id;
     this.description = description;
     this.dept_id = dept_id;
     this.course_code = course_code;
     this.short_code = short_code;
     this.sst_course_id = sst_course_id;
     this.duration_type = duration_type;
     this.course_duration = course_duration;
     this.class_id_pattern = class_id_pattern;
     this.remark = remark;
     this.board_university = board_university;
     this.stream_ind = stream_ind;
     this.course_strength = course_strength;
     this.quota_qty = quota_qty;
     this.course_coord = course_coord;
     this.min_fee_amt = min_fee_amt;
     this.cc_ptl_user_id = cc_ptl_user_id;
     this.class_std = class_std;
  }

  public String getorg_id()                           { return org_id; }
  public String getcourse_id()                         { return course_id; }
  public String getdescription()                        { return description; }
  public String getdept_id()                          { return dept_id; }
  public String getcourse_code()                        { return course_code; }
  public String getshort_code()                         { return short_code; }
  public String getsst_course_id()                       { return sst_course_id; }
  public String getduration_type()                       { return duration_type; }
  public int getcourse_duration()                        { return course_duration; }
  public String getclass_id_pattern()                      { return class_id_pattern; }
  public String getremark()                           { return remark; }
  public String getboard_university()                      { return board_university; }
  public String getstream_ind()                         { return stream_ind; }
  public int getcourse_strength()                        { return course_strength; }
  public int getquota_qty()                           { return quota_qty; }
  public String getcourse_coord()                        { return course_coord; }
  public double getmin_fee_amt()                        { return min_fee_amt; }
  public String getcc_ptl_user_id()                       { return cc_ptl_user_id; }
  public String getclass_std()                         { return class_std; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setdescription(String description )               { this.description = description; }
  public void  setdept_id(String dept_id )                   { this.dept_id = dept_id; }
  public void  setcourse_code(String course_code )               { this.course_code = course_code; }
  public void  setshort_code(String short_code )                { this.short_code = short_code; }
  public void  setsst_course_id(String sst_course_id )             { this.sst_course_id = sst_course_id; }
  public void  setduration_type(String duration_type )             { this.duration_type = duration_type; }
  public void  setcourse_duration(int course_duration )             { this.course_duration = course_duration; }
  public void  setclass_id_pattern(String class_id_pattern )          { this.class_id_pattern = class_id_pattern; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setboard_university(String board_university )          { this.board_university = board_university; }
  public void  setstream_ind(String stream_ind )                { this.stream_ind = stream_ind; }
  public void  setcourse_strength(int course_strength )             { this.course_strength = course_strength; }
  public void  setquota_qty(int quota_qty )                   { this.quota_qty = quota_qty; }
  public void  setcourse_coord(String course_coord )              { this.course_coord = course_coord; }
  public void  setmin_fee_amt(double min_fee_amt )               { this.min_fee_amt = min_fee_amt; }
  public void  setcc_ptl_user_id(String cc_ptl_user_id )            { this.cc_ptl_user_id = cc_ptl_user_id; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
}