package sstdb.ees.EesAlumniProf;


public class EesAlumniProfPkeyObj
{
  public String                                 student_org_id;
  public String                                 alumni_id;
  public int                                  seq_num;
}