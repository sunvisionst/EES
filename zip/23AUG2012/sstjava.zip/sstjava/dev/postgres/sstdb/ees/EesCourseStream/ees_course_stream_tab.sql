CREATE TABLE EES_COURSE_STREAM
(
  ORG_ID                                                                                              VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  DESCRIPTION                                                                                         VARCHAR(100),
  STREAM_STRENGTH                                                                                     NUMERIC(9),
  QUOTA_QTY                                                                                           NUMERIC(9),
  COURSE_CODE                                                                                         VARCHAR(10),
  SHORT_CODE                                                                                          VARCHAR(10),
  SST_STREAM_ID                                                                                       VARCHAR(10),
  COURSE_COORD                                                                                        VARCHAR(20),
  BOARD_UNIVERSITY                                                                                    VARCHAR(100),
  MIN_FEE_AMT                                                                                         NUMERIC(13,2),
  CC_PTL_USER_ID                                                                                      VARCHAR(50),
  CLASS_STD                                                                                           VARCHAR(10)
)
 WITH OIDS;
