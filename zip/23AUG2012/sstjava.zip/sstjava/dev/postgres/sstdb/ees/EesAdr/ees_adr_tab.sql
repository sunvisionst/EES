CREATE TABLE EES_ADR
(
  ORG_ID                                                                                              VARCHAR(10),
  EMPLOYEE_ID                                                                                         VARCHAR(20),
  PERIOD_NUM                                                                                          NUMERIC(2),
  ADR_DATE                                                                                            VARCHAR(8),
  TOPIC_ID                                                                                            VARCHAR(10),
  ADR_START_TIME                                                                                      VARCHAR(6),
  ADR_END_TIME                                                                                        VARCHAR(6),
  LECTURE_NUM                                                                                         VARCHAR(10),
  SUBJECT_CODE                                                                                        VARCHAR(20),
  TOPIC_PERCENT_COVERED                                                                               NUMERIC(5,2),
  CLASS_ID                                                                                            VARCHAR(20),
  CLASS_NUM                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  CLASS_SECTION                                                                                       VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10)
)
 WITH OIDS;
