
var lEesAwardTabObjJSArr = new Array();
<%
{
   if ( lEesAwardTabObjArrCache != null && lEesAwardTabObjArrCache.size() > 0 )
   {
%>
       lEesAwardTabObjJSArr = new Array(<%=lEesAwardTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAwardTabObjArrCache.size(); lRecNum++ )
       {
          EesAwardTabObj lEesAwardTabObj    =    new EesAwardTabObj();
          lEesAwardTabObj = (EesAwardTabObj)lEesAwardTabObjArrCache.get(lRecNum);
%>
          lEesAwardTabObjJSArr[<%=lRecNum%>] = new constructorEesAward
          (
          "<%=lEesAwardTabObj.org_id%>",
          "<%=lEesAwardTabObj.award_id%>",
          "<%=lEesAwardTabObj.award_name%>",
          "<%=lEesAwardTabObj.award_type%>",
          "<%=lEesAwardTabObj.award_desc%>",
          "<%=lEesAwardTabObj.award_start_date%>",
          "<%=lEesAwardTabObj.award_started_by%>"
          );
<%
       }
   }
}
%>


