package sstdb.ees.EesAppcPrevMark;


public class EesAppcPrevMarkTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 applicant_id;
  public float                                 stmm_1;
  public float                                 stmo_1;
  public float                                 spmm_1;
  public float                                 spmo_1;
  public float                                 stmm_2;
  public float                                 stmo_2;
  public float                                 spmm_2;
  public float                                 spmo_2;
  public float                                 stmm_3;
  public float                                 stmo_3;
  public float                                 spmm_3;
  public float                                 spmo_3;
  public float                                 stmm_4;
  public float                                 stmo_4;
  public float                                 spmm_4;
  public float                                 spmo_4;
  public String                                 adm_req_id_req;
  public String                                 adm_req_id_list;





  public short                                  org_id_ind;
  public short                                  applicant_id_ind;
  public short                                  stmm_1_ind;
  public short                                  stmo_1_ind;
  public short                                  spmm_1_ind;
  public short                                  spmo_1_ind;
  public short                                  stmm_2_ind;
  public short                                  stmo_2_ind;
  public short                                  spmm_2_ind;
  public short                                  spmo_2_ind;
  public short                                  stmm_3_ind;
  public short                                  stmo_3_ind;
  public short                                  spmm_3_ind;
  public short                                  spmo_3_ind;
  public short                                  stmm_4_ind;
  public short                                  stmo_4_ind;
  public short                                  spmm_4_ind;
  public short                                  spmo_4_ind;
  public short                                  adm_req_id_req_ind;
  public short                                  adm_req_id_list_ind;


  public EesAppcPrevMarkTabObj(){}


  public EesAppcPrevMarkTabObj
  (
    String org_id,
    String applicant_id,
    float stmm_1,
    float stmo_1,
    float spmm_1,
    float spmo_1,
    float stmm_2,
    float stmo_2,
    float spmm_2,
    float spmo_2,
    float stmm_3,
    float stmo_3,
    float spmm_3,
    float spmo_3,
    float stmm_4,
    float stmo_4,
    float spmm_4,
    float spmo_4,
    String adm_req_id_req,
    String adm_req_id_list
  )
  {
     this.org_id = org_id;
     this.applicant_id = applicant_id;
     this.stmm_1 = stmm_1;
     this.stmo_1 = stmo_1;
     this.spmm_1 = spmm_1;
     this.spmo_1 = spmo_1;
     this.stmm_2 = stmm_2;
     this.stmo_2 = stmo_2;
     this.spmm_2 = spmm_2;
     this.spmo_2 = spmo_2;
     this.stmm_3 = stmm_3;
     this.stmo_3 = stmo_3;
     this.spmm_3 = spmm_3;
     this.spmo_3 = spmo_3;
     this.stmm_4 = stmm_4;
     this.stmo_4 = stmo_4;
     this.spmm_4 = spmm_4;
     this.spmo_4 = spmo_4;
     this.adm_req_id_req = adm_req_id_req;
     this.adm_req_id_list = adm_req_id_list;
  }

  public String getorg_id()                           { return org_id; }
  public String getapplicant_id()                        { return applicant_id; }
  public float getstmm_1()                           { return stmm_1; }
  public float getstmo_1()                           { return stmo_1; }
  public float getspmm_1()                           { return spmm_1; }
  public float getspmo_1()                           { return spmo_1; }
  public float getstmm_2()                           { return stmm_2; }
  public float getstmo_2()                           { return stmo_2; }
  public float getspmm_2()                           { return spmm_2; }
  public float getspmo_2()                           { return spmo_2; }
  public float getstmm_3()                           { return stmm_3; }
  public float getstmo_3()                           { return stmo_3; }
  public float getspmm_3()                           { return spmm_3; }
  public float getspmo_3()                           { return spmo_3; }
  public float getstmm_4()                           { return stmm_4; }
  public float getstmo_4()                           { return stmo_4; }
  public float getspmm_4()                           { return spmm_4; }
  public float getspmo_4()                           { return spmo_4; }
  public String getadm_req_id_req()                       { return adm_req_id_req; }
  public String getadm_req_id_list()                      { return adm_req_id_list; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setapplicant_id(String applicant_id )              { this.applicant_id = applicant_id; }
  public void  setstmm_1(float stmm_1 )                     { this.stmm_1 = stmm_1; }
  public void  setstmo_1(float stmo_1 )                     { this.stmo_1 = stmo_1; }
  public void  setspmm_1(float spmm_1 )                     { this.spmm_1 = spmm_1; }
  public void  setspmo_1(float spmo_1 )                     { this.spmo_1 = spmo_1; }
  public void  setstmm_2(float stmm_2 )                     { this.stmm_2 = stmm_2; }
  public void  setstmo_2(float stmo_2 )                     { this.stmo_2 = stmo_2; }
  public void  setspmm_2(float spmm_2 )                     { this.spmm_2 = spmm_2; }
  public void  setspmo_2(float spmo_2 )                     { this.spmo_2 = spmo_2; }
  public void  setstmm_3(float stmm_3 )                     { this.stmm_3 = stmm_3; }
  public void  setstmo_3(float stmo_3 )                     { this.stmo_3 = stmo_3; }
  public void  setspmm_3(float spmm_3 )                     { this.spmm_3 = spmm_3; }
  public void  setspmo_3(float spmo_3 )                     { this.spmo_3 = spmo_3; }
  public void  setstmm_4(float stmm_4 )                     { this.stmm_4 = stmm_4; }
  public void  setstmo_4(float stmo_4 )                     { this.stmo_4 = stmo_4; }
  public void  setspmm_4(float spmm_4 )                     { this.spmm_4 = spmm_4; }
  public void  setspmo_4(float spmo_4 )                     { this.spmo_4 = spmo_4; }
  public void  setadm_req_id_req(String adm_req_id_req )            { this.adm_req_id_req = adm_req_id_req; }
  public void  setadm_req_id_list(String adm_req_id_list )           { this.adm_req_id_list = adm_req_id_list; }
}