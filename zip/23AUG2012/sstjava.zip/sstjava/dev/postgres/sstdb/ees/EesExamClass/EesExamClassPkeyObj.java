package sstdb.ees.EesExamClass;


public class EesExamClassPkeyObj
{
  public String                                 org_id;
  public String                                 exam_id;
  public String                                 class_id;
}