CREATE TABLE EES_DAILY_TRIP
(
  ORG_ID                                                                                              VARCHAR(10),
  WO_NUM                                                                                              VARCHAR(10),
  WO_DATE                                                                                             VARCHAR(8),
  ROUTE_ID                                                                                            VARCHAR(10),
  TRIP_ID                                                                                             VARCHAR(10),
  TRIP_NUM                                                                                            VARCHAR(5),
  VEHICLE_ID                                                                                          VARCHAR(10),
  DRIVER_ID                                                                                           VARCHAR(10),
  START_TIME                                                                                          VARCHAR(6),
  END_TIME                                                                                            VARCHAR(6),
  OMR                                                                                                 NUMERIC(9),
  CMR                                                                                                 NUMERIC(9),
  REMARK                                                                                              VARCHAR(100)
)
 WITH OIDS;
