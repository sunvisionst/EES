CREATE TABLE EES_APPC_ACADEMIC_EXT
(
  org_id                                                                                              VARCHAR(10),
  applicant_id                                                                                        VARCHAR(25),
  seq_num                                                                                             NUMERIC(9),
  class_num                                                                                           VARCHAR(10),
  class_std                                                                                           VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  course_term                                                                                         VARCHAR(10),
  course_stream                                                                                       VARCHAR(10),
  full_part_time                                                                                      VARCHAR(1),
  university_board_name                                                                               VARCHAR(100),
  college_school_name                                                                                 VARCHAR(100),
  state                                                                                               VARCHAR(50),
  country                                                                                             VARCHAR(10),
  unv_rn                                                                                              VARCHAR(10),
  subject_list                                                                                        VARCHAR(200),
  year_of_passing                                                                                     NUMERIC(4),
  percent_grade                                                                                       VARCHAR(1),
  marks_in_percent                                                                                    NUMERIC(5,2),
  grade                                                                                               VARCHAR(5),
  adm_req_id_req                                                                                      VARCHAR(30),
  adm_req_id_list                                                                                     VARCHAR(30)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       APPLICANT_ID                                                                                        CHAR(25),
       SEQ_NUM                                                                                             CHAR(9),
       CLASS_NUM                                                                                           CHAR(10),
       CLASS_STD                                                                                           CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       COURSE_TERM                                                                                         CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10),
       FULL_PART_TIME                                                                                      CHAR(1),
       UNIVERSITY_BOARD_NAME                                                                               CHAR(100),
       COLLEGE_SCHOOL_NAME                                                                                 CHAR(100),
       STATE                                                                                               CHAR(50),
       COUNTRY                                                                                             CHAR(10),
       UNV_RN                                                                                              CHAR(10),
       SUBJECT_LIST                                                                                        CHAR(200),
       YEAR_OF_PASSING                                                                                     CHAR(4),
       PERCENT_GRADE                                                                                       CHAR(1),
       MARKS_IN_PERCENT                                                                                    CHAR(5),
       GRADE                                                                                               CHAR(5),
       ADM_REQ_ID_REQ                                                                                      CHAR(30),
       ADM_REQ_ID_LIST                                                                                     CHAR(30)
    )
  )
  LOCATION ('ees_appc_academic_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
