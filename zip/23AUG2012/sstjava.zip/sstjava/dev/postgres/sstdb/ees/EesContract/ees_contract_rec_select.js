function EesContractRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("contract_id").value  = document.getElementById("contract_id"+"_r"+inRecNum).value;
    document.getElementById("contract_id").readOnly = true;
    document.getElementById("contract_num").value  = document.getElementById("contract_num"+"_r"+inRecNum).value;
    document.getElementById("tender_num").value  = document.getElementById("tender_num"+"_r"+inRecNum).value;
    document.getElementById("vendor_id").value  = document.getElementById("vendor_id"+"_r"+inRecNum).value;
    document.getElementById("tender_date").value  = document.getElementById("tender_date"+"_r"+inRecNum).value;
    document.getElementById("effective_date").value  = document.getElementById("effective_date"+"_r"+inRecNum).value;
    document.getElementById("expiry_date").value  = document.getElementById("expiry_date"+"_r"+inRecNum).value;
    document.getElementById("poc").value  = document.getElementById("poc"+"_r"+inRecNum).value;
    document.getElementById("remark").value  = document.getElementById("remark"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("contract_id").value = '';
    document.getElementById("contract_id").readOnly = false;
    document.getElementById("contract_num").value = '';
    document.getElementById("tender_num").value = '';
    document.getElementById("vendor_id").value = '';
    document.getElementById("tender_date").value = '';
    document.getElementById("effective_date").value = '';
    document.getElementById("expiry_date").value = '';
    document.getElementById("poc").value = '';
    document.getElementById("remark").value = '';
  }
}
