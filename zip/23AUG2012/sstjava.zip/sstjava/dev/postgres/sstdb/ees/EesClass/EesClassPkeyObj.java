package sstdb.ees.EesClass;


public class EesClassPkeyObj
{
  public String                                 org_id;
  public String                                 class_id;
}