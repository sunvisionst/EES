CREATE TABLE EES_CLASS_SCH_SHIP
(
  ORG_ID                                                                                              VARCHAR(10),
  SCHOLORSHIP_ID                                                                                      VARCHAR(10),
  CLASS_ID                                                                                            VARCHAR(20),
  SCHOLORSHIP_AMT                                                                                     NUMERIC(13,2),
  START_DATE                                                                                          VARCHAR(8),
  END_DATE                                                                                            VARCHAR(8),
  SCHOLORSHIP_STATUS                                                                                  VARCHAR(1)
)
 WITH OIDS;
