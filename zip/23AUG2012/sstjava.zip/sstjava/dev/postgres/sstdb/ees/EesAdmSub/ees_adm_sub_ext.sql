CREATE TABLE EES_ADM_SUB_EXT
(
  org_id                                                                                              VARCHAR(10),
  academic_session                                                                                    VARCHAR(11),
  subject_code                                                                                        VARCHAR(10),
  class_num                                                                                           VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  class_std                                                                                           VARCHAR(10),
  course_term                                                                                         VARCHAR(10),
  course_stream                                                                                       VARCHAR(10),
  max_mark                                                                                            NUMERIC(9),
  min_mark                                                                                            NUMERIC(9),
  description                                                                                         VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       ACADEMIC_SESSION                                                                                    CHAR(11),
       SUBJECT_CODE                                                                                        CHAR(10),
       CLASS_NUM                                                                                           CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       CLASS_STD                                                                                           CHAR(10),
       COURSE_TERM                                                                                         CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10),
       MAX_MARK                                                                                            CHAR(9),
       MIN_MARK                                                                                            CHAR(9),
       DESCRIPTION                                                                                         CHAR(100)
    )
  )
  LOCATION ('ees_adm_sub_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
