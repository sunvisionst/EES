
var lEesEventContactTabObjJSArr = new Array();
<%
{
   if ( lEesEventContactTabObjArrCache != null && lEesEventContactTabObjArrCache.size() > 0 )
   {
%>
       lEesEventContactTabObjJSArr = new Array(<%=lEesEventContactTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesEventContactTabObjArrCache.size(); lRecNum++ )
       {
          EesEventContactTabObj lEesEventContactTabObj    =    new EesEventContactTabObj();
          lEesEventContactTabObj = (EesEventContactTabObj)lEesEventContactTabObjArrCache.get(lRecNum);
%>
          lEesEventContactTabObjJSArr[<%=lRecNum%>] = new constructorEesEventContact
          (
          "<%=lEesEventContactTabObj.org_id%>",
          "<%=lEesEventContactTabObj.activity_id%>",
          "<%=lEesEventContactTabObj.seq_num%>",
          "<%=lEesEventContactTabObj.event_id%>",
          "<%=lEesEventContactTabObj.contact_type%>",
          "<%=lEesEventContactTabObj.poc_type%>",
          "<%=lEesEventContactTabObj.poc_id%>",
          "<%=lEesEventContactTabObj.poc_name%>",
          "<%=lEesEventContactTabObj.phone_list%>",
          "<%=lEesEventContactTabObj.email_list%>",
          "<%=lEesEventContactTabObj.fax_list%>",
          "<%=lEesEventContactTabObj.address_1%>",
          "<%=lEesEventContactTabObj.address_2%>",
          "<%=lEesEventContactTabObj.country%>",
          "<%=lEesEventContactTabObj.state%>",
          "<%=lEesEventContactTabObj.city%>",
          "<%=lEesEventContactTabObj.district%>",
          "<%=lEesEventContactTabObj.zip%>"
          );
<%
       }
   }
}
%>


