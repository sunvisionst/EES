package sstdb.ees.EesExamPaper;


public class EesExamPaperTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 exam_id;
  public String                                 paper_id;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 disp_paper_id;
  public String                                 subject_code;
  public String                                 exam_term;
  public String                                 exam_type;
  public String                                 exam_date;
  public String                                 paper_file_name;
  public String                                 paper_file_path;
  public String                                 paper_file_type;
  public String                                 prepared_by;





  public short                                  org_id_ind;
  public short                                  exam_id_ind;
  public short                                  paper_id_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  disp_paper_id_ind;
  public short                                  subject_code_ind;
  public short                                  exam_term_ind;
  public short                                  exam_type_ind;
  public short                                  exam_date_ind;
  public short                                  paper_file_name_ind;
  public short                                  paper_file_path_ind;
  public short                                  paper_file_type_ind;
  public short                                  prepared_by_ind;


  public EesExamPaperTabObj(){}


  public EesExamPaperTabObj
  (
    String org_id,
    String exam_id,
    String paper_id,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream,
    String disp_paper_id,
    String subject_code,
    String exam_term,
    String exam_type,
    String exam_date,
    String paper_file_name,
    String paper_file_path,
    String paper_file_type,
    String prepared_by
  )
  {
     this.org_id = org_id;
     this.exam_id = exam_id;
     this.paper_id = paper_id;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.disp_paper_id = disp_paper_id;
     this.subject_code = subject_code;
     this.exam_term = exam_term;
     this.exam_type = exam_type;
     this.exam_date = exam_date;
     this.paper_file_name = paper_file_name;
     this.paper_file_path = paper_file_path;
     this.paper_file_type = paper_file_type;
     this.prepared_by = prepared_by;
  }

  public String getorg_id()                           { return org_id; }
  public String getexam_id()                          { return exam_id; }
  public String getpaper_id()                          { return paper_id; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getdisp_paper_id()                       { return disp_paper_id; }
  public String getsubject_code()                        { return subject_code; }
  public String getexam_term()                         { return exam_term; }
  public String getexam_type()                         { return exam_type; }
  public String getexam_date()                         { return exam_date; }
  public String getpaper_file_name()                      { return paper_file_name; }
  public String getpaper_file_path()                      { return paper_file_path; }
  public String getpaper_file_type()                      { return paper_file_type; }
  public String getprepared_by()                        { return prepared_by; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setexam_id(String exam_id )                   { this.exam_id = exam_id; }
  public void  setpaper_id(String paper_id )                  { this.paper_id = paper_id; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setdisp_paper_id(String disp_paper_id )             { this.disp_paper_id = disp_paper_id; }
  public void  setsubject_code(String subject_code )              { this.subject_code = subject_code; }
  public void  setexam_term(String exam_term )                 { this.exam_term = exam_term; }
  public void  setexam_type(String exam_type )                 { this.exam_type = exam_type; }
  public void  setexam_date(String exam_date )                 { this.exam_date = exam_date; }
  public void  setpaper_file_name(String paper_file_name )           { this.paper_file_name = paper_file_name; }
  public void  setpaper_file_path(String paper_file_path )           { this.paper_file_path = paper_file_path; }
  public void  setpaper_file_type(String paper_file_type )           { this.paper_file_type = paper_file_type; }
  public void  setprepared_by(String prepared_by )               { this.prepared_by = prepared_by; }
}