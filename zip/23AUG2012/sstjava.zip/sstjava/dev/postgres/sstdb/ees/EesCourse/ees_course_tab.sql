CREATE TABLE EES_COURSE
(
  ORG_ID                                                                                              VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  DESCRIPTION                                                                                         VARCHAR(60),
  DEPT_ID                                                                                             VARCHAR(10),
  COURSE_CODE                                                                                         VARCHAR(10),
  SHORT_CODE                                                                                          VARCHAR(10),
  SST_COURSE_ID                                                                                       VARCHAR(10),
  DURATION_TYPE                                                                                       VARCHAR(1),
  COURSE_DURATION                                                                                     NUMERIC(9),
  CLASS_ID_PATTERN                                                                                    VARCHAR(100),
  REMARK                                                                                              VARCHAR(100),
  BOARD_UNIVERSITY                                                                                    VARCHAR(100),
  STREAM_IND                                                                                          VARCHAR(1),
  COURSE_STRENGTH                                                                                     NUMERIC(9),
  QUOTA_QTY                                                                                           NUMERIC(9),
  COURSE_COORD                                                                                        VARCHAR(20),
  MIN_FEE_AMT                                                                                         NUMERIC(13,2),
  CC_PTL_USER_ID                                                                                      VARCHAR(50),
  CLASS_STD                                                                                           VARCHAR(10)
)
 WITH OIDS;
