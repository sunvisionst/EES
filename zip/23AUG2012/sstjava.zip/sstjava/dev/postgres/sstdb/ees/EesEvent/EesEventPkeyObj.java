package sstdb.ees.EesEvent;


public class EesEventPkeyObj
{
  public String                                 org_id;
  public String                                 event_id;
}