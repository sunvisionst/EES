CREATE TABLE EES_AS_CHECKLIST
(
  ORG_ID                                                                                              VARCHAR(10),
  ACADEMIC_SESSION                                                                                    VARCHAR(11),
  CHECKLIST_ID                                                                                        VARCHAR(20),
  DESCRIPTION                                                                                         VARCHAR(100),
  CHECKLIST_STS                                                                                       VARCHAR(20),
  CHECKLIST_STS_DATE                                                                                  VARCHAR(8),
  APR_STS_DATE                                                                                        VARCHAR(8),
  APR_REMARK                                                                                          VARCHAR(100),
  REJ_REMARK                                                                                          VARCHAR(100)
)
 WITH OIDS;
