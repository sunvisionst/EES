CREATE TABLE EES_CLASS_EXT
(
  org_id                                                                                              VARCHAR(10),
  class_id                                                                                            VARCHAR(20),
  class_num                                                                                           VARCHAR(10),
  class_std                                                                                           VARCHAR(10),
  class_section                                                                                       VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  course_term                                                                                         VARCHAR(10),
  course_stream                                                                                       VARCHAR(10),
  description                                                                                         VARCHAR(50),
  duration_type                                                                                       VARCHAR(1),
  course_duration                                                                                     NUMERIC(9),
  remark                                                                                              VARCHAR(100),
  upgrade_ind                                                                                         VARCHAR(1),
  run_ind                                                                                             VARCHAR(1),
  room_num                                                                                            VARCHAR(5),
  building_id                                                                                         VARCHAR(10),
  room_share_ind                                                                                      VARCHAR(1),
  class_teacher                                                                                       VARCHAR(20),
  stream_ind                                                                                          VARCHAR(1),
  shift_code                                                                                          VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       CLASS_ID                                                                                            CHAR(20),
       CLASS_NUM                                                                                           CHAR(10),
       CLASS_STD                                                                                           CHAR(10),
       CLASS_SECTION                                                                                       CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       COURSE_TERM                                                                                         CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10),
       DESCRIPTION                                                                                         CHAR(50),
       DURATION_TYPE                                                                                       CHAR(1),
       COURSE_DURATION                                                                                     CHAR(9),
       REMARK                                                                                              CHAR(100),
       UPGRADE_IND                                                                                         CHAR(1),
       RUN_IND                                                                                             CHAR(1),
       ROOM_NUM                                                                                            CHAR(5),
       BUILDING_ID                                                                                         CHAR(10),
       ROOM_SHARE_IND                                                                                      CHAR(1),
       CLASS_TEACHER                                                                                       CHAR(20),
       STREAM_IND                                                                                          CHAR(1),
       SHIFT_CODE                                                                                          CHAR(10)
    )
  )
  LOCATION ('ees_class_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
