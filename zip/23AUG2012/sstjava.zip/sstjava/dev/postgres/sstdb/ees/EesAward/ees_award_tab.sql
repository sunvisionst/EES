CREATE TABLE EES_AWARD
(
  ORG_ID                                                                                              VARCHAR(10),
  AWARD_ID                                                                                            VARCHAR(10),
  AWARD_NAME                                                                                          VARCHAR(20),
  AWARD_TYPE                                                                                          VARCHAR(10),
  AWARD_DESC                                                                                          VARCHAR(50),
  AWARD_START_DATE                                                                                    VARCHAR(8),
  AWARD_STARTED_BY                                                                                    VARCHAR(100)
)
 WITH OIDS;
