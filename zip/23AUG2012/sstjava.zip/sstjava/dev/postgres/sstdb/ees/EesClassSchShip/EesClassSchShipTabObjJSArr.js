
var lEesClassSchShipTabObjJSArr = new Array();
<%
{
   if ( lEesClassSchShipTabObjArrCache != null && lEesClassSchShipTabObjArrCache.size() > 0 )
   {
%>
       lEesClassSchShipTabObjJSArr = new Array(<%=lEesClassSchShipTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesClassSchShipTabObjArrCache.size(); lRecNum++ )
       {
          EesClassSchShipTabObj lEesClassSchShipTabObj    =    new EesClassSchShipTabObj();
          lEesClassSchShipTabObj = (EesClassSchShipTabObj)lEesClassSchShipTabObjArrCache.get(lRecNum);
%>
          lEesClassSchShipTabObjJSArr[<%=lRecNum%>] = new constructorEesClassSchShip
          (
          "<%=lEesClassSchShipTabObj.org_id%>",
          "<%=lEesClassSchShipTabObj.scholorship_id%>",
          "<%=lEesClassSchShipTabObj.class_id%>",
          "<%=lEesClassSchShipTabObj.scholorship_amt%>",
          "<%=lEesClassSchShipTabObj.start_date%>",
          "<%=lEesClassSchShipTabObj.end_date%>",
          "<%=lEesClassSchShipTabObj.scholorship_status%>"
          );
<%
       }
   }
}
%>


