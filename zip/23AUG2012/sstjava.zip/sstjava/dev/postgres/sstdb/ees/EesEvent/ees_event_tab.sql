CREATE TABLE EES_EVENT
(
  ORG_ID                                                                                              VARCHAR(10),
  EVENT_ID                                                                                            VARCHAR(10),
  EVENT_TYPE                                                                                          VARCHAR(10),
  EVENT_DESC                                                                                          VARCHAR(100),
  STATUS                                                                                              VARCHAR(5),
  EVENT_START_DATE                                                                                    VARCHAR(8),
  EVENT_CLOSE_DATE                                                                                    VARCHAR(8),
  PTL_PUBLISH_IND                                                                                     VARCHAR(5),
  PTL_PUBLISH_START_DATE                                                                              VARCHAR(8),
  PTL_PUBLISH_CLOSE_DATE                                                                              VARCHAR(8),
  PTL_USER_ID                                                                                         VARCHAR(50),
  REC_CRE_BY                                                                                          VARCHAR(50),
  REC_CRE_DATE                                                                                        VARCHAR(8),
  REC_CRE_TIME                                                                                        VARCHAR(6),
  REC_UPD_BY                                                                                          VARCHAR(50),
  REC_UPD_DATE                                                                                        VARCHAR(8),
  REC_UPD_TIME                                                                                        VARCHAR(6)
)
 WITH OIDS;
