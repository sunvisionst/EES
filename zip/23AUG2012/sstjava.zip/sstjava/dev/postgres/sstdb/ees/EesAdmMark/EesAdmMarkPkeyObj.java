package sstdb.ees.EesAdmMark;


public class EesAdmMarkPkeyObj
{
  public String                                 org_id;
  public String                                 adm_req_id;
  public String                                 academic_session;
  public String                                 subject_code;
}