CREATE TABLE EES_AWARD_EXT
(
  org_id                                                                                              VARCHAR(10),
  award_id                                                                                            VARCHAR(10),
  award_name                                                                                          VARCHAR(20),
  award_type                                                                                          VARCHAR(10),
  award_desc                                                                                          VARCHAR(50),
  award_start_date                                                                                    VARCHAR(8),
  award_started_by                                                                                    VARCHAR(100)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       AWARD_ID                                                                                            CHAR(10),
       AWARD_NAME                                                                                          CHAR(20),
       AWARD_TYPE                                                                                          CHAR(10),
       AWARD_DESC                                                                                          CHAR(50),
       AWARD_START_DATE                                                                                    CHAR(8),
       AWARD_STARTED_BY                                                                                    CHAR(100)
    )
  )
  LOCATION ('ees_award_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
