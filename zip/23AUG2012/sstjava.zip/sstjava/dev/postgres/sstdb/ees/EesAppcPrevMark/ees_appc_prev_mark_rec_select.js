function EesAppcPrevMarkRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("applicant_id").value  = document.getElementById("applicant_id"+"_r"+inRecNum).value;
    document.getElementById("applicant_id").readOnly = true;
    document.getElementById("stmm_1").value  = document.getElementById("stmm_1"+"_r"+inRecNum).value;
    document.getElementById("stmo_1").value  = document.getElementById("stmo_1"+"_r"+inRecNum).value;
    document.getElementById("spmm_1").value  = document.getElementById("spmm_1"+"_r"+inRecNum).value;
    document.getElementById("spmo_1").value  = document.getElementById("spmo_1"+"_r"+inRecNum).value;
    document.getElementById("stmm_2").value  = document.getElementById("stmm_2"+"_r"+inRecNum).value;
    document.getElementById("stmo_2").value  = document.getElementById("stmo_2"+"_r"+inRecNum).value;
    document.getElementById("spmm_2").value  = document.getElementById("spmm_2"+"_r"+inRecNum).value;
    document.getElementById("spmo_2").value  = document.getElementById("spmo_2"+"_r"+inRecNum).value;
    document.getElementById("stmm_3").value  = document.getElementById("stmm_3"+"_r"+inRecNum).value;
    document.getElementById("stmo_3").value  = document.getElementById("stmo_3"+"_r"+inRecNum).value;
    document.getElementById("spmm_3").value  = document.getElementById("spmm_3"+"_r"+inRecNum).value;
    document.getElementById("spmo_3").value  = document.getElementById("spmo_3"+"_r"+inRecNum).value;
    document.getElementById("stmm_4").value  = document.getElementById("stmm_4"+"_r"+inRecNum).value;
    document.getElementById("stmo_4").value  = document.getElementById("stmo_4"+"_r"+inRecNum).value;
    document.getElementById("spmm_4").value  = document.getElementById("spmm_4"+"_r"+inRecNum).value;
    document.getElementById("spmo_4").value  = document.getElementById("spmo_4"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_req").value  = document.getElementById("adm_req_id_req"+"_r"+inRecNum).value;
    document.getElementById("adm_req_id_list").value  = document.getElementById("adm_req_id_list"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("applicant_id").value = '';
    document.getElementById("applicant_id").readOnly = false;
    document.getElementById("stmm_1").value = '';
    document.getElementById("stmo_1").value = '';
    document.getElementById("spmm_1").value = '';
    document.getElementById("spmo_1").value = '';
    document.getElementById("stmm_2").value = '';
    document.getElementById("stmo_2").value = '';
    document.getElementById("spmm_2").value = '';
    document.getElementById("spmo_2").value = '';
    document.getElementById("stmm_3").value = '';
    document.getElementById("stmo_3").value = '';
    document.getElementById("spmm_3").value = '';
    document.getElementById("spmo_3").value = '';
    document.getElementById("stmm_4").value = '';
    document.getElementById("stmo_4").value = '';
    document.getElementById("spmm_4").value = '';
    document.getElementById("spmo_4").value = '';
    document.getElementById("adm_req_id_req").value = '';
    document.getElementById("adm_req_id_list").value = '';
  }
}
