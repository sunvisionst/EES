package sstdb.ees.EesAsChecklist;


public class EesAsChecklistTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 academic_session;
  public String                                 checklist_id;
  public String                                 description;
  public String                                 checklist_sts;
  public String                                 checklist_sts_date;
  public String                                 apr_sts_date;
  public String                                 apr_remark;
  public String                                 rej_remark;





  public short                                  org_id_ind;
  public short                                  academic_session_ind;
  public short                                  checklist_id_ind;
  public short                                  description_ind;
  public short                                  checklist_sts_ind;
  public short                                  checklist_sts_date_ind;
  public short                                  apr_sts_date_ind;
  public short                                  apr_remark_ind;
  public short                                  rej_remark_ind;


  public EesAsChecklistTabObj(){}


  public EesAsChecklistTabObj
  (
    String org_id,
    String academic_session,
    String checklist_id,
    String description,
    String checklist_sts,
    String checklist_sts_date,
    String apr_sts_date,
    String apr_remark,
    String rej_remark
  )
  {
     this.org_id = org_id;
     this.academic_session = academic_session;
     this.checklist_id = checklist_id;
     this.description = description;
     this.checklist_sts = checklist_sts;
     this.checklist_sts_date = checklist_sts_date;
     this.apr_sts_date = apr_sts_date;
     this.apr_remark = apr_remark;
     this.rej_remark = rej_remark;
  }

  public String getorg_id()                           { return org_id; }
  public String getacademic_session()                      { return academic_session; }
  public String getchecklist_id()                        { return checklist_id; }
  public String getdescription()                        { return description; }
  public String getchecklist_sts()                       { return checklist_sts; }
  public String getchecklist_sts_date()                     { return checklist_sts_date; }
  public String getapr_sts_date()                        { return apr_sts_date; }
  public String getapr_remark()                         { return apr_remark; }
  public String getrej_remark()                         { return rej_remark; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setchecklist_id(String checklist_id )              { this.checklist_id = checklist_id; }
  public void  setdescription(String description )               { this.description = description; }
  public void  setchecklist_sts(String checklist_sts )             { this.checklist_sts = checklist_sts; }
  public void  setchecklist_sts_date(String checklist_sts_date )        { this.checklist_sts_date = checklist_sts_date; }
  public void  setapr_sts_date(String apr_sts_date )              { this.apr_sts_date = apr_sts_date; }
  public void  setapr_remark(String apr_remark )                { this.apr_remark = apr_remark; }
  public void  setrej_remark(String rej_remark )                { this.rej_remark = rej_remark; }
}