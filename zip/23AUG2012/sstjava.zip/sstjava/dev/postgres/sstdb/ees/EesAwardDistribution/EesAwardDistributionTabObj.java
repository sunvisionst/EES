package sstdb.ees.EesAwardDistribution;


public class EesAwardDistributionTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 event_id;
  public String                                 awardee_id;
  public String                                 awardee_type;
  public String                                 award_id;
  public String                                 distribution_date;
  public String                                 distributed_by;





  public short                                  org_id_ind;
  public short                                  event_id_ind;
  public short                                  awardee_id_ind;
  public short                                  awardee_type_ind;
  public short                                  award_id_ind;
  public short                                  distribution_date_ind;
  public short                                  distributed_by_ind;


  public EesAwardDistributionTabObj(){}


  public EesAwardDistributionTabObj
  (
    String org_id,
    String event_id,
    String awardee_id,
    String awardee_type,
    String award_id,
    String distribution_date,
    String distributed_by
  )
  {
     this.org_id = org_id;
     this.event_id = event_id;
     this.awardee_id = awardee_id;
     this.awardee_type = awardee_type;
     this.award_id = award_id;
     this.distribution_date = distribution_date;
     this.distributed_by = distributed_by;
  }

  public String getorg_id()                           { return org_id; }
  public String getevent_id()                          { return event_id; }
  public String getawardee_id()                         { return awardee_id; }
  public String getawardee_type()                        { return awardee_type; }
  public String getaward_id()                          { return award_id; }
  public String getdistribution_date()                     { return distribution_date; }
  public String getdistributed_by()                       { return distributed_by; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setawardee_id(String awardee_id )                { this.awardee_id = awardee_id; }
  public void  setawardee_type(String awardee_type )              { this.awardee_type = awardee_type; }
  public void  setaward_id(String award_id )                  { this.award_id = award_id; }
  public void  setdistribution_date(String distribution_date )         { this.distribution_date = distribution_date; }
  public void  setdistributed_by(String distributed_by )            { this.distributed_by = distributed_by; }
}