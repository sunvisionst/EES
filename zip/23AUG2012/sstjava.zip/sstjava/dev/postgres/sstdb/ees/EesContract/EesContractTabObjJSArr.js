
var lEesContractTabObjJSArr = new Array();
<%
{
   if ( lEesContractTabObjArrCache != null && lEesContractTabObjArrCache.size() > 0 )
   {
%>
       lEesContractTabObjJSArr = new Array(<%=lEesContractTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesContractTabObjArrCache.size(); lRecNum++ )
       {
          EesContractTabObj lEesContractTabObj    =    new EesContractTabObj();
          lEesContractTabObj = (EesContractTabObj)lEesContractTabObjArrCache.get(lRecNum);
%>
          lEesContractTabObjJSArr[<%=lRecNum%>] = new constructorEesContract
          (
          "<%=lEesContractTabObj.org_id%>",
          "<%=lEesContractTabObj.contract_id%>",
          "<%=lEesContractTabObj.contract_num%>",
          "<%=lEesContractTabObj.tender_num%>",
          "<%=lEesContractTabObj.vendor_id%>",
          "<%=lEesContractTabObj.tender_date%>",
          "<%=lEesContractTabObj.effective_date%>",
          "<%=lEesContractTabObj.expiry_date%>",
          "<%=lEesContractTabObj.poc%>",
          "<%=lEesContractTabObj.remark%>"
          );
<%
       }
   }
}
%>


