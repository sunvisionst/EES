package sstdb.ees.EesExam;

import sstdb.ees.EesExam.EesExamTabObj;
import sstdb.ees.EesExam.EesExamPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesExamMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesExamMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesExamMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesExamTabObj
               ( 
                 EesExamTabObj  outEesExamTabObj
               )
  {
  
     outEesExamTabObj.org_id = ""; 
     outEesExamTabObj.exam_id = ""; 
     outEesExamTabObj.exam_term = ""; 
     outEesExamTabObj.exam_type = ""; 
     outEesExamTabObj.year = (int)0; 
     outEesExamTabObj.month = (int)0; 
     outEesExamTabObj.academic_session = ""; 
     outEesExamTabObj.exam_start_date = ""; 
     outEesExamTabObj.exam_end_date = ""; 
     outEesExamTabObj.exam_status = ""; 
     outEesExamTabObj.exam_status_date = ""; 
     outEesExamTabObj.exam_sch_status = ""; 
     outEesExamTabObj.sitting_plan_status = ""; 
     outEesExamTabObj.seat_alloc_status = ""; 
     outEesExamTabObj.exam_attn_status = ""; 
     outEesExamTabObj.mark_entry_status = ""; 
  }





  public void guiDateConvEesExamTabObj
               ( 
                 EesExamTabObj  inEesExamTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesExamTabObj.exam_start_date != null && inEesExamTabObj.exam_start_date.length() > 0 ) 
            inEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesExamTabObj.exam_start_date, lDateTimeTrgFmt);

          if ( inEesExamTabObj.exam_end_date != null && inEesExamTabObj.exam_end_date.length() > 0 ) 
            inEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesExamTabObj.exam_end_date, lDateTimeTrgFmt);

          if ( inEesExamTabObj.exam_status_date != null && inEesExamTabObj.exam_status_date.length() > 0 ) 
            inEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesExamByTabObj
               ( 
                 EesExamTabObj  inEesExamTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesExamTabObjArrCtx  = new ArrayList(); 
    lEesExamTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesExamTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesExamTabObjArrCtx.add(inEesExamTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesExamTabObjArrCtx.size();  lRecNum++ )
      {
        EesExamTabObj lEesExamTabObj = new EesExamTabObj();
        lEesExamTabObj = (EesExamTabObj)lEesExamTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesExamTabObj.org_id.equals(lEesExamTabObj.org_id) &&
              lEesExamTabObj.exam_id.equals(lEesExamTabObj.exam_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesExamTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesExamTabObjArrCtx.set(lRecNum, inEesExamTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesExamTabObjArrCtx",lEesExamTabObjArrCtx);
  }





  public void sortEesExamTabObjArr
               ( 
                 ArrayList  inEesExamTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesExamTabObjArr  = new ArrayList(); 
     lEesExamTabObjArr = inEesExamTabObjArr; 
     List lEesExamTabObjList  = new ArrayList(lEesExamTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesExamTabObjArr.size();  lRecNum++ )
     {
       EesExamTabObj  lEesExamTabObj = new EesExamTabObj(); 
       lEesExamTabObj = (EesExamTabObj)lEesExamTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesExamTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesExamTabObj.exam_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesExamTabObj.exam_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesExamTabObj.exam_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("year") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (4 - Short.toString(lEesExamTabObj.year).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.year+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("month") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesExamTabObj.month).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.month+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("academic_session") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (11 - lEesExamTabObj.academic_session.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.academic_session+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_start_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesExamTabObj.exam_start_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_start_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_end_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesExamTabObj.exam_end_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_end_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.exam_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_status_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesExamTabObj.exam_status_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_status_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_sch_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.exam_sch_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_sch_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("sitting_plan_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.sitting_plan_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.sitting_plan_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("seat_alloc_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.seat_alloc_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.seat_alloc_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_attn_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.exam_attn_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.exam_attn_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mark_entry_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesExamTabObj.mark_entry_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesExamTabObj.mark_entry_status+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesExamTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesExamTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesExamTabObjList ); 
     ArrayList lEesExamTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesExamTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesExamTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesExamTabObjArrSorted.add( (EesExamTabObj)lEesExamTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesExamTabObjArr.size();  lRecNum++ )
     {
       inEesExamTabObjArr.set( lRecNum, (EesExamTabObj)lEesExamTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesExamTabObj
               ( 
                 EesExamTabObj  inEesExamTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesExamTabObj.exam_start_date != null && inEesExamTabObj.exam_start_date.length() > 0 ) 
            inEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_start_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_end_date != null && inEesExamTabObj.exam_end_date.length() > 0 ) 
            inEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_end_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_status_date != null && inEesExamTabObj.exam_status_date.length() > 0 ) 
            inEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_status_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_TYPE";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeYear
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 4 )
   {
      outErrorFlag          = true;
      String lFieldName   = "YEAR";
      String lErrorReason = "Size Greater Than 4";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMonth
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MONTH";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAcademicSession
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 11 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACADEMIC_SESSION";
      String lErrorReason = "Size Greater Than 11";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamStartDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_START_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamEndDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_END_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamStatusDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_STATUS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamSchStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_SCH_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSittingPlanStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SITTING_PLAN_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSeatAllocStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SEAT_ALLOC_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamAttnStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_ATTN_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMarkEntryStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MARK_ENTRY_STATUS";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesExamCount
               ( String inEesExamWhereText
               )
  {
    sop("gtEesExamCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamCount
               ( String inEesExamWhereText
               , String inEesExamSelectFieldList
               )
  {
    sop("gtEesExamCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesExamSelectFieldList+" AS count "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamRecByPkey
               ( EesExamPkeyObj inEesExamPkeyObj
               , EesExamTabObj  outEesExamTabObj
               )
  {
    sop("gtEesExamRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "exam_id, "+
                                 "exam_term, "+
                                 "exam_type, "+
                                 "year, "+
                                 "month, "+
                                 "academic_session, "+
                                 "exam_start_date, "+
                                 "exam_end_date, "+
                                 "exam_status, "+
                                 "exam_status_date, "+
                                 "exam_sch_status, "+
                                 "sitting_plan_status, "+
                                 "seat_alloc_status, "+
                                 "exam_attn_status, "+
                                 "mark_entry_status "+
                         "FROM   EES_EXAM " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesExamPkeyObj.org_id+"' and "+
                              "exam_id = "+"'"+inEesExamPkeyObj.exam_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesExamTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesExamTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesExamTabObj.exam_id  =  lResultSet.getString("EXAM_ID");
          outEesExamTabObj.exam_term  =  lResultSet.getString("EXAM_TERM");
          outEesExamTabObj.exam_type  =  lResultSet.getString("EXAM_TYPE");
          outEesExamTabObj.year  =  lResultSet.getShort("YEAR");
          outEesExamTabObj.month  =  lResultSet.getByte("MONTH");
          outEesExamTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesExamTabObj.exam_start_date  =  lResultSet.getString("EXAM_START_DATE");

          if ( outEesExamTabObj.exam_start_date != null && outEesExamTabObj.exam_start_date.length() > 0 ) 
            outEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_start_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_end_date  =  lResultSet.getString("EXAM_END_DATE");

          if ( outEesExamTabObj.exam_end_date != null && outEesExamTabObj.exam_end_date.length() > 0 ) 
            outEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_end_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_status  =  lResultSet.getString("EXAM_STATUS");
          outEesExamTabObj.exam_status_date  =  lResultSet.getString("EXAM_STATUS_DATE");

          if ( outEesExamTabObj.exam_status_date != null && outEesExamTabObj.exam_status_date.length() > 0 ) 
            outEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_sch_status  =  lResultSet.getString("EXAM_SCH_STATUS");
          outEesExamTabObj.sitting_plan_status  =  lResultSet.getString("SITTING_PLAN_STATUS");
          outEesExamTabObj.seat_alloc_status  =  lResultSet.getString("SEAT_ALLOC_STATUS");
          outEesExamTabObj.exam_attn_status  =  lResultSet.getString("EXAM_ATTN_STATUS");
          outEesExamTabObj.mark_entry_status  =  lResultSet.getString("MARK_ENTRY_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesExamTabObj( outEesExamTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamArr
               ( EesExamPkeyObj inEesExamPkeyObj
               , ArrayList  outEesExamTabObjArr
               )
  {
    sop("gtEesExamArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "exam_id, "+
                                 "exam_term, "+
                                 "exam_type, "+
                                 "year, "+
                                 "month, "+
                                 "academic_session, "+
                                 "exam_start_date, "+
                                 "exam_end_date, "+
                                 "exam_status, "+
                                 "exam_status_date, "+
                                 "exam_sch_status, "+
                                 "sitting_plan_status, "+
                                 "seat_alloc_status, "+
                                 "exam_attn_status, "+
                                 "mark_entry_status "+
                         "FROM   EES_EXAM";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesExamTabObj  lEesExamTabObj = new EesExamTabObj();
          lEesExamTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesExamTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesExamTabObj.exam_id  =  lResultSet.getString("EXAM_ID");
          lEesExamTabObj.exam_term  =  lResultSet.getString("EXAM_TERM");
          lEesExamTabObj.exam_type  =  lResultSet.getString("EXAM_TYPE");
          lEesExamTabObj.year  =  lResultSet.getShort("YEAR");
          lEesExamTabObj.month  =  lResultSet.getByte("MONTH");
          lEesExamTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesExamTabObj.exam_start_date  =  lResultSet.getString("EXAM_START_DATE");

          if ( lEesExamTabObj.exam_start_date != null && lEesExamTabObj.exam_start_date.length() > 0 ) 
            lEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_start_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_end_date  =  lResultSet.getString("EXAM_END_DATE");

          if ( lEesExamTabObj.exam_end_date != null && lEesExamTabObj.exam_end_date.length() > 0 ) 
            lEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_end_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_status  =  lResultSet.getString("EXAM_STATUS");
          lEesExamTabObj.exam_status_date  =  lResultSet.getString("EXAM_STATUS_DATE");

          if ( lEesExamTabObj.exam_status_date != null && lEesExamTabObj.exam_status_date.length() > 0 ) 
            lEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_sch_status  =  lResultSet.getString("EXAM_SCH_STATUS");
          lEesExamTabObj.sitting_plan_status  =  lResultSet.getString("SITTING_PLAN_STATUS");
          lEesExamTabObj.seat_alloc_status  =  lResultSet.getString("SEAT_ALLOC_STATUS");
          lEesExamTabObj.exam_attn_status  =  lResultSet.getString("EXAM_ATTN_STATUS");
          lEesExamTabObj.mark_entry_status  =  lResultSet.getString("MARK_ENTRY_STATUS");

          removeNullEesExamTabObj( lEesExamTabObj );

          outEesExamTabObjArr.add(  lEesExamTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesExamTabObjArr != null && outEesExamTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesExamArr2XML
               ( String inEesExamWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesExamArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesExam>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_id") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_ID>" +  lResultSet.getString("EXAM_ID") +   "</EXAM_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_term") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_TERM>" +  lResultSet.getString("EXAM_TERM") +   "</EXAM_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_type") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_TYPE>" +  lResultSet.getString("EXAM_TYPE") +   "</EXAM_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("year") )
              lXmlBuffer = lXmlBuffer +   "<YEAR>" +  lResultSet.getShort("YEAR") +   "</YEAR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("month") )
              lXmlBuffer = lXmlBuffer +   "<MONTH>" +  lResultSet.getByte("MONTH") +   "</MONTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("academic_session") )
              lXmlBuffer = lXmlBuffer +   "<ACADEMIC_SESSION>" +  lResultSet.getString("ACADEMIC_SESSION") +   "</ACADEMIC_SESSION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_start_date") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_START_DATE>" +  lResultSet.getString("EXAM_START_DATE") +   "</EXAM_START_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_end_date") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_END_DATE>" +  lResultSet.getString("EXAM_END_DATE") +   "</EXAM_END_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_status") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_STATUS>" +  lResultSet.getString("EXAM_STATUS") +   "</EXAM_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_status_date") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_STATUS_DATE>" +  lResultSet.getString("EXAM_STATUS_DATE") +   "</EXAM_STATUS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_sch_status") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_SCH_STATUS>" +  lResultSet.getString("EXAM_SCH_STATUS") +   "</EXAM_SCH_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("sitting_plan_status") )
              lXmlBuffer = lXmlBuffer +   "<SITTING_PLAN_STATUS>" +  lResultSet.getString("SITTING_PLAN_STATUS") +   "</SITTING_PLAN_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("seat_alloc_status") )
              lXmlBuffer = lXmlBuffer +   "<SEAT_ALLOC_STATUS>" +  lResultSet.getString("SEAT_ALLOC_STATUS") +   "</SEAT_ALLOC_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_attn_status") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_ATTN_STATUS>" +  lResultSet.getString("EXAM_ATTN_STATUS") +   "</EXAM_ATTN_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mark_entry_status") )
              lXmlBuffer = lXmlBuffer +   "<MARK_ENTRY_STATUS>" +  lResultSet.getString("MARK_ENTRY_STATUS") +   "</MARK_ENTRY_STATUS>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesExam>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesExamRecByRowid
               ( String inRowId
               , EesExamTabObj  outEesExamTabObj
               )
  {
    sop("gtEesExamRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "exam_id, "+
                                 "exam_term, "+
                                 "exam_type, "+
                                 "year, "+
                                 "month, "+
                                 "academic_session, "+
                                 "exam_start_date, "+
                                 "exam_end_date, "+
                                 "exam_status, "+
                                 "exam_status_date, "+
                                 "exam_sch_status, "+
                                 "sitting_plan_status, "+
                                 "seat_alloc_status, "+
                                 "exam_attn_status, "+
                                 "mark_entry_status "+
                         "FROM   EES_EXAM "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesExamTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesExamTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesExamTabObj.exam_id  =  lResultSet.getString("EXAM_ID");
          outEesExamTabObj.exam_term  =  lResultSet.getString("EXAM_TERM");
          outEesExamTabObj.exam_type  =  lResultSet.getString("EXAM_TYPE");
          outEesExamTabObj.year  =  lResultSet.getShort("YEAR");
          outEesExamTabObj.month  =  lResultSet.getByte("MONTH");
          outEesExamTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesExamTabObj.exam_start_date  =  lResultSet.getString("EXAM_START_DATE");

          if ( outEesExamTabObj.exam_start_date != null && outEesExamTabObj.exam_start_date.length() > 0 ) 
            outEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_start_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_end_date  =  lResultSet.getString("EXAM_END_DATE");

          if ( outEesExamTabObj.exam_end_date != null && outEesExamTabObj.exam_end_date.length() > 0 ) 
            outEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_end_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_status  =  lResultSet.getString("EXAM_STATUS");
          outEesExamTabObj.exam_status_date  =  lResultSet.getString("EXAM_STATUS_DATE");

          if ( outEesExamTabObj.exam_status_date != null && outEesExamTabObj.exam_status_date.length() > 0 ) 
            outEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
          outEesExamTabObj.exam_sch_status  =  lResultSet.getString("EXAM_SCH_STATUS");
          outEesExamTabObj.sitting_plan_status  =  lResultSet.getString("SITTING_PLAN_STATUS");
          outEesExamTabObj.seat_alloc_status  =  lResultSet.getString("SEAT_ALLOC_STATUS");
          outEesExamTabObj.exam_attn_status  =  lResultSet.getString("EXAM_ATTN_STATUS");
          outEesExamTabObj.mark_entry_status  =  lResultSet.getString("MARK_ENTRY_STATUS");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesExamTabObj( outEesExamTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamArr
               ( String inEesExamWhereText
               , ArrayList  outEesExamTabObjArr
               )
  {
    sop("gtEesExamArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "exam_id, "+
                                 "exam_term, "+
                                 "exam_type, "+
                                 "year, "+
                                 "month, "+
                                 "academic_session, "+
                                 "exam_start_date, "+
                                 "exam_end_date, "+
                                 "exam_status, "+
                                 "exam_status_date, "+
                                 "exam_sch_status, "+
                                 "sitting_plan_status, "+
                                 "seat_alloc_status, "+
                                 "exam_attn_status, "+
                                 "mark_entry_status "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesExamTabObj  lEesExamTabObj = new EesExamTabObj();
          lEesExamTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesExamTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesExamTabObj.exam_id  =  lResultSet.getString("EXAM_ID");
          lEesExamTabObj.exam_term  =  lResultSet.getString("EXAM_TERM");
          lEesExamTabObj.exam_type  =  lResultSet.getString("EXAM_TYPE");
          lEesExamTabObj.year  =  lResultSet.getShort("YEAR");
          lEesExamTabObj.month  =  lResultSet.getByte("MONTH");
          lEesExamTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesExamTabObj.exam_start_date  =  lResultSet.getString("EXAM_START_DATE");

          if ( lEesExamTabObj.exam_start_date != null && lEesExamTabObj.exam_start_date.length() > 0 ) 
            lEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_start_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_end_date  =  lResultSet.getString("EXAM_END_DATE");

          if ( lEesExamTabObj.exam_end_date != null && lEesExamTabObj.exam_end_date.length() > 0 ) 
            lEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_end_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_status  =  lResultSet.getString("EXAM_STATUS");
          lEesExamTabObj.exam_status_date  =  lResultSet.getString("EXAM_STATUS_DATE");

          if ( lEesExamTabObj.exam_status_date != null && lEesExamTabObj.exam_status_date.length() > 0 ) 
            lEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
          lEesExamTabObj.exam_sch_status  =  lResultSet.getString("EXAM_SCH_STATUS");
          lEesExamTabObj.sitting_plan_status  =  lResultSet.getString("SITTING_PLAN_STATUS");
          lEesExamTabObj.seat_alloc_status  =  lResultSet.getString("SEAT_ALLOC_STATUS");
          lEesExamTabObj.exam_attn_status  =  lResultSet.getString("EXAM_ATTN_STATUS");
          lEesExamTabObj.mark_entry_status  =  lResultSet.getString("MARK_ENTRY_STATUS");

          removeNullEesExamTabObj( lEesExamTabObj );

          outEesExamTabObjArr.add(  lEesExamTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesExamTabObjArr != null && outEesExamTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamArrDist
               ( String inEesExamWhereText
               , String inDistEesExamField
               , ArrayList  outEesExamTabObjArr
               )
  {

    sop("gtEesExamArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";
  

       String lDistEesExamFieldQry = inDistEesExamField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesExamFieldQry+
                         " FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesExamField.substring(inDistEesExamField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesExamTabObj  lEesExamTabObj = new EesExamTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesExamTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_id") )
              lEesExamTabObj.exam_id  =  lResultSet.getString("EXAM_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_term") )
              lEesExamTabObj.exam_term  =  lResultSet.getString("EXAM_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_type") )
              lEesExamTabObj.exam_type  =  lResultSet.getString("EXAM_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("year") )
              lEesExamTabObj.year  =  lResultSet.getShort("YEAR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("month") )
              lEesExamTabObj.month  =  lResultSet.getByte("MONTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("academic_session") )
              lEesExamTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_start_date") )
              {
              lEesExamTabObj.exam_start_date  =  lResultSet.getString("EXAM_START_DATE");
  
          if ( lEesExamTabObj.exam_start_date != null && lEesExamTabObj.exam_start_date.length() > 0 ) 
            lEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_start_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_end_date") )
              {
              lEesExamTabObj.exam_end_date  =  lResultSet.getString("EXAM_END_DATE");
  
          if ( lEesExamTabObj.exam_end_date != null && lEesExamTabObj.exam_end_date.length() > 0 ) 
            lEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_end_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_status") )
              lEesExamTabObj.exam_status  =  lResultSet.getString("EXAM_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_status_date") )
              {
              lEesExamTabObj.exam_status_date  =  lResultSet.getString("EXAM_STATUS_DATE");
  
          if ( lEesExamTabObj.exam_status_date != null && lEesExamTabObj.exam_status_date.length() > 0 ) 
            lEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesExamTabObj.exam_status_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_sch_status") )
              lEesExamTabObj.exam_sch_status  =  lResultSet.getString("EXAM_SCH_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("sitting_plan_status") )
              lEesExamTabObj.sitting_plan_status  =  lResultSet.getString("SITTING_PLAN_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("seat_alloc_status") )
              lEesExamTabObj.seat_alloc_status  =  lResultSet.getString("SEAT_ALLOC_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_attn_status") )
              lEesExamTabObj.exam_attn_status  =  lResultSet.getString("EXAM_ATTN_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mark_entry_status") )
              lEesExamTabObj.mark_entry_status  =  lResultSet.getString("MARK_ENTRY_STATUS");

          }
          removeNullEesExamTabObj( lEesExamTabObj );

          outEesExamTabObjArr.add(  lEesExamTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesExamTabObjArr != null && outEesExamTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesExamStrArrDist
               ( String inEesExamWhereText
               , String inDistEesExamField
               , ArrayList  outEesExamTabObjArr
               )
  {

    sop("gtEesExamStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesExamStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";
  

       String lDistEesExamFieldQry = inDistEesExamField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesExamFieldQry+
                         " FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesExamField.substring(inDistEesExamField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesExamTabObjStr = "";
       while(lResultSet.next())
       {
          lEesExamTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesExamTabObjStr =   lEesExamTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesExamTabObjArr.add(  lEesExamTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesExamTabObjArr != null && outEesExamTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesExam
               ( String inEesExamWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesExam - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesExam";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesExamTabObj
               ( 
                 EesExamTabObj  outEesExamTabObj
               )
  {
  
    if ( outEesExamTabObj.org_id == null ) 
     outEesExamTabObj.org_id = ""; 
    if ( outEesExamTabObj.exam_id == null ) 
     outEesExamTabObj.exam_id = ""; 
    if ( outEesExamTabObj.exam_term == null ) 
     outEesExamTabObj.exam_term = ""; 
    if ( outEesExamTabObj.exam_type == null ) 
     outEesExamTabObj.exam_type = ""; 
    if ( outEesExamTabObj.year == (int)0 ) 
     outEesExamTabObj.year = (int)0; 
    if ( outEesExamTabObj.month == (int)0 ) 
     outEesExamTabObj.month = (int)0; 
    if ( outEesExamTabObj.academic_session == null ) 
     outEesExamTabObj.academic_session = ""; 
    if ( outEesExamTabObj.exam_start_date == null ) 
     outEesExamTabObj.exam_start_date = ""; 
    if ( outEesExamTabObj.exam_end_date == null ) 
     outEesExamTabObj.exam_end_date = ""; 
    if ( outEesExamTabObj.exam_status == null ) 
     outEesExamTabObj.exam_status = ""; 
    if ( outEesExamTabObj.exam_status_date == null ) 
     outEesExamTabObj.exam_status_date = ""; 
    if ( outEesExamTabObj.exam_sch_status == null ) 
     outEesExamTabObj.exam_sch_status = ""; 
    if ( outEesExamTabObj.sitting_plan_status == null ) 
     outEesExamTabObj.sitting_plan_status = ""; 
    if ( outEesExamTabObj.seat_alloc_status == null ) 
     outEesExamTabObj.seat_alloc_status = ""; 
    if ( outEesExamTabObj.exam_attn_status == null ) 
     outEesExamTabObj.exam_attn_status = ""; 
    if ( outEesExamTabObj.mark_entry_status == null ) 
     outEesExamTabObj.mark_entry_status = ""; 
  }





  public int insEesExamRec
               ( EesExamTabObj  inEesExamTabObj )
  {
    int lUpdateCount;
    sop("insEesExamRec - Started");
    gSSTErrorObj.sourceMethod = "insEesExamRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesExamTabObj.exam_start_date != null && inEesExamTabObj.exam_start_date.length() > 0 ) 
            inEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_start_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_end_date != null && inEesExamTabObj.exam_end_date.length() > 0 ) 
            inEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_end_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_status_date != null && inEesExamTabObj.exam_status_date.length() > 0 ) 
            inEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_status_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_EXAM"+
                        "("+
                                "org_id,"+
                                "exam_id,"+
                                "exam_term,"+
                                "exam_type,"+
                                "year,"+
                                "month,"+
                                "academic_session,"+
                                "exam_start_date,"+
                                "exam_end_date,"+
                                "exam_status,"+
                                "exam_status_date,"+
                                "exam_sch_status,"+
                                "sitting_plan_status,"+
                                "seat_alloc_status,"+
                                "exam_attn_status,"+
                                "mark_entry_status"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesExamTabObj.year+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesExamTabObj.month+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.academic_session+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_start_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_end_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_status_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_sch_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.sitting_plan_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.seat_alloc_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesExamTabObj.exam_attn_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesExamTabObj.mark_entry_status+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesExamTabObj.org_id);
        lPreparedStatement.setString(2, inEesExamTabObj.exam_id);
        lPreparedStatement.setString(3, inEesExamTabObj.exam_term);
        lPreparedStatement.setString(4, inEesExamTabObj.exam_type);
          lPreparedStatement.setShort(5, inEesExamTabObj.year);
          lPreparedStatement.setByte(6, inEesExamTabObj.month);
        lPreparedStatement.setString(7, inEesExamTabObj.academic_session);
        lPreparedStatement.setString(8, inEesExamTabObj.exam_start_date);
        lPreparedStatement.setString(9, inEesExamTabObj.exam_end_date);
        lPreparedStatement.setString(10, inEesExamTabObj.exam_status);
        lPreparedStatement.setString(11, inEesExamTabObj.exam_status_date);
        lPreparedStatement.setString(12, inEesExamTabObj.exam_sch_status);
        lPreparedStatement.setString(13, inEesExamTabObj.sitting_plan_status);
        lPreparedStatement.setString(14, inEesExamTabObj.seat_alloc_status);
        lPreparedStatement.setString(15, inEesExamTabObj.exam_attn_status);
        lPreparedStatement.setString(16, inEesExamTabObj.mark_entry_status);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesExamArr
               ( ArrayList  inEesExamTabObjArr 
               , String  inRowidFlag )
  {
    EesExamTabObj  lEesExamTabObj = new EesExamTabObj();
    int lUpdateCount;
    sop("insEesExamArr - Started");
    gSSTErrorObj.sourceMethod = "insEesExamArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesExamTabObjArr.size(); lNumRec++ )
      {
        lEesExamTabObj = (EesExamTabObj)inEesExamTabObjArr.get(lNumRec);

          if ( lEesExamTabObj.exam_start_date != null && lEesExamTabObj.exam_start_date.length() > 0 ) 
            lEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesExamTabObj.exam_start_date, lDateTimeSrcFmt);

          if ( lEesExamTabObj.exam_end_date != null && lEesExamTabObj.exam_end_date.length() > 0 ) 
            lEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesExamTabObj.exam_end_date, lDateTimeSrcFmt);

          if ( lEesExamTabObj.exam_status_date != null && lEesExamTabObj.exam_status_date.length() > 0 ) 
            lEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesExamTabObj.exam_status_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_EXAM"+
                        "("+
                        "org_id,"+
                        "exam_id,"+
                        "exam_term,"+
                        "exam_type,"+
                        "year,"+
                        "month,"+
                        "academic_session,"+
                        "exam_start_date,"+
                        "exam_end_date,"+
                        "exam_status,"+
                        "exam_status_date,"+
                        "exam_sch_status,"+
                        "sitting_plan_status,"+
                        "seat_alloc_status,"+
                        "exam_attn_status,"+
                        "mark_entry_status"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesExamTabObj.year+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesExamTabObj.month+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.academic_session+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_start_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_end_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_status_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_sch_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.sitting_plan_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.seat_alloc_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesExamTabObj.exam_attn_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesExamTabObj.mark_entry_status+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesExamTabObj.org_id);
            lPreparedStatement.setString(2, lEesExamTabObj.exam_id);
            lPreparedStatement.setString(3, lEesExamTabObj.exam_term);
            lPreparedStatement.setString(4, lEesExamTabObj.exam_type);
              lPreparedStatement.setShort(5, lEesExamTabObj.year);
              lPreparedStatement.setByte(6, lEesExamTabObj.month);
            lPreparedStatement.setString(7, lEesExamTabObj.academic_session);
            lPreparedStatement.setString(8, lEesExamTabObj.exam_start_date);
            lPreparedStatement.setString(9, lEesExamTabObj.exam_end_date);
            lPreparedStatement.setString(10, lEesExamTabObj.exam_status);
            lPreparedStatement.setString(11, lEesExamTabObj.exam_status_date);
            lPreparedStatement.setString(12, lEesExamTabObj.exam_sch_status);
            lPreparedStatement.setString(13, lEesExamTabObj.sitting_plan_status);
            lPreparedStatement.setString(14, lEesExamTabObj.seat_alloc_status);
            lPreparedStatement.setString(15, lEesExamTabObj.exam_attn_status);
            lPreparedStatement.setString(16, lEesExamTabObj.mark_entry_status);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesExamReq2Obj
               ( HttpServletRequest inRequest
               , EesExamTabObj  outEesExamTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesExamTabObj.tab_rowid = lTabRowidValue;

    outEesExamTabObj.org_id = inRequest.getParameter("org_id");
    outEesExamTabObj.exam_id = inRequest.getParameter("exam_id");
    outEesExamTabObj.exam_term = inRequest.getParameter("exam_term");
    outEesExamTabObj.exam_type = inRequest.getParameter("exam_type");
    if ( inRequest.getParameter("year") == null )
      outEesExamTabObj.year = 0;
    else
    if ( inRequest.getParameter("year").trim().length() == 0 )
      outEesExamTabObj.year = 0;
    else
      outEesExamTabObj.year = Short.parseShort( inRequest.getParameter("year"));
    if ( inRequest.getParameter("month") == null )
      outEesExamTabObj.month = 0;
    else
    if ( inRequest.getParameter("month").trim().length() == 0 )
      outEesExamTabObj.month = 0;
    else
      outEesExamTabObj.month = Byte.parseByte( inRequest.getParameter("month"));
    outEesExamTabObj.academic_session = inRequest.getParameter("academic_session");
    outEesExamTabObj.exam_start_date = inRequest.getParameter("exam_start_date");
    outEesExamTabObj.exam_end_date = inRequest.getParameter("exam_end_date");
    outEesExamTabObj.exam_status = inRequest.getParameter("exam_status");
    outEesExamTabObj.exam_status_date = inRequest.getParameter("exam_status_date");
    outEesExamTabObj.exam_sch_status = inRequest.getParameter("exam_sch_status");
    outEesExamTabObj.sitting_plan_status = inRequest.getParameter("sitting_plan_status");
    outEesExamTabObj.seat_alloc_status = inRequest.getParameter("seat_alloc_status");
    outEesExamTabObj.exam_attn_status = inRequest.getParameter("exam_attn_status");
    outEesExamTabObj.mark_entry_status = inRequest.getParameter("mark_entry_status");
    return lReturnValue;
  }


  public int popEesExamReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesExamTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesExamTabObj lEesExamTabObj= new EesExamTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesExamTabObj.tab_rowid = lTabRowidValue;

      lEesExamTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesExamTabObj.exam_id = inRequest.getParameter("exam_id_r"+lNumRec);
      lEesExamTabObj.exam_term = inRequest.getParameter("exam_term_r"+lNumRec);
      lEesExamTabObj.exam_type = inRequest.getParameter("exam_type_r"+lNumRec);
      if ( inRequest.getParameter("year_r"+lNumRec) == null )
        lEesExamTabObj.year = 0;
      else
      if ( inRequest.getParameter("year_r"+lNumRec).trim().length() == 0 )
        lEesExamTabObj.year = 0;
      else
        lEesExamTabObj.year = Short.parseShort( inRequest.getParameter("year_r"+lNumRec));
      if ( inRequest.getParameter("month_r"+lNumRec) == null )
        lEesExamTabObj.month = 0;
      else
      if ( inRequest.getParameter("month_r"+lNumRec).trim().length() == 0 )
        lEesExamTabObj.month = 0;
      else
        lEesExamTabObj.month = Byte.parseByte( inRequest.getParameter("month_r"+lNumRec));
      lEesExamTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
      lEesExamTabObj.exam_start_date = inRequest.getParameter("exam_start_date_r"+lNumRec);
      lEesExamTabObj.exam_end_date = inRequest.getParameter("exam_end_date_r"+lNumRec);
      lEesExamTabObj.exam_status = inRequest.getParameter("exam_status_r"+lNumRec);
      lEesExamTabObj.exam_status_date = inRequest.getParameter("exam_status_date_r"+lNumRec);
      lEesExamTabObj.exam_sch_status = inRequest.getParameter("exam_sch_status_r"+lNumRec);
      lEesExamTabObj.sitting_plan_status = inRequest.getParameter("sitting_plan_status_r"+lNumRec);
      lEesExamTabObj.seat_alloc_status = inRequest.getParameter("seat_alloc_status_r"+lNumRec);
      lEesExamTabObj.exam_attn_status = inRequest.getParameter("exam_attn_status_r"+lNumRec);
      lEesExamTabObj.mark_entry_status = inRequest.getParameter("mark_entry_status_r"+lNumRec);
      outEesExamTabObjArr.add( lEesExamTabObj);
    }
    return lReturnValue;
  }


  public int popEesExamReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesExamTabObj outEesExamTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_exam_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesExamTabObj.tab_rowid = lTabRowidValue;

        outEesExamTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesExamTabObj.exam_id = inRequest.getParameter("exam_id_r"+lNumRec);
        outEesExamTabObj.exam_term = inRequest.getParameter("exam_term_r"+lNumRec);
        outEesExamTabObj.exam_type = inRequest.getParameter("exam_type_r"+lNumRec);
        if ( inRequest.getParameter("year_r"+lNumRec) == null )
          outEesExamTabObj.year = 0;
        else
        if ( inRequest.getParameter("year_r"+lNumRec).trim().length() == 0 )
          outEesExamTabObj.year = 0;
        else
          outEesExamTabObj.year = Short.parseShort( inRequest.getParameter("year_r"+lNumRec));
        if ( inRequest.getParameter("month_r"+lNumRec) == null )
          outEesExamTabObj.month = 0;
        else
        if ( inRequest.getParameter("month_r"+lNumRec).trim().length() == 0 )
          outEesExamTabObj.month = 0;
        else
          outEesExamTabObj.month = Byte.parseByte( inRequest.getParameter("month_r"+lNumRec));
        outEesExamTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        outEesExamTabObj.exam_start_date = inRequest.getParameter("exam_start_date_r"+lNumRec);
        outEesExamTabObj.exam_end_date = inRequest.getParameter("exam_end_date_r"+lNumRec);
        outEesExamTabObj.exam_status = inRequest.getParameter("exam_status_r"+lNumRec);
        outEesExamTabObj.exam_status_date = inRequest.getParameter("exam_status_date_r"+lNumRec);
        outEesExamTabObj.exam_sch_status = inRequest.getParameter("exam_sch_status_r"+lNumRec);
        outEesExamTabObj.sitting_plan_status = inRequest.getParameter("sitting_plan_status_r"+lNumRec);
        outEesExamTabObj.seat_alloc_status = inRequest.getParameter("seat_alloc_status_r"+lNumRec);
        outEesExamTabObj.exam_attn_status = inRequest.getParameter("exam_attn_status_r"+lNumRec);
        outEesExamTabObj.mark_entry_status = inRequest.getParameter("mark_entry_status_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesExamReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesExamTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesExamTabObj lEesExamTabObj= new EesExamTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_exam_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesExamTabObj.tab_rowid = lTabRowidValue;

        lEesExamTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesExamTabObj.exam_id = inRequest.getParameter("exam_id_r"+lNumRec);
        lEesExamTabObj.exam_term = inRequest.getParameter("exam_term_r"+lNumRec);
        lEesExamTabObj.exam_type = inRequest.getParameter("exam_type_r"+lNumRec);
        if ( inRequest.getParameter("year_r"+lNumRec) == null )
          lEesExamTabObj.year = 0;
        else
        if ( inRequest.getParameter("year_r"+lNumRec).trim().length() == 0 )
          lEesExamTabObj.year = 0;
        else
          lEesExamTabObj.year = Short.parseShort( inRequest.getParameter("year_r"+lNumRec));
        if ( inRequest.getParameter("month_r"+lNumRec) == null )
          lEesExamTabObj.month = 0;
        else
        if ( inRequest.getParameter("month_r"+lNumRec).trim().length() == 0 )
          lEesExamTabObj.month = 0;
        else
          lEesExamTabObj.month = Byte.parseByte( inRequest.getParameter("month_r"+lNumRec));
        lEesExamTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        lEesExamTabObj.exam_start_date = inRequest.getParameter("exam_start_date_r"+lNumRec);
        lEesExamTabObj.exam_end_date = inRequest.getParameter("exam_end_date_r"+lNumRec);
        lEesExamTabObj.exam_status = inRequest.getParameter("exam_status_r"+lNumRec);
        lEesExamTabObj.exam_status_date = inRequest.getParameter("exam_status_date_r"+lNumRec);
        lEesExamTabObj.exam_sch_status = inRequest.getParameter("exam_sch_status_r"+lNumRec);
        lEesExamTabObj.sitting_plan_status = inRequest.getParameter("sitting_plan_status_r"+lNumRec);
        lEesExamTabObj.seat_alloc_status = inRequest.getParameter("seat_alloc_status_r"+lNumRec);
        lEesExamTabObj.exam_attn_status = inRequest.getParameter("exam_attn_status_r"+lNumRec);
        lEesExamTabObj.mark_entry_status = inRequest.getParameter("mark_entry_status_r"+lNumRec);
        outEesExamTabObjArr.add( lEesExamTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesExamRecByRowid
               ( String inRowId
               , EesExamTabObj  inEesExamTabObj
               )
  {
    int lUpdateCount;
    sop("updEesExamRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesExamRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesExamTabObj.exam_start_date != null && inEesExamTabObj.exam_start_date.length() > 0 ) 
            inEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_start_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_end_date != null && inEesExamTabObj.exam_end_date.length() > 0 ) 
            inEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_end_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_status_date != null && inEesExamTabObj.exam_status_date.length() > 0 ) 
            inEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_status_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EXAM ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesExamTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesExamTabObj.org_id+"', ";
      if ( inEesExamTabObj.exam_id != null  )         lSqlStmt = lSqlStmt + "exam_id = "+"'"+inEesExamTabObj.exam_id+"', ";
      if ( inEesExamTabObj.exam_term != null  )         lSqlStmt = lSqlStmt + "exam_term = "+"'"+inEesExamTabObj.exam_term+"', ";
      if ( inEesExamTabObj.exam_type != null  )         lSqlStmt = lSqlStmt + "exam_type = "+"'"+inEesExamTabObj.exam_type+"', ";
             lSqlStmt = lSqlStmt + "year = "+inEesExamTabObj.year+", ";
             lSqlStmt = lSqlStmt + "month = "+inEesExamTabObj.month+", ";
      if ( inEesExamTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesExamTabObj.academic_session+"', ";
      if ( inEesExamTabObj.exam_start_date != null  )         lSqlStmt = lSqlStmt + "exam_start_date = "+"'"+inEesExamTabObj.exam_start_date+"', ";
      if ( inEesExamTabObj.exam_end_date != null  )         lSqlStmt = lSqlStmt + "exam_end_date = "+"'"+inEesExamTabObj.exam_end_date+"', ";
      if ( inEesExamTabObj.exam_status != null  )         lSqlStmt = lSqlStmt + "exam_status = "+"'"+inEesExamTabObj.exam_status+"', ";
      if ( inEesExamTabObj.exam_status_date != null  )         lSqlStmt = lSqlStmt + "exam_status_date = "+"'"+inEesExamTabObj.exam_status_date+"', ";
      if ( inEesExamTabObj.exam_sch_status != null  )         lSqlStmt = lSqlStmt + "exam_sch_status = "+"'"+inEesExamTabObj.exam_sch_status+"', ";
      if ( inEesExamTabObj.sitting_plan_status != null  )         lSqlStmt = lSqlStmt + "sitting_plan_status = "+"'"+inEesExamTabObj.sitting_plan_status+"', ";
      if ( inEesExamTabObj.seat_alloc_status != null  )         lSqlStmt = lSqlStmt + "seat_alloc_status = "+"'"+inEesExamTabObj.seat_alloc_status+"', ";
      if ( inEesExamTabObj.exam_attn_status != null  )         lSqlStmt = lSqlStmt + "exam_attn_status = "+"'"+inEesExamTabObj.exam_attn_status+"', ";
      if ( inEesExamTabObj.mark_entry_status != null  )         lSqlStmt = lSqlStmt + "mark_entry_status = "+"'"+inEesExamTabObj.mark_entry_status+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesExamRecByPkey
               ( EesExamPkeyObj inEesExamPkeyObj
               , EesExamTabObj  inEesExamTabObj
               )
  {
    int lUpdateCount;
    sop("updEesExamRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesExamRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesExamTabObj.exam_start_date != null && inEesExamTabObj.exam_start_date.length() > 0 ) 
            inEesExamTabObj.exam_start_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_start_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_end_date != null && inEesExamTabObj.exam_end_date.length() > 0 ) 
            inEesExamTabObj.exam_end_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_end_date, lDateTimeSrcFmt);

          if ( inEesExamTabObj.exam_status_date != null && inEesExamTabObj.exam_status_date.length() > 0 ) 
            inEesExamTabObj.exam_status_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesExamTabObj.exam_status_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EXAM ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesExamTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesExamTabObj.exam_id != null  )         lSqlStmt = lSqlStmt + "exam_id = ? , ";
        if ( inEesExamTabObj.exam_term != null  )         lSqlStmt = lSqlStmt + "exam_term = ? , ";
        if ( inEesExamTabObj.exam_type != null  )         lSqlStmt = lSqlStmt + "exam_type = ? , ";
               lSqlStmt = lSqlStmt + "year = ? , ";
               lSqlStmt = lSqlStmt + "month = ? , ";
        if ( inEesExamTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = ? , ";
        if ( inEesExamTabObj.exam_start_date != null  )         lSqlStmt = lSqlStmt + "exam_start_date = ? , ";
        if ( inEesExamTabObj.exam_end_date != null  )         lSqlStmt = lSqlStmt + "exam_end_date = ? , ";
        if ( inEesExamTabObj.exam_status != null  )         lSqlStmt = lSqlStmt + "exam_status = ? , ";
        if ( inEesExamTabObj.exam_status_date != null  )         lSqlStmt = lSqlStmt + "exam_status_date = ? , ";
        if ( inEesExamTabObj.exam_sch_status != null  )         lSqlStmt = lSqlStmt + "exam_sch_status = ? , ";
        if ( inEesExamTabObj.sitting_plan_status != null  )         lSqlStmt = lSqlStmt + "sitting_plan_status = ? , ";
        if ( inEesExamTabObj.seat_alloc_status != null  )         lSqlStmt = lSqlStmt + "seat_alloc_status = ? , ";
        if ( inEesExamTabObj.exam_attn_status != null  )         lSqlStmt = lSqlStmt + "exam_attn_status = ? , ";
        if ( inEesExamTabObj.mark_entry_status != null  )         lSqlStmt = lSqlStmt + "mark_entry_status = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesExamTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesExamTabObj.org_id+"', ";
        if ( inEesExamTabObj.exam_id != null  )         lSqlStmt = lSqlStmt + "exam_id = "+"'"+inEesExamTabObj.exam_id+"', ";
        if ( inEesExamTabObj.exam_term != null  )         lSqlStmt = lSqlStmt + "exam_term = "+"'"+inEesExamTabObj.exam_term+"', ";
        if ( inEesExamTabObj.exam_type != null  )         lSqlStmt = lSqlStmt + "exam_type = "+"'"+inEesExamTabObj.exam_type+"', ";
               lSqlStmt = lSqlStmt + "year = "+inEesExamTabObj.year+", ";
               lSqlStmt = lSqlStmt + "month = "+inEesExamTabObj.month+", ";
        if ( inEesExamTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesExamTabObj.academic_session+"', ";
        if ( inEesExamTabObj.exam_start_date != null  )         lSqlStmt = lSqlStmt + "exam_start_date = "+"'"+inEesExamTabObj.exam_start_date+"', ";
        if ( inEesExamTabObj.exam_end_date != null  )         lSqlStmt = lSqlStmt + "exam_end_date = "+"'"+inEesExamTabObj.exam_end_date+"', ";
        if ( inEesExamTabObj.exam_status != null  )         lSqlStmt = lSqlStmt + "exam_status = "+"'"+inEesExamTabObj.exam_status+"', ";
        if ( inEesExamTabObj.exam_status_date != null  )         lSqlStmt = lSqlStmt + "exam_status_date = "+"'"+inEesExamTabObj.exam_status_date+"', ";
        if ( inEesExamTabObj.exam_sch_status != null  )         lSqlStmt = lSqlStmt + "exam_sch_status = "+"'"+inEesExamTabObj.exam_sch_status+"', ";
        if ( inEesExamTabObj.sitting_plan_status != null  )         lSqlStmt = lSqlStmt + "sitting_plan_status = "+"'"+inEesExamTabObj.sitting_plan_status+"', ";
        if ( inEesExamTabObj.seat_alloc_status != null  )         lSqlStmt = lSqlStmt + "seat_alloc_status = "+"'"+inEesExamTabObj.seat_alloc_status+"', ";
        if ( inEesExamTabObj.exam_attn_status != null  )         lSqlStmt = lSqlStmt + "exam_attn_status = "+"'"+inEesExamTabObj.exam_attn_status+"', ";
        if ( inEesExamTabObj.mark_entry_status != null  )         lSqlStmt = lSqlStmt + "mark_entry_status = "+"'"+inEesExamTabObj.mark_entry_status+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesExamPkeyObj.org_id+"' and "+
                              "exam_id = "+"'"+inEesExamPkeyObj.exam_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesExamTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.org_id); } 
         if ( inEesExamTabObj.exam_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_id); } 
         if ( inEesExamTabObj.exam_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_term); } 
         if ( inEesExamTabObj.exam_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_type); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(5, inEesExamTabObj.year);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(6, inEesExamTabObj.month);
         if ( inEesExamTabObj.academic_session != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.academic_session); } 
         if ( inEesExamTabObj.exam_start_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_start_date); } 
         if ( inEesExamTabObj.exam_end_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_end_date); } 
         if ( inEesExamTabObj.exam_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_status); } 
         if ( inEesExamTabObj.exam_status_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_status_date); } 
         if ( inEesExamTabObj.exam_sch_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_sch_status); } 
         if ( inEesExamTabObj.sitting_plan_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.sitting_plan_status); } 
         if ( inEesExamTabObj.seat_alloc_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.seat_alloc_status); } 
         if ( inEesExamTabObj.exam_attn_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.exam_attn_status); } 
         if ( inEesExamTabObj.mark_entry_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesExamTabObj.mark_entry_status); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesExamRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesExamRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesExamRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_EXAM "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesExamRecByPkeyWithSet
               ( EesExamPkeyObj inEesExamPkeyObj
               , String  inEesExamSetlist
               )
  {
    int lUpdateCount;
    sop("updEesExamRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesExamRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EXAM ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesExamSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesExamPkeyObj.org_id+"' and "+
                              "exam_id = "+"'"+inEesExamPkeyObj.exam_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesExamRecByRowidWithSet
               ( String inRowId
               , String  inEesExamSetlist
               )
  {
    int lUpdateCount;
    sop("updEesExamRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesExamRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EXAM ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesExamSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesExamRecByWhereWithSet
               ( String inEesExamWhereText
               , String  inEesExamSetlist
               )
  {
    int lUpdateCount;
    sop("updEesExamRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesExamRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_EXAM ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesExamSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesExamRecByPkey
               ( EesExamPkeyObj  inEesExamPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesExamRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesExamRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_EXAM " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesExamPkeyObj.org_id+"' and "+
                              "exam_id = "+"'"+inEesExamPkeyObj.exam_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesExamByWhere
               ( String inEesExamWhereText
               )
  {
    int lUpdateCount;
    sop("delEesExamByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesExamByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesExamWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesExamWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_EXAM "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
