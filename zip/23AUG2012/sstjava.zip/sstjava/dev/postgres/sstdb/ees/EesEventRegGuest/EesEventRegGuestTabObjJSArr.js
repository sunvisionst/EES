
var lEesEventRegGuestTabObjJSArr = new Array();
<%
{
   if ( lEesEventRegGuestTabObjArrCache != null && lEesEventRegGuestTabObjArrCache.size() > 0 )
   {
%>
       lEesEventRegGuestTabObjJSArr = new Array(<%=lEesEventRegGuestTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesEventRegGuestTabObjArrCache.size(); lRecNum++ )
       {
          EesEventRegGuestTabObj lEesEventRegGuestTabObj    =    new EesEventRegGuestTabObj();
          lEesEventRegGuestTabObj = (EesEventRegGuestTabObj)lEesEventRegGuestTabObjArrCache.get(lRecNum);
%>
          lEesEventRegGuestTabObjJSArr[<%=lRecNum%>] = new constructorEesEventRegGuest
          (
          "<%=lEesEventRegGuestTabObj.org_id%>",
          "<%=lEesEventRegGuestTabObj.activity_id%>",
          "<%=lEesEventRegGuestTabObj.event_id%>",
          "<%=lEesEventRegGuestTabObj.speaker_ind%>",
          "<%=lEesEventRegGuestTabObj.attendee_name%>",
          "<%=lEesEventRegGuestTabObj.attendee_email%>",
          "<%=lEesEventRegGuestTabObj.attendee_phone%>",
          "<%=lEesEventRegGuestTabObj.attendee_fax%>",
          "<%=lEesEventRegGuestTabObj.status%>",
          "<%=lEesEventRegGuestTabObj.status_date%>"
          );
<%
       }
   }
}
%>


