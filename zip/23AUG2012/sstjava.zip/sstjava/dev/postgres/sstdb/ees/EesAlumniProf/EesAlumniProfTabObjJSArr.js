
var lEesAlumniProfTabObjJSArr = new Array();
<%
{
   if ( lEesAlumniProfTabObjArrCache != null && lEesAlumniProfTabObjArrCache.size() > 0 )
   {
%>
       lEesAlumniProfTabObjJSArr = new Array(<%=lEesAlumniProfTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesAlumniProfTabObjArrCache.size(); lRecNum++ )
       {
          EesAlumniProfTabObj lEesAlumniProfTabObj    =    new EesAlumniProfTabObj();
          lEesAlumniProfTabObj = (EesAlumniProfTabObj)lEesAlumniProfTabObjArrCache.get(lRecNum);
%>
          lEesAlumniProfTabObjJSArr[<%=lRecNum%>] = new constructorEesAlumniProf
          (
          "<%=lEesAlumniProfTabObj.student_org_id%>",
          "<%=lEesAlumniProfTabObj.alumni_id%>",
          "<%=lEesAlumniProfTabObj.seq_num%>",
          "<%=lEesAlumniProfTabObj.occupation%>",
          "<%=lEesAlumniProfTabObj.designation%>",
          "<%=lEesAlumniProfTabObj.joining_date%>",
          "<%=lEesAlumniProfTabObj.org_name%>",
          "<%=lEesAlumniProfTabObj.working_tech%>",
          "<%=lEesAlumniProfTabObj.area_of_interest%>",
          "<%=lEesAlumniProfTabObj.web_page_ind%>",
          "<%=lEesAlumniProfTabObj.office_address1%>",
          "<%=lEesAlumniProfTabObj.office_address2%>",
          "<%=lEesAlumniProfTabObj.city%>",
          "<%=lEesAlumniProfTabObj.state%>",
          "<%=lEesAlumniProfTabObj.zip%>",
          "<%=lEesAlumniProfTabObj.country%>",
          "<%=lEesAlumniProfTabObj.phone_list%>",
          "<%=lEesAlumniProfTabObj.email_list%>",
          "<%=lEesAlumniProfTabObj.fax_list%>"
          );
<%
       }
   }
}
%>


