package sstdb.ees.EesAdmList;


public class EesAdmListTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 adm_req_id;
  public String                                 application_form_num;
  public String                                 applicant_id;
  public String                                 student_photo_file;
  public String                                 mother_photo_file;
  public String                                 father_photo_file;
  public String                                 class_id;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 class_section;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 name_initials;
  public String                                 student_f_name;
  public String                                 student_m_name;
  public String                                 student_l_name;
  public String                                 dob;
  public String                                 age_on_date;
  public byte                                  age_year;
  public String                                 age_month;
  public byte                                  age_day;
  public String                                 s_nationality;
  public String                                 religion;
  public String                                 student_ctg;
  public String                                 gender_flag;
  public String                                 p_address_1;
  public String                                 p_address_2;
  public String                                 p_country;
  public String                                 p_state;
  public String                                 p_city;
  public String                                 p_district;
  public String                                 p_zip;
  public String                                 m_address_1;
  public String                                 m_address_2;
  public String                                 m_country;
  public String                                 m_state;
  public String                                 m_city;
  public String                                 m_district;
  public String                                 m_zip;
  public String                                 phone_list;
  public String                                 email_list;
  public String                                 fax_list;
  public String                                 prev_org_name;
  public String                                 prev_class_id;
  public String                                 prev_class_num;
  public String                                 prev_class_std;
  public String                                 prev_class_section;
  public String                                 prev_course_id;
  public String                                 prev_course_term;
  public String                                 prev_course_stream;
  public String                                 reason_for_leaving;
  public String                                 father_name;
  public byte                                  father_age;
  public String                                 f_nationality;
  public String                                 father_occ_type;
  public String                                 father_employer;
  public String                                 father_designation;
  public double                                 father_annual_income;
  public String                                 f_off_address_1;
  public String                                 f_phone_list;
  public String                                 mother_name;
  public byte                                  mother_age;
  public String                                 m_nationality;
  public String                                 mother_occ_type;
  public String                                 mother_employer;
  public String                                 mother_designation;
  public double                                 mother_annual_income;
  public String                                 m_off_address_1;
  public String                                 m_phone_list;
  public String                                 divorced_flag;
  public String                                 child_with;
  public String                                 roll_num;
  public String                                 academic_session;
  public String                                 adm_req_sts;
  public String                                 adm_req_sts_date;
  public String                                 student_id;
  public String                                 scholor_num;
  public String                                 form_recv_date;
  public String                                 form_recv_time;
  public String                                 prospectus_sale_date;
  public String                                 prospectus_sale_time;
  public String                                 prospectus_sold_by;
  public double                                 application_form_fee;
  public String                                 adm_academic_session;
  public String                                 entrance_exam_date;
  public String                                 entrance_exam_time_start;
  public String                                 entrance_exam_time_end;
  public String                                 exam_present_status;
  public String                                 building_id;
  public String                                 floor_num;
  public String                                 room_num;
  public short                                 max_mark;
  public short                                 obtained_mark;
  public String                                 grade;
  public String                                 fee_sch_date;
  public String                                 fee_deposit_date;
  public String                                 online_flag;
  public String                                 admission_mode;
  public String                                 course_stream_1;
  public String                                 course_stream_2;
  public String                                 course_stream_3;
  public String                                 course_stream_4;
  public String                                 apr_course_stream;
  public String                                 unv_1;
  public String                                 unv_rn_1;
  public String                                 gen_rank_1;
  public String                                 ctg_rank_1;
  public String                                 stt_rank_1;
  public String                                 yoa_1;
  public String                                 unv_2;
  public String                                 unv_rn_2;
  public String                                 gen_rank_2;
  public String                                 ctg_rank_2;
  public String                                 stt_rank_2;
  public String                                 yoa_2;
  public float                                 prev_mark_percent;
  public String                                 domecile_ind;
  public String                                 org_transport_req_ind;
  public String                                 org_hostel_req_ind;
  public String                                 cheque_num;
  public String                                 cheque_date;
  public String                                 bank_code;
  public String                                 bank_name;
  public double                                 cheque_amt;
  public String                                 lg_0_name;
  public String                                 lg_0_rel_type;
  public String                                 lg_0_address;
  public String                                 lg_0_phone;
  public String                                 lg_1_name;
  public String                                 lg_1_rel_type;
  public String                                 lg_1_address;
  public String                                 lg_1_phone;
  public String                                 st_cap_attr_1;
  public String                                 st_cap_attr_2;
  public String                                 st_cap_attr_3;
  public String                                 st_cap_attr_4;
  public String                                 st_cap_attr_5;
  public String                                 st_cap_attr_6;
  public String                                 st_cap_attr_7;
  public String                                 st_cap_attr_8;
  public String                                 allergy;
  public String                                 physical_disability;
  public String                                 health_problem;
  public String                                 health_problem_1;
  public String                                 health_problem_2;
  public String                                 health_problem_3;
  public String                                 health_problem_4;
  public String                                 health_problem_5;
  public String                                 health_problem_6;
  public String                                 health_problem_7;
  public String                                 health_problem_8;
  public String                                 health_problem_9;
  public String                                 health_problem_10;
  public String                                 health_problem_11;
  public String                                 health_problem_12;
  public String                                 enclosure_1;
  public String                                 enclosure_2;
  public String                                 enclosure_3;
  public String                                 enclosure_4;
  public String                                 enclosure_5;
  public String                                 enclosure_6;
  public String                                 enclosure_7;
  public String                                 enclosure_8;
  public short                                 seat_num;
  public String                                 reason_for_join;
  public String                                 remark;
  public String                                 place_of_birth;
  public double                                 adv_adm_fee;
  public String                                 payment_mode;
  public String                                 target_ptl_user_id;
  public String                                 adm_req_id_req;
  public String                                 adm_req_id_list;





  public short                                  org_id_ind;
  public short                                  adm_req_id_ind;
  public short                                  application_form_num_ind;
  public short                                  applicant_id_ind;
  public short                                  student_photo_file_ind;
  public short                                  mother_photo_file_ind;
  public short                                  father_photo_file_ind;
  public short                                  class_id_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  class_section_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  name_initials_ind;
  public short                                  student_f_name_ind;
  public short                                  student_m_name_ind;
  public short                                  student_l_name_ind;
  public short                                  dob_ind;
  public short                                  age_on_date_ind;
  public short                                  age_year_ind;
  public short                                  age_month_ind;
  public short                                  age_day_ind;
  public short                                  s_nationality_ind;
  public short                                  religion_ind;
  public short                                  student_ctg_ind;
  public short                                  gender_flag_ind;
  public short                                  p_address_1_ind;
  public short                                  p_address_2_ind;
  public short                                  p_country_ind;
  public short                                  p_state_ind;
  public short                                  p_city_ind;
  public short                                  p_district_ind;
  public short                                  p_zip_ind;
  public short                                  m_address_1_ind;
  public short                                  m_address_2_ind;
  public short                                  m_country_ind;
  public short                                  m_state_ind;
  public short                                  m_city_ind;
  public short                                  m_district_ind;
  public short                                  m_zip_ind;
  public short                                  phone_list_ind;
  public short                                  email_list_ind;
  public short                                  fax_list_ind;
  public short                                  prev_org_name_ind;
  public short                                  prev_class_id_ind;
  public short                                  prev_class_num_ind;
  public short                                  prev_class_std_ind;
  public short                                  prev_class_section_ind;
  public short                                  prev_course_id_ind;
  public short                                  prev_course_term_ind;
  public short                                  prev_course_stream_ind;
  public short                                  reason_for_leaving_ind;
  public short                                  father_name_ind;
  public short                                  father_age_ind;
  public short                                  f_nationality_ind;
  public short                                  father_occ_type_ind;
  public short                                  father_employer_ind;
  public short                                  father_designation_ind;
  public short                                  father_annual_income_ind;
  public short                                  f_off_address_1_ind;
  public short                                  f_phone_list_ind;
  public short                                  mother_name_ind;
  public short                                  mother_age_ind;
  public short                                  m_nationality_ind;
  public short                                  mother_occ_type_ind;
  public short                                  mother_employer_ind;
  public short                                  mother_designation_ind;
  public short                                  mother_annual_income_ind;
  public short                                  m_off_address_1_ind;
  public short                                  m_phone_list_ind;
  public short                                  divorced_flag_ind;
  public short                                  child_with_ind;
  public short                                  roll_num_ind;
  public short                                  academic_session_ind;
  public short                                  adm_req_sts_ind;
  public short                                  adm_req_sts_date_ind;
  public short                                  student_id_ind;
  public short                                  scholor_num_ind;
  public short                                  form_recv_date_ind;
  public short                                  form_recv_time_ind;
  public short                                  prospectus_sale_date_ind;
  public short                                  prospectus_sale_time_ind;
  public short                                  prospectus_sold_by_ind;
  public short                                  application_form_fee_ind;
  public short                                  adm_academic_session_ind;
  public short                                  entrance_exam_date_ind;
  public short                                  entrance_exam_time_start_ind;
  public short                                  entrance_exam_time_end_ind;
  public short                                  exam_present_status_ind;
  public short                                  building_id_ind;
  public short                                  floor_num_ind;
  public short                                  room_num_ind;
  public short                                  max_mark_ind;
  public short                                  obtained_mark_ind;
  public short                                  grade_ind;
  public short                                  fee_sch_date_ind;
  public short                                  fee_deposit_date_ind;
  public short                                  online_flag_ind;
  public short                                  admission_mode_ind;
  public short                                  course_stream_1_ind;
  public short                                  course_stream_2_ind;
  public short                                  course_stream_3_ind;
  public short                                  course_stream_4_ind;
  public short                                  apr_course_stream_ind;
  public short                                  unv_1_ind;
  public short                                  unv_rn_1_ind;
  public short                                  gen_rank_1_ind;
  public short                                  ctg_rank_1_ind;
  public short                                  stt_rank_1_ind;
  public short                                  yoa_1_ind;
  public short                                  unv_2_ind;
  public short                                  unv_rn_2_ind;
  public short                                  gen_rank_2_ind;
  public short                                  ctg_rank_2_ind;
  public short                                  stt_rank_2_ind;
  public short                                  yoa_2_ind;
  public short                                  prev_mark_percent_ind;
  public short                                  domecile_ind_ind;
  public short                                  org_transport_req_ind_ind;
  public short                                  org_hostel_req_ind_ind;
  public short                                  cheque_num_ind;
  public short                                  cheque_date_ind;
  public short                                  bank_code_ind;
  public short                                  bank_name_ind;
  public short                                  cheque_amt_ind;
  public short                                  lg_0_name_ind;
  public short                                  lg_0_rel_type_ind;
  public short                                  lg_0_address_ind;
  public short                                  lg_0_phone_ind;
  public short                                  lg_1_name_ind;
  public short                                  lg_1_rel_type_ind;
  public short                                  lg_1_address_ind;
  public short                                  lg_1_phone_ind;
  public short                                  st_cap_attr_1_ind;
  public short                                  st_cap_attr_2_ind;
  public short                                  st_cap_attr_3_ind;
  public short                                  st_cap_attr_4_ind;
  public short                                  st_cap_attr_5_ind;
  public short                                  st_cap_attr_6_ind;
  public short                                  st_cap_attr_7_ind;
  public short                                  st_cap_attr_8_ind;
  public short                                  allergy_ind;
  public short                                  physical_disability_ind;
  public short                                  health_problem_ind;
  public short                                  health_problem_1_ind;
  public short                                  health_problem_2_ind;
  public short                                  health_problem_3_ind;
  public short                                  health_problem_4_ind;
  public short                                  health_problem_5_ind;
  public short                                  health_problem_6_ind;
  public short                                  health_problem_7_ind;
  public short                                  health_problem_8_ind;
  public short                                  health_problem_9_ind;
  public short                                  health_problem_10_ind;
  public short                                  health_problem_11_ind;
  public short                                  health_problem_12_ind;
  public short                                  enclosure_1_ind;
  public short                                  enclosure_2_ind;
  public short                                  enclosure_3_ind;
  public short                                  enclosure_4_ind;
  public short                                  enclosure_5_ind;
  public short                                  enclosure_6_ind;
  public short                                  enclosure_7_ind;
  public short                                  enclosure_8_ind;
  public short                                  seat_num_ind;
  public short                                  reason_for_join_ind;
  public short                                  remark_ind;
  public short                                  place_of_birth_ind;
  public short                                  adv_adm_fee_ind;
  public short                                  payment_mode_ind;
  public short                                  target_ptl_user_id_ind;
  public short                                  adm_req_id_req_ind;
  public short                                  adm_req_id_list_ind;


  public EesAdmListTabObj(){}


  public EesAdmListTabObj
  (
    String org_id,
    String adm_req_id,
    String application_form_num,
    String applicant_id,
    String student_photo_file,
    String mother_photo_file,
    String father_photo_file,
    String class_id,
    String class_num,
    String class_std,
    String class_section,
    String course_id,
    String course_term,
    String course_stream,
    String name_initials,
    String student_f_name,
    String student_m_name,
    String student_l_name,
    String dob,
    String age_on_date,
    byte age_year,
    String age_month,
    byte age_day,
    String s_nationality,
    String religion,
    String student_ctg,
    String gender_flag,
    String p_address_1,
    String p_address_2,
    String p_country,
    String p_state,
    String p_city,
    String p_district,
    String p_zip,
    String m_address_1,
    String m_address_2,
    String m_country,
    String m_state,
    String m_city,
    String m_district,
    String m_zip,
    String phone_list,
    String email_list,
    String fax_list,
    String prev_org_name,
    String prev_class_id,
    String prev_class_num,
    String prev_class_std,
    String prev_class_section,
    String prev_course_id,
    String prev_course_term,
    String prev_course_stream,
    String reason_for_leaving,
    String father_name,
    byte father_age,
    String f_nationality,
    String father_occ_type,
    String father_employer,
    String father_designation,
    double father_annual_income,
    String f_off_address_1,
    String f_phone_list,
    String mother_name,
    byte mother_age,
    String m_nationality,
    String mother_occ_type,
    String mother_employer,
    String mother_designation,
    double mother_annual_income,
    String m_off_address_1,
    String m_phone_list,
    String divorced_flag,
    String child_with,
    String roll_num,
    String academic_session,
    String adm_req_sts,
    String adm_req_sts_date,
    String student_id,
    String scholor_num,
    String form_recv_date,
    String form_recv_time,
    String prospectus_sale_date,
    String prospectus_sale_time,
    String prospectus_sold_by,
    double application_form_fee,
    String adm_academic_session,
    String entrance_exam_date,
    String entrance_exam_time_start,
    String entrance_exam_time_end,
    String exam_present_status,
    String building_id,
    String floor_num,
    String room_num,
    short max_mark,
    short obtained_mark,
    String grade,
    String fee_sch_date,
    String fee_deposit_date,
    String online_flag,
    String admission_mode,
    String course_stream_1,
    String course_stream_2,
    String course_stream_3,
    String course_stream_4,
    String apr_course_stream,
    String unv_1,
    String unv_rn_1,
    String gen_rank_1,
    String ctg_rank_1,
    String stt_rank_1,
    String yoa_1,
    String unv_2,
    String unv_rn_2,
    String gen_rank_2,
    String ctg_rank_2,
    String stt_rank_2,
    String yoa_2,
    float prev_mark_percent,
    String domecile_ind,
    String org_transport_req_ind,
    String org_hostel_req_ind,
    String cheque_num,
    String cheque_date,
    String bank_code,
    String bank_name,
    double cheque_amt,
    String lg_0_name,
    String lg_0_rel_type,
    String lg_0_address,
    String lg_0_phone,
    String lg_1_name,
    String lg_1_rel_type,
    String lg_1_address,
    String lg_1_phone,
    String st_cap_attr_1,
    String st_cap_attr_2,
    String st_cap_attr_3,
    String st_cap_attr_4,
    String st_cap_attr_5,
    String st_cap_attr_6,
    String st_cap_attr_7,
    String st_cap_attr_8,
    String allergy,
    String physical_disability,
    String health_problem,
    String health_problem_1,
    String health_problem_2,
    String health_problem_3,
    String health_problem_4,
    String health_problem_5,
    String health_problem_6,
    String health_problem_7,
    String health_problem_8,
    String health_problem_9,
    String health_problem_10,
    String health_problem_11,
    String health_problem_12,
    String enclosure_1,
    String enclosure_2,
    String enclosure_3,
    String enclosure_4,
    String enclosure_5,
    String enclosure_6,
    String enclosure_7,
    String enclosure_8,
    short seat_num,
    String reason_for_join,
    String remark,
    String place_of_birth,
    double adv_adm_fee,
    String payment_mode,
    String target_ptl_user_id,
    String adm_req_id_req,
    String adm_req_id_list
  )
  {
     this.org_id = org_id;
     this.adm_req_id = adm_req_id;
     this.application_form_num = application_form_num;
     this.applicant_id = applicant_id;
     this.student_photo_file = student_photo_file;
     this.mother_photo_file = mother_photo_file;
     this.father_photo_file = father_photo_file;
     this.class_id = class_id;
     this.class_num = class_num;
     this.class_std = class_std;
     this.class_section = class_section;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.name_initials = name_initials;
     this.student_f_name = student_f_name;
     this.student_m_name = student_m_name;
     this.student_l_name = student_l_name;
     this.dob = dob;
     this.age_on_date = age_on_date;
     this.age_year = age_year;
     this.age_month = age_month;
     this.age_day = age_day;
     this.s_nationality = s_nationality;
     this.religion = religion;
     this.student_ctg = student_ctg;
     this.gender_flag = gender_flag;
     this.p_address_1 = p_address_1;
     this.p_address_2 = p_address_2;
     this.p_country = p_country;
     this.p_state = p_state;
     this.p_city = p_city;
     this.p_district = p_district;
     this.p_zip = p_zip;
     this.m_address_1 = m_address_1;
     this.m_address_2 = m_address_2;
     this.m_country = m_country;
     this.m_state = m_state;
     this.m_city = m_city;
     this.m_district = m_district;
     this.m_zip = m_zip;
     this.phone_list = phone_list;
     this.email_list = email_list;
     this.fax_list = fax_list;
     this.prev_org_name = prev_org_name;
     this.prev_class_id = prev_class_id;
     this.prev_class_num = prev_class_num;
     this.prev_class_std = prev_class_std;
     this.prev_class_section = prev_class_section;
     this.prev_course_id = prev_course_id;
     this.prev_course_term = prev_course_term;
     this.prev_course_stream = prev_course_stream;
     this.reason_for_leaving = reason_for_leaving;
     this.father_name = father_name;
     this.father_age = father_age;
     this.f_nationality = f_nationality;
     this.father_occ_type = father_occ_type;
     this.father_employer = father_employer;
     this.father_designation = father_designation;
     this.father_annual_income = father_annual_income;
     this.f_off_address_1 = f_off_address_1;
     this.f_phone_list = f_phone_list;
     this.mother_name = mother_name;
     this.mother_age = mother_age;
     this.m_nationality = m_nationality;
     this.mother_occ_type = mother_occ_type;
     this.mother_employer = mother_employer;
     this.mother_designation = mother_designation;
     this.mother_annual_income = mother_annual_income;
     this.m_off_address_1 = m_off_address_1;
     this.m_phone_list = m_phone_list;
     this.divorced_flag = divorced_flag;
     this.child_with = child_with;
     this.roll_num = roll_num;
     this.academic_session = academic_session;
     this.adm_req_sts = adm_req_sts;
     this.adm_req_sts_date = adm_req_sts_date;
     this.student_id = student_id;
     this.scholor_num = scholor_num;
     this.form_recv_date = form_recv_date;
     this.form_recv_time = form_recv_time;
     this.prospectus_sale_date = prospectus_sale_date;
     this.prospectus_sale_time = prospectus_sale_time;
     this.prospectus_sold_by = prospectus_sold_by;
     this.application_form_fee = application_form_fee;
     this.adm_academic_session = adm_academic_session;
     this.entrance_exam_date = entrance_exam_date;
     this.entrance_exam_time_start = entrance_exam_time_start;
     this.entrance_exam_time_end = entrance_exam_time_end;
     this.exam_present_status = exam_present_status;
     this.building_id = building_id;
     this.floor_num = floor_num;
     this.room_num = room_num;
     this.max_mark = max_mark;
     this.obtained_mark = obtained_mark;
     this.grade = grade;
     this.fee_sch_date = fee_sch_date;
     this.fee_deposit_date = fee_deposit_date;
     this.online_flag = online_flag;
     this.admission_mode = admission_mode;
     this.course_stream_1 = course_stream_1;
     this.course_stream_2 = course_stream_2;
     this.course_stream_3 = course_stream_3;
     this.course_stream_4 = course_stream_4;
     this.apr_course_stream = apr_course_stream;
     this.unv_1 = unv_1;
     this.unv_rn_1 = unv_rn_1;
     this.gen_rank_1 = gen_rank_1;
     this.ctg_rank_1 = ctg_rank_1;
     this.stt_rank_1 = stt_rank_1;
     this.yoa_1 = yoa_1;
     this.unv_2 = unv_2;
     this.unv_rn_2 = unv_rn_2;
     this.gen_rank_2 = gen_rank_2;
     this.ctg_rank_2 = ctg_rank_2;
     this.stt_rank_2 = stt_rank_2;
     this.yoa_2 = yoa_2;
     this.prev_mark_percent = prev_mark_percent;
     this.domecile_ind = domecile_ind;
     this.org_transport_req_ind = org_transport_req_ind;
     this.org_hostel_req_ind = org_hostel_req_ind;
     this.cheque_num = cheque_num;
     this.cheque_date = cheque_date;
     this.bank_code = bank_code;
     this.bank_name = bank_name;
     this.cheque_amt = cheque_amt;
     this.lg_0_name = lg_0_name;
     this.lg_0_rel_type = lg_0_rel_type;
     this.lg_0_address = lg_0_address;
     this.lg_0_phone = lg_0_phone;
     this.lg_1_name = lg_1_name;
     this.lg_1_rel_type = lg_1_rel_type;
     this.lg_1_address = lg_1_address;
     this.lg_1_phone = lg_1_phone;
     this.st_cap_attr_1 = st_cap_attr_1;
     this.st_cap_attr_2 = st_cap_attr_2;
     this.st_cap_attr_3 = st_cap_attr_3;
     this.st_cap_attr_4 = st_cap_attr_4;
     this.st_cap_attr_5 = st_cap_attr_5;
     this.st_cap_attr_6 = st_cap_attr_6;
     this.st_cap_attr_7 = st_cap_attr_7;
     this.st_cap_attr_8 = st_cap_attr_8;
     this.allergy = allergy;
     this.physical_disability = physical_disability;
     this.health_problem = health_problem;
     this.health_problem_1 = health_problem_1;
     this.health_problem_2 = health_problem_2;
     this.health_problem_3 = health_problem_3;
     this.health_problem_4 = health_problem_4;
     this.health_problem_5 = health_problem_5;
     this.health_problem_6 = health_problem_6;
     this.health_problem_7 = health_problem_7;
     this.health_problem_8 = health_problem_8;
     this.health_problem_9 = health_problem_9;
     this.health_problem_10 = health_problem_10;
     this.health_problem_11 = health_problem_11;
     this.health_problem_12 = health_problem_12;
     this.enclosure_1 = enclosure_1;
     this.enclosure_2 = enclosure_2;
     this.enclosure_3 = enclosure_3;
     this.enclosure_4 = enclosure_4;
     this.enclosure_5 = enclosure_5;
     this.enclosure_6 = enclosure_6;
     this.enclosure_7 = enclosure_7;
     this.enclosure_8 = enclosure_8;
     this.seat_num = seat_num;
     this.reason_for_join = reason_for_join;
     this.remark = remark;
     this.place_of_birth = place_of_birth;
     this.adv_adm_fee = adv_adm_fee;
     this.payment_mode = payment_mode;
     this.target_ptl_user_id = target_ptl_user_id;
     this.adm_req_id_req = adm_req_id_req;
     this.adm_req_id_list = adm_req_id_list;
  }

  public String getorg_id()                           { return org_id; }
  public String getadm_req_id()                         { return adm_req_id; }
  public String getapplication_form_num()                    { return application_form_num; }
  public String getapplicant_id()                        { return applicant_id; }
  public String getstudent_photo_file()                     { return student_photo_file; }
  public String getmother_photo_file()                     { return mother_photo_file; }
  public String getfather_photo_file()                     { return father_photo_file; }
  public String getclass_id()                          { return class_id; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getclass_section()                       { return class_section; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getname_initials()                       { return name_initials; }
  public String getstudent_f_name()                       { return student_f_name; }
  public String getstudent_m_name()                       { return student_m_name; }
  public String getstudent_l_name()                       { return student_l_name; }
  public String getdob()                            { return dob; }
  public String getage_on_date()                        { return age_on_date; }
  public byte getage_year()                           { return age_year; }
  public String getage_month()                         { return age_month; }
  public byte getage_day()                           { return age_day; }
  public String gets_nationality()                       { return s_nationality; }
  public String getreligion()                          { return religion; }
  public String getstudent_ctg()                        { return student_ctg; }
  public String getgender_flag()                        { return gender_flag; }
  public String getp_address_1()                        { return p_address_1; }
  public String getp_address_2()                        { return p_address_2; }
  public String getp_country()                         { return p_country; }
  public String getp_state()                          { return p_state; }
  public String getp_city()                           { return p_city; }
  public String getp_district()                         { return p_district; }
  public String getp_zip()                           { return p_zip; }
  public String getm_address_1()                        { return m_address_1; }
  public String getm_address_2()                        { return m_address_2; }
  public String getm_country()                         { return m_country; }
  public String getm_state()                          { return m_state; }
  public String getm_city()                           { return m_city; }
  public String getm_district()                         { return m_district; }
  public String getm_zip()                           { return m_zip; }
  public String getphone_list()                         { return phone_list; }
  public String getemail_list()                         { return email_list; }
  public String getfax_list()                          { return fax_list; }
  public String getprev_org_name()                       { return prev_org_name; }
  public String getprev_class_id()                       { return prev_class_id; }
  public String getprev_class_num()                       { return prev_class_num; }
  public String getprev_class_std()                       { return prev_class_std; }
  public String getprev_class_section()                     { return prev_class_section; }
  public String getprev_course_id()                       { return prev_course_id; }
  public String getprev_course_term()                      { return prev_course_term; }
  public String getprev_course_stream()                     { return prev_course_stream; }
  public String getreason_for_leaving()                     { return reason_for_leaving; }
  public String getfather_name()                        { return father_name; }
  public byte getfather_age()                          { return father_age; }
  public String getf_nationality()                       { return f_nationality; }
  public String getfather_occ_type()                      { return father_occ_type; }
  public String getfather_employer()                      { return father_employer; }
  public String getfather_designation()                     { return father_designation; }
  public double getfather_annual_income()                    { return father_annual_income; }
  public String getf_off_address_1()                      { return f_off_address_1; }
  public String getf_phone_list()                        { return f_phone_list; }
  public String getmother_name()                        { return mother_name; }
  public byte getmother_age()                          { return mother_age; }
  public String getm_nationality()                       { return m_nationality; }
  public String getmother_occ_type()                      { return mother_occ_type; }
  public String getmother_employer()                      { return mother_employer; }
  public String getmother_designation()                     { return mother_designation; }
  public double getmother_annual_income()                    { return mother_annual_income; }
  public String getm_off_address_1()                      { return m_off_address_1; }
  public String getm_phone_list()                        { return m_phone_list; }
  public String getdivorced_flag()                       { return divorced_flag; }
  public String getchild_with()                         { return child_with; }
  public String getroll_num()                          { return roll_num; }
  public String getacademic_session()                      { return academic_session; }
  public String getadm_req_sts()                        { return adm_req_sts; }
  public String getadm_req_sts_date()                      { return adm_req_sts_date; }
  public String getstudent_id()                         { return student_id; }
  public String getscholor_num()                        { return scholor_num; }
  public String getform_recv_date()                       { return form_recv_date; }
  public String getform_recv_time()                       { return form_recv_time; }
  public String getprospectus_sale_date()                    { return prospectus_sale_date; }
  public String getprospectus_sale_time()                    { return prospectus_sale_time; }
  public String getprospectus_sold_by()                     { return prospectus_sold_by; }
  public double getapplication_form_fee()                    { return application_form_fee; }
  public String getadm_academic_session()                    { return adm_academic_session; }
  public String getentrance_exam_date()                     { return entrance_exam_date; }
  public String getentrance_exam_time_start()                  { return entrance_exam_time_start; }
  public String getentrance_exam_time_end()                   { return entrance_exam_time_end; }
  public String getexam_present_status()                    { return exam_present_status; }
  public String getbuilding_id()                        { return building_id; }
  public String getfloor_num()                         { return floor_num; }
  public String getroom_num()                          { return room_num; }
  public short getmax_mark()                          { return max_mark; }
  public short getobtained_mark()                        { return obtained_mark; }
  public String getgrade()                           { return grade; }
  public String getfee_sch_date()                        { return fee_sch_date; }
  public String getfee_deposit_date()                      { return fee_deposit_date; }
  public String getonline_flag()                        { return online_flag; }
  public String getadmission_mode()                       { return admission_mode; }
  public String getcourse_stream_1()                      { return course_stream_1; }
  public String getcourse_stream_2()                      { return course_stream_2; }
  public String getcourse_stream_3()                      { return course_stream_3; }
  public String getcourse_stream_4()                      { return course_stream_4; }
  public String getapr_course_stream()                     { return apr_course_stream; }
  public String getunv_1()                           { return unv_1; }
  public String getunv_rn_1()                          { return unv_rn_1; }
  public String getgen_rank_1()                         { return gen_rank_1; }
  public String getctg_rank_1()                         { return ctg_rank_1; }
  public String getstt_rank_1()                         { return stt_rank_1; }
  public String getyoa_1()                           { return yoa_1; }
  public String getunv_2()                           { return unv_2; }
  public String getunv_rn_2()                          { return unv_rn_2; }
  public String getgen_rank_2()                         { return gen_rank_2; }
  public String getctg_rank_2()                         { return ctg_rank_2; }
  public String getstt_rank_2()                         { return stt_rank_2; }
  public String getyoa_2()                           { return yoa_2; }
  public float getprev_mark_percent()                      { return prev_mark_percent; }
  public String getdomecile_ind()                        { return domecile_ind; }
  public String getorg_transport_req_ind()                   { return org_transport_req_ind; }
  public String getorg_hostel_req_ind()                     { return org_hostel_req_ind; }
  public String getcheque_num()                         { return cheque_num; }
  public String getcheque_date()                        { return cheque_date; }
  public String getbank_code()                         { return bank_code; }
  public String getbank_name()                         { return bank_name; }
  public double getcheque_amt()                         { return cheque_amt; }
  public String getlg_0_name()                         { return lg_0_name; }
  public String getlg_0_rel_type()                       { return lg_0_rel_type; }
  public String getlg_0_address()                        { return lg_0_address; }
  public String getlg_0_phone()                         { return lg_0_phone; }
  public String getlg_1_name()                         { return lg_1_name; }
  public String getlg_1_rel_type()                       { return lg_1_rel_type; }
  public String getlg_1_address()                        { return lg_1_address; }
  public String getlg_1_phone()                         { return lg_1_phone; }
  public String getst_cap_attr_1()                       { return st_cap_attr_1; }
  public String getst_cap_attr_2()                       { return st_cap_attr_2; }
  public String getst_cap_attr_3()                       { return st_cap_attr_3; }
  public String getst_cap_attr_4()                       { return st_cap_attr_4; }
  public String getst_cap_attr_5()                       { return st_cap_attr_5; }
  public String getst_cap_attr_6()                       { return st_cap_attr_6; }
  public String getst_cap_attr_7()                       { return st_cap_attr_7; }
  public String getst_cap_attr_8()                       { return st_cap_attr_8; }
  public String getallergy()                          { return allergy; }
  public String getphysical_disability()                    { return physical_disability; }
  public String gethealth_problem()                       { return health_problem; }
  public String gethealth_problem_1()                      { return health_problem_1; }
  public String gethealth_problem_2()                      { return health_problem_2; }
  public String gethealth_problem_3()                      { return health_problem_3; }
  public String gethealth_problem_4()                      { return health_problem_4; }
  public String gethealth_problem_5()                      { return health_problem_5; }
  public String gethealth_problem_6()                      { return health_problem_6; }
  public String gethealth_problem_7()                      { return health_problem_7; }
  public String gethealth_problem_8()                      { return health_problem_8; }
  public String gethealth_problem_9()                      { return health_problem_9; }
  public String gethealth_problem_10()                     { return health_problem_10; }
  public String gethealth_problem_11()                     { return health_problem_11; }
  public String gethealth_problem_12()                     { return health_problem_12; }
  public String getenclosure_1()                        { return enclosure_1; }
  public String getenclosure_2()                        { return enclosure_2; }
  public String getenclosure_3()                        { return enclosure_3; }
  public String getenclosure_4()                        { return enclosure_4; }
  public String getenclosure_5()                        { return enclosure_5; }
  public String getenclosure_6()                        { return enclosure_6; }
  public String getenclosure_7()                        { return enclosure_7; }
  public String getenclosure_8()                        { return enclosure_8; }
  public short getseat_num()                          { return seat_num; }
  public String getreason_for_join()                      { return reason_for_join; }
  public String getremark()                           { return remark; }
  public String getplace_of_birth()                       { return place_of_birth; }
  public double getadv_adm_fee()                        { return adv_adm_fee; }
  public String getpayment_mode()                        { return payment_mode; }
  public String gettarget_ptl_user_id()                     { return target_ptl_user_id; }
  public String getadm_req_id_req()                       { return adm_req_id_req; }
  public String getadm_req_id_list()                      { return adm_req_id_list; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setadm_req_id(String adm_req_id )                { this.adm_req_id = adm_req_id; }
  public void  setapplication_form_num(String application_form_num )      { this.application_form_num = application_form_num; }
  public void  setapplicant_id(String applicant_id )              { this.applicant_id = applicant_id; }
  public void  setstudent_photo_file(String student_photo_file )        { this.student_photo_file = student_photo_file; }
  public void  setmother_photo_file(String mother_photo_file )         { this.mother_photo_file = mother_photo_file; }
  public void  setfather_photo_file(String father_photo_file )         { this.father_photo_file = father_photo_file; }
  public void  setclass_id(String class_id )                  { this.class_id = class_id; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setclass_section(String class_section )             { this.class_section = class_section; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setname_initials(String name_initials )             { this.name_initials = name_initials; }
  public void  setstudent_f_name(String student_f_name )            { this.student_f_name = student_f_name; }
  public void  setstudent_m_name(String student_m_name )            { this.student_m_name = student_m_name; }
  public void  setstudent_l_name(String student_l_name )            { this.student_l_name = student_l_name; }
  public void  setdob(String dob )                       { this.dob = dob; }
  public void  setage_on_date(String age_on_date )               { this.age_on_date = age_on_date; }
  public void  setage_year(byte age_year )                   { this.age_year = age_year; }
  public void  setage_month(String age_month )                 { this.age_month = age_month; }
  public void  setage_day(byte age_day )                    { this.age_day = age_day; }
  public void  sets_nationality(String s_nationality )             { this.s_nationality = s_nationality; }
  public void  setreligion(String religion )                  { this.religion = religion; }
  public void  setstudent_ctg(String student_ctg )               { this.student_ctg = student_ctg; }
  public void  setgender_flag(String gender_flag )               { this.gender_flag = gender_flag; }
  public void  setp_address_1(String p_address_1 )               { this.p_address_1 = p_address_1; }
  public void  setp_address_2(String p_address_2 )               { this.p_address_2 = p_address_2; }
  public void  setp_country(String p_country )                 { this.p_country = p_country; }
  public void  setp_state(String p_state )                   { this.p_state = p_state; }
  public void  setp_city(String p_city )                    { this.p_city = p_city; }
  public void  setp_district(String p_district )                { this.p_district = p_district; }
  public void  setp_zip(String p_zip )                     { this.p_zip = p_zip; }
  public void  setm_address_1(String m_address_1 )               { this.m_address_1 = m_address_1; }
  public void  setm_address_2(String m_address_2 )               { this.m_address_2 = m_address_2; }
  public void  setm_country(String m_country )                 { this.m_country = m_country; }
  public void  setm_state(String m_state )                   { this.m_state = m_state; }
  public void  setm_city(String m_city )                    { this.m_city = m_city; }
  public void  setm_district(String m_district )                { this.m_district = m_district; }
  public void  setm_zip(String m_zip )                     { this.m_zip = m_zip; }
  public void  setphone_list(String phone_list )                { this.phone_list = phone_list; }
  public void  setemail_list(String email_list )                { this.email_list = email_list; }
  public void  setfax_list(String fax_list )                  { this.fax_list = fax_list; }
  public void  setprev_org_name(String prev_org_name )             { this.prev_org_name = prev_org_name; }
  public void  setprev_class_id(String prev_class_id )             { this.prev_class_id = prev_class_id; }
  public void  setprev_class_num(String prev_class_num )            { this.prev_class_num = prev_class_num; }
  public void  setprev_class_std(String prev_class_std )            { this.prev_class_std = prev_class_std; }
  public void  setprev_class_section(String prev_class_section )        { this.prev_class_section = prev_class_section; }
  public void  setprev_course_id(String prev_course_id )            { this.prev_course_id = prev_course_id; }
  public void  setprev_course_term(String prev_course_term )          { this.prev_course_term = prev_course_term; }
  public void  setprev_course_stream(String prev_course_stream )        { this.prev_course_stream = prev_course_stream; }
  public void  setreason_for_leaving(String reason_for_leaving )        { this.reason_for_leaving = reason_for_leaving; }
  public void  setfather_name(String father_name )               { this.father_name = father_name; }
  public void  setfather_age(byte father_age )                 { this.father_age = father_age; }
  public void  setf_nationality(String f_nationality )             { this.f_nationality = f_nationality; }
  public void  setfather_occ_type(String father_occ_type )           { this.father_occ_type = father_occ_type; }
  public void  setfather_employer(String father_employer )           { this.father_employer = father_employer; }
  public void  setfather_designation(String father_designation )        { this.father_designation = father_designation; }
  public void  setfather_annual_income(double father_annual_income )      { this.father_annual_income = father_annual_income; }
  public void  setf_off_address_1(String f_off_address_1 )           { this.f_off_address_1 = f_off_address_1; }
  public void  setf_phone_list(String f_phone_list )              { this.f_phone_list = f_phone_list; }
  public void  setmother_name(String mother_name )               { this.mother_name = mother_name; }
  public void  setmother_age(byte mother_age )                 { this.mother_age = mother_age; }
  public void  setm_nationality(String m_nationality )             { this.m_nationality = m_nationality; }
  public void  setmother_occ_type(String mother_occ_type )           { this.mother_occ_type = mother_occ_type; }
  public void  setmother_employer(String mother_employer )           { this.mother_employer = mother_employer; }
  public void  setmother_designation(String mother_designation )        { this.mother_designation = mother_designation; }
  public void  setmother_annual_income(double mother_annual_income )      { this.mother_annual_income = mother_annual_income; }
  public void  setm_off_address_1(String m_off_address_1 )           { this.m_off_address_1 = m_off_address_1; }
  public void  setm_phone_list(String m_phone_list )              { this.m_phone_list = m_phone_list; }
  public void  setdivorced_flag(String divorced_flag )             { this.divorced_flag = divorced_flag; }
  public void  setchild_with(String child_with )                { this.child_with = child_with; }
  public void  setroll_num(String roll_num )                  { this.roll_num = roll_num; }
  public void  setacademic_session(String academic_session )          { this.academic_session = academic_session; }
  public void  setadm_req_sts(String adm_req_sts )               { this.adm_req_sts = adm_req_sts; }
  public void  setadm_req_sts_date(String adm_req_sts_date )          { this.adm_req_sts_date = adm_req_sts_date; }
  public void  setstudent_id(String student_id )                { this.student_id = student_id; }
  public void  setscholor_num(String scholor_num )               { this.scholor_num = scholor_num; }
  public void  setform_recv_date(String form_recv_date )            { this.form_recv_date = form_recv_date; }
  public void  setform_recv_time(String form_recv_time )            { this.form_recv_time = form_recv_time; }
  public void  setprospectus_sale_date(String prospectus_sale_date )      { this.prospectus_sale_date = prospectus_sale_date; }
  public void  setprospectus_sale_time(String prospectus_sale_time )      { this.prospectus_sale_time = prospectus_sale_time; }
  public void  setprospectus_sold_by(String prospectus_sold_by )        { this.prospectus_sold_by = prospectus_sold_by; }
  public void  setapplication_form_fee(double application_form_fee )      { this.application_form_fee = application_form_fee; }
  public void  setadm_academic_session(String adm_academic_session )      { this.adm_academic_session = adm_academic_session; }
  public void  setentrance_exam_date(String entrance_exam_date )        { this.entrance_exam_date = entrance_exam_date; }
  public void  setentrance_exam_time_start(String entrance_exam_time_start )  { this.entrance_exam_time_start = entrance_exam_time_start; }
  public void  setentrance_exam_time_end(String entrance_exam_time_end )    { this.entrance_exam_time_end = entrance_exam_time_end; }
  public void  setexam_present_status(String exam_present_status )       { this.exam_present_status = exam_present_status; }
  public void  setbuilding_id(String building_id )               { this.building_id = building_id; }
  public void  setfloor_num(String floor_num )                 { this.floor_num = floor_num; }
  public void  setroom_num(String room_num )                  { this.room_num = room_num; }
  public void  setmax_mark(short max_mark )                   { this.max_mark = max_mark; }
  public void  setobtained_mark(short obtained_mark )              { this.obtained_mark = obtained_mark; }
  public void  setgrade(String grade )                     { this.grade = grade; }
  public void  setfee_sch_date(String fee_sch_date )              { this.fee_sch_date = fee_sch_date; }
  public void  setfee_deposit_date(String fee_deposit_date )          { this.fee_deposit_date = fee_deposit_date; }
  public void  setonline_flag(String online_flag )               { this.online_flag = online_flag; }
  public void  setadmission_mode(String admission_mode )            { this.admission_mode = admission_mode; }
  public void  setcourse_stream_1(String course_stream_1 )           { this.course_stream_1 = course_stream_1; }
  public void  setcourse_stream_2(String course_stream_2 )           { this.course_stream_2 = course_stream_2; }
  public void  setcourse_stream_3(String course_stream_3 )           { this.course_stream_3 = course_stream_3; }
  public void  setcourse_stream_4(String course_stream_4 )           { this.course_stream_4 = course_stream_4; }
  public void  setapr_course_stream(String apr_course_stream )         { this.apr_course_stream = apr_course_stream; }
  public void  setunv_1(String unv_1 )                     { this.unv_1 = unv_1; }
  public void  setunv_rn_1(String unv_rn_1 )                  { this.unv_rn_1 = unv_rn_1; }
  public void  setgen_rank_1(String gen_rank_1 )                { this.gen_rank_1 = gen_rank_1; }
  public void  setctg_rank_1(String ctg_rank_1 )                { this.ctg_rank_1 = ctg_rank_1; }
  public void  setstt_rank_1(String stt_rank_1 )                { this.stt_rank_1 = stt_rank_1; }
  public void  setyoa_1(String yoa_1 )                     { this.yoa_1 = yoa_1; }
  public void  setunv_2(String unv_2 )                     { this.unv_2 = unv_2; }
  public void  setunv_rn_2(String unv_rn_2 )                  { this.unv_rn_2 = unv_rn_2; }
  public void  setgen_rank_2(String gen_rank_2 )                { this.gen_rank_2 = gen_rank_2; }
  public void  setctg_rank_2(String ctg_rank_2 )                { this.ctg_rank_2 = ctg_rank_2; }
  public void  setstt_rank_2(String stt_rank_2 )                { this.stt_rank_2 = stt_rank_2; }
  public void  setyoa_2(String yoa_2 )                     { this.yoa_2 = yoa_2; }
  public void  setprev_mark_percent(float prev_mark_percent )          { this.prev_mark_percent = prev_mark_percent; }
  public void  setdomecile_ind(String domecile_ind )              { this.domecile_ind = domecile_ind; }
  public void  setorg_transport_req_ind(String org_transport_req_ind )     { this.org_transport_req_ind = org_transport_req_ind; }
  public void  setorg_hostel_req_ind(String org_hostel_req_ind )        { this.org_hostel_req_ind = org_hostel_req_ind; }
  public void  setcheque_num(String cheque_num )                { this.cheque_num = cheque_num; }
  public void  setcheque_date(String cheque_date )               { this.cheque_date = cheque_date; }
  public void  setbank_code(String bank_code )                 { this.bank_code = bank_code; }
  public void  setbank_name(String bank_name )                 { this.bank_name = bank_name; }
  public void  setcheque_amt(double cheque_amt )                { this.cheque_amt = cheque_amt; }
  public void  setlg_0_name(String lg_0_name )                 { this.lg_0_name = lg_0_name; }
  public void  setlg_0_rel_type(String lg_0_rel_type )             { this.lg_0_rel_type = lg_0_rel_type; }
  public void  setlg_0_address(String lg_0_address )              { this.lg_0_address = lg_0_address; }
  public void  setlg_0_phone(String lg_0_phone )                { this.lg_0_phone = lg_0_phone; }
  public void  setlg_1_name(String lg_1_name )                 { this.lg_1_name = lg_1_name; }
  public void  setlg_1_rel_type(String lg_1_rel_type )             { this.lg_1_rel_type = lg_1_rel_type; }
  public void  setlg_1_address(String lg_1_address )              { this.lg_1_address = lg_1_address; }
  public void  setlg_1_phone(String lg_1_phone )                { this.lg_1_phone = lg_1_phone; }
  public void  setst_cap_attr_1(String st_cap_attr_1 )             { this.st_cap_attr_1 = st_cap_attr_1; }
  public void  setst_cap_attr_2(String st_cap_attr_2 )             { this.st_cap_attr_2 = st_cap_attr_2; }
  public void  setst_cap_attr_3(String st_cap_attr_3 )             { this.st_cap_attr_3 = st_cap_attr_3; }
  public void  setst_cap_attr_4(String st_cap_attr_4 )             { this.st_cap_attr_4 = st_cap_attr_4; }
  public void  setst_cap_attr_5(String st_cap_attr_5 )             { this.st_cap_attr_5 = st_cap_attr_5; }
  public void  setst_cap_attr_6(String st_cap_attr_6 )             { this.st_cap_attr_6 = st_cap_attr_6; }
  public void  setst_cap_attr_7(String st_cap_attr_7 )             { this.st_cap_attr_7 = st_cap_attr_7; }
  public void  setst_cap_attr_8(String st_cap_attr_8 )             { this.st_cap_attr_8 = st_cap_attr_8; }
  public void  setallergy(String allergy )                   { this.allergy = allergy; }
  public void  setphysical_disability(String physical_disability )       { this.physical_disability = physical_disability; }
  public void  sethealth_problem(String health_problem )            { this.health_problem = health_problem; }
  public void  sethealth_problem_1(String health_problem_1 )          { this.health_problem_1 = health_problem_1; }
  public void  sethealth_problem_2(String health_problem_2 )          { this.health_problem_2 = health_problem_2; }
  public void  sethealth_problem_3(String health_problem_3 )          { this.health_problem_3 = health_problem_3; }
  public void  sethealth_problem_4(String health_problem_4 )          { this.health_problem_4 = health_problem_4; }
  public void  sethealth_problem_5(String health_problem_5 )          { this.health_problem_5 = health_problem_5; }
  public void  sethealth_problem_6(String health_problem_6 )          { this.health_problem_6 = health_problem_6; }
  public void  sethealth_problem_7(String health_problem_7 )          { this.health_problem_7 = health_problem_7; }
  public void  sethealth_problem_8(String health_problem_8 )          { this.health_problem_8 = health_problem_8; }
  public void  sethealth_problem_9(String health_problem_9 )          { this.health_problem_9 = health_problem_9; }
  public void  sethealth_problem_10(String health_problem_10 )         { this.health_problem_10 = health_problem_10; }
  public void  sethealth_problem_11(String health_problem_11 )         { this.health_problem_11 = health_problem_11; }
  public void  sethealth_problem_12(String health_problem_12 )         { this.health_problem_12 = health_problem_12; }
  public void  setenclosure_1(String enclosure_1 )               { this.enclosure_1 = enclosure_1; }
  public void  setenclosure_2(String enclosure_2 )               { this.enclosure_2 = enclosure_2; }
  public void  setenclosure_3(String enclosure_3 )               { this.enclosure_3 = enclosure_3; }
  public void  setenclosure_4(String enclosure_4 )               { this.enclosure_4 = enclosure_4; }
  public void  setenclosure_5(String enclosure_5 )               { this.enclosure_5 = enclosure_5; }
  public void  setenclosure_6(String enclosure_6 )               { this.enclosure_6 = enclosure_6; }
  public void  setenclosure_7(String enclosure_7 )               { this.enclosure_7 = enclosure_7; }
  public void  setenclosure_8(String enclosure_8 )               { this.enclosure_8 = enclosure_8; }
  public void  setseat_num(short seat_num )                   { this.seat_num = seat_num; }
  public void  setreason_for_join(String reason_for_join )           { this.reason_for_join = reason_for_join; }
  public void  setremark(String remark )                    { this.remark = remark; }
  public void  setplace_of_birth(String place_of_birth )            { this.place_of_birth = place_of_birth; }
  public void  setadv_adm_fee(double adv_adm_fee )               { this.adv_adm_fee = adv_adm_fee; }
  public void  setpayment_mode(String payment_mode )              { this.payment_mode = payment_mode; }
  public void  settarget_ptl_user_id(String target_ptl_user_id )        { this.target_ptl_user_id = target_ptl_user_id; }
  public void  setadm_req_id_req(String adm_req_id_req )            { this.adm_req_id_req = adm_req_id_req; }
  public void  setadm_req_id_list(String adm_req_id_list )           { this.adm_req_id_list = adm_req_id_list; }
}