package sstdb.ees.EesExam;


public class EesExamPkeyObj
{
  public String                                 org_id;
  public String                                 exam_id;
}