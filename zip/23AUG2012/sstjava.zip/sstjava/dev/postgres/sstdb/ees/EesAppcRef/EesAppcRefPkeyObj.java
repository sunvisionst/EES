package sstdb.ees.EesAppcRef;


public class EesAppcRefPkeyObj
{
  public String                                 org_id;
  public String                                 applicant_id;
  public byte                                  seq_num;
}