package sstdb.ees.EesEventRegStud;


public class EesEventRegStudTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 activity_id;
  public String                                 student_id;
  public String                                 event_id;
  public String                                 status;
  public String                                 status_date;





  public short                                  org_id_ind;
  public short                                  activity_id_ind;
  public short                                  student_id_ind;
  public short                                  event_id_ind;
  public short                                  status_ind;
  public short                                  status_date_ind;


  public EesEventRegStudTabObj(){}


  public EesEventRegStudTabObj
  (
    String org_id,
    String activity_id,
    String student_id,
    String event_id,
    String status,
    String status_date
  )
  {
     this.org_id = org_id;
     this.activity_id = activity_id;
     this.student_id = student_id;
     this.event_id = event_id;
     this.status = status;
     this.status_date = status_date;
  }

  public String getorg_id()                           { return org_id; }
  public String getactivity_id()                        { return activity_id; }
  public String getstudent_id()                         { return student_id; }
  public String getevent_id()                          { return event_id; }
  public String getstatus()                           { return status; }
  public String getstatus_date()                        { return status_date; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setactivity_id(String activity_id )               { this.activity_id = activity_id; }
  public void  setstudent_id(String student_id )                { this.student_id = student_id; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setstatus(String status )                    { this.status = status; }
  public void  setstatus_date(String status_date )               { this.status_date = status_date; }
}