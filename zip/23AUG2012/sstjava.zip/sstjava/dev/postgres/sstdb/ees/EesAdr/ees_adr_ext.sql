CREATE TABLE EES_ADR_EXT
(
  org_id                                                                                              VARCHAR(10),
  employee_id                                                                                         VARCHAR(20),
  period_num                                                                                          NUMERIC(2),
  adr_date                                                                                            VARCHAR(8),
  topic_id                                                                                            VARCHAR(10),
  adr_start_time                                                                                      VARCHAR(6),
  adr_end_time                                                                                        VARCHAR(6),
  lecture_num                                                                                         VARCHAR(10),
  subject_code                                                                                        VARCHAR(20),
  topic_percent_covered                                                                               NUMERIC(5,2),
  class_id                                                                                            VARCHAR(20),
  class_num                                                                                           VARCHAR(10),
  class_std                                                                                           VARCHAR(10),
  class_section                                                                                       VARCHAR(10),
  course_id                                                                                           VARCHAR(10),
  course_term                                                                                         VARCHAR(10),
  course_stream                                                                                       VARCHAR(10)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       EMPLOYEE_ID                                                                                         CHAR(20),
       PERIOD_NUM                                                                                          CHAR(2),
       ADR_DATE                                                                                            CHAR(8),
       TOPIC_ID                                                                                            CHAR(10),
       ADR_START_TIME                                                                                      CHAR(6),
       ADR_END_TIME                                                                                        CHAR(6),
       LECTURE_NUM                                                                                         CHAR(10),
       SUBJECT_CODE                                                                                        CHAR(20),
       TOPIC_PERCENT_COVERED                                                                               CHAR(5),
       CLASS_ID                                                                                            CHAR(20),
       CLASS_NUM                                                                                           CHAR(10),
       CLASS_STD                                                                                           CHAR(10),
       CLASS_SECTION                                                                                       CHAR(10),
       COURSE_ID                                                                                           CHAR(10),
       COURSE_TERM                                                                                         CHAR(10),
       COURSE_STREAM                                                                                       CHAR(10)
    )
  )
  LOCATION ('ees_adr_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
