ALTER TABLE           EES_CLASS
  ADD                 CONSTRAINT EES_CLASS_PK
  PRIMARY             KEY
  ( ORG_ID, CLASS_ID )
;
