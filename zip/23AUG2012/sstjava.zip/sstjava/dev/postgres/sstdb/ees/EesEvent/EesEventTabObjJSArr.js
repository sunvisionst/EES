
var lEesEventTabObjJSArr = new Array();
<%
{
   if ( lEesEventTabObjArrCache != null && lEesEventTabObjArrCache.size() > 0 )
   {
%>
       lEesEventTabObjJSArr = new Array(<%=lEesEventTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesEventTabObjArrCache.size(); lRecNum++ )
       {
          EesEventTabObj lEesEventTabObj    =    new EesEventTabObj();
          lEesEventTabObj = (EesEventTabObj)lEesEventTabObjArrCache.get(lRecNum);
%>
          lEesEventTabObjJSArr[<%=lRecNum%>] = new constructorEesEvent
          (
          "<%=lEesEventTabObj.org_id%>",
          "<%=lEesEventTabObj.event_id%>",
          "<%=lEesEventTabObj.event_type%>",
          "<%=lEesEventTabObj.event_desc%>",
          "<%=lEesEventTabObj.status%>",
          "<%=lEesEventTabObj.event_start_date%>",
          "<%=lEesEventTabObj.event_close_date%>",
          "<%=lEesEventTabObj.ptl_publish_ind%>",
          "<%=lEesEventTabObj.ptl_publish_start_date%>",
          "<%=lEesEventTabObj.ptl_publish_close_date%>",
          "<%=lEesEventTabObj.ptl_user_id%>",
          "<%=lEesEventTabObj.rec_cre_by%>",
          "<%=lEesEventTabObj.rec_cre_date%>",
          "<%=lEesEventTabObj.rec_cre_time%>",
          "<%=lEesEventTabObj.rec_upd_by%>",
          "<%=lEesEventTabObj.rec_upd_date%>",
          "<%=lEesEventTabObj.rec_upd_time%>"
          );
<%
       }
   }
}
%>


