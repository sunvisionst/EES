package sstdb.ees.EesAlumni;


public class EesAlumniPkeyObj
{
  public String                                 org_id;
  public String                                 alumni_id;
}