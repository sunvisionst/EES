CREATE TABLE EES_APPC_PREV_MARK_EXT
(
  org_id                                                                                              VARCHAR(10),
  applicant_id                                                                                        VARCHAR(25),
  stmm_1                                                                                              NUMERIC(9,2),
  stmo_1                                                                                              NUMERIC(9,2),
  spmm_1                                                                                              NUMERIC(9,2),
  spmo_1                                                                                              NUMERIC(9,2),
  stmm_2                                                                                              NUMERIC(9,2),
  stmo_2                                                                                              NUMERIC(9,2),
  spmm_2                                                                                              NUMERIC(9,2),
  spmo_2                                                                                              NUMERIC(9,2),
  stmm_3                                                                                              NUMERIC(9,2),
  stmo_3                                                                                              NUMERIC(9,2),
  spmm_3                                                                                              NUMERIC(9,2),
  spmo_3                                                                                              NUMERIC(9,2),
  stmm_4                                                                                              NUMERIC(9,2),
  stmo_4                                                                                              NUMERIC(9,2),
  spmm_4                                                                                              NUMERIC(9,2),
  spmo_4                                                                                              NUMERIC(9,2),
  adm_req_id_req                                                                                      VARCHAR(30),
  adm_req_id_list                                                                                     VARCHAR(30)
)
ORGANIZATION EXTERNAL
(
  TYPE ORACLE_LOADER
  DEFAULT DIRECTORY esm_public
  ACCESS PARAMETERS
  (
    FIELDS TERMINATED BY ','
    (
       ORG_ID                                                                                              CHAR(10),
       APPLICANT_ID                                                                                        CHAR(25),
       STMM_1                                                                                              CHAR(9),
       STMO_1                                                                                              CHAR(9),
       SPMM_1                                                                                              CHAR(9),
       SPMO_1                                                                                              CHAR(9),
       STMM_2                                                                                              CHAR(9),
       STMO_2                                                                                              CHAR(9),
       SPMM_2                                                                                              CHAR(9),
       SPMO_2                                                                                              CHAR(9),
       STMM_3                                                                                              CHAR(9),
       STMO_3                                                                                              CHAR(9),
       SPMM_3                                                                                              CHAR(9),
       SPMO_3                                                                                              CHAR(9),
       STMM_4                                                                                              CHAR(9),
       STMO_4                                                                                              CHAR(9),
       SPMM_4                                                                                              CHAR(9),
       SPMO_4                                                                                              CHAR(9),
       ADM_REQ_ID_REQ                                                                                      CHAR(30),
       ADM_REQ_ID_LIST                                                                                     CHAR(30)
    )
  )
  LOCATION ('ees_appc_prev_mark_ext.dat')
)
PARALLEL
REJECT LIMIT UNLIMITED;
