package sstdb.ees.EesAwardDistribution;


public class EesAwardDistributionPkeyObj
{
  public String                                 org_id;
  public String                                 event_id;
  public String                                 awardee_id;
}