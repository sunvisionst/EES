function EesAcademicSessionRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("academic_session").readOnly = true;
    document.getElementById("start_date").value  = document.getElementById("start_date"+"_r"+inRecNum).value;
    document.getElementById("end_date").value  = document.getElementById("end_date"+"_r"+inRecNum).value;
    document.getElementById("close_date").value  = document.getElementById("close_date"+"_r"+inRecNum).value;
    document.getElementById("academic_session_sts").value  = document.getElementById("academic_session_sts"+"_r"+inRecNum).value;
    document.getElementById("semester_start_date").value  = document.getElementById("semester_start_date"+"_r"+inRecNum).value;
    document.getElementById("semester_end_date").value  = document.getElementById("semester_end_date"+"_r"+inRecNum).value;
    document.getElementById("semester_close_date").value  = document.getElementById("semester_close_date"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("academic_session").value = '';
    document.getElementById("academic_session").readOnly = false;
    document.getElementById("start_date").value = '';
    document.getElementById("end_date").value = '';
    document.getElementById("close_date").value = '';
    document.getElementById("academic_session_sts").value = '';
    document.getElementById("semester_start_date").value = '';
    document.getElementById("semester_end_date").value = '';
    document.getElementById("semester_close_date").value = '';
  }
}
