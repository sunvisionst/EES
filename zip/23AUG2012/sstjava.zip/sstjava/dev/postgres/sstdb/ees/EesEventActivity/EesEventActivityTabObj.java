package sstdb.ees.EesEventActivity;


public class EesEventActivityTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 activity_id;
  public String                                 event_act_type;
  public String                                 activity_date;
  public String                                 act_start_time;
  public String                                 act_end_time;
  public String                                 reg_date;
  public String                                 event_id;
  public String                                 activity_desc;
  public String                                 activity_location;
  public String                                 sponsor_flag;
  public String                                 sponsored_by;





  public short                                  org_id_ind;
  public short                                  activity_id_ind;
  public short                                  event_act_type_ind;
  public short                                  activity_date_ind;
  public short                                  act_start_time_ind;
  public short                                  act_end_time_ind;
  public short                                  reg_date_ind;
  public short                                  event_id_ind;
  public short                                  activity_desc_ind;
  public short                                  activity_location_ind;
  public short                                  sponsor_flag_ind;
  public short                                  sponsored_by_ind;


  public EesEventActivityTabObj(){}


  public EesEventActivityTabObj
  (
    String org_id,
    String activity_id,
    String event_act_type,
    String activity_date,
    String act_start_time,
    String act_end_time,
    String reg_date,
    String event_id,
    String activity_desc,
    String activity_location,
    String sponsor_flag,
    String sponsored_by
  )
  {
     this.org_id = org_id;
     this.activity_id = activity_id;
     this.event_act_type = event_act_type;
     this.activity_date = activity_date;
     this.act_start_time = act_start_time;
     this.act_end_time = act_end_time;
     this.reg_date = reg_date;
     this.event_id = event_id;
     this.activity_desc = activity_desc;
     this.activity_location = activity_location;
     this.sponsor_flag = sponsor_flag;
     this.sponsored_by = sponsored_by;
  }

  public String getorg_id()                           { return org_id; }
  public String getactivity_id()                        { return activity_id; }
  public String getevent_act_type()                       { return event_act_type; }
  public String getactivity_date()                       { return activity_date; }
  public String getact_start_time()                       { return act_start_time; }
  public String getact_end_time()                        { return act_end_time; }
  public String getreg_date()                          { return reg_date; }
  public String getevent_id()                          { return event_id; }
  public String getactivity_desc()                       { return activity_desc; }
  public String getactivity_location()                     { return activity_location; }
  public String getsponsor_flag()                        { return sponsor_flag; }
  public String getsponsored_by()                        { return sponsored_by; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setactivity_id(String activity_id )               { this.activity_id = activity_id; }
  public void  setevent_act_type(String event_act_type )            { this.event_act_type = event_act_type; }
  public void  setactivity_date(String activity_date )             { this.activity_date = activity_date; }
  public void  setact_start_time(String act_start_time )            { this.act_start_time = act_start_time; }
  public void  setact_end_time(String act_end_time )              { this.act_end_time = act_end_time; }
  public void  setreg_date(String reg_date )                  { this.reg_date = reg_date; }
  public void  setevent_id(String event_id )                  { this.event_id = event_id; }
  public void  setactivity_desc(String activity_desc )             { this.activity_desc = activity_desc; }
  public void  setactivity_location(String activity_location )         { this.activity_location = activity_location; }
  public void  setsponsor_flag(String sponsor_flag )              { this.sponsor_flag = sponsor_flag; }
  public void  setsponsored_by(String sponsored_by )              { this.sponsored_by = sponsored_by; }
}