package sstdb.ees.EesAward;


public class EesAwardPkeyObj
{
  public String                                 org_id;
  public String                                 award_id;
}