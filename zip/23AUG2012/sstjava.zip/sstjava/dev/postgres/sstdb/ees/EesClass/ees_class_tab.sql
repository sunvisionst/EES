CREATE TABLE EES_CLASS
(
  ORG_ID                                                                                              VARCHAR(10),
  CLASS_ID                                                                                            VARCHAR(20),
  CLASS_NUM                                                                                           VARCHAR(10),
  CLASS_STD                                                                                           VARCHAR(10),
  CLASS_SECTION                                                                                       VARCHAR(10),
  COURSE_ID                                                                                           VARCHAR(10),
  COURSE_TERM                                                                                         VARCHAR(10),
  COURSE_STREAM                                                                                       VARCHAR(10),
  DESCRIPTION                                                                                         VARCHAR(50),
  DURATION_TYPE                                                                                       VARCHAR(1),
  COURSE_DURATION                                                                                     NUMERIC(9),
  REMARK                                                                                              VARCHAR(100),
  UPGRADE_IND                                                                                         VARCHAR(1),
  RUN_IND                                                                                             VARCHAR(1),
  ROOM_NUM                                                                                            VARCHAR(5),
  BUILDING_ID                                                                                         VARCHAR(10),
  ROOM_SHARE_IND                                                                                      VARCHAR(1),
  CLASS_TEACHER                                                                                       VARCHAR(20),
  STREAM_IND                                                                                          VARCHAR(1),
  SHIFT_CODE                                                                                          VARCHAR(10)
)
 WITH OIDS;
