
var lEesDailyTripTabObjJSArr = new Array();
<%
{
   if ( lEesDailyTripTabObjArrCache != null && lEesDailyTripTabObjArrCache.size() > 0 )
   {
%>
       lEesDailyTripTabObjJSArr = new Array(<%=lEesDailyTripTabObjArrCache.size()%>);
<%
       for ( int lRecNum = 0; lRecNum < lEesDailyTripTabObjArrCache.size(); lRecNum++ )
       {
          EesDailyTripTabObj lEesDailyTripTabObj    =    new EesDailyTripTabObj();
          lEesDailyTripTabObj = (EesDailyTripTabObj)lEesDailyTripTabObjArrCache.get(lRecNum);
%>
          lEesDailyTripTabObjJSArr[<%=lRecNum%>] = new constructorEesDailyTrip
          (
          "<%=lEesDailyTripTabObj.org_id%>",
          "<%=lEesDailyTripTabObj.wo_num%>",
          "<%=lEesDailyTripTabObj.wo_date%>",
          "<%=lEesDailyTripTabObj.route_id%>",
          "<%=lEesDailyTripTabObj.trip_id%>",
          "<%=lEesDailyTripTabObj.trip_num%>",
          "<%=lEesDailyTripTabObj.vehicle_id%>",
          "<%=lEesDailyTripTabObj.driver_id%>",
          "<%=lEesDailyTripTabObj.start_time%>",
          "<%=lEesDailyTripTabObj.end_time%>",
          "<%=lEesDailyTripTabObj.omr%>",
          "<%=lEesDailyTripTabObj.cmr%>",
          "<%=lEesDailyTripTabObj.remark%>"
          );
<%
       }
   }
}
%>


