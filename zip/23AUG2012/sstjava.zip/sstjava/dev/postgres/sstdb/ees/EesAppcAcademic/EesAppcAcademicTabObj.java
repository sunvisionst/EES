package sstdb.ees.EesAppcAcademic;


public class EesAppcAcademicTabObj
{
  public String                                 tab_rowid;
  public String                                 org_id;
  public String                                 applicant_id;
  public int                                  seq_num;
  public String                                 class_num;
  public String                                 class_std;
  public String                                 course_id;
  public String                                 course_term;
  public String                                 course_stream;
  public String                                 full_part_time;
  public String                                 university_board_name;
  public String                                 college_school_name;
  public String                                 state;
  public String                                 country;
  public String                                 unv_rn;
  public String                                 subject_list;
  public short                                 year_of_passing;
  public String                                 percent_grade;
  public float                                 marks_in_percent;
  public String                                 grade;
  public String                                 adm_req_id_req;
  public String                                 adm_req_id_list;





  public short                                  org_id_ind;
  public short                                  applicant_id_ind;
  public short                                  seq_num_ind;
  public short                                  class_num_ind;
  public short                                  class_std_ind;
  public short                                  course_id_ind;
  public short                                  course_term_ind;
  public short                                  course_stream_ind;
  public short                                  full_part_time_ind;
  public short                                  university_board_name_ind;
  public short                                  college_school_name_ind;
  public short                                  state_ind;
  public short                                  country_ind;
  public short                                  unv_rn_ind;
  public short                                  subject_list_ind;
  public short                                  year_of_passing_ind;
  public short                                  percent_grade_ind;
  public short                                  marks_in_percent_ind;
  public short                                  grade_ind;
  public short                                  adm_req_id_req_ind;
  public short                                  adm_req_id_list_ind;


  public EesAppcAcademicTabObj(){}


  public EesAppcAcademicTabObj
  (
    String org_id,
    String applicant_id,
    int seq_num,
    String class_num,
    String class_std,
    String course_id,
    String course_term,
    String course_stream,
    String full_part_time,
    String university_board_name,
    String college_school_name,
    String state,
    String country,
    String unv_rn,
    String subject_list,
    short year_of_passing,
    String percent_grade,
    float marks_in_percent,
    String grade,
    String adm_req_id_req,
    String adm_req_id_list
  )
  {
     this.org_id = org_id;
     this.applicant_id = applicant_id;
     this.seq_num = seq_num;
     this.class_num = class_num;
     this.class_std = class_std;
     this.course_id = course_id;
     this.course_term = course_term;
     this.course_stream = course_stream;
     this.full_part_time = full_part_time;
     this.university_board_name = university_board_name;
     this.college_school_name = college_school_name;
     this.state = state;
     this.country = country;
     this.unv_rn = unv_rn;
     this.subject_list = subject_list;
     this.year_of_passing = year_of_passing;
     this.percent_grade = percent_grade;
     this.marks_in_percent = marks_in_percent;
     this.grade = grade;
     this.adm_req_id_req = adm_req_id_req;
     this.adm_req_id_list = adm_req_id_list;
  }

  public String getorg_id()                           { return org_id; }
  public String getapplicant_id()                        { return applicant_id; }
  public int getseq_num()                            { return seq_num; }
  public String getclass_num()                         { return class_num; }
  public String getclass_std()                         { return class_std; }
  public String getcourse_id()                         { return course_id; }
  public String getcourse_term()                        { return course_term; }
  public String getcourse_stream()                       { return course_stream; }
  public String getfull_part_time()                       { return full_part_time; }
  public String getuniversity_board_name()                   { return university_board_name; }
  public String getcollege_school_name()                    { return college_school_name; }
  public String getstate()                           { return state; }
  public String getcountry()                          { return country; }
  public String getunv_rn()                           { return unv_rn; }
  public String getsubject_list()                        { return subject_list; }
  public short getyear_of_passing()                       { return year_of_passing; }
  public String getpercent_grade()                       { return percent_grade; }
  public float getmarks_in_percent()                      { return marks_in_percent; }
  public String getgrade()                           { return grade; }
  public String getadm_req_id_req()                       { return adm_req_id_req; }
  public String getadm_req_id_list()                      { return adm_req_id_list; }



  public void  setorg_id(String org_id )                    { this.org_id = org_id; }
  public void  setapplicant_id(String applicant_id )              { this.applicant_id = applicant_id; }
  public void  setseq_num(int seq_num )                     { this.seq_num = seq_num; }
  public void  setclass_num(String class_num )                 { this.class_num = class_num; }
  public void  setclass_std(String class_std )                 { this.class_std = class_std; }
  public void  setcourse_id(String course_id )                 { this.course_id = course_id; }
  public void  setcourse_term(String course_term )               { this.course_term = course_term; }
  public void  setcourse_stream(String course_stream )             { this.course_stream = course_stream; }
  public void  setfull_part_time(String full_part_time )            { this.full_part_time = full_part_time; }
  public void  setuniversity_board_name(String university_board_name )     { this.university_board_name = university_board_name; }
  public void  setcollege_school_name(String college_school_name )       { this.college_school_name = college_school_name; }
  public void  setstate(String state )                     { this.state = state; }
  public void  setcountry(String country )                   { this.country = country; }
  public void  setunv_rn(String unv_rn )                    { this.unv_rn = unv_rn; }
  public void  setsubject_list(String subject_list )              { this.subject_list = subject_list; }
  public void  setyear_of_passing(short year_of_passing )            { this.year_of_passing = year_of_passing; }
  public void  setpercent_grade(String percent_grade )             { this.percent_grade = percent_grade; }
  public void  setmarks_in_percent(float marks_in_percent )           { this.marks_in_percent = marks_in_percent; }
  public void  setgrade(String grade )                     { this.grade = grade; }
  public void  setadm_req_id_req(String adm_req_id_req )            { this.adm_req_id_req = adm_req_id_req; }
  public void  setadm_req_id_list(String adm_req_id_list )           { this.adm_req_id_list = adm_req_id_list; }
}