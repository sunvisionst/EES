function EesEventActivityRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("activity_id").value  = document.getElementById("activity_id"+"_r"+inRecNum).value;
    document.getElementById("activity_id").readOnly = true;
    document.getElementById("event_act_type").value  = document.getElementById("event_act_type"+"_r"+inRecNum).value;
    document.getElementById("activity_date").value  = document.getElementById("activity_date"+"_r"+inRecNum).value;
    document.getElementById("act_start_time").value  = document.getElementById("act_start_time"+"_r"+inRecNum).value;
    document.getElementById("act_end_time").value  = document.getElementById("act_end_time"+"_r"+inRecNum).value;
    document.getElementById("reg_date").value  = document.getElementById("reg_date"+"_r"+inRecNum).value;
    document.getElementById("event_id").value  = document.getElementById("event_id"+"_r"+inRecNum).value;
    document.getElementById("activity_desc").value  = document.getElementById("activity_desc"+"_r"+inRecNum).value;
    document.getElementById("activity_location").value  = document.getElementById("activity_location"+"_r"+inRecNum).value;
    document.getElementById("sponsor_flag").value  = document.getElementById("sponsor_flag"+"_r"+inRecNum).value;
    document.getElementById("sponsored_by").value  = document.getElementById("sponsored_by"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("activity_id").value = '';
    document.getElementById("activity_id").readOnly = false;
    document.getElementById("event_act_type").value = '';
    document.getElementById("activity_date").value = '';
    document.getElementById("act_start_time").value = '';
    document.getElementById("act_end_time").value = '';
    document.getElementById("reg_date").value = '';
    document.getElementById("event_id").value = '';
    document.getElementById("activity_desc").value = '';
    document.getElementById("activity_location").value = '';
    document.getElementById("sponsor_flag").value = '';
    document.getElementById("sponsored_by").value = '';
  }
}
