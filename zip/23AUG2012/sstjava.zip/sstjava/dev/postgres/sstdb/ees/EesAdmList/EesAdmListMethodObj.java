package sstdb.ees.EesAdmList;

import sstdb.ees.EesAdmList.EesAdmListTabObj;
import sstdb.ees.EesAdmList.EesAdmListPkeyObj;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.sql.*;
import java.sql.*;

import sstcom.gn.SSTDBMethod;
import sstcom.gn.SSTProperty;
import sstcom.gn.SSTError;
import sstcom.gn.SSTErrorObj;
import sstcom.gn.SSTDateMethod;

import java.util.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

public class EesAdmListMethodObj
{

  public SSTErrorObj gSSTErrorObj;
  public String      gConfigFilePath;
  public String      gConfigFile;
  public String      gDBUsr;
  public boolean     gIsPreparedStmt = false;
  public String      gDebugFlagQryStr;
  public Connection  gConnection;
  public boolean     gConnectInd;
  public ResultSet   gResultSet;

  //------------------------------------------------------
  public boolean     MAX_VALUE_DATATYPE_STR_FLAG = false;
  public String      max_value_str_fmt = null;
  //------------------------------------------------------

  public EesAdmListMethodObj()
  { 
     gSSTErrorObj = new SSTErrorObj();
     gSSTErrorObj.errorCode        = 0;
     gSSTErrorObj.errorText        = "";
     gSSTErrorObj.sqlState         = "";
     gSSTErrorObj.sourceClass      = "EesAdmListMethodObj";
     gSSTErrorObj.sourceMethod     = "";
     gConfigFilePath  = "";
     gConfigFile      = "";
     gDBUsr           = "";
     gIsPreparedStmt  = false;
     gDebugFlagQryStr = "N";
     gConnection      = null;
     gConnectInd      = false;
     gResultSet       = null;
  }
  public void sop( String inString )
  { 
    if ( gDebugFlagQryStr.equals("Y") )      System.out.println( inString ); 
  }



  public void initEesAdmListTabObj
               ( 
                 EesAdmListTabObj  outEesAdmListTabObj
               )
  {
  
     outEesAdmListTabObj.org_id = ""; 
     outEesAdmListTabObj.adm_req_id = ""; 
     outEesAdmListTabObj.application_form_num = ""; 
     outEesAdmListTabObj.applicant_id = ""; 
     outEesAdmListTabObj.student_photo_file = ""; 
     outEesAdmListTabObj.mother_photo_file = ""; 
     outEesAdmListTabObj.father_photo_file = ""; 
     outEesAdmListTabObj.class_id = ""; 
     outEesAdmListTabObj.class_num = ""; 
     outEesAdmListTabObj.class_std = ""; 
     outEesAdmListTabObj.class_section = ""; 
     outEesAdmListTabObj.course_id = ""; 
     outEesAdmListTabObj.course_term = ""; 
     outEesAdmListTabObj.course_stream = ""; 
     outEesAdmListTabObj.name_initials = ""; 
     outEesAdmListTabObj.student_f_name = ""; 
     outEesAdmListTabObj.student_m_name = ""; 
     outEesAdmListTabObj.student_l_name = ""; 
     outEesAdmListTabObj.dob = ""; 
     outEesAdmListTabObj.age_on_date = ""; 
     outEesAdmListTabObj.age_year = (int)0; 
     outEesAdmListTabObj.age_month = ""; 
     outEesAdmListTabObj.age_day = (int)0; 
     outEesAdmListTabObj.s_nationality = ""; 
     outEesAdmListTabObj.religion = ""; 
     outEesAdmListTabObj.student_ctg = ""; 
     outEesAdmListTabObj.gender_flag = ""; 
     outEesAdmListTabObj.p_address_1 = ""; 
     outEesAdmListTabObj.p_address_2 = ""; 
     outEesAdmListTabObj.p_country = ""; 
     outEesAdmListTabObj.p_state = ""; 
     outEesAdmListTabObj.p_city = ""; 
     outEesAdmListTabObj.p_district = ""; 
     outEesAdmListTabObj.p_zip = ""; 
     outEesAdmListTabObj.m_address_1 = ""; 
     outEesAdmListTabObj.m_address_2 = ""; 
     outEesAdmListTabObj.m_country = ""; 
     outEesAdmListTabObj.m_state = ""; 
     outEesAdmListTabObj.m_city = ""; 
     outEesAdmListTabObj.m_district = ""; 
     outEesAdmListTabObj.m_zip = ""; 
     outEesAdmListTabObj.phone_list = ""; 
     outEesAdmListTabObj.email_list = ""; 
     outEesAdmListTabObj.fax_list = ""; 
     outEesAdmListTabObj.prev_org_name = ""; 
     outEesAdmListTabObj.prev_class_id = ""; 
     outEesAdmListTabObj.prev_class_num = ""; 
     outEesAdmListTabObj.prev_class_std = ""; 
     outEesAdmListTabObj.prev_class_section = ""; 
     outEesAdmListTabObj.prev_course_id = ""; 
     outEesAdmListTabObj.prev_course_term = ""; 
     outEesAdmListTabObj.prev_course_stream = ""; 
     outEesAdmListTabObj.reason_for_leaving = ""; 
     outEesAdmListTabObj.father_name = ""; 
     outEesAdmListTabObj.father_age = (int)0; 
     outEesAdmListTabObj.f_nationality = ""; 
     outEesAdmListTabObj.father_occ_type = ""; 
     outEesAdmListTabObj.father_employer = ""; 
     outEesAdmListTabObj.father_designation = ""; 
     outEesAdmListTabObj.father_annual_income = (double)0.00; 
     outEesAdmListTabObj.f_off_address_1 = ""; 
     outEesAdmListTabObj.f_phone_list = ""; 
     outEesAdmListTabObj.mother_name = ""; 
     outEesAdmListTabObj.mother_age = (int)0; 
     outEesAdmListTabObj.m_nationality = ""; 
     outEesAdmListTabObj.mother_occ_type = ""; 
     outEesAdmListTabObj.mother_employer = ""; 
     outEesAdmListTabObj.mother_designation = ""; 
     outEesAdmListTabObj.mother_annual_income = (double)0.00; 
     outEesAdmListTabObj.m_off_address_1 = ""; 
     outEesAdmListTabObj.m_phone_list = ""; 
     outEesAdmListTabObj.divorced_flag = ""; 
     outEesAdmListTabObj.child_with = ""; 
     outEesAdmListTabObj.roll_num = ""; 
     outEesAdmListTabObj.academic_session = ""; 
     outEesAdmListTabObj.adm_req_sts = ""; 
     outEesAdmListTabObj.adm_req_sts_date = ""; 
     outEesAdmListTabObj.student_id = ""; 
     outEesAdmListTabObj.scholor_num = ""; 
     outEesAdmListTabObj.form_recv_date = ""; 
     outEesAdmListTabObj.form_recv_time = ""; 
     outEesAdmListTabObj.prospectus_sale_date = ""; 
     outEesAdmListTabObj.prospectus_sale_time = ""; 
     outEesAdmListTabObj.prospectus_sold_by = ""; 
     outEesAdmListTabObj.application_form_fee = (double)0.00; 
     outEesAdmListTabObj.adm_academic_session = ""; 
     outEesAdmListTabObj.entrance_exam_date = ""; 
     outEesAdmListTabObj.entrance_exam_time_start = ""; 
     outEesAdmListTabObj.entrance_exam_time_end = ""; 
     outEesAdmListTabObj.exam_present_status = ""; 
     outEesAdmListTabObj.building_id = ""; 
     outEesAdmListTabObj.floor_num = ""; 
     outEesAdmListTabObj.room_num = ""; 
     outEesAdmListTabObj.max_mark = (int)0; 
     outEesAdmListTabObj.obtained_mark = (int)0; 
     outEesAdmListTabObj.grade = ""; 
     outEesAdmListTabObj.fee_sch_date = ""; 
     outEesAdmListTabObj.fee_deposit_date = ""; 
     outEesAdmListTabObj.online_flag = ""; 
     outEesAdmListTabObj.admission_mode = ""; 
     outEesAdmListTabObj.course_stream_1 = ""; 
     outEesAdmListTabObj.course_stream_2 = ""; 
     outEesAdmListTabObj.course_stream_3 = ""; 
     outEesAdmListTabObj.course_stream_4 = ""; 
     outEesAdmListTabObj.apr_course_stream = ""; 
     outEesAdmListTabObj.unv_1 = ""; 
     outEesAdmListTabObj.unv_rn_1 = ""; 
     outEesAdmListTabObj.gen_rank_1 = ""; 
     outEesAdmListTabObj.ctg_rank_1 = ""; 
     outEesAdmListTabObj.stt_rank_1 = ""; 
     outEesAdmListTabObj.yoa_1 = ""; 
     outEesAdmListTabObj.unv_2 = ""; 
     outEesAdmListTabObj.unv_rn_2 = ""; 
     outEesAdmListTabObj.gen_rank_2 = ""; 
     outEesAdmListTabObj.ctg_rank_2 = ""; 
     outEesAdmListTabObj.stt_rank_2 = ""; 
     outEesAdmListTabObj.yoa_2 = ""; 
     outEesAdmListTabObj.prev_mark_percent = (float)0.00; 
     outEesAdmListTabObj.domecile_ind = ""; 
     outEesAdmListTabObj.org_transport_req_ind = ""; 
     outEesAdmListTabObj.org_hostel_req_ind = ""; 
     outEesAdmListTabObj.cheque_num = ""; 
     outEesAdmListTabObj.cheque_date = ""; 
     outEesAdmListTabObj.bank_code = ""; 
     outEesAdmListTabObj.bank_name = ""; 
     outEesAdmListTabObj.cheque_amt = (double)0.00; 
     outEesAdmListTabObj.lg_0_name = ""; 
     outEesAdmListTabObj.lg_0_rel_type = ""; 
     outEesAdmListTabObj.lg_0_address = ""; 
     outEesAdmListTabObj.lg_0_phone = ""; 
     outEesAdmListTabObj.lg_1_name = ""; 
     outEesAdmListTabObj.lg_1_rel_type = ""; 
     outEesAdmListTabObj.lg_1_address = ""; 
     outEesAdmListTabObj.lg_1_phone = ""; 
     outEesAdmListTabObj.st_cap_attr_1 = ""; 
     outEesAdmListTabObj.st_cap_attr_2 = ""; 
     outEesAdmListTabObj.st_cap_attr_3 = ""; 
     outEesAdmListTabObj.st_cap_attr_4 = ""; 
     outEesAdmListTabObj.st_cap_attr_5 = ""; 
     outEesAdmListTabObj.st_cap_attr_6 = ""; 
     outEesAdmListTabObj.st_cap_attr_7 = ""; 
     outEesAdmListTabObj.st_cap_attr_8 = ""; 
     outEesAdmListTabObj.allergy = ""; 
     outEesAdmListTabObj.physical_disability = ""; 
     outEesAdmListTabObj.health_problem = ""; 
     outEesAdmListTabObj.health_problem_1 = ""; 
     outEesAdmListTabObj.health_problem_2 = ""; 
     outEesAdmListTabObj.health_problem_3 = ""; 
     outEesAdmListTabObj.health_problem_4 = ""; 
     outEesAdmListTabObj.health_problem_5 = ""; 
     outEesAdmListTabObj.health_problem_6 = ""; 
     outEesAdmListTabObj.health_problem_7 = ""; 
     outEesAdmListTabObj.health_problem_8 = ""; 
     outEesAdmListTabObj.health_problem_9 = ""; 
     outEesAdmListTabObj.health_problem_10 = ""; 
     outEesAdmListTabObj.health_problem_11 = ""; 
     outEesAdmListTabObj.health_problem_12 = ""; 
     outEesAdmListTabObj.enclosure_1 = ""; 
     outEesAdmListTabObj.enclosure_2 = ""; 
     outEesAdmListTabObj.enclosure_3 = ""; 
     outEesAdmListTabObj.enclosure_4 = ""; 
     outEesAdmListTabObj.enclosure_5 = ""; 
     outEesAdmListTabObj.enclosure_6 = ""; 
     outEesAdmListTabObj.enclosure_7 = ""; 
     outEesAdmListTabObj.enclosure_8 = ""; 
     outEesAdmListTabObj.seat_num = (int)0; 
     outEesAdmListTabObj.reason_for_join = ""; 
     outEesAdmListTabObj.remark = ""; 
     outEesAdmListTabObj.place_of_birth = ""; 
     outEesAdmListTabObj.adv_adm_fee = (double)0.00; 
     outEesAdmListTabObj.payment_mode = ""; 
     outEesAdmListTabObj.target_ptl_user_id = ""; 
     outEesAdmListTabObj.adm_req_id_req = ""; 
     outEesAdmListTabObj.adm_req_id_list = ""; 
  }





  public void guiDateConvEesAdmListTabObj
               ( 
                 EesAdmListTabObj  inEesAdmListTabObj
               , String  inDateTimeSrcFmt 
               , String  inDateTimeTrgFmt 
               )
  {
   
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    //lDateTimeSrcFmt = "yyyyMMdd";
    //lDateTimeTrgFmt = "dd-MMM-yyyy";
    lDateTimeSrcFmt = inDateTimeSrcFmt;
    lDateTimeTrgFmt = inDateTimeTrgFmt;

          if ( inEesAdmListTabObj.dob != null && inEesAdmListTabObj.dob.length() > 0 ) 
            inEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.dob, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.age_on_date != null && inEesAdmListTabObj.age_on_date.length() > 0 ) 
            inEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.adm_req_sts_date != null && inEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.form_recv_date != null && inEesAdmListTabObj.form_recv_date.length() > 0 ) 
            inEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.prospectus_sale_date != null && inEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.entrance_exam_date != null && inEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.fee_sch_date != null && inEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.fee_deposit_date != null && inEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);

          if ( inEesAdmListTabObj.cheque_date != null && inEesAdmListTabObj.cheque_date.length() > 0 ) 
            inEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, inEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
  }





  public void refreshCtxEesAdmListByTabObj
               ( 
                 EesAdmListTabObj  inEesAdmListTabObj
               , String  inDBOpr 
               , ServletContext  inServletContext 
               )
  {
   
    ArrayList lEesAdmListTabObjArrCtx  = new ArrayList(); 
    lEesAdmListTabObjArrCtx  = (ArrayList)inServletContext.getAttribute("lEesAdmListTabObjArrCtx"); 
    
    if( inDBOpr.equals("Insert") ) 
    {
      lEesAdmListTabObjArrCtx.add(inEesAdmListTabObj); 
    }
    
    else
    if( inDBOpr.equals("Delete")   
      ||inDBOpr.equals("Update") ) 
    {
      for ( int lRecNum = 0;  lRecNum < lEesAdmListTabObjArrCtx.size();  lRecNum++ )
      {
        EesAdmListTabObj lEesAdmListTabObj = new EesAdmListTabObj();
        lEesAdmListTabObj = (EesAdmListTabObj)lEesAdmListTabObjArrCtx.get(lRecNum);
    
        if ( 
              lEesAdmListTabObj.org_id.equals(lEesAdmListTabObj.org_id) &&
              lEesAdmListTabObj.adm_req_id.equals(lEesAdmListTabObj.adm_req_id) 
           )
        {
          if( inDBOpr.equals("Delete") )
            lEesAdmListTabObjArrCtx.remove(lRecNum);
          else
          if( inDBOpr.equals("Update") )
            lEesAdmListTabObjArrCtx.set(lRecNum, inEesAdmListTabObj);
        }
      }
    }
    else
    if( inDBOpr.equals("Update") ) 
    {
    }
    inServletContext.setAttribute("lEesAdmListTabObjArrCtx",lEesAdmListTabObjArrCtx);
  }





  public void sortEesAdmListTabObjArr
               ( 
                 ArrayList  inEesAdmListTabObjArr
               , String  inFieldList 
               , String  inSortType 
               )
  {
   
     String lSortString = ""; 
     boolean  trueFalse = true; 
     int lNumRec = 0; 
     String lFieldListTemp = ""; 
     ArrayList lStringList =  new ArrayList(); 
     while( trueFalse ) 
     { 
        if ( inFieldList.indexOf(',') > 0 ) 
        { 
           String lString  =  inFieldList.substring( 0, inFieldList.indexOf(',') ); 
           lStringList.add( lString ); 
           lFieldListTemp = inFieldList.substring( inFieldList.indexOf(',')+1, inFieldList.length() ); 
           inFieldList    = ""; 
           inFieldList    = lFieldListTemp; 
        } 
        else 
        { 
           trueFalse = true; 
           break; 
        } 
     } 
     ArrayList lEesAdmListTabObjArr  = new ArrayList(); 
     lEesAdmListTabObjArr = inEesAdmListTabObjArr; 
     List lEesAdmListTabObjList  = new ArrayList(lEesAdmListTabObjArr.size()); 
     String lSortKey = ""; 
     for ( int lRecNum = 0; lRecNum < lEesAdmListTabObjArr.size();  lRecNum++ )
     {
       EesAdmListTabObj  lEesAdmListTabObj = new EesAdmListTabObj(); 
       lEesAdmListTabObj = (EesAdmListTabObj)lEesAdmListTabObjArr.get( lRecNum ); 
       for ( int lFldCnt = 0; lFldCnt < lStringList.size(); lFldCnt++ )
       {
         if  ( lStringList.get(lFldCnt).equals("org_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.org_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.org_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.adm_req_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_req_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("application_form_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.application_form_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.application_form_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("applicant_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.applicant_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.applicant_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmListTabObj.student_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmListTabObj.mother_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_photo_file") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (56 - lEesAdmListTabObj.father_photo_file.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_photo_file+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("name_initials") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.name_initials.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.name_initials+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_f_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.student_f_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_f_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_m_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.student_m_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_m_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_l_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.student_l_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_l_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("dob") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.dob.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.dob+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_on_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.age_on_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.age_on_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_year") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmListTabObj.age_year).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.age_year+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_month") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - lEesAdmListTabObj.age_month.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.age_month+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("age_day") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmListTabObj.age_day).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.age_day+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("s_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.s_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.s_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("religion") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.religion.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.religion+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_ctg") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.student_ctg.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_ctg+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gender_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.gender_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.gender_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.p_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.p_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.p_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.p_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.p_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_district") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.p_district.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_district+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("p_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.p_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.p_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.m_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_address_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.m_address_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_address_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_country") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.m_country.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_country+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_state") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.m_state.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_state+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_city") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.m_city.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_city+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_district") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.m_district.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_district+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_zip") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.m_zip.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_zip+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("email_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.email_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.email_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fax_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.fax_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.fax_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_org_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmListTabObj.prev_org_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_org_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.prev_class_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_class_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_class_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_class_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_std") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_class_std.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_class_std+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_class_section") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_class_section.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_class_section+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_course_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_course_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_term") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_course_term.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_course_term+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prev_course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reason_for_leaving") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.reason_for_leaving.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.reason_for_leaving+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.father_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_age") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmListTabObj.father_age).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_age+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.f_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.f_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_occ_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.father_occ_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_occ_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_employer") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.father_employer.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_employer+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmListTabObj.father_designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("father_annual_income") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmListTabObj.father_annual_income).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.father_annual_income+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_off_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.f_off_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.f_off_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("f_phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.f_phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.f_phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.mother_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_age") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (2 - Byte.toString(lEesAdmListTabObj.mother_age).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_age+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_nationality") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.m_nationality.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_nationality+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_occ_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.mother_occ_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_occ_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_employer") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.mother_employer.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_employer+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_designation") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmListTabObj.mother_designation.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_designation+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("mother_annual_income") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmListTabObj.mother_annual_income).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.mother_annual_income+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_off_address_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.m_off_address_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_off_address_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("m_phone_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.m_phone_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.m_phone_list+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("divorced_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.divorced_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.divorced_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("child_with") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.child_with.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.child_with+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("roll_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.roll_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.roll_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("academic_session") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (11 - lEesAdmListTabObj.academic_session.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.academic_session+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_sts") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.adm_req_sts.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_req_sts+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_sts_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.adm_req_sts_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_req_sts_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("student_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.student_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.student_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("scholor_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.scholor_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.scholor_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("form_recv_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.form_recv_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.form_recv_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("form_recv_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmListTabObj.form_recv_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.form_recv_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sale_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.prospectus_sale_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prospectus_sale_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sale_time") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmListTabObj.prospectus_sale_time.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prospectus_sale_time+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prospectus_sold_by") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.prospectus_sold_by.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prospectus_sold_by+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("application_form_fee") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmListTabObj.application_form_fee).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.application_form_fee+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_academic_session") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (11 - lEesAdmListTabObj.adm_academic_session.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_academic_session+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.entrance_exam_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.entrance_exam_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_time_start") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmListTabObj.entrance_exam_time_start.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.entrance_exam_time_start+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("entrance_exam_time_end") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (6 - lEesAdmListTabObj.entrance_exam_time_end.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.entrance_exam_time_end+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("exam_present_status") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.exam_present_status.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.exam_present_status+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("building_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.building_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.building_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("floor_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.floor_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.floor_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("room_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.room_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.room_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("max_mark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (4 - Short.toString(lEesAdmListTabObj.max_mark).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.max_mark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("obtained_mark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (4 - Short.toString(lEesAdmListTabObj.obtained_mark).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.obtained_mark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("grade") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.grade.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.grade+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fee_sch_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.fee_sch_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.fee_sch_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("fee_deposit_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.fee_deposit_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.fee_deposit_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("online_flag") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.online_flag.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.online_flag+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("admission_mode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.admission_mode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.admission_mode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_stream_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_stream_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_stream_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_stream_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_stream_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_stream_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("course_stream_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.course_stream_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.course_stream_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("apr_course_stream") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.apr_course_stream.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.apr_course_stream+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.unv_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.unv_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_rn_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.unv_rn_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.unv_rn_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gen_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.gen_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.gen_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ctg_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.ctg_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.ctg_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stt_rank_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.stt_rank_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.stt_rank_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("yoa_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.yoa_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.yoa_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.unv_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.unv_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("unv_rn_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.unv_rn_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.unv_rn_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("gen_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.gen_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.gen_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("ctg_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.ctg_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.ctg_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("stt_rank_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.stt_rank_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.stt_rank_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("yoa_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (10 - lEesAdmListTabObj.yoa_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.yoa_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("prev_mark_percent") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - Float.toString(lEesAdmListTabObj.prev_mark_percent).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.prev_mark_percent+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("domecile_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.domecile_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.domecile_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_transport_req_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.org_transport_req_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.org_transport_req_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("org_hostel_req_ind") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.org_hostel_req_ind.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.org_hostel_req_ind+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.cheque_num.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.cheque_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_date") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (8 - lEesAdmListTabObj.cheque_date.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.cheque_date+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bank_code") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (20 - lEesAdmListTabObj.bank_code.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.bank_code+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("bank_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (60 - lEesAdmListTabObj.bank_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.bank_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("cheque_amt") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmListTabObj.cheque_amt).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.cheque_amt+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_0_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_0_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_rel_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_0_rel_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_0_rel_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_address") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_0_address.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_0_address+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_0_phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.lg_0_phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_0_phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_name") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_1_name.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_1_name+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_rel_type") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_1_rel_type.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_1_rel_type+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_address") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.lg_1_address.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_1_address+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("lg_1_phone") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.lg_1_phone.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.lg_1_phone+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("st_cap_attr_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.st_cap_attr_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.st_cap_attr_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("allergy") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.allergy.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.allergy+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("physical_disability") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.physical_disability.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.physical_disability+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.health_problem.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_9") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_9.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_9+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_10") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_10.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_10+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_11") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_11.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_11+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("health_problem_12") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.health_problem_12.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.health_problem_12+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_1") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_1.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_1+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_2") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_2.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_2+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_3") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_3.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_3+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_4") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_4.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_4+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_5") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_5.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_5+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_6") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_6.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_6+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_7") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_7.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_7+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("enclosure_8") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (1 - lEesAdmListTabObj.enclosure_8.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.enclosure_8+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("seat_num") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (3 - Short.toString(lEesAdmListTabObj.seat_num).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.seat_num+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("reason_for_join") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.reason_for_join.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.reason_for_join+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("remark") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.remark.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.remark+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("place_of_birth") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (100 - lEesAdmListTabObj.place_of_birth.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.place_of_birth+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adv_adm_fee") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (13 - Double.toString(lEesAdmListTabObj.adv_adm_fee).trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adv_adm_fee+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("payment_mode") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (5 - lEesAdmListTabObj.payment_mode.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.payment_mode+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("target_ptl_user_id") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (50 - lEesAdmListTabObj.target_ptl_user_id.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.target_ptl_user_id+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_req") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.adm_req_id_req.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_req_id_req+"#";
         }
         else if  ( lStringList.get(lFldCnt).equals("adm_req_id_list") )
         {
           for ( int lSortFieldLen = 0; lSortFieldLen < (30 - lEesAdmListTabObj.adm_req_id_list.trim().length() ); lSortFieldLen++ )
             lSortKey = lSortKey + "0";
           lSortKey = lSortKey + lEesAdmListTabObj.adm_req_id_list+"#";
         }
         
       }
       lSortKey = lSortKey + lRecNum;
       lEesAdmListTabObjList.add( lSortKey ); 
       lSortKey = "";
     }
     
     if ( inSortType != null && inSortType.equals("D") )
       Collections.sort( lEesAdmListTabObjList, Collections.reverseOrder() ); 
     else
     if ( inSortType != null && inSortType.equals("I") )
       Collections.sort( lEesAdmListTabObjList ); 
     ArrayList lEesAdmListTabObjArrSorted = new ArrayList();
     
     for ( int lRecNum = 0; lRecNum < lEesAdmListTabObjArr.size();  lRecNum++ )
     {
       String lGetIndex = "";
       lGetIndex = (String) lEesAdmListTabObjList.get(lRecNum); 
       int lIndex = lGetIndex.lastIndexOf("#");
       lGetIndex = lGetIndex.substring(lIndex+1,lGetIndex.length());
       int lGetRecord = Integer.parseInt(lGetIndex);
       lEesAdmListTabObjArrSorted.add( (EesAdmListTabObj)lEesAdmListTabObjArr.get(lGetRecord) ); 
     }
     
     for ( int lRecNum = 0; lRecNum < lEesAdmListTabObjArr.size();  lRecNum++ )
     {
       inEesAdmListTabObjArr.set( lRecNum, (EesAdmListTabObj)lEesAdmListTabObjArrSorted.get(lRecNum) ); 
     }
  }





  public void dbDateConvEesAdmListTabObj
               ( 
                 EesAdmListTabObj  inEesAdmListTabObj
               )
  {
  
    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

          if ( inEesAdmListTabObj.dob != null && inEesAdmListTabObj.dob.length() > 0 ) 
            inEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.age_on_date != null && inEesAdmListTabObj.age_on_date.length() > 0 ) 
            inEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.adm_req_sts_date != null && inEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.form_recv_date != null && inEesAdmListTabObj.form_recv_date.length() > 0 ) 
            inEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.prospectus_sale_date != null && inEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.entrance_exam_date != null && inEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_sch_date != null && inEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_deposit_date != null && inEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.cheque_date != null && inEesAdmListTabObj.cheque_date.length() > 0 ) 
            inEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.cheque_date, lDateTimeSrcFmt);
  }





  public void vldFieldDBSizeOrgId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicationFormNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICATION_FORM_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicantId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICANT_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherPhotoFile
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 56 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_PHOTO_FILE";
      String lErrorReason = "Size Greater Than 56";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeNameInitials
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "NAME_INITIALS";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentFName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_F_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentMName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_M_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentLName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_L_NAME";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDob
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOB";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeOnDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_ON_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeYear
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_YEAR";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeMonth
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_MONTH";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAgeDay
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "AGE_DAY";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeS_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "S_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReligion
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "RELIGION";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentCtg
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_CTG";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenderFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GENDER_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_district
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_DISTRICT";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeP_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "P_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_address_2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ADDRESS_2";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_country
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_COUNTRY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_state
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_STATE";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_city
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_CITY";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_district
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_DISTRICT";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_zip
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_ZIP";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhoneList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEmailList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EMAIL_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFaxList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FAX_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevOrgName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_ORG_NAME";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_ID";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassStd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_STD";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevClassSection
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_CLASS_SECTION";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseTerm
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_TERM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReasonForLeaving
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REASON_FOR_LEAVING";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherAge
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_AGE";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherOccType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_OCC_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherEmployer
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_EMPLOYER";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFatherAnnualIncome
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FATHER_ANNUAL_INCOME";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_off_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_OFF_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeF_phone_list
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "F_PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherAge
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 2 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_AGE";
      String lErrorReason = "Size Greater Than 2";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_nationality
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_NATIONALITY";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherOccType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_OCC_TYPE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherEmployer
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_EMPLOYER";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherDesignation
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_DESIGNATION";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMotherAnnualIncome
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MOTHER_ANNUAL_INCOME";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_off_address_1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_OFF_ADDRESS_1";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeM_phone_list
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "M_PHONE_LIST";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDivorcedFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DIVORCED_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChildWith
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHILD_WITH";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRollNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROLL_NUM";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAcademicSession
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 11 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ACADEMIC_SESSION";
      String lErrorReason = "Size Greater Than 11";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqSts
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_STS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqStsDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_STS_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStudentId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STUDENT_ID";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeScholorNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SCHOLOR_NUM";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFormRecvDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FORM_RECV_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFormRecvTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FORM_RECV_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSaleDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SALE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSaleTime
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SALE_TIME";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeProspectusSoldBy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PROSPECTUS_SOLD_BY";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeApplicationFormFee
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APPLICATION_FORM_FEE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmAcademicSession
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 11 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_ACADEMIC_SESSION";
      String lErrorReason = "Size Greater Than 11";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamTimeStart
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_TIME_START";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEntranceExamTimeEnd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 6 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENTRANCE_EXAM_TIME_END";
      String lErrorReason = "Size Greater Than 6";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeExamPresentStatus
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "EXAM_PRESENT_STATUS";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBuildingId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BUILDING_ID";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFloorNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FLOOR_NUM";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRoomNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ROOM_NUM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeMaxMark
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 4 )
   {
      outErrorFlag          = true;
      String lFieldName   = "MAX_MARK";
      String lErrorReason = "Size Greater Than 4";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeObtainedMark
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 4 )
   {
      outErrorFlag          = true;
      String lFieldName   = "OBTAINED_MARK";
      String lErrorReason = "Size Greater Than 4";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGrade
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GRADE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFeeSchDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FEE_SCH_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeFeeDepositDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "FEE_DEPOSIT_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOnlineFlag
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ONLINE_FLAG";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmissionMode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADMISSION_MODE";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_3";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCourseStream4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "COURSE_STREAM_4";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAprCourseStream
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "APR_COURSE_STREAM";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnv1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnvRn1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_RN_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GEN_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCtgRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CTG_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSttRank1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STT_RANK_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeYoa1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "YOA_1";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnv2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeUnvRn2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "UNV_RN_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeGenRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "GEN_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeCtgRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CTG_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSttRank2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "STT_RANK_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeYoa2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 10 )
   {
      outErrorFlag          = true;
      String lFieldName   = "YOA_2";
      String lErrorReason = "Size Greater Than 10";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePrevMarkPercent
               ( 
                   float   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Float.toString(inFieldValue).trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PREV_MARK_PERCENT";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = Float.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeDomecileInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "DOMECILE_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgTransportReqInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_TRANSPORT_REQ_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeOrgHostelReqInd
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ORG_HOSTEL_REQ_IND";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeNum
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_NUM";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeDate
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 8 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_DATE";
      String lErrorReason = "Size Greater Than 8";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankCode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 20 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANK_CODE";
      String lErrorReason = "Size Greater Than 20";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeBankName
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 60 )
   {
      outErrorFlag          = true;
      String lFieldName   = "BANK_NAME";
      String lErrorReason = "Size Greater Than 60";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeChequeAmt
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "CHEQUE_AMT";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Name
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0RelType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_REL_TYPE";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Address
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_ADDRESS";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg0Phone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_0_PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Name
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_NAME";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1RelType
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_REL_TYPE";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Address
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_ADDRESS";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeLg1Phone
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "LG_1_PHONE";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_1";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_2";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_3";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_4";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_5";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_6";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_7";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeStCapAttr8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ST_CAP_ATTR_8";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAllergy
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ALLERGY";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePhysicalDisability
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PHYSICAL_DISABILITY";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_1";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_2";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_3";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_4";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_5";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_6";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_7";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_8";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem9
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_9";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem10
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_10";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem11
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_11";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeHealthProblem12
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "HEALTH_PROBLEM_12";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure1
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_1";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure2
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_2";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure3
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_3";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure4
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_4";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure5
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_5";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure6
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_6";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure7
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_7";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeEnclosure8
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 1 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ENCLOSURE_8";
      String lErrorReason = "Size Greater Than 1";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeSeatNum
               ( 
                   int   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Integer.toString(inFieldValue).trim().length() > 3 )
   {
      outErrorFlag          = true;
      String lFieldName   = "SEAT_NUM";
      String lErrorReason = "Size Greater Than 3";
      String lFieldValue  = Integer.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeReasonForJoin
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REASON_FOR_JOIN";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeRemark
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "REMARK";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePlaceOfBirth
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 100 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PLACE_OF_BIRTH";
      String lErrorReason = "Size Greater Than 100";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdvAdmFee
               ( 
                   double  inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != 0 && Double.toString(inFieldValue).trim().length() > 13 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADV_ADM_FEE";
      String lErrorReason = "Size Greater Than 13";
      String lFieldValue  = Double.toString(inFieldValue);
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizePaymentMode
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 5 )
   {
      outErrorFlag          = true;
      String lFieldName   = "PAYMENT_MODE";
      String lErrorReason = "Size Greater Than 5";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeTargetPtlUserId
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 50 )
   {
      outErrorFlag          = true;
      String lFieldName   = "TARGET_PTL_USER_ID";
      String lErrorReason = "Size Greater Than 50";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdReq
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_REQ";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
 }
 



  public void vldFieldDBSizeAdmReqIdList
               ( 
                   String   inFieldValue
                 , String   inFieldLableName
                 , boolean  outErrorFlag
                 , String   outErrorText
                   )
  {
   if ( inFieldValue != null && inFieldValue.trim().length() > 30 )
   {
      outErrorFlag          = true;
      String lFieldName   = "ADM_REQ_ID_LIST";
      String lErrorReason = "Size Greater Than 30";
      String lFieldValue  = inFieldValue;
      outErrorText = outErrorText+"#error#";
      outErrorText = outErrorText+"#field-name#"+lFieldName+"#/field-name#";
      outErrorText = outErrorText+"#field-value#"+lFieldValue+"#/field-value#";
      outErrorText = outErrorText+"#error-reason#"+lErrorReason+"#/error-reason#";
      outErrorText = outErrorText+"#/error#";
    }
  }





  public int gtEesAdmListCount
               ( String inEesAdmListWhereText
               )
  {
    sop("gtEesAdmListCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT COUNT(1) AS count "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
         gSSTErrorObj.errorCode = -999001403; 
         gSSTErrorObj.errorText = "No Record Found"; 
         lReturnValue = -999001403; 
         throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListCount
               ( String inEesAdmListWhereText
               , String inEesAdmListSelectFieldList
               )
  {
    sop("gtEesAdmListCount - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListCount";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT "+
                         inEesAdmListSelectFieldList+" AS count "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       lReturnValue = lResultSet.getInt("count");
       if ( lReturnValue == 0 ) 
       { 
          gSSTErrorObj.errorCode = -999001403; 
          gSSTErrorObj.errorText = "No Record Found"; 
          lReturnValue = -999001403; 
          throw new Exception(); 
       } 

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListRecByPkey
               ( EesAdmListPkeyObj inEesAdmListPkeyObj
               , EesAdmListTabObj  outEesAdmListTabObj
               )
  {
    sop("gtEesAdmListRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_LIST " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAdmListPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmListPkeyObj.adm_req_id+"'";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          outEesAdmListTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAdmListTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAdmListTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          outEesAdmListTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          outEesAdmListTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAdmListTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          outEesAdmListTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          outEesAdmListTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          outEesAdmListTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAdmListTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAdmListTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAdmListTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAdmListTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAdmListTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAdmListTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAdmListTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outEesAdmListTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          outEesAdmListTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          outEesAdmListTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          outEesAdmListTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAdmListTabObj.dob != null && outEesAdmListTabObj.dob.length() > 0 ) 
            outEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.dob, lDateTimeTrgFmt);
          outEesAdmListTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( outEesAdmListTabObj.age_on_date != null && outEesAdmListTabObj.age_on_date.length() > 0 ) 
            outEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          outEesAdmListTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          outEesAdmListTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          outEesAdmListTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          outEesAdmListTabObj.religion  =  lResultSet.getString("RELIGION");
          outEesAdmListTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAdmListTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAdmListTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outEesAdmListTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outEesAdmListTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outEesAdmListTabObj.p_state  =  lResultSet.getString("P_STATE");
          outEesAdmListTabObj.p_city  =  lResultSet.getString("P_CITY");
          outEesAdmListTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          outEesAdmListTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outEesAdmListTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outEesAdmListTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outEesAdmListTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outEesAdmListTabObj.m_state  =  lResultSet.getString("M_STATE");
          outEesAdmListTabObj.m_city  =  lResultSet.getString("M_CITY");
          outEesAdmListTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          outEesAdmListTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outEesAdmListTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAdmListTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAdmListTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outEesAdmListTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          outEesAdmListTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAdmListTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAdmListTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAdmListTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAdmListTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAdmListTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAdmListTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAdmListTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          outEesAdmListTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAdmListTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          outEesAdmListTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          outEesAdmListTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          outEesAdmListTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          outEesAdmListTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          outEesAdmListTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          outEesAdmListTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          outEesAdmListTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          outEesAdmListTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAdmListTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          outEesAdmListTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          outEesAdmListTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          outEesAdmListTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          outEesAdmListTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          outEesAdmListTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          outEesAdmListTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          outEesAdmListTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          outEesAdmListTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          outEesAdmListTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          outEesAdmListTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAdmListTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesAdmListTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          outEesAdmListTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( outEesAdmListTabObj.adm_req_sts_date != null && outEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            outEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          outEesAdmListTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          outEesAdmListTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( outEesAdmListTabObj.form_recv_date != null && outEesAdmListTabObj.form_recv_date.length() > 0 ) 
            outEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          outEesAdmListTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( outEesAdmListTabObj.prospectus_sale_date != null && outEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            outEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          outEesAdmListTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          outEesAdmListTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          outEesAdmListTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          outEesAdmListTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( outEesAdmListTabObj.entrance_exam_date != null && outEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            outEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          outEesAdmListTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          outEesAdmListTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          outEesAdmListTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outEesAdmListTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outEesAdmListTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outEesAdmListTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          outEesAdmListTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          outEesAdmListTabObj.grade  =  lResultSet.getString("GRADE");
          outEesAdmListTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( outEesAdmListTabObj.fee_sch_date != null && outEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            outEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( outEesAdmListTabObj.fee_deposit_date != null && outEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            outEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          outEesAdmListTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          outEesAdmListTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          outEesAdmListTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          outEesAdmListTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          outEesAdmListTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          outEesAdmListTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          outEesAdmListTabObj.unv_1  =  lResultSet.getString("UNV_1");
          outEesAdmListTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          outEesAdmListTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          outEesAdmListTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          outEesAdmListTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          outEesAdmListTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          outEesAdmListTabObj.unv_2  =  lResultSet.getString("UNV_2");
          outEesAdmListTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          outEesAdmListTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          outEesAdmListTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          outEesAdmListTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          outEesAdmListTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          outEesAdmListTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          outEesAdmListTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          outEesAdmListTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          outEesAdmListTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          outEesAdmListTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          outEesAdmListTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( outEesAdmListTabObj.cheque_date != null && outEesAdmListTabObj.cheque_date.length() > 0 ) 
            outEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          outEesAdmListTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          outEesAdmListTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          outEesAdmListTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          outEesAdmListTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          outEesAdmListTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          outEesAdmListTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          outEesAdmListTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          outEesAdmListTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          outEesAdmListTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          outEesAdmListTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          outEesAdmListTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          outEesAdmListTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          outEesAdmListTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          outEesAdmListTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          outEesAdmListTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          outEesAdmListTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          outEesAdmListTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          outEesAdmListTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          outEesAdmListTabObj.allergy  =  lResultSet.getString("ALLERGY");
          outEesAdmListTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          outEesAdmListTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          outEesAdmListTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          outEesAdmListTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          outEesAdmListTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          outEesAdmListTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          outEesAdmListTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          outEesAdmListTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          outEesAdmListTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          outEesAdmListTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          outEesAdmListTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          outEesAdmListTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          outEesAdmListTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          outEesAdmListTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          outEesAdmListTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          outEesAdmListTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          outEesAdmListTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          outEesAdmListTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          outEesAdmListTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          outEesAdmListTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          outEesAdmListTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          outEesAdmListTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          outEesAdmListTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          outEesAdmListTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          outEesAdmListTabObj.remark  =  lResultSet.getString("REMARK");
          outEesAdmListTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          outEesAdmListTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          outEesAdmListTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          outEesAdmListTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          outEesAdmListTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAdmListTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAdmListTabObj( outEesAdmListTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListArr
               ( EesAdmListPkeyObj inEesAdmListPkeyObj
               , ArrayList  outEesAdmListTabObjArr
               )
  {
    sop("gtEesAdmListArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_LIST";

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAdmListTabObj  lEesAdmListTabObj = new EesAdmListTabObj();
          lEesAdmListTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid")).trim();

          lEesAdmListTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAdmListTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          lEesAdmListTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          lEesAdmListTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAdmListTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          lEesAdmListTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          lEesAdmListTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          lEesAdmListTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAdmListTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAdmListTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAdmListTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAdmListTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAdmListTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAdmListTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAdmListTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lEesAdmListTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          lEesAdmListTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          lEesAdmListTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          lEesAdmListTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAdmListTabObj.dob != null && lEesAdmListTabObj.dob.length() > 0 ) 
            lEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.dob, lDateTimeTrgFmt);
          lEesAdmListTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( lEesAdmListTabObj.age_on_date != null && lEesAdmListTabObj.age_on_date.length() > 0 ) 
            lEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          lEesAdmListTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          lEesAdmListTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          lEesAdmListTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          lEesAdmListTabObj.religion  =  lResultSet.getString("RELIGION");
          lEesAdmListTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAdmListTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAdmListTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lEesAdmListTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lEesAdmListTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lEesAdmListTabObj.p_state  =  lResultSet.getString("P_STATE");
          lEesAdmListTabObj.p_city  =  lResultSet.getString("P_CITY");
          lEesAdmListTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          lEesAdmListTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lEesAdmListTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lEesAdmListTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lEesAdmListTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lEesAdmListTabObj.m_state  =  lResultSet.getString("M_STATE");
          lEesAdmListTabObj.m_city  =  lResultSet.getString("M_CITY");
          lEesAdmListTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          lEesAdmListTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lEesAdmListTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAdmListTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAdmListTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lEesAdmListTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          lEesAdmListTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAdmListTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAdmListTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAdmListTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAdmListTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAdmListTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAdmListTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAdmListTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          lEesAdmListTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAdmListTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          lEesAdmListTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          lEesAdmListTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          lEesAdmListTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          lEesAdmListTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          lEesAdmListTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          lEesAdmListTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          lEesAdmListTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          lEesAdmListTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAdmListTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          lEesAdmListTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          lEesAdmListTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          lEesAdmListTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          lEesAdmListTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          lEesAdmListTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          lEesAdmListTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          lEesAdmListTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          lEesAdmListTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          lEesAdmListTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          lEesAdmListTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAdmListTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesAdmListTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          lEesAdmListTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( lEesAdmListTabObj.adm_req_sts_date != null && lEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          lEesAdmListTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          lEesAdmListTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( lEesAdmListTabObj.form_recv_date != null && lEesAdmListTabObj.form_recv_date.length() > 0 ) 
            lEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          lEesAdmListTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( lEesAdmListTabObj.prospectus_sale_date != null && lEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          lEesAdmListTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          lEesAdmListTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          lEesAdmListTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          lEesAdmListTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( lEesAdmListTabObj.entrance_exam_date != null && lEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          lEesAdmListTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          lEesAdmListTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          lEesAdmListTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lEesAdmListTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lEesAdmListTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lEesAdmListTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          lEesAdmListTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          lEesAdmListTabObj.grade  =  lResultSet.getString("GRADE");
          lEesAdmListTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( lEesAdmListTabObj.fee_sch_date != null && lEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( lEesAdmListTabObj.fee_deposit_date != null && lEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          lEesAdmListTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          lEesAdmListTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          lEesAdmListTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          lEesAdmListTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          lEesAdmListTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          lEesAdmListTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          lEesAdmListTabObj.unv_1  =  lResultSet.getString("UNV_1");
          lEesAdmListTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          lEesAdmListTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          lEesAdmListTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          lEesAdmListTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          lEesAdmListTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          lEesAdmListTabObj.unv_2  =  lResultSet.getString("UNV_2");
          lEesAdmListTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          lEesAdmListTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          lEesAdmListTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          lEesAdmListTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          lEesAdmListTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          lEesAdmListTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          lEesAdmListTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          lEesAdmListTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          lEesAdmListTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          lEesAdmListTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          lEesAdmListTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( lEesAdmListTabObj.cheque_date != null && lEesAdmListTabObj.cheque_date.length() > 0 ) 
            lEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          lEesAdmListTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          lEesAdmListTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          lEesAdmListTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          lEesAdmListTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          lEesAdmListTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          lEesAdmListTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          lEesAdmListTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          lEesAdmListTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          lEesAdmListTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          lEesAdmListTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          lEesAdmListTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          lEesAdmListTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          lEesAdmListTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          lEesAdmListTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          lEesAdmListTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          lEesAdmListTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          lEesAdmListTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          lEesAdmListTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          lEesAdmListTabObj.allergy  =  lResultSet.getString("ALLERGY");
          lEesAdmListTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          lEesAdmListTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          lEesAdmListTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          lEesAdmListTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          lEesAdmListTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          lEesAdmListTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          lEesAdmListTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          lEesAdmListTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          lEesAdmListTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          lEesAdmListTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          lEesAdmListTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          lEesAdmListTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          lEesAdmListTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          lEesAdmListTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          lEesAdmListTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          lEesAdmListTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          lEesAdmListTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          lEesAdmListTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          lEesAdmListTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          lEesAdmListTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          lEesAdmListTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          lEesAdmListTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          lEesAdmListTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          lEesAdmListTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          lEesAdmListTabObj.remark  =  lResultSet.getString("REMARK");
          lEesAdmListTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          lEesAdmListTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          lEesAdmListTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          lEesAdmListTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          lEesAdmListTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAdmListTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAdmListTabObj( lEesAdmListTabObj );

          outEesAdmListTabObjArr.add(  lEesAdmListTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmListTabObjArr != null && outEesAdmListTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public String gtEesAdmListArr2XML
               ( String inEesAdmListWhereText
               , String  inFieldList
               )
  {
    String lXmlBuffer = "";
    sop("gtEesAdmListArr2XML - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListArr2XML";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

  

       String lSqlStmt = " SELECT "+
                         inFieldList+" "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       String lFieldNameArr[]  = null;
       if ( inFieldList.toUpperCase().indexOf("DISTINCT") > 0 )
       {
         lFieldNameArr  = (inFieldList.substring(inFieldList.indexOf(" ")+1)).split(",");
       }
       else
         lFieldNameArr  = inFieldList.split(",");
//-----------------------------------------------------------------
if ( lFieldNameArr != null && lFieldNameArr.length > 0 )
{
  int lLastIndexOf = 0;
  String lSearchString = " AS ";
  for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
  {
    try
    {
      if ( lFieldNameArr[lFieldCount].contains( lSearchString ) )
      {
        lLastIndexOf = lFieldNameArr[lFieldCount].lastIndexOf( lSearchString );
        lFieldNameArr[lFieldCount] = lFieldNameArr[lFieldCount].substring( lLastIndexOf + lSearchString.length());
      }
    }
    catch ( Exception exp )
    {
      lResultSet.close();
      throw new Exception();
    }
  }
}
else
{
  lResultSet.close();
  throw new Exception();
}
//-----------------------------------------------------------------


       lXmlBuffer = "<EesAdmList>";
       while( lResultSet.next() )
       {
          lXmlBuffer = lXmlBuffer + "<option>";
           for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_id") )
              lXmlBuffer = lXmlBuffer +   "<ORG_ID>" +  lResultSet.getString("ORG_ID") +   "</ORG_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID>" +  lResultSet.getString("ADM_REQ_ID") +   "</ADM_REQ_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("application_form_num") )
              lXmlBuffer = lXmlBuffer +   "<APPLICATION_FORM_NUM>" +  lResultSet.getString("APPLICATION_FORM_NUM") +   "</APPLICATION_FORM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("applicant_id") )
              lXmlBuffer = lXmlBuffer +   "<APPLICANT_ID>" +  lResultSet.getString("APPLICANT_ID") +   "</APPLICANT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_PHOTO_FILE>" +  lResultSet.getString("STUDENT_PHOTO_FILE") +   "</STUDENT_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_PHOTO_FILE>" +  lResultSet.getString("MOTHER_PHOTO_FILE") +   "</MOTHER_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_photo_file") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_PHOTO_FILE>" +  lResultSet.getString("FATHER_PHOTO_FILE") +   "</FATHER_PHOTO_FILE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_id") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_ID>" +  lResultSet.getString("CLASS_ID") +   "</CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_num") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_NUM>" +  lResultSet.getString("CLASS_NUM") +   "</CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_std") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_STD>" +  lResultSet.getString("CLASS_STD") +   "</CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("class_section") )
              lXmlBuffer = lXmlBuffer +   "<CLASS_SECTION>" +  lResultSet.getString("CLASS_SECTION") +   "</CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_id") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_ID>" +  lResultSet.getString("COURSE_ID") +   "</COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_term") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_TERM>" +  lResultSet.getString("COURSE_TERM") +   "</COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM>" +  lResultSet.getString("COURSE_STREAM") +   "</COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("name_initials") )
              lXmlBuffer = lXmlBuffer +   "<NAME_INITIALS>" +  lResultSet.getString("NAME_INITIALS") +   "</NAME_INITIALS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_f_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_F_NAME>" +  lResultSet.getString("STUDENT_F_NAME") +   "</STUDENT_F_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_m_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_M_NAME>" +  lResultSet.getString("STUDENT_M_NAME") +   "</STUDENT_M_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_l_name") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_L_NAME>" +  lResultSet.getString("STUDENT_L_NAME") +   "</STUDENT_L_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("dob") )
              lXmlBuffer = lXmlBuffer +   "<DOB>" +  lResultSet.getString("DOB") +   "</DOB>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_on_date") )
              lXmlBuffer = lXmlBuffer +   "<AGE_ON_DATE>" +  lResultSet.getString("AGE_ON_DATE") +   "</AGE_ON_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_year") )
              lXmlBuffer = lXmlBuffer +   "<AGE_YEAR>" +  lResultSet.getByte("AGE_YEAR") +   "</AGE_YEAR>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_month") )
              lXmlBuffer = lXmlBuffer +   "<AGE_MONTH>" +  lResultSet.getString("AGE_MONTH") +   "</AGE_MONTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("age_day") )
              lXmlBuffer = lXmlBuffer +   "<AGE_DAY>" +  lResultSet.getByte("AGE_DAY") +   "</AGE_DAY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("s_nationality") )
              lXmlBuffer = lXmlBuffer +   "<S_NATIONALITY>" +  lResultSet.getString("S_NATIONALITY") +   "</S_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("religion") )
              lXmlBuffer = lXmlBuffer +   "<RELIGION>" +  lResultSet.getString("RELIGION") +   "</RELIGION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_ctg") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_CTG>" +  lResultSet.getString("STUDENT_CTG") +   "</STUDENT_CTG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gender_flag") )
              lXmlBuffer = lXmlBuffer +   "<GENDER_FLAG>" +  lResultSet.getString("GENDER_FLAG") +   "</GENDER_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_1") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_1>" +  lResultSet.getString("P_ADDRESS_1") +   "</P_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_address_2") )
              lXmlBuffer = lXmlBuffer +   "<P_ADDRESS_2>" +  lResultSet.getString("P_ADDRESS_2") +   "</P_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_country") )
              lXmlBuffer = lXmlBuffer +   "<P_COUNTRY>" +  lResultSet.getString("P_COUNTRY") +   "</P_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_state") )
              lXmlBuffer = lXmlBuffer +   "<P_STATE>" +  lResultSet.getString("P_STATE") +   "</P_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_city") )
              lXmlBuffer = lXmlBuffer +   "<P_CITY>" +  lResultSet.getString("P_CITY") +   "</P_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_district") )
              lXmlBuffer = lXmlBuffer +   "<P_DISTRICT>" +  lResultSet.getString("P_DISTRICT") +   "</P_DISTRICT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("p_zip") )
              lXmlBuffer = lXmlBuffer +   "<P_ZIP>" +  lResultSet.getString("P_ZIP") +   "</P_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_1") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_1>" +  lResultSet.getString("M_ADDRESS_1") +   "</M_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_address_2") )
              lXmlBuffer = lXmlBuffer +   "<M_ADDRESS_2>" +  lResultSet.getString("M_ADDRESS_2") +   "</M_ADDRESS_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_country") )
              lXmlBuffer = lXmlBuffer +   "<M_COUNTRY>" +  lResultSet.getString("M_COUNTRY") +   "</M_COUNTRY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_state") )
              lXmlBuffer = lXmlBuffer +   "<M_STATE>" +  lResultSet.getString("M_STATE") +   "</M_STATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_city") )
              lXmlBuffer = lXmlBuffer +   "<M_CITY>" +  lResultSet.getString("M_CITY") +   "</M_CITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_district") )
              lXmlBuffer = lXmlBuffer +   "<M_DISTRICT>" +  lResultSet.getString("M_DISTRICT") +   "</M_DISTRICT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_zip") )
              lXmlBuffer = lXmlBuffer +   "<M_ZIP>" +  lResultSet.getString("M_ZIP") +   "</M_ZIP>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("phone_list") )
              lXmlBuffer = lXmlBuffer +   "<PHONE_LIST>" +  lResultSet.getString("PHONE_LIST") +   "</PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("email_list") )
              lXmlBuffer = lXmlBuffer +   "<EMAIL_LIST>" +  lResultSet.getString("EMAIL_LIST") +   "</EMAIL_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fax_list") )
              lXmlBuffer = lXmlBuffer +   "<FAX_LIST>" +  lResultSet.getString("FAX_LIST") +   "</FAX_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_org_name") )
              lXmlBuffer = lXmlBuffer +   "<PREV_ORG_NAME>" +  lResultSet.getString("PREV_ORG_NAME") +   "</PREV_ORG_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_ID>" +  lResultSet.getString("PREV_CLASS_ID") +   "</PREV_CLASS_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_num") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_NUM>" +  lResultSet.getString("PREV_CLASS_NUM") +   "</PREV_CLASS_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_std") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_STD>" +  lResultSet.getString("PREV_CLASS_STD") +   "</PREV_CLASS_STD>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_class_section") )
              lXmlBuffer = lXmlBuffer +   "<PREV_CLASS_SECTION>" +  lResultSet.getString("PREV_CLASS_SECTION") +   "</PREV_CLASS_SECTION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_id") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_ID>" +  lResultSet.getString("PREV_COURSE_ID") +   "</PREV_COURSE_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_term") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_TERM>" +  lResultSet.getString("PREV_COURSE_TERM") +   "</PREV_COURSE_TERM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_course_stream") )
              lXmlBuffer = lXmlBuffer +   "<PREV_COURSE_STREAM>" +  lResultSet.getString("PREV_COURSE_STREAM") +   "</PREV_COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reason_for_leaving") )
              lXmlBuffer = lXmlBuffer +   "<REASON_FOR_LEAVING>" +  lResultSet.getString("REASON_FOR_LEAVING") +   "</REASON_FOR_LEAVING>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_name") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_NAME>" +  lResultSet.getString("FATHER_NAME") +   "</FATHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_age") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_AGE>" +  lResultSet.getByte("FATHER_AGE") +   "</FATHER_AGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_nationality") )
              lXmlBuffer = lXmlBuffer +   "<F_NATIONALITY>" +  lResultSet.getString("F_NATIONALITY") +   "</F_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_occ_type") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_OCC_TYPE>" +  lResultSet.getString("FATHER_OCC_TYPE") +   "</FATHER_OCC_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_employer") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_EMPLOYER>" +  lResultSet.getString("FATHER_EMPLOYER") +   "</FATHER_EMPLOYER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_designation") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_DESIGNATION>" +  lResultSet.getString("FATHER_DESIGNATION") +   "</FATHER_DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("father_annual_income") )
              lXmlBuffer = lXmlBuffer +   "<FATHER_ANNUAL_INCOME>" +  lResultSet.getDouble("FATHER_ANNUAL_INCOME") +   "</FATHER_ANNUAL_INCOME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_off_address_1") )
              lXmlBuffer = lXmlBuffer +   "<F_OFF_ADDRESS_1>" +  lResultSet.getString("F_OFF_ADDRESS_1") +   "</F_OFF_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("f_phone_list") )
              lXmlBuffer = lXmlBuffer +   "<F_PHONE_LIST>" +  lResultSet.getString("F_PHONE_LIST") +   "</F_PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_name") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_NAME>" +  lResultSet.getString("MOTHER_NAME") +   "</MOTHER_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_age") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_AGE>" +  lResultSet.getByte("MOTHER_AGE") +   "</MOTHER_AGE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_nationality") )
              lXmlBuffer = lXmlBuffer +   "<M_NATIONALITY>" +  lResultSet.getString("M_NATIONALITY") +   "</M_NATIONALITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_occ_type") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_OCC_TYPE>" +  lResultSet.getString("MOTHER_OCC_TYPE") +   "</MOTHER_OCC_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_employer") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_EMPLOYER>" +  lResultSet.getString("MOTHER_EMPLOYER") +   "</MOTHER_EMPLOYER>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_designation") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_DESIGNATION>" +  lResultSet.getString("MOTHER_DESIGNATION") +   "</MOTHER_DESIGNATION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("mother_annual_income") )
              lXmlBuffer = lXmlBuffer +   "<MOTHER_ANNUAL_INCOME>" +  lResultSet.getDouble("MOTHER_ANNUAL_INCOME") +   "</MOTHER_ANNUAL_INCOME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_off_address_1") )
              lXmlBuffer = lXmlBuffer +   "<M_OFF_ADDRESS_1>" +  lResultSet.getString("M_OFF_ADDRESS_1") +   "</M_OFF_ADDRESS_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("m_phone_list") )
              lXmlBuffer = lXmlBuffer +   "<M_PHONE_LIST>" +  lResultSet.getString("M_PHONE_LIST") +   "</M_PHONE_LIST>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("divorced_flag") )
              lXmlBuffer = lXmlBuffer +   "<DIVORCED_FLAG>" +  lResultSet.getString("DIVORCED_FLAG") +   "</DIVORCED_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("child_with") )
              lXmlBuffer = lXmlBuffer +   "<CHILD_WITH>" +  lResultSet.getString("CHILD_WITH") +   "</CHILD_WITH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("roll_num") )
              lXmlBuffer = lXmlBuffer +   "<ROLL_NUM>" +  lResultSet.getString("ROLL_NUM") +   "</ROLL_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("academic_session") )
              lXmlBuffer = lXmlBuffer +   "<ACADEMIC_SESSION>" +  lResultSet.getString("ACADEMIC_SESSION") +   "</ACADEMIC_SESSION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_sts") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_STS>" +  lResultSet.getString("ADM_REQ_STS") +   "</ADM_REQ_STS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_sts_date") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_STS_DATE>" +  lResultSet.getString("ADM_REQ_STS_DATE") +   "</ADM_REQ_STS_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("student_id") )
              lXmlBuffer = lXmlBuffer +   "<STUDENT_ID>" +  lResultSet.getString("STUDENT_ID") +   "</STUDENT_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("scholor_num") )
              lXmlBuffer = lXmlBuffer +   "<SCHOLOR_NUM>" +  lResultSet.getString("SCHOLOR_NUM") +   "</SCHOLOR_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("form_recv_date") )
              lXmlBuffer = lXmlBuffer +   "<FORM_RECV_DATE>" +  lResultSet.getString("FORM_RECV_DATE") +   "</FORM_RECV_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("form_recv_time") )
              lXmlBuffer = lXmlBuffer +   "<FORM_RECV_TIME>" +  lResultSet.getString("FORM_RECV_TIME") +   "</FORM_RECV_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sale_date") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SALE_DATE>" +  lResultSet.getString("PROSPECTUS_SALE_DATE") +   "</PROSPECTUS_SALE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sale_time") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SALE_TIME>" +  lResultSet.getString("PROSPECTUS_SALE_TIME") +   "</PROSPECTUS_SALE_TIME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prospectus_sold_by") )
              lXmlBuffer = lXmlBuffer +   "<PROSPECTUS_SOLD_BY>" +  lResultSet.getString("PROSPECTUS_SOLD_BY") +   "</PROSPECTUS_SOLD_BY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("application_form_fee") )
              lXmlBuffer = lXmlBuffer +   "<APPLICATION_FORM_FEE>" +  lResultSet.getDouble("APPLICATION_FORM_FEE") +   "</APPLICATION_FORM_FEE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_academic_session") )
              lXmlBuffer = lXmlBuffer +   "<ADM_ACADEMIC_SESSION>" +  lResultSet.getString("ADM_ACADEMIC_SESSION") +   "</ADM_ACADEMIC_SESSION>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_date") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_DATE>" +  lResultSet.getString("ENTRANCE_EXAM_DATE") +   "</ENTRANCE_EXAM_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_time_start") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_TIME_START>" +  lResultSet.getString("ENTRANCE_EXAM_TIME_START") +   "</ENTRANCE_EXAM_TIME_START>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("entrance_exam_time_end") )
              lXmlBuffer = lXmlBuffer +   "<ENTRANCE_EXAM_TIME_END>" +  lResultSet.getString("ENTRANCE_EXAM_TIME_END") +   "</ENTRANCE_EXAM_TIME_END>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("exam_present_status") )
              lXmlBuffer = lXmlBuffer +   "<EXAM_PRESENT_STATUS>" +  lResultSet.getString("EXAM_PRESENT_STATUS") +   "</EXAM_PRESENT_STATUS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("building_id") )
              lXmlBuffer = lXmlBuffer +   "<BUILDING_ID>" +  lResultSet.getString("BUILDING_ID") +   "</BUILDING_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("floor_num") )
              lXmlBuffer = lXmlBuffer +   "<FLOOR_NUM>" +  lResultSet.getString("FLOOR_NUM") +   "</FLOOR_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("room_num") )
              lXmlBuffer = lXmlBuffer +   "<ROOM_NUM>" +  lResultSet.getString("ROOM_NUM") +   "</ROOM_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("max_mark") )
              lXmlBuffer = lXmlBuffer +   "<MAX_MARK>" +  lResultSet.getShort("MAX_MARK") +   "</MAX_MARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("obtained_mark") )
              lXmlBuffer = lXmlBuffer +   "<OBTAINED_MARK>" +  lResultSet.getShort("OBTAINED_MARK") +   "</OBTAINED_MARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("grade") )
              lXmlBuffer = lXmlBuffer +   "<GRADE>" +  lResultSet.getString("GRADE") +   "</GRADE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fee_sch_date") )
              lXmlBuffer = lXmlBuffer +   "<FEE_SCH_DATE>" +  lResultSet.getString("FEE_SCH_DATE") +   "</FEE_SCH_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("fee_deposit_date") )
              lXmlBuffer = lXmlBuffer +   "<FEE_DEPOSIT_DATE>" +  lResultSet.getString("FEE_DEPOSIT_DATE") +   "</FEE_DEPOSIT_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("online_flag") )
              lXmlBuffer = lXmlBuffer +   "<ONLINE_FLAG>" +  lResultSet.getString("ONLINE_FLAG") +   "</ONLINE_FLAG>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("admission_mode") )
              lXmlBuffer = lXmlBuffer +   "<ADMISSION_MODE>" +  lResultSet.getString("ADMISSION_MODE") +   "</ADMISSION_MODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_1") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_1>" +  lResultSet.getString("COURSE_STREAM_1") +   "</COURSE_STREAM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_2") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_2>" +  lResultSet.getString("COURSE_STREAM_2") +   "</COURSE_STREAM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_3") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_3>" +  lResultSet.getString("COURSE_STREAM_3") +   "</COURSE_STREAM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("course_stream_4") )
              lXmlBuffer = lXmlBuffer +   "<COURSE_STREAM_4>" +  lResultSet.getString("COURSE_STREAM_4") +   "</COURSE_STREAM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("apr_course_stream") )
              lXmlBuffer = lXmlBuffer +   "<APR_COURSE_STREAM>" +  lResultSet.getString("APR_COURSE_STREAM") +   "</APR_COURSE_STREAM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_1") )
              lXmlBuffer = lXmlBuffer +   "<UNV_1>" +  lResultSet.getString("UNV_1") +   "</UNV_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_rn_1") )
              lXmlBuffer = lXmlBuffer +   "<UNV_RN_1>" +  lResultSet.getString("UNV_RN_1") +   "</UNV_RN_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gen_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<GEN_RANK_1>" +  lResultSet.getString("GEN_RANK_1") +   "</GEN_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ctg_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<CTG_RANK_1>" +  lResultSet.getString("CTG_RANK_1") +   "</CTG_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stt_rank_1") )
              lXmlBuffer = lXmlBuffer +   "<STT_RANK_1>" +  lResultSet.getString("STT_RANK_1") +   "</STT_RANK_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("yoa_1") )
              lXmlBuffer = lXmlBuffer +   "<YOA_1>" +  lResultSet.getString("YOA_1") +   "</YOA_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_2") )
              lXmlBuffer = lXmlBuffer +   "<UNV_2>" +  lResultSet.getString("UNV_2") +   "</UNV_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("unv_rn_2") )
              lXmlBuffer = lXmlBuffer +   "<UNV_RN_2>" +  lResultSet.getString("UNV_RN_2") +   "</UNV_RN_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("gen_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<GEN_RANK_2>" +  lResultSet.getString("GEN_RANK_2") +   "</GEN_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("ctg_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<CTG_RANK_2>" +  lResultSet.getString("CTG_RANK_2") +   "</CTG_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("stt_rank_2") )
              lXmlBuffer = lXmlBuffer +   "<STT_RANK_2>" +  lResultSet.getString("STT_RANK_2") +   "</STT_RANK_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("yoa_2") )
              lXmlBuffer = lXmlBuffer +   "<YOA_2>" +  lResultSet.getString("YOA_2") +   "</YOA_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("prev_mark_percent") )
              lXmlBuffer = lXmlBuffer +   "<PREV_MARK_PERCENT>" +  lResultSet.getFloat("PREV_MARK_PERCENT") +   "</PREV_MARK_PERCENT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("domecile_ind") )
              lXmlBuffer = lXmlBuffer +   "<DOMECILE_IND>" +  lResultSet.getString("DOMECILE_IND") +   "</DOMECILE_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_transport_req_ind") )
              lXmlBuffer = lXmlBuffer +   "<ORG_TRANSPORT_REQ_IND>" +  lResultSet.getString("ORG_TRANSPORT_REQ_IND") +   "</ORG_TRANSPORT_REQ_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("org_hostel_req_ind") )
              lXmlBuffer = lXmlBuffer +   "<ORG_HOSTEL_REQ_IND>" +  lResultSet.getString("ORG_HOSTEL_REQ_IND") +   "</ORG_HOSTEL_REQ_IND>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_num") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_NUM>" +  lResultSet.getString("CHEQUE_NUM") +   "</CHEQUE_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_date") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_DATE>" +  lResultSet.getString("CHEQUE_DATE") +   "</CHEQUE_DATE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bank_code") )
              lXmlBuffer = lXmlBuffer +   "<BANK_CODE>" +  lResultSet.getString("BANK_CODE") +   "</BANK_CODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("bank_name") )
              lXmlBuffer = lXmlBuffer +   "<BANK_NAME>" +  lResultSet.getString("BANK_NAME") +   "</BANK_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("cheque_amt") )
              lXmlBuffer = lXmlBuffer +   "<CHEQUE_AMT>" +  lResultSet.getDouble("CHEQUE_AMT") +   "</CHEQUE_AMT>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_name") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_NAME>" +  lResultSet.getString("LG_0_NAME") +   "</LG_0_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_rel_type") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_REL_TYPE>" +  lResultSet.getString("LG_0_REL_TYPE") +   "</LG_0_REL_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_address") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_ADDRESS>" +  lResultSet.getString("LG_0_ADDRESS") +   "</LG_0_ADDRESS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_0_phone") )
              lXmlBuffer = lXmlBuffer +   "<LG_0_PHONE>" +  lResultSet.getString("LG_0_PHONE") +   "</LG_0_PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_name") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_NAME>" +  lResultSet.getString("LG_1_NAME") +   "</LG_1_NAME>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_rel_type") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_REL_TYPE>" +  lResultSet.getString("LG_1_REL_TYPE") +   "</LG_1_REL_TYPE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_address") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_ADDRESS>" +  lResultSet.getString("LG_1_ADDRESS") +   "</LG_1_ADDRESS>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("lg_1_phone") )
              lXmlBuffer = lXmlBuffer +   "<LG_1_PHONE>" +  lResultSet.getString("LG_1_PHONE") +   "</LG_1_PHONE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_1") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_1>" +  lResultSet.getString("ST_CAP_ATTR_1") +   "</ST_CAP_ATTR_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_2") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_2>" +  lResultSet.getString("ST_CAP_ATTR_2") +   "</ST_CAP_ATTR_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_3") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_3>" +  lResultSet.getString("ST_CAP_ATTR_3") +   "</ST_CAP_ATTR_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_4") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_4>" +  lResultSet.getString("ST_CAP_ATTR_4") +   "</ST_CAP_ATTR_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_5") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_5>" +  lResultSet.getString("ST_CAP_ATTR_5") +   "</ST_CAP_ATTR_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_6") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_6>" +  lResultSet.getString("ST_CAP_ATTR_6") +   "</ST_CAP_ATTR_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_7") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_7>" +  lResultSet.getString("ST_CAP_ATTR_7") +   "</ST_CAP_ATTR_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("st_cap_attr_8") )
              lXmlBuffer = lXmlBuffer +   "<ST_CAP_ATTR_8>" +  lResultSet.getString("ST_CAP_ATTR_8") +   "</ST_CAP_ATTR_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("allergy") )
              lXmlBuffer = lXmlBuffer +   "<ALLERGY>" +  lResultSet.getString("ALLERGY") +   "</ALLERGY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("physical_disability") )
              lXmlBuffer = lXmlBuffer +   "<PHYSICAL_DISABILITY>" +  lResultSet.getString("PHYSICAL_DISABILITY") +   "</PHYSICAL_DISABILITY>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM>" +  lResultSet.getString("HEALTH_PROBLEM") +   "</HEALTH_PROBLEM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_1") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_1>" +  lResultSet.getString("HEALTH_PROBLEM_1") +   "</HEALTH_PROBLEM_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_2") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_2>" +  lResultSet.getString("HEALTH_PROBLEM_2") +   "</HEALTH_PROBLEM_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_3") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_3>" +  lResultSet.getString("HEALTH_PROBLEM_3") +   "</HEALTH_PROBLEM_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_4") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_4>" +  lResultSet.getString("HEALTH_PROBLEM_4") +   "</HEALTH_PROBLEM_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_5") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_5>" +  lResultSet.getString("HEALTH_PROBLEM_5") +   "</HEALTH_PROBLEM_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_6") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_6>" +  lResultSet.getString("HEALTH_PROBLEM_6") +   "</HEALTH_PROBLEM_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_7") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_7>" +  lResultSet.getString("HEALTH_PROBLEM_7") +   "</HEALTH_PROBLEM_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_8") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_8>" +  lResultSet.getString("HEALTH_PROBLEM_8") +   "</HEALTH_PROBLEM_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_9") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_9>" +  lResultSet.getString("HEALTH_PROBLEM_9") +   "</HEALTH_PROBLEM_9>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_10") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_10>" +  lResultSet.getString("HEALTH_PROBLEM_10") +   "</HEALTH_PROBLEM_10>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_11") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_11>" +  lResultSet.getString("HEALTH_PROBLEM_11") +   "</HEALTH_PROBLEM_11>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("health_problem_12") )
              lXmlBuffer = lXmlBuffer +   "<HEALTH_PROBLEM_12>" +  lResultSet.getString("HEALTH_PROBLEM_12") +   "</HEALTH_PROBLEM_12>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_1") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_1>" +  lResultSet.getString("ENCLOSURE_1") +   "</ENCLOSURE_1>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_2") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_2>" +  lResultSet.getString("ENCLOSURE_2") +   "</ENCLOSURE_2>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_3") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_3>" +  lResultSet.getString("ENCLOSURE_3") +   "</ENCLOSURE_3>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_4") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_4>" +  lResultSet.getString("ENCLOSURE_4") +   "</ENCLOSURE_4>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_5") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_5>" +  lResultSet.getString("ENCLOSURE_5") +   "</ENCLOSURE_5>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_6") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_6>" +  lResultSet.getString("ENCLOSURE_6") +   "</ENCLOSURE_6>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_7") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_7>" +  lResultSet.getString("ENCLOSURE_7") +   "</ENCLOSURE_7>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("enclosure_8") )
              lXmlBuffer = lXmlBuffer +   "<ENCLOSURE_8>" +  lResultSet.getString("ENCLOSURE_8") +   "</ENCLOSURE_8>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("seat_num") )
              lXmlBuffer = lXmlBuffer +   "<SEAT_NUM>" +  lResultSet.getShort("SEAT_NUM") +   "</SEAT_NUM>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("reason_for_join") )
              lXmlBuffer = lXmlBuffer +   "<REASON_FOR_JOIN>" +  lResultSet.getString("REASON_FOR_JOIN") +   "</REASON_FOR_JOIN>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("remark") )
              lXmlBuffer = lXmlBuffer +   "<REMARK>" +  lResultSet.getString("REMARK") +   "</REMARK>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("place_of_birth") )
              lXmlBuffer = lXmlBuffer +   "<PLACE_OF_BIRTH>" +  lResultSet.getString("PLACE_OF_BIRTH") +   "</PLACE_OF_BIRTH>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adv_adm_fee") )
              lXmlBuffer = lXmlBuffer +   "<ADV_ADM_FEE>" +  lResultSet.getDouble("ADV_ADM_FEE") +   "</ADV_ADM_FEE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("payment_mode") )
              lXmlBuffer = lXmlBuffer +   "<PAYMENT_MODE>" +  lResultSet.getString("PAYMENT_MODE") +   "</PAYMENT_MODE>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("target_ptl_user_id") )
              lXmlBuffer = lXmlBuffer +   "<TARGET_PTL_USER_ID>" +  lResultSet.getString("TARGET_PTL_USER_ID") +   "</TARGET_PTL_USER_ID>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_req") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_REQ>" +  lResultSet.getString("ADM_REQ_ID_REQ") +   "</ADM_REQ_ID_REQ>" ;
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
            if ( (lFieldNameArr[ lFieldCount ].trim().toLowerCase()).equals("adm_req_id_list") )
              lXmlBuffer = lXmlBuffer +   "<ADM_REQ_ID_LIST>" +  lResultSet.getString("ADM_REQ_ID_LIST") +   "</ADM_REQ_ID_LIST>" ;


          lXmlBuffer = lXmlBuffer + "</option>";
       }
       lXmlBuffer = lXmlBuffer + "</EesAdmList>";

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
       return lXmlBuffer;
  }





  public int gtEesAdmListRecByRowid
               ( String inRowId
               , EesAdmListTabObj  outEesAdmListTabObj
               )
  {
    sop("gtEesAdmListRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_LIST "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception();
       }

       while(lResultSet.next())
       {
          outEesAdmListTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          outEesAdmListTabObj.org_id  =  lResultSet.getString("ORG_ID");
          outEesAdmListTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          outEesAdmListTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          outEesAdmListTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          outEesAdmListTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          outEesAdmListTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          outEesAdmListTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          outEesAdmListTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          outEesAdmListTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          outEesAdmListTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          outEesAdmListTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          outEesAdmListTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          outEesAdmListTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          outEesAdmListTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          outEesAdmListTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          outEesAdmListTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          outEesAdmListTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          outEesAdmListTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          outEesAdmListTabObj.dob  =  lResultSet.getString("DOB");

          if ( outEesAdmListTabObj.dob != null && outEesAdmListTabObj.dob.length() > 0 ) 
            outEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.dob, lDateTimeTrgFmt);
          outEesAdmListTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( outEesAdmListTabObj.age_on_date != null && outEesAdmListTabObj.age_on_date.length() > 0 ) 
            outEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          outEesAdmListTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          outEesAdmListTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          outEesAdmListTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          outEesAdmListTabObj.religion  =  lResultSet.getString("RELIGION");
          outEesAdmListTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          outEesAdmListTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          outEesAdmListTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          outEesAdmListTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          outEesAdmListTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          outEesAdmListTabObj.p_state  =  lResultSet.getString("P_STATE");
          outEesAdmListTabObj.p_city  =  lResultSet.getString("P_CITY");
          outEesAdmListTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          outEesAdmListTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          outEesAdmListTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          outEesAdmListTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          outEesAdmListTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          outEesAdmListTabObj.m_state  =  lResultSet.getString("M_STATE");
          outEesAdmListTabObj.m_city  =  lResultSet.getString("M_CITY");
          outEesAdmListTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          outEesAdmListTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          outEesAdmListTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          outEesAdmListTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          outEesAdmListTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          outEesAdmListTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          outEesAdmListTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          outEesAdmListTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          outEesAdmListTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          outEesAdmListTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          outEesAdmListTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          outEesAdmListTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          outEesAdmListTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          outEesAdmListTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          outEesAdmListTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          outEesAdmListTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          outEesAdmListTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          outEesAdmListTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          outEesAdmListTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          outEesAdmListTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          outEesAdmListTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          outEesAdmListTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          outEesAdmListTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          outEesAdmListTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          outEesAdmListTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          outEesAdmListTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          outEesAdmListTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          outEesAdmListTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          outEesAdmListTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          outEesAdmListTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          outEesAdmListTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          outEesAdmListTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          outEesAdmListTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          outEesAdmListTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          outEesAdmListTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          outEesAdmListTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          outEesAdmListTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          outEesAdmListTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( outEesAdmListTabObj.adm_req_sts_date != null && outEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            outEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          outEesAdmListTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          outEesAdmListTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( outEesAdmListTabObj.form_recv_date != null && outEesAdmListTabObj.form_recv_date.length() > 0 ) 
            outEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          outEesAdmListTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( outEesAdmListTabObj.prospectus_sale_date != null && outEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            outEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          outEesAdmListTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          outEesAdmListTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          outEesAdmListTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          outEesAdmListTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( outEesAdmListTabObj.entrance_exam_date != null && outEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            outEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          outEesAdmListTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          outEesAdmListTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          outEesAdmListTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          outEesAdmListTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          outEesAdmListTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          outEesAdmListTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          outEesAdmListTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          outEesAdmListTabObj.grade  =  lResultSet.getString("GRADE");
          outEesAdmListTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( outEesAdmListTabObj.fee_sch_date != null && outEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            outEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( outEesAdmListTabObj.fee_deposit_date != null && outEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            outEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          outEesAdmListTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          outEesAdmListTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          outEesAdmListTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          outEesAdmListTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          outEesAdmListTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          outEesAdmListTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          outEesAdmListTabObj.unv_1  =  lResultSet.getString("UNV_1");
          outEesAdmListTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          outEesAdmListTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          outEesAdmListTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          outEesAdmListTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          outEesAdmListTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          outEesAdmListTabObj.unv_2  =  lResultSet.getString("UNV_2");
          outEesAdmListTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          outEesAdmListTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          outEesAdmListTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          outEesAdmListTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          outEesAdmListTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          outEesAdmListTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          outEesAdmListTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          outEesAdmListTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          outEesAdmListTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          outEesAdmListTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          outEesAdmListTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( outEesAdmListTabObj.cheque_date != null && outEesAdmListTabObj.cheque_date.length() > 0 ) 
            outEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, outEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
          outEesAdmListTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          outEesAdmListTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          outEesAdmListTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          outEesAdmListTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          outEesAdmListTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          outEesAdmListTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          outEesAdmListTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          outEesAdmListTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          outEesAdmListTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          outEesAdmListTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          outEesAdmListTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          outEesAdmListTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          outEesAdmListTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          outEesAdmListTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          outEesAdmListTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          outEesAdmListTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          outEesAdmListTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          outEesAdmListTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          outEesAdmListTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          outEesAdmListTabObj.allergy  =  lResultSet.getString("ALLERGY");
          outEesAdmListTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          outEesAdmListTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          outEesAdmListTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          outEesAdmListTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          outEesAdmListTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          outEesAdmListTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          outEesAdmListTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          outEesAdmListTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          outEesAdmListTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          outEesAdmListTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          outEesAdmListTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          outEesAdmListTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          outEesAdmListTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          outEesAdmListTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          outEesAdmListTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          outEesAdmListTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          outEesAdmListTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          outEesAdmListTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          outEesAdmListTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          outEesAdmListTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          outEesAdmListTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          outEesAdmListTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          outEesAdmListTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          outEesAdmListTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          outEesAdmListTabObj.remark  =  lResultSet.getString("REMARK");
          outEesAdmListTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          outEesAdmListTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          outEesAdmListTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          outEesAdmListTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          outEesAdmListTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          outEesAdmListTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");
          NO_DATA_FOUND = true;
       }
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       removeNullEesAdmListTabObj( outEesAdmListTabObj );

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListArr
               ( String inEesAdmListWhereText
               , ArrayList  outEesAdmListTabObjArr
               )
  {
    sop("gtEesAdmListArr - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT OID AS ROWID, "+
                                 "org_id, "+
                                 "adm_req_id, "+
                                 "application_form_num, "+
                                 "applicant_id, "+
                                 "student_photo_file, "+
                                 "mother_photo_file, "+
                                 "father_photo_file, "+
                                 "class_id, "+
                                 "class_num, "+
                                 "class_std, "+
                                 "class_section, "+
                                 "course_id, "+
                                 "course_term, "+
                                 "course_stream, "+
                                 "name_initials, "+
                                 "student_f_name, "+
                                 "student_m_name, "+
                                 "student_l_name, "+
                                 "dob, "+
                                 "age_on_date, "+
                                 "age_year, "+
                                 "age_month, "+
                                 "age_day, "+
                                 "s_nationality, "+
                                 "religion, "+
                                 "student_ctg, "+
                                 "gender_flag, "+
                                 "p_address_1, "+
                                 "p_address_2, "+
                                 "p_country, "+
                                 "p_state, "+
                                 "p_city, "+
                                 "p_district, "+
                                 "p_zip, "+
                                 "m_address_1, "+
                                 "m_address_2, "+
                                 "m_country, "+
                                 "m_state, "+
                                 "m_city, "+
                                 "m_district, "+
                                 "m_zip, "+
                                 "phone_list, "+
                                 "email_list, "+
                                 "fax_list, "+
                                 "prev_org_name, "+
                                 "prev_class_id, "+
                                 "prev_class_num, "+
                                 "prev_class_std, "+
                                 "prev_class_section, "+
                                 "prev_course_id, "+
                                 "prev_course_term, "+
                                 "prev_course_stream, "+
                                 "reason_for_leaving, "+
                                 "father_name, "+
                                 "father_age, "+
                                 "f_nationality, "+
                                 "father_occ_type, "+
                                 "father_employer, "+
                                 "father_designation, "+
                                 "father_annual_income, "+
                                 "f_off_address_1, "+
                                 "f_phone_list, "+
                                 "mother_name, "+
                                 "mother_age, "+
                                 "m_nationality, "+
                                 "mother_occ_type, "+
                                 "mother_employer, "+
                                 "mother_designation, "+
                                 "mother_annual_income, "+
                                 "m_off_address_1, "+
                                 "m_phone_list, "+
                                 "divorced_flag, "+
                                 "child_with, "+
                                 "roll_num, "+
                                 "academic_session, "+
                                 "adm_req_sts, "+
                                 "adm_req_sts_date, "+
                                 "student_id, "+
                                 "scholor_num, "+
                                 "form_recv_date, "+
                                 "form_recv_time, "+
                                 "prospectus_sale_date, "+
                                 "prospectus_sale_time, "+
                                 "prospectus_sold_by, "+
                                 "application_form_fee, "+
                                 "adm_academic_session, "+
                                 "entrance_exam_date, "+
                                 "entrance_exam_time_start, "+
                                 "entrance_exam_time_end, "+
                                 "exam_present_status, "+
                                 "building_id, "+
                                 "floor_num, "+
                                 "room_num, "+
                                 "max_mark, "+
                                 "obtained_mark, "+
                                 "grade, "+
                                 "fee_sch_date, "+
                                 "fee_deposit_date, "+
                                 "online_flag, "+
                                 "admission_mode, "+
                                 "course_stream_1, "+
                                 "course_stream_2, "+
                                 "course_stream_3, "+
                                 "course_stream_4, "+
                                 "apr_course_stream, "+
                                 "unv_1, "+
                                 "unv_rn_1, "+
                                 "gen_rank_1, "+
                                 "ctg_rank_1, "+
                                 "stt_rank_1, "+
                                 "yoa_1, "+
                                 "unv_2, "+
                                 "unv_rn_2, "+
                                 "gen_rank_2, "+
                                 "ctg_rank_2, "+
                                 "stt_rank_2, "+
                                 "yoa_2, "+
                                 "prev_mark_percent, "+
                                 "domecile_ind, "+
                                 "org_transport_req_ind, "+
                                 "org_hostel_req_ind, "+
                                 "cheque_num, "+
                                 "cheque_date, "+
                                 "bank_code, "+
                                 "bank_name, "+
                                 "cheque_amt, "+
                                 "lg_0_name, "+
                                 "lg_0_rel_type, "+
                                 "lg_0_address, "+
                                 "lg_0_phone, "+
                                 "lg_1_name, "+
                                 "lg_1_rel_type, "+
                                 "lg_1_address, "+
                                 "lg_1_phone, "+
                                 "st_cap_attr_1, "+
                                 "st_cap_attr_2, "+
                                 "st_cap_attr_3, "+
                                 "st_cap_attr_4, "+
                                 "st_cap_attr_5, "+
                                 "st_cap_attr_6, "+
                                 "st_cap_attr_7, "+
                                 "st_cap_attr_8, "+
                                 "allergy, "+
                                 "physical_disability, "+
                                 "health_problem, "+
                                 "health_problem_1, "+
                                 "health_problem_2, "+
                                 "health_problem_3, "+
                                 "health_problem_4, "+
                                 "health_problem_5, "+
                                 "health_problem_6, "+
                                 "health_problem_7, "+
                                 "health_problem_8, "+
                                 "health_problem_9, "+
                                 "health_problem_10, "+
                                 "health_problem_11, "+
                                 "health_problem_12, "+
                                 "enclosure_1, "+
                                 "enclosure_2, "+
                                 "enclosure_3, "+
                                 "enclosure_4, "+
                                 "enclosure_5, "+
                                 "enclosure_6, "+
                                 "enclosure_7, "+
                                 "enclosure_8, "+
                                 "seat_num, "+
                                 "reason_for_join, "+
                                 "remark, "+
                                 "place_of_birth, "+
                                 "adv_adm_fee, "+
                                 "payment_mode, "+
                                 "target_ptl_user_id, "+
                                 "adm_req_id_req, "+
                                 "adm_req_id_list "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode;
         throw new Exception(); 
       }

       while(lResultSet.next())
       {
          EesAdmListTabObj  lEesAdmListTabObj = new EesAdmListTabObj();
          lEesAdmListTabObj.tab_rowid  = Integer.toString(lResultSet.getInt("rowid"));

          lEesAdmListTabObj.org_id  =  lResultSet.getString("ORG_ID");
          lEesAdmListTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
          lEesAdmListTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
          lEesAdmListTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
          lEesAdmListTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
          lEesAdmListTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
          lEesAdmListTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
          lEesAdmListTabObj.class_id  =  lResultSet.getString("CLASS_ID");
          lEesAdmListTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
          lEesAdmListTabObj.class_std  =  lResultSet.getString("CLASS_STD");
          lEesAdmListTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
          lEesAdmListTabObj.course_id  =  lResultSet.getString("COURSE_ID");
          lEesAdmListTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
          lEesAdmListTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
          lEesAdmListTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
          lEesAdmListTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
          lEesAdmListTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
          lEesAdmListTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
          lEesAdmListTabObj.dob  =  lResultSet.getString("DOB");

          if ( lEesAdmListTabObj.dob != null && lEesAdmListTabObj.dob.length() > 0 ) 
            lEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.dob, lDateTimeTrgFmt);
          lEesAdmListTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");

          if ( lEesAdmListTabObj.age_on_date != null && lEesAdmListTabObj.age_on_date.length() > 0 ) 
            lEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
          lEesAdmListTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
          lEesAdmListTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
          lEesAdmListTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
          lEesAdmListTabObj.religion  =  lResultSet.getString("RELIGION");
          lEesAdmListTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
          lEesAdmListTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
          lEesAdmListTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
          lEesAdmListTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
          lEesAdmListTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
          lEesAdmListTabObj.p_state  =  lResultSet.getString("P_STATE");
          lEesAdmListTabObj.p_city  =  lResultSet.getString("P_CITY");
          lEesAdmListTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
          lEesAdmListTabObj.p_zip  =  lResultSet.getString("P_ZIP");
          lEesAdmListTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
          lEesAdmListTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
          lEesAdmListTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
          lEesAdmListTabObj.m_state  =  lResultSet.getString("M_STATE");
          lEesAdmListTabObj.m_city  =  lResultSet.getString("M_CITY");
          lEesAdmListTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
          lEesAdmListTabObj.m_zip  =  lResultSet.getString("M_ZIP");
          lEesAdmListTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
          lEesAdmListTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
          lEesAdmListTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
          lEesAdmListTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
          lEesAdmListTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
          lEesAdmListTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
          lEesAdmListTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
          lEesAdmListTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
          lEesAdmListTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
          lEesAdmListTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
          lEesAdmListTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
          lEesAdmListTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
          lEesAdmListTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
          lEesAdmListTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
          lEesAdmListTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
          lEesAdmListTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
          lEesAdmListTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
          lEesAdmListTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
          lEesAdmListTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
          lEesAdmListTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
          lEesAdmListTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
          lEesAdmListTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
          lEesAdmListTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
          lEesAdmListTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
          lEesAdmListTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
          lEesAdmListTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
          lEesAdmListTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
          lEesAdmListTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
          lEesAdmListTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
          lEesAdmListTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
          lEesAdmListTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
          lEesAdmListTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
          lEesAdmListTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
          lEesAdmListTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
          lEesAdmListTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
          lEesAdmListTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");

          if ( lEesAdmListTabObj.adm_req_sts_date != null && lEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
          lEesAdmListTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
          lEesAdmListTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");

          if ( lEesAdmListTabObj.form_recv_date != null && lEesAdmListTabObj.form_recv_date.length() > 0 ) 
            lEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
          lEesAdmListTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");

          if ( lEesAdmListTabObj.prospectus_sale_date != null && lEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
          lEesAdmListTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
          lEesAdmListTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
          lEesAdmListTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
          lEesAdmListTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");

          if ( lEesAdmListTabObj.entrance_exam_date != null && lEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
          lEesAdmListTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
          lEesAdmListTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
          lEesAdmListTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
          lEesAdmListTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
          lEesAdmListTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
          lEesAdmListTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
          lEesAdmListTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
          lEesAdmListTabObj.grade  =  lResultSet.getString("GRADE");
          lEesAdmListTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");

          if ( lEesAdmListTabObj.fee_sch_date != null && lEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");

          if ( lEesAdmListTabObj.fee_deposit_date != null && lEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
          lEesAdmListTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
          lEesAdmListTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
          lEesAdmListTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
          lEesAdmListTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
          lEesAdmListTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
          lEesAdmListTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
          lEesAdmListTabObj.unv_1  =  lResultSet.getString("UNV_1");
          lEesAdmListTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
          lEesAdmListTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
          lEesAdmListTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
          lEesAdmListTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
          lEesAdmListTabObj.yoa_1  =  lResultSet.getString("YOA_1");
          lEesAdmListTabObj.unv_2  =  lResultSet.getString("UNV_2");
          lEesAdmListTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
          lEesAdmListTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
          lEesAdmListTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
          lEesAdmListTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
          lEesAdmListTabObj.yoa_2  =  lResultSet.getString("YOA_2");
          lEesAdmListTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
          lEesAdmListTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
          lEesAdmListTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
          lEesAdmListTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
          lEesAdmListTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
          lEesAdmListTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");

          if ( lEesAdmListTabObj.cheque_date != null && lEesAdmListTabObj.cheque_date.length() > 0 ) 
            lEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
          lEesAdmListTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
          lEesAdmListTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
          lEesAdmListTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
          lEesAdmListTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
          lEesAdmListTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
          lEesAdmListTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
          lEesAdmListTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
          lEesAdmListTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
          lEesAdmListTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
          lEesAdmListTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
          lEesAdmListTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
          lEesAdmListTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
          lEesAdmListTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
          lEesAdmListTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
          lEesAdmListTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
          lEesAdmListTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
          lEesAdmListTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
          lEesAdmListTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
          lEesAdmListTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
          lEesAdmListTabObj.allergy  =  lResultSet.getString("ALLERGY");
          lEesAdmListTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
          lEesAdmListTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
          lEesAdmListTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
          lEesAdmListTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
          lEesAdmListTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
          lEesAdmListTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
          lEesAdmListTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
          lEesAdmListTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
          lEesAdmListTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
          lEesAdmListTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
          lEesAdmListTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
          lEesAdmListTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
          lEesAdmListTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
          lEesAdmListTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
          lEesAdmListTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
          lEesAdmListTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
          lEesAdmListTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
          lEesAdmListTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
          lEesAdmListTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
          lEesAdmListTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
          lEesAdmListTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
          lEesAdmListTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
          lEesAdmListTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
          lEesAdmListTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
          lEesAdmListTabObj.remark  =  lResultSet.getString("REMARK");
          lEesAdmListTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
          lEesAdmListTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
          lEesAdmListTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
          lEesAdmListTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
          lEesAdmListTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
          lEesAdmListTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          removeNullEesAdmListTabObj( lEesAdmListTabObj );

          outEesAdmListTabObjArr.add(  lEesAdmListTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////

     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmListTabObjArr != null && outEesAdmListTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListArrDist
               ( String inEesAdmListWhereText
               , String inDistEesAdmListField
               , ArrayList  outEesAdmListTabObjArr
               )
  {

    sop("gtEesAdmListArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";
  

       String lDistEesAdmListFieldQry = inDistEesAdmListField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAdmListFieldQry+
                         " FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAdmListField.substring(inDistEesAdmListField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       while(lResultSet.next())
       {
          EesAdmListTabObj  lEesAdmListTabObj = new EesAdmListTabObj();
          for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
          {
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_id") )
              lEesAdmListTabObj.org_id  =  lResultSet.getString("ORG_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id") )
              lEesAdmListTabObj.adm_req_id  =  lResultSet.getString("ADM_REQ_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("application_form_num") )
              lEesAdmListTabObj.application_form_num  =  lResultSet.getString("APPLICATION_FORM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("applicant_id") )
              lEesAdmListTabObj.applicant_id  =  lResultSet.getString("APPLICANT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_photo_file") )
              lEesAdmListTabObj.student_photo_file  =  lResultSet.getString("STUDENT_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_photo_file") )
              lEesAdmListTabObj.mother_photo_file  =  lResultSet.getString("MOTHER_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_photo_file") )
              lEesAdmListTabObj.father_photo_file  =  lResultSet.getString("FATHER_PHOTO_FILE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_id") )
              lEesAdmListTabObj.class_id  =  lResultSet.getString("CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_num") )
              lEesAdmListTabObj.class_num  =  lResultSet.getString("CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_std") )
              lEesAdmListTabObj.class_std  =  lResultSet.getString("CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("class_section") )
              lEesAdmListTabObj.class_section  =  lResultSet.getString("CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_id") )
              lEesAdmListTabObj.course_id  =  lResultSet.getString("COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_term") )
              lEesAdmListTabObj.course_term  =  lResultSet.getString("COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream") )
              lEesAdmListTabObj.course_stream  =  lResultSet.getString("COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("name_initials") )
              lEesAdmListTabObj.name_initials  =  lResultSet.getString("NAME_INITIALS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_f_name") )
              lEesAdmListTabObj.student_f_name  =  lResultSet.getString("STUDENT_F_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_m_name") )
              lEesAdmListTabObj.student_m_name  =  lResultSet.getString("STUDENT_M_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_l_name") )
              lEesAdmListTabObj.student_l_name  =  lResultSet.getString("STUDENT_L_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("dob") )
              {
              lEesAdmListTabObj.dob  =  lResultSet.getString("DOB");
  
          if ( lEesAdmListTabObj.dob != null && lEesAdmListTabObj.dob.length() > 0 ) 
            lEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.dob, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_on_date") )
              {
              lEesAdmListTabObj.age_on_date  =  lResultSet.getString("AGE_ON_DATE");
  
          if ( lEesAdmListTabObj.age_on_date != null && lEesAdmListTabObj.age_on_date.length() > 0 ) 
            lEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.age_on_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_year") )
              lEesAdmListTabObj.age_year  =  lResultSet.getByte("AGE_YEAR");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_month") )
              lEesAdmListTabObj.age_month  =  lResultSet.getString("AGE_MONTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("age_day") )
              lEesAdmListTabObj.age_day  =  lResultSet.getByte("AGE_DAY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("s_nationality") )
              lEesAdmListTabObj.s_nationality  =  lResultSet.getString("S_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("religion") )
              lEesAdmListTabObj.religion  =  lResultSet.getString("RELIGION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_ctg") )
              lEesAdmListTabObj.student_ctg  =  lResultSet.getString("STUDENT_CTG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gender_flag") )
              lEesAdmListTabObj.gender_flag  =  lResultSet.getString("GENDER_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_1") )
              lEesAdmListTabObj.p_address_1  =  lResultSet.getString("P_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_address_2") )
              lEesAdmListTabObj.p_address_2  =  lResultSet.getString("P_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_country") )
              lEesAdmListTabObj.p_country  =  lResultSet.getString("P_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_state") )
              lEesAdmListTabObj.p_state  =  lResultSet.getString("P_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_city") )
              lEesAdmListTabObj.p_city  =  lResultSet.getString("P_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_district") )
              lEesAdmListTabObj.p_district  =  lResultSet.getString("P_DISTRICT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("p_zip") )
              lEesAdmListTabObj.p_zip  =  lResultSet.getString("P_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_1") )
              lEesAdmListTabObj.m_address_1  =  lResultSet.getString("M_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_address_2") )
              lEesAdmListTabObj.m_address_2  =  lResultSet.getString("M_ADDRESS_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_country") )
              lEesAdmListTabObj.m_country  =  lResultSet.getString("M_COUNTRY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_state") )
              lEesAdmListTabObj.m_state  =  lResultSet.getString("M_STATE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_city") )
              lEesAdmListTabObj.m_city  =  lResultSet.getString("M_CITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_district") )
              lEesAdmListTabObj.m_district  =  lResultSet.getString("M_DISTRICT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_zip") )
              lEesAdmListTabObj.m_zip  =  lResultSet.getString("M_ZIP");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("phone_list") )
              lEesAdmListTabObj.phone_list  =  lResultSet.getString("PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("email_list") )
              lEesAdmListTabObj.email_list  =  lResultSet.getString("EMAIL_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fax_list") )
              lEesAdmListTabObj.fax_list  =  lResultSet.getString("FAX_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_org_name") )
              lEesAdmListTabObj.prev_org_name  =  lResultSet.getString("PREV_ORG_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_id") )
              lEesAdmListTabObj.prev_class_id  =  lResultSet.getString("PREV_CLASS_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_num") )
              lEesAdmListTabObj.prev_class_num  =  lResultSet.getString("PREV_CLASS_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_std") )
              lEesAdmListTabObj.prev_class_std  =  lResultSet.getString("PREV_CLASS_STD");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_class_section") )
              lEesAdmListTabObj.prev_class_section  =  lResultSet.getString("PREV_CLASS_SECTION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_id") )
              lEesAdmListTabObj.prev_course_id  =  lResultSet.getString("PREV_COURSE_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_term") )
              lEesAdmListTabObj.prev_course_term  =  lResultSet.getString("PREV_COURSE_TERM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_course_stream") )
              lEesAdmListTabObj.prev_course_stream  =  lResultSet.getString("PREV_COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reason_for_leaving") )
              lEesAdmListTabObj.reason_for_leaving  =  lResultSet.getString("REASON_FOR_LEAVING");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_name") )
              lEesAdmListTabObj.father_name  =  lResultSet.getString("FATHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_age") )
              lEesAdmListTabObj.father_age  =  lResultSet.getByte("FATHER_AGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_nationality") )
              lEesAdmListTabObj.f_nationality  =  lResultSet.getString("F_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_occ_type") )
              lEesAdmListTabObj.father_occ_type  =  lResultSet.getString("FATHER_OCC_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_employer") )
              lEesAdmListTabObj.father_employer  =  lResultSet.getString("FATHER_EMPLOYER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_designation") )
              lEesAdmListTabObj.father_designation  =  lResultSet.getString("FATHER_DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("father_annual_income") )
              lEesAdmListTabObj.father_annual_income  =  lResultSet.getDouble("FATHER_ANNUAL_INCOME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_off_address_1") )
              lEesAdmListTabObj.f_off_address_1  =  lResultSet.getString("F_OFF_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("f_phone_list") )
              lEesAdmListTabObj.f_phone_list  =  lResultSet.getString("F_PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_name") )
              lEesAdmListTabObj.mother_name  =  lResultSet.getString("MOTHER_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_age") )
              lEesAdmListTabObj.mother_age  =  lResultSet.getByte("MOTHER_AGE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_nationality") )
              lEesAdmListTabObj.m_nationality  =  lResultSet.getString("M_NATIONALITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_occ_type") )
              lEesAdmListTabObj.mother_occ_type  =  lResultSet.getString("MOTHER_OCC_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_employer") )
              lEesAdmListTabObj.mother_employer  =  lResultSet.getString("MOTHER_EMPLOYER");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_designation") )
              lEesAdmListTabObj.mother_designation  =  lResultSet.getString("MOTHER_DESIGNATION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("mother_annual_income") )
              lEesAdmListTabObj.mother_annual_income  =  lResultSet.getDouble("MOTHER_ANNUAL_INCOME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_off_address_1") )
              lEesAdmListTabObj.m_off_address_1  =  lResultSet.getString("M_OFF_ADDRESS_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("m_phone_list") )
              lEesAdmListTabObj.m_phone_list  =  lResultSet.getString("M_PHONE_LIST");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("divorced_flag") )
              lEesAdmListTabObj.divorced_flag  =  lResultSet.getString("DIVORCED_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("child_with") )
              lEesAdmListTabObj.child_with  =  lResultSet.getString("CHILD_WITH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("roll_num") )
              lEesAdmListTabObj.roll_num  =  lResultSet.getString("ROLL_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("academic_session") )
              lEesAdmListTabObj.academic_session  =  lResultSet.getString("ACADEMIC_SESSION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_sts") )
              lEesAdmListTabObj.adm_req_sts  =  lResultSet.getString("ADM_REQ_STS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_sts_date") )
              {
              lEesAdmListTabObj.adm_req_sts_date  =  lResultSet.getString("ADM_REQ_STS_DATE");
  
          if ( lEesAdmListTabObj.adm_req_sts_date != null && lEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.adm_req_sts_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("student_id") )
              lEesAdmListTabObj.student_id  =  lResultSet.getString("STUDENT_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("scholor_num") )
              lEesAdmListTabObj.scholor_num  =  lResultSet.getString("SCHOLOR_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("form_recv_date") )
              {
              lEesAdmListTabObj.form_recv_date  =  lResultSet.getString("FORM_RECV_DATE");
  
          if ( lEesAdmListTabObj.form_recv_date != null && lEesAdmListTabObj.form_recv_date.length() > 0 ) 
            lEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.form_recv_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("form_recv_time") )
              lEesAdmListTabObj.form_recv_time  =  lResultSet.getString("FORM_RECV_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sale_date") )
              {
              lEesAdmListTabObj.prospectus_sale_date  =  lResultSet.getString("PROSPECTUS_SALE_DATE");
  
          if ( lEesAdmListTabObj.prospectus_sale_date != null && lEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.prospectus_sale_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sale_time") )
              lEesAdmListTabObj.prospectus_sale_time  =  lResultSet.getString("PROSPECTUS_SALE_TIME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prospectus_sold_by") )
              lEesAdmListTabObj.prospectus_sold_by  =  lResultSet.getString("PROSPECTUS_SOLD_BY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("application_form_fee") )
              lEesAdmListTabObj.application_form_fee  =  lResultSet.getDouble("APPLICATION_FORM_FEE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_academic_session") )
              lEesAdmListTabObj.adm_academic_session  =  lResultSet.getString("ADM_ACADEMIC_SESSION");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_date") )
              {
              lEesAdmListTabObj.entrance_exam_date  =  lResultSet.getString("ENTRANCE_EXAM_DATE");
  
          if ( lEesAdmListTabObj.entrance_exam_date != null && lEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.entrance_exam_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_time_start") )
              lEesAdmListTabObj.entrance_exam_time_start  =  lResultSet.getString("ENTRANCE_EXAM_TIME_START");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("entrance_exam_time_end") )
              lEesAdmListTabObj.entrance_exam_time_end  =  lResultSet.getString("ENTRANCE_EXAM_TIME_END");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("exam_present_status") )
              lEesAdmListTabObj.exam_present_status  =  lResultSet.getString("EXAM_PRESENT_STATUS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("building_id") )
              lEesAdmListTabObj.building_id  =  lResultSet.getString("BUILDING_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("floor_num") )
              lEesAdmListTabObj.floor_num  =  lResultSet.getString("FLOOR_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("room_num") )
              lEesAdmListTabObj.room_num  =  lResultSet.getString("ROOM_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("max_mark") )
              lEesAdmListTabObj.max_mark  =  lResultSet.getShort("MAX_MARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("obtained_mark") )
              lEesAdmListTabObj.obtained_mark  =  lResultSet.getShort("OBTAINED_MARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("grade") )
              lEesAdmListTabObj.grade  =  lResultSet.getString("GRADE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fee_sch_date") )
              {
              lEesAdmListTabObj.fee_sch_date  =  lResultSet.getString("FEE_SCH_DATE");
  
          if ( lEesAdmListTabObj.fee_sch_date != null && lEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_sch_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("fee_deposit_date") )
              {
              lEesAdmListTabObj.fee_deposit_date  =  lResultSet.getString("FEE_DEPOSIT_DATE");
  
          if ( lEesAdmListTabObj.fee_deposit_date != null && lEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.fee_deposit_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("online_flag") )
              lEesAdmListTabObj.online_flag  =  lResultSet.getString("ONLINE_FLAG");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("admission_mode") )
              lEesAdmListTabObj.admission_mode  =  lResultSet.getString("ADMISSION_MODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_1") )
              lEesAdmListTabObj.course_stream_1  =  lResultSet.getString("COURSE_STREAM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_2") )
              lEesAdmListTabObj.course_stream_2  =  lResultSet.getString("COURSE_STREAM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_3") )
              lEesAdmListTabObj.course_stream_3  =  lResultSet.getString("COURSE_STREAM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("course_stream_4") )
              lEesAdmListTabObj.course_stream_4  =  lResultSet.getString("COURSE_STREAM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("apr_course_stream") )
              lEesAdmListTabObj.apr_course_stream  =  lResultSet.getString("APR_COURSE_STREAM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_1") )
              lEesAdmListTabObj.unv_1  =  lResultSet.getString("UNV_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_rn_1") )
              lEesAdmListTabObj.unv_rn_1  =  lResultSet.getString("UNV_RN_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gen_rank_1") )
              lEesAdmListTabObj.gen_rank_1  =  lResultSet.getString("GEN_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ctg_rank_1") )
              lEesAdmListTabObj.ctg_rank_1  =  lResultSet.getString("CTG_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stt_rank_1") )
              lEesAdmListTabObj.stt_rank_1  =  lResultSet.getString("STT_RANK_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("yoa_1") )
              lEesAdmListTabObj.yoa_1  =  lResultSet.getString("YOA_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_2") )
              lEesAdmListTabObj.unv_2  =  lResultSet.getString("UNV_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("unv_rn_2") )
              lEesAdmListTabObj.unv_rn_2  =  lResultSet.getString("UNV_RN_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("gen_rank_2") )
              lEesAdmListTabObj.gen_rank_2  =  lResultSet.getString("GEN_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("ctg_rank_2") )
              lEesAdmListTabObj.ctg_rank_2  =  lResultSet.getString("CTG_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("stt_rank_2") )
              lEesAdmListTabObj.stt_rank_2  =  lResultSet.getString("STT_RANK_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("yoa_2") )
              lEesAdmListTabObj.yoa_2  =  lResultSet.getString("YOA_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("prev_mark_percent") )
              lEesAdmListTabObj.prev_mark_percent  =  lResultSet.getFloat("PREV_MARK_PERCENT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("domecile_ind") )
              lEesAdmListTabObj.domecile_ind  =  lResultSet.getString("DOMECILE_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_transport_req_ind") )
              lEesAdmListTabObj.org_transport_req_ind  =  lResultSet.getString("ORG_TRANSPORT_REQ_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("org_hostel_req_ind") )
              lEesAdmListTabObj.org_hostel_req_ind  =  lResultSet.getString("ORG_HOSTEL_REQ_IND");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_num") )
              lEesAdmListTabObj.cheque_num  =  lResultSet.getString("CHEQUE_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_date") )
              {
              lEesAdmListTabObj.cheque_date  =  lResultSet.getString("CHEQUE_DATE");
  
          if ( lEesAdmListTabObj.cheque_date != null && lEesAdmListTabObj.cheque_date.length() > 0 ) 
            lEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeSrcFmt, lEesAdmListTabObj.cheque_date, lDateTimeTrgFmt);
              }
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bank_code") )
              lEesAdmListTabObj.bank_code  =  lResultSet.getString("BANK_CODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("bank_name") )
              lEesAdmListTabObj.bank_name  =  lResultSet.getString("BANK_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("cheque_amt") )
              lEesAdmListTabObj.cheque_amt  =  lResultSet.getDouble("CHEQUE_AMT");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_name") )
              lEesAdmListTabObj.lg_0_name  =  lResultSet.getString("LG_0_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_rel_type") )
              lEesAdmListTabObj.lg_0_rel_type  =  lResultSet.getString("LG_0_REL_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_address") )
              lEesAdmListTabObj.lg_0_address  =  lResultSet.getString("LG_0_ADDRESS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_0_phone") )
              lEesAdmListTabObj.lg_0_phone  =  lResultSet.getString("LG_0_PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_name") )
              lEesAdmListTabObj.lg_1_name  =  lResultSet.getString("LG_1_NAME");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_rel_type") )
              lEesAdmListTabObj.lg_1_rel_type  =  lResultSet.getString("LG_1_REL_TYPE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_address") )
              lEesAdmListTabObj.lg_1_address  =  lResultSet.getString("LG_1_ADDRESS");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("lg_1_phone") )
              lEesAdmListTabObj.lg_1_phone  =  lResultSet.getString("LG_1_PHONE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_1") )
              lEesAdmListTabObj.st_cap_attr_1  =  lResultSet.getString("ST_CAP_ATTR_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_2") )
              lEesAdmListTabObj.st_cap_attr_2  =  lResultSet.getString("ST_CAP_ATTR_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_3") )
              lEesAdmListTabObj.st_cap_attr_3  =  lResultSet.getString("ST_CAP_ATTR_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_4") )
              lEesAdmListTabObj.st_cap_attr_4  =  lResultSet.getString("ST_CAP_ATTR_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_5") )
              lEesAdmListTabObj.st_cap_attr_5  =  lResultSet.getString("ST_CAP_ATTR_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_6") )
              lEesAdmListTabObj.st_cap_attr_6  =  lResultSet.getString("ST_CAP_ATTR_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_7") )
              lEesAdmListTabObj.st_cap_attr_7  =  lResultSet.getString("ST_CAP_ATTR_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("st_cap_attr_8") )
              lEesAdmListTabObj.st_cap_attr_8  =  lResultSet.getString("ST_CAP_ATTR_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("allergy") )
              lEesAdmListTabObj.allergy  =  lResultSet.getString("ALLERGY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("physical_disability") )
              lEesAdmListTabObj.physical_disability  =  lResultSet.getString("PHYSICAL_DISABILITY");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem") )
              lEesAdmListTabObj.health_problem  =  lResultSet.getString("HEALTH_PROBLEM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_1") )
              lEesAdmListTabObj.health_problem_1  =  lResultSet.getString("HEALTH_PROBLEM_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_2") )
              lEesAdmListTabObj.health_problem_2  =  lResultSet.getString("HEALTH_PROBLEM_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_3") )
              lEesAdmListTabObj.health_problem_3  =  lResultSet.getString("HEALTH_PROBLEM_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_4") )
              lEesAdmListTabObj.health_problem_4  =  lResultSet.getString("HEALTH_PROBLEM_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_5") )
              lEesAdmListTabObj.health_problem_5  =  lResultSet.getString("HEALTH_PROBLEM_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_6") )
              lEesAdmListTabObj.health_problem_6  =  lResultSet.getString("HEALTH_PROBLEM_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_7") )
              lEesAdmListTabObj.health_problem_7  =  lResultSet.getString("HEALTH_PROBLEM_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_8") )
              lEesAdmListTabObj.health_problem_8  =  lResultSet.getString("HEALTH_PROBLEM_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_9") )
              lEesAdmListTabObj.health_problem_9  =  lResultSet.getString("HEALTH_PROBLEM_9");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_10") )
              lEesAdmListTabObj.health_problem_10  =  lResultSet.getString("HEALTH_PROBLEM_10");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_11") )
              lEesAdmListTabObj.health_problem_11  =  lResultSet.getString("HEALTH_PROBLEM_11");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("health_problem_12") )
              lEesAdmListTabObj.health_problem_12  =  lResultSet.getString("HEALTH_PROBLEM_12");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_1") )
              lEesAdmListTabObj.enclosure_1  =  lResultSet.getString("ENCLOSURE_1");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_2") )
              lEesAdmListTabObj.enclosure_2  =  lResultSet.getString("ENCLOSURE_2");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_3") )
              lEesAdmListTabObj.enclosure_3  =  lResultSet.getString("ENCLOSURE_3");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_4") )
              lEesAdmListTabObj.enclosure_4  =  lResultSet.getString("ENCLOSURE_4");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_5") )
              lEesAdmListTabObj.enclosure_5  =  lResultSet.getString("ENCLOSURE_5");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_6") )
              lEesAdmListTabObj.enclosure_6  =  lResultSet.getString("ENCLOSURE_6");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_7") )
              lEesAdmListTabObj.enclosure_7  =  lResultSet.getString("ENCLOSURE_7");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("enclosure_8") )
              lEesAdmListTabObj.enclosure_8  =  lResultSet.getString("ENCLOSURE_8");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("seat_num") )
              lEesAdmListTabObj.seat_num  =  lResultSet.getShort("SEAT_NUM");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("reason_for_join") )
              lEesAdmListTabObj.reason_for_join  =  lResultSet.getString("REASON_FOR_JOIN");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("remark") )
              lEesAdmListTabObj.remark  =  lResultSet.getString("REMARK");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("place_of_birth") )
              lEesAdmListTabObj.place_of_birth  =  lResultSet.getString("PLACE_OF_BIRTH");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adv_adm_fee") )
              lEesAdmListTabObj.adv_adm_fee  =  lResultSet.getDouble("ADV_ADM_FEE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("payment_mode") )
              lEesAdmListTabObj.payment_mode  =  lResultSet.getString("PAYMENT_MODE");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("target_ptl_user_id") )
              lEesAdmListTabObj.target_ptl_user_id  =  lResultSet.getString("TARGET_PTL_USER_ID");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_req") )
              lEesAdmListTabObj.adm_req_id_req  =  lResultSet.getString("ADM_REQ_ID_REQ");
            else
            if ( (lFieldNameArr[ lFieldCount ].trim()).equals("adm_req_id_list") )
              lEesAdmListTabObj.adm_req_id_list  =  lResultSet.getString("ADM_REQ_ID_LIST");

          }
          removeNullEesAdmListTabObj( lEesAdmListTabObj );

          outEesAdmListTabObjArr.add(  lEesAdmListTabObj );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmListTabObjArr != null && outEesAdmListTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtEesAdmListStrArrDist
               ( String inEesAdmListWhereText
               , String inDistEesAdmListField
               , ArrayList  outEesAdmListTabObjArr
               )
  {

    sop("gtEesAdmListStrArrDist - Started");
    gSSTErrorObj.sourceMethod = "gtEesAdmListStrArrDist";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";
  

       String lDistEesAdmListFieldQry = inDistEesAdmListField.replace("/"," AS ");  

       String lSqlStmt = " SELECT "+
                         lDistEesAdmListFieldQry+
                         " FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       }

       String lFieldNameArr[] = (inDistEesAdmListField.substring(inDistEesAdmListField.indexOf(" ")+1)).split(",");

       for ( int lFieldCount = 0; lFieldCount < lFieldNameArr.length; lFieldCount++ )
       {
         if ( ( lFieldNameArr[ lFieldCount ].trim()).indexOf('/') >= 0  )
           lFieldNameArr[ lFieldCount ] = (lFieldNameArr[ lFieldCount ].split("/"))[1];
       }

       String  lEesAdmListTabObjStr = "";
       while(lResultSet.next())
       {
          lEesAdmListTabObjStr = "";
          for ( int lFieldCount = 0; lFieldCount <= lFieldNameArr.length; lFieldCount++ )
          {
            lEesAdmListTabObjStr =   lEesAdmListTabObjStr  +  lResultSet.getString( lFieldNameArr[lFieldCount] );
          }
          outEesAdmListTabObjArr.add(  lEesAdmListTabObjStr );
       }

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
       if ( outEesAdmListTabObjArr != null && outEesAdmListTabObjArr.size() > 0 ) 
         ; 
       else 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int gtMaxFldValEesAdmList
               ( String inEesAdmListWhereText
               , String inFieldName
               )
  {
    sop("gtMaxFldValEesAdmList - Started");
    gSSTErrorObj.sourceMethod = "gtMaxFldValEesAdmList";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "SELECT MAX("+inFieldName+") AS max_val "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lResultSet = lSSTDBMethod.executeSSTQuery(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 

       NO_DATA_FOUND = lResultSet.next();
       if ( !NO_DATA_FOUND ) 
       { 
         lReturnValue = -999001403; 
         gSSTErrorObj.errorText   = "No Data Found"; 
         throw new Exception(); 
       } 

       if ( MAX_VALUE_DATATYPE_STR_FLAG )
       {
         max_value_str_fmt = lResultSet.getString("max_val");
       }
       else
         lReturnValue = lResultSet.getInt("max_val");

       lResultSet.close();
       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public void removeNullEesAdmListTabObj
               ( 
                 EesAdmListTabObj  outEesAdmListTabObj
               )
  {
  
    if ( outEesAdmListTabObj.org_id == null ) 
     outEesAdmListTabObj.org_id = ""; 
    if ( outEesAdmListTabObj.adm_req_id == null ) 
     outEesAdmListTabObj.adm_req_id = ""; 
    if ( outEesAdmListTabObj.application_form_num == null ) 
     outEesAdmListTabObj.application_form_num = ""; 
    if ( outEesAdmListTabObj.applicant_id == null ) 
     outEesAdmListTabObj.applicant_id = ""; 
    if ( outEesAdmListTabObj.student_photo_file == null ) 
     outEesAdmListTabObj.student_photo_file = ""; 
    if ( outEesAdmListTabObj.mother_photo_file == null ) 
     outEesAdmListTabObj.mother_photo_file = ""; 
    if ( outEesAdmListTabObj.father_photo_file == null ) 
     outEesAdmListTabObj.father_photo_file = ""; 
    if ( outEesAdmListTabObj.class_id == null ) 
     outEesAdmListTabObj.class_id = ""; 
    if ( outEesAdmListTabObj.class_num == null ) 
     outEesAdmListTabObj.class_num = ""; 
    if ( outEesAdmListTabObj.class_std == null ) 
     outEesAdmListTabObj.class_std = ""; 
    if ( outEesAdmListTabObj.class_section == null ) 
     outEesAdmListTabObj.class_section = ""; 
    if ( outEesAdmListTabObj.course_id == null ) 
     outEesAdmListTabObj.course_id = ""; 
    if ( outEesAdmListTabObj.course_term == null ) 
     outEesAdmListTabObj.course_term = ""; 
    if ( outEesAdmListTabObj.course_stream == null ) 
     outEesAdmListTabObj.course_stream = ""; 
    if ( outEesAdmListTabObj.name_initials == null ) 
     outEesAdmListTabObj.name_initials = ""; 
    if ( outEesAdmListTabObj.student_f_name == null ) 
     outEesAdmListTabObj.student_f_name = ""; 
    if ( outEesAdmListTabObj.student_m_name == null ) 
     outEesAdmListTabObj.student_m_name = ""; 
    if ( outEesAdmListTabObj.student_l_name == null ) 
     outEesAdmListTabObj.student_l_name = ""; 
    if ( outEesAdmListTabObj.dob == null ) 
     outEesAdmListTabObj.dob = ""; 
    if ( outEesAdmListTabObj.age_on_date == null ) 
     outEesAdmListTabObj.age_on_date = ""; 
    if ( outEesAdmListTabObj.age_year == (int)0 ) 
     outEesAdmListTabObj.age_year = (int)0; 
    if ( outEesAdmListTabObj.age_month == null ) 
     outEesAdmListTabObj.age_month = ""; 
    if ( outEesAdmListTabObj.age_day == (int)0 ) 
     outEesAdmListTabObj.age_day = (int)0; 
    if ( outEesAdmListTabObj.s_nationality == null ) 
     outEesAdmListTabObj.s_nationality = ""; 
    if ( outEesAdmListTabObj.religion == null ) 
     outEesAdmListTabObj.religion = ""; 
    if ( outEesAdmListTabObj.student_ctg == null ) 
     outEesAdmListTabObj.student_ctg = ""; 
    if ( outEesAdmListTabObj.gender_flag == null ) 
     outEesAdmListTabObj.gender_flag = ""; 
    if ( outEesAdmListTabObj.p_address_1 == null ) 
     outEesAdmListTabObj.p_address_1 = ""; 
    if ( outEesAdmListTabObj.p_address_2 == null ) 
     outEesAdmListTabObj.p_address_2 = ""; 
    if ( outEesAdmListTabObj.p_country == null ) 
     outEesAdmListTabObj.p_country = ""; 
    if ( outEesAdmListTabObj.p_state == null ) 
     outEesAdmListTabObj.p_state = ""; 
    if ( outEesAdmListTabObj.p_city == null ) 
     outEesAdmListTabObj.p_city = ""; 
    if ( outEesAdmListTabObj.p_district == null ) 
     outEesAdmListTabObj.p_district = ""; 
    if ( outEesAdmListTabObj.p_zip == null ) 
     outEesAdmListTabObj.p_zip = ""; 
    if ( outEesAdmListTabObj.m_address_1 == null ) 
     outEesAdmListTabObj.m_address_1 = ""; 
    if ( outEesAdmListTabObj.m_address_2 == null ) 
     outEesAdmListTabObj.m_address_2 = ""; 
    if ( outEesAdmListTabObj.m_country == null ) 
     outEesAdmListTabObj.m_country = ""; 
    if ( outEesAdmListTabObj.m_state == null ) 
     outEesAdmListTabObj.m_state = ""; 
    if ( outEesAdmListTabObj.m_city == null ) 
     outEesAdmListTabObj.m_city = ""; 
    if ( outEesAdmListTabObj.m_district == null ) 
     outEesAdmListTabObj.m_district = ""; 
    if ( outEesAdmListTabObj.m_zip == null ) 
     outEesAdmListTabObj.m_zip = ""; 
    if ( outEesAdmListTabObj.phone_list == null ) 
     outEesAdmListTabObj.phone_list = ""; 
    if ( outEesAdmListTabObj.email_list == null ) 
     outEesAdmListTabObj.email_list = ""; 
    if ( outEesAdmListTabObj.fax_list == null ) 
     outEesAdmListTabObj.fax_list = ""; 
    if ( outEesAdmListTabObj.prev_org_name == null ) 
     outEesAdmListTabObj.prev_org_name = ""; 
    if ( outEesAdmListTabObj.prev_class_id == null ) 
     outEesAdmListTabObj.prev_class_id = ""; 
    if ( outEesAdmListTabObj.prev_class_num == null ) 
     outEesAdmListTabObj.prev_class_num = ""; 
    if ( outEesAdmListTabObj.prev_class_std == null ) 
     outEesAdmListTabObj.prev_class_std = ""; 
    if ( outEesAdmListTabObj.prev_class_section == null ) 
     outEesAdmListTabObj.prev_class_section = ""; 
    if ( outEesAdmListTabObj.prev_course_id == null ) 
     outEesAdmListTabObj.prev_course_id = ""; 
    if ( outEesAdmListTabObj.prev_course_term == null ) 
     outEesAdmListTabObj.prev_course_term = ""; 
    if ( outEesAdmListTabObj.prev_course_stream == null ) 
     outEesAdmListTabObj.prev_course_stream = ""; 
    if ( outEesAdmListTabObj.reason_for_leaving == null ) 
     outEesAdmListTabObj.reason_for_leaving = ""; 
    if ( outEesAdmListTabObj.father_name == null ) 
     outEesAdmListTabObj.father_name = ""; 
    if ( outEesAdmListTabObj.father_age == (int)0 ) 
     outEesAdmListTabObj.father_age = (int)0; 
    if ( outEesAdmListTabObj.f_nationality == null ) 
     outEesAdmListTabObj.f_nationality = ""; 
    if ( outEesAdmListTabObj.father_occ_type == null ) 
     outEesAdmListTabObj.father_occ_type = ""; 
    if ( outEesAdmListTabObj.father_employer == null ) 
     outEesAdmListTabObj.father_employer = ""; 
    if ( outEesAdmListTabObj.father_designation == null ) 
     outEesAdmListTabObj.father_designation = ""; 
    if ( outEesAdmListTabObj.father_annual_income == (double)0.00 ) 
     outEesAdmListTabObj.father_annual_income = (double)0.00; 
    if ( outEesAdmListTabObj.f_off_address_1 == null ) 
     outEesAdmListTabObj.f_off_address_1 = ""; 
    if ( outEesAdmListTabObj.f_phone_list == null ) 
     outEesAdmListTabObj.f_phone_list = ""; 
    if ( outEesAdmListTabObj.mother_name == null ) 
     outEesAdmListTabObj.mother_name = ""; 
    if ( outEesAdmListTabObj.mother_age == (int)0 ) 
     outEesAdmListTabObj.mother_age = (int)0; 
    if ( outEesAdmListTabObj.m_nationality == null ) 
     outEesAdmListTabObj.m_nationality = ""; 
    if ( outEesAdmListTabObj.mother_occ_type == null ) 
     outEesAdmListTabObj.mother_occ_type = ""; 
    if ( outEesAdmListTabObj.mother_employer == null ) 
     outEesAdmListTabObj.mother_employer = ""; 
    if ( outEesAdmListTabObj.mother_designation == null ) 
     outEesAdmListTabObj.mother_designation = ""; 
    if ( outEesAdmListTabObj.mother_annual_income == (double)0.00 ) 
     outEesAdmListTabObj.mother_annual_income = (double)0.00; 
    if ( outEesAdmListTabObj.m_off_address_1 == null ) 
     outEesAdmListTabObj.m_off_address_1 = ""; 
    if ( outEesAdmListTabObj.m_phone_list == null ) 
     outEesAdmListTabObj.m_phone_list = ""; 
    if ( outEesAdmListTabObj.divorced_flag == null ) 
     outEesAdmListTabObj.divorced_flag = ""; 
    if ( outEesAdmListTabObj.child_with == null ) 
     outEesAdmListTabObj.child_with = ""; 
    if ( outEesAdmListTabObj.roll_num == null ) 
     outEesAdmListTabObj.roll_num = ""; 
    if ( outEesAdmListTabObj.academic_session == null ) 
     outEesAdmListTabObj.academic_session = ""; 
    if ( outEesAdmListTabObj.adm_req_sts == null ) 
     outEesAdmListTabObj.adm_req_sts = ""; 
    if ( outEesAdmListTabObj.adm_req_sts_date == null ) 
     outEesAdmListTabObj.adm_req_sts_date = ""; 
    if ( outEesAdmListTabObj.student_id == null ) 
     outEesAdmListTabObj.student_id = ""; 
    if ( outEesAdmListTabObj.scholor_num == null ) 
     outEesAdmListTabObj.scholor_num = ""; 
    if ( outEesAdmListTabObj.form_recv_date == null ) 
     outEesAdmListTabObj.form_recv_date = ""; 
    if ( outEesAdmListTabObj.form_recv_time == null ) 
     outEesAdmListTabObj.form_recv_time = ""; 
    if ( outEesAdmListTabObj.prospectus_sale_date == null ) 
     outEesAdmListTabObj.prospectus_sale_date = ""; 
    if ( outEesAdmListTabObj.prospectus_sale_time == null ) 
     outEesAdmListTabObj.prospectus_sale_time = ""; 
    if ( outEesAdmListTabObj.prospectus_sold_by == null ) 
     outEesAdmListTabObj.prospectus_sold_by = ""; 
    if ( outEesAdmListTabObj.application_form_fee == (double)0.00 ) 
     outEesAdmListTabObj.application_form_fee = (double)0.00; 
    if ( outEesAdmListTabObj.adm_academic_session == null ) 
     outEesAdmListTabObj.adm_academic_session = ""; 
    if ( outEesAdmListTabObj.entrance_exam_date == null ) 
     outEesAdmListTabObj.entrance_exam_date = ""; 
    if ( outEesAdmListTabObj.entrance_exam_time_start == null ) 
     outEesAdmListTabObj.entrance_exam_time_start = ""; 
    if ( outEesAdmListTabObj.entrance_exam_time_end == null ) 
     outEesAdmListTabObj.entrance_exam_time_end = ""; 
    if ( outEesAdmListTabObj.exam_present_status == null ) 
     outEesAdmListTabObj.exam_present_status = ""; 
    if ( outEesAdmListTabObj.building_id == null ) 
     outEesAdmListTabObj.building_id = ""; 
    if ( outEesAdmListTabObj.floor_num == null ) 
     outEesAdmListTabObj.floor_num = ""; 
    if ( outEesAdmListTabObj.room_num == null ) 
     outEesAdmListTabObj.room_num = ""; 
    if ( outEesAdmListTabObj.max_mark == (int)0 ) 
     outEesAdmListTabObj.max_mark = (int)0; 
    if ( outEesAdmListTabObj.obtained_mark == (int)0 ) 
     outEesAdmListTabObj.obtained_mark = (int)0; 
    if ( outEesAdmListTabObj.grade == null ) 
     outEesAdmListTabObj.grade = ""; 
    if ( outEesAdmListTabObj.fee_sch_date == null ) 
     outEesAdmListTabObj.fee_sch_date = ""; 
    if ( outEesAdmListTabObj.fee_deposit_date == null ) 
     outEesAdmListTabObj.fee_deposit_date = ""; 
    if ( outEesAdmListTabObj.online_flag == null ) 
     outEesAdmListTabObj.online_flag = ""; 
    if ( outEesAdmListTabObj.admission_mode == null ) 
     outEesAdmListTabObj.admission_mode = ""; 
    if ( outEesAdmListTabObj.course_stream_1 == null ) 
     outEesAdmListTabObj.course_stream_1 = ""; 
    if ( outEesAdmListTabObj.course_stream_2 == null ) 
     outEesAdmListTabObj.course_stream_2 = ""; 
    if ( outEesAdmListTabObj.course_stream_3 == null ) 
     outEesAdmListTabObj.course_stream_3 = ""; 
    if ( outEesAdmListTabObj.course_stream_4 == null ) 
     outEesAdmListTabObj.course_stream_4 = ""; 
    if ( outEesAdmListTabObj.apr_course_stream == null ) 
     outEesAdmListTabObj.apr_course_stream = ""; 
    if ( outEesAdmListTabObj.unv_1 == null ) 
     outEesAdmListTabObj.unv_1 = ""; 
    if ( outEesAdmListTabObj.unv_rn_1 == null ) 
     outEesAdmListTabObj.unv_rn_1 = ""; 
    if ( outEesAdmListTabObj.gen_rank_1 == null ) 
     outEesAdmListTabObj.gen_rank_1 = ""; 
    if ( outEesAdmListTabObj.ctg_rank_1 == null ) 
     outEesAdmListTabObj.ctg_rank_1 = ""; 
    if ( outEesAdmListTabObj.stt_rank_1 == null ) 
     outEesAdmListTabObj.stt_rank_1 = ""; 
    if ( outEesAdmListTabObj.yoa_1 == null ) 
     outEesAdmListTabObj.yoa_1 = ""; 
    if ( outEesAdmListTabObj.unv_2 == null ) 
     outEesAdmListTabObj.unv_2 = ""; 
    if ( outEesAdmListTabObj.unv_rn_2 == null ) 
     outEesAdmListTabObj.unv_rn_2 = ""; 
    if ( outEesAdmListTabObj.gen_rank_2 == null ) 
     outEesAdmListTabObj.gen_rank_2 = ""; 
    if ( outEesAdmListTabObj.ctg_rank_2 == null ) 
     outEesAdmListTabObj.ctg_rank_2 = ""; 
    if ( outEesAdmListTabObj.stt_rank_2 == null ) 
     outEesAdmListTabObj.stt_rank_2 = ""; 
    if ( outEesAdmListTabObj.yoa_2 == null ) 
     outEesAdmListTabObj.yoa_2 = ""; 
    if ( outEesAdmListTabObj.prev_mark_percent == (float)0.00 ) 
     outEesAdmListTabObj.prev_mark_percent = (float)0.00; 
    if ( outEesAdmListTabObj.domecile_ind == null ) 
     outEesAdmListTabObj.domecile_ind = ""; 
    if ( outEesAdmListTabObj.org_transport_req_ind == null ) 
     outEesAdmListTabObj.org_transport_req_ind = ""; 
    if ( outEesAdmListTabObj.org_hostel_req_ind == null ) 
     outEesAdmListTabObj.org_hostel_req_ind = ""; 
    if ( outEesAdmListTabObj.cheque_num == null ) 
     outEesAdmListTabObj.cheque_num = ""; 
    if ( outEesAdmListTabObj.cheque_date == null ) 
     outEesAdmListTabObj.cheque_date = ""; 
    if ( outEesAdmListTabObj.bank_code == null ) 
     outEesAdmListTabObj.bank_code = ""; 
    if ( outEesAdmListTabObj.bank_name == null ) 
     outEesAdmListTabObj.bank_name = ""; 
    if ( outEesAdmListTabObj.cheque_amt == (double)0.00 ) 
     outEesAdmListTabObj.cheque_amt = (double)0.00; 
    if ( outEesAdmListTabObj.lg_0_name == null ) 
     outEesAdmListTabObj.lg_0_name = ""; 
    if ( outEesAdmListTabObj.lg_0_rel_type == null ) 
     outEesAdmListTabObj.lg_0_rel_type = ""; 
    if ( outEesAdmListTabObj.lg_0_address == null ) 
     outEesAdmListTabObj.lg_0_address = ""; 
    if ( outEesAdmListTabObj.lg_0_phone == null ) 
     outEesAdmListTabObj.lg_0_phone = ""; 
    if ( outEesAdmListTabObj.lg_1_name == null ) 
     outEesAdmListTabObj.lg_1_name = ""; 
    if ( outEesAdmListTabObj.lg_1_rel_type == null ) 
     outEesAdmListTabObj.lg_1_rel_type = ""; 
    if ( outEesAdmListTabObj.lg_1_address == null ) 
     outEesAdmListTabObj.lg_1_address = ""; 
    if ( outEesAdmListTabObj.lg_1_phone == null ) 
     outEesAdmListTabObj.lg_1_phone = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_1 == null ) 
     outEesAdmListTabObj.st_cap_attr_1 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_2 == null ) 
     outEesAdmListTabObj.st_cap_attr_2 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_3 == null ) 
     outEesAdmListTabObj.st_cap_attr_3 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_4 == null ) 
     outEesAdmListTabObj.st_cap_attr_4 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_5 == null ) 
     outEesAdmListTabObj.st_cap_attr_5 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_6 == null ) 
     outEesAdmListTabObj.st_cap_attr_6 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_7 == null ) 
     outEesAdmListTabObj.st_cap_attr_7 = ""; 
    if ( outEesAdmListTabObj.st_cap_attr_8 == null ) 
     outEesAdmListTabObj.st_cap_attr_8 = ""; 
    if ( outEesAdmListTabObj.allergy == null ) 
     outEesAdmListTabObj.allergy = ""; 
    if ( outEesAdmListTabObj.physical_disability == null ) 
     outEesAdmListTabObj.physical_disability = ""; 
    if ( outEesAdmListTabObj.health_problem == null ) 
     outEesAdmListTabObj.health_problem = ""; 
    if ( outEesAdmListTabObj.health_problem_1 == null ) 
     outEesAdmListTabObj.health_problem_1 = ""; 
    if ( outEesAdmListTabObj.health_problem_2 == null ) 
     outEesAdmListTabObj.health_problem_2 = ""; 
    if ( outEesAdmListTabObj.health_problem_3 == null ) 
     outEesAdmListTabObj.health_problem_3 = ""; 
    if ( outEesAdmListTabObj.health_problem_4 == null ) 
     outEesAdmListTabObj.health_problem_4 = ""; 
    if ( outEesAdmListTabObj.health_problem_5 == null ) 
     outEesAdmListTabObj.health_problem_5 = ""; 
    if ( outEesAdmListTabObj.health_problem_6 == null ) 
     outEesAdmListTabObj.health_problem_6 = ""; 
    if ( outEesAdmListTabObj.health_problem_7 == null ) 
     outEesAdmListTabObj.health_problem_7 = ""; 
    if ( outEesAdmListTabObj.health_problem_8 == null ) 
     outEesAdmListTabObj.health_problem_8 = ""; 
    if ( outEesAdmListTabObj.health_problem_9 == null ) 
     outEesAdmListTabObj.health_problem_9 = ""; 
    if ( outEesAdmListTabObj.health_problem_10 == null ) 
     outEesAdmListTabObj.health_problem_10 = ""; 
    if ( outEesAdmListTabObj.health_problem_11 == null ) 
     outEesAdmListTabObj.health_problem_11 = ""; 
    if ( outEesAdmListTabObj.health_problem_12 == null ) 
     outEesAdmListTabObj.health_problem_12 = ""; 
    if ( outEesAdmListTabObj.enclosure_1 == null ) 
     outEesAdmListTabObj.enclosure_1 = ""; 
    if ( outEesAdmListTabObj.enclosure_2 == null ) 
     outEesAdmListTabObj.enclosure_2 = ""; 
    if ( outEesAdmListTabObj.enclosure_3 == null ) 
     outEesAdmListTabObj.enclosure_3 = ""; 
    if ( outEesAdmListTabObj.enclosure_4 == null ) 
     outEesAdmListTabObj.enclosure_4 = ""; 
    if ( outEesAdmListTabObj.enclosure_5 == null ) 
     outEesAdmListTabObj.enclosure_5 = ""; 
    if ( outEesAdmListTabObj.enclosure_6 == null ) 
     outEesAdmListTabObj.enclosure_6 = ""; 
    if ( outEesAdmListTabObj.enclosure_7 == null ) 
     outEesAdmListTabObj.enclosure_7 = ""; 
    if ( outEesAdmListTabObj.enclosure_8 == null ) 
     outEesAdmListTabObj.enclosure_8 = ""; 
    if ( outEesAdmListTabObj.seat_num == (int)0 ) 
     outEesAdmListTabObj.seat_num = (int)0; 
    if ( outEesAdmListTabObj.reason_for_join == null ) 
     outEesAdmListTabObj.reason_for_join = ""; 
    if ( outEesAdmListTabObj.remark == null ) 
     outEesAdmListTabObj.remark = ""; 
    if ( outEesAdmListTabObj.place_of_birth == null ) 
     outEesAdmListTabObj.place_of_birth = ""; 
    if ( outEesAdmListTabObj.adv_adm_fee == (double)0.00 ) 
     outEesAdmListTabObj.adv_adm_fee = (double)0.00; 
    if ( outEesAdmListTabObj.payment_mode == null ) 
     outEesAdmListTabObj.payment_mode = ""; 
    if ( outEesAdmListTabObj.target_ptl_user_id == null ) 
     outEesAdmListTabObj.target_ptl_user_id = ""; 
    if ( outEesAdmListTabObj.adm_req_id_req == null ) 
     outEesAdmListTabObj.adm_req_id_req = ""; 
    if ( outEesAdmListTabObj.adm_req_id_list == null ) 
     outEesAdmListTabObj.adm_req_id_list = ""; 
  }





  public int insEesAdmListRec
               ( EesAdmListTabObj  inEesAdmListTabObj )
  {
    int lUpdateCount;
    sop("insEesAdmListRec - Started");
    gSSTErrorObj.sourceMethod = "insEesAdmListRec";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmListTabObj.dob != null && inEesAdmListTabObj.dob.length() > 0 ) 
            inEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.age_on_date != null && inEesAdmListTabObj.age_on_date.length() > 0 ) 
            inEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.adm_req_sts_date != null && inEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.form_recv_date != null && inEesAdmListTabObj.form_recv_date.length() > 0 ) 
            inEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.prospectus_sale_date != null && inEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.entrance_exam_date != null && inEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_sch_date != null && inEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_deposit_date != null && inEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.cheque_date != null && inEesAdmListTabObj.cheque_date.length() > 0 ) 
            inEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.cheque_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ADM_LIST"+
                        "("+
                                "org_id,"+
                                "adm_req_id,"+
                                "application_form_num,"+
                                "applicant_id,"+
                                "student_photo_file,"+
                                "mother_photo_file,"+
                                "father_photo_file,"+
                                "class_id,"+
                                "class_num,"+
                                "class_std,"+
                                "class_section,"+
                                "course_id,"+
                                "course_term,"+
                                "course_stream,"+
                                "name_initials,"+
                                "student_f_name,"+
                                "student_m_name,"+
                                "student_l_name,"+
                                "dob,"+
                                "age_on_date,"+
                                "age_year,"+
                                "age_month,"+
                                "age_day,"+
                                "s_nationality,"+
                                "religion,"+
                                "student_ctg,"+
                                "gender_flag,"+
                                "p_address_1,"+
                                "p_address_2,"+
                                "p_country,"+
                                "p_state,"+
                                "p_city,"+
                                "p_district,"+
                                "p_zip,"+
                                "m_address_1,"+
                                "m_address_2,"+
                                "m_country,"+
                                "m_state,"+
                                "m_city,"+
                                "m_district,"+
                                "m_zip,"+
                                "phone_list,"+
                                "email_list,"+
                                "fax_list,"+
                                "prev_org_name,"+
                                "prev_class_id,"+
                                "prev_class_num,"+
                                "prev_class_std,"+
                                "prev_class_section,"+
                                "prev_course_id,"+
                                "prev_course_term,"+
                                "prev_course_stream,"+
                                "reason_for_leaving,"+
                                "father_name,"+
                                "father_age,"+
                                "f_nationality,"+
                                "father_occ_type,"+
                                "father_employer,"+
                                "father_designation,"+
                                "father_annual_income,"+
                                "f_off_address_1,"+
                                "f_phone_list,"+
                                "mother_name,"+
                                "mother_age,"+
                                "m_nationality,"+
                                "mother_occ_type,"+
                                "mother_employer,"+
                                "mother_designation,"+
                                "mother_annual_income,"+
                                "m_off_address_1,"+
                                "m_phone_list,"+
                                "divorced_flag,"+
                                "child_with,"+
                                "roll_num,"+
                                "academic_session,"+
                                "adm_req_sts,"+
                                "adm_req_sts_date,"+
                                "student_id,"+
                                "scholor_num,"+
                                "form_recv_date,"+
                                "form_recv_time,"+
                                "prospectus_sale_date,"+
                                "prospectus_sale_time,"+
                                "prospectus_sold_by,"+
                                "application_form_fee,"+
                                "adm_academic_session,"+
                                "entrance_exam_date,"+
                                "entrance_exam_time_start,"+
                                "entrance_exam_time_end,"+
                                "exam_present_status,"+
                                "building_id,"+
                                "floor_num,"+
                                "room_num,"+
                                "max_mark,"+
                                "obtained_mark,"+
                                "grade,"+
                                "fee_sch_date,"+
                                "fee_deposit_date,"+
                                "online_flag,"+
                                "admission_mode,"+
                                "course_stream_1,"+
                                "course_stream_2,"+
                                "course_stream_3,"+
                                "course_stream_4,"+
                                "apr_course_stream,"+
                                "unv_1,"+
                                "unv_rn_1,"+
                                "gen_rank_1,"+
                                "ctg_rank_1,"+
                                "stt_rank_1,"+
                                "yoa_1,"+
                                "unv_2,"+
                                "unv_rn_2,"+
                                "gen_rank_2,"+
                                "ctg_rank_2,"+
                                "stt_rank_2,"+
                                "yoa_2,"+
                                "prev_mark_percent,"+
                                "domecile_ind,"+
                                "org_transport_req_ind,"+
                                "org_hostel_req_ind,"+
                                "cheque_num,"+
                                "cheque_date,"+
                                "bank_code,"+
                                "bank_name,"+
                                "cheque_amt,"+
                                "lg_0_name,"+
                                "lg_0_rel_type,"+
                                "lg_0_address,"+
                                "lg_0_phone,"+
                                "lg_1_name,"+
                                "lg_1_rel_type,"+
                                "lg_1_address,"+
                                "lg_1_phone,"+
                                "st_cap_attr_1,"+
                                "st_cap_attr_2,"+
                                "st_cap_attr_3,"+
                                "st_cap_attr_4,"+
                                "st_cap_attr_5,"+
                                "st_cap_attr_6,"+
                                "st_cap_attr_7,"+
                                "st_cap_attr_8,"+
                                "allergy,"+
                                "physical_disability,"+
                                "health_problem,"+
                                "health_problem_1,"+
                                "health_problem_2,"+
                                "health_problem_3,"+
                                "health_problem_4,"+
                                "health_problem_5,"+
                                "health_problem_6,"+
                                "health_problem_7,"+
                                "health_problem_8,"+
                                "health_problem_9,"+
                                "health_problem_10,"+
                                "health_problem_11,"+
                                "health_problem_12,"+
                                "enclosure_1,"+
                                "enclosure_2,"+
                                "enclosure_3,"+
                                "enclosure_4,"+
                                "enclosure_5,"+
                                "enclosure_6,"+
                                "enclosure_7,"+
                                "enclosure_8,"+
                                "seat_num,"+
                                "reason_for_join,"+
                                "remark,"+
                                "place_of_birth,"+
                                "adv_adm_fee,"+
                                "payment_mode,"+
                                "target_ptl_user_id,"+
                                "adm_req_id_req,"+
                                "adm_req_id_list"+
                        ")"+
                        "VALUES "+
                        "(";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.org_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_req_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.application_form_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.applicant_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.mother_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.father_photo_file+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.name_initials+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_f_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_m_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_l_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.dob+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.age_on_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.age_year+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.age_month+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.age_day+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.s_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.religion+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_ctg+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.gender_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_district+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.p_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_address_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_country+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_state+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_city+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_district+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_zip+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.email_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.fax_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_org_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_class_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_class_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_class_std+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_class_section+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_course_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_course_term+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prev_course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.reason_for_leaving+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.father_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.father_age+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.f_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.father_occ_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.father_employer+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.father_designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.father_annual_income+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.f_off_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.f_phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.mother_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.mother_age+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_nationality+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.mother_occ_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.mother_employer+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.mother_designation+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.mother_annual_income+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_off_address_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.m_phone_list+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.divorced_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.child_with+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.roll_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.academic_session+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_req_sts+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_req_sts_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.student_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.scholor_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.form_recv_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.form_recv_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prospectus_sale_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prospectus_sale_time+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.prospectus_sold_by+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.application_form_fee+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_academic_session+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.entrance_exam_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.entrance_exam_time_start+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.entrance_exam_time_end+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.exam_present_status+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.building_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.floor_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.room_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.max_mark+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.obtained_mark+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.grade+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.fee_sch_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.fee_deposit_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.online_flag+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.admission_mode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_stream_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_stream_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_stream_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.course_stream_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.apr_course_stream+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.unv_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.unv_rn_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.gen_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.ctg_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.stt_rank_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.yoa_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.unv_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.unv_rn_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.gen_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.ctg_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.stt_rank_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.yoa_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.prev_mark_percent+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.domecile_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.org_transport_req_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.org_hostel_req_ind+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.cheque_num+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.cheque_date+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.bank_code+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.bank_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.cheque_amt+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_0_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_0_rel_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_0_address+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_0_phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_1_name+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_1_rel_type+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_1_address+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.lg_1_phone+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.st_cap_attr_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.allergy+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.physical_disability+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_9+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_10+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_11+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.health_problem_12+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_1+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_2+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_3+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_4+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_5+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_6+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_7+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.enclosure_8+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.seat_num+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.reason_for_join+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.remark+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.place_of_birth+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += inEesAdmListTabObj.adv_adm_fee+",";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.payment_mode+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.target_ptl_user_id+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_req_id_req+"',";
                            if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+inEesAdmListTabObj.adm_req_id_list+"'";
      lSqlStmt +=       ")";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
        lPreparedStatement.setString(1, inEesAdmListTabObj.org_id);
        lPreparedStatement.setString(2, inEesAdmListTabObj.adm_req_id);
        lPreparedStatement.setString(3, inEesAdmListTabObj.application_form_num);
        lPreparedStatement.setString(4, inEesAdmListTabObj.applicant_id);
        lPreparedStatement.setString(5, inEesAdmListTabObj.student_photo_file);
        lPreparedStatement.setString(6, inEesAdmListTabObj.mother_photo_file);
        lPreparedStatement.setString(7, inEesAdmListTabObj.father_photo_file);
        lPreparedStatement.setString(8, inEesAdmListTabObj.class_id);
        lPreparedStatement.setString(9, inEesAdmListTabObj.class_num);
        lPreparedStatement.setString(10, inEesAdmListTabObj.class_std);
        lPreparedStatement.setString(11, inEesAdmListTabObj.class_section);
        lPreparedStatement.setString(12, inEesAdmListTabObj.course_id);
        lPreparedStatement.setString(13, inEesAdmListTabObj.course_term);
        lPreparedStatement.setString(14, inEesAdmListTabObj.course_stream);
        lPreparedStatement.setString(15, inEesAdmListTabObj.name_initials);
        lPreparedStatement.setString(16, inEesAdmListTabObj.student_f_name);
        lPreparedStatement.setString(17, inEesAdmListTabObj.student_m_name);
        lPreparedStatement.setString(18, inEesAdmListTabObj.student_l_name);
        lPreparedStatement.setString(19, inEesAdmListTabObj.dob);
        lPreparedStatement.setString(20, inEesAdmListTabObj.age_on_date);
          lPreparedStatement.setByte(21, inEesAdmListTabObj.age_year);
        lPreparedStatement.setString(22, inEesAdmListTabObj.age_month);
          lPreparedStatement.setByte(23, inEesAdmListTabObj.age_day);
        lPreparedStatement.setString(24, inEesAdmListTabObj.s_nationality);
        lPreparedStatement.setString(25, inEesAdmListTabObj.religion);
        lPreparedStatement.setString(26, inEesAdmListTabObj.student_ctg);
        lPreparedStatement.setString(27, inEesAdmListTabObj.gender_flag);
        lPreparedStatement.setString(28, inEesAdmListTabObj.p_address_1);
        lPreparedStatement.setString(29, inEesAdmListTabObj.p_address_2);
        lPreparedStatement.setString(30, inEesAdmListTabObj.p_country);
        lPreparedStatement.setString(31, inEesAdmListTabObj.p_state);
        lPreparedStatement.setString(32, inEesAdmListTabObj.p_city);
        lPreparedStatement.setString(33, inEesAdmListTabObj.p_district);
        lPreparedStatement.setString(34, inEesAdmListTabObj.p_zip);
        lPreparedStatement.setString(35, inEesAdmListTabObj.m_address_1);
        lPreparedStatement.setString(36, inEesAdmListTabObj.m_address_2);
        lPreparedStatement.setString(37, inEesAdmListTabObj.m_country);
        lPreparedStatement.setString(38, inEesAdmListTabObj.m_state);
        lPreparedStatement.setString(39, inEesAdmListTabObj.m_city);
        lPreparedStatement.setString(40, inEesAdmListTabObj.m_district);
        lPreparedStatement.setString(41, inEesAdmListTabObj.m_zip);
        lPreparedStatement.setString(42, inEesAdmListTabObj.phone_list);
        lPreparedStatement.setString(43, inEesAdmListTabObj.email_list);
        lPreparedStatement.setString(44, inEesAdmListTabObj.fax_list);
        lPreparedStatement.setString(45, inEesAdmListTabObj.prev_org_name);
        lPreparedStatement.setString(46, inEesAdmListTabObj.prev_class_id);
        lPreparedStatement.setString(47, inEesAdmListTabObj.prev_class_num);
        lPreparedStatement.setString(48, inEesAdmListTabObj.prev_class_std);
        lPreparedStatement.setString(49, inEesAdmListTabObj.prev_class_section);
        lPreparedStatement.setString(50, inEesAdmListTabObj.prev_course_id);
        lPreparedStatement.setString(51, inEesAdmListTabObj.prev_course_term);
        lPreparedStatement.setString(52, inEesAdmListTabObj.prev_course_stream);
        lPreparedStatement.setString(53, inEesAdmListTabObj.reason_for_leaving);
        lPreparedStatement.setString(54, inEesAdmListTabObj.father_name);
          lPreparedStatement.setByte(55, inEesAdmListTabObj.father_age);
        lPreparedStatement.setString(56, inEesAdmListTabObj.f_nationality);
        lPreparedStatement.setString(57, inEesAdmListTabObj.father_occ_type);
        lPreparedStatement.setString(58, inEesAdmListTabObj.father_employer);
        lPreparedStatement.setString(59, inEesAdmListTabObj.father_designation);
          lPreparedStatement.setDouble(60, inEesAdmListTabObj.father_annual_income);
        lPreparedStatement.setString(61, inEesAdmListTabObj.f_off_address_1);
        lPreparedStatement.setString(62, inEesAdmListTabObj.f_phone_list);
        lPreparedStatement.setString(63, inEesAdmListTabObj.mother_name);
          lPreparedStatement.setByte(64, inEesAdmListTabObj.mother_age);
        lPreparedStatement.setString(65, inEesAdmListTabObj.m_nationality);
        lPreparedStatement.setString(66, inEesAdmListTabObj.mother_occ_type);
        lPreparedStatement.setString(67, inEesAdmListTabObj.mother_employer);
        lPreparedStatement.setString(68, inEesAdmListTabObj.mother_designation);
          lPreparedStatement.setDouble(69, inEesAdmListTabObj.mother_annual_income);
        lPreparedStatement.setString(70, inEesAdmListTabObj.m_off_address_1);
        lPreparedStatement.setString(71, inEesAdmListTabObj.m_phone_list);
        lPreparedStatement.setString(72, inEesAdmListTabObj.divorced_flag);
        lPreparedStatement.setString(73, inEesAdmListTabObj.child_with);
        lPreparedStatement.setString(74, inEesAdmListTabObj.roll_num);
        lPreparedStatement.setString(75, inEesAdmListTabObj.academic_session);
        lPreparedStatement.setString(76, inEesAdmListTabObj.adm_req_sts);
        lPreparedStatement.setString(77, inEesAdmListTabObj.adm_req_sts_date);
        lPreparedStatement.setString(78, inEesAdmListTabObj.student_id);
        lPreparedStatement.setString(79, inEesAdmListTabObj.scholor_num);
        lPreparedStatement.setString(80, inEesAdmListTabObj.form_recv_date);
        lPreparedStatement.setString(81, inEesAdmListTabObj.form_recv_time);
        lPreparedStatement.setString(82, inEesAdmListTabObj.prospectus_sale_date);
        lPreparedStatement.setString(83, inEesAdmListTabObj.prospectus_sale_time);
        lPreparedStatement.setString(84, inEesAdmListTabObj.prospectus_sold_by);
          lPreparedStatement.setDouble(85, inEesAdmListTabObj.application_form_fee);
        lPreparedStatement.setString(86, inEesAdmListTabObj.adm_academic_session);
        lPreparedStatement.setString(87, inEesAdmListTabObj.entrance_exam_date);
        lPreparedStatement.setString(88, inEesAdmListTabObj.entrance_exam_time_start);
        lPreparedStatement.setString(89, inEesAdmListTabObj.entrance_exam_time_end);
        lPreparedStatement.setString(90, inEesAdmListTabObj.exam_present_status);
        lPreparedStatement.setString(91, inEesAdmListTabObj.building_id);
        lPreparedStatement.setString(92, inEesAdmListTabObj.floor_num);
        lPreparedStatement.setString(93, inEesAdmListTabObj.room_num);
          lPreparedStatement.setShort(94, inEesAdmListTabObj.max_mark);
          lPreparedStatement.setShort(95, inEesAdmListTabObj.obtained_mark);
        lPreparedStatement.setString(96, inEesAdmListTabObj.grade);
        lPreparedStatement.setString(97, inEesAdmListTabObj.fee_sch_date);
        lPreparedStatement.setString(98, inEesAdmListTabObj.fee_deposit_date);
        lPreparedStatement.setString(99, inEesAdmListTabObj.online_flag);
        lPreparedStatement.setString(100, inEesAdmListTabObj.admission_mode);
        lPreparedStatement.setString(101, inEesAdmListTabObj.course_stream_1);
        lPreparedStatement.setString(102, inEesAdmListTabObj.course_stream_2);
        lPreparedStatement.setString(103, inEesAdmListTabObj.course_stream_3);
        lPreparedStatement.setString(104, inEesAdmListTabObj.course_stream_4);
        lPreparedStatement.setString(105, inEesAdmListTabObj.apr_course_stream);
        lPreparedStatement.setString(106, inEesAdmListTabObj.unv_1);
        lPreparedStatement.setString(107, inEesAdmListTabObj.unv_rn_1);
        lPreparedStatement.setString(108, inEesAdmListTabObj.gen_rank_1);
        lPreparedStatement.setString(109, inEesAdmListTabObj.ctg_rank_1);
        lPreparedStatement.setString(110, inEesAdmListTabObj.stt_rank_1);
        lPreparedStatement.setString(111, inEesAdmListTabObj.yoa_1);
        lPreparedStatement.setString(112, inEesAdmListTabObj.unv_2);
        lPreparedStatement.setString(113, inEesAdmListTabObj.unv_rn_2);
        lPreparedStatement.setString(114, inEesAdmListTabObj.gen_rank_2);
        lPreparedStatement.setString(115, inEesAdmListTabObj.ctg_rank_2);
        lPreparedStatement.setString(116, inEesAdmListTabObj.stt_rank_2);
        lPreparedStatement.setString(117, inEesAdmListTabObj.yoa_2);
          lPreparedStatement.setFloat(118, inEesAdmListTabObj.prev_mark_percent);
        lPreparedStatement.setString(119, inEesAdmListTabObj.domecile_ind);
        lPreparedStatement.setString(120, inEesAdmListTabObj.org_transport_req_ind);
        lPreparedStatement.setString(121, inEesAdmListTabObj.org_hostel_req_ind);
        lPreparedStatement.setString(122, inEesAdmListTabObj.cheque_num);
        lPreparedStatement.setString(123, inEesAdmListTabObj.cheque_date);
        lPreparedStatement.setString(124, inEesAdmListTabObj.bank_code);
        lPreparedStatement.setString(125, inEesAdmListTabObj.bank_name);
          lPreparedStatement.setDouble(126, inEesAdmListTabObj.cheque_amt);
        lPreparedStatement.setString(127, inEesAdmListTabObj.lg_0_name);
        lPreparedStatement.setString(128, inEesAdmListTabObj.lg_0_rel_type);
        lPreparedStatement.setString(129, inEesAdmListTabObj.lg_0_address);
        lPreparedStatement.setString(130, inEesAdmListTabObj.lg_0_phone);
        lPreparedStatement.setString(131, inEesAdmListTabObj.lg_1_name);
        lPreparedStatement.setString(132, inEesAdmListTabObj.lg_1_rel_type);
        lPreparedStatement.setString(133, inEesAdmListTabObj.lg_1_address);
        lPreparedStatement.setString(134, inEesAdmListTabObj.lg_1_phone);
        lPreparedStatement.setString(135, inEesAdmListTabObj.st_cap_attr_1);
        lPreparedStatement.setString(136, inEesAdmListTabObj.st_cap_attr_2);
        lPreparedStatement.setString(137, inEesAdmListTabObj.st_cap_attr_3);
        lPreparedStatement.setString(138, inEesAdmListTabObj.st_cap_attr_4);
        lPreparedStatement.setString(139, inEesAdmListTabObj.st_cap_attr_5);
        lPreparedStatement.setString(140, inEesAdmListTabObj.st_cap_attr_6);
        lPreparedStatement.setString(141, inEesAdmListTabObj.st_cap_attr_7);
        lPreparedStatement.setString(142, inEesAdmListTabObj.st_cap_attr_8);
        lPreparedStatement.setString(143, inEesAdmListTabObj.allergy);
        lPreparedStatement.setString(144, inEesAdmListTabObj.physical_disability);
        lPreparedStatement.setString(145, inEesAdmListTabObj.health_problem);
        lPreparedStatement.setString(146, inEesAdmListTabObj.health_problem_1);
        lPreparedStatement.setString(147, inEesAdmListTabObj.health_problem_2);
        lPreparedStatement.setString(148, inEesAdmListTabObj.health_problem_3);
        lPreparedStatement.setString(149, inEesAdmListTabObj.health_problem_4);
        lPreparedStatement.setString(150, inEesAdmListTabObj.health_problem_5);
        lPreparedStatement.setString(151, inEesAdmListTabObj.health_problem_6);
        lPreparedStatement.setString(152, inEesAdmListTabObj.health_problem_7);
        lPreparedStatement.setString(153, inEesAdmListTabObj.health_problem_8);
        lPreparedStatement.setString(154, inEesAdmListTabObj.health_problem_9);
        lPreparedStatement.setString(155, inEesAdmListTabObj.health_problem_10);
        lPreparedStatement.setString(156, inEesAdmListTabObj.health_problem_11);
        lPreparedStatement.setString(157, inEesAdmListTabObj.health_problem_12);
        lPreparedStatement.setString(158, inEesAdmListTabObj.enclosure_1);
        lPreparedStatement.setString(159, inEesAdmListTabObj.enclosure_2);
        lPreparedStatement.setString(160, inEesAdmListTabObj.enclosure_3);
        lPreparedStatement.setString(161, inEesAdmListTabObj.enclosure_4);
        lPreparedStatement.setString(162, inEesAdmListTabObj.enclosure_5);
        lPreparedStatement.setString(163, inEesAdmListTabObj.enclosure_6);
        lPreparedStatement.setString(164, inEesAdmListTabObj.enclosure_7);
        lPreparedStatement.setString(165, inEesAdmListTabObj.enclosure_8);
          lPreparedStatement.setShort(166, inEesAdmListTabObj.seat_num);
        lPreparedStatement.setString(167, inEesAdmListTabObj.reason_for_join);
        lPreparedStatement.setString(168, inEesAdmListTabObj.remark);
        lPreparedStatement.setString(169, inEesAdmListTabObj.place_of_birth);
          lPreparedStatement.setDouble(170, inEesAdmListTabObj.adv_adm_fee);
        lPreparedStatement.setString(171, inEesAdmListTabObj.payment_mode);
        lPreparedStatement.setString(172, inEesAdmListTabObj.target_ptl_user_id);
        lPreparedStatement.setString(173, inEesAdmListTabObj.adm_req_id_req);
        lPreparedStatement.setString(174, inEesAdmListTabObj.adm_req_id_list);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int insEesAdmListArr
               ( ArrayList  inEesAdmListTabObjArr 
               , String  inRowidFlag )
  {
    EesAdmListTabObj  lEesAdmListTabObj = new EesAdmListTabObj();
    int lUpdateCount;
    sop("insEesAdmListArr - Started");
    gSSTErrorObj.sourceMethod = "insEesAdmListArr";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      for ( int lNumRec = 0; lNumRec < inEesAdmListTabObjArr.size(); lNumRec++ )
      {
        lEesAdmListTabObj = (EesAdmListTabObj)inEesAdmListTabObjArr.get(lNumRec);

          if ( lEesAdmListTabObj.dob != null && lEesAdmListTabObj.dob.length() > 0 ) 
            lEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.dob, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.age_on_date != null && lEesAdmListTabObj.age_on_date.length() > 0 ) 
            lEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.age_on_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.adm_req_sts_date != null && lEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            lEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.form_recv_date != null && lEesAdmListTabObj.form_recv_date.length() > 0 ) 
            lEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.prospectus_sale_date != null && lEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            lEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.entrance_exam_date != null && lEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            lEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.fee_sch_date != null && lEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            lEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.fee_deposit_date != null && lEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            lEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( lEesAdmListTabObj.cheque_date != null && lEesAdmListTabObj.cheque_date.length() > 0 ) 
            lEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, lEesAdmListTabObj.cheque_date, lDateTimeSrcFmt);
          String lSqlStmt = "INSERT INTO EES_ADM_LIST"+
                        "("+
                        "org_id,"+
                        "adm_req_id,"+
                        "application_form_num,"+
                        "applicant_id,"+
                        "student_photo_file,"+
                        "mother_photo_file,"+
                        "father_photo_file,"+
                        "class_id,"+
                        "class_num,"+
                        "class_std,"+
                        "class_section,"+
                        "course_id,"+
                        "course_term,"+
                        "course_stream,"+
                        "name_initials,"+
                        "student_f_name,"+
                        "student_m_name,"+
                        "student_l_name,"+
                        "dob,"+
                        "age_on_date,"+
                        "age_year,"+
                        "age_month,"+
                        "age_day,"+
                        "s_nationality,"+
                        "religion,"+
                        "student_ctg,"+
                        "gender_flag,"+
                        "p_address_1,"+
                        "p_address_2,"+
                        "p_country,"+
                        "p_state,"+
                        "p_city,"+
                        "p_district,"+
                        "p_zip,"+
                        "m_address_1,"+
                        "m_address_2,"+
                        "m_country,"+
                        "m_state,"+
                        "m_city,"+
                        "m_district,"+
                        "m_zip,"+
                        "phone_list,"+
                        "email_list,"+
                        "fax_list,"+
                        "prev_org_name,"+
                        "prev_class_id,"+
                        "prev_class_num,"+
                        "prev_class_std,"+
                        "prev_class_section,"+
                        "prev_course_id,"+
                        "prev_course_term,"+
                        "prev_course_stream,"+
                        "reason_for_leaving,"+
                        "father_name,"+
                        "father_age,"+
                        "f_nationality,"+
                        "father_occ_type,"+
                        "father_employer,"+
                        "father_designation,"+
                        "father_annual_income,"+
                        "f_off_address_1,"+
                        "f_phone_list,"+
                        "mother_name,"+
                        "mother_age,"+
                        "m_nationality,"+
                        "mother_occ_type,"+
                        "mother_employer,"+
                        "mother_designation,"+
                        "mother_annual_income,"+
                        "m_off_address_1,"+
                        "m_phone_list,"+
                        "divorced_flag,"+
                        "child_with,"+
                        "roll_num,"+
                        "academic_session,"+
                        "adm_req_sts,"+
                        "adm_req_sts_date,"+
                        "student_id,"+
                        "scholor_num,"+
                        "form_recv_date,"+
                        "form_recv_time,"+
                        "prospectus_sale_date,"+
                        "prospectus_sale_time,"+
                        "prospectus_sold_by,"+
                        "application_form_fee,"+
                        "adm_academic_session,"+
                        "entrance_exam_date,"+
                        "entrance_exam_time_start,"+
                        "entrance_exam_time_end,"+
                        "exam_present_status,"+
                        "building_id,"+
                        "floor_num,"+
                        "room_num,"+
                        "max_mark,"+
                        "obtained_mark,"+
                        "grade,"+
                        "fee_sch_date,"+
                        "fee_deposit_date,"+
                        "online_flag,"+
                        "admission_mode,"+
                        "course_stream_1,"+
                        "course_stream_2,"+
                        "course_stream_3,"+
                        "course_stream_4,"+
                        "apr_course_stream,"+
                        "unv_1,"+
                        "unv_rn_1,"+
                        "gen_rank_1,"+
                        "ctg_rank_1,"+
                        "stt_rank_1,"+
                        "yoa_1,"+
                        "unv_2,"+
                        "unv_rn_2,"+
                        "gen_rank_2,"+
                        "ctg_rank_2,"+
                        "stt_rank_2,"+
                        "yoa_2,"+
                        "prev_mark_percent,"+
                        "domecile_ind,"+
                        "org_transport_req_ind,"+
                        "org_hostel_req_ind,"+
                        "cheque_num,"+
                        "cheque_date,"+
                        "bank_code,"+
                        "bank_name,"+
                        "cheque_amt,"+
                        "lg_0_name,"+
                        "lg_0_rel_type,"+
                        "lg_0_address,"+
                        "lg_0_phone,"+
                        "lg_1_name,"+
                        "lg_1_rel_type,"+
                        "lg_1_address,"+
                        "lg_1_phone,"+
                        "st_cap_attr_1,"+
                        "st_cap_attr_2,"+
                        "st_cap_attr_3,"+
                        "st_cap_attr_4,"+
                        "st_cap_attr_5,"+
                        "st_cap_attr_6,"+
                        "st_cap_attr_7,"+
                        "st_cap_attr_8,"+
                        "allergy,"+
                        "physical_disability,"+
                        "health_problem,"+
                        "health_problem_1,"+
                        "health_problem_2,"+
                        "health_problem_3,"+
                        "health_problem_4,"+
                        "health_problem_5,"+
                        "health_problem_6,"+
                        "health_problem_7,"+
                        "health_problem_8,"+
                        "health_problem_9,"+
                        "health_problem_10,"+
                        "health_problem_11,"+
                        "health_problem_12,"+
                        "enclosure_1,"+
                        "enclosure_2,"+
                        "enclosure_3,"+
                        "enclosure_4,"+
                        "enclosure_5,"+
                        "enclosure_6,"+
                        "enclosure_7,"+
                        "enclosure_8,"+
                        "seat_num,"+
                        "reason_for_join,"+
                        "remark,"+
                        "place_of_birth,"+
                        "adv_adm_fee,"+
                        "payment_mode,"+
                        "target_ptl_user_id,"+
                        "adm_req_id_req,"+
                        "adm_req_id_list"+
                          ")"+
                          "VALUES "+
                          "(";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.org_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_req_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.application_form_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.applicant_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.mother_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.father_photo_file+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.name_initials+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_f_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_m_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_l_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.dob+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.age_on_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.age_year+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.age_month+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.age_day+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.s_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.religion+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_ctg+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.gender_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_district+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.p_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_address_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_country+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_state+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_city+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_district+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_zip+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.email_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.fax_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_org_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_class_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_class_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_class_std+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_class_section+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_course_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_course_term+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prev_course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.reason_for_leaving+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.father_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.father_age+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.f_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.father_occ_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.father_employer+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.father_designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.father_annual_income+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.f_off_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.f_phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.mother_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.mother_age+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_nationality+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.mother_occ_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.mother_employer+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.mother_designation+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.mother_annual_income+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_off_address_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.m_phone_list+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.divorced_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.child_with+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.roll_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.academic_session+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_req_sts+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_req_sts_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.student_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.scholor_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.form_recv_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.form_recv_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prospectus_sale_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prospectus_sale_time+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.prospectus_sold_by+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.application_form_fee+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_academic_session+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.entrance_exam_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.entrance_exam_time_start+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.entrance_exam_time_end+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.exam_present_status+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.building_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.floor_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.room_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.max_mark+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.obtained_mark+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.grade+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.fee_sch_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.fee_deposit_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.online_flag+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.admission_mode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_stream_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_stream_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_stream_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.course_stream_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.apr_course_stream+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.unv_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.unv_rn_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.gen_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.ctg_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.stt_rank_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.yoa_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.unv_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.unv_rn_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.gen_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.ctg_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.stt_rank_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.yoa_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.prev_mark_percent+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.domecile_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.org_transport_req_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.org_hostel_req_ind+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.cheque_num+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.cheque_date+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.bank_code+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.bank_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.cheque_amt+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_0_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_0_rel_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_0_address+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_0_phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_1_name+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_1_rel_type+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_1_address+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.lg_1_phone+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.st_cap_attr_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.allergy+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.physical_disability+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_9+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_10+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_11+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.health_problem_12+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_1+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_2+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_3+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_4+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_5+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_6+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_7+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.enclosure_8+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.seat_num+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.reason_for_join+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.remark+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.place_of_birth+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += lEesAdmListTabObj.adv_adm_fee+",";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.payment_mode+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.target_ptl_user_id+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?,";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_req_id_req+"',";
          if ( gIsPreparedStmt )         lSqlStmt += "?";       else lSqlStmt += "'"+lEesAdmListTabObj.adm_req_id_list+"'";
      lSqlStmt +=           ")";

          lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
          lSqlStmt = lSqlStmt.replaceAll("''", "null");

           sop("Sql Statement : "+lSqlStmt);

          if ( gIsPreparedStmt ) 
          {
            PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
            lPreparedStatement.setString(1, lEesAdmListTabObj.org_id);
            lPreparedStatement.setString(2, lEesAdmListTabObj.adm_req_id);
            lPreparedStatement.setString(3, lEesAdmListTabObj.application_form_num);
            lPreparedStatement.setString(4, lEesAdmListTabObj.applicant_id);
            lPreparedStatement.setString(5, lEesAdmListTabObj.student_photo_file);
            lPreparedStatement.setString(6, lEesAdmListTabObj.mother_photo_file);
            lPreparedStatement.setString(7, lEesAdmListTabObj.father_photo_file);
            lPreparedStatement.setString(8, lEesAdmListTabObj.class_id);
            lPreparedStatement.setString(9, lEesAdmListTabObj.class_num);
            lPreparedStatement.setString(10, lEesAdmListTabObj.class_std);
            lPreparedStatement.setString(11, lEesAdmListTabObj.class_section);
            lPreparedStatement.setString(12, lEesAdmListTabObj.course_id);
            lPreparedStatement.setString(13, lEesAdmListTabObj.course_term);
            lPreparedStatement.setString(14, lEesAdmListTabObj.course_stream);
            lPreparedStatement.setString(15, lEesAdmListTabObj.name_initials);
            lPreparedStatement.setString(16, lEesAdmListTabObj.student_f_name);
            lPreparedStatement.setString(17, lEesAdmListTabObj.student_m_name);
            lPreparedStatement.setString(18, lEesAdmListTabObj.student_l_name);
            lPreparedStatement.setString(19, lEesAdmListTabObj.dob);
            lPreparedStatement.setString(20, lEesAdmListTabObj.age_on_date);
              lPreparedStatement.setByte(21, lEesAdmListTabObj.age_year);
            lPreparedStatement.setString(22, lEesAdmListTabObj.age_month);
              lPreparedStatement.setByte(23, lEesAdmListTabObj.age_day);
            lPreparedStatement.setString(24, lEesAdmListTabObj.s_nationality);
            lPreparedStatement.setString(25, lEesAdmListTabObj.religion);
            lPreparedStatement.setString(26, lEesAdmListTabObj.student_ctg);
            lPreparedStatement.setString(27, lEesAdmListTabObj.gender_flag);
            lPreparedStatement.setString(28, lEesAdmListTabObj.p_address_1);
            lPreparedStatement.setString(29, lEesAdmListTabObj.p_address_2);
            lPreparedStatement.setString(30, lEesAdmListTabObj.p_country);
            lPreparedStatement.setString(31, lEesAdmListTabObj.p_state);
            lPreparedStatement.setString(32, lEesAdmListTabObj.p_city);
            lPreparedStatement.setString(33, lEesAdmListTabObj.p_district);
            lPreparedStatement.setString(34, lEesAdmListTabObj.p_zip);
            lPreparedStatement.setString(35, lEesAdmListTabObj.m_address_1);
            lPreparedStatement.setString(36, lEesAdmListTabObj.m_address_2);
            lPreparedStatement.setString(37, lEesAdmListTabObj.m_country);
            lPreparedStatement.setString(38, lEesAdmListTabObj.m_state);
            lPreparedStatement.setString(39, lEesAdmListTabObj.m_city);
            lPreparedStatement.setString(40, lEesAdmListTabObj.m_district);
            lPreparedStatement.setString(41, lEesAdmListTabObj.m_zip);
            lPreparedStatement.setString(42, lEesAdmListTabObj.phone_list);
            lPreparedStatement.setString(43, lEesAdmListTabObj.email_list);
            lPreparedStatement.setString(44, lEesAdmListTabObj.fax_list);
            lPreparedStatement.setString(45, lEesAdmListTabObj.prev_org_name);
            lPreparedStatement.setString(46, lEesAdmListTabObj.prev_class_id);
            lPreparedStatement.setString(47, lEesAdmListTabObj.prev_class_num);
            lPreparedStatement.setString(48, lEesAdmListTabObj.prev_class_std);
            lPreparedStatement.setString(49, lEesAdmListTabObj.prev_class_section);
            lPreparedStatement.setString(50, lEesAdmListTabObj.prev_course_id);
            lPreparedStatement.setString(51, lEesAdmListTabObj.prev_course_term);
            lPreparedStatement.setString(52, lEesAdmListTabObj.prev_course_stream);
            lPreparedStatement.setString(53, lEesAdmListTabObj.reason_for_leaving);
            lPreparedStatement.setString(54, lEesAdmListTabObj.father_name);
              lPreparedStatement.setByte(55, lEesAdmListTabObj.father_age);
            lPreparedStatement.setString(56, lEesAdmListTabObj.f_nationality);
            lPreparedStatement.setString(57, lEesAdmListTabObj.father_occ_type);
            lPreparedStatement.setString(58, lEesAdmListTabObj.father_employer);
            lPreparedStatement.setString(59, lEesAdmListTabObj.father_designation);
              lPreparedStatement.setDouble(60, lEesAdmListTabObj.father_annual_income);
            lPreparedStatement.setString(61, lEesAdmListTabObj.f_off_address_1);
            lPreparedStatement.setString(62, lEesAdmListTabObj.f_phone_list);
            lPreparedStatement.setString(63, lEesAdmListTabObj.mother_name);
              lPreparedStatement.setByte(64, lEesAdmListTabObj.mother_age);
            lPreparedStatement.setString(65, lEesAdmListTabObj.m_nationality);
            lPreparedStatement.setString(66, lEesAdmListTabObj.mother_occ_type);
            lPreparedStatement.setString(67, lEesAdmListTabObj.mother_employer);
            lPreparedStatement.setString(68, lEesAdmListTabObj.mother_designation);
              lPreparedStatement.setDouble(69, lEesAdmListTabObj.mother_annual_income);
            lPreparedStatement.setString(70, lEesAdmListTabObj.m_off_address_1);
            lPreparedStatement.setString(71, lEesAdmListTabObj.m_phone_list);
            lPreparedStatement.setString(72, lEesAdmListTabObj.divorced_flag);
            lPreparedStatement.setString(73, lEesAdmListTabObj.child_with);
            lPreparedStatement.setString(74, lEesAdmListTabObj.roll_num);
            lPreparedStatement.setString(75, lEesAdmListTabObj.academic_session);
            lPreparedStatement.setString(76, lEesAdmListTabObj.adm_req_sts);
            lPreparedStatement.setString(77, lEesAdmListTabObj.adm_req_sts_date);
            lPreparedStatement.setString(78, lEesAdmListTabObj.student_id);
            lPreparedStatement.setString(79, lEesAdmListTabObj.scholor_num);
            lPreparedStatement.setString(80, lEesAdmListTabObj.form_recv_date);
            lPreparedStatement.setString(81, lEesAdmListTabObj.form_recv_time);
            lPreparedStatement.setString(82, lEesAdmListTabObj.prospectus_sale_date);
            lPreparedStatement.setString(83, lEesAdmListTabObj.prospectus_sale_time);
            lPreparedStatement.setString(84, lEesAdmListTabObj.prospectus_sold_by);
              lPreparedStatement.setDouble(85, lEesAdmListTabObj.application_form_fee);
            lPreparedStatement.setString(86, lEesAdmListTabObj.adm_academic_session);
            lPreparedStatement.setString(87, lEesAdmListTabObj.entrance_exam_date);
            lPreparedStatement.setString(88, lEesAdmListTabObj.entrance_exam_time_start);
            lPreparedStatement.setString(89, lEesAdmListTabObj.entrance_exam_time_end);
            lPreparedStatement.setString(90, lEesAdmListTabObj.exam_present_status);
            lPreparedStatement.setString(91, lEesAdmListTabObj.building_id);
            lPreparedStatement.setString(92, lEesAdmListTabObj.floor_num);
            lPreparedStatement.setString(93, lEesAdmListTabObj.room_num);
              lPreparedStatement.setShort(94, lEesAdmListTabObj.max_mark);
              lPreparedStatement.setShort(95, lEesAdmListTabObj.obtained_mark);
            lPreparedStatement.setString(96, lEesAdmListTabObj.grade);
            lPreparedStatement.setString(97, lEesAdmListTabObj.fee_sch_date);
            lPreparedStatement.setString(98, lEesAdmListTabObj.fee_deposit_date);
            lPreparedStatement.setString(99, lEesAdmListTabObj.online_flag);
            lPreparedStatement.setString(100, lEesAdmListTabObj.admission_mode);
            lPreparedStatement.setString(101, lEesAdmListTabObj.course_stream_1);
            lPreparedStatement.setString(102, lEesAdmListTabObj.course_stream_2);
            lPreparedStatement.setString(103, lEesAdmListTabObj.course_stream_3);
            lPreparedStatement.setString(104, lEesAdmListTabObj.course_stream_4);
            lPreparedStatement.setString(105, lEesAdmListTabObj.apr_course_stream);
            lPreparedStatement.setString(106, lEesAdmListTabObj.unv_1);
            lPreparedStatement.setString(107, lEesAdmListTabObj.unv_rn_1);
            lPreparedStatement.setString(108, lEesAdmListTabObj.gen_rank_1);
            lPreparedStatement.setString(109, lEesAdmListTabObj.ctg_rank_1);
            lPreparedStatement.setString(110, lEesAdmListTabObj.stt_rank_1);
            lPreparedStatement.setString(111, lEesAdmListTabObj.yoa_1);
            lPreparedStatement.setString(112, lEesAdmListTabObj.unv_2);
            lPreparedStatement.setString(113, lEesAdmListTabObj.unv_rn_2);
            lPreparedStatement.setString(114, lEesAdmListTabObj.gen_rank_2);
            lPreparedStatement.setString(115, lEesAdmListTabObj.ctg_rank_2);
            lPreparedStatement.setString(116, lEesAdmListTabObj.stt_rank_2);
            lPreparedStatement.setString(117, lEesAdmListTabObj.yoa_2);
              lPreparedStatement.setFloat(118, lEesAdmListTabObj.prev_mark_percent);
            lPreparedStatement.setString(119, lEesAdmListTabObj.domecile_ind);
            lPreparedStatement.setString(120, lEesAdmListTabObj.org_transport_req_ind);
            lPreparedStatement.setString(121, lEesAdmListTabObj.org_hostel_req_ind);
            lPreparedStatement.setString(122, lEesAdmListTabObj.cheque_num);
            lPreparedStatement.setString(123, lEesAdmListTabObj.cheque_date);
            lPreparedStatement.setString(124, lEesAdmListTabObj.bank_code);
            lPreparedStatement.setString(125, lEesAdmListTabObj.bank_name);
              lPreparedStatement.setDouble(126, lEesAdmListTabObj.cheque_amt);
            lPreparedStatement.setString(127, lEesAdmListTabObj.lg_0_name);
            lPreparedStatement.setString(128, lEesAdmListTabObj.lg_0_rel_type);
            lPreparedStatement.setString(129, lEesAdmListTabObj.lg_0_address);
            lPreparedStatement.setString(130, lEesAdmListTabObj.lg_0_phone);
            lPreparedStatement.setString(131, lEesAdmListTabObj.lg_1_name);
            lPreparedStatement.setString(132, lEesAdmListTabObj.lg_1_rel_type);
            lPreparedStatement.setString(133, lEesAdmListTabObj.lg_1_address);
            lPreparedStatement.setString(134, lEesAdmListTabObj.lg_1_phone);
            lPreparedStatement.setString(135, lEesAdmListTabObj.st_cap_attr_1);
            lPreparedStatement.setString(136, lEesAdmListTabObj.st_cap_attr_2);
            lPreparedStatement.setString(137, lEesAdmListTabObj.st_cap_attr_3);
            lPreparedStatement.setString(138, lEesAdmListTabObj.st_cap_attr_4);
            lPreparedStatement.setString(139, lEesAdmListTabObj.st_cap_attr_5);
            lPreparedStatement.setString(140, lEesAdmListTabObj.st_cap_attr_6);
            lPreparedStatement.setString(141, lEesAdmListTabObj.st_cap_attr_7);
            lPreparedStatement.setString(142, lEesAdmListTabObj.st_cap_attr_8);
            lPreparedStatement.setString(143, lEesAdmListTabObj.allergy);
            lPreparedStatement.setString(144, lEesAdmListTabObj.physical_disability);
            lPreparedStatement.setString(145, lEesAdmListTabObj.health_problem);
            lPreparedStatement.setString(146, lEesAdmListTabObj.health_problem_1);
            lPreparedStatement.setString(147, lEesAdmListTabObj.health_problem_2);
            lPreparedStatement.setString(148, lEesAdmListTabObj.health_problem_3);
            lPreparedStatement.setString(149, lEesAdmListTabObj.health_problem_4);
            lPreparedStatement.setString(150, lEesAdmListTabObj.health_problem_5);
            lPreparedStatement.setString(151, lEesAdmListTabObj.health_problem_6);
            lPreparedStatement.setString(152, lEesAdmListTabObj.health_problem_7);
            lPreparedStatement.setString(153, lEesAdmListTabObj.health_problem_8);
            lPreparedStatement.setString(154, lEesAdmListTabObj.health_problem_9);
            lPreparedStatement.setString(155, lEesAdmListTabObj.health_problem_10);
            lPreparedStatement.setString(156, lEesAdmListTabObj.health_problem_11);
            lPreparedStatement.setString(157, lEesAdmListTabObj.health_problem_12);
            lPreparedStatement.setString(158, lEesAdmListTabObj.enclosure_1);
            lPreparedStatement.setString(159, lEesAdmListTabObj.enclosure_2);
            lPreparedStatement.setString(160, lEesAdmListTabObj.enclosure_3);
            lPreparedStatement.setString(161, lEesAdmListTabObj.enclosure_4);
            lPreparedStatement.setString(162, lEesAdmListTabObj.enclosure_5);
            lPreparedStatement.setString(163, lEesAdmListTabObj.enclosure_6);
            lPreparedStatement.setString(164, lEesAdmListTabObj.enclosure_7);
            lPreparedStatement.setString(165, lEesAdmListTabObj.enclosure_8);
              lPreparedStatement.setShort(166, lEesAdmListTabObj.seat_num);
            lPreparedStatement.setString(167, lEesAdmListTabObj.reason_for_join);
            lPreparedStatement.setString(168, lEesAdmListTabObj.remark);
            lPreparedStatement.setString(169, lEesAdmListTabObj.place_of_birth);
              lPreparedStatement.setDouble(170, lEesAdmListTabObj.adv_adm_fee);
            lPreparedStatement.setString(171, lEesAdmListTabObj.payment_mode);
            lPreparedStatement.setString(172, lEesAdmListTabObj.target_ptl_user_id);
            lPreparedStatement.setString(173, lEesAdmListTabObj.adm_req_id_req);
            lPreparedStatement.setString(174, lEesAdmListTabObj.adm_req_id_list);
            lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
          }
          else
          { 
            lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
          } 
        if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
        { 
          gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
          lReturnValue = -999000000+gSSTErrorObj.errorCode; 
          throw new Exception(); 
        } 
        lReturnValue = lReturnValue + lUpdateCount; 
      }


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


  public int popEesAdmListReq2Obj
               ( HttpServletRequest inRequest
               , EesAdmListTabObj  outEesAdmListTabObj
               )
  {
    int    lReturnValue = 0;
    String lTabRowidValue = inRequest.getParameter("tab_rowid");
    outEesAdmListTabObj.tab_rowid = lTabRowidValue;

    outEesAdmListTabObj.org_id = inRequest.getParameter("org_id");
    outEesAdmListTabObj.adm_req_id = inRequest.getParameter("adm_req_id");
    outEesAdmListTabObj.application_form_num = inRequest.getParameter("application_form_num");
    outEesAdmListTabObj.applicant_id = inRequest.getParameter("applicant_id");
    outEesAdmListTabObj.student_photo_file = inRequest.getParameter("student_photo_file");
    outEesAdmListTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file");
    outEesAdmListTabObj.father_photo_file = inRequest.getParameter("father_photo_file");
    outEesAdmListTabObj.class_id = inRequest.getParameter("class_id");
    outEesAdmListTabObj.class_num = inRequest.getParameter("class_num");
    outEesAdmListTabObj.class_std = inRequest.getParameter("class_std");
    outEesAdmListTabObj.class_section = inRequest.getParameter("class_section");
    outEesAdmListTabObj.course_id = inRequest.getParameter("course_id");
    outEesAdmListTabObj.course_term = inRequest.getParameter("course_term");
    outEesAdmListTabObj.course_stream = inRequest.getParameter("course_stream");
    outEesAdmListTabObj.name_initials = inRequest.getParameter("name_initials");
    outEesAdmListTabObj.student_f_name = inRequest.getParameter("student_f_name");
    outEesAdmListTabObj.student_m_name = inRequest.getParameter("student_m_name");
    outEesAdmListTabObj.student_l_name = inRequest.getParameter("student_l_name");
    outEesAdmListTabObj.dob = inRequest.getParameter("dob");
    outEesAdmListTabObj.age_on_date = inRequest.getParameter("age_on_date");
    if ( inRequest.getParameter("age_year") == null )
      outEesAdmListTabObj.age_year = 0;
    else
    if ( inRequest.getParameter("age_year").trim().length() == 0 )
      outEesAdmListTabObj.age_year = 0;
    else
      outEesAdmListTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year"));
    outEesAdmListTabObj.age_month = inRequest.getParameter("age_month");
    if ( inRequest.getParameter("age_day") == null )
      outEesAdmListTabObj.age_day = 0;
    else
    if ( inRequest.getParameter("age_day").trim().length() == 0 )
      outEesAdmListTabObj.age_day = 0;
    else
      outEesAdmListTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day"));
    outEesAdmListTabObj.s_nationality = inRequest.getParameter("s_nationality");
    outEesAdmListTabObj.religion = inRequest.getParameter("religion");
    outEesAdmListTabObj.student_ctg = inRequest.getParameter("student_ctg");
    outEesAdmListTabObj.gender_flag = inRequest.getParameter("gender_flag");
    outEesAdmListTabObj.p_address_1 = inRequest.getParameter("p_address_1");
    outEesAdmListTabObj.p_address_2 = inRequest.getParameter("p_address_2");
    outEesAdmListTabObj.p_country = inRequest.getParameter("p_country");
    outEesAdmListTabObj.p_state = inRequest.getParameter("p_state");
    outEesAdmListTabObj.p_city = inRequest.getParameter("p_city");
    outEesAdmListTabObj.p_district = inRequest.getParameter("p_district");
    outEesAdmListTabObj.p_zip = inRequest.getParameter("p_zip");
    outEesAdmListTabObj.m_address_1 = inRequest.getParameter("m_address_1");
    outEesAdmListTabObj.m_address_2 = inRequest.getParameter("m_address_2");
    outEesAdmListTabObj.m_country = inRequest.getParameter("m_country");
    outEesAdmListTabObj.m_state = inRequest.getParameter("m_state");
    outEesAdmListTabObj.m_city = inRequest.getParameter("m_city");
    outEesAdmListTabObj.m_district = inRequest.getParameter("m_district");
    outEesAdmListTabObj.m_zip = inRequest.getParameter("m_zip");
    outEesAdmListTabObj.phone_list = inRequest.getParameter("phone_list");
    outEesAdmListTabObj.email_list = inRequest.getParameter("email_list");
    outEesAdmListTabObj.fax_list = inRequest.getParameter("fax_list");
    outEesAdmListTabObj.prev_org_name = inRequest.getParameter("prev_org_name");
    outEesAdmListTabObj.prev_class_id = inRequest.getParameter("prev_class_id");
    outEesAdmListTabObj.prev_class_num = inRequest.getParameter("prev_class_num");
    outEesAdmListTabObj.prev_class_std = inRequest.getParameter("prev_class_std");
    outEesAdmListTabObj.prev_class_section = inRequest.getParameter("prev_class_section");
    outEesAdmListTabObj.prev_course_id = inRequest.getParameter("prev_course_id");
    outEesAdmListTabObj.prev_course_term = inRequest.getParameter("prev_course_term");
    outEesAdmListTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream");
    outEesAdmListTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving");
    outEesAdmListTabObj.father_name = inRequest.getParameter("father_name");
    if ( inRequest.getParameter("father_age") == null )
      outEesAdmListTabObj.father_age = 0;
    else
    if ( inRequest.getParameter("father_age").trim().length() == 0 )
      outEesAdmListTabObj.father_age = 0;
    else
      outEesAdmListTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age"));
    outEesAdmListTabObj.f_nationality = inRequest.getParameter("f_nationality");
    outEesAdmListTabObj.father_occ_type = inRequest.getParameter("father_occ_type");
    outEesAdmListTabObj.father_employer = inRequest.getParameter("father_employer");
    outEesAdmListTabObj.father_designation = inRequest.getParameter("father_designation");
    if ( inRequest.getParameter("father_annual_income") == null )
      outEesAdmListTabObj.father_annual_income = 0;
    else
    if ( inRequest.getParameter("father_annual_income").trim().length() == 0 )
      outEesAdmListTabObj.father_annual_income = 0;
    else
      outEesAdmListTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income"));
    outEesAdmListTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1");
    outEesAdmListTabObj.f_phone_list = inRequest.getParameter("f_phone_list");
    outEesAdmListTabObj.mother_name = inRequest.getParameter("mother_name");
    if ( inRequest.getParameter("mother_age") == null )
      outEesAdmListTabObj.mother_age = 0;
    else
    if ( inRequest.getParameter("mother_age").trim().length() == 0 )
      outEesAdmListTabObj.mother_age = 0;
    else
      outEesAdmListTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age"));
    outEesAdmListTabObj.m_nationality = inRequest.getParameter("m_nationality");
    outEesAdmListTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type");
    outEesAdmListTabObj.mother_employer = inRequest.getParameter("mother_employer");
    outEesAdmListTabObj.mother_designation = inRequest.getParameter("mother_designation");
    if ( inRequest.getParameter("mother_annual_income") == null )
      outEesAdmListTabObj.mother_annual_income = 0;
    else
    if ( inRequest.getParameter("mother_annual_income").trim().length() == 0 )
      outEesAdmListTabObj.mother_annual_income = 0;
    else
      outEesAdmListTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income"));
    outEesAdmListTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1");
    outEesAdmListTabObj.m_phone_list = inRequest.getParameter("m_phone_list");
    outEesAdmListTabObj.divorced_flag = inRequest.getParameter("divorced_flag");
    outEesAdmListTabObj.child_with = inRequest.getParameter("child_with");
    outEesAdmListTabObj.roll_num = inRequest.getParameter("roll_num");
    outEesAdmListTabObj.academic_session = inRequest.getParameter("academic_session");
    outEesAdmListTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts");
    outEesAdmListTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date");
    outEesAdmListTabObj.student_id = inRequest.getParameter("student_id");
    outEesAdmListTabObj.scholor_num = inRequest.getParameter("scholor_num");
    outEesAdmListTabObj.form_recv_date = inRequest.getParameter("form_recv_date");
    outEesAdmListTabObj.form_recv_time = inRequest.getParameter("form_recv_time");
    outEesAdmListTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date");
    outEesAdmListTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time");
    outEesAdmListTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by");
    if ( inRequest.getParameter("application_form_fee") == null )
      outEesAdmListTabObj.application_form_fee = 0;
    else
    if ( inRequest.getParameter("application_form_fee").trim().length() == 0 )
      outEesAdmListTabObj.application_form_fee = 0;
    else
      outEesAdmListTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee"));
    outEesAdmListTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session");
    outEesAdmListTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date");
    outEesAdmListTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start");
    outEesAdmListTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end");
    outEesAdmListTabObj.exam_present_status = inRequest.getParameter("exam_present_status");
    outEesAdmListTabObj.building_id = inRequest.getParameter("building_id");
    outEesAdmListTabObj.floor_num = inRequest.getParameter("floor_num");
    outEesAdmListTabObj.room_num = inRequest.getParameter("room_num");
    if ( inRequest.getParameter("max_mark") == null )
      outEesAdmListTabObj.max_mark = 0;
    else
    if ( inRequest.getParameter("max_mark").trim().length() == 0 )
      outEesAdmListTabObj.max_mark = 0;
    else
      outEesAdmListTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark"));
    if ( inRequest.getParameter("obtained_mark") == null )
      outEesAdmListTabObj.obtained_mark = 0;
    else
    if ( inRequest.getParameter("obtained_mark").trim().length() == 0 )
      outEesAdmListTabObj.obtained_mark = 0;
    else
      outEesAdmListTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark"));
    outEesAdmListTabObj.grade = inRequest.getParameter("grade");
    outEesAdmListTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date");
    outEesAdmListTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date");
    outEesAdmListTabObj.online_flag = inRequest.getParameter("online_flag");
    outEesAdmListTabObj.admission_mode = inRequest.getParameter("admission_mode");
    outEesAdmListTabObj.course_stream_1 = inRequest.getParameter("course_stream_1");
    outEesAdmListTabObj.course_stream_2 = inRequest.getParameter("course_stream_2");
    outEesAdmListTabObj.course_stream_3 = inRequest.getParameter("course_stream_3");
    outEesAdmListTabObj.course_stream_4 = inRequest.getParameter("course_stream_4");
    outEesAdmListTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream");
    outEesAdmListTabObj.unv_1 = inRequest.getParameter("unv_1");
    outEesAdmListTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1");
    outEesAdmListTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1");
    outEesAdmListTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1");
    outEesAdmListTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1");
    outEesAdmListTabObj.yoa_1 = inRequest.getParameter("yoa_1");
    outEesAdmListTabObj.unv_2 = inRequest.getParameter("unv_2");
    outEesAdmListTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2");
    outEesAdmListTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2");
    outEesAdmListTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2");
    outEesAdmListTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2");
    outEesAdmListTabObj.yoa_2 = inRequest.getParameter("yoa_2");
    if ( inRequest.getParameter("prev_mark_percent") == null )
      outEesAdmListTabObj.prev_mark_percent = 0;
    else
    if ( inRequest.getParameter("prev_mark_percent").trim().length() == 0 )
      outEesAdmListTabObj.prev_mark_percent = 0;
    else
      outEesAdmListTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent"));
    outEesAdmListTabObj.domecile_ind = inRequest.getParameter("domecile_ind");
    outEesAdmListTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind");
    outEesAdmListTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind");
    outEesAdmListTabObj.cheque_num = inRequest.getParameter("cheque_num");
    outEesAdmListTabObj.cheque_date = inRequest.getParameter("cheque_date");
    outEesAdmListTabObj.bank_code = inRequest.getParameter("bank_code");
    outEesAdmListTabObj.bank_name = inRequest.getParameter("bank_name");
    if ( inRequest.getParameter("cheque_amt") == null )
      outEesAdmListTabObj.cheque_amt = 0;
    else
    if ( inRequest.getParameter("cheque_amt").trim().length() == 0 )
      outEesAdmListTabObj.cheque_amt = 0;
    else
      outEesAdmListTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt"));
    outEesAdmListTabObj.lg_0_name = inRequest.getParameter("lg_0_name");
    outEesAdmListTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type");
    outEesAdmListTabObj.lg_0_address = inRequest.getParameter("lg_0_address");
    outEesAdmListTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone");
    outEesAdmListTabObj.lg_1_name = inRequest.getParameter("lg_1_name");
    outEesAdmListTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type");
    outEesAdmListTabObj.lg_1_address = inRequest.getParameter("lg_1_address");
    outEesAdmListTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone");
    outEesAdmListTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1");
    outEesAdmListTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2");
    outEesAdmListTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3");
    outEesAdmListTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4");
    outEesAdmListTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5");
    outEesAdmListTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6");
    outEesAdmListTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7");
    outEesAdmListTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8");
    outEesAdmListTabObj.allergy = inRequest.getParameter("allergy");
    outEesAdmListTabObj.physical_disability = inRequest.getParameter("physical_disability");
    outEesAdmListTabObj.health_problem = inRequest.getParameter("health_problem");
    outEesAdmListTabObj.health_problem_1 = inRequest.getParameter("health_problem_1");
    outEesAdmListTabObj.health_problem_2 = inRequest.getParameter("health_problem_2");
    outEesAdmListTabObj.health_problem_3 = inRequest.getParameter("health_problem_3");
    outEesAdmListTabObj.health_problem_4 = inRequest.getParameter("health_problem_4");
    outEesAdmListTabObj.health_problem_5 = inRequest.getParameter("health_problem_5");
    outEesAdmListTabObj.health_problem_6 = inRequest.getParameter("health_problem_6");
    outEesAdmListTabObj.health_problem_7 = inRequest.getParameter("health_problem_7");
    outEesAdmListTabObj.health_problem_8 = inRequest.getParameter("health_problem_8");
    outEesAdmListTabObj.health_problem_9 = inRequest.getParameter("health_problem_9");
    outEesAdmListTabObj.health_problem_10 = inRequest.getParameter("health_problem_10");
    outEesAdmListTabObj.health_problem_11 = inRequest.getParameter("health_problem_11");
    outEesAdmListTabObj.health_problem_12 = inRequest.getParameter("health_problem_12");
    outEesAdmListTabObj.enclosure_1 = inRequest.getParameter("enclosure_1");
    outEesAdmListTabObj.enclosure_2 = inRequest.getParameter("enclosure_2");
    outEesAdmListTabObj.enclosure_3 = inRequest.getParameter("enclosure_3");
    outEesAdmListTabObj.enclosure_4 = inRequest.getParameter("enclosure_4");
    outEesAdmListTabObj.enclosure_5 = inRequest.getParameter("enclosure_5");
    outEesAdmListTabObj.enclosure_6 = inRequest.getParameter("enclosure_6");
    outEesAdmListTabObj.enclosure_7 = inRequest.getParameter("enclosure_7");
    outEesAdmListTabObj.enclosure_8 = inRequest.getParameter("enclosure_8");
    if ( inRequest.getParameter("seat_num") == null )
      outEesAdmListTabObj.seat_num = 0;
    else
    if ( inRequest.getParameter("seat_num").trim().length() == 0 )
      outEesAdmListTabObj.seat_num = 0;
    else
      outEesAdmListTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num"));
    outEesAdmListTabObj.reason_for_join = inRequest.getParameter("reason_for_join");
    outEesAdmListTabObj.remark = inRequest.getParameter("remark");
    outEesAdmListTabObj.place_of_birth = inRequest.getParameter("place_of_birth");
    if ( inRequest.getParameter("adv_adm_fee") == null )
      outEesAdmListTabObj.adv_adm_fee = 0;
    else
    if ( inRequest.getParameter("adv_adm_fee").trim().length() == 0 )
      outEesAdmListTabObj.adv_adm_fee = 0;
    else
      outEesAdmListTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee"));
    outEesAdmListTabObj.payment_mode = inRequest.getParameter("payment_mode");
    outEesAdmListTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id");
    outEesAdmListTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req");
    outEesAdmListTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list");
    return lReturnValue;
  }


  public int popEesAdmListReq2ObjArr
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAdmListTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAdmListTabObj lEesAdmListTabObj= new EesAdmListTabObj();
      String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAdmListTabObj.tab_rowid = lTabRowidValue;

      lEesAdmListTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
      lEesAdmListTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
      lEesAdmListTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
      lEesAdmListTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
      lEesAdmListTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
      lEesAdmListTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
      lEesAdmListTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
      lEesAdmListTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
      lEesAdmListTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
      lEesAdmListTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
      lEesAdmListTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
      lEesAdmListTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
      lEesAdmListTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
      lEesAdmListTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
      lEesAdmListTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
      lEesAdmListTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
      lEesAdmListTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
      lEesAdmListTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
      lEesAdmListTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
      lEesAdmListTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
      if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
        lEesAdmListTabObj.age_year = 0;
      else
      if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.age_year = 0;
      else
        lEesAdmListTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
      lEesAdmListTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
      if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
        lEesAdmListTabObj.age_day = 0;
      else
      if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.age_day = 0;
      else
        lEesAdmListTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
      lEesAdmListTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
      lEesAdmListTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
      lEesAdmListTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
      lEesAdmListTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
      lEesAdmListTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
      lEesAdmListTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
      lEesAdmListTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
      lEesAdmListTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
      lEesAdmListTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
      lEesAdmListTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
      lEesAdmListTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
      lEesAdmListTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
      lEesAdmListTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
      lEesAdmListTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
      lEesAdmListTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
      lEesAdmListTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
      lEesAdmListTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
      lEesAdmListTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
      lEesAdmListTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
      lEesAdmListTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
      lEesAdmListTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
      lEesAdmListTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
      lEesAdmListTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
      lEesAdmListTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
      lEesAdmListTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
      lEesAdmListTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
      lEesAdmListTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
      lEesAdmListTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
      lEesAdmListTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
      lEesAdmListTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
      lEesAdmListTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
      if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
        lEesAdmListTabObj.father_age = 0;
      else
      if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.father_age = 0;
      else
        lEesAdmListTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
      lEesAdmListTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
      lEesAdmListTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
      lEesAdmListTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
      lEesAdmListTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
      if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
        lEesAdmListTabObj.father_annual_income = 0;
      else
      if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.father_annual_income = 0;
      else
        lEesAdmListTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
      lEesAdmListTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
      lEesAdmListTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
      lEesAdmListTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
      if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
        lEesAdmListTabObj.mother_age = 0;
      else
      if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.mother_age = 0;
      else
        lEesAdmListTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
      lEesAdmListTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
      lEesAdmListTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
      lEesAdmListTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
      lEesAdmListTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
      if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
        lEesAdmListTabObj.mother_annual_income = 0;
      else
      if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.mother_annual_income = 0;
      else
        lEesAdmListTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
      lEesAdmListTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
      lEesAdmListTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
      lEesAdmListTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
      lEesAdmListTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
      lEesAdmListTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
      lEesAdmListTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
      lEesAdmListTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
      lEesAdmListTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
      lEesAdmListTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
      lEesAdmListTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
      lEesAdmListTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
      lEesAdmListTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
      lEesAdmListTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
      lEesAdmListTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
      lEesAdmListTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
      if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
        lEesAdmListTabObj.application_form_fee = 0;
      else
      if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.application_form_fee = 0;
      else
        lEesAdmListTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
      lEesAdmListTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
      lEesAdmListTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
      lEesAdmListTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
      lEesAdmListTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
      lEesAdmListTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
      lEesAdmListTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
      lEesAdmListTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
      lEesAdmListTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
      if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
        lEesAdmListTabObj.max_mark = 0;
      else
      if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.max_mark = 0;
      else
        lEesAdmListTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
      if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
        lEesAdmListTabObj.obtained_mark = 0;
      else
      if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.obtained_mark = 0;
      else
        lEesAdmListTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
      lEesAdmListTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
      lEesAdmListTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
      lEesAdmListTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
      lEesAdmListTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
      lEesAdmListTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
      lEesAdmListTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
      lEesAdmListTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
      lEesAdmListTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
      lEesAdmListTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
      lEesAdmListTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
      lEesAdmListTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
      lEesAdmListTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
      lEesAdmListTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
      lEesAdmListTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
      lEesAdmListTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
      lEesAdmListTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
      lEesAdmListTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
      lEesAdmListTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
      lEesAdmListTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
      lEesAdmListTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
      lEesAdmListTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
      lEesAdmListTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
      if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
        lEesAdmListTabObj.prev_mark_percent = 0;
      else
      if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.prev_mark_percent = 0;
      else
        lEesAdmListTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
      lEesAdmListTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
      lEesAdmListTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
      lEesAdmListTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
      lEesAdmListTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
      lEesAdmListTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
      lEesAdmListTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
      lEesAdmListTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
      if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
        lEesAdmListTabObj.cheque_amt = 0;
      else
      if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.cheque_amt = 0;
      else
        lEesAdmListTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
      lEesAdmListTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
      lEesAdmListTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
      lEesAdmListTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
      lEesAdmListTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
      lEesAdmListTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
      lEesAdmListTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
      lEesAdmListTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
      lEesAdmListTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
      lEesAdmListTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
      lEesAdmListTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
      lEesAdmListTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
      lEesAdmListTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
      lEesAdmListTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
      lEesAdmListTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
      lEesAdmListTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
      lEesAdmListTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
      lEesAdmListTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
      lEesAdmListTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
      lEesAdmListTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
      lEesAdmListTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
      lEesAdmListTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
      lEesAdmListTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
      lEesAdmListTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
      lEesAdmListTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
      lEesAdmListTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
      lEesAdmListTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
      lEesAdmListTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
      lEesAdmListTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
      lEesAdmListTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
      lEesAdmListTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
      lEesAdmListTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
      lEesAdmListTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
      if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
        lEesAdmListTabObj.seat_num = 0;
      else
      if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.seat_num = 0;
      else
        lEesAdmListTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
      lEesAdmListTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
      lEesAdmListTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
      lEesAdmListTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
      if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
        lEesAdmListTabObj.adv_adm_fee = 0;
      else
      if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
        lEesAdmListTabObj.adv_adm_fee = 0;
      else
        lEesAdmListTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
      lEesAdmListTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
      lEesAdmListTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
      lEesAdmListTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
      lEesAdmListTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      outEesAdmListTabObjArr.add( lEesAdmListTabObj);
    }
    return lReturnValue;
  }


  public int popEesAdmListReq2ObjM2O
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , EesAdmListTabObj outEesAdmListTabObj
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_adm_list_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
        outEesAdmListTabObj.tab_rowid = lTabRowidValue;

        outEesAdmListTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        outEesAdmListTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
        outEesAdmListTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
        outEesAdmListTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        outEesAdmListTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
        outEesAdmListTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
        outEesAdmListTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
        outEesAdmListTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        outEesAdmListTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        outEesAdmListTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        outEesAdmListTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        outEesAdmListTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        outEesAdmListTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        outEesAdmListTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        outEesAdmListTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        outEesAdmListTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
        outEesAdmListTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
        outEesAdmListTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
        outEesAdmListTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        outEesAdmListTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
        if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
          outEesAdmListTabObj.age_year = 0;
        else
        if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.age_year = 0;
        else
          outEesAdmListTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
        outEesAdmListTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
        if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
          outEesAdmListTabObj.age_day = 0;
        else
        if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.age_day = 0;
        else
          outEesAdmListTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
        outEesAdmListTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
        outEesAdmListTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
        outEesAdmListTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        outEesAdmListTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        outEesAdmListTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        outEesAdmListTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        outEesAdmListTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        outEesAdmListTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        outEesAdmListTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        outEesAdmListTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
        outEesAdmListTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        outEesAdmListTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        outEesAdmListTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        outEesAdmListTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        outEesAdmListTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        outEesAdmListTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        outEesAdmListTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
        outEesAdmListTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        outEesAdmListTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        outEesAdmListTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        outEesAdmListTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        outEesAdmListTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
        outEesAdmListTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        outEesAdmListTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        outEesAdmListTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        outEesAdmListTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        outEesAdmListTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        outEesAdmListTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        outEesAdmListTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        outEesAdmListTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
        outEesAdmListTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
          outEesAdmListTabObj.father_age = 0;
        else
        if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.father_age = 0;
        else
          outEesAdmListTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
        outEesAdmListTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
        outEesAdmListTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
        outEesAdmListTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
        outEesAdmListTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
          outEesAdmListTabObj.father_annual_income = 0;
        else
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.father_annual_income = 0;
        else
          outEesAdmListTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
        outEesAdmListTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
        outEesAdmListTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
        outEesAdmListTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
          outEesAdmListTabObj.mother_age = 0;
        else
        if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.mother_age = 0;
        else
          outEesAdmListTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
        outEesAdmListTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
        outEesAdmListTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
        outEesAdmListTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
        outEesAdmListTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
          outEesAdmListTabObj.mother_annual_income = 0;
        else
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.mother_annual_income = 0;
        else
          outEesAdmListTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
        outEesAdmListTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
        outEesAdmListTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
        outEesAdmListTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
        outEesAdmListTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
        outEesAdmListTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        outEesAdmListTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        outEesAdmListTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
        outEesAdmListTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
        outEesAdmListTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
        outEesAdmListTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
        outEesAdmListTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
        outEesAdmListTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
        outEesAdmListTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
        outEesAdmListTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
        outEesAdmListTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
          outEesAdmListTabObj.application_form_fee = 0;
        else
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.application_form_fee = 0;
        else
          outEesAdmListTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
        outEesAdmListTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
        outEesAdmListTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
        outEesAdmListTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
        outEesAdmListTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
        outEesAdmListTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
        outEesAdmListTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        outEesAdmListTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        outEesAdmListTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
          outEesAdmListTabObj.max_mark = 0;
        else
        if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.max_mark = 0;
        else
          outEesAdmListTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
          outEesAdmListTabObj.obtained_mark = 0;
        else
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.obtained_mark = 0;
        else
          outEesAdmListTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
        outEesAdmListTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
        outEesAdmListTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
        outEesAdmListTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
        outEesAdmListTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
        outEesAdmListTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
        outEesAdmListTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
        outEesAdmListTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
        outEesAdmListTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
        outEesAdmListTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
        outEesAdmListTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
        outEesAdmListTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
        outEesAdmListTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
        outEesAdmListTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
        outEesAdmListTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
        outEesAdmListTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
        outEesAdmListTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
        outEesAdmListTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
        outEesAdmListTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
        outEesAdmListTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
        outEesAdmListTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
        outEesAdmListTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
        outEesAdmListTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
          outEesAdmListTabObj.prev_mark_percent = 0;
        else
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.prev_mark_percent = 0;
        else
          outEesAdmListTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
        outEesAdmListTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
        outEesAdmListTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
        outEesAdmListTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
        outEesAdmListTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
        outEesAdmListTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
        outEesAdmListTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
        outEesAdmListTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
          outEesAdmListTabObj.cheque_amt = 0;
        else
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.cheque_amt = 0;
        else
          outEesAdmListTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
        outEesAdmListTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
        outEesAdmListTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
        outEesAdmListTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
        outEesAdmListTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
        outEesAdmListTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
        outEesAdmListTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
        outEesAdmListTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
        outEesAdmListTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
        outEesAdmListTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
        outEesAdmListTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
        outEesAdmListTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
        outEesAdmListTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
        outEesAdmListTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
        outEesAdmListTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
        outEesAdmListTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
        outEesAdmListTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
        outEesAdmListTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
        outEesAdmListTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
        outEesAdmListTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
        outEesAdmListTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
        outEesAdmListTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
        outEesAdmListTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
        outEesAdmListTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
        outEesAdmListTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
        outEesAdmListTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
        outEesAdmListTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
        outEesAdmListTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
        outEesAdmListTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
        outEesAdmListTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
        outEesAdmListTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
        outEesAdmListTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
        outEesAdmListTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
        if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
          outEesAdmListTabObj.seat_num = 0;
        else
        if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.seat_num = 0;
        else
          outEesAdmListTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
        outEesAdmListTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
        outEesAdmListTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        outEesAdmListTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
          outEesAdmListTabObj.adv_adm_fee = 0;
        else
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
          outEesAdmListTabObj.adv_adm_fee = 0;
        else
          outEesAdmListTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
        outEesAdmListTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
        outEesAdmListTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
        outEesAdmListTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        outEesAdmListTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
      }
    }
    return lReturnValue;
  }


  public int popEesAdmListReq2ObjM2F
               ( HttpServletRequest inRequest
               , int  inNumRec 
               , ArrayList  outEesAdmListTabObjArr
               )
  {
    int    lReturnValue = 0;
    for ( int lNumRec = 1; lNumRec < inNumRec+1; lNumRec++ )
    {
      EesAdmListTabObj lEesAdmListTabObj= new EesAdmListTabObj();

      String lSelectField      = "";
      String lSelectFieldValue = "";

      lSelectField = inRequest.getParameter("select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      lSelectField = inRequest.getParameter("ees_adm_list_select_r"+lNumRec);
      if ( lSelectField != null && lSelectField.equals("Y") )
         lSelectFieldValue = "Y";

      if ( lSelectFieldValue.equals("Y") )
      {
        String lTabRowidValue = inRequest.getParameter("tab_rowid_r"+lNumRec);
      lEesAdmListTabObj.tab_rowid = lTabRowidValue;

        lEesAdmListTabObj.org_id = inRequest.getParameter("org_id_r"+lNumRec);
        lEesAdmListTabObj.adm_req_id = inRequest.getParameter("adm_req_id_r"+lNumRec);
        lEesAdmListTabObj.application_form_num = inRequest.getParameter("application_form_num_r"+lNumRec);
        lEesAdmListTabObj.applicant_id = inRequest.getParameter("applicant_id_r"+lNumRec);
        lEesAdmListTabObj.student_photo_file = inRequest.getParameter("student_photo_file_r"+lNumRec);
        lEesAdmListTabObj.mother_photo_file = inRequest.getParameter("mother_photo_file_r"+lNumRec);
        lEesAdmListTabObj.father_photo_file = inRequest.getParameter("father_photo_file_r"+lNumRec);
        lEesAdmListTabObj.class_id = inRequest.getParameter("class_id_r"+lNumRec);
        lEesAdmListTabObj.class_num = inRequest.getParameter("class_num_r"+lNumRec);
        lEesAdmListTabObj.class_std = inRequest.getParameter("class_std_r"+lNumRec);
        lEesAdmListTabObj.class_section = inRequest.getParameter("class_section_r"+lNumRec);
        lEesAdmListTabObj.course_id = inRequest.getParameter("course_id_r"+lNumRec);
        lEesAdmListTabObj.course_term = inRequest.getParameter("course_term_r"+lNumRec);
        lEesAdmListTabObj.course_stream = inRequest.getParameter("course_stream_r"+lNumRec);
        lEesAdmListTabObj.name_initials = inRequest.getParameter("name_initials_r"+lNumRec);
        lEesAdmListTabObj.student_f_name = inRequest.getParameter("student_f_name_r"+lNumRec);
        lEesAdmListTabObj.student_m_name = inRequest.getParameter("student_m_name_r"+lNumRec);
        lEesAdmListTabObj.student_l_name = inRequest.getParameter("student_l_name_r"+lNumRec);
        lEesAdmListTabObj.dob = inRequest.getParameter("dob_r"+lNumRec);
        lEesAdmListTabObj.age_on_date = inRequest.getParameter("age_on_date_r"+lNumRec);
        if ( inRequest.getParameter("age_year_r"+lNumRec) == null )
          lEesAdmListTabObj.age_year = 0;
        else
        if ( inRequest.getParameter("age_year_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.age_year = 0;
        else
          lEesAdmListTabObj.age_year = Byte.parseByte( inRequest.getParameter("age_year_r"+lNumRec));
        lEesAdmListTabObj.age_month = inRequest.getParameter("age_month_r"+lNumRec);
        if ( inRequest.getParameter("age_day_r"+lNumRec) == null )
          lEesAdmListTabObj.age_day = 0;
        else
        if ( inRequest.getParameter("age_day_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.age_day = 0;
        else
          lEesAdmListTabObj.age_day = Byte.parseByte( inRequest.getParameter("age_day_r"+lNumRec));
        lEesAdmListTabObj.s_nationality = inRequest.getParameter("s_nationality_r"+lNumRec);
        lEesAdmListTabObj.religion = inRequest.getParameter("religion_r"+lNumRec);
        lEesAdmListTabObj.student_ctg = inRequest.getParameter("student_ctg_r"+lNumRec);
        lEesAdmListTabObj.gender_flag = inRequest.getParameter("gender_flag_r"+lNumRec);
        lEesAdmListTabObj.p_address_1 = inRequest.getParameter("p_address_1_r"+lNumRec);
        lEesAdmListTabObj.p_address_2 = inRequest.getParameter("p_address_2_r"+lNumRec);
        lEesAdmListTabObj.p_country = inRequest.getParameter("p_country_r"+lNumRec);
        lEesAdmListTabObj.p_state = inRequest.getParameter("p_state_r"+lNumRec);
        lEesAdmListTabObj.p_city = inRequest.getParameter("p_city_r"+lNumRec);
        lEesAdmListTabObj.p_district = inRequest.getParameter("p_district_r"+lNumRec);
        lEesAdmListTabObj.p_zip = inRequest.getParameter("p_zip_r"+lNumRec);
        lEesAdmListTabObj.m_address_1 = inRequest.getParameter("m_address_1_r"+lNumRec);
        lEesAdmListTabObj.m_address_2 = inRequest.getParameter("m_address_2_r"+lNumRec);
        lEesAdmListTabObj.m_country = inRequest.getParameter("m_country_r"+lNumRec);
        lEesAdmListTabObj.m_state = inRequest.getParameter("m_state_r"+lNumRec);
        lEesAdmListTabObj.m_city = inRequest.getParameter("m_city_r"+lNumRec);
        lEesAdmListTabObj.m_district = inRequest.getParameter("m_district_r"+lNumRec);
        lEesAdmListTabObj.m_zip = inRequest.getParameter("m_zip_r"+lNumRec);
        lEesAdmListTabObj.phone_list = inRequest.getParameter("phone_list_r"+lNumRec);
        lEesAdmListTabObj.email_list = inRequest.getParameter("email_list_r"+lNumRec);
        lEesAdmListTabObj.fax_list = inRequest.getParameter("fax_list_r"+lNumRec);
        lEesAdmListTabObj.prev_org_name = inRequest.getParameter("prev_org_name_r"+lNumRec);
        lEesAdmListTabObj.prev_class_id = inRequest.getParameter("prev_class_id_r"+lNumRec);
        lEesAdmListTabObj.prev_class_num = inRequest.getParameter("prev_class_num_r"+lNumRec);
        lEesAdmListTabObj.prev_class_std = inRequest.getParameter("prev_class_std_r"+lNumRec);
        lEesAdmListTabObj.prev_class_section = inRequest.getParameter("prev_class_section_r"+lNumRec);
        lEesAdmListTabObj.prev_course_id = inRequest.getParameter("prev_course_id_r"+lNumRec);
        lEesAdmListTabObj.prev_course_term = inRequest.getParameter("prev_course_term_r"+lNumRec);
        lEesAdmListTabObj.prev_course_stream = inRequest.getParameter("prev_course_stream_r"+lNumRec);
        lEesAdmListTabObj.reason_for_leaving = inRequest.getParameter("reason_for_leaving_r"+lNumRec);
        lEesAdmListTabObj.father_name = inRequest.getParameter("father_name_r"+lNumRec);
        if ( inRequest.getParameter("father_age_r"+lNumRec) == null )
          lEesAdmListTabObj.father_age = 0;
        else
        if ( inRequest.getParameter("father_age_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.father_age = 0;
        else
          lEesAdmListTabObj.father_age = Byte.parseByte( inRequest.getParameter("father_age_r"+lNumRec));
        lEesAdmListTabObj.f_nationality = inRequest.getParameter("f_nationality_r"+lNumRec);
        lEesAdmListTabObj.father_occ_type = inRequest.getParameter("father_occ_type_r"+lNumRec);
        lEesAdmListTabObj.father_employer = inRequest.getParameter("father_employer_r"+lNumRec);
        lEesAdmListTabObj.father_designation = inRequest.getParameter("father_designation_r"+lNumRec);
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec) == null )
          lEesAdmListTabObj.father_annual_income = 0;
        else
        if ( inRequest.getParameter("father_annual_income_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.father_annual_income = 0;
        else
            lEesAdmListTabObj.father_annual_income = Double.parseDouble( inRequest.getParameter("father_annual_income_r"+lNumRec));
        lEesAdmListTabObj.f_off_address_1 = inRequest.getParameter("f_off_address_1_r"+lNumRec);
        lEesAdmListTabObj.f_phone_list = inRequest.getParameter("f_phone_list_r"+lNumRec);
        lEesAdmListTabObj.mother_name = inRequest.getParameter("mother_name_r"+lNumRec);
        if ( inRequest.getParameter("mother_age_r"+lNumRec) == null )
          lEesAdmListTabObj.mother_age = 0;
        else
        if ( inRequest.getParameter("mother_age_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.mother_age = 0;
        else
          lEesAdmListTabObj.mother_age = Byte.parseByte( inRequest.getParameter("mother_age_r"+lNumRec));
        lEesAdmListTabObj.m_nationality = inRequest.getParameter("m_nationality_r"+lNumRec);
        lEesAdmListTabObj.mother_occ_type = inRequest.getParameter("mother_occ_type_r"+lNumRec);
        lEesAdmListTabObj.mother_employer = inRequest.getParameter("mother_employer_r"+lNumRec);
        lEesAdmListTabObj.mother_designation = inRequest.getParameter("mother_designation_r"+lNumRec);
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec) == null )
          lEesAdmListTabObj.mother_annual_income = 0;
        else
        if ( inRequest.getParameter("mother_annual_income_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.mother_annual_income = 0;
        else
            lEesAdmListTabObj.mother_annual_income = Double.parseDouble( inRequest.getParameter("mother_annual_income_r"+lNumRec));
        lEesAdmListTabObj.m_off_address_1 = inRequest.getParameter("m_off_address_1_r"+lNumRec);
        lEesAdmListTabObj.m_phone_list = inRequest.getParameter("m_phone_list_r"+lNumRec);
        lEesAdmListTabObj.divorced_flag = inRequest.getParameter("divorced_flag_r"+lNumRec);
        lEesAdmListTabObj.child_with = inRequest.getParameter("child_with_r"+lNumRec);
        lEesAdmListTabObj.roll_num = inRequest.getParameter("roll_num_r"+lNumRec);
        lEesAdmListTabObj.academic_session = inRequest.getParameter("academic_session_r"+lNumRec);
        lEesAdmListTabObj.adm_req_sts = inRequest.getParameter("adm_req_sts_r"+lNumRec);
        lEesAdmListTabObj.adm_req_sts_date = inRequest.getParameter("adm_req_sts_date_r"+lNumRec);
        lEesAdmListTabObj.student_id = inRequest.getParameter("student_id_r"+lNumRec);
        lEesAdmListTabObj.scholor_num = inRequest.getParameter("scholor_num_r"+lNumRec);
        lEesAdmListTabObj.form_recv_date = inRequest.getParameter("form_recv_date_r"+lNumRec);
        lEesAdmListTabObj.form_recv_time = inRequest.getParameter("form_recv_time_r"+lNumRec);
        lEesAdmListTabObj.prospectus_sale_date = inRequest.getParameter("prospectus_sale_date_r"+lNumRec);
        lEesAdmListTabObj.prospectus_sale_time = inRequest.getParameter("prospectus_sale_time_r"+lNumRec);
        lEesAdmListTabObj.prospectus_sold_by = inRequest.getParameter("prospectus_sold_by_r"+lNumRec);
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec) == null )
          lEesAdmListTabObj.application_form_fee = 0;
        else
        if ( inRequest.getParameter("application_form_fee_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.application_form_fee = 0;
        else
            lEesAdmListTabObj.application_form_fee = Double.parseDouble( inRequest.getParameter("application_form_fee_r"+lNumRec));
        lEesAdmListTabObj.adm_academic_session = inRequest.getParameter("adm_academic_session_r"+lNumRec);
        lEesAdmListTabObj.entrance_exam_date = inRequest.getParameter("entrance_exam_date_r"+lNumRec);
        lEesAdmListTabObj.entrance_exam_time_start = inRequest.getParameter("entrance_exam_time_start_r"+lNumRec);
        lEesAdmListTabObj.entrance_exam_time_end = inRequest.getParameter("entrance_exam_time_end_r"+lNumRec);
        lEesAdmListTabObj.exam_present_status = inRequest.getParameter("exam_present_status_r"+lNumRec);
        lEesAdmListTabObj.building_id = inRequest.getParameter("building_id_r"+lNumRec);
        lEesAdmListTabObj.floor_num = inRequest.getParameter("floor_num_r"+lNumRec);
        lEesAdmListTabObj.room_num = inRequest.getParameter("room_num_r"+lNumRec);
        if ( inRequest.getParameter("max_mark_r"+lNumRec) == null )
          lEesAdmListTabObj.max_mark = 0;
        else
        if ( inRequest.getParameter("max_mark_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.max_mark = 0;
        else
          lEesAdmListTabObj.max_mark = Short.parseShort( inRequest.getParameter("max_mark_r"+lNumRec));
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec) == null )
          lEesAdmListTabObj.obtained_mark = 0;
        else
        if ( inRequest.getParameter("obtained_mark_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.obtained_mark = 0;
        else
          lEesAdmListTabObj.obtained_mark = Short.parseShort( inRequest.getParameter("obtained_mark_r"+lNumRec));
        lEesAdmListTabObj.grade = inRequest.getParameter("grade_r"+lNumRec);
        lEesAdmListTabObj.fee_sch_date = inRequest.getParameter("fee_sch_date_r"+lNumRec);
        lEesAdmListTabObj.fee_deposit_date = inRequest.getParameter("fee_deposit_date_r"+lNumRec);
        lEesAdmListTabObj.online_flag = inRequest.getParameter("online_flag_r"+lNumRec);
        lEesAdmListTabObj.admission_mode = inRequest.getParameter("admission_mode_r"+lNumRec);
        lEesAdmListTabObj.course_stream_1 = inRequest.getParameter("course_stream_1_r"+lNumRec);
        lEesAdmListTabObj.course_stream_2 = inRequest.getParameter("course_stream_2_r"+lNumRec);
        lEesAdmListTabObj.course_stream_3 = inRequest.getParameter("course_stream_3_r"+lNumRec);
        lEesAdmListTabObj.course_stream_4 = inRequest.getParameter("course_stream_4_r"+lNumRec);
        lEesAdmListTabObj.apr_course_stream = inRequest.getParameter("apr_course_stream_r"+lNumRec);
        lEesAdmListTabObj.unv_1 = inRequest.getParameter("unv_1_r"+lNumRec);
        lEesAdmListTabObj.unv_rn_1 = inRequest.getParameter("unv_rn_1_r"+lNumRec);
        lEesAdmListTabObj.gen_rank_1 = inRequest.getParameter("gen_rank_1_r"+lNumRec);
        lEesAdmListTabObj.ctg_rank_1 = inRequest.getParameter("ctg_rank_1_r"+lNumRec);
        lEesAdmListTabObj.stt_rank_1 = inRequest.getParameter("stt_rank_1_r"+lNumRec);
        lEesAdmListTabObj.yoa_1 = inRequest.getParameter("yoa_1_r"+lNumRec);
        lEesAdmListTabObj.unv_2 = inRequest.getParameter("unv_2_r"+lNumRec);
        lEesAdmListTabObj.unv_rn_2 = inRequest.getParameter("unv_rn_2_r"+lNumRec);
        lEesAdmListTabObj.gen_rank_2 = inRequest.getParameter("gen_rank_2_r"+lNumRec);
        lEesAdmListTabObj.ctg_rank_2 = inRequest.getParameter("ctg_rank_2_r"+lNumRec);
        lEesAdmListTabObj.stt_rank_2 = inRequest.getParameter("stt_rank_2_r"+lNumRec);
        lEesAdmListTabObj.yoa_2 = inRequest.getParameter("yoa_2_r"+lNumRec);
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec) == null )
          lEesAdmListTabObj.prev_mark_percent = 0;
        else
        if ( inRequest.getParameter("prev_mark_percent_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.prev_mark_percent = 0;
        else
            lEesAdmListTabObj.prev_mark_percent = Float.parseFloat( inRequest.getParameter("prev_mark_percent_r"+lNumRec));
        lEesAdmListTabObj.domecile_ind = inRequest.getParameter("domecile_ind_r"+lNumRec);
        lEesAdmListTabObj.org_transport_req_ind = inRequest.getParameter("org_transport_req_ind_r"+lNumRec);
        lEesAdmListTabObj.org_hostel_req_ind = inRequest.getParameter("org_hostel_req_ind_r"+lNumRec);
        lEesAdmListTabObj.cheque_num = inRequest.getParameter("cheque_num_r"+lNumRec);
        lEesAdmListTabObj.cheque_date = inRequest.getParameter("cheque_date_r"+lNumRec);
        lEesAdmListTabObj.bank_code = inRequest.getParameter("bank_code_r"+lNumRec);
        lEesAdmListTabObj.bank_name = inRequest.getParameter("bank_name_r"+lNumRec);
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec) == null )
          lEesAdmListTabObj.cheque_amt = 0;
        else
        if ( inRequest.getParameter("cheque_amt_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.cheque_amt = 0;
        else
            lEesAdmListTabObj.cheque_amt = Double.parseDouble( inRequest.getParameter("cheque_amt_r"+lNumRec));
        lEesAdmListTabObj.lg_0_name = inRequest.getParameter("lg_0_name_r"+lNumRec);
        lEesAdmListTabObj.lg_0_rel_type = inRequest.getParameter("lg_0_rel_type_r"+lNumRec);
        lEesAdmListTabObj.lg_0_address = inRequest.getParameter("lg_0_address_r"+lNumRec);
        lEesAdmListTabObj.lg_0_phone = inRequest.getParameter("lg_0_phone_r"+lNumRec);
        lEesAdmListTabObj.lg_1_name = inRequest.getParameter("lg_1_name_r"+lNumRec);
        lEesAdmListTabObj.lg_1_rel_type = inRequest.getParameter("lg_1_rel_type_r"+lNumRec);
        lEesAdmListTabObj.lg_1_address = inRequest.getParameter("lg_1_address_r"+lNumRec);
        lEesAdmListTabObj.lg_1_phone = inRequest.getParameter("lg_1_phone_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_1 = inRequest.getParameter("st_cap_attr_1_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_2 = inRequest.getParameter("st_cap_attr_2_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_3 = inRequest.getParameter("st_cap_attr_3_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_4 = inRequest.getParameter("st_cap_attr_4_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_5 = inRequest.getParameter("st_cap_attr_5_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_6 = inRequest.getParameter("st_cap_attr_6_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_7 = inRequest.getParameter("st_cap_attr_7_r"+lNumRec);
        lEesAdmListTabObj.st_cap_attr_8 = inRequest.getParameter("st_cap_attr_8_r"+lNumRec);
        lEesAdmListTabObj.allergy = inRequest.getParameter("allergy_r"+lNumRec);
        lEesAdmListTabObj.physical_disability = inRequest.getParameter("physical_disability_r"+lNumRec);
        lEesAdmListTabObj.health_problem = inRequest.getParameter("health_problem_r"+lNumRec);
        lEesAdmListTabObj.health_problem_1 = inRequest.getParameter("health_problem_1_r"+lNumRec);
        lEesAdmListTabObj.health_problem_2 = inRequest.getParameter("health_problem_2_r"+lNumRec);
        lEesAdmListTabObj.health_problem_3 = inRequest.getParameter("health_problem_3_r"+lNumRec);
        lEesAdmListTabObj.health_problem_4 = inRequest.getParameter("health_problem_4_r"+lNumRec);
        lEesAdmListTabObj.health_problem_5 = inRequest.getParameter("health_problem_5_r"+lNumRec);
        lEesAdmListTabObj.health_problem_6 = inRequest.getParameter("health_problem_6_r"+lNumRec);
        lEesAdmListTabObj.health_problem_7 = inRequest.getParameter("health_problem_7_r"+lNumRec);
        lEesAdmListTabObj.health_problem_8 = inRequest.getParameter("health_problem_8_r"+lNumRec);
        lEesAdmListTabObj.health_problem_9 = inRequest.getParameter("health_problem_9_r"+lNumRec);
        lEesAdmListTabObj.health_problem_10 = inRequest.getParameter("health_problem_10_r"+lNumRec);
        lEesAdmListTabObj.health_problem_11 = inRequest.getParameter("health_problem_11_r"+lNumRec);
        lEesAdmListTabObj.health_problem_12 = inRequest.getParameter("health_problem_12_r"+lNumRec);
        lEesAdmListTabObj.enclosure_1 = inRequest.getParameter("enclosure_1_r"+lNumRec);
        lEesAdmListTabObj.enclosure_2 = inRequest.getParameter("enclosure_2_r"+lNumRec);
        lEesAdmListTabObj.enclosure_3 = inRequest.getParameter("enclosure_3_r"+lNumRec);
        lEesAdmListTabObj.enclosure_4 = inRequest.getParameter("enclosure_4_r"+lNumRec);
        lEesAdmListTabObj.enclosure_5 = inRequest.getParameter("enclosure_5_r"+lNumRec);
        lEesAdmListTabObj.enclosure_6 = inRequest.getParameter("enclosure_6_r"+lNumRec);
        lEesAdmListTabObj.enclosure_7 = inRequest.getParameter("enclosure_7_r"+lNumRec);
        lEesAdmListTabObj.enclosure_8 = inRequest.getParameter("enclosure_8_r"+lNumRec);
        if ( inRequest.getParameter("seat_num_r"+lNumRec) == null )
          lEesAdmListTabObj.seat_num = 0;
        else
        if ( inRequest.getParameter("seat_num_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.seat_num = 0;
        else
          lEesAdmListTabObj.seat_num = Short.parseShort( inRequest.getParameter("seat_num_r"+lNumRec));
        lEesAdmListTabObj.reason_for_join = inRequest.getParameter("reason_for_join_r"+lNumRec);
        lEesAdmListTabObj.remark = inRequest.getParameter("remark_r"+lNumRec);
        lEesAdmListTabObj.place_of_birth = inRequest.getParameter("place_of_birth_r"+lNumRec);
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec) == null )
          lEesAdmListTabObj.adv_adm_fee = 0;
        else
        if ( inRequest.getParameter("adv_adm_fee_r"+lNumRec).trim().length() == 0 )
          lEesAdmListTabObj.adv_adm_fee = 0;
        else
            lEesAdmListTabObj.adv_adm_fee = Double.parseDouble( inRequest.getParameter("adv_adm_fee_r"+lNumRec));
        lEesAdmListTabObj.payment_mode = inRequest.getParameter("payment_mode_r"+lNumRec);
        lEesAdmListTabObj.target_ptl_user_id = inRequest.getParameter("target_ptl_user_id_r"+lNumRec);
        lEesAdmListTabObj.adm_req_id_req = inRequest.getParameter("adm_req_id_req_r"+lNumRec);
        lEesAdmListTabObj.adm_req_id_list = inRequest.getParameter("adm_req_id_list_r"+lNumRec);
        outEesAdmListTabObjArr.add( lEesAdmListTabObj);
      }
    }
    return lReturnValue;
  }





  public int updEesAdmListRecByRowid
               ( String inRowId
               , EesAdmListTabObj  inEesAdmListTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAdmListRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmListRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmListTabObj.dob != null && inEesAdmListTabObj.dob.length() > 0 ) 
            inEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.age_on_date != null && inEesAdmListTabObj.age_on_date.length() > 0 ) 
            inEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.adm_req_sts_date != null && inEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.form_recv_date != null && inEesAdmListTabObj.form_recv_date.length() > 0 ) 
            inEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.prospectus_sale_date != null && inEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.entrance_exam_date != null && inEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_sch_date != null && inEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_deposit_date != null && inEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.cheque_date != null && inEesAdmListTabObj.cheque_date.length() > 0 ) 
            inEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.cheque_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_LIST ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( inEesAdmListTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAdmListTabObj.org_id+"', ";
      if ( inEesAdmListTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = "+"'"+inEesAdmListTabObj.adm_req_id+"', ";
      if ( inEesAdmListTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = "+"'"+inEesAdmListTabObj.application_form_num+"', ";
      if ( inEesAdmListTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAdmListTabObj.applicant_id+"', ";
      if ( inEesAdmListTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = "+"'"+inEesAdmListTabObj.student_photo_file+"', ";
      if ( inEesAdmListTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = "+"'"+inEesAdmListTabObj.mother_photo_file+"', ";
      if ( inEesAdmListTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = "+"'"+inEesAdmListTabObj.father_photo_file+"', ";
      if ( inEesAdmListTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAdmListTabObj.class_id+"', ";
      if ( inEesAdmListTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAdmListTabObj.class_num+"', ";
      if ( inEesAdmListTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAdmListTabObj.class_std+"', ";
      if ( inEesAdmListTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAdmListTabObj.class_section+"', ";
      if ( inEesAdmListTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAdmListTabObj.course_id+"', ";
      if ( inEesAdmListTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAdmListTabObj.course_term+"', ";
      if ( inEesAdmListTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAdmListTabObj.course_stream+"', ";
      if ( inEesAdmListTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inEesAdmListTabObj.name_initials+"', ";
      if ( inEesAdmListTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = "+"'"+inEesAdmListTabObj.student_f_name+"', ";
      if ( inEesAdmListTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = "+"'"+inEesAdmListTabObj.student_m_name+"', ";
      if ( inEesAdmListTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = "+"'"+inEesAdmListTabObj.student_l_name+"', ";
      if ( inEesAdmListTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAdmListTabObj.dob+"', ";
      if ( inEesAdmListTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = "+"'"+inEesAdmListTabObj.age_on_date+"', ";
             lSqlStmt = lSqlStmt + "age_year = "+inEesAdmListTabObj.age_year+", ";
      if ( inEesAdmListTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = "+"'"+inEesAdmListTabObj.age_month+"', ";
             lSqlStmt = lSqlStmt + "age_day = "+inEesAdmListTabObj.age_day+", ";
      if ( inEesAdmListTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = "+"'"+inEesAdmListTabObj.s_nationality+"', ";
      if ( inEesAdmListTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = "+"'"+inEesAdmListTabObj.religion+"', ";
      if ( inEesAdmListTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAdmListTabObj.student_ctg+"', ";
      if ( inEesAdmListTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAdmListTabObj.gender_flag+"', ";
      if ( inEesAdmListTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inEesAdmListTabObj.p_address_1+"', ";
      if ( inEesAdmListTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inEesAdmListTabObj.p_address_2+"', ";
      if ( inEesAdmListTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inEesAdmListTabObj.p_country+"', ";
      if ( inEesAdmListTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inEesAdmListTabObj.p_state+"', ";
      if ( inEesAdmListTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inEesAdmListTabObj.p_city+"', ";
      if ( inEesAdmListTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = "+"'"+inEesAdmListTabObj.p_district+"', ";
      if ( inEesAdmListTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inEesAdmListTabObj.p_zip+"', ";
      if ( inEesAdmListTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inEesAdmListTabObj.m_address_1+"', ";
      if ( inEesAdmListTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inEesAdmListTabObj.m_address_2+"', ";
      if ( inEesAdmListTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inEesAdmListTabObj.m_country+"', ";
      if ( inEesAdmListTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inEesAdmListTabObj.m_state+"', ";
      if ( inEesAdmListTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inEesAdmListTabObj.m_city+"', ";
      if ( inEesAdmListTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = "+"'"+inEesAdmListTabObj.m_district+"', ";
      if ( inEesAdmListTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inEesAdmListTabObj.m_zip+"', ";
      if ( inEesAdmListTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAdmListTabObj.phone_list+"', ";
      if ( inEesAdmListTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAdmListTabObj.email_list+"', ";
      if ( inEesAdmListTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAdmListTabObj.fax_list+"', ";
      if ( inEesAdmListTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = "+"'"+inEesAdmListTabObj.prev_org_name+"', ";
      if ( inEesAdmListTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAdmListTabObj.prev_class_id+"', ";
      if ( inEesAdmListTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAdmListTabObj.prev_class_num+"', ";
      if ( inEesAdmListTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAdmListTabObj.prev_class_std+"', ";
      if ( inEesAdmListTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAdmListTabObj.prev_class_section+"', ";
      if ( inEesAdmListTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAdmListTabObj.prev_course_id+"', ";
      if ( inEesAdmListTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAdmListTabObj.prev_course_term+"', ";
      if ( inEesAdmListTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAdmListTabObj.prev_course_stream+"', ";
      if ( inEesAdmListTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = "+"'"+inEesAdmListTabObj.reason_for_leaving+"', ";
      if ( inEesAdmListTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAdmListTabObj.father_name+"', ";
             lSqlStmt = lSqlStmt + "father_age = "+inEesAdmListTabObj.father_age+", ";
      if ( inEesAdmListTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = "+"'"+inEesAdmListTabObj.f_nationality+"', ";
      if ( inEesAdmListTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = "+"'"+inEesAdmListTabObj.father_occ_type+"', ";
      if ( inEesAdmListTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = "+"'"+inEesAdmListTabObj.father_employer+"', ";
      if ( inEesAdmListTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = "+"'"+inEesAdmListTabObj.father_designation+"', ";
             lSqlStmt = lSqlStmt + "father_annual_income = "+inEesAdmListTabObj.father_annual_income+", ";
      if ( inEesAdmListTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = "+"'"+inEesAdmListTabObj.f_off_address_1+"', ";
      if ( inEesAdmListTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = "+"'"+inEesAdmListTabObj.f_phone_list+"', ";
      if ( inEesAdmListTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAdmListTabObj.mother_name+"', ";
             lSqlStmt = lSqlStmt + "mother_age = "+inEesAdmListTabObj.mother_age+", ";
      if ( inEesAdmListTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = "+"'"+inEesAdmListTabObj.m_nationality+"', ";
      if ( inEesAdmListTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = "+"'"+inEesAdmListTabObj.mother_occ_type+"', ";
      if ( inEesAdmListTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = "+"'"+inEesAdmListTabObj.mother_employer+"', ";
      if ( inEesAdmListTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = "+"'"+inEesAdmListTabObj.mother_designation+"', ";
             lSqlStmt = lSqlStmt + "mother_annual_income = "+inEesAdmListTabObj.mother_annual_income+", ";
      if ( inEesAdmListTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = "+"'"+inEesAdmListTabObj.m_off_address_1+"', ";
      if ( inEesAdmListTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = "+"'"+inEesAdmListTabObj.m_phone_list+"', ";
      if ( inEesAdmListTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = "+"'"+inEesAdmListTabObj.divorced_flag+"', ";
      if ( inEesAdmListTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = "+"'"+inEesAdmListTabObj.child_with+"', ";
      if ( inEesAdmListTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAdmListTabObj.roll_num+"', ";
      if ( inEesAdmListTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesAdmListTabObj.academic_session+"', ";
      if ( inEesAdmListTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = "+"'"+inEesAdmListTabObj.adm_req_sts+"', ";
      if ( inEesAdmListTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = "+"'"+inEesAdmListTabObj.adm_req_sts_date+"', ";
      if ( inEesAdmListTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = "+"'"+inEesAdmListTabObj.student_id+"', ";
      if ( inEesAdmListTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = "+"'"+inEesAdmListTabObj.scholor_num+"', ";
      if ( inEesAdmListTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = "+"'"+inEesAdmListTabObj.form_recv_date+"', ";
      if ( inEesAdmListTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = "+"'"+inEesAdmListTabObj.form_recv_time+"', ";
      if ( inEesAdmListTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = "+"'"+inEesAdmListTabObj.prospectus_sale_date+"', ";
      if ( inEesAdmListTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = "+"'"+inEesAdmListTabObj.prospectus_sale_time+"', ";
      if ( inEesAdmListTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = "+"'"+inEesAdmListTabObj.prospectus_sold_by+"', ";
             lSqlStmt = lSqlStmt + "application_form_fee = "+inEesAdmListTabObj.application_form_fee+", ";
      if ( inEesAdmListTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = "+"'"+inEesAdmListTabObj.adm_academic_session+"', ";
      if ( inEesAdmListTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = "+"'"+inEesAdmListTabObj.entrance_exam_date+"', ";
      if ( inEesAdmListTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = "+"'"+inEesAdmListTabObj.entrance_exam_time_start+"', ";
      if ( inEesAdmListTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = "+"'"+inEesAdmListTabObj.entrance_exam_time_end+"', ";
      if ( inEesAdmListTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = "+"'"+inEesAdmListTabObj.exam_present_status+"', ";
      if ( inEesAdmListTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inEesAdmListTabObj.building_id+"', ";
      if ( inEesAdmListTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inEesAdmListTabObj.floor_num+"', ";
      if ( inEesAdmListTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inEesAdmListTabObj.room_num+"', ";
             lSqlStmt = lSqlStmt + "max_mark = "+inEesAdmListTabObj.max_mark+", ";
             lSqlStmt = lSqlStmt + "obtained_mark = "+inEesAdmListTabObj.obtained_mark+", ";
      if ( inEesAdmListTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = "+"'"+inEesAdmListTabObj.grade+"', ";
      if ( inEesAdmListTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = "+"'"+inEesAdmListTabObj.fee_sch_date+"', ";
      if ( inEesAdmListTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = "+"'"+inEesAdmListTabObj.fee_deposit_date+"', ";
      if ( inEesAdmListTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = "+"'"+inEesAdmListTabObj.online_flag+"', ";
      if ( inEesAdmListTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = "+"'"+inEesAdmListTabObj.admission_mode+"', ";
      if ( inEesAdmListTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = "+"'"+inEesAdmListTabObj.course_stream_1+"', ";
      if ( inEesAdmListTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = "+"'"+inEesAdmListTabObj.course_stream_2+"', ";
      if ( inEesAdmListTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = "+"'"+inEesAdmListTabObj.course_stream_3+"', ";
      if ( inEesAdmListTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = "+"'"+inEesAdmListTabObj.course_stream_4+"', ";
      if ( inEesAdmListTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = "+"'"+inEesAdmListTabObj.apr_course_stream+"', ";
      if ( inEesAdmListTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = "+"'"+inEesAdmListTabObj.unv_1+"', ";
      if ( inEesAdmListTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = "+"'"+inEesAdmListTabObj.unv_rn_1+"', ";
      if ( inEesAdmListTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = "+"'"+inEesAdmListTabObj.gen_rank_1+"', ";
      if ( inEesAdmListTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = "+"'"+inEesAdmListTabObj.ctg_rank_1+"', ";
      if ( inEesAdmListTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = "+"'"+inEesAdmListTabObj.stt_rank_1+"', ";
      if ( inEesAdmListTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = "+"'"+inEesAdmListTabObj.yoa_1+"', ";
      if ( inEesAdmListTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = "+"'"+inEesAdmListTabObj.unv_2+"', ";
      if ( inEesAdmListTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = "+"'"+inEesAdmListTabObj.unv_rn_2+"', ";
      if ( inEesAdmListTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = "+"'"+inEesAdmListTabObj.gen_rank_2+"', ";
      if ( inEesAdmListTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = "+"'"+inEesAdmListTabObj.ctg_rank_2+"', ";
      if ( inEesAdmListTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = "+"'"+inEesAdmListTabObj.stt_rank_2+"', ";
      if ( inEesAdmListTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = "+"'"+inEesAdmListTabObj.yoa_2+"', ";
             lSqlStmt = lSqlStmt + "prev_mark_percent = "+inEesAdmListTabObj.prev_mark_percent+", ";
      if ( inEesAdmListTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = "+"'"+inEesAdmListTabObj.domecile_ind+"', ";
      if ( inEesAdmListTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = "+"'"+inEesAdmListTabObj.org_transport_req_ind+"', ";
      if ( inEesAdmListTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = "+"'"+inEesAdmListTabObj.org_hostel_req_ind+"', ";
      if ( inEesAdmListTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = "+"'"+inEesAdmListTabObj.cheque_num+"', ";
      if ( inEesAdmListTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = "+"'"+inEesAdmListTabObj.cheque_date+"', ";
      if ( inEesAdmListTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = "+"'"+inEesAdmListTabObj.bank_code+"', ";
      if ( inEesAdmListTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = "+"'"+inEesAdmListTabObj.bank_name+"', ";
             lSqlStmt = lSqlStmt + "cheque_amt = "+inEesAdmListTabObj.cheque_amt+", ";
      if ( inEesAdmListTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = "+"'"+inEesAdmListTabObj.lg_0_name+"', ";
      if ( inEesAdmListTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = "+"'"+inEesAdmListTabObj.lg_0_rel_type+"', ";
      if ( inEesAdmListTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = "+"'"+inEesAdmListTabObj.lg_0_address+"', ";
      if ( inEesAdmListTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = "+"'"+inEesAdmListTabObj.lg_0_phone+"', ";
      if ( inEesAdmListTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = "+"'"+inEesAdmListTabObj.lg_1_name+"', ";
      if ( inEesAdmListTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = "+"'"+inEesAdmListTabObj.lg_1_rel_type+"', ";
      if ( inEesAdmListTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = "+"'"+inEesAdmListTabObj.lg_1_address+"', ";
      if ( inEesAdmListTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = "+"'"+inEesAdmListTabObj.lg_1_phone+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = "+"'"+inEesAdmListTabObj.st_cap_attr_1+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = "+"'"+inEesAdmListTabObj.st_cap_attr_2+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = "+"'"+inEesAdmListTabObj.st_cap_attr_3+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = "+"'"+inEesAdmListTabObj.st_cap_attr_4+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = "+"'"+inEesAdmListTabObj.st_cap_attr_5+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = "+"'"+inEesAdmListTabObj.st_cap_attr_6+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = "+"'"+inEesAdmListTabObj.st_cap_attr_7+"', ";
      if ( inEesAdmListTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = "+"'"+inEesAdmListTabObj.st_cap_attr_8+"', ";
      if ( inEesAdmListTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = "+"'"+inEesAdmListTabObj.allergy+"', ";
      if ( inEesAdmListTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = "+"'"+inEesAdmListTabObj.physical_disability+"', ";
      if ( inEesAdmListTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = "+"'"+inEesAdmListTabObj.health_problem+"', ";
      if ( inEesAdmListTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = "+"'"+inEesAdmListTabObj.health_problem_1+"', ";
      if ( inEesAdmListTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = "+"'"+inEesAdmListTabObj.health_problem_2+"', ";
      if ( inEesAdmListTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = "+"'"+inEesAdmListTabObj.health_problem_3+"', ";
      if ( inEesAdmListTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = "+"'"+inEesAdmListTabObj.health_problem_4+"', ";
      if ( inEesAdmListTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = "+"'"+inEesAdmListTabObj.health_problem_5+"', ";
      if ( inEesAdmListTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = "+"'"+inEesAdmListTabObj.health_problem_6+"', ";
      if ( inEesAdmListTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = "+"'"+inEesAdmListTabObj.health_problem_7+"', ";
      if ( inEesAdmListTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = "+"'"+inEesAdmListTabObj.health_problem_8+"', ";
      if ( inEesAdmListTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = "+"'"+inEesAdmListTabObj.health_problem_9+"', ";
      if ( inEesAdmListTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = "+"'"+inEesAdmListTabObj.health_problem_10+"', ";
      if ( inEesAdmListTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = "+"'"+inEesAdmListTabObj.health_problem_11+"', ";
      if ( inEesAdmListTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = "+"'"+inEesAdmListTabObj.health_problem_12+"', ";
      if ( inEesAdmListTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = "+"'"+inEesAdmListTabObj.enclosure_1+"', ";
      if ( inEesAdmListTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = "+"'"+inEesAdmListTabObj.enclosure_2+"', ";
      if ( inEesAdmListTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = "+"'"+inEesAdmListTabObj.enclosure_3+"', ";
      if ( inEesAdmListTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = "+"'"+inEesAdmListTabObj.enclosure_4+"', ";
      if ( inEesAdmListTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = "+"'"+inEesAdmListTabObj.enclosure_5+"', ";
      if ( inEesAdmListTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = "+"'"+inEesAdmListTabObj.enclosure_6+"', ";
      if ( inEesAdmListTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = "+"'"+inEesAdmListTabObj.enclosure_7+"', ";
      if ( inEesAdmListTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = "+"'"+inEesAdmListTabObj.enclosure_8+"', ";
             lSqlStmt = lSqlStmt + "seat_num = "+inEesAdmListTabObj.seat_num+", ";
      if ( inEesAdmListTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = "+"'"+inEesAdmListTabObj.reason_for_join+"', ";
      if ( inEesAdmListTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inEesAdmListTabObj.remark+"', ";
      if ( inEesAdmListTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = "+"'"+inEesAdmListTabObj.place_of_birth+"', ";
             lSqlStmt = lSqlStmt + "adv_adm_fee = "+inEesAdmListTabObj.adv_adm_fee+", ";
      if ( inEesAdmListTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = "+"'"+inEesAdmListTabObj.payment_mode+"', ";
      if ( inEesAdmListTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = "+"'"+inEesAdmListTabObj.target_ptl_user_id+"', ";
      if ( inEesAdmListTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAdmListTabObj.adm_req_id_req+"', ";
      if ( inEesAdmListTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAdmListTabObj.adm_req_id_list+"', ";
      if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )
        lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

       sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmListRecByPkey
               ( EesAdmListPkeyObj inEesAdmListPkeyObj
               , EesAdmListTabObj  inEesAdmListTabObj
               )
  {
    int lUpdateCount;
    sop("updEesAdmListRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmListRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////




          if ( inEesAdmListTabObj.dob != null && inEesAdmListTabObj.dob.length() > 0 ) 
            inEesAdmListTabObj.dob  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.dob, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.age_on_date != null && inEesAdmListTabObj.age_on_date.length() > 0 ) 
            inEesAdmListTabObj.age_on_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.age_on_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.adm_req_sts_date != null && inEesAdmListTabObj.adm_req_sts_date.length() > 0 ) 
            inEesAdmListTabObj.adm_req_sts_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.adm_req_sts_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.form_recv_date != null && inEesAdmListTabObj.form_recv_date.length() > 0 ) 
            inEesAdmListTabObj.form_recv_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.form_recv_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.prospectus_sale_date != null && inEesAdmListTabObj.prospectus_sale_date.length() > 0 ) 
            inEesAdmListTabObj.prospectus_sale_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.prospectus_sale_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.entrance_exam_date != null && inEesAdmListTabObj.entrance_exam_date.length() > 0 ) 
            inEesAdmListTabObj.entrance_exam_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.entrance_exam_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_sch_date != null && inEesAdmListTabObj.fee_sch_date.length() > 0 ) 
            inEesAdmListTabObj.fee_sch_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_sch_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.fee_deposit_date != null && inEesAdmListTabObj.fee_deposit_date.length() > 0 ) 
            inEesAdmListTabObj.fee_deposit_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.fee_deposit_date, lDateTimeSrcFmt);

          if ( inEesAdmListTabObj.cheque_date != null && inEesAdmListTabObj.cheque_date.length() > 0 ) 
            inEesAdmListTabObj.cheque_date  =  lSSTDateMethod.dateConversion( lDateTimeTrgFmt, inEesAdmListTabObj.cheque_date, lDateTimeSrcFmt);
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_LIST ";
      lSqlStmt = lSqlStmt + "SET ";
      if ( gIsPreparedStmt )
      {
        if ( inEesAdmListTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = ? , ";
        if ( inEesAdmListTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = ? , ";
        if ( inEesAdmListTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = ? , ";
        if ( inEesAdmListTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = ? , ";
        if ( inEesAdmListTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = ? , ";
        if ( inEesAdmListTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = ? , ";
        if ( inEesAdmListTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = ? , ";
        if ( inEesAdmListTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = ? , ";
        if ( inEesAdmListTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = ? , ";
        if ( inEesAdmListTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = ? , ";
        if ( inEesAdmListTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = ? , ";
        if ( inEesAdmListTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = ? , ";
        if ( inEesAdmListTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = ? , ";
        if ( inEesAdmListTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = ? , ";
        if ( inEesAdmListTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = ? , ";
        if ( inEesAdmListTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = ? , ";
        if ( inEesAdmListTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = ? , ";
        if ( inEesAdmListTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = ? , ";
        if ( inEesAdmListTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = ? , ";
        if ( inEesAdmListTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = ? , ";
               lSqlStmt = lSqlStmt + "age_year = ? , ";
        if ( inEesAdmListTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = ? , ";
               lSqlStmt = lSqlStmt + "age_day = ? , ";
        if ( inEesAdmListTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = ? , ";
        if ( inEesAdmListTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = ? , ";
        if ( inEesAdmListTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = ? , ";
        if ( inEesAdmListTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = ? , ";
        if ( inEesAdmListTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = ? , ";
        if ( inEesAdmListTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = ? , ";
        if ( inEesAdmListTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = ? , ";
        if ( inEesAdmListTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = ? , ";
        if ( inEesAdmListTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = ? , ";
        if ( inEesAdmListTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = ? , ";
        if ( inEesAdmListTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = ? , ";
        if ( inEesAdmListTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = ? , ";
        if ( inEesAdmListTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = ? , ";
        if ( inEesAdmListTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = ? , ";
        if ( inEesAdmListTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = ? , ";
        if ( inEesAdmListTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = ? , ";
        if ( inEesAdmListTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = ? , ";
        if ( inEesAdmListTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = ? , ";
        if ( inEesAdmListTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = ? , ";
        if ( inEesAdmListTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = ? , ";
        if ( inEesAdmListTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = ? , ";
        if ( inEesAdmListTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = ? , ";
        if ( inEesAdmListTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = ? , ";
        if ( inEesAdmListTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = ? , ";
        if ( inEesAdmListTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = ? , ";
        if ( inEesAdmListTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = ? , ";
        if ( inEesAdmListTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = ? , ";
        if ( inEesAdmListTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = ? , ";
        if ( inEesAdmListTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = ? , ";
        if ( inEesAdmListTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = ? , ";
        if ( inEesAdmListTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = ? , ";
               lSqlStmt = lSqlStmt + "father_age = ? , ";
        if ( inEesAdmListTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = ? , ";
        if ( inEesAdmListTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = ? , ";
        if ( inEesAdmListTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = ? , ";
        if ( inEesAdmListTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = ? , ";
               lSqlStmt = lSqlStmt + "father_annual_income = ? , ";
        if ( inEesAdmListTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = ? , ";
        if ( inEesAdmListTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = ? , ";
        if ( inEesAdmListTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = ? , ";
               lSqlStmt = lSqlStmt + "mother_age = ? , ";
        if ( inEesAdmListTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = ? , ";
        if ( inEesAdmListTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = ? , ";
        if ( inEesAdmListTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = ? , ";
        if ( inEesAdmListTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = ? , ";
               lSqlStmt = lSqlStmt + "mother_annual_income = ? , ";
        if ( inEesAdmListTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = ? , ";
        if ( inEesAdmListTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = ? , ";
        if ( inEesAdmListTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = ? , ";
        if ( inEesAdmListTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = ? , ";
        if ( inEesAdmListTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = ? , ";
        if ( inEesAdmListTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = ? , ";
        if ( inEesAdmListTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = ? , ";
        if ( inEesAdmListTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = ? , ";
        if ( inEesAdmListTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = ? , ";
        if ( inEesAdmListTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = ? , ";
        if ( inEesAdmListTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = ? , ";
        if ( inEesAdmListTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = ? , ";
        if ( inEesAdmListTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = ? , ";
        if ( inEesAdmListTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = ? , ";
        if ( inEesAdmListTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = ? , ";
               lSqlStmt = lSqlStmt + "application_form_fee = ? , ";
        if ( inEesAdmListTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = ? , ";
        if ( inEesAdmListTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = ? , ";
        if ( inEesAdmListTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = ? , ";
        if ( inEesAdmListTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = ? , ";
        if ( inEesAdmListTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = ? , ";
        if ( inEesAdmListTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = ? , ";
        if ( inEesAdmListTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = ? , ";
        if ( inEesAdmListTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = ? , ";
               lSqlStmt = lSqlStmt + "max_mark = ? , ";
               lSqlStmt = lSqlStmt + "obtained_mark = ? , ";
        if ( inEesAdmListTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = ? , ";
        if ( inEesAdmListTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = ? , ";
        if ( inEesAdmListTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = ? , ";
        if ( inEesAdmListTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = ? , ";
        if ( inEesAdmListTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = ? , ";
        if ( inEesAdmListTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = ? , ";
        if ( inEesAdmListTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = ? , ";
        if ( inEesAdmListTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = ? , ";
        if ( inEesAdmListTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = ? , ";
        if ( inEesAdmListTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = ? , ";
        if ( inEesAdmListTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = ? , ";
        if ( inEesAdmListTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = ? , ";
        if ( inEesAdmListTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = ? , ";
        if ( inEesAdmListTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = ? , ";
        if ( inEesAdmListTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = ? , ";
        if ( inEesAdmListTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = ? , ";
        if ( inEesAdmListTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = ? , ";
        if ( inEesAdmListTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = ? , ";
        if ( inEesAdmListTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = ? , ";
        if ( inEesAdmListTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = ? , ";
        if ( inEesAdmListTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = ? , ";
        if ( inEesAdmListTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = ? , ";
               lSqlStmt = lSqlStmt + "prev_mark_percent = ? , ";
        if ( inEesAdmListTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = ? , ";
        if ( inEesAdmListTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = ? , ";
        if ( inEesAdmListTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = ? , ";
        if ( inEesAdmListTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = ? , ";
        if ( inEesAdmListTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = ? , ";
        if ( inEesAdmListTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = ? , ";
        if ( inEesAdmListTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = ? , ";
               lSqlStmt = lSqlStmt + "cheque_amt = ? , ";
        if ( inEesAdmListTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = ? , ";
        if ( inEesAdmListTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = ? , ";
        if ( inEesAdmListTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = ? , ";
        if ( inEesAdmListTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = ? , ";
        if ( inEesAdmListTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = ? , ";
        if ( inEesAdmListTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = ? , ";
        if ( inEesAdmListTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = ? , ";
        if ( inEesAdmListTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = ? , ";
        if ( inEesAdmListTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = ? , ";
        if ( inEesAdmListTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = ? , ";
        if ( inEesAdmListTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = ? , ";
        if ( inEesAdmListTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = ? , ";
        if ( inEesAdmListTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = ? , ";
        if ( inEesAdmListTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = ? , ";
        if ( inEesAdmListTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = ? , ";
        if ( inEesAdmListTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = ? , ";
        if ( inEesAdmListTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = ? , ";
        if ( inEesAdmListTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = ? , ";
        if ( inEesAdmListTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = ? , ";
        if ( inEesAdmListTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = ? , ";
        if ( inEesAdmListTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = ? , ";
        if ( inEesAdmListTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = ? , ";
        if ( inEesAdmListTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = ? , ";
        if ( inEesAdmListTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = ? , ";
        if ( inEesAdmListTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = ? , ";
        if ( inEesAdmListTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = ? , ";
        if ( inEesAdmListTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = ? , ";
        if ( inEesAdmListTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = ? , ";
        if ( inEesAdmListTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = ? , ";
        if ( inEesAdmListTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = ? , ";
        if ( inEesAdmListTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = ? , ";
        if ( inEesAdmListTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = ? , ";
               lSqlStmt = lSqlStmt + "seat_num = ? , ";
        if ( inEesAdmListTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = ? , ";
        if ( inEesAdmListTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = ? , ";
        if ( inEesAdmListTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = ? , ";
               lSqlStmt = lSqlStmt + "adv_adm_fee = ? , ";
        if ( inEesAdmListTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = ? , ";
        if ( inEesAdmListTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = ? , ";
        if ( inEesAdmListTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = ? , ";
        if ( inEesAdmListTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = ? , ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
      else
      {
        if ( inEesAdmListTabObj.org_id != null  )         lSqlStmt = lSqlStmt + "org_id = "+"'"+inEesAdmListTabObj.org_id+"', ";
        if ( inEesAdmListTabObj.adm_req_id != null  )         lSqlStmt = lSqlStmt + "adm_req_id = "+"'"+inEesAdmListTabObj.adm_req_id+"', ";
        if ( inEesAdmListTabObj.application_form_num != null  )         lSqlStmt = lSqlStmt + "application_form_num = "+"'"+inEesAdmListTabObj.application_form_num+"', ";
        if ( inEesAdmListTabObj.applicant_id != null  )         lSqlStmt = lSqlStmt + "applicant_id = "+"'"+inEesAdmListTabObj.applicant_id+"', ";
        if ( inEesAdmListTabObj.student_photo_file != null  )         lSqlStmt = lSqlStmt + "student_photo_file = "+"'"+inEesAdmListTabObj.student_photo_file+"', ";
        if ( inEesAdmListTabObj.mother_photo_file != null  )         lSqlStmt = lSqlStmt + "mother_photo_file = "+"'"+inEesAdmListTabObj.mother_photo_file+"', ";
        if ( inEesAdmListTabObj.father_photo_file != null  )         lSqlStmt = lSqlStmt + "father_photo_file = "+"'"+inEesAdmListTabObj.father_photo_file+"', ";
        if ( inEesAdmListTabObj.class_id != null  )         lSqlStmt = lSqlStmt + "class_id = "+"'"+inEesAdmListTabObj.class_id+"', ";
        if ( inEesAdmListTabObj.class_num != null  )         lSqlStmt = lSqlStmt + "class_num = "+"'"+inEesAdmListTabObj.class_num+"', ";
        if ( inEesAdmListTabObj.class_std != null  )         lSqlStmt = lSqlStmt + "class_std = "+"'"+inEesAdmListTabObj.class_std+"', ";
        if ( inEesAdmListTabObj.class_section != null  )         lSqlStmt = lSqlStmt + "class_section = "+"'"+inEesAdmListTabObj.class_section+"', ";
        if ( inEesAdmListTabObj.course_id != null  )         lSqlStmt = lSqlStmt + "course_id = "+"'"+inEesAdmListTabObj.course_id+"', ";
        if ( inEesAdmListTabObj.course_term != null  )         lSqlStmt = lSqlStmt + "course_term = "+"'"+inEesAdmListTabObj.course_term+"', ";
        if ( inEesAdmListTabObj.course_stream != null  )         lSqlStmt = lSqlStmt + "course_stream = "+"'"+inEesAdmListTabObj.course_stream+"', ";
        if ( inEesAdmListTabObj.name_initials != null  )         lSqlStmt = lSqlStmt + "name_initials = "+"'"+inEesAdmListTabObj.name_initials+"', ";
        if ( inEesAdmListTabObj.student_f_name != null  )         lSqlStmt = lSqlStmt + "student_f_name = "+"'"+inEesAdmListTabObj.student_f_name+"', ";
        if ( inEesAdmListTabObj.student_m_name != null  )         lSqlStmt = lSqlStmt + "student_m_name = "+"'"+inEesAdmListTabObj.student_m_name+"', ";
        if ( inEesAdmListTabObj.student_l_name != null  )         lSqlStmt = lSqlStmt + "student_l_name = "+"'"+inEesAdmListTabObj.student_l_name+"', ";
        if ( inEesAdmListTabObj.dob != null  )         lSqlStmt = lSqlStmt + "dob = "+"'"+inEesAdmListTabObj.dob+"', ";
        if ( inEesAdmListTabObj.age_on_date != null  )         lSqlStmt = lSqlStmt + "age_on_date = "+"'"+inEesAdmListTabObj.age_on_date+"', ";
               lSqlStmt = lSqlStmt + "age_year = "+inEesAdmListTabObj.age_year+", ";
        if ( inEesAdmListTabObj.age_month != null  )         lSqlStmt = lSqlStmt + "age_month = "+"'"+inEesAdmListTabObj.age_month+"', ";
               lSqlStmt = lSqlStmt + "age_day = "+inEesAdmListTabObj.age_day+", ";
        if ( inEesAdmListTabObj.s_nationality != null  )         lSqlStmt = lSqlStmt + "s_nationality = "+"'"+inEesAdmListTabObj.s_nationality+"', ";
        if ( inEesAdmListTabObj.religion != null  )         lSqlStmt = lSqlStmt + "religion = "+"'"+inEesAdmListTabObj.religion+"', ";
        if ( inEesAdmListTabObj.student_ctg != null  )         lSqlStmt = lSqlStmt + "student_ctg = "+"'"+inEesAdmListTabObj.student_ctg+"', ";
        if ( inEesAdmListTabObj.gender_flag != null  )         lSqlStmt = lSqlStmt + "gender_flag = "+"'"+inEesAdmListTabObj.gender_flag+"', ";
        if ( inEesAdmListTabObj.p_address_1 != null  )         lSqlStmt = lSqlStmt + "p_address_1 = "+"'"+inEesAdmListTabObj.p_address_1+"', ";
        if ( inEesAdmListTabObj.p_address_2 != null  )         lSqlStmt = lSqlStmt + "p_address_2 = "+"'"+inEesAdmListTabObj.p_address_2+"', ";
        if ( inEesAdmListTabObj.p_country != null  )         lSqlStmt = lSqlStmt + "p_country = "+"'"+inEesAdmListTabObj.p_country+"', ";
        if ( inEesAdmListTabObj.p_state != null  )         lSqlStmt = lSqlStmt + "p_state = "+"'"+inEesAdmListTabObj.p_state+"', ";
        if ( inEesAdmListTabObj.p_city != null  )         lSqlStmt = lSqlStmt + "p_city = "+"'"+inEesAdmListTabObj.p_city+"', ";
        if ( inEesAdmListTabObj.p_district != null  )         lSqlStmt = lSqlStmt + "p_district = "+"'"+inEesAdmListTabObj.p_district+"', ";
        if ( inEesAdmListTabObj.p_zip != null  )         lSqlStmt = lSqlStmt + "p_zip = "+"'"+inEesAdmListTabObj.p_zip+"', ";
        if ( inEesAdmListTabObj.m_address_1 != null  )         lSqlStmt = lSqlStmt + "m_address_1 = "+"'"+inEesAdmListTabObj.m_address_1+"', ";
        if ( inEesAdmListTabObj.m_address_2 != null  )         lSqlStmt = lSqlStmt + "m_address_2 = "+"'"+inEesAdmListTabObj.m_address_2+"', ";
        if ( inEesAdmListTabObj.m_country != null  )         lSqlStmt = lSqlStmt + "m_country = "+"'"+inEesAdmListTabObj.m_country+"', ";
        if ( inEesAdmListTabObj.m_state != null  )         lSqlStmt = lSqlStmt + "m_state = "+"'"+inEesAdmListTabObj.m_state+"', ";
        if ( inEesAdmListTabObj.m_city != null  )         lSqlStmt = lSqlStmt + "m_city = "+"'"+inEesAdmListTabObj.m_city+"', ";
        if ( inEesAdmListTabObj.m_district != null  )         lSqlStmt = lSqlStmt + "m_district = "+"'"+inEesAdmListTabObj.m_district+"', ";
        if ( inEesAdmListTabObj.m_zip != null  )         lSqlStmt = lSqlStmt + "m_zip = "+"'"+inEesAdmListTabObj.m_zip+"', ";
        if ( inEesAdmListTabObj.phone_list != null  )         lSqlStmt = lSqlStmt + "phone_list = "+"'"+inEesAdmListTabObj.phone_list+"', ";
        if ( inEesAdmListTabObj.email_list != null  )         lSqlStmt = lSqlStmt + "email_list = "+"'"+inEesAdmListTabObj.email_list+"', ";
        if ( inEesAdmListTabObj.fax_list != null  )         lSqlStmt = lSqlStmt + "fax_list = "+"'"+inEesAdmListTabObj.fax_list+"', ";
        if ( inEesAdmListTabObj.prev_org_name != null  )         lSqlStmt = lSqlStmt + "prev_org_name = "+"'"+inEesAdmListTabObj.prev_org_name+"', ";
        if ( inEesAdmListTabObj.prev_class_id != null  )         lSqlStmt = lSqlStmt + "prev_class_id = "+"'"+inEesAdmListTabObj.prev_class_id+"', ";
        if ( inEesAdmListTabObj.prev_class_num != null  )         lSqlStmt = lSqlStmt + "prev_class_num = "+"'"+inEesAdmListTabObj.prev_class_num+"', ";
        if ( inEesAdmListTabObj.prev_class_std != null  )         lSqlStmt = lSqlStmt + "prev_class_std = "+"'"+inEesAdmListTabObj.prev_class_std+"', ";
        if ( inEesAdmListTabObj.prev_class_section != null  )         lSqlStmt = lSqlStmt + "prev_class_section = "+"'"+inEesAdmListTabObj.prev_class_section+"', ";
        if ( inEesAdmListTabObj.prev_course_id != null  )         lSqlStmt = lSqlStmt + "prev_course_id = "+"'"+inEesAdmListTabObj.prev_course_id+"', ";
        if ( inEesAdmListTabObj.prev_course_term != null  )         lSqlStmt = lSqlStmt + "prev_course_term = "+"'"+inEesAdmListTabObj.prev_course_term+"', ";
        if ( inEesAdmListTabObj.prev_course_stream != null  )         lSqlStmt = lSqlStmt + "prev_course_stream = "+"'"+inEesAdmListTabObj.prev_course_stream+"', ";
        if ( inEesAdmListTabObj.reason_for_leaving != null  )         lSqlStmt = lSqlStmt + "reason_for_leaving = "+"'"+inEesAdmListTabObj.reason_for_leaving+"', ";
        if ( inEesAdmListTabObj.father_name != null  )         lSqlStmt = lSqlStmt + "father_name = "+"'"+inEesAdmListTabObj.father_name+"', ";
               lSqlStmt = lSqlStmt + "father_age = "+inEesAdmListTabObj.father_age+", ";
        if ( inEesAdmListTabObj.f_nationality != null  )         lSqlStmt = lSqlStmt + "f_nationality = "+"'"+inEesAdmListTabObj.f_nationality+"', ";
        if ( inEesAdmListTabObj.father_occ_type != null  )         lSqlStmt = lSqlStmt + "father_occ_type = "+"'"+inEesAdmListTabObj.father_occ_type+"', ";
        if ( inEesAdmListTabObj.father_employer != null  )         lSqlStmt = lSqlStmt + "father_employer = "+"'"+inEesAdmListTabObj.father_employer+"', ";
        if ( inEesAdmListTabObj.father_designation != null  )         lSqlStmt = lSqlStmt + "father_designation = "+"'"+inEesAdmListTabObj.father_designation+"', ";
               lSqlStmt = lSqlStmt + "father_annual_income = "+inEesAdmListTabObj.father_annual_income+", ";
        if ( inEesAdmListTabObj.f_off_address_1 != null  )         lSqlStmt = lSqlStmt + "f_off_address_1 = "+"'"+inEesAdmListTabObj.f_off_address_1+"', ";
        if ( inEesAdmListTabObj.f_phone_list != null  )         lSqlStmt = lSqlStmt + "f_phone_list = "+"'"+inEesAdmListTabObj.f_phone_list+"', ";
        if ( inEesAdmListTabObj.mother_name != null  )         lSqlStmt = lSqlStmt + "mother_name = "+"'"+inEesAdmListTabObj.mother_name+"', ";
               lSqlStmt = lSqlStmt + "mother_age = "+inEesAdmListTabObj.mother_age+", ";
        if ( inEesAdmListTabObj.m_nationality != null  )         lSqlStmt = lSqlStmt + "m_nationality = "+"'"+inEesAdmListTabObj.m_nationality+"', ";
        if ( inEesAdmListTabObj.mother_occ_type != null  )         lSqlStmt = lSqlStmt + "mother_occ_type = "+"'"+inEesAdmListTabObj.mother_occ_type+"', ";
        if ( inEesAdmListTabObj.mother_employer != null  )         lSqlStmt = lSqlStmt + "mother_employer = "+"'"+inEesAdmListTabObj.mother_employer+"', ";
        if ( inEesAdmListTabObj.mother_designation != null  )         lSqlStmt = lSqlStmt + "mother_designation = "+"'"+inEesAdmListTabObj.mother_designation+"', ";
               lSqlStmt = lSqlStmt + "mother_annual_income = "+inEesAdmListTabObj.mother_annual_income+", ";
        if ( inEesAdmListTabObj.m_off_address_1 != null  )         lSqlStmt = lSqlStmt + "m_off_address_1 = "+"'"+inEesAdmListTabObj.m_off_address_1+"', ";
        if ( inEesAdmListTabObj.m_phone_list != null  )         lSqlStmt = lSqlStmt + "m_phone_list = "+"'"+inEesAdmListTabObj.m_phone_list+"', ";
        if ( inEesAdmListTabObj.divorced_flag != null  )         lSqlStmt = lSqlStmt + "divorced_flag = "+"'"+inEesAdmListTabObj.divorced_flag+"', ";
        if ( inEesAdmListTabObj.child_with != null  )         lSqlStmt = lSqlStmt + "child_with = "+"'"+inEesAdmListTabObj.child_with+"', ";
        if ( inEesAdmListTabObj.roll_num != null  )         lSqlStmt = lSqlStmt + "roll_num = "+"'"+inEesAdmListTabObj.roll_num+"', ";
        if ( inEesAdmListTabObj.academic_session != null  )         lSqlStmt = lSqlStmt + "academic_session = "+"'"+inEesAdmListTabObj.academic_session+"', ";
        if ( inEesAdmListTabObj.adm_req_sts != null  )         lSqlStmt = lSqlStmt + "adm_req_sts = "+"'"+inEesAdmListTabObj.adm_req_sts+"', ";
        if ( inEesAdmListTabObj.adm_req_sts_date != null  )         lSqlStmt = lSqlStmt + "adm_req_sts_date = "+"'"+inEesAdmListTabObj.adm_req_sts_date+"', ";
        if ( inEesAdmListTabObj.student_id != null  )         lSqlStmt = lSqlStmt + "student_id = "+"'"+inEesAdmListTabObj.student_id+"', ";
        if ( inEesAdmListTabObj.scholor_num != null  )         lSqlStmt = lSqlStmt + "scholor_num = "+"'"+inEesAdmListTabObj.scholor_num+"', ";
        if ( inEesAdmListTabObj.form_recv_date != null  )         lSqlStmt = lSqlStmt + "form_recv_date = "+"'"+inEesAdmListTabObj.form_recv_date+"', ";
        if ( inEesAdmListTabObj.form_recv_time != null  )         lSqlStmt = lSqlStmt + "form_recv_time = "+"'"+inEesAdmListTabObj.form_recv_time+"', ";
        if ( inEesAdmListTabObj.prospectus_sale_date != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_date = "+"'"+inEesAdmListTabObj.prospectus_sale_date+"', ";
        if ( inEesAdmListTabObj.prospectus_sale_time != null  )         lSqlStmt = lSqlStmt + "prospectus_sale_time = "+"'"+inEesAdmListTabObj.prospectus_sale_time+"', ";
        if ( inEesAdmListTabObj.prospectus_sold_by != null  )         lSqlStmt = lSqlStmt + "prospectus_sold_by = "+"'"+inEesAdmListTabObj.prospectus_sold_by+"', ";
               lSqlStmt = lSqlStmt + "application_form_fee = "+inEesAdmListTabObj.application_form_fee+", ";
        if ( inEesAdmListTabObj.adm_academic_session != null  )         lSqlStmt = lSqlStmt + "adm_academic_session = "+"'"+inEesAdmListTabObj.adm_academic_session+"', ";
        if ( inEesAdmListTabObj.entrance_exam_date != null  )         lSqlStmt = lSqlStmt + "entrance_exam_date = "+"'"+inEesAdmListTabObj.entrance_exam_date+"', ";
        if ( inEesAdmListTabObj.entrance_exam_time_start != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_start = "+"'"+inEesAdmListTabObj.entrance_exam_time_start+"', ";
        if ( inEesAdmListTabObj.entrance_exam_time_end != null  )         lSqlStmt = lSqlStmt + "entrance_exam_time_end = "+"'"+inEesAdmListTabObj.entrance_exam_time_end+"', ";
        if ( inEesAdmListTabObj.exam_present_status != null  )         lSqlStmt = lSqlStmt + "exam_present_status = "+"'"+inEesAdmListTabObj.exam_present_status+"', ";
        if ( inEesAdmListTabObj.building_id != null  )         lSqlStmt = lSqlStmt + "building_id = "+"'"+inEesAdmListTabObj.building_id+"', ";
        if ( inEesAdmListTabObj.floor_num != null  )         lSqlStmt = lSqlStmt + "floor_num = "+"'"+inEesAdmListTabObj.floor_num+"', ";
        if ( inEesAdmListTabObj.room_num != null  )         lSqlStmt = lSqlStmt + "room_num = "+"'"+inEesAdmListTabObj.room_num+"', ";
               lSqlStmt = lSqlStmt + "max_mark = "+inEesAdmListTabObj.max_mark+", ";
               lSqlStmt = lSqlStmt + "obtained_mark = "+inEesAdmListTabObj.obtained_mark+", ";
        if ( inEesAdmListTabObj.grade != null  )         lSqlStmt = lSqlStmt + "grade = "+"'"+inEesAdmListTabObj.grade+"', ";
        if ( inEesAdmListTabObj.fee_sch_date != null  )         lSqlStmt = lSqlStmt + "fee_sch_date = "+"'"+inEesAdmListTabObj.fee_sch_date+"', ";
        if ( inEesAdmListTabObj.fee_deposit_date != null  )         lSqlStmt = lSqlStmt + "fee_deposit_date = "+"'"+inEesAdmListTabObj.fee_deposit_date+"', ";
        if ( inEesAdmListTabObj.online_flag != null  )         lSqlStmt = lSqlStmt + "online_flag = "+"'"+inEesAdmListTabObj.online_flag+"', ";
        if ( inEesAdmListTabObj.admission_mode != null  )         lSqlStmt = lSqlStmt + "admission_mode = "+"'"+inEesAdmListTabObj.admission_mode+"', ";
        if ( inEesAdmListTabObj.course_stream_1 != null  )         lSqlStmt = lSqlStmt + "course_stream_1 = "+"'"+inEesAdmListTabObj.course_stream_1+"', ";
        if ( inEesAdmListTabObj.course_stream_2 != null  )         lSqlStmt = lSqlStmt + "course_stream_2 = "+"'"+inEesAdmListTabObj.course_stream_2+"', ";
        if ( inEesAdmListTabObj.course_stream_3 != null  )         lSqlStmt = lSqlStmt + "course_stream_3 = "+"'"+inEesAdmListTabObj.course_stream_3+"', ";
        if ( inEesAdmListTabObj.course_stream_4 != null  )         lSqlStmt = lSqlStmt + "course_stream_4 = "+"'"+inEesAdmListTabObj.course_stream_4+"', ";
        if ( inEesAdmListTabObj.apr_course_stream != null  )         lSqlStmt = lSqlStmt + "apr_course_stream = "+"'"+inEesAdmListTabObj.apr_course_stream+"', ";
        if ( inEesAdmListTabObj.unv_1 != null  )         lSqlStmt = lSqlStmt + "unv_1 = "+"'"+inEesAdmListTabObj.unv_1+"', ";
        if ( inEesAdmListTabObj.unv_rn_1 != null  )         lSqlStmt = lSqlStmt + "unv_rn_1 = "+"'"+inEesAdmListTabObj.unv_rn_1+"', ";
        if ( inEesAdmListTabObj.gen_rank_1 != null  )         lSqlStmt = lSqlStmt + "gen_rank_1 = "+"'"+inEesAdmListTabObj.gen_rank_1+"', ";
        if ( inEesAdmListTabObj.ctg_rank_1 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_1 = "+"'"+inEesAdmListTabObj.ctg_rank_1+"', ";
        if ( inEesAdmListTabObj.stt_rank_1 != null  )         lSqlStmt = lSqlStmt + "stt_rank_1 = "+"'"+inEesAdmListTabObj.stt_rank_1+"', ";
        if ( inEesAdmListTabObj.yoa_1 != null  )         lSqlStmt = lSqlStmt + "yoa_1 = "+"'"+inEesAdmListTabObj.yoa_1+"', ";
        if ( inEesAdmListTabObj.unv_2 != null  )         lSqlStmt = lSqlStmt + "unv_2 = "+"'"+inEesAdmListTabObj.unv_2+"', ";
        if ( inEesAdmListTabObj.unv_rn_2 != null  )         lSqlStmt = lSqlStmt + "unv_rn_2 = "+"'"+inEesAdmListTabObj.unv_rn_2+"', ";
        if ( inEesAdmListTabObj.gen_rank_2 != null  )         lSqlStmt = lSqlStmt + "gen_rank_2 = "+"'"+inEesAdmListTabObj.gen_rank_2+"', ";
        if ( inEesAdmListTabObj.ctg_rank_2 != null  )         lSqlStmt = lSqlStmt + "ctg_rank_2 = "+"'"+inEesAdmListTabObj.ctg_rank_2+"', ";
        if ( inEesAdmListTabObj.stt_rank_2 != null  )         lSqlStmt = lSqlStmt + "stt_rank_2 = "+"'"+inEesAdmListTabObj.stt_rank_2+"', ";
        if ( inEesAdmListTabObj.yoa_2 != null  )         lSqlStmt = lSqlStmt + "yoa_2 = "+"'"+inEesAdmListTabObj.yoa_2+"', ";
               lSqlStmt = lSqlStmt + "prev_mark_percent = "+inEesAdmListTabObj.prev_mark_percent+", ";
        if ( inEesAdmListTabObj.domecile_ind != null  )         lSqlStmt = lSqlStmt + "domecile_ind = "+"'"+inEesAdmListTabObj.domecile_ind+"', ";
        if ( inEesAdmListTabObj.org_transport_req_ind != null  )         lSqlStmt = lSqlStmt + "org_transport_req_ind = "+"'"+inEesAdmListTabObj.org_transport_req_ind+"', ";
        if ( inEesAdmListTabObj.org_hostel_req_ind != null  )         lSqlStmt = lSqlStmt + "org_hostel_req_ind = "+"'"+inEesAdmListTabObj.org_hostel_req_ind+"', ";
        if ( inEesAdmListTabObj.cheque_num != null  )         lSqlStmt = lSqlStmt + "cheque_num = "+"'"+inEesAdmListTabObj.cheque_num+"', ";
        if ( inEesAdmListTabObj.cheque_date != null  )         lSqlStmt = lSqlStmt + "cheque_date = "+"'"+inEesAdmListTabObj.cheque_date+"', ";
        if ( inEesAdmListTabObj.bank_code != null  )         lSqlStmt = lSqlStmt + "bank_code = "+"'"+inEesAdmListTabObj.bank_code+"', ";
        if ( inEesAdmListTabObj.bank_name != null  )         lSqlStmt = lSqlStmt + "bank_name = "+"'"+inEesAdmListTabObj.bank_name+"', ";
               lSqlStmt = lSqlStmt + "cheque_amt = "+inEesAdmListTabObj.cheque_amt+", ";
        if ( inEesAdmListTabObj.lg_0_name != null  )         lSqlStmt = lSqlStmt + "lg_0_name = "+"'"+inEesAdmListTabObj.lg_0_name+"', ";
        if ( inEesAdmListTabObj.lg_0_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_0_rel_type = "+"'"+inEesAdmListTabObj.lg_0_rel_type+"', ";
        if ( inEesAdmListTabObj.lg_0_address != null  )         lSqlStmt = lSqlStmt + "lg_0_address = "+"'"+inEesAdmListTabObj.lg_0_address+"', ";
        if ( inEesAdmListTabObj.lg_0_phone != null  )         lSqlStmt = lSqlStmt + "lg_0_phone = "+"'"+inEesAdmListTabObj.lg_0_phone+"', ";
        if ( inEesAdmListTabObj.lg_1_name != null  )         lSqlStmt = lSqlStmt + "lg_1_name = "+"'"+inEesAdmListTabObj.lg_1_name+"', ";
        if ( inEesAdmListTabObj.lg_1_rel_type != null  )         lSqlStmt = lSqlStmt + "lg_1_rel_type = "+"'"+inEesAdmListTabObj.lg_1_rel_type+"', ";
        if ( inEesAdmListTabObj.lg_1_address != null  )         lSqlStmt = lSqlStmt + "lg_1_address = "+"'"+inEesAdmListTabObj.lg_1_address+"', ";
        if ( inEesAdmListTabObj.lg_1_phone != null  )         lSqlStmt = lSqlStmt + "lg_1_phone = "+"'"+inEesAdmListTabObj.lg_1_phone+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_1 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_1 = "+"'"+inEesAdmListTabObj.st_cap_attr_1+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_2 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_2 = "+"'"+inEesAdmListTabObj.st_cap_attr_2+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_3 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_3 = "+"'"+inEesAdmListTabObj.st_cap_attr_3+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_4 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_4 = "+"'"+inEesAdmListTabObj.st_cap_attr_4+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_5 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_5 = "+"'"+inEesAdmListTabObj.st_cap_attr_5+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_6 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_6 = "+"'"+inEesAdmListTabObj.st_cap_attr_6+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_7 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_7 = "+"'"+inEesAdmListTabObj.st_cap_attr_7+"', ";
        if ( inEesAdmListTabObj.st_cap_attr_8 != null  )         lSqlStmt = lSqlStmt + "st_cap_attr_8 = "+"'"+inEesAdmListTabObj.st_cap_attr_8+"', ";
        if ( inEesAdmListTabObj.allergy != null  )         lSqlStmt = lSqlStmt + "allergy = "+"'"+inEesAdmListTabObj.allergy+"', ";
        if ( inEesAdmListTabObj.physical_disability != null  )         lSqlStmt = lSqlStmt + "physical_disability = "+"'"+inEesAdmListTabObj.physical_disability+"', ";
        if ( inEesAdmListTabObj.health_problem != null  )         lSqlStmt = lSqlStmt + "health_problem = "+"'"+inEesAdmListTabObj.health_problem+"', ";
        if ( inEesAdmListTabObj.health_problem_1 != null  )         lSqlStmt = lSqlStmt + "health_problem_1 = "+"'"+inEesAdmListTabObj.health_problem_1+"', ";
        if ( inEesAdmListTabObj.health_problem_2 != null  )         lSqlStmt = lSqlStmt + "health_problem_2 = "+"'"+inEesAdmListTabObj.health_problem_2+"', ";
        if ( inEesAdmListTabObj.health_problem_3 != null  )         lSqlStmt = lSqlStmt + "health_problem_3 = "+"'"+inEesAdmListTabObj.health_problem_3+"', ";
        if ( inEesAdmListTabObj.health_problem_4 != null  )         lSqlStmt = lSqlStmt + "health_problem_4 = "+"'"+inEesAdmListTabObj.health_problem_4+"', ";
        if ( inEesAdmListTabObj.health_problem_5 != null  )         lSqlStmt = lSqlStmt + "health_problem_5 = "+"'"+inEesAdmListTabObj.health_problem_5+"', ";
        if ( inEesAdmListTabObj.health_problem_6 != null  )         lSqlStmt = lSqlStmt + "health_problem_6 = "+"'"+inEesAdmListTabObj.health_problem_6+"', ";
        if ( inEesAdmListTabObj.health_problem_7 != null  )         lSqlStmt = lSqlStmt + "health_problem_7 = "+"'"+inEesAdmListTabObj.health_problem_7+"', ";
        if ( inEesAdmListTabObj.health_problem_8 != null  )         lSqlStmt = lSqlStmt + "health_problem_8 = "+"'"+inEesAdmListTabObj.health_problem_8+"', ";
        if ( inEesAdmListTabObj.health_problem_9 != null  )         lSqlStmt = lSqlStmt + "health_problem_9 = "+"'"+inEesAdmListTabObj.health_problem_9+"', ";
        if ( inEesAdmListTabObj.health_problem_10 != null  )         lSqlStmt = lSqlStmt + "health_problem_10 = "+"'"+inEesAdmListTabObj.health_problem_10+"', ";
        if ( inEesAdmListTabObj.health_problem_11 != null  )         lSqlStmt = lSqlStmt + "health_problem_11 = "+"'"+inEesAdmListTabObj.health_problem_11+"', ";
        if ( inEesAdmListTabObj.health_problem_12 != null  )         lSqlStmt = lSqlStmt + "health_problem_12 = "+"'"+inEesAdmListTabObj.health_problem_12+"', ";
        if ( inEesAdmListTabObj.enclosure_1 != null  )         lSqlStmt = lSqlStmt + "enclosure_1 = "+"'"+inEesAdmListTabObj.enclosure_1+"', ";
        if ( inEesAdmListTabObj.enclosure_2 != null  )         lSqlStmt = lSqlStmt + "enclosure_2 = "+"'"+inEesAdmListTabObj.enclosure_2+"', ";
        if ( inEesAdmListTabObj.enclosure_3 != null  )         lSqlStmt = lSqlStmt + "enclosure_3 = "+"'"+inEesAdmListTabObj.enclosure_3+"', ";
        if ( inEesAdmListTabObj.enclosure_4 != null  )         lSqlStmt = lSqlStmt + "enclosure_4 = "+"'"+inEesAdmListTabObj.enclosure_4+"', ";
        if ( inEesAdmListTabObj.enclosure_5 != null  )         lSqlStmt = lSqlStmt + "enclosure_5 = "+"'"+inEesAdmListTabObj.enclosure_5+"', ";
        if ( inEesAdmListTabObj.enclosure_6 != null  )         lSqlStmt = lSqlStmt + "enclosure_6 = "+"'"+inEesAdmListTabObj.enclosure_6+"', ";
        if ( inEesAdmListTabObj.enclosure_7 != null  )         lSqlStmt = lSqlStmt + "enclosure_7 = "+"'"+inEesAdmListTabObj.enclosure_7+"', ";
        if ( inEesAdmListTabObj.enclosure_8 != null  )         lSqlStmt = lSqlStmt + "enclosure_8 = "+"'"+inEesAdmListTabObj.enclosure_8+"', ";
               lSqlStmt = lSqlStmt + "seat_num = "+inEesAdmListTabObj.seat_num+", ";
        if ( inEesAdmListTabObj.reason_for_join != null  )         lSqlStmt = lSqlStmt + "reason_for_join = "+"'"+inEesAdmListTabObj.reason_for_join+"', ";
        if ( inEesAdmListTabObj.remark != null  )         lSqlStmt = lSqlStmt + "remark = "+"'"+inEesAdmListTabObj.remark+"', ";
        if ( inEesAdmListTabObj.place_of_birth != null  )         lSqlStmt = lSqlStmt + "place_of_birth = "+"'"+inEesAdmListTabObj.place_of_birth+"', ";
               lSqlStmt = lSqlStmt + "adv_adm_fee = "+inEesAdmListTabObj.adv_adm_fee+", ";
        if ( inEesAdmListTabObj.payment_mode != null  )         lSqlStmt = lSqlStmt + "payment_mode = "+"'"+inEesAdmListTabObj.payment_mode+"', ";
        if ( inEesAdmListTabObj.target_ptl_user_id != null  )         lSqlStmt = lSqlStmt + "target_ptl_user_id = "+"'"+inEesAdmListTabObj.target_ptl_user_id+"', ";
        if ( inEesAdmListTabObj.adm_req_id_req != null  )         lSqlStmt = lSqlStmt + "adm_req_id_req = "+"'"+inEesAdmListTabObj.adm_req_id_req+"', ";
        if ( inEesAdmListTabObj.adm_req_id_list != null  )         lSqlStmt = lSqlStmt + "adm_req_id_list = "+"'"+inEesAdmListTabObj.adm_req_id_list+"', ";
        if ( lSqlStmt.charAt((lSqlStmt.length()-2)) == ',' )          lSqlStmt = lSqlStmt.substring(0,(lSqlStmt.length()-2));
      }
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAdmListPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmListPkeyObj.adm_req_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);
      if ( gIsPreparedStmt ) 
      {
        int lPageFieldIndexNum = 0;
        sop("Sql Statement : prepared stmt"+gIsPreparedStmt);
        PreparedStatement lPreparedStatement = lSSTDBMethod.lConnection.prepareStatement( lSqlStmt ); 
         if ( inEesAdmListTabObj.org_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.org_id); } 
         if ( inEesAdmListTabObj.adm_req_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_req_id); } 
         if ( inEesAdmListTabObj.application_form_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.application_form_num); } 
         if ( inEesAdmListTabObj.applicant_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.applicant_id); } 
         if ( inEesAdmListTabObj.student_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_photo_file); } 
         if ( inEesAdmListTabObj.mother_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.mother_photo_file); } 
         if ( inEesAdmListTabObj.father_photo_file != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.father_photo_file); } 
         if ( inEesAdmListTabObj.class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.class_id); } 
         if ( inEesAdmListTabObj.class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.class_num); } 
         if ( inEesAdmListTabObj.class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.class_std); } 
         if ( inEesAdmListTabObj.class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.class_section); } 
         if ( inEesAdmListTabObj.course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_id); } 
         if ( inEesAdmListTabObj.course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_term); } 
         if ( inEesAdmListTabObj.course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_stream); } 
         if ( inEesAdmListTabObj.name_initials != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.name_initials); } 
         if ( inEesAdmListTabObj.student_f_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_f_name); } 
         if ( inEesAdmListTabObj.student_m_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_m_name); } 
         if ( inEesAdmListTabObj.student_l_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_l_name); } 
         if ( inEesAdmListTabObj.dob != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.dob); } 
         if ( inEesAdmListTabObj.age_on_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.age_on_date); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(21, inEesAdmListTabObj.age_year);
         if ( inEesAdmListTabObj.age_month != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.age_month); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(23, inEesAdmListTabObj.age_day);
         if ( inEesAdmListTabObj.s_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.s_nationality); } 
         if ( inEesAdmListTabObj.religion != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.religion); } 
         if ( inEesAdmListTabObj.student_ctg != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_ctg); } 
         if ( inEesAdmListTabObj.gender_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.gender_flag); } 
         if ( inEesAdmListTabObj.p_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_address_1); } 
         if ( inEesAdmListTabObj.p_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_address_2); } 
         if ( inEesAdmListTabObj.p_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_country); } 
         if ( inEesAdmListTabObj.p_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_state); } 
         if ( inEesAdmListTabObj.p_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_city); } 
         if ( inEesAdmListTabObj.p_district != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_district); } 
         if ( inEesAdmListTabObj.p_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.p_zip); } 
         if ( inEesAdmListTabObj.m_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_address_1); } 
         if ( inEesAdmListTabObj.m_address_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_address_2); } 
         if ( inEesAdmListTabObj.m_country != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_country); } 
         if ( inEesAdmListTabObj.m_state != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_state); } 
         if ( inEesAdmListTabObj.m_city != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_city); } 
         if ( inEesAdmListTabObj.m_district != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_district); } 
         if ( inEesAdmListTabObj.m_zip != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_zip); } 
         if ( inEesAdmListTabObj.phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.phone_list); } 
         if ( inEesAdmListTabObj.email_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.email_list); } 
         if ( inEesAdmListTabObj.fax_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.fax_list); } 
         if ( inEesAdmListTabObj.prev_org_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_org_name); } 
         if ( inEesAdmListTabObj.prev_class_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_class_id); } 
         if ( inEesAdmListTabObj.prev_class_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_class_num); } 
         if ( inEesAdmListTabObj.prev_class_std != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_class_std); } 
         if ( inEesAdmListTabObj.prev_class_section != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_class_section); } 
         if ( inEesAdmListTabObj.prev_course_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_course_id); } 
         if ( inEesAdmListTabObj.prev_course_term != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_course_term); } 
         if ( inEesAdmListTabObj.prev_course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prev_course_stream); } 
         if ( inEesAdmListTabObj.reason_for_leaving != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.reason_for_leaving); } 
         if ( inEesAdmListTabObj.father_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.father_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(55, inEesAdmListTabObj.father_age);
         if ( inEesAdmListTabObj.f_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.f_nationality); } 
         if ( inEesAdmListTabObj.father_occ_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.father_occ_type); } 
         if ( inEesAdmListTabObj.father_employer != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.father_employer); } 
         if ( inEesAdmListTabObj.father_designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.father_designation); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(60, inEesAdmListTabObj.father_annual_income);
         if ( inEesAdmListTabObj.f_off_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.f_off_address_1); } 
         if ( inEesAdmListTabObj.f_phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.f_phone_list); } 
         if ( inEesAdmListTabObj.mother_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.mother_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setByte(64, inEesAdmListTabObj.mother_age);
         if ( inEesAdmListTabObj.m_nationality != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_nationality); } 
         if ( inEesAdmListTabObj.mother_occ_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.mother_occ_type); } 
         if ( inEesAdmListTabObj.mother_employer != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.mother_employer); } 
         if ( inEesAdmListTabObj.mother_designation != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.mother_designation); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(69, inEesAdmListTabObj.mother_annual_income);
         if ( inEesAdmListTabObj.m_off_address_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_off_address_1); } 
         if ( inEesAdmListTabObj.m_phone_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.m_phone_list); } 
         if ( inEesAdmListTabObj.divorced_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.divorced_flag); } 
         if ( inEesAdmListTabObj.child_with != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.child_with); } 
         if ( inEesAdmListTabObj.roll_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.roll_num); } 
         if ( inEesAdmListTabObj.academic_session != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.academic_session); } 
         if ( inEesAdmListTabObj.adm_req_sts != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_req_sts); } 
         if ( inEesAdmListTabObj.adm_req_sts_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_req_sts_date); } 
         if ( inEesAdmListTabObj.student_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.student_id); } 
         if ( inEesAdmListTabObj.scholor_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.scholor_num); } 
         if ( inEesAdmListTabObj.form_recv_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.form_recv_date); } 
         if ( inEesAdmListTabObj.form_recv_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.form_recv_time); } 
         if ( inEesAdmListTabObj.prospectus_sale_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prospectus_sale_date); } 
         if ( inEesAdmListTabObj.prospectus_sale_time != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prospectus_sale_time); } 
         if ( inEesAdmListTabObj.prospectus_sold_by != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.prospectus_sold_by); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(85, inEesAdmListTabObj.application_form_fee);
         if ( inEesAdmListTabObj.adm_academic_session != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_academic_session); } 
         if ( inEesAdmListTabObj.entrance_exam_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.entrance_exam_date); } 
         if ( inEesAdmListTabObj.entrance_exam_time_start != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.entrance_exam_time_start); } 
         if ( inEesAdmListTabObj.entrance_exam_time_end != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.entrance_exam_time_end); } 
         if ( inEesAdmListTabObj.exam_present_status != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.exam_present_status); } 
         if ( inEesAdmListTabObj.building_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.building_id); } 
         if ( inEesAdmListTabObj.floor_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.floor_num); } 
         if ( inEesAdmListTabObj.room_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.room_num); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(94, inEesAdmListTabObj.max_mark);
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(95, inEesAdmListTabObj.obtained_mark);
         if ( inEesAdmListTabObj.grade != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.grade); } 
         if ( inEesAdmListTabObj.fee_sch_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.fee_sch_date); } 
         if ( inEesAdmListTabObj.fee_deposit_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.fee_deposit_date); } 
         if ( inEesAdmListTabObj.online_flag != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.online_flag); } 
         if ( inEesAdmListTabObj.admission_mode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.admission_mode); } 
         if ( inEesAdmListTabObj.course_stream_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_stream_1); } 
         if ( inEesAdmListTabObj.course_stream_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_stream_2); } 
         if ( inEesAdmListTabObj.course_stream_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_stream_3); } 
         if ( inEesAdmListTabObj.course_stream_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.course_stream_4); } 
         if ( inEesAdmListTabObj.apr_course_stream != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.apr_course_stream); } 
         if ( inEesAdmListTabObj.unv_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.unv_1); } 
         if ( inEesAdmListTabObj.unv_rn_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.unv_rn_1); } 
         if ( inEesAdmListTabObj.gen_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.gen_rank_1); } 
         if ( inEesAdmListTabObj.ctg_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.ctg_rank_1); } 
         if ( inEesAdmListTabObj.stt_rank_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.stt_rank_1); } 
         if ( inEesAdmListTabObj.yoa_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.yoa_1); } 
         if ( inEesAdmListTabObj.unv_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.unv_2); } 
         if ( inEesAdmListTabObj.unv_rn_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.unv_rn_2); } 
         if ( inEesAdmListTabObj.gen_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.gen_rank_2); } 
         if ( inEesAdmListTabObj.ctg_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.ctg_rank_2); } 
         if ( inEesAdmListTabObj.stt_rank_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.stt_rank_2); } 
         if ( inEesAdmListTabObj.yoa_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.yoa_2); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setFloat(118, inEesAdmListTabObj.prev_mark_percent);
         if ( inEesAdmListTabObj.domecile_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.domecile_ind); } 
         if ( inEesAdmListTabObj.org_transport_req_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.org_transport_req_ind); } 
         if ( inEesAdmListTabObj.org_hostel_req_ind != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.org_hostel_req_ind); } 
         if ( inEesAdmListTabObj.cheque_num != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.cheque_num); } 
         if ( inEesAdmListTabObj.cheque_date != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.cheque_date); } 
         if ( inEesAdmListTabObj.bank_code != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.bank_code); } 
         if ( inEesAdmListTabObj.bank_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.bank_name); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(126, inEesAdmListTabObj.cheque_amt);
         if ( inEesAdmListTabObj.lg_0_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_0_name); } 
         if ( inEesAdmListTabObj.lg_0_rel_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_0_rel_type); } 
         if ( inEesAdmListTabObj.lg_0_address != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_0_address); } 
         if ( inEesAdmListTabObj.lg_0_phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_0_phone); } 
         if ( inEesAdmListTabObj.lg_1_name != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_1_name); } 
         if ( inEesAdmListTabObj.lg_1_rel_type != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_1_rel_type); } 
         if ( inEesAdmListTabObj.lg_1_address != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_1_address); } 
         if ( inEesAdmListTabObj.lg_1_phone != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.lg_1_phone); } 
         if ( inEesAdmListTabObj.st_cap_attr_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_1); } 
         if ( inEesAdmListTabObj.st_cap_attr_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_2); } 
         if ( inEesAdmListTabObj.st_cap_attr_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_3); } 
         if ( inEesAdmListTabObj.st_cap_attr_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_4); } 
         if ( inEesAdmListTabObj.st_cap_attr_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_5); } 
         if ( inEesAdmListTabObj.st_cap_attr_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_6); } 
         if ( inEesAdmListTabObj.st_cap_attr_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_7); } 
         if ( inEesAdmListTabObj.st_cap_attr_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.st_cap_attr_8); } 
         if ( inEesAdmListTabObj.allergy != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.allergy); } 
         if ( inEesAdmListTabObj.physical_disability != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.physical_disability); } 
         if ( inEesAdmListTabObj.health_problem != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem); } 
         if ( inEesAdmListTabObj.health_problem_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_1); } 
         if ( inEesAdmListTabObj.health_problem_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_2); } 
         if ( inEesAdmListTabObj.health_problem_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_3); } 
         if ( inEesAdmListTabObj.health_problem_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_4); } 
         if ( inEesAdmListTabObj.health_problem_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_5); } 
         if ( inEesAdmListTabObj.health_problem_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_6); } 
         if ( inEesAdmListTabObj.health_problem_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_7); } 
         if ( inEesAdmListTabObj.health_problem_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_8); } 
         if ( inEesAdmListTabObj.health_problem_9 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_9); } 
         if ( inEesAdmListTabObj.health_problem_10 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_10); } 
         if ( inEesAdmListTabObj.health_problem_11 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_11); } 
         if ( inEesAdmListTabObj.health_problem_12 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.health_problem_12); } 
         if ( inEesAdmListTabObj.enclosure_1 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_1); } 
         if ( inEesAdmListTabObj.enclosure_2 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_2); } 
         if ( inEesAdmListTabObj.enclosure_3 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_3); } 
         if ( inEesAdmListTabObj.enclosure_4 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_4); } 
         if ( inEesAdmListTabObj.enclosure_5 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_5); } 
         if ( inEesAdmListTabObj.enclosure_6 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_6); } 
         if ( inEesAdmListTabObj.enclosure_7 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_7); } 
         if ( inEesAdmListTabObj.enclosure_8 != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.enclosure_8); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setShort(166, inEesAdmListTabObj.seat_num);
         if ( inEesAdmListTabObj.reason_for_join != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.reason_for_join); } 
         if ( inEesAdmListTabObj.remark != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.remark); } 
         if ( inEesAdmListTabObj.place_of_birth != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.place_of_birth); } 
           lPageFieldIndexNum = lPageFieldIndexNum + 1;  lPreparedStatement.setDouble(170, inEesAdmListTabObj.adv_adm_fee);
         if ( inEesAdmListTabObj.payment_mode != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.payment_mode); } 
         if ( inEesAdmListTabObj.target_ptl_user_id != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.target_ptl_user_id); } 
         if ( inEesAdmListTabObj.adm_req_id_req != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_req_id_req); } 
         if ( inEesAdmListTabObj.adm_req_id_list != null  )  {    lPageFieldIndexNum = lPageFieldIndexNum + 1;   lPreparedStatement.setString(lPageFieldIndexNum, inEesAdmListTabObj.adm_req_id_list); } 
        lUpdateCount = lSSTDBMethod.executeSSTUpdate( lPreparedStatement );
      }
      else
      { 
        sop("Sql Statement : simple stmt"+gIsPreparedStmt);
        lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      } 
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmListRecByRowid
               ( String inRowId
               )
  {
    int lUpdateCount;
    sop("delEesAdmListRecByRowid - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmListRecByRowid";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                        "FROM   EES_ADM_LIST "+
                         "WHERE  oid = "+Integer.parseInt(inRowId.trim());

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
      if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmListRecByPkeyWithSet
               ( EesAdmListPkeyObj inEesAdmListPkeyObj
               , String  inEesAdmListSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmListRecByPkeyWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmListRecByPkeyWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_LIST ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAdmListSetlist;
        lSqlStmt = lSqlStmt + " "+                         "WHERE "+
                              "org_id = "+"'"+inEesAdmListPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmListPkeyObj.adm_req_id+"'";

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmListRecByRowidWithSet
               ( String inRowId
               , String  inEesAdmListSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmListRecByRowidWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmListRecByRowidWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_LIST ";
      lSqlStmt = lSqlStmt + "SET ";
        lSqlStmt = lSqlStmt + inEesAdmListSetlist;
      lSqlStmt = lSqlStmt + " WHERE  oid = "+Integer.parseInt(inRowId.trim());

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int updEesAdmListRecByWhereWithSet
               ( String inEesAdmListWhereText
               , String  inEesAdmListSetlist
               )
  {
    int lUpdateCount;
    sop("updEesAdmListRecByWhereWithSet - Started");
    gSSTErrorObj.sourceMethod = "updEesAdmListRecByWhereWithSet";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";
      String lSqlStmt = "";
      lSqlStmt = lSqlStmt + "UPDATE EES_ADM_LIST ";
      lSqlStmt = lSqlStmt + "SET ";
      lSqlStmt = lSqlStmt + inEesAdmListSetlist;
      lSqlStmt = lSqlStmt + lWhereText;

      lSqlStmt = lSqlStmt.replaceAll("'null'", "null");
      lSqlStmt = lSqlStmt.replaceAll("''", "null");

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmListRecByPkey
               ( EesAdmListPkeyObj  inEesAdmListPkeyObj
               )
  {
    int lUpdateCount;
    sop("delEesAdmListRecByPkey - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmListRecByPkey";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////



      String lSqlStmt = "DELETE "+
                         "FROM   EES_ADM_LIST " + 
                         "WHERE "+
                              "org_id = "+"'"+inEesAdmListPkeyObj.org_id+"' and "+
                              "adm_req_id = "+"'"+inEesAdmListPkeyObj.adm_req_id+"'";

      sop("Sql Statement : "+lSqlStmt);

      lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
      if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
      { 
        gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode; 
        gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
        gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText; 
        lReturnValue = -999000000+gSSTErrorObj.errorCode; 
        throw new Exception(); 
      } 
      lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
      lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }





  public int delEesAdmListByWhere
               ( String inEesAdmListWhereText
               )
  {
    int lUpdateCount;
    sop("delEesAdmListByWhere - Started");
    gSSTErrorObj.sourceMethod = "delEesAdmListByWhere";

    Properties      props = new Properties();
    SSTProperty     sstProps;

    StringTokenizer lDBAttrib = null;

    String          lDBDriver = "";
    String          lDBUrl    = "";
    String          lDBUsr    = "";
    String          lDBPwd    = "";

    String          lDateTimeSrcFmt = "";
    String          lDateTimeTrgFmt = "";
    Properties      lParamProperty = new Properties();
    SSTProperty     sstParamProperty;
    SSTDateMethod   lSSTDateMethod = new SSTDateMethod();
    lDateTimeSrcFmt = "yyyyMMdd";
    lDateTimeTrgFmt = "dd-MMM-yyyy";

    int             lReturnValue   = 0;
    boolean         NO_DATA_FOUND  = false;

    SSTDBMethod     lSSTDBMethod   = new SSTDBMethod();
    Connection      lDBCon         = null;
    ResultSet       lResultSet     = null;

    try
    {
       /////////////////  IF CONNECT_IND = FALSE - STARTS ////////////////
     if ( !gConnectInd ) 
     { 
       sstProps = new SSTProperty(gConfigFilePath+gConfigFile);
       if ( sstProps.gSSTErrorObj.errorCode < 0 ) 
       { 
          gSSTErrorObj.errorCode = sstProps.gSSTErrorObj.errorCode; 
          gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
          gSSTErrorObj.errorText = sstProps.gSSTErrorObj.errorText; 
          lReturnValue = gSSTErrorObj.errorCode; 
          throw new Exception(); 
       } 


       props = sstProps.getSSTProperty();
       if ( props == null ) throw new Exception();


       lDBAttrib = new StringTokenizer(props.getProperty(gDBUsr).toString(), ",");
       if ( lDBAttrib == null ) throw new Exception();

       lDBDriver = lDBAttrib.nextToken().replaceAll("<driver>","");
       lDBUrl = lDBAttrib.nextToken().replaceAll("<url>","");
       lDBUsr = lDBAttrib.nextToken().replaceAll("<usr>","");
       lDBPwd = lDBAttrib.nextToken().replaceAll("<pwd>","");
       try
       {
         lDBDriver = lDBDriver.replaceAll("<db_driver_name>",System.getenv("DB_DRIVER_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_host_ip>",System.getenv("DB_HOST_IP"));
         lDBUrl = lDBUrl.replaceAll("<db_name>",System.getenv("DB_NAME"));
         lDBUrl = lDBUrl.replaceAll("<db_url>",System.getenv("DB_URL"));
         lDBUsr = lDBUsr.replaceAll("<db_user_name>",System.getenv("DB_USER_NAME"));
         lDBPwd = lDBPwd.replaceAll("<db_user_pswd>",System.getenv("DB_USER_PSWD"));
       }
       catch( Exception e )
       {
         gSSTErrorObj.errorCode = -999000000;
         gSSTErrorObj.errorText = "DATABASE CFG PARAMETERS NOT SET PROPERLY";
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }

       lSSTDBMethod = new SSTDBMethod(lDBDriver,lDBUrl,lDBUsr,lDBPwd);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 )
       {
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = gSSTErrorObj.errorCode;
         throw new Exception();
       }
       lDBCon = lSSTDBMethod.getSSTDBConnection();

       if ( lDBCon == null ) throw new Exception();
     }
     else
     {
       lSSTDBMethod.setConnection( gConnection );
     }
     lSSTDBMethod.gDebugFlagQryStr = gDebugFlagQryStr;
       /////////////////  IF CONNECT_IND = FALSE - ENDS ////////////////


       String lWhereText = new String();
       lWhereText = "  ";
       for ( int i = 0; i < (22); i++ )
          lWhereText = lWhereText + " ";

       if ( inEesAdmListWhereText.trim().length() > 0 )
         lWhereText = lWhereText + "WHERE "+inEesAdmListWhereText;
       else
         lWhereText = "";

       String lSqlStmt = "DELETE "+
                         "FROM   EES_ADM_LIST "+
                         lWhereText
                         ;

       sop("Sql Statement : "+lSqlStmt);

       lUpdateCount = lSSTDBMethod.executeSSTUpdate(lSqlStmt);
       if ( lSSTDBMethod.gSSTErrorObj.errorCode < 0 ) 
       { 
         gSSTErrorObj.errorCode = lSSTDBMethod.gSSTErrorObj.errorCode;
         gSSTErrorObj.sqlState  = lSSTDBMethod.gSSTErrorObj.sqlState;
         gSSTErrorObj.errorText = lSSTDBMethod.gSSTErrorObj.errorText;
         lReturnValue = -999000000+gSSTErrorObj.errorCode; 
         throw new Exception(); 
       } 
       lReturnValue = lUpdateCount; 


       /////////////////  IF CONNECT_IND = FALSE ////////////////
     if ( !gConnectInd ) 
       lSSTDBMethod.closeSSTDBConnection();
    }
    catch(Exception exp)
    {
      if ( !gConnectInd ) 
      {
        if ( props == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBAttrib == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lDBCon == null ) 
          lReturnValue = gSSTErrorObj.errorCode; 
        else 
        if ( lReturnValue < 0 ) 
          gSSTErrorObj.errorCode = lReturnValue; 
        else 
          exp.printStackTrace(); 
      }
    }
    return lReturnValue;
  }


}
