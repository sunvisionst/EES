ALTER TABLE           EES_ALUMNI
  ADD                 CONSTRAINT EES_ALUMNI_PK
  PRIMARY             KEY
  ( ORG_ID, ALUMNI_ID )
;
