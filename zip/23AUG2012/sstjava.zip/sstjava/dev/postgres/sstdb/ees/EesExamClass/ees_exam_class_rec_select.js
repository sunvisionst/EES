function EesExamClassRecSelect( inSelectFlag, inRecNum)
{
  var lSubmitObj;
  if ( inSelectFlag == 'Y' )
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;

    document.getElementById("org_id").value  = document.getElementById("org_id"+"_r"+inRecNum).value;
    document.getElementById("org_id").readOnly = true;
    document.getElementById("exam_id").value  = document.getElementById("exam_id"+"_r"+inRecNum).value;
    document.getElementById("exam_id").readOnly = true;
    document.getElementById("class_id").value  = document.getElementById("class_id"+"_r"+inRecNum).value;
    document.getElementById("class_id").readOnly = true;
    document.getElementById("class_num").value  = document.getElementById("class_num"+"_r"+inRecNum).value;
    document.getElementById("class_std").value  = document.getElementById("class_std"+"_r"+inRecNum).value;
    document.getElementById("class_section").value  = document.getElementById("class_section"+"_r"+inRecNum).value;
    document.getElementById("course_id").value  = document.getElementById("course_id"+"_r"+inRecNum).value;
    document.getElementById("course_term").value  = document.getElementById("course_term"+"_r"+inRecNum).value;
    document.getElementById("course_stream").value  = document.getElementById("course_stream"+"_r"+inRecNum).value;
    document.getElementById("exam_term").value  = document.getElementById("exam_term"+"_r"+inRecNum).value;
    document.getElementById("exam_type").value  = document.getElementById("exam_type"+"_r"+inRecNum).value;
    document.getElementById("year").value  = document.getElementById("year"+"_r"+inRecNum).value;
    document.getElementById("month").value  = document.getElementById("month"+"_r"+inRecNum).value;
    document.getElementById("academic_session").value  = document.getElementById("academic_session"+"_r"+inRecNum).value;
    document.getElementById("exam_status").value  = document.getElementById("exam_status"+"_r"+inRecNum).value;
    document.getElementById("exam_status_date").value  = document.getElementById("exam_status_date"+"_r"+inRecNum).value;
  }
  else
  {
    lSubmitObj = document.getElementById("submit1"); if ( lSubmitObj != null ) lSubmitObj.disabled = false;
    lSubmitObj = document.getElementById("submit2"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    lSubmitObj = document.getElementById("submit3"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;
    //lSubmitObj = document.getElementById("submit4"); if ( lSubmitObj != null ) lSubmitObj.disabled = true;

    document.getElementById("org_id").value = '';
    document.getElementById("org_id").readOnly = false;
    document.getElementById("exam_id").value = '';
    document.getElementById("exam_id").readOnly = false;
    document.getElementById("class_id").value = '';
    document.getElementById("class_id").readOnly = false;
    document.getElementById("class_num").value = '';
    document.getElementById("class_std").value = '';
    document.getElementById("class_section").value = '';
    document.getElementById("course_id").value = '';
    document.getElementById("course_term").value = '';
    document.getElementById("course_stream").value = '';
    document.getElementById("exam_term").value = '';
    document.getElementById("exam_type").value = '';
    document.getElementById("year").value = '';
    document.getElementById("month").value = '';
    document.getElementById("academic_session").value = '';
    document.getElementById("exam_status").value = '';
    document.getElementById("exam_status_date").value = '';
  }
}
