<?
   require_once("EesStudentMethodObj.php");

   $lSubjectCode        = "";
   $lClassId            = "";

   $lMenuOption         = $_GET['menu_option'];
   $lRequestType        = $_GET['req_type'];
   $lSubmitAction       = $_POST['submit_action'];

   $lLegendString       = $_SESSION['lLegendString']; 


   //--------------------------------------------------------------------------
   if( $lSubmitAction !== null && $lSubmitAction != 'saveSubmit' )
   {
     $lClassSubjectCode      = $_POST['subject_code'];

     $lClassSubjectCodeArr = explode( ",", $lClassSubjectCode);
     $lSubjectCode         = $lClassSubjectCodeArr[0];
     $lClassId             = $lClassSubjectCodeArr[1];
   }
   else
     $lSubjectCode           = $_POST['subject_code'];
   //--------------------------------------------------------------------------



   //--------------------------------------------------------------------------
   $lEesStudentMethodObj = new EesStudentMethodObj();  
   //$lStudentFileName     = "sst_sgi_ees_student_ext.dat";
   $lStudentFileName     = "sst_".$lOrgId."_ees_student_ext.dat";
   $lEesStudentMethodObj->lStudentFileName      = $lStudentFileName;
   $lEesStudentMethodObj->lFilteredFileName     = $lStudentFileName;
   $lEesStudentMethodObj->lFilterCriteriaValue1 = $lClassId;
   $lEesStudentMethodObj->lFilteredPosition1    = 27;

   //GETTING STUDENT ARR
   $lEesStudentTabObjArr                     = $lEesStudentMethodObj->gtEesStudentTabObjArr();
   //--------------------------------------------------------------------------




   //--------------------------------------------------------------------------
   echo "<table id=\"\" name=\"\" border=\"0\" width=\"100%\">";
   echo "<tr>"; 

   echo "<td>"; 
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Dash Board For $lLegendString</font></legend>";
   echo "<table border = \"0\" width = \"100%\"> ";
   echo "<tr>";
   echo "<td>";

     include("sst_ml_common_query_menu_box.php");

   echo "</td>";
   echo "</tr>";
   echo "</table> ";
   echo "</fieldset>";

   echo "</td>";
   echo "</tr>";
   //--------------------------------------------------------------------------



   //--------------------------------------------------------------------------
   echo "<tr>";
   echo "<td align=\"center\">";


   if( $lEesStudentTabObjArr !== null && count($lEesStudentTabObjArr) > 0 )
   {
     echo "<table border = \"1\" width = \"100%\"> ";

     echo "<tr>";
     echo "<fieldset>";
     echo "<legend><font color = \"white\" >Marks For Class ".$lClassId." and for subject ".$lSubjectCode."</font></legend>";
     echo "</fieldset>";
     echo "</tr>";

     echo "<tr>";
     include ("sst_ml_ees_subject_mark_entry_multi_include_th.php");
     echo "</tr>";

     for( $lStudRec = 1; $lStudRec < count($lEesStudentTabObjArr); $lStudRec++ )
     {
         $lEesStudentTabObj        = new EesStudentTabObj();
         $lEesStudentTabObj        = $lEesStudentTabObjArr[$lStudRec-1];

         echo "<tr>";
         include ("sst_ml_ees_subject_mark_entry_include_multi.php");
         echo "</tr>";
     }
     //echo "</tr>";
     echo "</table>";
   }
   else
   {
     echo "<Script language=\"JavaScript\">";
     echo "alert('Student File Not Found For This Class !!!.');";
     echo "</Script>";
   }

   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td>";
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Action</font></legend>";
   echo "</fieldset>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td>";
         include ("sst_ml_ees_subject_mark_entry_action_bar.php");
   echo "</td>";
   echo "<tr>";

   echo "</table> ";
?>
