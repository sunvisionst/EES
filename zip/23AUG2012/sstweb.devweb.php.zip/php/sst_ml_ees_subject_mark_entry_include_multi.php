<?
   $lFieldValue = "";

    echo "<input type=\"hidden\" 
                 id=\"org_id_$lStudRec\" 
                 name=\"org_id_$lStudRec\" 
                 value=\"SGI\"/>";

    echo "<input type=\"hidden\" 
                 id=\"student_id_$lStudRec\" 
                 name=\"student_id_$lStudRec\" 
                 value=\"$lEesStudentTabObj->student_id\"/>";

    echo "<td align=\"right\">";
    echo $lEesStudentTabObj->student_id; 
    echo "</td>";

    echo "<input type=\"hidden\" 
                 id=\"student_name_$lStudRec\" 
                 name=\"student_name_$lStudRec\" 
                 value=\"$lEesStudentTabObj->student_name\"/>";

    echo "<td align=\"right\">";
    echo $lEesStudentTabObj->student_name; 
    echo "</td>";

         
    echo "<input type=\"hidden\" 
                 id=\"exam_id_$lStudRec\" 
                 name=\"exam_id_$lStudRec\" 
                 value=\"\"/>";

    echo "<input type=\"hidden\" 
                 id=\"subject_type_$lStudRec\" 
                 name=\"subject_type_$lStudRec\" 
                 value=\"\"/>";

    echo "<input type=\"hidden\" 
                 id=\"subject_ctg_$lStudRec\" 
                 name=\"subject_ctg_$lStudRec\" 
                 value=\"$lEesStudentTabObj->roll_num\"/>";

    echo "<input type=\"hidden\" 
                 id=\"subject_code_$lStudRec\" 
                 name=\"subject_code_$lStudRec\" 
                 value=\"$lSubjectCode\"/>";

    echo "<input type=\"hidden\" 
                 id=\"paper_id_$lStudRec\" 
                 name=\"paper_id_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"class_id_$lStudRec\" 
                 name=\"class_id_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"class_num_$lStudRec\" 
                 name=\"class_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"class_std_$lStudRec\" 
                 name=\"class_std_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"class_section_$lStudRec\" 
                 name=\"class_section_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"course_id_$lStudRec\" 
                 name=\"course_id_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"course_term_$lStudRec\" 
                 name=\"course_term_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"course_stream_$lStudRec\" 
                 name=\"course_stream_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"roll_num_$lStudRec\" 
                 name=\"roll_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"enrollment_num_$lStudRec\" 
                 name=\"enrollment_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"room_num_$lStudRec\" 
                 name=\"room_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"building_id_$lStudRec\" 
                 name=\"building_id_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"floor_num_$lStudRec\" 
                 name=\"floor_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"seat_num_$lStudRec\" 
                 name=\"seat_num_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"exam_term_$lStudRec\" 
                 name=\"exam_term_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"exam_type_$lStudRec\" 
                 name=\"exam_type_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"exam_date_$lStudRec\" 
                 name=\"exam_date_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"session_id_$lStudRec\" 
                 name=\"session_id_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"exam_start_time_$lStudRec\" 
                 name=\"exam_start_time_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"exam_end_time_$lStudRec\" 
                 name=\"exam_end_time_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"pass_fail_ind_$lStudRec\" 
                 name=\"pass_fail_ind_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"attendance_status_$lStudRec\" 
                 name=\"attendance_status_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"student_status_$lStudRec\" 
                 name=\"student_status_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"copy_checked_status_$lStudRec\" 
                 name=\"copy_checked_status_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"max_mark_$lStudRec\" 
                 name=\"max_mark_$lStudRec\" 
                 value=\"$lClassId\">";

    echo "<input type=\"hidden\" 
                 id=\"obtained_mark_$lStudRec\" 
                 name=\"obtained_mark_$lStudRec\" 
                 value=\"$lClassId\">";
           
    echo "<td align=\"right\">";
    echo "<input type=\"textbox\" 
                 id=\"marks_$lStudRec\" 
                 name=\"marks_$lStudRec\" 
                 value=\"0.00\">";
    echo "</td>";
    /* 
    if( $lEesLectureAttendTabObjArr !== null && count($lEesLectureAttendTabObjArr) > 0 )
    {
      $lEesLectureAttndTabObjKey   = "SGI".$lEesStudentTabObj->student_id.$lTodayDBDate.$lClassId;

      if ( array_key_exists($lEesLectureAttndTabObjKey, $lEesLectureAttendTabObjArr) )
         $lEesLectureAttendTabObj = $lEesLectureAttendTabObjArr[$lEesLectureAttndTabObjKey];

      if( $lEesLectureAttendTabObj !== null )
        $lFieldValue = $lEesLectureAttendTabObj->attendance_status; 
    }
         
    echo "<td align=\"right\">";
    echo "<input type=\"hidden\" 
                 id=\"select_checkbox_r$lStudRec\" 
                 name=\"select_checkbox_r$lStudRec\" 
                 value=\"N\">";

    echo "<input type=\"checkbox\" 
                 id=\"attendance_sts_$lStudRec\" 
                 onClick=\"
                          {
                            if( document.form.attendance_sts_$lStudRec.checked ) 
                             document.getElementById('select_checkbox_r$lStudRec').value = 'Y';
                            else
                             document.getElementById('select_checkbox_r$lStudRec').value = 'N';
                          }
                         \" 

                 name=\"attendance_sts_$lStudRec\">";
    echo "</td>";


    if( $lFieldValue !== null && $lFieldValue == "P" )
    {
      echo "<Script language=\"JavaScript\">";  
      echo " document.getElementById('attendance_sts_$lStudRec').checked = true;";  
      echo " document.getElementById('select_checkbox_r$lStudRec').value = 'Y';"; 
      echo "</Script>";  
    }
   */


?>
