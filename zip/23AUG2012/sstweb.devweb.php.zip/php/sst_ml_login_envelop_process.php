<?
  {
    //------------------------------------------------
    if( !isset($_POST['user_id']) )
      ;
    else
       $lUserId       = $_POST['user_id'];

    if( !isset($_POST['user_password']) )
      ;
    else
       $lUserPass     = $_POST['user_password'];

    if( !isset($_POST['org_id']) )
      ;
    else
       $lOrgId       = $_POST['org_id'];

    if(!isset($_POST['action_login']))
      ;
    else
      $lSubmitAction     = $_POST['action_login'];
    //------------------------------------------------

    if( $lReturnValue < 0 )
    { 
      if( $lReturnValue == -1 )
        echo "<font color = \"red\" size = \"8\">User Not Found !!!</font>";
      else
      if( $lReturnValue == -2 )
        echo "<font color = \"red\" size = \"8\">Please Fill The User Id, Password And Org Id!!</font>";
      else
      if( $lReturnValue == -3 )
        echo "<font color = \"red\" size = \"8\">Problem In User File Contact Sunvision!!</font>";
 
      $lSessionId = "";
      // Unset all of the session variables.
      $_SESSION = array(); 
    }
  }
?>
