<?
  {
    echo "<table border=\"0\" width=\"100%\">" ;
    echo "<tr>" ;
   
    $lCurrentPage = "sst_ml_ees_subject_progress_entry_envelop.php?menu_option=eesFaculty&req_type=facAttnEntry&action=saveSubmit";
    echo"<td align=\"center\">";
    echo "<input  type =\"submit\" 
                 id   =\"save_submit\"  
                 name =\"save_submit\" 
                 onClick =\"{
                              javascript:form.action='$lCurrentPage'; 
                            }
                          \" 
                 value=\"Save Progress\">";
    echo"</td>";

    echo "</tr>" ;
    echo "<table>";
  }
?>
