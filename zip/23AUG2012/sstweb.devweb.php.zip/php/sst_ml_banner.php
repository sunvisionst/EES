<?

  echo "<td name=\"contact_td\" id=\"contact_td\" align=\"left\" width=\"15%\">";
  echo "<a href=\"../php/sst_ml_contact_envelop.php?sst_session_id=$lSessionId\"> Contacts </a>";
  echo "</td>";


  echo "<td name=\"banner_td\" id=\"banner_td\" align=\"center\">";
  //echo "<img src=\"../images/sst_ees_main_jp.gif\" width=\"230px\"/>";
  echo "</td>";


  echo "<td name=\"home_td\" id=\"home_td\" align=\"right\" width=\"15%\">";
  echo "<a href=\"../php/sst_ml_home_product_envelop.php?sst_session_id=$lSessionId\">Home</a>";
  echo "</td>";

 
?>
