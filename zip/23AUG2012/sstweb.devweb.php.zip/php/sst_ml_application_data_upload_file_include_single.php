<?
   echo "<table border = \"0\" width = \"100%\">";
   echo "<tr>";

   //--------------------------------------------------------------------------------
   echo "<td>";
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Uploaded File List</font></legend>";
   echo "<table border = \"0\" width = \"100%\">";
   echo "<tr>";
   echo "<td>";
   echo "<table border = \"0\" width = \"100%\">";
   if( $lReturnValue < 0 )
    ;
   else
   {
    for( $lRecNum = 0; $lRecNum < count($_FILES['upload_file']['name']); $lRecNum++ )
    {
      if( strlen($_FILES['upload_file']['name'][$lRecNum]) > 0 ) //CHECk IF FILE NAME IS GIVEN
      {
        echo "<tr>";
        echo "<td>";
        echo ($lRecNum+1).":-<font color=\"green\">"."<b>".strtoupper($_FILES['upload_file']['name'][$lRecNum])."</b></font>";
        echo "</td>";
        echo "</tr>";
      }
    }
   }         
   echo "</table>";
   echo "</td>";
   echo "</tr>";
   echo "</table>";
   echo "</fieldset>";
   echo "</td>";
   //--------------------------------------------------------------------------------



   //--------------------------------------------------------------------------------
   echo "<td width = \"1%\">";
   echo "</td>";
   //--------------------------------------------------------------------------------




   //--------------------------------------------------------------------------------
   echo "<td>";
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Browse Excel File</font></legend>";
   echo "<table border = \"0\" width = \"100%\">";

   echo "<tr>";
   echo "<td align = \"left\">";
   echo "Employee File Name ";
   echo "</td>";

   echo "<td align = \"left\">";
   echo "<input type=\"file\" 
                name=\"upload_file[]\" 
                id=\"upload_file[]\" 
         />";

//   echo "<input type=\"hidden\" 
 //               name=\"employee_filename\" 
  //              id=\"employee_filename\" 
   //             value=\"employee_file\" 
    //     />";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td align = \"left\">";
   echo "Class File Name ";
   echo "</td>";

   echo "<td align = \"left\">";
   echo "<input type=\"file\" 
                name=\"upload_file[]\" 
                id=\"upload_file[]\" 
         />";

   //echo "<input type=\"hidden\" 
     //           name=\"class_filename\" 
       //         id=\"class_filename\" 
         //       value=\"class_file\" 
         ///>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td align = \"left\">";
   echo "Student File Name ";
   echo "</td>";

   echo "<td align = \"left\">";
   echo "<input type=\"file\" 
                name=\"upload_file[]\" 
                id=\"upload_file[]\" 
         />";

//   echo "<input type=\"hidden\" 
 //               name=\"student_filename\" 
  //              id=\"student_filename\" 
   //             value=\"student_file\" 
    //     />";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td align = \"left\">";
   echo "Subject File Name ";
   echo "</td>";

   echo "<td align = \"left\">";
   echo "<input type=\"file\" 
                name=\"upload_file[]\" 
                id=\"upload_file[]\" 
         />";

//   echo "<input type=\"hidden\" 
 //               name=\"subject_filename\" 
  //              id=\"subject_filename\" 
   //             value=\"subject_file\" 
    //     />";
   echo "</td>";
   echo "</tr>";

   echo "</table>";
   echo "</fieldset>";
   echo "</td>";
   //--------------------------------------------------------------------------------

   echo "</tr>";


   echo "<tr>";
   echo "<td colspan = \"3\" align = \"center\">";
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Action</font></legend>";
   echo "<input type=\"hidden\" 
                name=\"action_submit\" 
                id=\"action_submit\" 
                value=\"\" 
         />";

   echo "<input type=\"submit\" 
                name=\"submit\" 
                value=\"Submit\" 
                onclick=\"
                         {
                           document.getElementById('action_submit').value = 'uploaddata';
                         }
                        \" 
         />";
   echo "</fieldset>";
   echo "</td>";
   echo "</tr>";
   //--------------------------------------------------------------------------------
   echo "</table>";
?>
