<?
  echo "<th align = \"right\">User Id</th>";
  echo "<th align = \"right\">Employee Id</th>";
  echo "<th align = \"right\">Employee Name</th>";
?>
