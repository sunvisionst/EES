<?
 { 
   $lSubjectAllocationFileName = "sst_".$lOrgId."_ees_subject_allocation_ext.dat";
   //$lSubjectAllocationFileName = "sst_sgi_ees_subject_allocation_ext.dat";

   $lEesSubjectAllocationMethodObj = new EesSubjectAllocationMethodObj();
   
   $lEesSubjectAllocationMethodObj->lSubjectAllocationFileName     = $lSubjectAllocationFileName;
   //$lEesSubjectAllocationMethodObj->lFilterCriteriaValue1 = "SGI";
   $lEesSubjectAllocationMethodObj->lFilterCriteriaValue1 = $lOrgId;
   $lEesSubjectAllocationMethodObj->lFilteredPosition1    = 0;
   $lEesSubjectAllocationMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
   $lEesSubjectAllocationMethodObj->lFilteredPosition2    = 2;

   $lEesSubjectAllocationTabObjArr = $lEesSubjectAllocationMethodObj->gtSubjectAllocationTabObjArr();

    echo "<td width = '70%'>";
    echo " <table border = '0' width = '100%'>";


    /*
    if( $lRequestType !== null && $lRequestType == 'facSubProgEntry' )
    {
      /*
      $_SESSION['lFilterFileName']        = "sst_sgi_ees_lecture_plan_ext.dat";
      $_SESSION['lFilterCriteriaValue1']  = "SGI";// CRITERIA VALUE ON WHICH FILTERING IS DONE.;
      $_SESSION['lFilterPositionValue1']  = 0; //INDEX POSTION WHERE WE SEARCH THE VALUE
      $_SESSION['lFilterPositionValue2']  = 1; //INDEX POSTION WHERE WE SEARCH THE VALUE;
      $_SESSION['lFieldValueIndexPosit']  = "2,7"; //INDEX POSITION FOR VALUE WHICH POP ON DD
      $_SESSION['lElementId']             = "topic_id"; //INDEX POSITION FOR VALUE WHICH POP ON DD
      * /
   }
   */
   echo "<input type=\"hidden\" id = \"class_id\" name=\"class_id\" value=\"\"/>";


    echo "  <tr>";

    //SUBJECT DD
    echo "   <td>";
    echo "  Subject Id ";
    echo "   </td>";

    echo "   <td>";
    echo "    <SELECT id = 'subject_code'";
    echo "            name = 'subject_code'"; 
    if( $lRequestType !== null && $lRequestType != 'facMarkEntry' )
    {
      echo "            onChange=\" ";
      echo "                      {";
      echo "                        var lSubjectId = ((this.value).split(','))[0];";
      if( $lRequestType !== null && $lRequestType == 'facAttnEntry' )
      {
         //$lFilterFileName = "sst_sgi_ees_timetable_model_".$lCurrentYear."_ext.dat";
         $lFilterFileName = "sst_".$lOrgId."_ees_timetable_model_".$lCurrentYear."_ext.dat";

         $_SESSION['lFilterFilePath']        = "/refdb/datafiledir/"; 
         $_SESSION['lFilterFileName']        = $lFilterFileName; 
         $_SESSION['lFilterCriteriaValue1']  = $lHrEmployeeTabObjGlobal->employee_id;//CRITERIA VALUE ON WHICH FILTERING IS DONE.
         $_SESSION['lFilterPositionValue1']  = 14;//INDEX POSTION WHERE WE SEARCH THE VALUE; 
         $_SESSION['lFilterPositionValue2']  = 7;//INDEX POSTION WHERE WE SEARCH THE VALUE;
  
         $_SESSION['lFieldValueIndexPosit']  = "2";//INDEX POSITION FOR VALUE WHICH POP ON DD
         $_SESSION['lElementId']             = "period_num";
  
        echo "                        invokeRefresh('sst_ml_ajax_action.php', 'period_num_td', lSubjectId );";
      }
      else
      if( $lRequestType !== null && $lRequestType == 'facSubProgEntry' )
      {
        $_SESSION['lFilterFilePath']        = "/refdb/datafiledir/"; 
        //$_SESSION['lFilterFileName']        = "sst_sgi_ees_lecture_plan_ext.dat";
        $_SESSION['lFilterFileName']        = "sst_".$lOrgId."_ees_lecture_plan_ext.dat";
        //$_SESSION['lFilterCriteriaValue1']  = "SGI";// CRITERIA VALUE ON WHICH FILTERING IS DONE.;
        $_SESSION['lFilterCriteriaValue1']  = $lOrgId;// CRITERIA VALUE ON WHICH FILTERING IS DONE.;
        $_SESSION['lFilterPositionValue1']  = 0; //INDEX POSTION WHERE WE SEARCH THE VALUE
        $_SESSION['lFilterPositionValue2']  = 1; //INDEX POSTION WHERE WE SEARCH THE VALUE;
        $_SESSION['lFieldValueIndexPosit']  = "2,7"; //INDEX POSITION FOR VALUE WHICH POP ON DD
        $_SESSION['lElementId']             = "topic_id"; //INDEX POSITION FOR VALUE WHICH POP ON DD
  
        echo "                        invokeRefresh('sst_ml_ajax_action.php', 'topic_id_td', lSubjectId );";
      }
      echo "                      }";
    }
    echo "                      \">";
    echo "    </SELECT>";
    echo "   </td>";
    //SUBJECT DD END

    echo "  </tr>";

    if( $lRequestType !== null && $lRequestType == 'facSubProgEntry' )
    {
      //TOPIC ID DD
      echo "  <tr>";
      echo "   <td>";
      echo "  Topic Id ";
      echo "   </td>";

      echo "   <td id=\"topic_id_td\" name=\"topic_id_td\">";
      echo "    <SELECT id = 'topic_id'";
      echo "            name = 'topic_id'"; 
      echo "    \">";
      echo "    <option value=\"\">SELECT TOPIC</option>";
      echo "  </tr>";
      //TOPIC ID DD
    }

    if( $lRequestType !== null && $lRequestType == 'facAttnEntry' )
    {
      echo "  <tr>";

      //PERIOD DD ON CHANGE OF SUBJECT
      echo "   <td>";
      echo "  Period Num";
      echo "   </td>";

      echo "   <td name=\"period_num_td\" id=\"period_num_td\" >";
      echo "    <SELECT id = 'period_num' 
                      name = 'period_num'>";
      echo "    <option value=\"\">SELECT PERIOD</option>";
      echo "    </SELECT>";
      echo "   </td>";

      echo "  </tr>";

      echo "  <tr>";
      //SECTION DD
      echo "   <td>";
      echo " Class Section ";
      echo "   </td>";
        
      echo "   <td>";
      echo "    <SELECT id = 'class_section' name = 'class_section'>";
      echo "      <Script language = \"JavaScript\">";
                         include("../cache/ITSGN/ees_classsec.js");
      echo "      </Script>";
      echo "    </SELECT>";
      echo "   </td>";
      //SECTION DD END

      echo "  </tr>";
    }

    echo " </table>";
    echo "</td>";

    if( $lEesSubjectAllocationTabObjArr !== null && count($lEesSubjectAllocationTabObjArr) > 0 )
    {
      echo "<Script language = \"JavaScript\">";
      echo "{";
      echo "  addOptVal( 'subject_code', '', 'SELECT SUBJECT' );";
      for( $lRecNum = 0; $lRecNum < count($lEesSubjectAllocationTabObjArr); $lRecNum++ )
      {
        $lEesSubjectAllocationTabObj = new EesSubjectAllocationTabObj(); 
        $lEesSubjectAllocationTabObj = $lEesSubjectAllocationTabObjArr[$lRecNum];
 
        echo "  addOptVal(  'subject_code'";
        if( $lRequestType !== null && $lRequestType == 'facSubProgEntry' || $lRequestType == 'facMarkEntry' )
          echo "                , '".$lEesSubjectAllocationTabObj->subject_code.",".$lEesSubjectAllocationTabObj->class_id."'";
        else
          echo "                , '".$lEesSubjectAllocationTabObj->subject_code."'";
        echo "                , '".$lEesSubjectAllocationTabObj->subject_code." (".$lEesSubjectAllocationTabObj->class_id.")'";
        echo "             );";
        
      }
      echo "}";
      echo "</Script>";
    }
    else
    {
      echo "<Script language = \"JavaScript\">";
      echo "  addOptVal( 'subject_code', '', 'SUBJECT NOT YET DEFINED' );";
      echo "</Script>";
    } 


    /*
    if( $lRequestType !== null && $lRequestType == 'facSubProgEntry' )
    {
      echo "<Script language = \"JavaScript\">";
      echo "{";
      echo "  addOptVal( 'class_id', '', 'SELECT CLASS' );";
      for( $lRecNum = 0; $lRecNum < count($lEesSubjectAllocationTabObjArr); $lRecNum++ )
      {
        $lEesSubjectAllocationTabObj = new EesSubjectAllocationTabObj(); 
        $lEesSubjectAllocationTabObj = $lEesSubjectAllocationTabObjArr[$lRecNum];
 
        echo "  addOptVal(  'class_id'
                              , '".$lEesSubjectAllocationTabObj->class_id."'
                              , '".$lEesSubjectAllocationTabObj->class_id." (".$lEesSubjectAllocationTabObj->class_id.")' 
                           );";
        
      }
      echo "}";
      echo "</Script>";
    }
    else
    {
      echo "<Script language = \"JavaScript\">";
      echo "  addOptVal( 'class_id', '', 'CLASS NOT YET DEFINED' );";
      echo "</Script>";
    } 
   */
 }
?>
