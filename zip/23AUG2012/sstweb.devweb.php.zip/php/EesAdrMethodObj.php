<?
   require_once("EesAdrTabObj.php");
   require_once("sst_ml_filter_record.php"); 


  class EesAdrMethodObj
  {
     //--------------------------------------------------------------------------------------------------
     public  $lSubjectProgFileName          = null; //ASSIGN FILE NAME TO FILTER
     //public  $lEesAdrTabObjFrmFileArr       = array(); //ASSIGN FILE NAME TO FILTER
     //--------------------------------------------------------------------------------------------------


     //--------------------------------------------------------------------------------------------------
     public  $lFilteredFilePath             = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilteredFileName             = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilterCriteriaValue1         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition1            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue2         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition2            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue3         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition3            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue4         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition4            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue5         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition5            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     //--------------------------------------------------------------------------------------------------


     public function gtEesAdrRecByCriteria()
     {
       $lEesAdrTabObjArr = array();
       $lSSTFilter             = new SSTFilter();

       //FILTER PART START
       $lSSTFilter->lFilteredFileRelPath  = $this->lFilteredFilePath; //ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilteredFileName     = $this->lFilteredFileName; //ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue3 = $this->lFilterCriteriaValue3; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition3    = $this->lFilteredPosition3; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue4 = $this->lFilterCriteriaValue4; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition4    = $this->lFilteredPosition4; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue5 = $this->lFilterCriteriaValue5; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition5    = $this->lFilteredPosition5; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

       //GETTING FILTERED RECORD ARR
       $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                

       if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
       {
         for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
         {
            //PREP TABOBJ OBJECT
            $lEesAdrTabObj     = new EesAdrTabObj();
            $lFieldArr  = explode( ",", $lFilteredRecordArr[$lRecNum] );

            $lEesAdrTabObj->org_id                            = $lFieldArr[0];
            $lEesAdrTabObj->employee_id                       = $lFieldArr[1];
            $lEesAdrTabObj->period_num                        = $lFieldArr[2];
            $lEesAdrTabObj->adr_date                          = $lFieldArr[3];
            $lEesAdrTabObj->topic_id                          = $lFieldArr[4];
            $lEesAdrTabObj->adr_start_time                    = $lFieldArr[5];
            $lEesAdrTabObj->adr_end_time                      = $lFieldArr[6];
            $lEesAdrTabObj->lecture_num                       = $lFieldArr[7];
            $lEesAdrTabObj->subject_code                      = $lFieldArr[8];
            $lEesAdrTabObj->topic_percent_covered             = $lFieldArr[9];
            $lEesAdrTabObj->class_id                          = $lFieldArr[10];
            $lEesAdrTabObj->class_num                         = $lFieldArr[11];
            $lEesAdrTabObj->class_std                         = $lFieldArr[12];
            $lEesAdrTabObj->class_section                     = $lFieldArr[13];
            $lEesAdrTabObj->course_id                         = $lFieldArr[14];
            $lEesAdrTabObj->course_term                       = $lFieldArr[15];
            $lEesAdrTabObj->course_stream                     = $lFieldArr[16];  

            $lEesAdrTabObjArr[$lRecNum-1] = $lEesAdrTabObj;
         }
       }

       if( $lEesAdrTabObjArr !== null && count($lEesAdrTabObjArr) > 0 )
         return $lEesAdrTabObjArr;
       else
         return null;
    }


    private function checkEesAdrRec()
    {
      $lEesAdrTabObjFrmFileArr = array();
      //-----------------------------------------------------------------------------
      //READ FILE 
      //-----------------------------------------------------------------------------

      //GETTING FILE SOURCE
      //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/inbox/".$this->lSubjectProgFileName;
      //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/refdb/datafiledir/".$this->lSubjectProgFileName; 
      //$lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      //$lFileNamePath .= "SGI/refdb/menufiledir/".$this->lSubjectProgFileName;

      $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      $lFileNamePath .= $this->lSubjectProgFileName;

      try
      {
        if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
        {
          //Open the file
          $lFileHandler = fopen($lFileNamePath, "r") or die("FILE NOT OPEN FOR READING!!!");
           while (!feof($lFileHandler))
           {
              $lEesAdrTabObj = new EesAdrTabObj();
              $lEesAdrTabObjArrKey = "";

              if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )   //READ LINE BY LINE 
                $lFieldValueArr = explode( ",", $lRecordLine );
              else
                break;
                     
              $lEesAdrTabObj->org_id                            = $lFieldValueArr[0];
              $lEesAdrTabObj->employee_id                       = $lFieldValueArr[1];
              $lEesAdrTabObj->period_num                        = $lFieldValueArr[2];
              $lEesAdrTabObj->adr_date                          = $lFieldValueArr[3];
              $lEesAdrTabObj->topic_id                          = $lFieldValueArr[4];
              $lEesAdrTabObj->adr_start_time                    = $lFieldValueArr[5];
              $lEesAdrTabObj->adr_end_time                      = $lFieldValueArr[6];
              $lEesAdrTabObj->lecture_num                       = $lFieldValueArr[7];
              $lEesAdrTabObj->subject_code                      = $lFieldValueArr[8];
              $lEesAdrTabObj->topic_percent_covered             = $lFieldValueArr[9];
              $lEesAdrTabObj->class_id                          = $lFieldValueArr[10];
              $lEesAdrTabObj->class_num                         = $lFieldValueArr[11];
              $lEesAdrTabObj->class_std                         = $lFieldValueArr[12];
              $lEesAdrTabObj->class_section                     = $lFieldValueArr[13];
              $lEesAdrTabObj->course_id                         = $lFieldValueArr[14];
              $lEesAdrTabObj->course_term                       = $lFieldValueArr[15];
              $lEesAdrTabObj->course_stream                     = $lFieldValueArr[16];  

              //PREP KEY 
              $lEesAdrTabObjArrKey = $lFieldValueArr[0].$lFieldValueArr[1].$lFieldValueArr[2].$lFieldValueArr[3].$lFieldValueArr[4];
              $lEesAdrTabObjFrmFileArr[$lEesAdrTabObjArrKey] = $lEesAdrTabObj;
           }  
        }
      }
      catch(Exception $Ex)
      {
        echo $Ex->getMessage();
      }

      // Close the file
      fclose($lFileHandler); 

      if( $lEesAdrTabObjFrmFileArr !== null && count( $lEesAdrTabObjFrmFileArr ) > 0 )
        return $lEesAdrTabObjFrmFileArr;
      else
        null; 
    }



    public function insEesSubjectProgress()
    {
      $lCSVFileData = "";
      $lEesAdrTabObjArrKey = "";
      $lEesAdrTabObj       = new EesAdrTabObj();

      //GETTING FILE SOURCE
      //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/inbox/".$this->lSubjectProgFileName;
      //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/inbox/".$this->lSubjectProgFileName; 
      //$lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      //$lFileNamePath .= "SGI/inbox/".$this->lSubjectProgFileName;

      $lFileNamePath  = $_SESSION['SST_MLA_INBOX_DIR'];
      $lFileNamePath .= $this->lSubjectProgFileName;

      //CALL A FUNCTION TO CHECK IF DATA EXISTS
      $lEesAdrTabObjFrmFileArr = $this -> checkEesAdrRec();

       //CHANGE FILE PERMISSION IF FILE EXISTS
       if( $lEesAdrTabObjFrmFileArr !== null && count($lEesAdrTabObjFrmFileArr) > 0 )
       { 
         $lFilePermissionMode = substr(sprintf('%o', fileperms($lFileNamePath)), -4);
         //CHECK FOR THE PERMISSION MODE
         if($lFilePermissionMode !== null && $lFilePermissionMode == "0644")
            chmod($lFileNamePath, 0777);
       } 
         
      try
      {
    
        $lOrgId                         = str_replace(" ","",$_POST['org_id']);
        $lEmployeeId                    = str_replace(" ","",$_POST['employee_id']);
        $lPeriodNum                     = str_replace(" ","",$_POST['period_num']);
        $lAdrDate                       = str_replace(" ","",$_POST['adr_date']);
        $lTopicId                       = str_replace(" ","",$_POST['topic_id']);
        $lAdrStartTime                  = str_replace(" ","",$_POST['adr_start_time']);
        $lAdrEndTime                    = str_replace(" ","",$_POST['adr_end_time']);
        $lLectureNum                    = str_replace(" ","",$_POST['lecture_num']);
        $lSubjectCode                   = str_replace(" ","",$_POST['subject_code']);
        $lTopicPercentCovered           = str_replace(" ","",$_POST['topic_percent_covered']);
        $lClassId                       = str_replace(" ","",$_POST['class_id']);
        $lClassNum                      = str_replace(" ","",$_POST['class_num']);
        $lClassStd                      = str_replace(" ","",$_POST['class_std']);
        $lClassSection                  = str_replace(" ","",$_POST['class_section']);
        $lCourseId                      = str_replace(" ","",$_POST['course_id']);
        $lCourseTerm                    = str_replace(" ","",$_POST['course_term']);
        $lCourseStream                  = str_replace(" ","",$_POST['course_stream']);


        //Open the file and erase the contents if any
        $lFileHandler = fopen($lFileNamePath, "w") or die("FILE NOT OPEN FOR WRITING DATA !!!");

        if( $lEesAdrTabObjFrmFileArr !== null && count($lEesAdrTabObjFrmFileArr) > 0 )
        {
           //PREP KEY 
           $lEesAdrTabObjArrKey = $lOrgId.$lEmployeeId.$lPeriodNum.$lAdrDate.$lTopicId; 
           if( array_key_exists($lEesAdrTabObjArrKey, $lEesAdrTabObjFrmFileArr)) // check if key exists in array
           {
             //prep Tab obj to insert on key position
             $lEesAdrTabObj->org_id                            = $lOrgId;
             $lEesAdrTabObj->employee_id                       = $lEmployeeId;
             $lEesAdrTabObj->period_num                        = $lPeriodNum;
             $lEesAdrTabObj->adr_date                          = $lAdrDate;
             $lEesAdrTabObj->topic_id                          = $lTopicId;
             $lEesAdrTabObj->adr_start_time                    = $lAdrStartTime;
             $lEesAdrTabObj->adr_end_time                      = $lAdrEndTime;
             $lEesAdrTabObj->lecture_num                       = $lLectureNum;
             $lEesAdrTabObj->subject_code                      = $lSubjectCode;
             $lEesAdrTabObj->topic_percent_covered             = $lTopicPercentCovered;
             $lEesAdrTabObj->class_id                          = $lClassId;
             $lEesAdrTabObj->class_num                         = $lClassNum;
             $lEesAdrTabObj->class_std                         = $lClassStd;
             $lEesAdrTabObj->class_section                     = $lClassSection;
             $lEesAdrTabObj->course_id                         = $lCourseId;
             $lEesAdrTabObj->course_term                       = $lCourseTerm;
             $lEesAdrTabObj->course_stream                     = $lCourseStream;  

             foreach( $lEesAdrTabObjFrmFileArr as $lKey => &$lValue ) //& is use for refrence of same element in the array
             {
                if( $lKey == $lEesAdrTabObjArrKey ) 
                {
                  //$lEesAdrTabObjFrmFileArr[$lKey] = $lEesAdrTabObj;
                  $lValue = $lEesAdrTabObj;//replacing value from the current in the array
                } 
             }

             //Get the All  the key array of the 
             $lEesAdrTabobjFrmFileKeysArr = array_keys( $lEesAdrTabObjFrmFileArr );

             if( $lEesAdrTabobjFrmFileKeysArr !== null && count($lEesAdrTabobjFrmFileKeysArr) > 0 )
             {
                for( $lKeyIdx = 0; $lKeyIdx < count( $lEesAdrTabobjFrmFileKeysArr ); $lKeyIdx++ )
                {
                  $lEesAdrTabObj       = new EesAdrTabObj();
                  $lEesAdrTabObj       = $lEesAdrTabObjFrmFileArr[$lEesAdrTabobjFrmFileKeysArr[$lKeyIdx]];  

                  $lCSVFileData = $lEesAdrTabObj->org_id.",".$lEesAdrTabObj->employee_id.",".$lEesAdrTabObj->period_num.",";
                  $lCSVFileData .= $lEesAdrTabObj->adr_date.",".$lEesAdrTabObj->topic_id.",".$lEesAdrTabObj->adr_start_time.",";
                  $lCSVFileData .= $lEesAdrTabObj->adr_end_time.",".$lEesAdrTabObj->lecture_num.",";
                  $lCSVFileData .= $lEesAdrTabObj->subject_code.",".$lEesAdrTabObj->topic_percent_covered.",";
                  $lCSVFileData .= $lEesAdrTabObj->class_id.",".$lEesAdrTabObj->class_num.",".$lEesAdrTabObj->class_std.",";
                  $lCSVFileData .= $lEesAdrTabObj->class_section.",".$lEesAdrTabObj->course_id.",";
                  $lCSVFileData .= $lEesAdrTabObj->course_term.",".$lEesAdrTabObj->course_stream;

                  //Write the data to the file
                  fwrite($lFileHandler, $lCSVFileData);
                } 
             }
           }
           else
           {  //WHEN FILE EXISTS AND NO MATCHING RECORDS
             //Get the All  the key array of the 
             $lEesAdrTabobjFrmFileKeysArr = array_keys( $lEesAdrTabObjFrmFileArr );

             if( $lEesAdrTabobjFrmFileKeysArr !== null && count($lEesAdrTabobjFrmFileKeysArr) > 0 )
             {
                for( $lKeyIdx = 0; $lKeyIdx < count( $lEesAdrTabobjFrmFileKeysArr ); $lKeyIdx++ )
                {
                  $lEesAdrTabObj       = new EesAdrTabObj();
                  $lEesAdrTabObj       = $lEesAdrTabObjFrmFileArr[$lEesAdrTabobjFrmFileKeysArr[$lKeyIdx]];  

                  $lCSVFileData = $lEesAdrTabObj->org_id.",".$lEesAdrTabObj->employee_id.",".$lEesAdrTabObj->period_num.",";
                  $lCSVFileData .= $lEesAdrTabObj->adr_date.",".$lEesAdrTabObj->topic_id.",".$lEesAdrTabObj->adr_start_time.",";
                  $lCSVFileData .= $lEesAdrTabObj->adr_end_time.",".$lEesAdrTabObj->lecture_num.",";
                  $lCSVFileData .= $lEesAdrTabObj->subject_code.",".$lEesAdrTabObj->topic_percent_covered.",";
                  $lCSVFileData .= $lEesAdrTabObj->class_id.",".$lEesAdrTabObj->class_num.",".$lEesAdrTabObj->class_std.",";
                  $lCSVFileData .= $lEesAdrTabObj->class_section.",".$lEesAdrTabObj->course_id.",";
                  $lCSVFileData .= $lEesAdrTabObj->course_term.",".$lEesAdrTabObj->course_stream;

                  //Write the data to the file
                  fwrite($lFileHandler, $lCSVFileData);
                } 
             }

             $lCSVFileData = $lOrgId.",".$lEmployeeId.",".$lPeriodNum.",".$lAdrDate.",".$lTopicId.",".$lAdrStartTime.",".$lAdrEndTime.",".$lLectureNum.",".$lSubjectCode.",".$lTopicPercentCovered.",".$lClassId.",".$lClassNum.",".$lClassStd.",".$lClassSection.",".$lCourseId.",".$lCourseTerm.",".$lCourseStream; 

             //Write the data to the file
             fwrite($lFileHandler, $lCSVFileData);
           }
        }
        else
        {
          //WHEN NO FILE EXISTS
          $lCSVFileData = $lOrgId.",".$lEmployeeId.",".$lPeriodNum.",".$lAdrDate.",".$lTopicId.",".$lAdrStartTime.",".$lAdrEndTime.",".$lLectureNum.",".$lSubjectCode.",".$lTopicPercentCovered.",".$lClassId.",".$lClassNum.",".$lClassStd.",".$lClassSection.",".$lCourseId.",".$lCourseTerm.",".$lCourseStream; 

          // Write the data to the file
          fwrite($lFileHandler, $lCSVFileData);
        }
      }
      catch(Exception $Ex)
      {
        echo $Ex->getMessage();
      }
      // Close the file
      fclose($lFileHandler); 
    }
  }
?>
