<?
  echo "<table border=\"0\" width=\"100%\">";
  echo "<tr>";
  echo "<td>";

  echo "<div class=\"container\">";
  echo "<table border=\"0\" width=\"100%\">";

  echo "<tr>";
  echo "<td colspan=\"2\" align=\"center\" class = \"txtcontent\">";
  echo "Data Colloection Process";
  echo "</td>";
  echo "</tr>";


  echo "<tr>";
  echo "<td width=\"30%\" class=\"td\">";
  echo "<div id=\"archives\" class=\"boxed\">";
  echo "            <ul>";
  echo "                        <li><a href=\"#\">Academic Session</a></li>";
  echo "                        <li><a href=\"#\">Class</a></li>";
  echo "                        <li><a href=\"#\">Subject</a></li>";
  echo "                        <li><a href=\"#\">Student</a></li>";
  echo "                        <li><a href=\"#\">Fee Detail</a></li>";
  echo "                        <li><a href=\"#\">Subject Allocation</a></li>";
  echo "            </ul>";

  echo "</div>";
  echo "</td>";
 
  echo "<td width=\"70%\" valign=\"top\" align=\"center\">";
  echo "<table border=\"0\" width=\"100%\">";

  echo "<tr>";

  echo "<form enctype=\"multipart/form-data\" action=\"sst_ml_upload_file.php\" method=\"post\">";
  echo "<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"2048000\">";
  echo "Source File: <input name=\"userfile\" type=\"file\" /><br />";
  echo "<input type=\"submit\" value=\"Upload\" />";
  echo "</form>";

  echo "</tr>";


  echo "</table>";
  echo "</div>";

  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>
