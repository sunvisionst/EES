<?
  echo "<title>Academic IT Enabler By Sunvision Software Technologies</title>";
  echo "<link href=\"../css/gn_php_css.css\" rel=\"stylesheet\" type=\"text/css\" />";
?>
