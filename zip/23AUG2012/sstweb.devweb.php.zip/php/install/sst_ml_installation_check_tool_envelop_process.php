<?
  echo "<table border=\"0\" width=\"100%\">";
  echo "<tr>";
  echo "<td>";


  echo "<div class=\"container\">";
  echo "<table border=\"0\" width=\"100%\">";
  echo "<tr>";
  echo "<td class=\"header\" colspan=\"3\">";
  echo "Install Tool";
  echo "</td>";
  echo "</tr>";


  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Php";
  echo "</td>";
  echo "<td class =\"txtcontent\" align=\"center\">";
  echo "ver 1.04.02";
  echo "</td>";

  echo "<td>";
  echo "<a href=\"#\">Install</a>";
  if( $lSSTInstallationMethod->lALREADY_INSTALL_PHP == 'true' )
  {
  }
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Apache Tomcat";
  echo "</td>";
  echo "<td class =\"txtcontent\" align=\"center\">";
  echo "ver 1.04.02";
  echo "</td>";
  echo "<td>";
  echo "<a href=\"#\">Install</a>";
  if( $lSSTInstallationMethod->lALREADY_INSTALL_APACHE == 'true' )
  {
  }
  echo "</td>";
  echo "</tr>";


  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Browser(mozilla)";
  echo "</td>";
  echo "<td class =\"txtcontent\" align=\"center\">";
  echo "ver 1.04.02";
  echo "</td>";
  echo "<td>";
  echo "<a href=\"#\">Install</a>";

  if( $lSSTInstallationMethod->lBROWSER_INSTALLED == 'true' )
  {
  }
  echo "</td>";
  echo "</tr>";

  echo "</table>";
  echo "</div>"; 

  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>

