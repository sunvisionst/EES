<?
   echo "<table border=\"0\" width=\"100%\">"; 

   echo "<tr>"; 
   echo "<td>"; 

   if( $lCurrentAction !== null && $lCurrentAction == 'preInstall' )
      require_once("sst_ml_installation_check_pre_envelop_process.php");
   else
   if( $lCurrentAction !== null && $lCurrentAction == 'toolInstall' )
      require_once("sst_ml_installation_check_tool_envelop_process.php");
   else
   if( $lCurrentAction !== null && $lCurrentAction == 'registration' )
      require_once("sst_ml_installation_registration_envelop_process.php");
   else
   if( $lCurrentAction !== null && $lCurrentAction == 'finalize' )
      require_once("sst_ml_installation_finalize_envelop_process.php");

   echo "</td>"; 
   echo "</tr>"; 

   echo "</table>"; 
?>
