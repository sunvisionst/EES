<?

   echo "<table border=\"0\" width=\"100%\">";

   echo "<tr>";
   echo "<td align=\"center\" colspan=\"4\">";
   echo "<h2 class=\"title\">Registration</h2>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td colspan = \"2\">";
   echo "Note :- <u><font color=\"green\">Mark <font color=\"red\">*</font> Are Mandatory</font></u>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_first_name\" name =\"First Name\" abbr =\"First Name\">";
   echo "<font size=\"2\">First Name</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"first_name\" name=\"first_name\"/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_last_name\" name =\"Last Name\" abbr =\"Last Name\">";
   echo "<font size=\"2\">Last  Name</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"last_name\" name=\"last_name\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_position\" name =\"Position\" abbr =\"Position\">";
   echo "<font size=\"2\">Your Positon</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"position\" name=\"position\"/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_org_name\" name =\"Org Name\" abbr =\"Org Name\">";
   echo "<font size=\"2\">Org Name</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"org_name\" name=\"org_name\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_org_type\" name =\"Org Type\" abbr =\"Org Type\">";
   echo "<font size=\"2\">Org Type</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"org_type\" name=\"org_type\"/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_org_ctg\" name =\"Org Category\" abbr =\"Org Category\">";
   echo "<font size=\"2\">Org Category</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"org_ctg\" name=\"org_ctg\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_org_id\" name =\"Org Id\" abbr =\"Org Id\">";
   echo "<font size=\"2\">Org Id</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"text\" id=\"org_id\" name=\"org_id\" value=\"SST_DEMO\" READONLY/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_address\" name =\"Address\" abbr =\"Address\">";
   echo "<font size=\"2\">Address Detail</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"address\" name=\"address\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_contact\" name =\"Contact\" abbr =\"Contact\">";
   echo "<font size=\"2\">Contact</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"contact\" name=\"contact\"/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_phone\" name =\"Phone\" abbr =\"Phone\">";
   echo "<font size=\"2\">Phone</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"phone\" name=\"phone\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_mobile\" name =\"Mobile\" abbr =\"Mobile\">";
   echo "<font size=\"2\">Mobile</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"mobile\" name=\"mobile\"/>";
   echo "</td>";

   //echo "</tr>";

   //echo "<tr>";

   echo "<td align=\"right\" id =\"lable_email\" name =\"Email\" abbr =\"Email\">";
   echo "<font size=\"2\">Email</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"email\" name=\"email\"/>";
   echo "</td>";

   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_website\" name =\"Website\" abbr =\"Website\">";
   echo "<font size=\"2\">Website</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"textbox\" id=\"website\" name=\"website\"/>";
   echo "</td>";

   echo "</tr>";


   //ADMIN PASSWORD SECTION START
   echo "<tr>";
   echo "<td colspan=\"4\">";
   echo "<fieldset>";
   echo "<legend><font size=\"2\">Admin Info</font></legend>";
   echo "<table border=\"0\" width=\"100%\">";
  
   /*
   echo "<tr>";
   echo "<td align=\"right\">";
   echo "<font size=\"2\">User</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type  =\"hidden\"
                id    =\"emp_type\"
                name  =\"emp_type\"
                value =\"admin\"
         />";
   echo "<font size=\"2\">Admin</font>";
   echo "</td>";
   echo "</tr>";
   */

   echo "<tr>";
   echo "<td align=\"right\" id =\"lable_user_id\" name =\"User Id\" abbr =\"User Id\">";
   echo "<font size=\"2\">User Id</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type  =\"textbox\"
                id    =\"user_id\"
                name  =\"user_id\"
                value =\"admin\"
                READONLY          
         />";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_employee_id\" name =\"Employee Id\" abbr =\"Employee Id\">";
   echo "<font size=\"2\">Employee Id</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type =\"textbox\"
                id   =\"employee_id\"
                name =\"employee_id\"
         />";
   echo "</td>";

   echo "</tr>";





   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_admin_password\" name =\"Password\" abbr =\"Password\">";
   echo "<font size=\"2\">Password</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"password\" id=\"admin_password\" name=\"admin_password\"/>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";

   echo "<td align=\"right\" id =\"lable_re_admin_password\" name =\"Re-Password\" abbr =\"Re-Password\">";
   echo "<font size=\"2\">Re-Type Password</font><font color=\"red\">*</font>:";
   echo "</td>";

   echo "<td align=\"center\">";
   echo "<input type=\"password\" id=\"re_admin_password\" name=\"re_admin_password\"/>";
   echo "</td>";
   echo "</tr>";

   echo "</table>";
   echo "</fieldset>";
   echo "</td>";
   echo "</tr>";
   //ADMIN PASSWORD SECTION ENDS  

   echo "</table>";
?>
