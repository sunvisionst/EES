<?

  echo "<div id=\"archives\" class=\"boxed\">";
  echo "   <h2 class=\"heading\">Installation Steps</h2>";
  echo "       <div class=\"content\">";
  echo "            <ul>";
  echo "                        <li><a href=\"#\">Pre-Installation Check</a></li>";
  echo "                        <li><a href=\"#\">Tool Installation</a></li>";
  echo "                        <li><a href=\"#\">Registration</a></li>";
  //echo "                        <li><a href=\"#\">User Account</a></li>";
  //echo "                        <li><a href=\"#\">Data Installation</a></li>";
  //echo "                        <li><a href=\"#\">Final Setup</a></li>";
  echo "            </ul>";

  echo "       </div>";
  echo "</div>";
?>
