<?
  echo "<table border=\"0\" width=\"100%\">";


  $lReturnValue = $lSSTInstallationMethod->checkRegistration();

  if( $lReturnValue == 0 )
  {
    echo "<tr>";
    echo "<td>";
    echo "<p>Note :-<font color = \"green\">Congratulation !!! Registration SuccessFully Done.</font></p>";
    echo "</td>";
    echo "</tr>";
  }
  else
  if( $lReturnValue > 0 )
  {
    echo "<tr>";
    echo "<td>";
    echo "<p>Note :-<font color = \"green\">This Process Will Take Several Minute...Your Registration Data is Being Processed By Sunvision Data Center and It Will Take 10 Minute to Complete, Otherwise Check Your Internet Availability...</font></P>";
    echo "</td>";
    echo "</tr>";
  }


  if( $lReturnValue < 0 )
  {
    echo "<font color=\"red\">Registration Failed !!!</font>"; 
    if( $lReturnValue == -1 ) 
      echo "<font color=\"red\"> Problem in Organization File!!!</font>"; 
    if( $lReturnValue == -2 ) 
      echo "<font color=\"red\"> Problem in Employee File!!!</font>"; 
    if( $lReturnValue == -3 ) 
      echo "<font color=\"red\"> Problem in User File!!!</font>"; 
    if( $lReturnValue == -4 ) 
      echo "<font color=\"red\"> Problem in User Access File!!!</font>"; 
    if( $lReturnValue == -5 ) 
      echo "<font color=\"red\"> Problem in ApplnConfig File!!!</font>"; 

    $_SESSION['lOldAction']      = "toolInstall";
    $_SESSION['lCurrentAction']  = "finalize";

    echo "<script language=\"javascript\">";
    echo "document.getElementById('next_action').value = 'finalize';";
    echo "</script>";
  }


  echo "<tr>";
  echo "<td>";
  echo "Final Process Of Installation!!!";
  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>
