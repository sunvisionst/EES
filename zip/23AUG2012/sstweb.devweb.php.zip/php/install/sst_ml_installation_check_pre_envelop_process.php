<?
  echo "<table border=\"0\" width=\"100%\">";

  echo "<tr>";
  echo "<td>";
  echo "<div class=\"container\">";
  echo "<table border=\"0\" width=\"100%\">";
  echo "<tr>";
  echo "<td class=\"header\" colspan=\"2\">";
  echo "System Configuration";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Disk Space";
  echo "</td>";
  echo "<td class=\"txtcontent\">";
  echo "<input type = \"checkbox\" 
               id = \"os_check\" 
               name = \"os_check\"
               class = \"checkBox\" 
               />";
  if( $lSSTInstallationMethod->lCHECK_DISK_SPACE == 'true' )
  {
    echo "<Script language=\"javascript\">";
    echo " document.getElementById('os_check').checked = true;";
    echo "</Script>";
  }
  echo "</td>";
  echo "</tr>";



  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Php";
  echo "</td>";
  echo "<td class=\"txtcontent\">";
  echo "<input type = \"checkbox\" 
               id = \"php_check\" 
               name = \"php_check\"
               class = \"checkBox\" 
               />";
  if( $lSSTInstallationMethod->lALREADY_INSTALL_PHP == 'true' )
  {
    echo "<Script language=\"javascript\">";
    echo " document.getElementById('php_check').checked = true;";
    echo "</Script>";
  }
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Apache Tomcat";
  echo "</td>";
  echo "<td class=\"txtcontent\">";
  echo "<input type = \"checkbox\" 
               id = \"apache_check\" 
               name = \"apache_check\"
               class = \"checkBox\" 
               />";
  if( $lSSTInstallationMethod->lALREADY_INSTALL_APACHE == 'true' )
  {
    echo "<Script language=\"javascript\">";
    echo " document.getElementById('apache_check').checked = true;";
    echo "</Script>";
  }
  echo "</td>";
  echo "</tr>";


  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Java Script Enabled";
  echo "</td>";
  echo "<td class=\"txtcontent\">";
  echo "<input type = \"checkbox\" 
               id = \"js_check\" 
               name = \"js_check\"
               class = \"checkBox\" 
               />";
  if( $lSSTInstallationMethod->lJAVASCRIPT_ENABLED == 'true' )
  {
    echo "<Script language=\"javascript\">";
    echo " document.getElementById('js_check').checked = true;";
    echo "</Script>";
  }
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td class=\"txtcontent\">";
  echo "Browser";
  echo "</td>";
  echo "<td class=\"txtcontent\">";
  echo "<input type = \"checkbox\" 
               id = \"brow_check\" 
               name = \"brow_check\"
               class = \"checkBox\" 
               />";
  if( $lSSTInstallationMethod->lBROWSER_INSTALLED == 'true' )
  {
    echo "<Script language=\"javascript\">";
    echo " document.getElementById('brow_check').checked = true;";
    echo "</Script>";
  }
  echo "</td>";
  echo "</tr>";

  echo "</table>";
  echo "</div>"; 


  echo "</td>";
  echo "</tr>";

  echo "</table>";
?>
