<?php
     if (@is_uploaded_file($_FILES["userfile"]["tmp_name"])) 
     {
       echo "KK-----".$_FILES["userfile"]["tmp_name"];
       copy($_FILES["userfile"]["tmp_name"], "/opt3/dev4/sstweb/devweb/upload/custmla/SGI/install/data/" .$_FILES["userfile"]["name"]);
       echo "<p>File uploaded successfully.</p>";
     }
?>
