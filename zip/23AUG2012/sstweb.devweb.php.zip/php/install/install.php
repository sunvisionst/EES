<?php

  session_start();

  require_once("SSTInstallationMethod.php");
   
  echo "<html>";


  echo "<head>";
  //---------------------------------------------------------------------------
  include("sst_ml_installation_common_head_include.php");
  echo "<script language=\"javascript\" src=\"../../js/gn_loginEnvVar.js\"> </script>";
  echo "<script language=\"javascript\" src=\"../../js/gn_confMultiNotNullById.js\"> </script>";
  echo "<script language=\"javascript\" src=\"../js/sst_vio_registration_check_password.js\"> </script>";

  //---------------------------------------------------------------------------
  echo "</head>";

  $lAction          = "";
  $lRedirectPage    = "";
  $lOldAction       = "";
  $lCurrentAction   = "";
  $lNextAction      = "";
  $lSubmitValue     = "Process Next...";
  //$lActionComplete  = "Y";

  //OBJECT FOR THE CLASS FILE
  $lSSTInstallationMethod = new SSTInstallationMethod();



  $lAction = $_GET['action'];
  if( $lAction !== null && $lAction == 'welcome' )
  {
    $lOldAction     = "";
    $lCurrentAction = "welcome";
    $lNextAction    = "preInstall";

    $_SESSION['lOldAction']      = $lOldAction;      
    $_SESSION['lCurrentAction']  = $lCurrentAction;      
    $_SESSION['lNextAction']     = $lNextAction;     
  }
  else
  if( $lAction !== null && $lAction != 'welcome' )
  {
    $lOldAction      = $_SESSION['lCurrentAction'];     
    $lCurrentAction  = $_SESSION['lNextAction'];

    $_SESSION['lOldAction']     = $lOldAction;      
    $_SESSION['lCurrentAction'] = $lCurrentAction;      

    $lNextAction  = $_POST['next_action'];  
    $_SESSION['lNextAction']    = $lNextAction;     
  } 


  echo "<body>";
  echo "<form method = \"post\">";
  echo "<table border=\"0\" width=\"100%\">";

  echo "<div id=\"header\">";
  echo "<h1><a href=\"#\">VIO</a></h1>";
  echo "<h2><a href=\"http://www.sunvisionst.com/\">It Enabler Application</a></h2>";
  echo "</div>";

  echo "<tr>";
  echo "<td>";
  echo "<table border=\"0\" width=\"100%\">";

  //LEFT PANEl FOR INSTALLATION MENU START
  echo "<tr>";
  echo "<td width=\"30%\" align=\"left\" valign=\"top\">";

  require_once("sst_ml_installation_menu.php");

  echo "</td>";
  //LEFT PANEl FOR INSTALLATION MENU ENDS  



  //RIGHT PANEl FOR DETAIL INSTALLATION START
  echo "<td width=\"70%\" align=\"right\" valign=\"top\">";
  echo "<table border=\"0\" width=\"100%\">";

  if( $lOldAction !== null && $lOldAction == 'welcome' ) 
  {
    $lReturnValue = $lSSTInstallationMethod->preInstallCheck(); 
  }
  else 
  if( $lOldAction !== null && $lOldAction == 'preInstall' ) 
     ;
  else 
  if( $lOldAction !== null && $lOldAction == 'toolInstall' ) 
    ;
  else 
  if( $lOldAction !== null && $lOldAction == 'registration' ) 
  {
    $lSSTInstallationMethod->lApplnFileName      = "sst_org_id_vio.appln_config"; 
    $lSSTInstallationMethod->lOrgFileName        = "sst_org_id_hr_organization_ext.dat"; 
    $lSSTInstallationMethod->lUserFileName       = "sst_org_id_gn_user_ext.dat"; 
    $lSSTInstallationMethod->lUserAccessFileName = "sst_org_id_gn_user_access_ext.dat";
    $lSSTInstallationMethod->lEmployeeFileName   = "sst_org_id_hr_employee_ext.dat";

    $lReturnValue = $lSSTInstallationMethod->invokeRegistrationPrc();


    //HERE A STATUS WILL BE SET WHICH DECIDE THE MESSAGE ON FINAL PAGE
    //NAD THE PROCCES TO BE PERFORM ON THE BASIS OF REGISTRATION RESULT
    //ON THE PAGE.
    //ON FINISH BUTTON CLICK PAGE WILL MOVE ON INDEX.PHP
  }  
  else 
  if( $lOldAction !== null && $lOldAction == 'final' ) 
    ;


  echo "<tr>";

  if( $lAction !== null && $lAction == 'welcome' )
  {
    echo "<td align=\"center\">";
    echo "        <div class=\"post\">";
    echo "                <h2 class=\"title\">Welcome to VIO Intsallation!</h2>";
    echo "                <h3 class=\"posted\">Application For Education Sector</h3>";
    echo "                    <div class=\"story\">";
    echo "                         <p><em><strong>VIO</strong></em> is a Application released for The Education Sector</p>";
    echo "                    </div>";
    echo "        </div>";
    echo "</td>";
  }
  else
  {
    echo "<td align=\"center\" colspan=\"4\">";
          include("sst_ml_installation_wizard.php");
    echo "</td>";
  }
  echo "</tr>";


  if( $lAction !== null && $lAction == 'welcome' )
    $lRedirectPage  = "install.php?action=installProcess&next_action=preInstall";

  if( $lCurrentAction !== null && $lCurrentAction == 'preInstall' )
    $lRedirectPage  = "install.php?action=$lCurrentAction&next_action=$lNextAction";
       
  if( $lCurrentAction !== null && $lCurrentAction == 'toolInstall' )
    $lRedirectPage  = "install.php?action=$lCurrentAction&next_action=$lNextAction";
      
  if( $lCurrentAction !== null && $lCurrentAction == 'registration' )
  {
    $lSubmitValue   = "Register...";
    $lRedirectPage  = "install.php?action=$lCurrentAction&next_action=$lNextAction";
  }
      
  if( $lNextAction !== null && $lNextAction == 'finalize' )
    $lRedirectPage  = "install.php?action=$lCurrentAction&next_action=$lNextAction";



  {
    echo "<tr>";
    echo "<td align=\"right\">";
    echo "<table border=\"0\" width=\"40%\">";
    echo "<tr>";
    echo "<td>";


    if( $lCurrentAction !== null && $lCurrentAction != 'finalize' )
    {
      //-------------------------------------------------------------------------------------------------------
      echo "<input type    =\"submit\"
                   id      =\"submit\"       
                   name    =\"submit\"       
                   onClick =\"
                            {
                              var lTrueFalse = false;
                              if( document.getElementById('next_action').value == 'preInstall' )
                              { 
                                document.getElementById('next_action').value = 'toolInstall';
                                lTrueFalse = true; 
                              }
                              else
                               if( document.getElementById('next_action').value == 'toolInstall' ) 
                              { 
                                document.getElementById('next_action').value = 'registration';
                                lTrueFalse = true; 
                              }
                              else
                              if( document.getElementById('next_action').value == 'registration' )
                              { 
                                document.getElementById('next_action').value = 'finalize';
                                lTrueFalse = true; 
                              } 
                              else
                              if( document.getElementById('next_action').value == 'finalize')
                              {
                                if ( confMultiNotNullById(event,'first_name,last_name,org_name,org_type,org_ctg,contact,email,employee_id,admin_password') < 0 )
                                  ;
                                else
                                {
                                  if ( check_password(event) )
                                  {
                                    document.getElementById('next_action').value = 'finish';
                                    lTrueFalse = true; 
                                  }
                                }
                              }
  
                              if(lTrueFalse)  
                                javascript:form.action='$lRedirectPage';
                            }
                            \"       
                   value   =\"$lSubmitValue\"       
            />";


      echo "<input type =\"hidden\"
                   id   =\"next_action\"
                   name =\"next_action\"
                   value =\"$lNextAction\"
           />"; 
    }
    else
    {
      $lRedirectPage  = "../index.php";
      echo "<input type    =\"submit\"
                   id      =\"finish_submit\"       
                   name    =\"finish_submit\"       
                   onClick =\"
                            {
                              javascript:form.action='$lRedirectPage';
                            }
                           \"       
                   value   =\"Finish...\"       
            />";
    }
    //-------------------------------------------------------------------------------------------------------
    echo "</td>";
    echo "</tr>";
    echo "</table>";
    echo "</td>";
    echo "</tr>";
 }


  echo "</table>";
  echo "</td>";
  echo "</tr>";
  //RIGHT PANEl FOR DEATIL INSTALLATION MENU ENDS 


  echo "</table>";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  echo "<br>";
  echo "<div id=\"footer\">";
  echo "<p>Copyright &copy; 2006 <a href=\"http://www.sunvisionst.com/\"><strong>Sunvision</strong></a> S/w Pvt. Ltd New Delhi (India)</strong></a></p>";
  echo "</div>";
  echo "</td>";
  echo "</tr>";
  echo "</table>";
  echo "</form>";
  echo "</body>";

  echo "</html>";
?>
