<?
   class SSTInstallationMethod
   {
     public $lApplnFileName       = ""; 
     public $lOrgFileName         = ""; 
     public $lUserFileName        = ""; 
     public $lUserAccessFileName  = ""; 
     public $lEmployeeFileName    = ""; 

     //FLAG FOR SOME ACTION
     public $lCHECK_DISK_SPACE       = "false";
     public $lALREADY_INSTALL_PHP    = "false";
     public $lALREADY_INSTALL_APACHE = "false";
     public $lJAVASCRIPT_ENABLED     = "false";
     public $lBROWSER_INSTALLED      = "false"; //mozilla,netscape etc.
     public $lREGISTRATION_SUCCESS   = "false"; //mozilla,netscape etc.

     public function invokeRegistrationPrc()
     {
       $lUserId             = $_POST['user_id'];
       $lFirstName          = $_POST['first_name'];
       $lLastName           = $_POST['last_name'];
       $lPosition           = $_POST['position'];
       $lOrgName            = $_POST['org_name'];
       $lOrgType            = $_POST['org_type'];
       $lOrgCategory        = $_POST['org_ctg'];
       $lOrgId              = $_POST['org_id'];
       $lAddress            = $_POST['address'];
       $lContact            = $_POST['contact'];
       $lPhone              = $_POST['phone'];
       $lMobile             = $_POST['mobile'];
       $lEmail              = $_POST['email'];
       $lWebsite            = $_POST['website'];
       //$lEmpType            = $_POST['emp_type'];
       $lEmployeeId         = $_POST['employee_id'];
       $lPassword           = $_POST['admin_password'];
       //$lRePassword         = $_POST['re_admin_password'];


       if( $this->gen_org_file(
                                 $lOrgId
                               , $lOrgName
                               , $lOrgType
                               , $lOrgCategory
                               , $lAddress
                               , $lContact
                               , $lPhone
                               , $lMobile
                               , $lEmail
                               , $lWebsite
                               , $this->lOrgFileName
                               ) < 0 
         )
         return -1;

       if( $this->gen_employee_file(
                                     $lOrgId
                                   , $lEmployeeId
                                   , $lFirstName
                                   , $lLastName
                                   , $this->lEmployeeFileName
                                   ) < 0
         )
         return -2;

       if( $this->gen_usr_file(
                                $lOrgId
                              , $lUserId
                              , $lFirstName." ".$lLastName
                              , $lEmpType   
                              , $lEmployeeId
                              , $lPassword
                              , $this->lUserFileName
                              ) < 0
         )
         return -3;

       if( $this->gen_usr_access_file(
                                       $lOrgId
                                     , $lUserId
                                     , $lEmpType   
                                     , $lEmployeeId
                                     , $this->lUserAccessFileName
                                     ) < 0 
         )
         return -4;


       if( $this->gen_appln_config($this->lApplnFileName) < 0 )
         return -5;


       if( $this->checkRegistration() < 0 )
         return -1;
       else
        $this->lREGISTRATION_SUCCESS = "true";

       return 0;
     } 


     private function gen_appln_config($inApplnFileName)
     {
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_INSTALL'].$inApplnFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          return -1;
       try
       { 
         $lFileHandler  = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");
         $lCSVFileData  = "INSTALL_OK";
         fwrite($lFileHandler, $lCSVFileData); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
       return 0; 
     }

     private function gen_employee_file( 
                                         $inOrgId
                                       , $inEmployeeId
                                       , $inEmployeefName
                                       , $inEmployeelName
                                       , $inEmpFileName
                                       )
     {
       //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/install/data/".$inEmpFileName;
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_INSTALL'].$inEmpFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          return -1;
       try
       { 
         $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");
         $lCSVFileData  = "$inOrgId,$inEmployeeId,,$inEmployeefName,,$inEmployeelName,,,,,,,,,,,,,,,,,,,,,,,,,";
         $lCSVFileData .= ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,";
         $lCSVFileData .= ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,";
         $lCSVFileData .= ",,,,,,,,,";
         fwrite($lFileHandler, $lCSVFileData); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
       return 0; 
     }



     private function gen_usr_file(
                                      $inOrgId
                                    , $inUserId
                                    , $inUserName
                                    , $inUserType   
                                    , $inUserEmployeeId
                                    , $inPassword
                                    , $inUsrFileName
                                  )
     {
       //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/install/data/".$inUsrFileName;
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_INSTALL'].$inUsrFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          return -1;
       try
       { 
         $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");
         $lCSVFileData  = "$inOrgId,$inUserId,$inUserName,$inUserType,,,$inUserEmployeeId,$inUserEmployeeId,";
         $lCSVFileData .= ",$inPassword,,,,,,,,,,,,,,,,,,,,";
         fwrite($lFileHandler, $lCSVFileData); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
       return 0; 
     }

     private function gen_usr_access_file(
                                           $inOrgId
                                         , $inUserId
                                         , $inUserType   
                                         , $inUserEmployeeId
                                         , $inUsrAccessFileName
                                         )
     {
       //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/install/data/".$inUsrAccessFileName;
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_INSTALL'].$inUsrAccessFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          return -1;
       try
       { 
         $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");
         $lCSVFileData  = "$inOrgId,VIO,$inUserId,$inUserType,,$inUserEmployeeId,,,";
         fwrite($lFileHandler, $lCSVFileData); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
       return 0; 
     }

     private function gen_org_file(
                                    $inOrgId
                                  , $inOrgName
                                  , $inOrgType
                                  , $inOrgCategory
                                  , $inAddress
                                  , $inContact
                                  , $inPhone
                                  , $inMobile
                                  , $inEmail
                                  , $inWebsite
                                  , $inOrgFileName
                                  )
     {
       //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/install/data/".$inOrgFileName;
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_INSTALL'].$inOrgFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          return -1;
       try
       { 
         $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");
         $lCSVFileData = "$inOrgId,$inOrgName,,$inAddress,$inAddress,,,,,$inOrgType,$inOrgCategory,$inPhone,$inEmail,,,,,,,,,,,,,,,,,,";
         fwrite($lFileHandler, $lCSVFileData); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
       return 0; 
     }


     
     public function preInstallCheck()
     {
       $lOSName = $this->getOSName();          

       if( $this->checkPhp() < 0 )
         ;
       else 
       {
         $this->lALREADY_INSTALL_PHP = "true";
         if( $this->checkPhpVersion() < 0 )
           ;  
       } 

       if( $this->checkApache() < 0 )
        ;
       else 
       {
         $this->lALREADY_INSTALL_APACHE = "true";
         if( $this->checkApacheVersion() < 0 )
           ; 
       } 

       if( $this->checkdiskSpace() < 0 )
         ;
       else
       {
         $this->lCHECK_DISK_SPACE = "true";
       }

       if( $this->checkJavaScriptEnb() < 0 )
         ;
       else
       {
         $this->lJAVASCRIPT_ENABLED = "true"; 
       } 

       if( $this->checkBrowser() < 0 )
         ;
       else
       {
         $this->lBROWSER_INSTALLED = "true";
       }
       
       /*THIS METHOD WILL CALL ON THE TIME OF REGISTRATION OR DATA COLLECTING PROCESS BCOZ OF ORGID
       if( $this->setEnvFileParam($lOSName) < 0 )
          return -1; 
       */
     }

     private function getOSName()
     {
       return "linux";
     } 


     private function checkPhp()
     {
       return 0; 
     }

     private function checkPhpVersion()
     {
       return 0; 
     }

     private function checkApache()
     {
       return 0; 
     }

     private function checkApacheVersion()
     {
       return 0; 
     }

     private function checkdiskSpace()
     {
       return 0; 
     }

     private function checkJavaScriptEnb()
     {
       return 0; 
     }

     private function checkBrowser()
     {
       return 0; 
     }




     public function checkRegistration()
     {
  
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'].$this->lOrgFileName;
       echo "KK-----".$lFileNamePath;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
          ;
       else 
         return -1;

       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'].$this->lEmployeeFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         ;
       else
          return -2;

       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'].$this->lUserFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         ;
       else
          return -3;


       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'].$this->lUserAccessFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         ;
       else 
         return -4;


       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'].$this->lApplnFileName;
       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         ;
       else
         return -5;

       return 0;
     } 


     /*
      THIS IS USED TO CREATE A ENVOIRNMENT
      FILE WITH PATH OF THE SPECIFIC DIR.
     */ 
     private function setEnvFileParam($inOSName)
     {
       $lENVContent         = ""; 
       $lFilePathForEnvFile = ""; 
       $lFilePathForEnvFileName = "sst_ml_env_var.php";

 
        $lENVContent = "<?php\n";
       //WRITE ENV_PHP FILE HERE ACCORDING TO OS
       if( $inOSName == "linux")
       {
         $lFilePathForEnvFile = "/opt3/dev4/sstweb/devweb/php/";
         $lENVContent        .= "putenv(\"SST_MLA_HOME=/opt3/dev4/sstweb/devweb/php/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_INSTALL=/opt3/dev4/sstweb/devweb/upload/SGI/install\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_DATA_INSTALL=/opt3/dev4/sstweb/devweb/upload/SGI/install/data/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_DATA_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/refdb/datafiledir/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_INBOX_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/php/inbox/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_OUTBOX_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/php/outbox/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_DATA_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/refdb/datafiledir/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_INBOX_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/inbox/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_INBOX_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/outbox/\");\n";
       }
       else
       if( $inOSName == "win")
       {
         $lFilePathForEnvFile     = "c:/sst_linux/home/eesma/";
         $lENVContent        .= "putenv(\"SST_MLA_HOME=c:/sst_linux/home/eesma/sstweb/devweb/php/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_INSTALL=c:/sst_linux/home/eesma/sstweb/devweb/upload/SGI/install\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_DATA_INSTALL=c:/sst_linux/home/eesma/sstweb/devweb/upload/SGI/install/data/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_DATA_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/custmla/refdb/datafiledir/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_INBOX_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/custmla/SGI/php/inbox/\");\n";
         $lENVContent        .= "putenv(\"SST_MLA_OUTBOX_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/custmla/SGI/php/outbox/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_DATA_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/sstmladc/refdb/datafiledir/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_INBOX_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/sstmladc/inbox/\");\n";
         $lENVContent        .= "putenv(\"SST_DC_INBOX_DIR=c:/sst_linux/home/eesma/sstweb/devweb/upload/sstmladc/outbox/\");\n";
       }
       $lENVContent = "?>";
       $lFilePathForEnvFile .=$lFilePathForEnvFileName;

       if(file_exists($lFilePathForEnvFile) && is_readable ($lFilePathForEnvFile))
          return -1;

       try
       { 
         $lFileHandler = fopen($lFilePathForEnvFile, "w") or die("Request File Can Not Open!!!");
         fwrite($lFileHandler, $lENVContent); 
       }
       catch(Exception $Ex)
       {
         echo $Ex->getMessage();
       }  
       fclose($lFileHandler);
     }

   }
?>
