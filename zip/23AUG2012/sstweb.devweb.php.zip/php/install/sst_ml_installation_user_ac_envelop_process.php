<?
  echo "<table border=\"0\" width=\"100%\">";
  echo "<tr>";
  echo "<td>";
  echo "User ACCOUNT";
  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>
