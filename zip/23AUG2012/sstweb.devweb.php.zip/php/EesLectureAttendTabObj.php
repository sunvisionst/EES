<?

class EesLectureAttendTabObj
{
  public $tab_rowid;
  public $org_id;
  public $student_id;
  public $period_num;
  public $lecture_date;
  public $roll_num;
  public $subject_code;
  public $class_id;
  public $attendance_status;


  /*
  public $org_id_ind;
  public $student_id_ind;
  public $period_num_ind;
  public $lecture_date_ind;
  public $roll_num_ind;
  public $subject_code_ind;
  public $class_id_ind;
  public $attendance_status_ind;
  */

  function __construct(){}

  function EesLectureAttendTabObj
  (
    $org_id,
    $student_id,
    $riod_num,
    $lecture_date,
    $roll_num,
    $subject_code,
    $class_id,
    $attendance_status
  )
  {
     $this->org_id            = $org_id;
     $this->student_id        = $student_id;
     $this->period_num        = $period_num;
     $this->lecture_date      = $lecture_date;
     $this->roll_num          = $roll_num;
     $this->subject_code      = $subject_code;
     $this->class_id          = $class_id;
     $this->attendance_status = $attendance_status;
  }


  /*
  public function getorg_id()                               { return org_id;            }
  public function getstudent_id()                           { return student_id;        }
  public function getperiod_num()                           { return period_num;        }
  public function getlecture_date()                         { return lecture_date;      }
  public function getroll_num()                             { return roll_num;          }
  public function getsubject_code()                         { return subject_code;      }
  public function getclass_id()                             { return class_id;          }
  public function getattendance_status()                    { return attendance_status; }



  public function  setorg_id($org_id )                      { $this->org_id            = $org_id;            }
  public function  setstudent_id($student_id )              { $this->student_id        = $student_id;        }
  public function  setperiod_num($period_num )              { $this->period_num        = $period_num;        }
  public function  setlecture_date($lecture_date )          { $this->lecture_date      = $lecture_date;      }
  public function  setroll_num($roll_num )                  { $this->roll_num          = $roll_num;          }
  public function  setsubject_code($subject_code )          { $this->subject_code      = $subject_code;      }
  public function  setclass_id($class_id )                  { $this->class_id          = $class_id;          }
  public function  setattendance_status($attendance_status ){ $this->attendance_status = $attendance_status; }
  */
}

?>
