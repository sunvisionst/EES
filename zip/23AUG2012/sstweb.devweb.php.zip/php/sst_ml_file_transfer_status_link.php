<?
  echo "<table border=\"0\" width=\"100%\">";

  echo "<tr>";

  echo "<td align=\"right\">";
  echo "<a href =\"#\">Upload</a>";
  echo "</td>";

  echo "<td align=\"right\">";
  echo "<a href =\"#\">Rfresh Upload</a>";
  echo "</td>";

  echo "<td align=\"right\">";
  echo "<a href =\"#\">Download</a>";
  echo "</td>";

  echo "<td align=\"right\">";
  echo "<a href =\"#\">Refresh Download</a>";
  echo "</td>";

  echo "</tr>";

  echo "</table>";
?>
