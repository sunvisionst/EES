<?php
   
  class SSTMlaSession
  {

    public function sessionId() 
    {
      $lRandlen     = 32;
      $lRandval     = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
      $lRandom      = "";

      for ($lSesRec = 1; $lSesRec <= $lRandlen; $lSesRec++) 
      {
        $lRandom .= substr($lRandval, rand(0,(strlen($lRandval) - 1)), 1);
      }

      // use md5 value for id or remove capitals from string $lRandval
      $lRandom = md5($lRandom);
      
      if (session_id($lRandom)) //SET ID INTO THE SESSION ATTRIBUTE
        return true;
      else 
        return false;
    }
    /*
    if (!function_exists("session_regenerate_id")) 
    {
      sessionId();
    } 
    else 
    {
      session_regenerate_id();
    }
    */ 
 
  } 
?>
