var httpObject       = null;
var lDestFieldName   = '';//To Hold Destination Field Id
var lPhpFileName     = ''; //File On which ajax code fire
var lSourceFieldValue = ''; //Source Field Id                  
var lUrl             = ''; //Source Field Id                  




 // Get the HTTP Object
 function getHTTPObject()
 {
   if (window.ActiveXObject) return new ActiveXObject("Microsoft.XMLHTTP");
   else 
   if (window.XMLHttpRequest) return new XMLHttpRequest();
   else 
   {
     alert("Your browser does not support AJAX.");
     return null;
   }
 }

       
 // Change the value of the outputText field
 function setOutput()
 {
   if(httpObject.readyState == 4)
   {
     if( httpObject.responseText.length <= '96' ) ///CHECK IF NO EXTRA VALUE IS APPENDED
     {
       alert('No Data Found');
       document.getElementById(lDestFieldName).innerHTML = httpObject.responseText;
     }
     else
       document.getElementById(lDestFieldName).innerHTML = httpObject.responseText;
   }
 }
       
 // Implement business logic
 function refreshAjaxElement()
 {
   httpObject = getHTTPObject();
   if (httpObject != null) 
   {
     lUrl = lPhpFileName+"?ajax_action=y&criteria_value="+lSourceFieldValue;
     httpObject.open("GET", lUrl, true);
     httpObject.send(null);
     httpObject.onreadystatechange = setOutput;
   }
 }
 

 //Function which call on Control
 function invokeRefresh( inPhpFileName, inDestFieldName, inSourceFieldValue )
 {
   lPhpFileName       = inPhpFileName;
   lDestFieldName     = inDestFieldName;
   lSourceFieldValue  = inSourceFieldValue;

   refreshAjaxElement(); 
 }





 //METHOD TO REMOVE LEADING & TRAILING SPACES FROM A STRING
 function trimString (inTrimStr) 
 {
   //alert('kkk---->'+inTrimStr);
   inTrimStr = inTrimStr.replace(/^\s+/g, '');
   inTrimStr = inTrimStr.replace(/\s+$/g, '');

   return inTrimStr;
   //return inTrimStr.replace(/^\s+/g, '').replace(/\s+$/g, '');
 }


