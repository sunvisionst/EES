<?

class HrEmployeeTabObj
{
  public $tab_rowid;
  public $org_id;
  public $employee_id;
  public $name_initials;
  public $employee_f_name;
  public $employee_m_name;
  public $employee_l_name;
  public $employee_short_name;
  public $emp_type;
  public $emp_ctg;
  public $reporting_head_id;
  public $dept_id;
  public $logical_group_id;
  public $position_id;
  public $level_id;
  public $designation;
  public $doj;
  public $dot;
  public $project_id;
  public $shift_code;
  public $cycle_code;
  public $phone;
  public $ext;
  public $email_id;
  public $building_id;
  public $floor_num;
  public $room_num;
  public $cubical_num;
  public $emp_status;
  public $emp_status_date;
  public $emp_agreement_sts;
  public $emp_agreement_sts_date;
  public $country;
  public $recruit_req_id;
  public $work_org_id;
  public $marital_status;
  public $pan_ind;
  public $pf_ind;
  public $esi_ind;
  public $pan_num;
  public $pan_create_date;
  public $epf_act_num;
  public $epf_act_open_dt;
  public $epf_act_close_dt;
  public $prev_epf_act_num;
  public $prev_epf_act_open_dt;
  public $prev_epf_act_close_dt;
  public $esi_num;
  public $esi_act_open_dt;
  public $esi_act_close_dt;
  public $prev_esi_num;
  public $prev_esi_num_open_dt;
  public $prev_esi_num_close_dt;
  public $nss_num;
  public $nss_create_date;
  public $gender;
  public $dob;
  public $birth_city;
  public $birth_country;
  public $relation_type;
  public $relative_name;
  public $applicant_id;
  public $p_card_id;
  public $banker_code;
  public $banker_name;
  public $salary_mode;
  public $pay_card_num;
  public $bank_act_num;
  public $father_name;
  public $mother_name;
  public $spouse_name;
  public $barcode;
  public $user_id;
  public $pswd_0;
  public $p_address_1;
  public $p_address_2;
  public $p_city;
  public $p_state;
  public $p_zip;
  public $p_country;
  public $m_address_1;
  public $m_address_2;
  public $m_city;
  public $m_state;
  public $m_zip;
  public $m_country;
  public $hospital_id;
  public $course_id;
  public $course_stream;





  public $org_id_ind;
  public $employee_id_ind;
  public $name_initials_ind;
  public $employee_f_name_ind;
  public $employee_m_name_ind;
  public $employee_l_name_ind;
  public $employee_short_name_ind;
  public $emp_type_ind;
  public $emp_ctg_ind;
  public $reporting_head_id_ind;
  public $dept_id_ind;
  public $logical_group_id_ind;
  public $position_id_ind;
  public $level_id_ind;
  public $designation_ind;
  public $doj_ind;
  public $dot_ind;
  public $project_id_ind;
  public $shift_code_ind;
  public $cycle_code_ind;
  public $phone_ind;
  public $ext_ind;
  public $email_id_ind;
  public $building_id_ind;
  public $floor_num_ind;
  public $room_num_ind;
  public $cubical_num_ind;
  public $emp_status_ind;
  public $emp_status_date_ind;
  public $emp_agreement_sts_ind;
  public $emp_agreement_sts_date_ind;
  public $country_ind;
  public $recruit_req_id_ind;
  public $work_org_id_ind;
  public $marital_status_ind;
  public $pan_ind_ind;
  public $pf_ind_ind;
  public $esi_ind_ind;
  public $pan_num_ind;
  public $pan_create_date_ind;
  public $epf_act_num_ind;
  public $epf_act_open_dt_ind;
  public $epf_act_close_dt_ind;
  public $prev_epf_act_num_ind;
  public $prev_epf_act_open_dt_ind;
  public $prev_epf_act_close_dt_ind;
  public $esi_num_ind;
  public $esi_act_open_dt_ind;
  public $esi_act_close_dt_ind;
  public $prev_esi_num_ind;
  public $prev_esi_num_open_dt_ind;
  public $prev_esi_num_close_dt_ind;
  public $nss_num_ind;
  public $nss_create_date_ind;
  public $gender_ind;
  public $dob_ind;
  public $birth_city_ind;
  public $birth_country_ind;
  public $relation_type_ind;
  public $relative_name_ind;
  public $applicant_id_ind;
  public $emp_card_id_ind;
  public $banker_code_ind;
  public $banker_name_ind;
  public $salary_mode_ind;
  public $pay_card_num_ind;
  public $bank_act_num_ind;
  public $father_name_ind;
  public $mother_name_ind;
  public $spouse_name_ind;
  public $barcode_ind;
  public $user_id_ind;
  public $pswd_0_ind;
  public $p_address_1_ind;
  public $p_address_2_ind;
  public $p_city_ind;
  public $p_state_ind;
  public $p_zip_ind;
  public $p_country_ind;
  public $m_address_1_ind;
  public $m_address_2_ind;
  public $m_city_ind;
  public $m_state_ind;
  public $m_zip_ind;
  public $m_country_ind;
  public $hospital_id_ind;
  public $course_id_ind;
  public $course_stream_ind;


  function __construct(){}

  function HrEmployeeTabObj
  (
    $org_id,
    $employee_id,
    $name_initials,
    $employee_f_name,
    $employee_m_name,
    $employee_l_name,
    $employee_short_name,
    $emp_type,
    $emp_ctg,
    $reporting_head_id,
    $dept_id,
    $logical_group_id,
    $position_id,
    $level_id,
    $designation,
    $doj,
    $dot,
    $project_id,
    $shift_code,
    $cycle_code,
    $phone,
    $ext,
    $email_id,
    $building_id,
    $floor_num,
    $room_num,
    $cubical_num,
    $emp_status,
    $emp_status_date,
    $emp_agreement_sts,
    $emp_agreement_sts_date,
    $country,
    $recruit_req_id,
    $work_org_id,
    $marital_status,
    $pan_ind,
    $pf_ind,
    $esi_ind,
    $pan_num,
    $pan_create_date,
    $epf_act_num,
    $epf_act_open_dt,
    $epf_act_close_dt,
    $prev_epf_act_num,
    $prev_epf_act_open_dt,
    $prev_epf_act_close_dt,
    $esi_num,
    $esi_act_open_dt,
    $esi_act_close_dt,
    $prev_esi_num,
    $prev_esi_num_open_dt,
    $prev_esi_num_close_dt,
    $nss_num,
    $nss_create_date,
    $gender,
    $dob,
    $birth_city,
    $birth_country,
    $relation_type,
    $relative_name,
    $applicant_id,
    $emp_card_id,
    $banker_code,
    $banker_name,
    $salary_mode,
    $pay_card_num,
    $bank_act_num,
    $father_name,
    $mother_name,
    $spouse_name,
    $barcode,
    $user_id,
    $pswd_0,
    $p_address_1,
    $p_address_2,
    $p_city,
    $p_state,
    $p_zip,
    $p_country,
    $m_address_1,
    $m_address_2,
    $m_city,
    $m_state,
    $m_zip,
    $m_country,
    $hospital_id,
    $course_id,
    $course_stream
  )
  {
     $this->org_id = $org_id;
     $this->employee_id = $employee_id;
     $this->name_initials = $name_initials;
     $this->employee_f_name = $employee_f_name;
     $this->employee_m_name = $employee_m_name;
     $this->employee_l_name = $employee_l_name;
     $this->employee_short_name = $employee_short_name;
     $this->emp_type = $emp_type;
     $this->emp_ctg = $emp_ctg;
     $this->reporting_head_id = $reporting_head_id;
     $this->dept_id = $dept_id;
     $this->logical_group_id = $logical_group_id;
     $this->position_id = $position_id;
     $this->level_id = $level_id;
     $this->designation = $designation;
     $this->doj = $doj;
     $this->dot = $dot;
     $this->project_id = $project_id;
     $this->shift_code = $shift_code;
     $this->cycle_code = $cycle_code;
     $this->phone = $phone;
     $this->ext = $ext;
     $this->email_id = $email_id;
     $this->building_id = $building_id;
     $this->floor_num = $floor_num;
     $this->room_num = $room_num;
     $this->cubical_num = $cubical_num;
     $this->emp_status = $emp_status;
     $this->emp_status_date = $emp_status_date;
     $this->emp_agreement_sts = $emp_agreement_sts;
     $this->emp_agreement_sts_date = $emp_agreement_sts_date;
     $this->country = $country;
     $this->recruit_req_id = $recruit_req_id;
     $this->work_org_id = $work_org_id;
     $this->marital_status = $marital_status;
     $this->pan_ind = $pan_ind;
     $this->pf_ind = $pf_ind;
     $this->esi_ind = $esi_ind;
     $this->pan_num = $pan_num;
     $this->pan_create_date = $pan_create_date;
     $this->epf_act_num = $epf_act_num;
     $this->epf_act_open_dt = $epf_act_open_dt;
     $this->epf_act_close_dt = $epf_act_close_dt;
     $this->prev_epf_act_num = $prev_epf_act_num;
     $this->prev_epf_act_open_dt = $prev_epf_act_open_dt;
     $this->prev_epf_act_close_dt = $prev_epf_act_close_dt;
     $this->esi_num = $esi_num;
     $this->esi_act_open_dt = $esi_act_open_dt;
     $this->esi_act_close_dt = $esi_act_close_dt;
     $this->prev_esi_num = $prev_esi_num;
     $this->prev_esi_num_open_dt = $prev_esi_num_open_dt;
     $this->prev_esi_num_close_dt = $prev_esi_num_close_dt;
     $this->nss_num = $nss_num;
     $this->nss_create_date = $nss_create_date;
     $this->gender = $gender;
     $this->dob = $dob;
     $this->birth_city = $birth_city;
     $this->birth_country = $birth_country;
     $this->relation_type = $relation_type;
     $this->relative_name = $relative_name;
     $this->applicant_id = $applicant_id;
     $this->emp_card_id = $emp_card_id;
     $this->banker_code = $banker_code;
     $this->banker_name = $banker_name;
     $this->salary_mode = $salary_mode;
     $this->pay_card_num = $pay_card_num;
     $this->bank_act_num = $bank_act_num;
     $this->father_name = $father_name;
     $this->mother_name = $mother_name;
     $this->spouse_name = $spouse_name;
     $this->barcode = $barcode;
     $this->user_id = $user_id;
     $this->pswd_0 = $pswd_0;
     $this->p_address_1 = $p_address_1;
     $this->p_address_2 = $p_address_2;
     $this->p_city = $p_city;
     $this->p_state = $p_state;
     $this->p_zip = $p_zip;
     $this->p_country = $p_country;
     $this->m_address_1 = $m_address_1;
     $this->m_address_2 = $m_address_2;
     $this->m_city = $m_city;
     $this->m_state = $m_state;
     $this->m_zip = $m_zip;
     $this->m_country = $m_country;
     $this->hospital_id = $hospital_id;
     $this->course_id = $course_id;
     $this->course_stream = $course_stream;
  }


  /*
  public function getorg_id()                           { return $org_id; }
  public function getemployee_id()                      { return $employee_id; }
  public function getname_initials()                    { return $name_initials; }
  public function getemployee_f_name()                  { return $employee_f_name; }
  public function getemployee_m_name()                  { return $employee_m_name; }
  public function getemployee_l_name()                  { return $employee_l_name; }
  public function getemployee_short_name()              { return $employee_short_name; }
  public function getemp_type()                         { return $emp_type; }
  public function getemp_ctg()                          { return $emp_ctg; }
  public function getreporting_head_id()                { return $reporting_head_id; }
  public function getdept_id()                          { return $dept_id; }
  public function getlogical_group_id()                 { return $logical_group_id; }
  public function getposition_id()                      { return $position_id; }
  public function getlevel_id()                         { return $level_id; }
  public function getdesignation()                      { return $designation; }
  public function getdoj()                              { return $doj; }
  public function getdot()                              { return $dot; }
  public function getproject_id()                       { return $project_id; }
  public function getshift_code()                       { return $shift_code; }
  public function getcycle_code()                       { return $cycle_code; }
  public function getphone()                            { return $phone; }
  public function getext()                              { return $ext; }
  public function getemail_id()                         { return $email_id; }
  public function getbuilding_id()                      { return $building_id; }
  public function getfloor_num()                        { return $floor_num; }
  public function getroom_num()                         { return $room_num; }
  public function getcubical_num()                      { return $cubical_num; }
  public function getemp_status()                       { return $emp_status; }
  public function getemp_status_date()                  { return $emp_status_date; }
  public function getemp_agreement_sts()                { return $emp_agreement_sts; }
  public function getemp_agreement_sts_date()           { return $emp_agreement_sts_date; }
  public function getcountry()                          { return $country; }
  public function getrecruit_req_id()                   { return $recruit_req_id; }
  public function getwork_org_id()                      { return $work_org_id; }
  public function getmarital_status()                   { return $marital_status; }
  public function getpan_ind()                          { return $pan_ind; }
  public function getpf_ind()                           { return $pf_ind; }
  public function getesi_ind()                          { return $esi_ind; }
  public function getpan_num()                          { return $pan_num; }
  public function getpan_create_date()                  { return $pan_create_date; }
  public function getepf_act_num()                      { return $epf_act_num; }
  public function getepf_act_open_dt()                  { return $epf_act_open_dt; }
  public function getepf_act_close_dt()                 { return $epf_act_close_dt; }
  public function getprev_epf_act_num()                 { return $prev_epf_act_num; }
  public function getprev_epf_act_open_dt()             { return $prev_epf_act_open_dt; }
  public function getprev_epf_act_close_dt()            { return $prev_epf_act_close_dt; }
  public function getesi_num()                          { return $esi_num; }
  public function getesi_act_open_dt()                  { return $esi_act_open_dt; }
  public function getesi_act_close_dt()                 { return $esi_act_close_dt; }
  public function getprev_esi_num()                     { return $prev_esi_num; }
  public function getprev_esi_num_open_dt()             { return $prev_esi_num_open_dt; }
  public function getprev_esi_num_close_dt()            { return $prev_esi_num_close_dt; }
  public function getnss_num()                          { return $nss_num; }
  public function getnss_create_date()                  { return $nss_create_date; }
  public function getgender()                           { return $gender; }
  public function getdob()                              { return $dob; }
  public function getbirth_city()                       { return $birth_city; }
  public function getbirth_country()                    { return $birth_country; }
  public function getrelation_type()                    { return $relation_type; }
  public function getrelative_name()                    { return $relative_name; }
  public function getapplicant_id()                     { return $applicant_id; }
  public function getemp_card_id()                      { return $emp_card_id; }
  public function getbanker_code()                      { return $banker_code; }
  public function getbanker_name()                      { return $banker_name; }
  public function getsalary_mode()                      { return $salary_mode; }
  public function getpay_card_num()                     { return $pay_card_num; }
  public function getbank_act_num()                     { return $bank_act_num; }
  public function getfather_name()                      { return $father_name; }
  public function getmother_name()                      { return $mother_name; }
  public function getspouse_name()                      { return $spouse_name; }
  public function getbarcode()                          { return $barcode; }
  public function getuser_id()                          { return $user_id; }
  public function getpswd_0()                           { return $pswd_0; }
  public function getp_address_1()                      { return $p_address_1; }
  public function getp_address_2()                      { return $p_address_2; }
  public function getp_city()                           { return $p_city; }
  public function getp_state()                          { return $p_state; }
  public function getp_zip()                            { return $p_zip; }
  public function getp_country()                        { return $p_country; }
  public function getm_address_1()                      { return $m_address_1; }
  public function getm_address_2()                      { return $m_address_2; }
  public function getm_city()                           { return $m_city; }
  public function getm_state()                          { return $m_state; }
  public function getm_zip()                            { return $m_zip; }
  public function getm_country()                        { return $m_country; }
  public function gethospital_id()                      { return $hospital_id; }
  public function getcourse_id()                        { return $course_id; }
  public function getcourse_stream()                    { return $course_stream; }



  public function  setorg_id($org_id )                                  { $this->org_id = $org_id; }
  public function  setemployee_id($employee_id )                        { $this->employee_id = $employee_id; }
  public function  setname_initials($name_initials )                    { $this->name_initials = $name_initials; }
  public function  setemployee_f_name($employee_f_name )                { $this->employee_f_name = $employee_f_name; }
  public function  setemployee_m_name($employee_m_name )                { $this->employee_m_name = $employee_m_name; }
  public function  setemployee_l_name($employee_l_name )                { $this->employee_l_name = $employee_l_name; }
  public function  setemployee_short_name($employee_short_name )        { $this->employee_short_name = $employee_short_name; }
  public function  setemp_type($emp_type )                              { $this->emp_type = $emp_type; }
  public function  setemp_ctg($emp_ctg )                                { $this->emp_ctg = $emp_ctg; }
  public function  setreporting_head_id($reporting_head_id )            { $this->reporting_head_id = $reporting_head_id; }
  public function  setdept_id($dept_id )                                { $this->dept_id = $dept_id; }
  public function  setlogical_group_id($logical_group_id )              { $this->logical_group_id = $logical_group_id; }
  public function  setposition_id($position_id )                        { $this->position_id = $position_id; }
  public function  setlevel_id($level_id )                              { $this->level_id = $level_id; }
  public function  setdesignation($designation )                        { $this->designation = $designation; }
  public function  setdoj($doj )                                        { $this->doj = $doj; }
  public function  setdot($dot )                                        { $this->dot = $dot; }
  public function  setproject_id($project_id )                          { $this->project_id = $project_id; }
  public function  setshift_code($shift_code )                          { $this->shift_code = $shift_code; }
  public function  setcycle_code($cycle_code )                          { $this->cycle_code = $cycle_code; }
  public function  setphone($phone )                                    { $this->phone = $phone; }
  public function  setext($ext )                                        { $this->ext = $ext; }
  public function  setemail_id($email_id )                              { $this->email_id = $email_id; }
  public function  setbuilding_id($building_id )                        { $this->building_id = $building_id; }
  public function  setfloor_num($floor_num )                            { $this->floor_num = $floor_num; }
  public function  setroom_num($room_num )                              { $this->room_num = $room_num; }
  public function  setcubical_num($cubical_num )                        { $this->cubical_num = $cubical_num; }
  public function  setemp_status($emp_status )                          { $this->emp_status = $emp_status; }
  public function  setemp_status_date($emp_status_date )                { $this->emp_status_date = $emp_status_date; }
  public function  setemp_agreement_sts($emp_agreement_sts )            { $this->emp_agreement_sts = $emp_agreement_sts; }
  public function  setemp_agreement_sts_date($emp_agreement_sts_date )  { $this->emp_agreement_sts_date = $emp_agreement_sts_date; }
  public function  setcountry($country )                                { $this->country = $country; }
  public function  setrecruit_req_id($recruit_req_id )                  { $this->recruit_req_id = $recruit_req_id; }
  public function  setwork_org_id($work_org_id )                        { $this->work_org_id = $work_org_id; }
  public function  setmarital_status($marital_status )                  { $this->marital_status = $marital_status; }
  public function  setpan_ind($pan_ind )                                { $this->pan_ind = $pan_ind; }
  public function  setpf_ind($pf_ind )                                  { $this->pf_ind = $pf_ind; }
  public function  setesi_ind($esi_ind )                                { $this->esi_ind = $esi_ind; }
  public function  setpan_num($pan_num )                                { $this->pan_num = $pan_num; }
  public function  setpan_create_date($pan_create_date )                { $this->pan_create_date = $pan_create_date; }
  public function  setepf_act_num($epf_act_num )                        { $this->epf_act_num = $epf_act_num; }
  public function  setepf_act_open_dt($epf_act_open_dt )                { $this->epf_act_open_dt = $epf_act_open_dt; }
  public function  setepf_act_close_dt($epf_act_close_dt )              { $this->epf_act_close_dt = $epf_act_close_dt; }
  public function  setprev_epf_act_num($prev_epf_act_num )              { $this->prev_epf_act_num = $prev_epf_act_num; }
  public function  setprev_epf_act_open_dt($prev_epf_act_open_dt )      { $this->prev_epf_act_open_dt = $prev_epf_act_open_dt; }
  public function  setprev_epf_act_close_dt($prev_epf_act_close_dt )    { $this->prev_epf_act_close_dt = $prev_epf_act_close_dt; }
  public function  setesi_num($esi_num )                                { $this->esi_num = $esi_num; }
  public function  setesi_act_open_dt($esi_act_open_dt )                { $this->esi_act_open_dt = $esi_act_open_dt; }
  public function  setesi_act_close_dt($esi_act_close_dt )              { $this->esi_act_close_dt = $esi_act_close_dt; }
  public function  setprev_esi_num($prev_esi_num )                      { $this->prev_esi_num = $prev_esi_num; }
  public function  setprev_esi_num_open_dt($prev_esi_num_open_dt )      { $this->prev_esi_num_open_dt = $prev_esi_num_open_dt; }
  public function  setprev_esi_num_close_dt($prev_esi_num_close_dt )    { $this->prev_esi_num_close_dt = $prev_esi_num_close_dt; }
  public function  setnss_num($nss_num )                                { $this->nss_num = $nss_num; }
  public function  setnss_create_date($nss_create_date )                { $this->nss_create_date = $nss_create_date; }
  public function  setgender($gender )                                  { $this->gender = $gender; }
  public function  setdob($dob )                                        { $this->dob = $dob; }
  public function  setbirth_city($birth_city )                          { $this->birth_city = $birth_city; }
  public function  setbirth_country($birth_country )                    { $this->birth_country = $birth_country; }
  public function  setrelation_type($relation_type )                    { $this->relation_type = $relation_type; }
  public function  setrelative_name($relative_name )                    { $this->relative_name = $relative_name; }
  public function  setapplicant_id($applicant_id )                      { $this->applicant_id = $applicant_id; }
  public function  setemp_card_id(int emp_card_id )                     { $this->emp_card_id = $emp_card_id; }
  public function  setbanker_code($banker_code )                        { $this->banker_code = $banker_code; }
  public function  setbanker_name($banker_name )                        { $this->banker_name = $banker_name; }
  public function  setsalary_mode($salary_mode )                        { $this->salary_mode = $salary_mode; }
  public function  setpay_card_num($pay_card_num )                      { $this->pay_card_num = $pay_card_num; }
  public function  setbank_act_num($bank_act_num )                      { $this->bank_act_num = $bank_act_num; }
  public function  setfather_name($father_name )                        { $this->father_name = $father_name; }
  public function  setmother_name($mother_name )                        { $this->mother_name = $mother_name; }
  public function  setspouse_name($spouse_name )                        { $this->spouse_name = $spouse_name; }
  public function  setbarcode($barcode )                                { $this->barcode = $barcode; }
  public function  setuser_id($user_id )                                { $this->user_id = $user_id; }
  public function  setpswd_0($pswd_0 )                                  { $this->pswd_0 = $pswd_0; }
  public function  setp_address_1($p_address_1 )                        { $this->p_address_1 = $p_address_1; }
  public function  setp_address_2($p_address_2 )                        { $this->p_address_2 = $p_address_2; }
  public function  setp_city($p_city )                                  { $this->p_city = $p_city; }
  public function  setp_state($p_state )                                { $this->p_state = $p_state; }
  public function  setp_zip($p_zip )                                    { $this->p_zip = $p_zip; }
  public function  setp_country($p_country )                            { $this->p_country = $p_country; }
  public function  setm_address_1($m_address_1 )                        { $this->m_address_1 = $m_address_1; }
  public function  setm_address_2($m_address_2 )                        { $this->m_address_2 = $m_address_2; }
  public function  setm_city($m_city )                                  { $this->m_city = $m_city; }
  public function  setm_state($m_state )                                { $this->m_state = $m_state; }
  public function  setm_zip($m_zip )                                    { $this->m_zip = $m_zip; }
  public function  setm_country($m_country )                            { $this->m_country = $m_country; }
  public function  sethospital_id($hospital_id )                        { $this->hospital_id = $hospital_id; }
  public function  setcourse_id($course_id )                            { $this->course_id = $course_id; }
  public function  setcourse_stream($course_stream )                    { $this->course_stream = $course_stream; }
  */


}

?>
