<?


class EesSubjectAllocationTabObj
{
  public $tab_rowid;
  public $org_id;
  public $subject_code;
  public $employee_id;
  public $class_id;
  public $class_num;
  public $class_std;
  public $class_section;
  public $course_id;
  public $course_term;
  public $course_stream;
  public $lp_version;
  public $load_point;
  public $planned_lect_num;
  public $choice_ind;
  public $approve_sts;
  public $short_subject_code;





  public $org_id_ind;
  public $subject_code_ind;
  public $employee_id_ind;
  public $class_id_ind;
  public $class_num_ind;
  public $class_std_ind;
  public $class_section_ind;
  public $course_id_ind;
  public $course_term_ind;
  public $course_stream_ind;
  public $lp_version_ind;
  public $load_point_ind;
  public $planned_lect_num_ind;
  public $choice_ind_ind;
  public $approve_sts_ind;
  public $short_subject_code_ind;


  function __construct(){}


  function EesSubjectAllocationTabObj
  (
    $org_id,
    $subject_code,
    $employee_id,
    $class_id,
    $class_num,
    $class_std,
    $class_section,
    $course_id,
    $course_term,
    $course_stream,
    $lp_version,
    $load_point,
    $planned_lect_num,
    $choice_ind,
    $approve_sts,
    $short_subject_code
  )
  {
     $this->org_id             = $org_id;
     $this->subject_code       = $subject_code;
     $this->employee_id        = $employee_id;
     $this->class_id           = $class_id;
     $this->class_num          = $class_num;
     $this->class_std          = $class_std;
     $this->class_section      = $class_section;
     $this->course_id          = $course_id;
     $this->course_term        = $course_term;
     $this->course_stream      = $course_stream;
     $this->lp_version         = $lp_version;
     $this->load_point         = $load_point;
     $this->planned_lect_num   = $planned_lect_num;
     $this->choice_ind         = $choice_ind;
     $this->approve_sts        = $approve_sts;
     $this->short_subject_code = $short_subject_code;
  }

  public function getorg_id()                                 { return $this->org_id; }
  public function getsubject_code()                           { return $this->subject_code; }
  public function getemployee_id()                            { return $this->employee_id; }
  public function getclass_id()                               { return $this->class_id; }
  public function getclass_num()                              { return $this->class_num; }
  public function getclass_std()                              { return $this->class_std; }
  public function getclass_section()                          { return $this->class_section; }
  public function getcourse_id()                              { return $this->course_id; }
  public function getcourse_term()                            { return $this->course_term; }
  public function getcourse_stream()                          { return $this->course_stream; }
  public function getlp_version()                             { return $this->lp_version; }
  public function getload_point()                             { return $this->load_point; }
  public function getplanned_lect_num()                       { return $this->planned_lect_num; }
  public function getchoice_ind()                             { return $this->choice_ind; }
  public function getapprove_sts()                            { return $this->approve_sts; }
  public function getshort_subject_code()                     { return $this->short_subject_code; }



  public function  setorg_id($org_id )                          { $this->org_id             = $org_id; }
  public function  setsubject_code($subject_code )              { $this->subject_code       = $subject_code; }
  public function  setemployee_id($employee_id )                { $this->employee_id        = $employee_id; }
  public function  setclass_id($class_id )                      { $this->class_id           = $class_id; }
  public function  setclass_num($class_num )                    { $this->class_num          = $class_num; }
  public function  setclass_std($class_std )                    { $this->class_std          = $class_std; }
  public function  setclass_section($class_section )            { $this->class_section      = $class_section; }
  public function  setcourse_id($course_id )                    { $this->course_id          = $course_id; }
  public function  setcourse_term($course_term )                { $this->course_term        = $course_term; }
  public function  setcourse_stream($course_stream )            { $this->course_stream      = $course_stream; }
  public function  setlp_version($lp_version )                  { $this->lp_version         = $lp_version; }
  public function  setload_point($load_point )                  { $this->load_point         = $load_point; }
  public function  setplanned_lect_num($planned_lect_num )      { $this->planned_lect_num   = $planned_lect_num; }
  public function  setchoice_ind($choice_ind )                  { $this->choice_ind         = $choice_ind; }
  public function  setapprove_sts($approve_sts )                { $this->approve_sts        = $approve_sts; }
  public function  setshort_subject_code($short_subject_code )  { $this->short_subject_code = $short_subject_code; }
}
?>
