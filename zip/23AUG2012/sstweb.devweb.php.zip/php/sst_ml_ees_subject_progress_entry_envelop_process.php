<?
      require_once("EesTimeTableModelMethodObj.php");
      require_once("EesTimeTableMethodObj.php");
      require_once("EesAdrMethodObj.php");

     //VARIABLE DECLARATION & GETTING VALUE FROM QUERY STRING
     //------------------------------------------------------------------------------------------
     $lSubjectCode             = "";
     $lClassId                 = "";
     $lMenuOption              = $_GET['menu_option'];
     $lRequestType             = $_GET['req_type'];
     $lAction                  = $_GET['action'];
     $lClassId                 = $_POST['class_id'];
     $lTopicId                 = $_POST['topic_id'];

     if( $lAction !== null && $lAction != 'saveSubmit' )
       $lClassSubjectCode      = $_POST['subject_code'];
     else
       $lSubjectCode           = $_POST['subject_code'];

     $lTodayGUIDate            = $_SESSION['lTodayGUIDate'];
     $lTodayDBDate             = $_SESSION['lTodayDBDate'];
     $lLegendString            = $_SESSION['lLegendString'];
     $lCurrentYear             = $_SESSION['lCurrentYear']; 

     $lEesAdrTabObjArr         = array();
     //------------------------------------------------------------------------------------------

     //TO GET 1 To 31 Of The Month 
     $lDate  = date('d');
     //TO GET 1 To 12 Of The Month 
     $lMonth = date('m');
     //TO GET 1 To 7 Of The Week 
     $lWeekDay = date('N');

     if( $lAction !== null && $lAction != 'saveSubmit' )
     {
       $lClassSubjectCodeArr = explode( ",", $lClassSubjectCode);

       $lSubjectCode  = $lClassSubjectCodeArr[0];
       $lClassId      = $lClassSubjectCodeArr[1];
     }
     
     //TO GET PERIOD NUM
     //------------------------------------------------------------------------------------------
     $lEesTimeTableModelMethodObj = new EesTimeTableModelMethodObj();
     $lEesTimeTableModelMethodObj->lFilteredFileName     = "sst_sgi_ees_timetable_model_".$lCurrentYear."_ext.dat";
     $lEesTimeTableModelMethodObj->lFilterCriteriaValue1 = $lClassId;
     $lEesTimeTableModelMethodObj->lFilteredPosition1    = 3;
     $lEesTimeTableModelMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
     $lEesTimeTableModelMethodObj->lFilteredPosition2    = 14;
     $lEesTimeTableModelMethodObj->lFilterCriteriaValue3 = $lSubjectCode;
     $lEesTimeTableModelMethodObj->lFilteredPosition3    = 7;
     $lEesTimeTableModelMethodObj->lFilterCriteriaValue4 = $lWeekDay;
     $lEesTimeTableModelMethodObj->lFilteredPosition4    = 1;

     $lEesTimeTableModelTabObjArr = $lEesTimeTableModelMethodObj->gtEesTimeTableModelRecByCriteria();
     $lEesTimeTableModelTabObj    = new EesTimeTableModelTabObj();
     //Getting Tab Obj For Period Num 
     $lEesTimeTableModelTabObj    = $lEesTimeTableModelTabObjArr[0];
     //------------------------------------------------------------------------------------------

      
      

 
      //TO GET PLANNED TOPIC PERCENT(%)
     //------------------------------------------------------------------------------------------
     $lEesTimeTableMethodObj = new EesTimeTableMethodObj();

     $lEesTimeTableModelMethodObj->lFilteredFileRelPath  = "/refdb/datafiledir/";
     $lEesTimeTableMethodObj->lFilteredFileName     = "sst_sgi_ees_timetable_".$lCurrentYear."_ext.dat";
     $lEesTimeTableMethodObj->lFilterCriteriaValue1 = $lClassId;
     $lEesTimeTableMethodObj->lFilteredPosition1    = 5;
     $lEesTimeTableMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
     $lEesTimeTableMethodObj->lFilteredPosition2    = 18;
     $lEesTimeTableMethodObj->lFilterCriteriaValue3 = $lSubjectCode;
     $lEesTimeTableMethodObj->lFilteredPosition3    = 9;
     $lEesTimeTableMethodObj->lFilterCriteriaValue4 = $lMonth;
     $lEesTimeTableMethodObj->lFilteredPosition4    = 2;
     $lEesTimeTableMethodObj->lFilterCriteriaValue5 = $lDate;
     $lEesTimeTableMethodObj->lFilteredPosition5    = 3;

     $lEesTimeTableTabObjArr = $lEesTimeTableMethodObj->gtEesTimeTableRecByCriteria();
     $lEesTimeTableTabObj    = new EesTimeTableTabObj();

     //Getting Tab Obj For Period Num 
     $lEesTimeTableTabObj    = $lEesTimeTableTabObjArr[0];
     //------------------------------------------------------------------------------------------


     //TO GET START TIME  & END TIME 
    //----------------------------------------------------------------------------------------------
     $lEesAdrMethodObj = new EesAdrMethodObj();
     $lTodaydate = str_replace("/","",$lTodayDBDate);



    
     //----------------------------------------------------------------------------------------------
     if( $lAction !== null && $lAction == 'saveSubmit' )
     {
        $lSubjectProgFileName = "SST_SGI_EES_ADR"."_"."$lHrEmployeeTabObjGlobal->employee_id"."_".str_replace("/","_",$lTodayDBDate)."_"."SUBJECT_PROGRESS_ext.dat";
        $lEesAdrMethodObj->lSubjectProgFileName = $lSubjectProgFileName;

        //METHOD CALL FOR SUBJECT PROGRESS INSERTION
        $lEesAdrMethodObj->insEesSubjectProgress();
     }
     //----------------------------------------------------------------------------------------------



     if( $lAction !== null && $lAction !== 'saveSubmit' )
     {
       $lEesAdrMethodObj->lFilteredFilePath     = "/refdb/datafiledir/";
       $lEesAdrMethodObj->lFilteredFileName     = "sst_sgi_ees_adr_".$lCurrentYear."_ext.dat";
       $lEesAdrMethodObj->lFilterCriteriaValue4 = $lTodaydate;
       $lEesAdrMethodObj->lFilteredPosition4    = 3;
     }
     else
     {
       $lEesAdrMethodObj->lFilteredFilePath     = "/inbox/";
       $lEesAdrMethodObj->lFilteredFileName     = "SST_SGI_EES_ADR"."_"."$lHrEmployeeTabObjGlobal->employee_id"."_".str_replace("/","_",$lTodayDBDate)."_"."SUBJECT_PROGRESS_ext.dat";
       $lEesAdrMethodObj->lFilterCriteriaValue4 = $lTodayGUIDate;
       $lEesAdrMethodObj->lFilteredPosition4    = 3;
     }

     $lEesAdrMethodObj->lFilterCriteriaValue1 = $lClassId;
     $lEesAdrMethodObj->lFilteredPosition1    = 10;
     $lEesAdrMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
     $lEesAdrMethodObj->lFilteredPosition2    = 1;
     $lEesAdrMethodObj->lFilterCriteriaValue3 = $lSubjectCode;
     $lEesAdrMethodObj->lFilteredPosition3    = 8;
     $lEesAdrMethodObj->lFilterCriteriaValue5 = $lTopicId;
     $lEesAdrMethodObj->lFilteredPosition5    = 4;
 
     $lEesAdrTabObjArr = $lEesAdrMethodObj->gtEesAdrRecByCriteria();
     $lEesAdrTabObj    = new EesAdrTabObj();

     //Getting Tab Obj For Period Num 
     $lEesAdrTabObj    = $lEesAdrTabObjArr[0];
     //----------------------------------------------------------------------------------------------
  

     


 
     echo "<table border=\"0\" width=\"100%\">";

     //COMMON MENU BOX 
     echo"<tr>";
     echo"<td align = \"center\" width = \"80%\">";
     echo"<fieldset>";
     echo"<legend><font color = \"white\" >Dash Board For $lLegendString</font></legend>";
     echo"<table border = \"0\" width = \"100%\"> ";
     echo"<tr>";
     echo"<td>";

     include("sst_ml_common_query_menu_box.php");

     echo"</td>";
     echo"</tr>";
     echo"</table> ";
     echo"</fieldset>";
     echo"</td>";
     echo"</tr> ";
     //COMMON MENU BOX 



     //INCLUDE SINGLE INCLUDE HERE
     echo"<tr>";
     echo"<td align = \"center\" width = \"100%\">";
     echo"<fieldset>";
     echo"<legend><font color = \"white\" >Progress Entry For Subject Code ";
     echo"".$lSubjectCode." and for Class ".$lClassId."</font></legend>";
     echo"<table border = \"0\" width = \"100%\"> ";
     echo"<tr>";
     echo"<td>";

     include("sst_ml_ees_subject_progress_entry_include_single.php");

     echo"</td>";
     echo"</tr>";
     echo"</table> ";
     echo"</fieldset>";
     echo"</td>";
     echo"</tr>";
     //INCLUDE SINGLE INCLUDE HERE


     
     echo"<tr>";
     echo"<td>";
     echo"<fieldset>";
     echo"<legend><font color = \"white\" >Action</font></legend>";
     echo"<table border = \"0\" width = \"100%\"> ";
     echo"<tr>";
     echo"<td>";

     include("sst_ml_ees_subject_progress_entry_action_bar.php");

     echo"</td>";
     echo"</tr>";
     echo"</table> ";
     echo"</fieldset>";
     echo"</td>";
     echo"</tr>";
     



     echo "</table>";
?>
