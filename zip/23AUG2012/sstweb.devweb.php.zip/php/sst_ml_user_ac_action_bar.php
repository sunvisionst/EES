<?
  echo "<table border = \"0\" width = \"100%\">";

  echo "<tr>";

  echo "<input type  = \"hidden\"
               id    = \"action_submit\" 
               name  = \"action_submit\" 
               value = \"\" 
        />";


  if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type == 'admin' )
  {
    echo "<td align = \"center\">";
    echo "<input type  = \"submit\"
                 id    = \"create_submit\" 
                 name  = \"create_submit\" 
                 value = \"Create\" 
                 onClick = \"
                           {
                             document.getElementById('action_submit').value = 'create';
                             var lMandotroyField = 'user_id,password,re_password,first_name';
                             lMandotroyField += ',user_role,last_name,employee_id,dept_id';
                             if ( confMultiNotNullById(event,lMandotroyField) < 0 )
                              ;
                           }
                           \" 
         />";
    echo "</td>";

    echo "<td align = \"center\" colspan = \"2\">";
    echo "<input type  = \"submit\"
                 id    = \"delete_submit\" 
                 name  = \"delete_submit\" 
                 value = \"Delete\" 
                 onClick = \"
                           {
                             var lEmpId = '';
                             var lUsrId = '';
                             var lDDValueArr = (document.getElementById('user_list').value).split(',');
                             lUsrId = lDDValueArr[0];
                             lEmpId = lDDValueArr[1];
                             document.getElementById('action_submit').value = 'delete';
                             if ( confMultiNotNullById(event,'user_list') < 0 )
                              ;
                             javascript:form.action= 'sst_ml_user_ac_envelop.php?action=deleteSubmit&sst_session_id=$lSessionId&sel_user_id='+lUsrId+'&sel_employee_id='+lEmpId+''; 
                           }
                         \" 
          />";
    echo "</td>";
  }
  else
  {
    echo "<td align = \"center\">";
    echo "<input type  = \"submit\"
                 id    = \"update_submit\" 
                 name  = \"update_submit\" 
                 value = \"Update\" 
                 onClick = \"
                           {
                             document.getElementById('action_submit').value = 'update';
                           }
                           \" 
         />";
    echo "</td>";
  }

  echo "</tr>";

  echo "</table>";
?>
