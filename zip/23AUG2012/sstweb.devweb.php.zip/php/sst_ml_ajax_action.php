<?php
{

   session_start();

   require_once("sst_ml_filter_record.php");

   //---------------------------------------------
   $lAjaxAction           = $_GET['ajax_action']; 
   $lFilterCriteriaValue2 = $_GET['criteria_value']; // CRITERIA VALUE ON WHICH FILTERING IS DONE.
   //---------------------------------------------

   $lFilterFilePath        = $_SESSION['lFilterFilePath'];
   $lFilterFileName        = $_SESSION['lFilterFileName'];
   $lFilterCriteriaValue1  = $_SESSION['lFilterCriteriaValue1'];// CRITERIA VALUE ON WHICH FILTERING IS DONE.;

   $lFilterPositionValue1 = $_SESSION['lFilterPositionValue1']; //INDEX POSTION WHERE WE SEARCH THE VALUE
   $lFilterPositionValue2 = $_SESSION['lFilterPositionValue2']; //INDEX POSTION WHERE WE SEARCH THE VALUE;
 
   $lFieldValueIndexPosit = $_SESSION['lFieldValueIndexPosit']; //INDEX POSITION FOR VALUE WHICH POP ON DD
   $lElementId            = $_SESSION['lElementId']; //HOLDING THE DESTINATION FIELD ID        
   //---------------------------------------------
   $lFieldValueIndexPositArr = array();


   //OBJECT FOR FILETER CLASS/////////////////////////////////////
   $lSSTFilter = new SSTFilter();


   //////////////////////////////////////////////////////////////////
   $lSSTFilter->lFilteredFileRelPath   = $lFilterFilePath;
   $lSSTFilter->lFilteredFileName      = $lFilterFileName;

   $lSSTFilter->lFilteredPosition1     = $lFilterPositionValue1;
   $lSSTFilter->lFilteredPosition2     = $lFilterPositionValue2;
   $lSSTFilter->lFilterCriteriaValue1  = $lFilterCriteriaValue1;
   $lSSTFilter->lFilterCriteriaValue2  = $lFilterCriteriaValue2;


   if( count(explode(",",$lFieldValueIndexPosit)) > 1 )
      $lFieldValueIndexPositArr = explode(",", $lFieldValueIndexPosit);


   //FILTER METHID CALL
   $lFilteredRecordArr = $lSSTFilter->filter_record();
  
   echo "    <SELECT id='$lElementId' name='$lElementId' >";
   echo "    <option value=\"\">SELECT</option>";
   if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
   {
     for ( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
     {
       $lFieldValueArr = explode( ",", $lFilteredRecordArr[$lRecNum] );
       if( count(explode(",",$lFieldValueIndexPosit)) > 1 )
       {
         echo "<option value=".$lFieldValueArr[$lFieldValueIndexPositArr[0]].">";
         echo "".$lFieldValueArr[$lFieldValueIndexPositArr[1]]." ";
         echo "(".$lFieldValueArr[$lFieldValueIndexPositArr[0]].")";
         echo "</option>";
       }
       else
       {
         echo"<option value=".$lFieldValueArr[$lFieldValueIndexPosit]."> ".$lFieldValueArr[$lFieldValueIndexPosit]." </option>";
       }
     }
   }
   echo "    </SELECT>";
}
?>
