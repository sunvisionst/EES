<?
  require_once("EesTimeTableTabObj.php");
  require_once("sst_ml_filter_record.php");


  class EesTimeTableMethodObj
  {
     //--------------------------------------------------------------------------------------------------
     public  $lFilteredFileName             = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilterCriteriaValue1         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition1            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue2         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition2            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue3         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition3            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue4         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition4            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue5         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition5            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     //--------------------------------------------------------------------------------------------------

     public function gtEesTimeTableRecByCriteria()
     {
       $lEesTimeTableTabObjArr = array();
       $lSSTFilter             = new SSTFilter();

       //FILTER PART START
       $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/";//ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilteredFileName     = $this->lFilteredFileName; //ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue3 = $this->lFilterCriteriaValue3; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition3    = $this->lFilteredPosition3; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue4 = $this->lFilterCriteriaValue4; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition4    = $this->lFilteredPosition4; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue5 = $this->lFilterCriteriaValue5; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition5    = $this->lFilteredPosition5; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

       //GETTING FILTERED RECORD ARR
       $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          
       if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
       {
         for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
         {
            //PREP TABOBJ OBJECT
            $lEesTimeTableTabObj     = new EesTimeTableTabObj();
            $lFieldArr  = explode( ",", $lFilteredRecordArr[$lRecNum] );

            $lEesTimeTableTabObj->org_id                 =         $lFieldArr[0];
            $lEesTimeTableTabObj->year                   =         $lFieldArr[1];
            $lEesTimeTableTabObj->month                  =         $lFieldArr[2];
            $lEesTimeTableTabObj->day                    =         $lFieldArr[3];
            $lEesTimeTableTabObj->period_num             =         $lFieldArr[4];
            $lEesTimeTableTabObj->class_id               =         $lFieldArr[5];
            $lEesTimeTableTabObj->timetable_id           =         $lFieldArr[6];
            $lEesTimeTableTabObj->timetable_sts          =         $lFieldArr[7];
            $lEesTimeTableTabObj->timetable_sts_date     =         $lFieldArr[8];
            $lEesTimeTableTabObj->subject_code           =         $lFieldArr[9];
            $lEesTimeTableTabObj->class_num              =         $lFieldArr[10];
            $lEesTimeTableTabObj->class_std              =         $lFieldArr[11];
            $lEesTimeTableTabObj->class_section          =         $lFieldArr[12];
            $lEesTimeTableTabObj->course_id              =         $lFieldArr[13];
            $lEesTimeTableTabObj->course_term            =         $lFieldArr[14];
            $lEesTimeTableTabObj->course_stream          =         $lFieldArr[15];
            $lEesTimeTableTabObj->week_num               =         $lFieldArr[16];
            $lEesTimeTableTabObj->period_status          =         $lFieldArr[17];
            $lEesTimeTableTabObj->employee_id            =         $lFieldArr[18];
            $lEesTimeTableTabObj->add_faculty_1          =         $lFieldArr[19];
            $lEesTimeTableTabObj->add_faculty_2          =         $lFieldArr[20];
            $lEesTimeTableTabObj->add_faculty_3          =         $lFieldArr[21];
            $lEesTimeTableTabObj->alternate_faculty      =         $lFieldArr[22];
            $lEesTimeTableTabObj->topic_id               =         $lFieldArr[23];
            $lEesTimeTableTabObj->topic_status           =         $lFieldArr[24];
            $lEesTimeTableTabObj->topic_percent_planned  =         $lFieldArr[25];
            $lEesTimeTableTabObj->building_id            =         $lFieldArr[26];
            $lEesTimeTableTabObj->room_num               =         $lFieldArr[27];
            $lEesTimeTableTabObj->short_subject_code     =         $lFieldArr[28];

            $lEesTimeTableTabObjArr[$lRecNum-1] = $lEesTimeTableTabObj;
         }
       }
 
       if( $lEesTimeTableTabObjArr !== null && count($lEesTimeTableTabObjArr) > 0 )
           return $lEesTimeTableTabObjArr; 
       else
          return null; 

     } 
  }

?>
