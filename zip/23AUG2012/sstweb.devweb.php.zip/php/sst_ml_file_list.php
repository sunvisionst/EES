<?php
 function get_file_list( $inDirName )
 {
   if ($handle = opendir( $inDirName ))
   {
     $lHtmlText = "";
     $lHtmlText .= "<table border=\"1\">";
     $lHtmlText .= "<tr>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Weekday";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Location";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "File Name";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Size";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Access Time";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Modified  Time";
     $lHtmlText .= "</th>";
     $lHtmlText .= "<th>";
     $lHtmlText .= "Create  Time";
     $lHtmlText .= "</th>";
     $lHtmlText .= "</tr>";
     while (false !== ($file = readdir($handle)))
     {
       if ($file != "." && $file != "..")
       {
         $lFileInfo = null;
         $lFileInfo = lstat( $file );
         $lHtmlText .= "<tr>";
         $lHtmlText .= "<td>"."WD"."</td>";
         $lHtmlText .= "<td>"."LOC"."</td>";
         $lHtmlText .= "<td>";
         $lHtmlText .= "<a href=".$file.">".$file."</a>";
         $lHtmlText .= "</td>";
         $lHtmlText .= "<td>".$lFileInfo["size"]."</td>";
         $lHtmlText .= "<td>".date("Y-M-d H:m:s",$lFileInfo["atime"])."</td>";
         $lHtmlText .= "<td>".date("Y-M-d H:m:s",$lFileInfo["mtime"])."</td>";
         $lHtmlText .= "<td>".date("Y-M-d H:m:s",$lFileInfo["ctime"])."</td>";
         $lHtmlText .= "</tr>";
       }
     }
     closedir($handle);
     $lHtmlText .= "</table>";
   }
   return $lHtmlText; 
 }
?>

<html>
<body>
<?php
  echo "<table border=\"1\">";

  
  echo "<tr>";
  echo "<td colspan=\"2\" width=\"100%\">";
  echo "<table width=\"100%\">";

  echo "<tr>";
  echo "<td width=\"25%\">";
  echo "<a href=\"\">Upload</a>";
  echo "</td>";
  echo "<td width=\"25%\">";
  echo "<a href=\"\">Refresh Upload</a>";
  echo "</td>";
  echo "<td width=\"25%\">";
  echo "<a href=\"\">Download</a>";
  echo "</td>";
  echo "<td width=\"25%\">";
  echo "<a href=\"\">Refresh Download</a>";
  echo "</td>";
  echo "</tr>";

  echo "</table>";
  echo "</td>";
  echo "</tr>";


  echo "<tr>";
  echo "<td>";
  echo "Sent Files Log - Last One Week";
  echo "</td>";
  echo "<td>";
  echo "Received Files Log - Last One Week";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  echo "Complete Path";
  echo "</td>";
  echo "<td>";
  echo "Complete Path";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  print get_file_list( "../upload/custmla/SGI/" );
  echo "</td>";

  echo "<td>";
  print get_file_list( "../upload/sstmladc/SGI/" );
  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>
</body>
</html>


<?php
 /*
 ON UPLOAD
 ----------
 1. 
 */

{
  // Dir is the directory to create
  $dir          = $HTTP_GET_VARS["ftpdelme"];
  //$dir          = "ftpdelme";
  $dir          = "/home/eesma/sstweb/devweb/upload/custmla/SGI/inbox/";
  $ftp_ip       = "172.30.10.56";
  $ftp_username = "dev4";
  $ftp_password = "Linux789";
  $proxy_user   = "proxyuser";
  $proxy_pass   = "proxypass";
  $proxy_host   = "172.30.10.29";


  for ( ;; )
  {


    //-----------------------------------------------------
    if($ftp=ftp_connect($ftp_ip))
    {
      echo ("FTP Server - Connected</br>");
    }
    else
    {
      echo ("Couldn't connect to $ftp_server</br>");
      break;
    }
    //-----------------------------------------------------



    //-----------------------------------------------------
    if(ftp_login($ftp,$ftp_username,$ftp_password))
    {
      echo("FTP Server - Login Successful</br>");
    }
    else
    {
      echo ("Couldn't login to $ftp_username</br>");
      break;
    }
    //-----------------------------------------------------


    //-----------------------------------------------------
    // Set to PASV mode
    if ( !(ftp_pasv( $ftp, 1)) )
    {
      echo ("Couldn't SET in PASSIVE MODE</br>");
      break;
    }
    else
    {
      echo ("Passive Mode Set</br>");
    }
    //-----------------------------------------------------



    // ANALYSE BELOW FOR FUTURE USER
    //-----------------------------------------------------
    // If we cannot set our directory to the new one then we create it
    if ( !ftp_chdir($ftp,$dir) )
    {    
      if( !ftp_mkdir($ftp,$dir) )
      {
        echo ("Couldn't Create DIR $dir </br>");
        break;
      }
      echo("Directory $dir created ok</br>");
    }
    else
    {
      echo ("DIR $dir already exists</br>");
    }
    //-----------------------------------------------------



    $inChangeDir = "/refdb/datadir/";
    // recv_files & send_files();

    $inChangeDir = "/refdb/menufiledir/";
    // recv_files & send_files();

    $inChangeDir = "/refdb/datadir/";
    // recv_files & send_files();

    // recv_files
    // send_files
    {
    //-----------------------------------------------------
    if ( !(ftp_chdir($ftp, $dir/$inChangeDir) ) )
    {
      echo ("Couldn't Change To DIR $inChangeDir </br>");
      break;
    }
    echo("Directory Changed To $inChangeDir </br>");
    //-----------------------------------------------------


    // COMMENT BELOW
    //-----------------------------------------------------
    if ( !(ftp_pwd($ftp) ) )
    {
      echo ("Couldn't Show PWD </br>");
      break;
    }
    else
    {
      echo ("PWD is ".ftp_pwd($ftp)." </br>");
    }
    //-----------------------------------------------------


    //-----------------------------------------------------
    // get contents of the current directory
    if ( !( $contents = ftp_nlist($ftp, $dir/$inChnageDir ) ) )
    {
      echo ("Couldn't LIST Directory Content</br>");
      break;
    }
    else
    {
      echo ("Current Directory List</br>");
      for ( $lRecNum=0; $lRecNum <sizeof($contents); $lRecNum++ )
      {
        echo (".....$contents[$lRecNum] </br>");
        if ( $lRecNum > 5 ) break;
      }
    }
    //-----------------------------------------------------



    // LOOP STARTS
    //for ( $lRecNum=0; $lRecNum <sizeof($contents); $lRecNum++ )
    {
      //$file = $contents[$lRecNum];
      $file = "abc";
      //-----------------------------------------------------
      if (ftp_fput($conn_id, $file, $fp, FTP_ASCII))
      {
        echo "Successfully uploaded $file\n";
      }
      else
      {
        echo "There was a problem while uploading $file\n";
      }
      //-----------------------------------------------------
    }
    // LOOP END
    }


    //-----------------------------------------------------
    if ( !ftp_close($ftp) )
    {
      echo ("Couldn't Close Connection From Server $ftp_ip </br>");
      break;
    }
    echo("FTP Server - Connection Closed </br>");
    //-----------------------------------------------------


    break;
  }
}
?>
