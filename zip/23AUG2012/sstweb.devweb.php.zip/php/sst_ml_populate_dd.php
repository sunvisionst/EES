<?
  /*
    METHOD FOR DROP DOWN
    WHICH POPULATED BY THE ARRAY
    RETURN BU POPDD(POPULATE DROP DOWN).
   */

   class SSTPopDDValue
   {
     //member variable
     public $lPrepDDArr = array();
     public $lFileName  = "";

     public function popDD() 
     {
        //-----------------------------------------------------------------------------
        //READ FILE 
        //-----------------------------------------------------------------------------

        //GETTING FILE SOURCE
        //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/refdb/ddfiledir/".$this->lFileName;
        //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/refdb/ddfiledir/".$this->lFileName; 
        $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
        $lFileNamePath .= $this->lFileName;
           
        if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lFileNamePath, "r");
          //GETTING THE SIZE OF THE FILE 
          $lFileSize     = filesize($lFileNamePath);
  
          //echo "FILE size--->".$lFileSize."<br>";
          //-------------------------------------------------------------
          //GEt A ARRAY WITH THE METHOD FGETCSV()
          $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");

          /*
          INIT FOR THE DDARR lPREPDDArr
          IT's NECCESSARY TO PUT NEXT VALUE IN IT
          THROUGH METHOD array_push()
          */ 
          $lPrepDDArr = array( array( $lFieldArr[1], $lFieldArr[2], $lFieldArr[3]) );
          //-------------------------------------------------------------

          while (!feof($lFileHandler))
          {
            $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");

            //USING Multidimensional ARRAY TO STORE VALUE
            //LIKE COURSE_ID, CS, DESCRIPTION as Value
            array_push($lPrepDDArr, array( $lFieldArr[1], $lFieldArr[2], $lFieldArr[3]) );
          }
          //CLOSE THE FILE 
          fclose($lFileHandler); 
        }
        else
        {
          echo "File Not Found!!!";
        }
        return $lPrepDDArr;
     }
   }
?>
