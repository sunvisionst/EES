<?
  //------------------------------------------------
  // LOGIN BOX PANEL
  //------------------------------------------------
  {
    echo "<table border=\"0\" id=\"login_box_tab\" name=\"login_box_tab\">";
 
    echo "<tr>";
    echo "<td align = \"right\">";

    require_once("sst_ml_login_include_single.php");

    if( $lReturnValue < 0 )
    {
      if ( $lReturnValue == -2  )
         echo "<font color=\"red\">Please Fill User & Password.</font>";
      else
         echo "<font color=\"red\">User Name And Password Are Not Correct !!!</font>";
    }
    echo "</td>" ;
    echo "</tr>" ;

 
    echo "<tr>" ;
    echo "<td align =\"center\">" ;

    //Hidden filed for login action
    echo "<input type=\"hidden\" 
                 id=\"action_login\" 
                 name = \"action_login\" 
                 value =\"loginPage\"/>" ;


    echo "<input type=\"submit\" 
                 id=\"login_submit\" 
                 name = \"login_submit\" 
                 onClick = \"{
                               document.getElementById('action_login').value = 'loginUsr';
                             }
                           \" 
                 value =\"Login\"/>" ;
    echo "</td>" ;
    echo "</tr>" ;

    echo "</table>" ;
  }
  //------------------------------------------------
?>
