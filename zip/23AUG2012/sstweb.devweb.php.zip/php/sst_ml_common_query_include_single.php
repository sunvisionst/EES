<?php
    echo "<td width = '70%'>";
    echo " <table border = '0' width = '100%'>";


    
    if( $lMenuOption == 'eesCourse' )
    {
      if( $lCourseId == 'BTECH' )
      {
        $lSSTPopDDValue->lFileName = "sst_".$lOrgId."_ees_course_stream_ext.dat";
        //$lSSTPopDDValue->lFileName = "sst_sgi_ees_course_stream_ext.dat";
        $lCourseStreamDDArr  = $lSSTPopDDValue->popDD();
  
        echo "  <tr>";
        //COURSE STREAM DD
        echo "   <td>";
        echo "Course Stream";
        echo "   </td>";
    
        echo "   <td>";
        echo "    <SELECT id = 'course_stream' name = 'course_stream'>";
        echo "    </SELECT>";
        echo "   </td>";
        //COURSE STREAM DD END
        echo "  </tr>";
      } 
  
      /*  
      if( $lRequestType !== null && $lRequestType == 'subProg')
      {
          $lSubjectAllocationFileName = "sst_sgi_ees_subject_allocation_ext.dat";
          $lEesSubjectAllocationMethodObj = new EesSubjectAllocationMethodObj();

          $lEesSubjectAllocationMethodObj->lSubjectAllocationFileName     = $lSubjectAllocationFileName;
          $lEesSubjectAllocationMethodObj->lFilterCriteriaValue1 = "SGI";
          $lEesSubjectAllocationMethodObj->lFilteredPosition1    = 0;
          $lEesSubjectAllocationMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
          $lEesSubjectAllocationMethodObj->lFilteredPosition2    = 2;

          $lEesSubjectAllocationTabObjArr = $lEesSubjectAllocationMethodObj->gtSubjectAllocationTabObjArr();


          echo "  <tr>";

          //SUBJECT DD
          echo "   <td>";
          echo "  Subject Id ";
          echo "   </td>";
      
          echo "   <td>";
          echo "    <SELECT id = 'subject_code' name = 'subject_code'>";
          echo "    </SELECT>";
          echo "   </td>";
          //SUBJECT DD END

          echo "  </tr>";
      }
      */


      if(  ($lRequestType !== null && $lRequestType == 'facList'         )
        || ($lRequestType !== null && $lRequestType == 'facAllocatedSub' )
        || ($lRequestType !== null && $lRequestType == 'stuList'         )
        || ($lRequestType !== null && $lRequestType == 'classTT'         )
        || ($lRequestType !== null && $lRequestType == 'classAtten'      )
        )
      {
        echo "  <tr>";
        //SECTION DD
        echo "   <td>";
        echo " Class Section ";
        echo "   </td>";
      
        echo "   <td>";
        echo "    <SELECT id = 'class_section' name = 'class_section'>";
        echo "      <Script language = \"JavaScript\">";
                       include("../cache/ITSGN/ees_classsec.js");
        echo "      </Script>";
        echo "    </SELECT>";
        echo "   </td>";
        //SECTION DD END

        echo "  </tr>";
      }


        echo "  <tr>";
        //YEAR DD
        echo "   <td>";
        echo "Course Year";
        echo "   </td>";
  
        echo "   <td>";
        echo "    <SELECT id = 'class_num' name = 'class_num'>";
        echo "      <Script language = \"JavaScript\">";
                     include("../cache/ITSGN/gn_yr_qrt.js");
        echo "      </Script>";
        echo "    </SELECT>";
        echo "   </td>";
        //YEAR DD END
        echo "  </tr>";
  
  
        echo "  </tr>";
        //TERM DD
        echo "   <td>";
        echo "Course Sem/Term";
        echo "   </td>";
    
        echo "   <td>";
        echo "    <SELECT id = 'course_term' name = 'course_term'>";
        echo "      <Script language = \"JavaScript\">";
                     include("../cache/ITSGN/ees_semester.js");
        echo "      </Script>";
        echo "    </SELECT>";
        echo "   </td>";
        //TERM DD END
        echo "  </tr>";
    }
    else
    if( $lMenuOption == 'eesFaculty' )
    {
      //$lEmployeeFileName = "sst_sgi_hr_employee_ext.dat"; 
      $lEmployeeFileName = "sst_".$lOrgId."_hr_employee_ext.dat"; 

      //Create Object of Class HR_EMPLOYEEMETHOD_OBJ        
      $lHrEmployeeMethodObj   = new HrEmployeeMethodObj();

      $lHrEmployeeMethodObj->lEmployeeFileName     = $lEmployeeFileName;
      //$lHrEmployeeMethodObj->lFilterCriteriaValue1 = "SGI";
      $lHrEmployeeMethodObj->lFilterCriteriaValue1 = $lOrgId;
      $lHrEmployeeMethodObj->lFilteredPosition1    = 0;

      $lHrEmployeeTabObjArr = $lHrEmployeeMethodObj->gtHrEmployeeTabObjArr();
 
      echo "  <tr>";
      //FACUlTY STREAM DD
      echo "   <td>";
      echo "Faculty Id";
      echo "   </td>";
    
      echo "   <td>";
      echo "    <SELECT id = 'employee_id' name = 'employee_id'>";
      echo "    </SELECT>";
      echo "   </td>";
      //FACULTY STREAM DD END
      echo "  </tr>";
    }
    else
    if( $lMenuOption == 'eesStudent' )
    {
      //$lStudentFileName = 'sst_sgi_ees_student_ext.dat'; 
      $lStudentFileName = "sst_".$lOrgId."_ees_student_ext.dat"; 

      //Create Object of Class EES_LECTURE_ATTEND_METHOD_OBJ
      $lEesStudentMethodObj   = new EesStudentMethodObj();

      $lEesStudentMethodObj->lFilteredFileName     = $lStudentFileName;
      //$lEesStudentMethodObj->lFilterCriteriaValue1 = "SGI";
      $lEesStudentMethodObj->lFilterCriteriaValue1 = $lOrgId;
      $lEesStudentMethodObj->lFilteredPosition1    = 0;

      $lEesStudentTabObjArr = $lEesStudentMethodObj->gtEesStudentTabObjArr();

      echo "  <tr>";
      //STUDENT DD
      echo "   <td>";
      echo "Student Id";
      echo "   </td>";
  
      echo "   <td>";
      echo "    <SELECT id = 'student_id' name = 'student_id'>";
      echo "    </SELECT>";
      echo "   </td>";
      //STUDENT DD END
      echo "  </tr>";
    }

    if(  ( $lRequestType !== null && $lRequestType == 'facTT'       )
      || ( $lRequestType !== null && $lRequestType == 'stuAtten'    )
      || ( $lRequestType !== null && $lRequestType == 'classAtten')
      )
    { 
      echo "  <tr>";
      //MONTH DD
      echo "   <td>";
      echo "Month";
      echo "   </td>";
    
      echo "   <td>";
      echo "    <SELECT id = 'month' name = 'month'>";
      echo "      <Script language = \"JavaScript\">";
               include("../cache/ITSM/gn_month.js");
      echo "      </Script>";
      echo "    </SELECT>";
      echo "   </td>";
      //MONTH DD END
      echo "  </tr>";
    } 




    echo " </table>";
    echo "</td>";

    //LOOP ON ARRAY TO ADD VALUE IN DD
    if( $lCourseId !== null && $lCourseId == 'BTECH' )
    {
      if( $lCourseStreamDDArr != null && count($lCourseStreamDDArr) > 0 )
      {
        echo "<Script language = \"JavaScript\">";
        echo "{";
        echo "  addOptVal( 'course_stream', '', 'SELECT STREAM' );";
        for( $lRecNum = 0; $lRecNum < count($lCourseStreamDDArr); $lRecNum++ )
        {
          echo "  addOptVal(  'course_stream'
                              , '".$lCourseStreamDDArr[$lRecNum][1]."'
                              , '".$lCourseStreamDDArr[$lRecNum][2]."' 
                           );";
        }
        echo "}";
        echo "</Script>"; 
      }
      else
      {
        echo "<Script language = \"JavaScript\">";
        echo "  addOptVal( 'course_stream', '', 'COURSE STREAM NOT YET DEFINED' );";
        echo "</Script>"; 
      }
    }



    //DD FOR SUBJECT CODE
    /*
    if( $lRequestType !== null && $lRequestType == 'subProg')
    {
      if( $lEesSubjectAllocationTabObjArr !== null && count($lEesSubjectAllocationTabObjArr) > 0 )
      {
        echo "<Script language = \"JavaScript\">";
        echo "{";
        echo "  addOptVal( 'subject_code', '', 'SELECT SUBJECT' );";
        for( $lRecNum = 0; $lRecNum < count($lEesSubjectAllocationTabObjArr); $lRecNum++ )
        {
          $lEesSubjectAllocationTabObj = new EesSubjectAllocationTabObj(); 
          $lEesSubjectAllocationTabObj = $lEesSubjectAllocationTabObjArr[$lRecNum];
   
          echo "  addOptVal(  'subject_code'
                                , '".$lEesSubjectAllocationTabObj->subject_code."'
                                , '".$lEesSubjectAllocationTabObj->subject_code." (".$lEesSubjectAllocationTabObj->subject_code.")' 
                             );";
          
        }
        echo "}";
        echo "</Script>";
      }
      else
      {
        echo "<Script language = \"JavaScript\">";
        echo "  addOptVal( 'subject_code', '', 'SUBJECT NOT YET DEFINED' );";
        echo "</Script>";
      }
    }
    */

    //DD FOR SUBJECT CODE


    //DD FOR HR EMPLOYEE 
    if(  ( $lRequestType !== null && $lRequestType == 'facProfile' )
      || ( $lRequestType !== null && $lRequestType == 'facTT' )
      || ( $lRequestType !== null && $lRequestType == 'facAllocatedSubject' )
      )
    {
      if( $lHrEmployeeTabObjArr != null && count($lHrEmployeeTabObjArr) > 0 )
      {
        echo "<Script language = \"JavaScript\">";
        echo "{";
        echo "  addOptVal( 'employee_id', '', 'SELECT EMPLOYEE' );";
        for( $lRecNum = 0; $lRecNum < count($lHrEmployeeTabObjArr); $lRecNum++ )
        {
          $lHrEmployeeTabObj  = new HrEmployeeTabObj();
          $lHrEmployeeTabObj  = $lHrEmployeeTabObjArr[$lRecNum];
         
          echo "  addOptVal(  'employee_id'";
          echo " , '".$lHrEmployeeTabObj->employee_id."'";
          echo " , '".$lHrEmployeeTabObj->employee_f_name."";
          echo " ".$lHrEmployeeTabObj->employee_l_name."(".$lHrEmployeeTabObj->employee_id.")'"; 
          echo ");";
        }
        echo "}";
        echo "</Script>"; 
      }
      else
      {
        echo "<Script language = \"JavaScript\">";
        echo "  addOptVal( 'employee_id', '', 'EMPLOYEE NOT YET DEFINED' );";
        echo "</Script>"; 
      }
    }



    if($lMenuOption  !== null && $lMenuOption  == 'eesStudent')
    {
      if( $lEesStudentTabObjArr != null && count($lEesStudentTabObjArr) > 0 )
      {
        echo "<Script language = \"JavaScript\">";
        echo "{";
        echo "  addOptVal( 'student_id', '', 'SELECT STUDENT' );";
        for( $lRecNum = 0; $lRecNum < count($lEesStudentTabObjArr); $lRecNum++ )
        {
          $lEesStudentTabObj  = new EesStudentTabObj();
          $lEesStudentTabObj  = $lEesStudentTabObjArr[$lRecNum];
          
          echo "  addOptVal(  'student_id'
                              , '".$lEesStudentTabObj->roll_num."'
                              , '".$lEesStudentTabObj->student_name." (".$lEesStudentTabObj->roll_num.")' 
                           );";
         
        }
        echo "}";
        echo "</Script>"; 
      }
      else
      {
        echo "<Script language = \"JavaScript\">";
        echo "  addOptVal( 'student_id', '', 'STUDENT NOT YET DEFINED' );";
        echo "</Script>"; 
      }
    }

?>
