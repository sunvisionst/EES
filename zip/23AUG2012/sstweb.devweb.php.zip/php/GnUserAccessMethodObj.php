<?
  require_once("GnUserAccessTabObj.php");
  require_once("sst_ml_filter_record.php");

  class GnUserAccessMethodObj    
  {
    //--------------------------------------------------------------------------------------------------
    public  $lUserFileName         = null;
    public  $lTodayDate            = "";

    //public  $lFilteredFileName     = null; //ASSIGN FILE NAME TO FILTER
    public  $lFilterCriteriaValue1 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition1    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    public  $lFilterCriteriaValue2 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition2    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    //--------------------------------------------------------------------------------------------------




    /*
     This Function is used to create
     User On Admin Login Link Create User.
    */
    public function createGnUserAccess()
    {
      //GETTING FILE SOURCE
      $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      $lFileNamePath .= $this->lUserFileName;
      $lGnUserAccessArr     = array();
 
      if( isset( $_POST['org_id'] ) )
        $lOrgId          = $_POST['org_id']; 
      else
        $lOrgId          = ""; 
       
      if( isset( $_POST['user_id'] ) )
        $lUserId         = $_POST['user_id'];
      else
        $lUserId         = ""; 

      if( isset( $_POST['appln_short_name'] ) )
        $lApplnShortName = $_POST['appln_short_name'];
      else
        $lApplnShortName = ""; 

      if( isset( $_POST['employee_id'] ) )
        $lEmployeeId     = $_POST['employee_id'];
      else 
        $lEmployeeId     = "";


      if( isset( $_POST['user_role'] ) )
        $lUserRole       = $_POST['user_role'];
      else 
        $lUserRole       = "";


      if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      {
         $lGnUserAccessArr     = $this->readGnUserAccessData();
         try
         {
           //OPEN A FILE FROM THE GIVEN PATH
           $lFileHandler  = fopen($lFileNamePath, "w") or die("FILE CAN NOT BE OPEN !!");
         
            if( $lGnUserAccessArr !== null && count($lGnUserAccessArr) > 0 )
            {
              for( $lRecNum = 1; $lRecNum <= count ($lGnUserAccessArr); $lRecNum++ )
              {
                $lWriteLineData = $lGnUserAccessArr[$lRecNum-1];
                fwrite( $lFileHandler, $lWriteLineData );
              }
            }

            //PREPARE DATA FOR WRITE
            $lCSVFileData = $lOrgId.",".$lApplnShortName.",".$lUserId.",".$lUserRole.",,".$lEmployeeId.",,,\n"; 
            fwrite($lFileHandler, $lCSVFileData);
         }
         catch (Exception $Ex )
         {
           echo $Ex->getMessage();
           return -1;
         }
         // Close the file
         fclose($lFileHandler);
      }
      else
       return -1;  //FILE DOES NOT EXISTS

      return 0;
    }


    private function readGnUserAccessData()
    {
       $lRecNum         = 0;
       $lGnUserAccessArr      = array();

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lUserFileName;

         //OPEN A FILE FROM THE GIVEN PATH
         if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         if ( filesize ($lFileNamePath) > 0 )
         {
           $lFileHandler  = fopen($lFileNamePath, "r") or die("FILE CAN NOT BE OPEN !!");
           //GETTING THE SIZE OF THE FILE 
           $lFileSize     = filesize($lFileNamePath);

            while (!feof($lFileHandler))
            {
               if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )
               {
                 $lGnUserAccessArr[$lRecNum] = $lRecordLine;
                 $lRecNum = $lRecNum + 1;
               }
            }
         }
         else
          return null;
       }
       catch (Exception $Ex )
       {
           echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);

       if( $lGnUserAccessArr !== null && count( $lGnUserAccessArr ) > 0 )
          return $lGnUserAccessArr;
       else
         null;
    }



    public function deleteGnUserAccess($lOrgId, $lUserId)
    {
       $lDELETED_SUUCESSFUL = "false";

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lUserFileName;
         /*
          This Array Will Contain All the Employee Data
         */

         $lGnUserArrAccess = $this->readGnUserAccessData();

         if( $lGnUserArrAccess !== null && count( $lGnUserArrAccess ) > 0 )
         {
           for( $lRecNum = 0; $lRecNum < count( $lGnUserArrAccess ); $lRecNum++ )
           {
             $lRecordLine    = $lGnUserArrAccess[$lRecNum];
             $lFieldValueArr = explode( ",", $lRecordLine );

             if( $lOrgId == $lFieldValueArr[0] )
               if( $lUserId == $lFieldValueArr[2] )
               {
                 unset( $lGnUserArrAccess[$lRecNum] );//THIS WILL REMOVE THE INDEX POS VALUE
                 $lGnUserArrAccess = array_values($lGnUserArrAccess);//THIS WILL TRANSFER THE VALUE WITH NEW INDEXS\
                 $lDELETED_SUUCESSFUL = "true";
                 break;
               }
           }
         }

         if( $lDELETED_SUUCESSFUL == "true" )
         {
           // Open the file and erase the contents if any
           $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

           if( $lGnUserArrAccess !== null && count($lGnUserArrAccess) > 0 )
           {
             for( $lRecNum = 1; $lRecNum <= count ($lGnUserArrAccess); $lRecNum++ )
             {
               $lWriteLineData = $lGnUserArrAccess[$lRecNum-1];
               fwrite( $lFileHandler, $lWriteLineData );
             }
           }
         }
         else
          return -1;
       }
       catch (Exception $Ex )
       {
         echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);
       return 0;
    }
  }
?>
