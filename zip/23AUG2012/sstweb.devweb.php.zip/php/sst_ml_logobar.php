<?


  //-----------------------------------------------------------------------------------
  echo "<td name=\"client_logo_td\" id=\"client_logo_td\" align=\"left\" width=\"15%\">";
  //echo "<link rel=\"shortcut icon\" href=\"../images/"+lGnApplnSessionTabObjLogin.org_id+"/sst_img_logo_small.jpg\" type=\"image/x-icon\"> ";
  echo "<img rel=\"shortcut icon\" src=\"../images/".$lOrgId."/sst_img_logo_small.jpg\" type=\"image/x-icon\"> ";
  echo "</td>";
  //-----------------------------------------------------------------------------------




  //-----------------------------------------------------------------------------------
  echo "<td name=\"prod_name_td\" id=\"prod_name_td\" align=\"center\" bgcolor =\"darkred\">";
  // IF NOT LOGIN
  echo "<h1><font color=\"white\">Academic IT Enabler</font> </h1><br>"; // BEFORE LOGIN
  // ELSE
  //echo "<H1><font color=\"white\">".$lOrgName."</font></H1>"; // AFTER LOGIN
  echo "</td>";
  //-----------------------------------------------------------------------------------




  //-----------------------------------------------------------------------------------
  echo "<td name=\"sst_logo_td\" id=\"sst_logo_td\" align=\"left\" width=\"15%\">";
  //echo "<link rel=\"shortcut icon\" href=\"../images/".$lOrgId."/sst_img_logo_small.jpg\" type=\"image/x-icon\"> ";
  echo "<img rel=\"shortcut icon\" src=\"../images/".$lOrgId."/sst_img_logo_small.jpg\" type=\"image/x-icon\"> ";
  echo "</td>";
  //-----------------------------------------------------------------------------------



?>
