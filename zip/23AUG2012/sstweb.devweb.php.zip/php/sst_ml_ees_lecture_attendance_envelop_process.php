<?php

     require_once("EesLectureAttendMethodObj.php");///MUST BE INCLUDED IN INTERFACE PHP FILE
     require_once("EesStudentMethodObj.php");///MUST BE INCLUDED IN INTERFACE PHP FILE


     echo"<html> ";
     echo"  <head> ";
     echo "   <Script language = \"JavaScript\">";
              //include("../js/gn_prep_dd_option.js");//FOR ADD_OPT FUNCTION
     echo "   </Script>";
     echo"  </head> ";



     //--------------------------------------------------------------------------
     //VARIABLE DECLARATION & GETTING VALUE FROM QUERY STRING
     $lMenuOption         = $_GET['menu_option'];
     $lRequestType        = $_GET['req_type'];
     $lAction             = $_GET['action'];

     $lSubjectCode        = $_POST['subject_code'];
     $lClassSection       = $_POST['class_section'];
     $lPeriodNum          = $_POST['period_num'];
     $lTodayDBDate        = $_SESSION['lTodayDBDate'];
     $lTodayGUIDate       = $_SESSION['lTodayGUIDate'];
     $lCurrentMonth       = $_SESSION['lCurrentMonth'];


     //Hidden field for period_num
     echo "<input type=\"hidden\" name=\"period_num\" name=\"period_num\" value=\"$lPeriodNum\">";



     /*
     SPLIT THE VALUE OF SUBJECT CODE 
     TO GET THE COURSE, STRAEM, YEAR &
     TERM.
     */
     $lSplitSubjectCodeArr = explode( "-", $lSubjectCode);
     $lCourseStreamYrArr   = explode( "/", $lSplitSubjectCodeArr[2] );


     //THE ONLY REASON TO REDUCE 
     //THE LINE OF CODE
     $lIndexPos = 0;

     $lCourseId           = $lCourseStreamYrArr[$lIndexPos++];                     

     if( $lCourseId !== null && $lCourseId != "MCA" )
       $lCourseStream       = $lCourseStreamYrArr[$lIndexPos++];

     $lClassNum           = $lCourseStreamYrArr[$lIndexPos++];                      
     $lCourseTerm         = $lCourseStreamYrArr[$lIndexPos]; 
       
 
     $lLegendString       = $_SESSION['lLegendString'];
     $lEesLectureAttendTabObjArr = array();
     //--------------------------------------------------------------------------
     


     //--------------------------------------------------------------------------
     //Create Object of Class EES_LECTURE_ATTEND_METHOD_OBJ
     $lEesLectureAttendMethodObj   = new EesLectureAttendMethodObj();
     $lEesStudentMethodObj         = new EesStudentMethodObj();
     //--------------------------------------------------------------------------




     //--------------------------------------------------------------------------
     if( $lCourseId !== null && $lCourseId == 'BTECH' )
       ;
     else
       $lCourseStream = "NA";
     //--------------------------------------------------------------------------

     //FILE FOR HIDDEN FIELD
     include("sst_ml_ees_hidden_field.php");                                          


     //--------------------------------------------------------------------------
     //GETTING STUDENT FILE ON THE BASIS OF CLASS ID 
     //$lStudentFileName = 'sst_sgi_ees_student'.'_'.$lCourseId.'_'.$lCourseStream.'_'.$lClassNum.'_'.$lCourseTerm.'_'.$lClassSection.'_'.'ext.dat';
     //$lStudentFileName = 'sst_sgi_ees_student_ext.dat';
     $lStudentFileName = "sst_".$lOrgId."_ees_student_ext.dat";
     //--------------------------------------------------------------------------



 
     //--------------------------------------------------------------------------
     //GETTING ATTENDANCE FILE 
     //REPLACE THE OCCURENACE OF - & / in to _ of SUBJECT CODE
     $lSubjectCodeTmp = str_replace("/", "_", $lSubjectCode);
     $lSubjectCodeTmp = str_replace("-", "_", $lSubjectCodeTmp);

      
     $lTodayDate = str_replace("/","_",$lTodayDBDate);

     //file name format sst_org_ees_lecture_attend_subject_code_classid_todaydate_student_attendance_ext.dat
     //$lAttendFileName = "SST_SGI_EES_LECTURE_ATTEND"."_".$lSubjectCodeTmp."_".$lCourseId.'_'.$lCourseStream.'_'.$lClassNum.'_'.$lCourseTerm.'_'.$lClassSection.'_'.$lTodayDate."_"."STUDENT_ATTENDANCE_ext.dat";
     $lAttendFileName = "SST_".$lOrgId."_EES_LECTURE_ATTEND"."_".$lSubjectCodeTmp."_".$lCourseId.'_'.$lCourseStream.'_'.$lClassNum.'_'.$lCourseTerm.'_'.$lClassSection.'_'.$lTodayDate."_"."STUDENT_ATTENDANCE_ext.dat";
     //--------------------------------------------------------------------------

     //echo "AAA---".$lAttendFileName;

     if( $lCourseId !== null && $lCourseId == 'BTECH' )
       $lClassIdTemp = $lCourseId."/".$lCourseStream."/".$lClassNum."/".$lCourseTerm."/".$lClassSection;
     else  
     if( $lCourseId !== null && $lCourseId == 'MCA' )
       $lClassIdTemp = $lCourseId."/".$lClassNum."/".$lCourseTerm."/".$lClassSection;


     //ASSIGN SOME VALUE TO THE 
     //CLASS MEMBER. 
     //--------------------------------------------------------------------------
     $lEesLectureAttendMethodObj->lAttendanceFileName = $lAttendFileName; 
     $lEesLectureAttendMethodObj->lTodayDate          = $lTodayDBDate;
     $lEesLectureAttendMethodObj->lCourseId           = $lClassIdTemp;
     //--------------------------------------------------------------------------



     //--------------------------------------------------------------------------
     $lEesStudentMethodObj->lStudentFileName    = $lStudentFileName; 
     $lEesStudentMethodObj->lFilteredFileName     = $lStudentFileName; 
     $lEesStudentMethodObj->lFilterCriteriaValue1 = $lClassIdTemp; 
     $lEesStudentMethodObj->lFilteredPosition1    = 27; 

     //GETTING STUDENT ARR
     $lEesStudentTabObjArr                     = $lEesStudentMethodObj->gtEesStudentTabObjArr();
     //--------------------------------------------------------------------------



     //--------------------------------------------------------------------------
     $lEesLectureAttendMethodObj->lRecordSize  = count($lEesStudentTabObjArr); 
     //--------------------------------------------------------------------------



     //--------------------------------------------------------------------------
     //CHECK FILE IF IT's ALREADY APPROVED
     $lEesLectureAttendMethodObj->checkApproved(); 
     //--------------------------------------------------------------------------




   



     //--------------------------------------------------------------------------
     if( $lAction !==null && $lAction == 'saveSubmit' )
     {
        //METHOD CALL FOR ATTENDANCE RECORD INSERTION
        $lEesLectureAttendMethodObj->prepStudentATTND();
     } 
     else
     if( $lAction !==null && $lAction == 'approveSubmit' )
     {
        //METHOD CALL FOR APPROVAL OF ATTANDANCE 
        $lEesLectureAttendMethodObj->approveStudentAttend();
     } 
    //--------------------------------------------------------------------------
    



     //--------------------------------------------------------------------------
     //CHECK FILE IF IT's ALREADY EXISTS   
     $lEesLectureAttendMethodObj->checkStudentATTND(); 
     //--------------------------------------------------------------------------



   

 
    //--------------------------------------------------------------------------
    //METHOD CALL TO CHECK IF ATTENDANCE ALLREADY PREP
    if( $lEesLectureAttendMethodObj->lALREADY_ATTENDANCE !== null )
      if( $lEesLectureAttendMethodObj->lALREADY_ATTENDANCE == "true" )
        $lEesLectureAttendTabObjArr = $lEesLectureAttendMethodObj->readStudentATTND();
    //--------------------------------------------------------------------------

    


 
     //--------------------------------------------------------------------------
     echo "<table id=\"\" name=\"\" border=\"0\" width=\"100%\">";
     echo "<tr>";
 
     echo "<td>"; 
     echo "<fieldset>";
     echo "<legend><font color = \"white\" >Dash Board For $lLegendString</font></legend>";
     echo "<table border = \"0\" width = \"100%\"> ";
     echo "<tr>";
     echo "<td>";

     include("sst_ml_common_query_menu_box.php");

     echo "</td>";
     echo "</tr>";
     echo "</table> ";
     echo "</fieldset>";

     echo "</td>"; 
     echo "</tr>"; 
     //--------------------------------------------------------------------------




     //--------------------------------------------------------------------------
     echo "<tr>"; 
     echo "<td align=\"center\">"; 
    
      
     if( $lEesStudentTabObjArr !== null && count($lEesStudentTabObjArr) > 0 )
     {    
       echo "<table border = \"0\" width = \"70%\"> ";

       echo "<tr>";
       echo "<fieldset>";
       echo "<legend><font color = \"white\" >Attendance For Class " .$lSplitSubjectCodeArr[2]."/".$lClassSection."</font></legend>";
       echo "</fieldset>";
       echo "<tr>";

       echo "</tr>";
       include ("sst_ml_ees_lecture_attend_multi_include_th.php");
       echo "</tr>";


       for( $lStudRec = 1; $lStudRec < count($lEesStudentTabObjArr); $lStudRec++ )
       {
         $lFieldValue = "";
         $lEesLectureAttndTabObjKey   = ""; 
         $lEesLectureAttendTabObj  = new EesLectureAttendTabObj();
         $lEesStudentTabObj        = new EesStudentTabObj();
         $lEesStudentTabObj        = $lEesStudentTabObjArr[$lStudRec-1];

         echo "<tr>";
         include ("sst_ml_ees_lecture_attend_include_multi.php");
         echo "</tr>";
       }
       echo "</tr>";
       echo "</table>";
     }
     else
     {
        echo "<Script language=\"JavaScript\">"; 
        echo "alert('Student File Not Found For This Class !!!.');"; 
        echo "</Script>"; 
     }
     

     echo "</td>"; 
     echo "</tr>"; 


    if( $lEesStudentTabObjArr !== null && count($lEesStudentTabObjArr) > 0 )
      if( $lEesLectureAttendMethodObj->lALREADY_APPORVED !== null && $lEesLectureAttendMethodObj->lALREADY_APPORVED == false )
      {
        echo "<tr>"; 

        echo"<td align = \"center\" width = \"50%\">";
        echo"<fieldset>";
        echo"<legend><font color = \"white\" >Submit Action</font></legend>";
        echo"<table border = \"0\" width = \"100%\"> ";
        echo"<tr>";
        echo"<td align = \"center\">";

        include("sst_ml_ees_lecture_attendance_action_bar.php");
  
        echo"</td>";
        echo"</tr>";
        echo"</table> ";
        echo"</td>";
  
        echo "</tr>"; 
      }
     echo "</table>";
     echo "</html> ";
?>
