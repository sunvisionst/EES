<?
 echo "<th align=\"right\"> Student Id</th>";
 echo "<th align=\"right\"> Student Name</th>";
 echo "<th align=\"right\"> Marks</th>";
?>
