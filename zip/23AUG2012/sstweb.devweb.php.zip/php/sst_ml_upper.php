<?

  if( !isset( $_POST['sst_session_id'] ))
   ;
  else
    $lSessionId = $_POST['sst_session_id'];

  if( !isset( $_GET['sst_session_id'] ))
   ;
  else
    $lSessionId = $_GET['sst_session_id'];


   if( $lSessionId == null || strlen($lSessionId) == 0 )
   {
     if( $lSubmitAction !== null && $lSubmitAction == 'loginUsr' )
     {
       $lSSTMlaSession = new SSTMlaSession();
        
       //------------------------------------------------------------------------------------------------------
       $lCurrentYear  = date("Y");
       $lCurrentDate  = date("d");
       $lCurrentMonth = date("m");
       $lTodayDBDate  = date("Y/m/d");  
       $lTodayGUIDate = date("d-M-Y");  
 
       //------------------------------------------------------------------------------------------------------
       //-----------------------CHECK USER AUTHENTICATION------------------------------------------------------
       //------------------------------------------------------------------------------------------------------
       $lSSTLogin->lPath             = $SST_MLA_HOME_PREFIX.$SST_MLA_HOME_CUST_DC."SGI/".$SST_MLA_DATA_DIR;
       $lSSTLogin->lUserFileName     = "sst_".$lOrgId."_gn_user_ext.dat";
       $lSSTLogin->lEmployeeFileName = "sst_".$lOrgId."_hr_employee_ext.dat";

       $lReturnValue = $lSSTLogin->user_Auth($lUserId, $lUserPass, $lOrgId);  // user_auth();
       //------------------------------------------------------------------------------------------------------

 
       if( $lReturnValue < 0 )
         ;
       else
       {
        //METHOD TO GENERATE AND SET A SESSION ID
        $lSSTMlaSession->sessionId();
        $lSessionId             = session_id();
       }
     }
   }

    
   if( strlen($lSessionId) > 0 )
   {
     session_id($lSessionId);
     session_start();

 
     if( $lSubmitAction !== null && $lSubmitAction == 'loginUsr' )
     {
       $_SESSION['lSessionId']    = $lSessionId;
       $_SESSION['lCurrentYear']  = $lCurrentYear;
       $_SESSION['lCurrentDate']  = $lCurrentDate;
       $_SESSION['lCurrentMonth'] = $lCurrentMonth;
       $_SESSION['lTodayDBDate']  = $lTodayDBDate;
       $_SESSION['lTodayGUIDate'] = $lTodayGUIDate;

       //SETTING ENVOIRNMENT VARIABLES
       $_SESSION['SST_DC_DATA_DIR']        = getenv('SST_DC_DATA_DIR');
       $_SESSION['SST_DC_INBOX_DIR']       = getenv('SST_DC_INBOX_DIR');
       $_SESSION['SST_DC_OUTBOX_DIR']      = getenv('SST_DC_OUTBOX_DIR');
       $_SESSION['SST_MLA_HOME']           = getenv('SST_MLA_HOME');
       $_SESSION['SST_MLA_INSTALL']        = getenv('SST_MLA_INSTALL');
       $_SESSION['SST_MLA_DATA_INSTALL']   = getenv('SST_MLA_DATA_INSTALL');
       $_SESSION['SST_MLA_DATA_DIR']       = getenv('SST_MLA_DATA_DIR');
       $_SESSION['SST_MLA_MENU_DIR']       = getenv('SST_MLA_MENU_DIR');
       $_SESSION['SST_MLA_INBOX_DIR']      = getenv('SST_MLA_INBOX_DIR');
       $_SESSION['SST_MLA_OUTBOX_DIR']     = getenv('SST_MLA_OUTBOX_DIR');
       $_SESSION['SST_MLA_FILTER_PATH']    = getenv('SST_MLA_FILTER_PATH');

       //THIS CHECKS FOR NUM OF USER IN THE FILE 
       $_SESSION['lCheckUserQty'] = $lSSTLogin->lCheckUserQty;

       require_once("sst_ml_after_login_envelop_process.php"); 
     }
   }

  
  
   if( isset($_SESSION['lSessionId'] ) )
   {
     //SETTING GLOBAL EMPLOYEE TABOBJ VALUE
     if( isset($_SESSION['lHrEmployeeTabObjGlobal'] ) )
       $lHrEmployeeTabObjGlobal   = unserialize($_SESSION['lHrEmployeeTabObjGlobal']); 
  
     if( isset($_SESSION['lGnUserTabObj'] ) ) 
       $lGnUserTabObj    = unserialize($_SESSION['lGnUserTabObj']);
       
     if( isset( $_SESSION['lGnApplnSessionTabObj'] ) )
       $lGnApplnSessionTabObj = unserialize($_SESSION['lGnApplnSessionTabObj']);
  
     if( isset($_SESSION['lOrgId'] ) )
       $lOrgId        = $_SESSION['lOrgId'];
  
     if( isset($_SESSION['lCurrentYear'] ) )
       $lCurrentYear  = $_SESSION['lCurrentYear'];
    
     if( isset($_SESSION['lCurrentDate'] ) )
       $lCurrentDate  = $_SESSION['lCurrentDate'];
    
     if( isset($_SESSION['lCurrentMonth'] ) )
       $lCurrentMonth = $_SESSION['lCurrentMonth'];
    
     if( isset($_SESSION['lTodayDBDate'] ) )
       $lTodayDBDate  = $_SESSION['lTodayDBDate'];
  
     if( isset($_SESSION['lTodayGUIDate'] ) )
       $lTodayGUIDate = $_SESSION['lTodayGUIDate'];

     if( isset($_SESSION['lCheckUserQty']) )
       $lCheckUserQty = $_SESSION['lCheckUserQty'];
   } 
  
   echo "<input type = \"hidden\" 
                id=\"sst_session_id\" 
                name=\"sst_session_id\" 
                value = \"$lSessionId\">";
   

  //--------------------------------------------------------
  // LOGO BAR - STARTS
  echo "<tr bgcolor=\"white\">";
  include("sst_ml_logobar.php");
  echo "</tr>";
  // LOGO BAR - ENDS



  // BANNER TR - STARTS
  echo "<tr>";
  include("sst_ml_banner.php");
  echo "</tr>";
  // BANNER TR - ENDS



  // BANNER TR - STARTS
  echo "<tr>";
  include("sst_ml_after_logobar.php");
  echo "</tr>";
  // BANNER TR - ENDS
  //--------------------------------------------------------

?>
