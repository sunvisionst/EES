<?php
     //-----------------------------------------
     //READ MENU FILE CONTENT
     //-----------------------------------------

     
     /*echo "SCRIPT_FILENAME:",$_SERVER['SCRIPT_FILENAME'],"<br>";
     echo "SERVER_NAME:",$_SERVER['SERVER_NAME'],"<br>";
     echo "SERVER_ADDR:",$_SERVER['SERVER_ADDR'],"<br>";
     echo "DOCUMENT_ROOT:",$_SERVER['DOCUMENT_ROOT'],"<br>";
     echo "GATEWAY_INTERFACE:",$_SERVER['GATEWAY_INTERFACE'],"<br>";
     echo "SERVER_PROTOCOL:",$_SERVER['SERVER_PROTOCOL'],"<br>";
     echo "REQUEST_METHOD:",$_SERVER['REQUEST_METHOD'],"<br>";
     echo "REQUEST_TIME:",$_SERVER['REQUEST_TIME'],"<br>";
     echo "QUERY_STRING:",$_SERVER['QUERY_STRING'],"<br>";
     echo "HTTP_ACCEPT:",$_SERVER['HTTP_ACCEPT'],"<br>";
     echo "HTTP_ACCEPT_CHARSET:",$_SERVER['HTTP_ACCEPT_CHARSET'],"<br>";
     echo "HTTP_ACCEPT_ENCODING:",$_SERVER['HTTP_ACCEPT_ENCODING'],"<br>";
     echo "HTTP_ACCEPT_LANGUAGE:",$_SERVER['HTTP_ACCEPT_LANGUAGE'],"<br>";
     echo "HTTP_CONNECTION:",$_SERVER['HTTP_CONNECTION'],"<br>";
     echo "HTTP_HOST:",$_SERVER['HTTP_HOST'],"<br>";
     //echo "HTTP_REFERER:",$_SERVER['HTTP_REFERER'],"<br>";
     echo "HTTP_USER_AGENT:",$_SERVER['HTTP_USER_AGENT'],"<br>";
     //echo "HTTPS:",$_SERVER['HTTPS'],"<br>";
     echo "REMOTE_ADDR:",$_SERVER['REMOTE_ADDR'],"<br>";
     //echo "REMOTE_HOST:",$_SERVER['REMOTE_HOST'],"<br>";
     echo "REMOTE_PORT:",$_SERVER['REMOTE_PORT'],"<br>";
     echo "SERVER_ADMIN:",$_SERVER['SERVER_ADMIN'],"<br>";
     echo "SERVER_PORT:",$_SERVER['SERVER_PORT'],"<br>";
     echo "SERVER_SIGNATURE:",$_SERVER['SERVER_SIGNATURE'],"<br>";
     //echo "PATH_TRANSLATED:",$_SERVER['PATH_TRANSLATED'],"<br>";
     echo "SCRIPT_NAME:",$_SERVER['SCRIPT_NAME'],"<br>";
     echo "REQUEST_URI:",$_SERVER['REQUEST_URI'],"<br>";
     //echo "PHP_AUTH_DIGEST:",$_SERVER['PHP_AUTH_DIGEST'],"<br>";
     //echo "PHP_AUTH_USER:",$_SERVER['PHP_AUTH_USER'],"<br>";
     //echo "PHP_AUTH_PW:",$_SERVER['PHP_AUTH_PW'],"<br>";
     //echo "AUTH_TYPE:",$_SERVER['AUTH_TYPE'],"<br>";
     echo "PHP_SELF:",$_SERVER['PHP_SELF'],"<br>";
     echo "PATH_INFO:",pathinfo($_SERVER['PHP_SELF']),"<br>";
     echo "Current directory is " . dirname($_SERVER['SCRIPT_FILENAME']),"<br>";
     */

     //$lMenuFileName = dirname($_SERVER['SCRIPT_FILENAME'])."/refdb/menufiledir/sst_ml_menu_list_box.txt";
     //$lMenuFileName = getenv("SST_MLA_DATA_DIR")."SGI/refdb/menufiledir/sst_ml_menu_list_box.txt";
     //$lMenuFileName  = $_SESSION['SST_MLA_DATA_DIR'];
     //$lMenuFileName .= "SGI/refdb/menufiledir/sst_ml_menu_list_box.txt";

    class SSTMLAMenuMethodObj
    {
      public function prepMenu( $lUserType, $lUserMenuFlag, $lSessionId )
      {
        $lMenuFilePath  = $_SESSION['SST_MLA_MENU_DIR'];
        $lMenuFilePath .= "sst_ml_menu_list_box.txt";

        if (file_exists($lMenuFilePath) && is_readable ($lMenuFilePath))
        {
          $lMenuFileHandler = fopen($lMenuFilePath, "r");
          $lMenuFileSize    = filesize($lMenuFilePath);

          while (!feof($lMenuFileHandler))
          {
            $lMenuFieldArr = fgetcsv($lMenuFileHandler,$lMenuFileSize,",");
        
            if( $lUserType !== null && $lUserType == "admin" )
            {
              /*
               When lUserMenuFlag eq to false
               then we have to show only admin
               menu(In Menu File "U" Denotes to User Menu & "A" Denotes to Admin Menu). 
               And when lUserFlag eq to true means we have to display all the menu items
               on the screen when admin login other wise on the basis of user menu will be
               displayed. 
              */


              if( $lUserMenuFlag !== null && $lUserMenuFlag == "false" )
              {
                if( $lMenuFieldArr[1] == 'A' )
                {
                  if( $lMenuFieldArr[2] == 'R' )
                    echo "<b><font color=\"blue\">".$lMenuFieldArr[3]."</font></b><br>";
                  else 
                    if( $lMenuFieldArr[2] == 'C' )
                    {
                      $lMenuUrl  = "<a href = '$lMenuFieldArr[4]";
                      $lMenuUrl .= "&sst_session_id=$lSessionId'>";
                      $lMenuUrl .= "$lMenuFieldArr[3]</a><br>";
 
                      echo $lMenuUrl;
                       

                      //echo "<a href = '$lMenuUrl'>$lMenuFieldArr[3]</a><br>";
                    }
                }
              }
              else
              {
                if( $lMenuFieldArr[2] == 'R' )
                  echo "<b><font color=\"blue\">".$lMenuFieldArr[3]."</font></b><br>";
                else 
                  if( $lMenuFieldArr[2] == 'C' )
                  {
                    $lMenuUrl  = "<a href = '$lMenuFieldArr[4]";
                    $lMenuUrl .= "&sst_session_id=$lSessionId'>";
                    $lMenuUrl .= "$lMenuFieldArr[3]</a><br>";
 
                    echo $lMenuUrl;
                    //echo "<a href = '$lMenuFieldArr[4]'>$lMenuFieldArr[3]</a><br>";
                  }
              }
            }
            else //In the case when admin nt login
            {
              if( $lMenuFieldArr[1] == 'U' )
              {
                if( $lMenuFieldArr[2] == 'R' )
                  echo "<b><font color=\"blue\">".$lMenuFieldArr[3]."</font></b><br>";
                else 
                  if( $lMenuFieldArr[2] == 'C' )
                  {
                    $lMenuUrl  = "<a href = '$lMenuFieldArr[4]";
                    $lMenuUrl .= "&sst_session_id=$lSessionId'>";
                    $lMenuUrl .= "$lMenuFieldArr[3]</a><br>";
 
                    echo $lMenuUrl;
                    //echo "<a href = '$lMenuFieldArr[4]'>$lMenuFieldArr[3]</a><br>";
                  }
              }
              
            }

            //echo $lMenuFieldArr[2];
          }
          fclose($lMenuFileHandler);
        }
        else
        {
          echo "Menu File Not Found!!!";
        }
      }
    }

?>
