<?
  class SSTLogin
  {
    private $lUserFound        = "false";       
    private $lEmployeeExists   = "false";       

    public  $lPath             = ""; 
    public  $lUserFileName     = "";       
    public  $lEmployeeFileName = "";       
    public  $lOrganizationId   = "";       
    public  $lEmployeeId       = "";       
    public  $lCheckUserQty     = "false"; //False Means There is only one record in the file & only admin part will be shown

    public function user_Auth($lUserId, $lUserPass, $lOrgId)
    { 
      $lFileNamePath   = $this->lPath.$this->lUserFileName;

      if(empty($lUserId) || empty($lUserPass)) 
        return -2;
      else
      if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      { 
        try
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lFileNamePath, "r");

          //GETTING THE SIZE OF THE FILE 
          $lFileSize     = filesize($lFileNamePath);

          while (!feof($lFileHandler))
          {
            $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");
            if( $lFieldArr[1] == $lUserId )
              if( $lFieldArr[9] == $lUserPass )
              {
                $this->lOrganizationId = $lOrgId;       
                $this->lEmployeeId     = $lFieldArr[6];       
                $this->lUserFound      = "true";
                break;
              }  
          }
        }
        catch (Exception $Ex )
        {
           echo $Ex->getMessage();
        }
      }
      else
        return -1;

      if( $this->lUserFound == "false" )
        return -1;
      else
      if( $this->lUserFound  == "true" )
      {
        /*
         THIS PART OF CODE IS USE
         TO ONLY CHECK THAT LOGIN USER 
         RECORD EXISTS IN HR EMPLOYEE FILE OR NOT
         IF(Y) Then LOGIN SUCESSFUL.  
        */ 
        $lFileNamePath   = $this->lPath.$this->lEmployeeFileName;
        if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lFileNamePath, "r") or die("Employee File Not Found!!!");

          //GETTING THE SIZE OF THE FILE 
          $lFileSize     = filesize($lFileNamePath);
          while (!feof($lFileHandler))
          {
            $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");
            if( $lFieldArr[0] == $this->lOrganizationId )
              if( $lFieldArr[1] == $this->lEmployeeId )
              {
                $this->lEmployeeExists = "true";
                break;
              }  
          }
        }
        else
         return -1; 
       
        if ( $this->checkUserInFile($this->lUserFileName) < 0 )
          ;
        if ( $this->lEmployeeExists !== null && $this->lEmployeeExists == "false" )
           return -1;
      }

      return 0;
    }



    /*
     This Method is Used to check 
     if there is one record in file
     then it should be admin, and only admin links 
     will be displayed for admin only.
    */
    private function checkUserInFile($inUserFileName)
    {
      $lFileNamePath   = $this->lPath.$inUserFileName;
      $lRecCount       = 0;
      if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      {
        try
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lFileNamePath, "r");

          //GETTING THE SIZE OF THE FILE 
          $lFileSize     = filesize($lFileNamePath);
          $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");

           while (!feof($lFileHandler))
           {
             $lRecCount = $lRecCount + 1;
             $lFieldArr = fgetcsv($lFileHandler,$lFileSize,",");

             if( $lRecCount > 1 )
             {
               /*this means that more than one 
                 user is available & not only admin 
                 link but other user link will 
                 also be display on admin login.
               */ 
               $this->lCheckUserQty = "true";
               break;
             }                  
           }
        }
        catch (Exception $Ex )
        {
           echo $Ex->getMessage();
           return -1; 
        }
      }
      else
       return -1; 

      return 0; 
    }
  }
?>
