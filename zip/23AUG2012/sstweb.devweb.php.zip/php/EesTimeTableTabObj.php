<?


class EesTimetableTabObj
{
  public $tab_rowid;
  public $org_id;
  public $year;
  public $month;
  public $day;
  public $period_num;
  public $class_id;
  public $timetable_id;
  public $timetable_sts;
  public $timetable_sts_date;
  public $subject_code;
  public $class_num;
  public $class_std;
  public $class_section;
  public $course_id;
  public $course_term;
  public $course_stream;
  public $week_num;
  public $period_status;
  public $employee_id;
  public $add_faculty_1;
  public $add_faculty_2;
  public $add_faculty_3;
  public $alternate_faculty;
  public $topic_id;
  public $topic_status;
  public $topic_percent_planned;
  public $building_id;
  public $room_num;
  public $short_subject_code;





  public $org_id_ind;
  public $year_ind;
  public $month_ind;
  public $day_ind;
  public $period_num_ind;
  public $class_id_ind;
  public $timetable_id_ind;
  public $timetable_sts_ind;
  public $timetable_sts_date_ind;
  public $subject_code_ind;
  public $class_num_ind;
  public $class_std_ind;
  public $class_section_ind;
  public $course_id_ind;
  public $course_term_ind;
  public $course_stream_ind;
  public $week_num_ind;
  public $period_status_ind;
  public $employee_id_ind;
  public $add_faculty_1_ind;
  public $add_faculty_2_ind;
  public $add_faculty_3_ind;
  public $alternate_faculty_ind;
  public $topic_id_ind;
  public $topic_status_ind;
  public $topic_percent_planned_ind;
  public $building_id_ind;
  public $room_num_ind;
  public $short_subject_code_ind;


  public function __construct(){}


  public function EesTimetableTabObj
  (
    $org_id,
    $year,
    $month,
    $day,
    $period_num,
    $class_id,
    $timetable_id,
    $timetable_sts,
    $timetable_sts_date,
    $subject_code,
    $class_num,
    $class_std,
    $class_section,
    $course_id,
    $course_term,
    $course_stream,
    $week_num,
    $period_status,
    $employee_id,
    $add_faculty_1,
    $add_faculty_2,
    $add_faculty_3,
    $alternate_faculty,
    $topic_id,
    $topic_status,
    $topic_percent_planned,
    $building_id,
    $room_num,
    $short_subject_code
  )
  {
     $this->org_id = $org_id;
     $this->year = $year;
     $this->month = $month;
     $this->day = $day;
     $this->period_num = $period_num;
     $this->class_id = $class_id;
     $this->timetable_id = $timetable_id;
     $this->timetable_sts = $timetable_sts;
     $this->timetable_sts_date = $timetable_sts_date;
     $this->subject_code = $subject_code;
     $this->class_num = $class_num;
     $this->class_std = $class_std;
     $this->class_section = $class_section;
     $this->course_id = $course_id;
     $this->course_term = $course_term;
     $this->course_stream = $course_stream;
     $this->week_num = $week_num;
     $this->period_status = $period_status;
     $this->employee_id = $employee_id;
     $this->add_faculty_1 = $add_faculty_1;
     $this->add_faculty_2 = $add_faculty_2;
     $this->add_faculty_3 = $add_faculty_3;
     $this->alternate_faculty = $alternate_faculty;
     $this->topic_id = $topic_id;
     $this->topic_status = $topic_status;
     $this->topic_percent_planned = $topic_percent_planned;
     $this->building_id = $building_id;
     $this->room_num = $room_num;
     $this->short_subject_code = $short_subject_code;
  }

  public function getorg_id()                           { return $this->org_id; }
  public function getyear()                             { return $this->year; }
  public function getmonth()                            { return $this->month; }
  public function getday()                              { return $this->day; }
  public function getperiod_num()                       { return $this->period_num; }
  public function getclass_id()                         { return $this->class_id; }
  public function gettimetable_id()                     { return $this->timetable_id; }
  public function gettimetable_sts()                    { return $this->timetable_sts; }
  public function gettimetable_sts_date()               { return $this->timetable_sts_date; }
  public function getsubject_code()                     { return $this->subject_code; }
  public function getclass_num()                        { return $this->class_num; }
  public function getclass_std()                        { return $this->class_std; }
  public function getclass_section()                    { return $this->class_section; }
  public function getcourse_id()                        { return $this->course_id; }
  public function getcourse_term()                      { return $this->course_term; }
  public function getcourse_stream()                    { return $this->course_stream; }
  public function getweek_num()                         { return $this->week_num; }
  public function getperiod_status()                    { return $this->period_status; }
  public function getemployee_id()                      { return $this->employee_id; }
  public function getadd_faculty_1()                    { return $this->add_faculty_1; }
  public function getadd_faculty_2()                    { return $this->add_faculty_2; }
  public function getadd_faculty_3()                    { return $this->add_faculty_3; }
  public function getalternate_faculty()                { return $this->alternate_faculty; }
  public function gettopic_id()                         { return $this->topic_id; }
  public function gettopic_status()                     { return $this->topic_status; }
  public function gettopic_percent_planned()            { return $this->topic_percent_planned; }
  public function getbuilding_id()                      { return $this->building_id; }
  public function getroom_num()                         { return $this->room_num; }
  public function getshort_subject_code()               { return $this->short_subject_code; }



  public function  setorg_id($org_id )                                { $this->org_id                 = $org_id; }
  public function  setyear($year )                                    { $this->year                   = $year; }
  public function  setmonth($month )                                  { $this->month                  = $month; }
  public function  setday($day )                                      { $this->day                    = $day; }
  public function  setperiod_num($period_num )                        { $this->period_num             = $period_num; }
  public function  setclass_id($class_id )                            { $this->class_id               = $class_id; }
  public function  settimetable_id($timetable_id )                    { $this->timetable_id           = $timetable_id; }
  public function  settimetable_sts($timetable_sts )                  { $this->timetable_sts          = $timetable_sts; }
  public function  settimetable_sts_date($timetable_sts_date )        { $this->timetable_sts_date     = $timetable_sts_date; }
  public function  setsubject_code($subject_code )                    { $this->subject_code           = $subject_code; }
  public function  setclass_num($class_num )                          { $this->class_num              = $class_num; }
  public function  setclass_std($class_std )                          { $this->class_std              = $class_std; }
  public function  setclass_section($class_section )                  { $this->class_section          = $class_section; }
  public function  setcourse_id($course_id )                          { $this->course_id              = $course_id; }
  public function  setcourse_term($course_term )                      { $this->course_term            = $course_term; }
  public function  setcourse_stream($course_stream )                  { $this->course_stream          = $course_stream; }
  public function  setweek_num($week_num )                            { $this->week_num               = $week_num; }
  public function  setperiod_status($period_status )                  { $this->period_status          = $period_status; }
  public function  setemployee_id($employee_id )                      { $this->employee_id            = $employee_id; }
  public function  setadd_faculty_1($add_faculty_1 )                  { $this->add_faculty_1          = $add_faculty_1; }
  public function  setadd_faculty_2($add_faculty_2 )                  { $this->add_faculty_2          = $add_faculty_2; }
  public function  setadd_faculty_3($add_faculty_3 )                  { $this->add_faculty_3          = $add_faculty_3; }
  public function  setalternate_faculty($alternate_faculty )          { $this->alternate_faculty      = $alternate_faculty; }
  public function  settopic_id($topic_id )                            { $this->topic_id               = $topic_id; }
  public function  settopic_status($topic_status )                    { $this->topic_status           = $topic_status; }
  public function  settopic_percent_planned($topic_percent_planned )  { $this->topic_percent_planned  = $topic_percent_planned; }
  public function  setbuilding_id($building_id )                      { $this->building_id            = $building_id; }
  public function  setroom_num($room_num )                            { $this->room_num               = $room_num; }
  public function  setshort_subject_code($short_subject_code )        { $this->short_subject_code     = $short_subject_code; }
}
?>
