<?
  require_once("GnUserTabObj.php");
  require_once("sst_ml_filter_record.php");

  class GnUserMethodObj    
  {
    //--------------------------------------------------------------------------------------------------
    public  $lUserFileName         = null;
    public  $lTodayDate            = "";

    //public  $lFilteredFileName     = null; //ASSIGN FILE NAME TO FILTER
    public  $lFilterCriteriaValue1 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition1    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    public  $lFilterCriteriaValue2 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition2    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    //--------------------------------------------------------------------------------------------------


    public function gtGnUserTabObjArr()
    {
      $lGnUserTabObjArr  = array();
      //FILTER OBJECT    
      $lSSTFilter = new SSTFilter();
      //-----------------------------------------------------------------------------
      //READ FILE 
      //-----------------------------------------------------------------------------

      //GETTING FILE SOURCE
      $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      $lFileNamePath .= $this->lUserFileName;
   

      //FILTER PART START
      $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/"; 
      $lSSTFilter->lFilteredFileName     = $this->lUserFileName; //ASSIGN FILE NAME TO FILTER

      if( $this->lFilterCriteriaValue1 !== null && strlen($this->lFilterCriteriaValue1) > 0 ) 
         $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1;//ASSIGN CRITERIA VALUE TO FILTER

      if( $this->lFilteredPosition1 !== null && strlen($this->lFilteredPosition1) > 0 ) 
         $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

      if( $this->lFilterCriteriaValue2 !== null && strlen($this->lFilterCriteriaValue2) > 0 ) 
         $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2;//ASSIGN CRITERIA VALUE TO FILTER

      if( $this->lFilteredPosition2 !== null && strlen($this->lFilteredPosition2) > 0 ) 
         $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

      if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      {
         //GETTING FILTERED RECORD ARR
         $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          
 
         if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
         {
           for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
           {
             //PREP TABOBJ OBJECT
             $lGnUserTabObj     = new HrEmployeeTabObj();
             $lFieldArr         = explode( ",", $lFilteredRecordArr[$lRecNum] );

             //PREP TAB OBJ FOR GnUser  
             $lGnUserTabObj->org_id                      = $lFieldArr[0];
             $lGnUserTabObj->user_id                     = $lFieldArr[1];
             $lGnUserTabObj->user_name                   = $lFieldArr[2];
             $lGnUserTabObj->role_type                   = $lFieldArr[3];
             $lGnUserTabObj->lnf_template_id             = $lFieldArr[4];
             $lGnUserTabObj->remark                      = $lFieldArr[5];
             $lGnUserTabObj->user_emp_id                 = $lFieldArr[6];
             $lGnUserTabObj->parent_user_id              = $lFieldArr[7];
             $lGnUserTabObj->pswd_change_cnt             = $lFieldArr[8];
             $lGnUserTabObj->pswd_0                      = $lFieldArr[9];
             $lGnUserTabObj->pswd_1                      = $lFieldArr[10];
             $lGnUserTabObj->pswd_2                      = $lFieldArr[11];
             $lGnUserTabObj->pswd_3                      = $lFieldArr[12];
             $lGnUserTabObj->pswd_4                      = $lFieldArr[13];
             $lGnUserTabObj->pswd_5                      = $lFieldArr[14];
             $lGnUserTabObj->pswd_6                      = $lFieldArr[15];
             $lGnUserTabObj->pswd_7                      = $lFieldArr[16];
             $lGnUserTabObj->pswd_8                      = $lFieldArr[17];
             $lGnUserTabObj->pswd_9                      = $lFieldArr[18];
             $lGnUserTabObj->pswd_10                     = $lFieldArr[19];
             $lGnUserTabObj->pswd_11                     = $lFieldArr[20];
             $lGnUserTabObj->pswd_12                     = $lFieldArr[21];
             $lGnUserTabObj->pswd_effective_date         = $lFieldArr[22];
             $lGnUserTabObj->expiry_period               = $lFieldArr[23];
             $lGnUserTabObj->hint                        = $lFieldArr[24];
             $lGnUserTabObj->hint_ans                    = $lFieldArr[25];
             $lGnUserTabObj->effective_date              = $lFieldArr[26];
             $lGnUserTabObj->expiration_date             = $lFieldArr[27];
             $lGnUserTabObj->user_status                 = $lFieldArr[28];
             $lGnUserTabObj->user_status_date            = $lFieldArr[29];
  
             $lGnUserTabObjArr[$lRecNum-1] = $lGnUserTabObj;
           }
         }
      }
 
      if( $lGnUserTabObjArr !== null && count($lGnUserTabObjArr) > 0 )
         return $lGnUserTabObjArr;
      else
        return null;
    }


    /*
     This Function is used to create
     User On Admin Login Link Create User.
    */
    public function createGnUser()
    {
      //GETTING FILE SOURCE
      $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      $lFileNamePath .= $this->lUserFileName;
      $lGnUserArr     = array();
 
      if( isset( $_POST['org_id'] ) )
        $lOrgId          = $_POST['org_id']; 
      else
        $lOrgId          = ""; 
       
      if( isset( $_POST['user_id'] ) )
        $lUserId         = $_POST['user_id'];
      else
        $lUserId         = ""; 

      if( isset( $_POST['password'] ) )
        $lPassword       = $_POST['password'];
      else 
        $lPassword       = ""; 

      if( isset( $_POST['re_password'] ) )
        $lRePassword     = $_POST['re_password'];
      else 
        $lRePassword     = ""; 

      if( isset( $_POST['first_name'] ) )
        $lFirstName      = $_POST['first_name'];
      else 
        $lFirstName      = ""; 

      if( isset( $_POST['last_name'] ) )
        $lLastName       = $_POST['last_name'];
      else 
        $lLastName       = ""; 

      if( isset( $_POST['employee_id'] ) )
        $lEmployeeId     = $_POST['employee_id'];
      else 
        $lEmployeeId     = "";

      if( isset( $_POST['user_role'] ) )
        $lUserRole       = $_POST['user_role'];
      else 
        $lUserRole       = "";

      if( isset( $_POST['parent_id'] ) )
        $lParentId       = $_POST['parent_id'];
      else
        $lParentId = "";
       
      $lFirstName = $lFirstName." ".$lLastName;

      if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      {
         $lGnUserArr     = $this->readGnUserData();
         try
         {
           //OPEN A FILE FROM THE GIVEN PATH
           $lFileHandler  = fopen($lFileNamePath, "w") or die("FILE CAN NOT BE OPEN !!");
         
            if( $lGnUserArr !== null && count($lGnUserArr) > 0 )
            {
              for( $lRecNum = 1; $lRecNum <= count ($lGnUserArr); $lRecNum++ )
              {
                $lWriteLineData = $lGnUserArr[$lRecNum-1];
                fwrite( $lFileHandler, $lWriteLineData );
              }
            }

           //PREPARE DATA FOR WRITE
           $lCSVFileData = "$lOrgId".","."$lUserId".","."$lFirstName".","."$lUserRole".",,,"."$lEmployeeId".","."$lParentId".",,"."$lPassword".",,,,,,,,,,,,,,,,,,,,\n";
           fwrite($lFileHandler, $lCSVFileData);
         }
         catch (Exception $Ex )
         {
           echo $Ex->getMessage();
           return -1;
         }
         // Close the file
         fclose($lFileHandler);
      }
      else
       return -1;  //FILE DOES NOT EXISTS

      return 0;
    }


    private function readGnUserData()
    {
       $lRecNum         = 0;
       $lGnUserArr      = array();

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lUserFileName;

         //OPEN A FILE FROM THE GIVEN PATH
         if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         if ( filesize ($lFileNamePath) > 0 )
         {
           $lFileHandler  = fopen($lFileNamePath, "r") or die("FILE CAN NOT BE OPEN !!");
           //GETTING THE SIZE OF THE FILE 
           $lFileSize     = filesize($lFileNamePath);

            while (!feof($lFileHandler))
            {
               if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )
               {
                 $lGnUserArr[$lRecNum] = $lRecordLine;
                 $lRecNum = $lRecNum + 1;
               }
            }
         }
         else
          return null;
       }
       catch (Exception $Ex )
       {
           echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);

       if( $lGnUserArr !== null && count( $lGnUserArr ) > 0 )
          return $lGnUserArr;
       else
         null;
    }



    public function deleteGnUser($lOrgId, $lUserId)
    {
       $lDELETED_SUUCESSFUL = "false";

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lUserFileName;
         /*
          This Array Will Contain All the Employee Data
         */

         $lGnUserArr = $this->readGnUserData();

         if( $lGnUserArr !== null && count( $lGnUserArr ) > 0 )
         {
           for( $lRecNum = 0; $lRecNum < count( $lGnUserArr ); $lRecNum++ )
           {
             $lRecordLine    = $lGnUserArr[$lRecNum];
             $lFieldValueArr = explode( ",", $lRecordLine );

             if( $lOrgId == $lFieldValueArr[0] )
               if( $lUserId == $lFieldValueArr[1] )
               {
                 unset( $lGnUserArr[$lRecNum] );//THIS WILL REMOVE THE INDEX POS VALUE
                 $lGnUserArr = array_values($lGnUserArr);//THIS WILL TRANSFER THE VALUE WITH NEW INDEXS\
                 $lDELETED_SUUCESSFUL = "true";
                 break;
               }
           }
         }

         if( $lDELETED_SUUCESSFUL == "true" )
         {
           // Open the file and erase the contents if any
           $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

           if( $lGnUserArr !== null && count($lGnUserArr) > 0 )
           {
             for( $lRecNum = 1; $lRecNum <= count ($lGnUserArr); $lRecNum++ )
             {
               $lWriteLineData = $lGnUserArr[$lRecNum-1];
               fwrite( $lFileHandler, $lWriteLineData );
             }
           }
         }
         else
          return -1;
       }
       catch (Exception $Ex )
       {
         echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);
       return 0;
    }

  }

?>
