<?
{
  echo "<html>";

  echo "<head>";
  //---------------------------------------------------------------------------
  // COMMON HEAD PART - STARTS
  //---------------------------------------------------------------------------
  require_once("sst_ml_common_head_include.php");
  //---------------------------------------------------------------------------
  // COMMON HEAD PART - ENDS
  //---------------------------------------------------------------------------
  echo "</head>";

  //------------------------------------------------
  require_once("SSTMlaUserLogin.php");
  require_once("SSTMlaAppParameterInit.php");
  require_once("sst_ml_filter_record.php");
  //------------------------------------------------

  require_once("SSTMlaSession.php");
  require_once("sst_ml_menu_list_box.php");
  //require_once("sst_ml_get_browser_info.php");
  require_once("sst_ml_env_var.php");

  require_once("HrEmployeeTabObj.php");
  require_once("GnUserTabObj.php");
  require_once("GnApplnSessionTabObj.php");

  require_once("GnUserMethodObj.php");
  require_once("GnApplnSessionMethodObj.php");
  require_once("HrEmployeeMethodObj.php");
  //---------------------------------------------------------------------------


  ///////////////////////////////////////////////////////////////////////////// 
  ////////////////////APP PARAMETER DECLARATION /////////////////////////////// 
  ///////////////////////////////////////////////////////////////////////////// 
  
  $SST_MLA_HOME_PREFIX          = "";
  $SST_MLA_HOME                 = "";
  $SST_MLA_HOME_CUST_DC         = "";
  $SST_MLA_HOME_SST_DC          = "";
  $SST_MLA_INSTALL              = "";
  $SST_MLA_DATA_INSTALL         = "";
  $SST_MLA_DATA_DIR             = "";
  $SST_MLA_MENU_DIR             = "";
  $SST_MLA_INBOX_DIR            = "";
  $SST_MLA_OUTBOX_DIR           = "";
  $SST_DC_DATA_DIR              = "";
  $SST_DC_INBOX_DIR             = "";
  $SST_DC_OUTBOX_DIR            = "";
  $SST_MLA_FILTER_PATH          = "";
  $SST_MLA_UPLOAD_DATA_TRG_PATH = "";

  ///////////////////////////////////////////////////////////////////////////// 

  ///////////////////////////////////////////////////////////////////////////// 
  ////////////////////GLOBAL VARIABLE DECLARATION ///////////////////////////// 
  ///////////////////////////////////////////////////////////////////////////// 
  
  $lSessionId    = null; 
  $lReturnValue  = 0;
  $lUserPass     = "";
  $lOrgId        = "";
  $lSubmitAction = "";

  $lOrgId        = ""; 
  $lCheckUserQty = "";
  $lCurrentYear  = ""; 
  $lCurrentDate  = ""; 
  $lCurrentMonth = ""; 

  $lTodayDBDate  = ""; 
  $lTodayGUIDate = ""; 
  ///////////////////////////////////////////////////////////////////////////// 


  //------------------------------------------------------------------------------------------------------
  // REQUIRED TABOBJ
  //------------------------------------------------------------------------------------------------------
  $lSSTLogin                = new SSTLogin();
  $lSSTMlaAppParameterInit  = new SSTMlaAppParameterInit();
  $lHrEmployeeMethodObj     = new HrEmployeeMethodObj();
  $lGnApplnSessionMethodObj = new GnApplnSessionMethodObj();
  $lGnUserMethodObj         = new GnUserMethodObj();
  $lSSTMLAMenuMethodObj     = new SSTMLAMenuMethodObj();  

  $lGnApplnSessionTabObj    = new GnApplnSessionTabObj();
  $lHrEmployeeTabObjGlobal  = new HrEmployeeTabObj();
  $lGnUserTabObj            = new GnUserTabObj();

  //------------------------------------------------------------------------------------------------------


  

  ///////////////////////////////////////////////////////////////////////////// 
  /////////////////////APP PARAMETER INITILIZATION PROCESS///////////////////// 
  ///////////////////////////////////////////////////////////////////////////// 

  if ( $lSSTMlaAppParameterInit->MlaAppParametrInit() < 0 )
      echo "ERROR IN APPLICATION PARAMETER !!!";
  else
  {
    $SST_MLA_HOME_PREFIX           = trim($lSSTMlaAppParameterInit->SST_MLA_HOME_PREFIX);
    $SST_MLA_HOME                  = trim($lSSTMlaAppParameterInit->SST_MLA_HOME);
    $SST_MLA_HOME_CUST_DC          = trim($lSSTMlaAppParameterInit->SST_MLA_HOME_CUST_DC);
    $SST_MLA_HOME_SST_DC           = trim($lSSTMlaAppParameterInit->SST_MLA_HOME_SST_DC);
    $SST_MLA_INSTALL               = trim($lSSTMlaAppParameterInit->SST_MLA_INSTALL);
    $SST_MLA_DATA_INSTALL          = trim($lSSTMlaAppParameterInit->SST_MLA_DATA_INSTALL);
    $SST_MLA_DATA_DIR              = trim($lSSTMlaAppParameterInit->SST_MLA_DATA_DIR);
    $SST_MLA_MENU_DIR              = trim($lSSTMlaAppParameterInit->SST_MLA_MENU_DIR);
    $SST_MLA_INBOX_DIR             = trim($lSSTMlaAppParameterInit->SST_MLA_INBOX_DIR);
    $SST_MLA_OUTBOX_DIR            = trim($lSSTMlaAppParameterInit->SST_MLA_OUTBOX_DIR);
    $SST_DC_DATA_DIR               = trim($lSSTMlaAppParameterInit->SST_DC_DATA_DIR);
    $SST_DC_INBOX_DIR              = trim($lSSTMlaAppParameterInit->SST_DC_INBOX_DIR);
    $SST_DC_OUTBOX_DIR             = trim($lSSTMlaAppParameterInit->SST_DC_OUTBOX_DIR);
    $SST_MLA_FILTER_PATH           = trim($lSSTMlaAppParameterInit->SST_MLA_FILTER_PATH);
    $SST_MLA_UPLOAD_DATA_TRG_PATH  = trim($lSSTMlaAppParameterInit->SST_MLA_UPLOAD_DATA_TRG_PATH);
  }  
  ///////////////////////////////////////////////////////////////////////////// 



  //------------------------------------------------------------------------------------------------------
  require_once("sst_ml_login_envelop_process.php");
  //------------------------------------------------------------------------------------------------------



  //------------------------------------------------------------------------------------------------------
  if( !isset($_SESSION['lSessionId']) )
    ;
  else
  {
    $lSessionId = $_SESSION['lSessionId'];
    $lOrgId     = $_SESSION['lOrgId'];
  } 
  //------------------------------------------------------------------------------------------------------


  //------------------------------------------------------------------------------------------------------
  // CHECK ALL ABOVE SESSION ATTRIBUTES, IF SET IN SESSION THEN REINIT ABOVE INSTANCE FROM SESSION
  // DON"T REINIT ONLY IN CASE OF LOGOUT
  //------------------------------------------------------------------------------------------------------
  if(!isset($_SESSION['lGnApplnSessionTabObj']))
    ;  
  else
  {
    $lGnApplnSessionTabObj = unserialize($_SESSION['lGnApplnSessionTabObj']);
  }
  //------------------------------------------------------------------------------------------------------


  echo "<body style=\"{ margin: 0px 0px 0px 0px; }\" name=\"ml_product_body\" id=\"ml_product_body\" width=\"100%\">";
  echo "<form method = \"post\" name = 'form' id = 'form'>";
  echo "<table name=\"ml_product_table\" id=\"ml_product_table\" width=\"100%\" border=\"0\">";


  //--------------------------------------------------------------------------
  // INCLUDE FOR UPPER  - STARTS
  //--------------------------------------------------------------------------
  include("sst_ml_upper.php");
  //--------------------------------------------------------------------------
  // INCLUDE FOR UPPER  - ENDS
  //--------------------------------------------------------------------------


  //------------------------------------------------------------------------------------------------------
  if( !isset($_SESSION['lSessionId']) )
    ;  
  else
  {
    $lHrEmployeeTabObjGlobal = unserialize($_SESSION['lHrEmployeeTabObjGlobal']);
    $lGnUserTabObj           = unserialize($_SESSION['lGnUserTabObj']);
    $lCheckUserQty           = $_SESSION['lCheckUserQty'];

    $lUpTargetPath = $SST_MLA_HOME_PREFIX.$SST_MLA_HOME_CUST_DC.$lOrgId."/".$SST_MLA_UPLOAD_DATA_TRG_PATH; 
    $_SESSION['SST_MLA_UPLOAD_DATA_TRG_PATH'] = $lUpTargetPath; 
  }
  //------------------------------------------------------------------------------------------------------



  //------------------------------------------------------------------------------------------------------
  if( !isset($_POST['action_logout']) )
    ;
  else
  {
    $lAction = $_GET['action_logout'];
    if( !isset($_SESSION['lSessionId']) )
       ;
    else 
      if( $lAction !== null && $lAction == 'logout' )
      {
        // Unset all of the session variables.
        $_SESSION = array();

        if (isset($_COOKIE[session_id()])) 
        {
          setcookie(session_name(), '', time()-42000, '/');
        } 

        session_destroy();
      }
  }

  //--------------------------------------------------------------------------
  // INCLUDE FOR DATA - STARTS
  // - TWO TDs
  // - First TD for MENU
  // - Second TD for envelop_process
  //--------------------------------------------------------------------------

  echo "<tr>";

  echo "<td name=\"prod_data_td\" id=\"prod_data_td\" align=\"center\" colspan=\"3\" width=\"100%\">";
  echo "<table name=\"prod_data_tab\" id=\"prod_data_tab\" align=\"center\" width=\"100%\" border = \"0\" cellspacing=\"1\">";
  echo "<tr>";


  //-------------------------------------------------------------------------
  // MENU FILE - STARTS
  //-------------------------------------------------------------------------
  echo "<td name=\"menu_list_td\" id=\"menu_list_td\" align=\"right\" width=\"20%\" valign=\"top\">";
  if(!isset($_SESSION['lSessionId']))
    ;
  else
  {
    $lSSTMLAMenuMethodObj->prepMenu($lGnUserTabObj->role_type, $lCheckUserQty, $lSessionId);
  }
  echo "</td>";
  //-------------------------------------------------------------------------
  // MENU FILE - ENDS
  //-------------------------------------------------------------------------


  //-------------------------------------------------------------------------
  //Draw a Vertical Line B/W Menu & Envelop Process
  echo "<td width = \"1%\">"; 
  echo "</td>";
  //-------------------------------------------------------------------------


  //-------------------------------------------------------------------------
  // ENVELOP PROCESS - STARTS
  //-------------------------------------------------------------------------
  echo "<td name=\"envelop_pro_td\" id=\"envelop_pro_td\" align=\"right\" width=\"70%\">"; 
  include ("sst_ml_home_product_envelop_process.php");
  echo "</td>";
  //-------------------------------------------------------------------------
  // ENVELOP PROCESS - ENDS
  //-------------------------------------------------------------------------

 


  //-------------------------------------------------------------------------
  // LOGIN BOX     - STARTS
  //-------------------------------------------------------------------------
  if(!isset($_SESSION['lSessionId']))
  {
    echo "<td name=\"login_td\" id=\"login_td\" align=\"right\" width=\"5%\">"; 
    include ("sst_ml_login_box_include.php");
    echo "</td>";
  }
  //-------------------------------------------------------------------------
  // LOGIN BOX     - ENDS
  //-------------------------------------------------------------------------




  echo "</tr>";

  echo "</table>";
  echo "</td>";
  echo "</tr>";

  //--------------------------------------------------------------------------
  // INCLUDE FOR DATA - ENDS 
  //--------------------------------------------------------------------------





  //--------------------------------------------------------------------------
  // INCLUDE FOR LOWER  - STARTS
  //--------------------------------------------------------------------------
  echo "<tr>";
  include ("sst_ml_lower.php");
  echo "</tr>";
  //--------------------------------------------------------------------------
  // INCLUDE FOR LOWER  - ENDS
  //--------------------------------------------------------------------------

  echo " </table>";
  echo "</form>";

  echo "</body>";
  echo "</html>";
}
?>
