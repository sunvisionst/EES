<?

  echo "<input type = \"hidden\" id = \"course_id\" name = \"course_id\" value = \"$lCourseId\"/>";
  echo "<input type = \"hidden\" id = \"subject_code\" name = \"subject_code\" value = \"$lSubjectCode\"/>";
  echo "<input type = \"hidden\" id = \"course_stream\" name = \"course_stream\" value = \"$lCourseStream\"/>";
  echo "<input type = \"hidden\" id = \"class_num\" name = \"class_num\" value = \"$lClassNum\"/>";
  echo "<input type = \"hidden\" id = \"course_term\" name = \"course_term\" value = \"$lCourseTerm\"/>";
  echo "<input type = \"hidden\" id = \"class_section\" name = \"class_section\" value = \"$lClassSection\"/>";

?>
