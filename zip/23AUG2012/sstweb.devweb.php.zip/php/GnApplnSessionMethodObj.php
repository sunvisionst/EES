<?
  require_once("GnApplnSessionTabObj.php");

  class GnApplnSessionMethodObj
  {
     public $org_id           = ""; 
     public $session_id       = ""; 
     public $appln_short_name = ""; 
     public $user_name        = ""; 
     public $user_id          = ""; 
     public $user_emp_id      = ""; 
     public $pswd             = ""; 
     public $session_status   = ""; 
     public $role_type        = ""; 
 
     public $lSessionFileName = ""; 
 

     public function checkSessionId()
     {
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
       $lFileNamePath  .= $this->lSessionFileName;
      
       $lGnApplnSessionTabObjArr = array();
       //FILTER OBJECT    
       $lSSTFilter = new SSTFilter();

       //FILTER PART START
       $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/"; 
       $lSSTFilter->lFilteredFileName     = $this->lSessionFileName; 
       $lSSTFilter->lFilterCriteriaValue1 = $this->org_id; 
       $lSSTFilter->lFilteredPosition1    = 0; 
       $lSSTFilter->lFilterCriteriaValue2 = $this->session_id;
       $lSSTFilter->lFilteredPosition2    = 1; 

       if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
       {
         //GETTING FILTERED RECORD ARR
         $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          
           
         if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
         { 
           for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
           {
             //PREP TABOBJ OBJECT
             $lGnApplnSessionTabObj = new GnApplnSessionTabObj();
             $lFieldArr  = explode( ",", $lFilteredRecordArr[$lRecNum] );

             $lGnApplnSessionTabObj->org_id                       = $lFieldArr[0];
             $lGnApplnSessionTabObj->session_id                   = $lFieldArr[1];
             $lGnApplnSessionTabObj->seq_num                      = $lFieldArr[2];
             $lGnApplnSessionTabObj->appln_short_name             = $lFieldArr[3];
             $lGnApplnSessionTabObj->user_name                    = $lFieldArr[4];
             $lGnApplnSessionTabObj->user_id                      = $lFieldArr[5];
             $lGnApplnSessionTabObj->user_emp_id                  = $lFieldArr[6];
             $lGnApplnSessionTabObj->pswd                         = $lFieldArr[7];
             $lGnApplnSessionTabObj->login_time                   = $lFieldArr[8];
             $lGnApplnSessionTabObj->login_date                   = $lFieldArr[9];
             $lGnApplnSessionTabObj->logout_time                  = $lFieldArr[10];
             $lGnApplnSessionTabObj->logout_date                  = $lFieldArr[11];
             $lGnApplnSessionTabObj->session_status               = $lFieldArr[12];
             $lGnApplnSessionTabObj->role_type                    = $lFieldArr[13];
             $lGnApplnSessionTabObj->role_weight                  = $lFieldArr[14];
             $lGnApplnSessionTabObj->schema_name                  = $lFieldArr[15];
             $lGnApplnSessionTabObj->server_ip_v4                 = $lFieldArr[16];
             $lGnApplnSessionTabObj->server_ip_v6                 = $lFieldArr[17];
             $lGnApplnSessionTabObj->server_country               = $lFieldArr[18];
             $lGnApplnSessionTabObj->server_city                  = $lFieldArr[19];
             $lGnApplnSessionTabObj->server_name                  = $lFieldArr[20];
             $lGnApplnSessionTabObj->server_port                  = $lFieldArr[21];
             $lGnApplnSessionTabObj->server_scheme                = $lFieldArr[22];
             $lGnApplnSessionTabObj->server_char_encoding         = $lFieldArr[23];
             $lGnApplnSessionTabObj->server_os_name               = $lFieldArr[24];
             $lGnApplnSessionTabObj->server_os_user_name          = $lFieldArr[25];
             $lGnApplnSessionTabObj->process_id                   = $lFieldArr[26];
             $lGnApplnSessionTabObj->remote_ip_v4                 = $lFieldArr[27];
             $lGnApplnSessionTabObj->remote_ip_v6                 = $lFieldArr[28];
             $lGnApplnSessionTabObj->remote_country               = $lFieldArr[29];
             $lGnApplnSessionTabObj->remote_city                  = $lFieldArr[30];
             $lGnApplnSessionTabObj->remote_name                  = $lFieldArr[31];
             $lGnApplnSessionTabObj->remote_os_name               = $lFieldArr[32];
             $lGnApplnSessionTabObj->remote_os_user_name          = $lFieldArr[33];
             $lGnApplnSessionTabObj->remote_browser               = $lFieldArr[34];
             $lGnApplnSessionTabObj->req_session_id               = $lFieldArr[35];
             $lGnApplnSessionTabObj->default_lab                  = $lFieldArr[36];
             $lGnApplnSessionTabObj->login_lab                    = $lFieldArr[37];
             $lGnApplnSessionTabObj->lnf_template_id              = $lFieldArr[38];

             //PUT VALUE IN ARRAY
             $lGnApplnSessionTabObjArr[$lRecNum-1] = $lGnApplnSessionTabObj;
           }
         }
       }
     
       if( $lGnApplnSessionTabObjArr !== null && count($lGnApplnSessionTabObjArr) > 0 )
          return $lGnApplnSessionTabObjArr;
       else
          return null;
     }



     public function insSessionRec()
     {
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
       $lFileNamePath  .= $this->lSessionFileName;
       $lSeqNum         = 0;
 
       $lGnApplnSessionArr = array();

       try
       {
         /*
          This Array Will Contain All the Session Data
          if It has any using method readSessionData.
         */

         $lGnApplnSessionArr = $this->readSessionData(); 

         // Open the file and erase the contents if any
         $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

         if( $lGnApplnSessionArr !== null && count($lGnApplnSessionArr) > 0 )
         {
           $lSeqNum = count($lGnApplnSessionArr); 
           for( $lRecNum = 1; $lRecNum <= count ($lGnApplnSessionArr); $lRecNum++ )
           {
             $lWriteLineData = $lGnApplnSessionArr[$lRecNum-1];
             fwrite( $lFileHandler, $lWriteLineData ); 
           } 
         }
         $lSeqNum = $lSeqNum + 1;
         //PREPARE DATA FOR WRITE
         $lCSVFileData = $this->org_id.",".$this->session_id.",$lSeqNum,$this->appln_short_name,$this->user_name,$this->user_id,$this->user_emp_id,$this->pswd,,,,,$this->session_status,,,,,,,,,,,,,,,,,,,,,,,,,,,\n";

         fwrite($lFileHandler, $lCSVFileData); 
       }  
       catch (Exception $Ex )
       {
           echo $Ex->getMessage();
       }
       // Close the file
       fclose($lFileHandler);
     }


    private function readSessionData()
    {
       $lRecNum         = 0;
       $lGnApplnSessionArr = array();

       try
       { 
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lSessionFileName;

         //OPEN A FILE FROM THE GIVEN PATH
         if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         if ( filesize ($lFileNamePath) > 0 )
         {
           $lFileHandler  = fopen($lFileNamePath, "r") or die("FILE CAN NOT BE OPEN !!");
           //GETTING THE SIZE OF THE FILE 
           $lFileSize     = filesize($lFileNamePath); 

            while (!feof($lFileHandler))
            {
               if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )
               {
                 $lGnApplnSessionArr[$lRecNum] = $lRecordLine; 
                 $lRecNum = $lRecNum + 1;  
               }
            }  
         }
         else
          return null;  
       }
       catch (Exception $Ex )
       {
           echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);
       
       if( $lGnApplnSessionArr !== null && count( $lGnApplnSessionArr ) > 0 )
          return $lGnApplnSessionArr;
       else
         null; 
    }


    public function deleteSession($lSessionId, $lOrgId)
    {
       $lDELETED_SUUCESSFUL = "false";

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lSessionFileName;
         /*
          This Array Will Contain All the Session Data
          if It has any using method readSessionRec.
         */

         $lGnApplnSessionArr = $this->readData();
      
 
         if( $lGnApplnSessionArr !== null && count( $lGnApplnSessionArr ) > 0 )
         {
           for( $lRecNum = 0; $lRecNum < count( $lGnApplnSessionArr ); $lRecNum++ )
           {
             $lRecordLine    = $lGnApplnSessionArr[$lRecNum]; 
             $lFieldValueArr = explode( ",", $lRecordLine ); 

             if( $lOrgId == $lFieldValueArr[0] )
               if( $lSessionId == $lFieldValueArr[1] ) 
               {
                 unset( $lGnApplnSessionArr[$lRecNum] );//THIS WILL REMOVE THE INDEX POS VALUE
                 $lGnApplnSessionArr = array_values($lGnApplnSessionArr);//THIS WILL TRANSFER THE VALUE WITH NEW INDEXS\
                 $lDELETED_SUUCESSFUL = "true";
                 break;
               }
           }
         }

         if( $lDELETED_SUUCESSFUL == "true" )
         {
           // Open the file and erase the contents if any
           $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

           if( $lGnApplnSessionArr !== null && count($lGnApplnSessionArr) > 0 )
           {
             for( $lRecNum = 1; $lRecNum <= count ($lGnApplnSessionArr); $lRecNum++ )
             {
               $lWriteLineData = $lGnApplnSessionArr[$lRecNum-1];
               fwrite( $lFileHandler, $lWriteLineData ); 
             } 
           }
         }
       }
       catch (Exception $Ex )
       {
           echo $Ex->getMessage();
       }
 
       // Close the file
       fclose($lFileHandler);
    }




  }
?>
