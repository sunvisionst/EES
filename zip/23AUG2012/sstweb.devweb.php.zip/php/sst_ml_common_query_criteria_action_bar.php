<? 
    $lActionValue;
    $lRedirectPage;
 
    echo "<table border = '0' width = 'center'>";
    echo "<tr>";
    echo "<td>";

    if( $lRequestType == 'facAttnEntry' )
    {
      $lActionValue   = 'Submit';
      $lRedirectPage  = 'sst_ml_ees_lecture_attendance_envelop.php?menu_option=eesFaculty&req_type=facAttnEntry&action=null';    
    } 
    else
    if( $lRequestType == 'facMarkEntry' )
    {
      $lActionValue   = 'Submit';
      $lRedirectPage  = 'sst_ml_ees_subject_mark_entry_envelop.php?menu_option=eesFaculty&req_type=facMarkEntry&submit_action=querySubmit';    
    } 
    else
    if( $lRequestType == 'facSubProgEntry' )
    {
      $lActionValue   = 'Submit';
      $lRedirectPage  = 'sst_ml_ees_subject_progress_entry_envelop.php?menu_option=eesFaculty&req_type=facSubProgEntry&action=querySubmit';    
    } 
    else
    { 
      $lActionValue  = 'View Report';
      $lRedirectPage  = 'sst_ml_common_view_report_envelop.php';    
    }

    echo "<input type=\"hidden\" 
                id=\"submit_action\" 
                name=\"submit_action\" value=\"\"/>";

     echo "<input type=\"submit\" 
                  id=\"submit\" 
                  name=\"submit\" 
                  value=\"$lActionValue\"
                  onClick=\" { 
                               document.getElementById('submit_action').value = 'querySubmit';
                               javascript:form.action='$lRedirectPage'; 
                             }
                          \"
           >"; 

     echo "</td>";
     echo "</tr>";
     echo "</table>";
?>
