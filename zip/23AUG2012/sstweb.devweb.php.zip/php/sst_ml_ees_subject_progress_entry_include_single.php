<?
   echo "<table border=\"0\" width=\"100%\">"; 

   $lFieldValue = "";

   //----------------------------------------------------------------- 
   echo "<tr>";
   echo "<td>";
   echo"<fieldset>";
   echo"<legend><font color = \"white\" >Topic Planned</font></legend>";
   echo"<table border = \"0\" width = \"100%\"> ";
   echo"<tr>";

   echo"<td>";
   echo" Topic Id";
   echo"</td>";
   echo"<td>";
   echo" <font size=\"2\" color=\"blue\">  $lTopicId</font>";
   echo"</td>";

   echo"<td align=\"right\">";
   echo" Planned (%) On Date </td><td> <font size=\"2\" color=\"blue\">$lTodayGUIDate</font>";
   echo"</td>";
   echo"<td>";
   if ( $lEesTimeTableTabObj->topic_percent_planned !== null )
     echo" <font size=\"2\" color=\"blue\">$lEesTimeTableTabObj->topic_percent_planned</font>";
   echo"</td>";

   echo"</tr>";
   echo"</table> ";
   echo"</fieldset>";
   echo "</td>";
   echo "</tr>";
   //----------------------------------------------------------------- 
   

   //----------------------------------------------------------------- 
   echo "<tr>";
   echo "<td>";
   echo"<fieldset>";
   echo"<legend><font color = \"white\" >Topic Covered</font></legend>";
   echo"<table border = \"0\" width = \"100%\"> ";

   echo"<tr>";
   echo"<td>";
   echo" Covered (%)";
   echo"</td>";
   echo"<td>";
   
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->topic_percent_covered;
   else
     $lFieldValue = "";  
   echo" <input type=\"textbox\" 
                id=\"topic_percent_covered\" 
                name=\"topic_percent_covered\"";
   echo"        value=\"$lFieldValue\" ";
   echo" />";
   echo"</td>";


   echo"<td>";
   echo" Period Num";
   echo"</td>";
   echo"<td>";
   if ( $lEesTimeTableModelTabObj !== null )
     echo"<font size=\"2\" color=\"blue\">".$lEesTimeTableModelTabObj->period_num."</font>";
   echo"</td>";
   echo"</tr>";

   echo"<tr>";

   echo"<td>";
   echo" Start Time";
   echo"</td>";
   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->adr_start_time;
   else
     $lFieldValue = ""; 
   echo" <input type=\"textbox\" 
                id=\"adr_start_time\" 
                name=\"adr_start_time\" 
                value=\"$lFieldValue\" READONLY/>";
   echo"</td>";

   echo"<td>";
   echo" End Time";
   echo"</td>";
   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->adr_end_time;
   else
     $lFieldValue = ""; 
   echo" <input type=\"textbox\" 
                id=\"adr_end_time\" 
                name=\"adr_end_time\" 
                value=\"$lFieldValue\" READONLY/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->org_id;
   else
    $lFieldValue   = "SGI";//GLOBAL ATTRIBUTE WILL BE REPLACED

   echo" <input type=\"hidden\" 
                id=\"org_id\" 
                name=\"org_id\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";


   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->employee_id;
   else
    $lFieldValue   = $lHrEmployeeTabObj->employee_id;//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"employee_id\" 
                name=\"employee_id\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";


   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->period_num;
   else
   if( $lEesTimeTableModelTabObj !== null )
    $lFieldValue   = $lEesTimeTableModelTabObj->period_num;//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"period_num\" 
                name=\"period_num\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   $lFieldValue   = $lTodayGUIDate;                                 
   echo" <input type=\"hidden\" 
                id=\"adr_date\" 
                name=\"adr_date\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->topic_id;
   else
    $lFieldValue   = $lTopicId;//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"topic_id\" 
                name=\"topic_id\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->lecture_num;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"lecture_num\" 
                name=\"lecture_num\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->subject_code;
   else
    $lFieldValue   = $lSubjectCode;//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"subject_code\" 
                name=\"subject_code\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->class_id;
   else
    $lFieldValue   = $lClassId;//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"class_id\" 
                name=\"class_id\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->class_num;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"class_num\" 
                name=\"class_num\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->class_std;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"class_std\" 
                name=\"class_std\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->class_section;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"class_section\" 
                name=\"class_section\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->course_id;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"course_id\" 
                name=\"course_id\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->course_term;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"course_term\" 
                name=\"course_term\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"<td>";
   if( $lEesAdrTabObj !== null )
     $lFieldValue = $lEesAdrTabObj->course_stream;
   else
    $lFieldValue   = "";//GLOBAL ATTRIBUTE WILL BE REPLACED 
   echo" <input type=\"hidden\" 
                id=\"course_stream\" 
                name=\"course_stream\" 
                value=\"$lFieldValue\"/>";
   echo"</td>";

   echo"</tr>";

   echo"</table> ";
   echo"</fieldset>";
   echo "</td>";
   echo "</tr>";
   //----------------------------------------------------------------- 



   echo "</table>";
?>
