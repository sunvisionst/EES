<?
  require_once("HrEmployeeTabObj.php");

  class HrEmployeeMethodObj
  {
    //--------------------------------------------------------------------------------------------------
    public  $lEmployeeFileName     = null;
    public  $lTodayDate            = "";
    //public  $lFilteredFileName     = null; //ASSIGN FILE NAME TO FILTER
    public  $lFilterCriteriaValue1 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition1    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    public  $lFilterCriteriaValue2 = null; //ASSIGN CRITERIA VALUE TO FILTER
    public  $lFilteredPosition2    = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
    //--------------------------------------------------------------------------------------------------




   /*
   FUNCTION TO GET EMPLOYEE
   TAB OBJ ARR.
   */
    public function gtHrEmployeeTabObjArr()
    {
      $lHrEmployeeTabObjArr  = array();
      //FILTER OBJECT    
      $lSSTFilter = new SSTFilter();
      //-----------------------------------------------------------------------------
      //READ FILE 
      //-----------------------------------------------------------------------------

      //GETTING FILE SOURCE
      $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
      $lFileNamePath .= $this->lEmployeeFileName;
   

      //FILTER PART START
      $lSSTFilter->lFilteredFileRelPath  = "refdb/datafiledir/"; 
      $lSSTFilter->lFilteredFileName     = $this->lEmployeeFileName; //ASSIGN FILE NAME TO FILTER
      $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1;//ASSIGN CRITERIA VALUE TO FILTER
      $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
      $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2;//ASSIGN CRITERIA VALUE TO FILTER
      $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED


      if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
      {
        //GETTING FILTERED RECORD ARR
        $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          

        if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
        {
          for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
          {
            //PREP TABOBJ OBJECT
            $lHrEmployeeTabObj     = new HrEmployeeTabObj();
            $lFieldArr             = explode( ",", $lFilteredRecordArr[$lRecNum] );

            //PREP TAB OBJ FOR EMPLOYEE
             
            $lHrEmployeeTabObj->org_id                 = $lFieldArr[0];
            $lHrEmployeeTabObj->employee_id            = $lFieldArr[1];
            $lHrEmployeeTabObj->name_initials          = $lFieldArr[2];
            $lHrEmployeeTabObj->employee_f_name        = $lFieldArr[3];
            $lHrEmployeeTabObj->employee_m_name        = $lFieldArr[4];
            $lHrEmployeeTabObj->employee_l_name        = $lFieldArr[5];
            $lHrEmployeeTabObj->employee_short_name    = $lFieldArr[6];
            $lHrEmployeeTabObj->emp_type               = $lFieldArr[7];
            $lHrEmployeeTabObj->emp_ctg                = $lFieldArr[8];
            $lHrEmployeeTabObj->reporting_head_id      = $lFieldArr[9];
            $lHrEmployeeTabObj->dept_id                = $lFieldArr[10];
            $lHrEmployeeTabObj->logical_group_id       = $lFieldArr[11];
            $lHrEmployeeTabObj->position_id            = $lFieldArr[12];
            $lHrEmployeeTabObj->level_id               = $lFieldArr[13];
            $lHrEmployeeTabObj->designation            = $lFieldArr[14];
            $lHrEmployeeTabObj->doj                    = $lFieldArr[15];
            $lHrEmployeeTabObj->dot                    = $lFieldArr[16];
            $lHrEmployeeTabObj->project_id             = $lFieldArr[17];
            $lHrEmployeeTabObj->shift_code             = $lFieldArr[18];
            $lHrEmployeeTabObj->cycle_code             = $lFieldArr[19];
            $lHrEmployeeTabObj->phone                  = $lFieldArr[20];
            $lHrEmployeeTabObj->ext                    = $lFieldArr[21];
            $lHrEmployeeTabObj->email_id               = $lFieldArr[22];
            $lHrEmployeeTabObj->building_id            = $lFieldArr[23];
            $lHrEmployeeTabObj->floor_num              = $lFieldArr[24];
            $lHrEmployeeTabObj->room_num               = $lFieldArr[25];
            $lHrEmployeeTabObj->cubical_num            = $lFieldArr[26];
            $lHrEmployeeTabObj->emp_status             = $lFieldArr[27];
            $lHrEmployeeTabObj->emp_status_date        = $lFieldArr[28];
            $lHrEmployeeTabObj->emp_agreement_sts      = $lFieldArr[29];
            $lHrEmployeeTabObj->emp_agreement_sts_date = $lFieldArr[30];
            $lHrEmployeeTabObj->country                = $lFieldArr[31];
            $lHrEmployeeTabObj->recruit_req_id         = $lFieldArr[32];
            $lHrEmployeeTabObj->work_org_id            = $lFieldArr[33];
            $lHrEmployeeTabObj->marital_status         = $lFieldArr[34];
            $lHrEmployeeTabObj->pan_ind                = $lFieldArr[35];
            $lHrEmployeeTabObj->pf_ind                 = $lFieldArr[36];
            $lHrEmployeeTabObj->esi_ind                = $lFieldArr[37];
            $lHrEmployeeTabObj->pan_num                = $lFieldArr[38];
            $lHrEmployeeTabObj->pan_create_date        = $lFieldArr[39];
            $lHrEmployeeTabObj->epf_act_num            = $lFieldArr[40];
            $lHrEmployeeTabObj->epf_act_open_dt        = $lFieldArr[41];
            $lHrEmployeeTabObj->epf_act_close_dt       = $lFieldArr[42];
            $lHrEmployeeTabObj->prev_epf_act_num       = $lFieldArr[43];
            $lHrEmployeeTabObj->prev_epf_act_open_dt   = $lFieldArr[44];
            $lHrEmployeeTabObj->prev_epf_act_close_dt  = $lFieldArr[45];
            $lHrEmployeeTabObj->esi_num                = $lFieldArr[46];
            $lHrEmployeeTabObj->esi_act_open_dt        = $lFieldArr[47];
            $lHrEmployeeTabObj->esi_act_close_dt       = $lFieldArr[48];
            $lHrEmployeeTabObj->prev_esi_num           = $lFieldArr[49];
            $lHrEmployeeTabObj->prev_esi_num_open_dt   = $lFieldArr[50];
            $lHrEmployeeTabObj->prev_esi_num_close_dt  = $lFieldArr[51];
            $lHrEmployeeTabObj->nss_num                = $lFieldArr[52];
            $lHrEmployeeTabObj->nss_create_date        = $lFieldArr[53];
            $lHrEmployeeTabObj->gender                 = $lFieldArr[54];
            $lHrEmployeeTabObj->dob                    = $lFieldArr[55];
            $lHrEmployeeTabObj->birth_city             = $lFieldArr[56];
            $lHrEmployeeTabObj->birth_country          = $lFieldArr[57];
            $lHrEmployeeTabObj->relation_type          = $lFieldArr[58];
            $lHrEmployeeTabObj->relative_name          = $lFieldArr[59];
            $lHrEmployeeTabObj->applicant_id           = $lFieldArr[60];
            $lHrEmployeeTabObj->emp_card_id            = $lFieldArr[61];
            $lHrEmployeeTabObj->banker_code            = $lFieldArr[62];
            $lHrEmployeeTabObj->banker_name            = $lFieldArr[63];
            $lHrEmployeeTabObj->salary_mode            = $lFieldArr[64];
            $lHrEmployeeTabObj->pay_card_num           = $lFieldArr[65];
            $lHrEmployeeTabObj->bank_act_num           = $lFieldArr[66];
            $lHrEmployeeTabObj->father_name            = $lFieldArr[67];
            $lHrEmployeeTabObj->mother_name            = $lFieldArr[68];
            $lHrEmployeeTabObj->spouse_name            = $lFieldArr[69];
            $lHrEmployeeTabObj->barcode                = $lFieldArr[70];
            $lHrEmployeeTabObj->user_id                = $lFieldArr[71];
            $lHrEmployeeTabObj->pswd_0                 = $lFieldArr[72];
            $lHrEmployeeTabObj->p_address_1            = $lFieldArr[73];
            $lHrEmployeeTabObj->p_address_2            = $lFieldArr[74];
            $lHrEmployeeTabObj->p_city                 = $lFieldArr[75];
            $lHrEmployeeTabObj->p_state                = $lFieldArr[76];
            $lHrEmployeeTabObj->p_zip                  = $lFieldArr[77];
            $lHrEmployeeTabObj->p_country              = $lFieldArr[78];
            $lHrEmployeeTabObj->m_address_1            = $lFieldArr[79];
            $lHrEmployeeTabObj->m_address_2            = $lFieldArr[80];
            $lHrEmployeeTabObj->m_city                 = $lFieldArr[81];
            $lHrEmployeeTabObj->m_state                = $lFieldArr[82];
            $lHrEmployeeTabObj->m_zip                  = $lFieldArr[83];
            $lHrEmployeeTabObj->m_country              = $lFieldArr[84];
            $lHrEmployeeTabObj->hospital_id            = $lFieldArr[85];
            $lHrEmployeeTabObj->course_id              = $lFieldArr[86];
           
            $lHrEmployeeTabObjArr[$lRecNum-1] = $lHrEmployeeTabObj;
          }
        }
      }

      if( $lHrEmployeeTabObjArr !== null && count($lHrEmployeeTabObjArr) > 0 )
          return $lHrEmployeeTabObjArr;
         else
          return null;
    }


   public function createHrEmployee()
   {
     //GETTING FILE SOURCE
     $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
     $lFileNamePath .= $this->lEmployeeFileName;

     $lHrEmployeeArr = array();

     if( isset( $_POST['org_id'] ) )
       $lOrgId          = $_POST['org_id'];
     else
       $lOrgId          = "";

     if( isset( $_POST['initial'] ) )
       $lInitial        = $_POST['initial'];
     else
       $lInitial        = "";

     if( isset( $_POST['first_name'] ) )
       $lFirstName      = $_POST['first_name'];
     else
       $lFirstName      = "";

     if( isset( $_POST['middle_name'] ) )
       $lMiddleName       = $_POST['middle_name'];
     else
       $lMiddleName       = "";

     if( isset( $_POST['last_name'] ) )
       $lLastName       = $_POST['last_name'];
     else
       $lLastName       = "";

     if( isset( $_POST['dept_id'] ) )
       $lDeptId       = $_POST['dept_id'];
     else
       $lDeptId       = "";

     if( isset( $_POST['employee_id'] ) )
       $lEmployeeId     = $_POST['employee_id'];
     else
       $lEmployeeId     = "";

     if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
     {
       $lHrEmployeeArr     = $this->readHrEmployeeData();
       try
       {
         //OPEN A FILE FROM THE GIVEN PATH
         $lFileHandler  = fopen($lFileNamePath, "w") or die("FILE CAN NOT BE OPEN !!");

         if( $lHrEmployeeArr !== null && count($lHrEmployeeArr) > 0 )
         {
           for( $lRecNum = 1; $lRecNum <= count ($lHrEmployeeArr); $lRecNum++ )
           {
             $lWriteLineData = $lHrEmployeeArr[$lRecNum-1];
             fwrite( $lFileHandler, $lWriteLineData );
           }
         }

         //PREPARE DATA FOR WRITE
         $lCSVFileData = "$lOrgId".",".$lEmployeeId.",".$lInitial.",".$lFirstName.",".$lMiddleName.",".$lLastName.",,,,,".$lDeptId.",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\n";

         fwrite($lFileHandler, $lCSVFileData);
       }
       catch (Exception $Ex )
       {
         echo $Ex->getMessage();
         return -1;
       }
       // Close the file
       fclose($lFileHandler);
     }
     else
       return -1;

     return 0; 
   } 


   private function readHrEmployeeData()
   {
     $lRecNum         = 0;
     $lHrEmployeeArr  = array();

     try
     {
       $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
       $lFileNamePath  .= $this->lEmployeeFileName;

       //OPEN A FILE FROM THE GIVEN PATH
       if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
       if ( filesize ($lFileNamePath) > 0 )
       {
         $lFileHandler  = fopen($lFileNamePath, "r") or die("FILE CAN NOT BE OPEN !!");
         //GETTING THE SIZE OF THE FILE 
         $lFileSize     = filesize($lFileNamePath);

         while (!feof($lFileHandler))
         {
           if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )
           {
             $lHrEmployeeArr[$lRecNum] = $lRecordLine;
             $lRecNum = $lRecNum + 1;
           }
         }
       }
       else
         return null;
     }
     catch (Exception $Ex )
     {
       echo $Ex->getMessage();
     }

       // Close the file
       fclose($lFileHandler);

       if( $lHrEmployeeArr !== null && count( $lHrEmployeeArr ) > 0 )
          return $lHrEmployeeArr;
       else
         null;
   }


    public function deleteHrEmployee($lOrgId, $lEmployeeId)
    {
       $lDELETED_SUUCESSFUL = "false";

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lEmployeeFileName;
         /*
          This Array Will Contain All the Employee Data
         */

         $lHrEmployeeArr = $this->readHrEmployeeData();

         if( $lHrEmployeeArr !== null && count( $lHrEmployeeArr ) > 0 )
         {
           for( $lRecNum = 0; $lRecNum < count( $lHrEmployeeArr ); $lRecNum++ )
           {
             $lRecordLine    = $lHrEmployeeArr[$lRecNum];
             $lFieldValueArr = explode( ",", $lRecordLine );

             if( $lOrgId == $lFieldValueArr[0] )
               if( $lEmployeeId == $lFieldValueArr[1] )
               {
                 unset( $lHrEmployeeArr[$lRecNum] );//THIS WILL REMOVE THE INDEX POS VALUE
                 $lHrEmployeeArr = array_values($lHrEmployeeArr);//THIS WILL TRANSFER THE VALUE WITH NEW INDEXS\
                 $lDELETED_SUUCESSFUL = "true";
                 break;
               }
           }
         }

         if( $lDELETED_SUUCESSFUL == "true" )
         {
           // Open the file and erase the contents if any
           $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

           if( $lHrEmployeeArr !== null && count($lHrEmployeeArr) > 0 )
           {
             for( $lRecNum = 1; $lRecNum <= count ($lHrEmployeeArr); $lRecNum++ )
             {
               $lWriteLineData = $lHrEmployeeArr[$lRecNum-1];
               fwrite( $lFileHandler, $lWriteLineData );
             }
           }
         }
         else
          return -1;
       }
       catch (Exception $Ex )
       {
         echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);
       return 0; 
    }


    public function updateHrEmployee($lOrgId, $lEmployeeId)
    {
       $lUPDATION_SUUCESSFUL = "false";

       if( isset( $_POST['org_id'] ) )
         $lOrgId          = $_POST['org_id'];
       else
         $lOrgId          = "";

       if( isset( $_POST['employee_id'] ) )
         $lEmployeeId     = $_POST['employee_id'];
       else
         $lEmployeeId     = "";

       if( isset( $_POST['initial'] ) )
         $lInitial        = $_POST['initial'];
       else
         $lInitial        = "";

       if( isset( $_POST['first_name'] ) )
         $lFirstName      = $_POST['first_name'];
       else
         $lFirstName      = "";

       if( isset( $_POST['last_name'] ) )
         $lLastName       = $_POST['last_name'];
       else
         $lLastName       = "";

       if( isset( $_POST['middle_name'] ) )
         $lMiddleName       = $_POST['middle_name'];
       else
         $lMiddleName       = "";
       
       if( isset( $_POST['dept_id'] ) )
         $lDeptId       = $_POST['dept_id'];
       else
         $lDeptId       = "";

       if( isset( $_POST['short_name'] ) )
         $lShortName     = $_POST['short_name'];
       else
         $lShortName     = "";
 
       if( isset( $_POST['position_id'] ) )
         $lPositionId    = $_POST['position_id'];
       else
         $lPositionId    = "";

       if( isset( $_POST['level_id'] ) )
         $lLevelId       = $_POST['level_id'];
       else
         $lLevelId       = "";

       if( isset( $_POST['designation'] ) )
         $lDesignation   = $_POST['designation'];
       else
         $lDesignation   = "";

       if( isset( $_POST['doj'] ) )
         $lDoj           = $_POST['doj'];
       else
         $lDoj           = "";

       if( isset( $_POST['phone'] ) )
         $lPhone         = $_POST['phone'];
       else
         $lPhone         = "";

       if( isset( $_POST['address'] ) )
         $lAddress       = $_POST['address'];
       else
         $lAddress       = "";

       if( isset( $_POST['city'] ) )
         $lCity          = $_POST['city'];
       else
         $lCity          = "";

       if( isset( $_POST['state'] ) )
         $lState         = $_POST['state'];
       else
         $lState         = "";

       if( isset( $_POST['country'] ) )
         $lCountry       = $_POST['country'];
       else
         $lCountry       = "";

       if( isset( $_POST['marital_status'] ) )
         $lMaritalSts    = $_POST['marital_status'];
       else
         $lMaritalSts    = "";

       if( isset( $_POST['gender'] ) )
         $lGender        = $_POST['gender'];
       else
         $lGender        = "";

       if( isset( $_POST['dob'] ) )
         $lDOB           = $_POST['dob'];
       else
         $lDOB           = "";

       if( isset( $_POST['father_name'] ) )
         $lFatherName    = $_POST['father_name'];
       else
         $lFatherName    = "";

       if( isset( $_POST['mother_name'] ) )
         $lMotherName    = $_POST['mother_name'];
       else
         $lMotherName    = "";

       if( isset( $_POST['spouse_name'] ) )
         $lSpouseName    = $_POST['spouse_name'];
       else
         $lSpouseName    = "";

       try
       {
         $lFileNamePath   = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath  .= $this->lEmployeeFileName;
         /*
          This Array Will Contain All the Employee Data
         */

         $lHrEmployeeArr = $this->readHrEmployeeData();

         if( $lHrEmployeeArr !== null && count( $lHrEmployeeArr ) > 0 )
         {
           for( $lRecNum = 0; $lRecNum < count( $lHrEmployeeArr ); $lRecNum++ )
           {
             $lRecordLine    = $lHrEmployeeArr[$lRecNum];
             $lFieldValueArr = explode( ",", $lRecordLine );

             if( $lOrgId == $lFieldValueArr[0] )
               if( $lEmployeeId == $lFieldValueArr[1] )
               {
                 $lUpdatedRecLine ="$lOrgId".",".$lEmployeeId.",".$lInitial.",".$lFirstName.",".$lMiddleName.",".$lLastName.",".$lShortName.",,,,".$lDeptId.",,".$lPositionId.",".$lLevelId.",".$lDesignation.",".$lDoj.",,,,,".$lPhone.",,,,,,,,,,,".$lCountry.",,,".$lMaritalSts.",,,,,,,,,,,,,,,,,,,,".$lGender.",".$lDOB.",,,,,,,,,,,,".$lFatherName.",".$lMotherName.",".$lSpouseName.",,,,,".$lAddress.",,".$lCity.",".$lState.",,,,,,,,,,,\n";

                 $lHrEmployeeArr[$lRecNum] = $lUpdatedRecLine; //ARRAY UPDATE WITHE UPDATED RECORD
                 $lUPDATION_SUUCESSFUL = "true";
                 break;
               }
           }
         }

         if( $lUPDATION_SUUCESSFUL == "true" )
         {
           // Open the file and erase the contents if any
           $lFileHandler = fopen($lFileNamePath, "w") or die("Request File Can Not Open!!!");

           if( $lHrEmployeeArr !== null && count($lHrEmployeeArr) > 0 )
           {
             for( $lRecNum = 1; $lRecNum <= count ($lHrEmployeeArr); $lRecNum++ )
             {
               $lWriteLineData = $lHrEmployeeArr[$lRecNum-1];
               fwrite( $lFileHandler, $lWriteLineData );
             }
           }
         }
         else
          return -1;
       }
       catch (Exception $Ex )
       {
         echo $Ex->getMessage();
       }

       // Close the file
       fclose($lFileHandler);
       return 0; 
    }

  }
?>
