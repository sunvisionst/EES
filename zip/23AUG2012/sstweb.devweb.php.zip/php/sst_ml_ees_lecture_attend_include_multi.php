<?
    echo "<input type=\"hidden\" 
                 id=\"org_id_$lStudRec\" 
                 name=\"org_id_$lStudRec\" 
                 value=\"SGI\"/>";

    echo "<input type=\"hidden\" 
                 id=\"student_id_$lStudRec\" 
                 name=\"student_id_$lStudRec\" 
                 value=\"$lEesStudentTabObj->student_id\"/>";

    echo "<td align=\"right\">";
    echo $lEesStudentTabObj->student_id; 
    echo "</td>";

    echo "<input type=\"hidden\" 
                 id=\"student_name_$lStudRec\" 
                 name=\"student_name_$lStudRec\" 
                 value=\"$lEesStudentTabObj->student_name\"/>";

    echo "<td align=\"right\">";
    echo $lEesStudentTabObj->student_name; 
    echo "</td>";

         
    echo "<input type=\"hidden\" 
                 id=\"period_num_$lStudRec\" 
                 name=\"period_num_$lStudRec\" 
                 value=\"$lPeriodNum\"/>";

    echo "<input type=\"hidden\" 
                 id=\"lecture_date_$lStudRec\" 
                 name=\"lecture_date_$lStudRec\" 
                 value=\"$lTodayGUIDate\"/>";

    echo "<input type=\"hidden\" 
                 id=\"roll_num_$lStudRec\" 
                 name=\"roll_num_$lStudRec\" 
                 value=\"$lEesStudentTabObj->roll_num\"/>";

    echo "<input type=\"hidden\" 
                 id=\"subject_code_$lStudRec\" 
                 name=\"subject_code_$lStudRec\" 
                 value=\"$lSubjectCode\"/>";


    //PREP CLASS ID
    if( $lCourseId !== null && $lCourseId == "MCA" )  
       $lClassId = $lCourseId."/".$lClassNum."/".$lCourseTerm."/".$lClassSection;
    else
       $lClassId = $lCourseId."/".$lCourseStream."/".$lClassNum."/".$lCourseTerm."/".$lClassSection;


    echo "<input type=\"hidden\" 
                 id=\"class_id_$lStudRec\" 
                 name=\"class_id_$lStudRec\" 
                 value=\"$lClassId\">";
           
 
    if( $lEesLectureAttendTabObjArr !== null && count($lEesLectureAttendTabObjArr) > 0 )
    {
      $lEesLectureAttndTabObjKey   = "SGI".$lEesStudentTabObj->student_id.$lTodayDBDate.$lClassId;

      if ( array_key_exists($lEesLectureAttndTabObjKey, $lEesLectureAttendTabObjArr) )
         $lEesLectureAttendTabObj = $lEesLectureAttendTabObjArr[$lEesLectureAttndTabObjKey];

      if( $lEesLectureAttendTabObj !== null )
        $lFieldValue = $lEesLectureAttendTabObj->attendance_status; 
    }
         
    echo "<td align=\"right\">";
    echo "<input type=\"hidden\" 
                 id=\"select_checkbox_r$lStudRec\" 
                 name=\"select_checkbox_r$lStudRec\" 
                 value=\"N\">";

    echo "<input type=\"checkbox\" 
                 id=\"attendance_sts_$lStudRec\" 
                 onClick=\"
                          {
                            if( document.form.attendance_sts_$lStudRec.checked ) 
                             document.getElementById('select_checkbox_r$lStudRec').value = 'Y';
                            else
                             document.getElementById('select_checkbox_r$lStudRec').value = 'N';
                          }
                         \" 

                 name=\"attendance_sts_$lStudRec\">";
    echo "</td>";


    if( $lFieldValue !== null && $lFieldValue == "P" )
    {
      echo "<Script language=\"JavaScript\">";  
      echo " document.getElementById('attendance_sts_$lStudRec').checked = true;";  
      echo " document.getElementById('select_checkbox_r$lStudRec').value = 'Y';"; 
      echo "</Script>";  
    }

?>
