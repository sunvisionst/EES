<?
   include("EesStudentTabObj.php");
   require_once("sst_ml_filter_record.php");
 
  class EesStudentMethodObj
  { 
     public  $lStudentFileName      = "";
     public  $lFilteredFileName             = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilterCriteriaValue1         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition1            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

     //--------------------------------------------------------------------------------------------------
     /*
      FUNCTION TO GET       
      EES_STUDENT_TABOBJ_ARR.        
     */
     public function gtEesStudentTabObjArr() 
     {
         $lEesStudentTabObjArr  = array();
         //FILTER OBJECT    
         $lSSTFilter = new SSTFilter();
         //-----------------------------------------------------------------------------
         //READ FILE 
         //-----------------------------------------------------------------------------

         //GETTING FILE SOURCE
         //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/refdb/datafiledir/".$this->lStudentFileName;
         //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/refdb/datafiledir/".$this->lStudentFileName; 
         //$lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
         //$lFileNamePath .= "SGI/refdb/datafiledir/".$this->lStudentFileName;
         $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath .= $this->lStudentFileName;


         //FILTER PART START
         $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/"; 
         $lSSTFilter->lFilteredFileName     = $this->lFilteredFileName; //ASSIGN FILE NAME TO FILTER
         $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1; //ASSIGN CRITERIA VALUE TO FILTER
         $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
 
         if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         {
           //GETTING FILTERED RECORD ARR
           $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          
           
           if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
           { 
             for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
             {
               //PREP TABOBJ OBJECT
               $lEesStudentTabObj     = new EesStudentTabObj();
               $lFieldArr  = explode( ",", $lFilteredRecordArr[$lRecNum] );

               //PREP TAB OBJ FOR STUDENT 
               $lEesStudentTabObj->org_id                                = $lFieldArr[0];
               $lEesStudentTabObj->student_id                            = $lFieldArr[1];     
               $lEesStudentTabObj->barcode                               = $lFieldArr[2]; 
               $lEesStudentTabObj->user_id                               = $lFieldArr[3]; 
               $lEesStudentTabObj->pswd_0                                = $lFieldArr[4];
               $lEesStudentTabObj->student_name                          = $lFieldArr[5];        
               $lEesStudentTabObj->father_name                           = $lFieldArr[6];           
               $lEesStudentTabObj->mother_name                           = $lFieldArr[7];     
               $lEesStudentTabObj->student_ctg                           = $lFieldArr[8];     
               $lEesStudentTabObj->gender_flag                           = $lFieldArr[9];     
               $lEesStudentTabObj->dob                                   = $lFieldArr[10];
               $lEesStudentTabObj->doj                                   = $lFieldArr[11];
               $lEesStudentTabObj->dot                                   = $lFieldArr[12];
               $lEesStudentTabObj->p_address_1                           = $lFieldArr[13];      
               $lEesStudentTabObj->p_address_2                           = $lFieldArr[14];      
               $lEesStudentTabObj->p_country                             = $lFieldArr[15];     
               $lEesStudentTabObj->p_state                               = $lFieldArr[16]; 
               $lEesStudentTabObj->p_city                                = $lFieldArr[17];
               $lEesStudentTabObj->p_district                            = $lFieldArr[18];    
               $lEesStudentTabObj->p_zip                                 = $lFieldArr[19];     
               $lEesStudentTabObj->m_address_1                           = $lFieldArr[20];
               $lEesStudentTabObj->m_address_2                           = $lFieldArr[21];     
               $lEesStudentTabObj->m_country                             = $lFieldArr[22];   
               $lEesStudentTabObj->m_state                               = $lFieldArr[23]; 
               $lEesStudentTabObj->m_city                                = $lFieldArr[24];
               $lEesStudentTabObj->m_district                            = $lFieldArr[25];
               $lEesStudentTabObj->m_zip                                 = $lFieldArr[26];            
               $lEesStudentTabObj->class_id                              = $lFieldArr[27];
               $lEesStudentTabObj->class_num                             = $lFieldArr[28];       
               $lEesStudentTabObj->class_std                             = $lFieldArr[29];     
               $lEesStudentTabObj->class_section                         = $lFieldArr[30];         
               $lEesStudentTabObj->course_id                             = $lFieldArr[31];      
               $lEesStudentTabObj->course_term                           = $lFieldArr[32];      
               $lEesStudentTabObj->course_stream                         = $lFieldArr[33];         
               $lEesStudentTabObj->scholor_num                           = $lFieldArr[34];       
               $lEesStudentTabObj->roll_num                              = $lFieldArr[35];  
               $lEesStudentTabObj->external_roll_num                     = $lFieldArr[36];             
               $lEesStudentTabObj->enrollment_num                        = $lFieldArr[37];          
               $lEesStudentTabObj->shift_code                            = $lFieldArr[38];         
               $lEesStudentTabObj->prev_org_id                           = $lFieldArr[39];         
               $lEesStudentTabObj->prev_class_id                         = $lFieldArr[40];          
               $lEesStudentTabObj->prev_class_num                        = $lFieldArr[41];         
               $lEesStudentTabObj->prev_class_std                        = $lFieldArr[42];           
               $lEesStudentTabObj->prev_class_section                    = $lFieldArr[43];                
               $lEesStudentTabObj->prev_course_id                        = $lFieldArr[44];            
               $lEesStudentTabObj->prev_course_term                      = $lFieldArr[45];            
               $lEesStudentTabObj->prev_course_stream                    = $lFieldArr[46];              
               $lEesStudentTabObj->prev_shift_code                       = $lFieldArr[47];             
               $lEesStudentTabObj->promotion_sts                         = $lFieldArr[48];          
               $lEesStudentTabObj->promotion_date                        = $lFieldArr[49];        
               $lEesStudentTabObj->phone                                 = $lFieldArr[50];
               $lEesStudentTabObj->email_id                              = $lFieldArr[51];
               $lEesStudentTabObj->student_sts                           = $lFieldArr[52];         
               $lEesStudentTabObj->student_sts_date                      = $lFieldArr[53];           
               $lEesStudentTabObj->photo_file_name                       = $lFieldArr[54];           
               $lEesStudentTabObj->batch_number                          = $lFieldArr[55];          
               $lEesStudentTabObj->num_of_yr_in_class                    = $lFieldArr[56];             
               $lEesStudentTabObj->passing_year                          = $lFieldArr[57];         
               $lEesStudentTabObj->extra_class_ind                       = $lFieldArr[58];           
               $lEesStudentTabObj->admission_mode                        = $lFieldArr[59];           
               $lEesStudentTabObj->account_balance                       = $lFieldArr[60];            
               $lEesStudentTabObj->bal_close_curr                        = $lFieldArr[61];           
               $lEesStudentTabObj->dr_amt_curr                           = $lFieldArr[62];        
               $lEesStudentTabObj->cr_amt_curr                           = $lFieldArr[63];       
               $lEesStudentTabObj->bal_open_curr                         = $lFieldArr[64];        
               $lEesStudentTabObj->bal_close_prev                        = $lFieldArr[65];         
               $lEesStudentTabObj->dr_amt_prev                           = $lFieldArr[66];        
               $lEesStudentTabObj->cr_amt_prev                           = $lFieldArr[67];       
               $lEesStudentTabObj->bal_open_prev                         = $lFieldArr[68];        
               $lEesStudentTabObj->ban_status                            = $lFieldArr[69];       
               $lEesStudentTabObj->last_status_date                      = $lFieldArr[70];            
               $lEesStudentTabObj->bank_code                             = $lFieldArr[71];      
               $lEesStudentTabObj->year_qrt_num                          = $lFieldArr[72];       
               $lEesStudentTabObj->last_year_qrt_num                     = $lFieldArr[73];             
               $lEesStudentTabObj->next_year_qrt_num                     = $lFieldArr[74];            
               $lEesStudentTabObj->next_payment_date                     = $lFieldArr[75];           
               $lEesStudentTabObj->allergy                               = $lFieldArr[76]; 
               $lEesStudentTabObj->allergic_medicine                     = $lFieldArr[77];             
               $lEesStudentTabObj->physical_disability                   = $lFieldArr[78];               
               $lEesStudentTabObj->health_problem                        = $lFieldArr[79];         
               $lEesStudentTabObj->blood_group                           = $lFieldArr[80];     
               $lEesStudentTabObj->hobbies                               = $lFieldArr[81]; 
               $lEesStudentTabObj->lg_0_name                             = $lFieldArr[82];      
               $lEesStudentTabObj->lg_0_rel_type                         = $lFieldArr[83];         
               $lEesStudentTabObj->lg_0_address                          = $lFieldArr[84];          
               $lEesStudentTabObj->lg_0_phone                            = $lFieldArr[85];      
               $lEesStudentTabObj->lg_1_name                             = $lFieldArr[86];     
               $lEesStudentTabObj->lg_1_rel_type                         = $lFieldArr[87];        
               $lEesStudentTabObj->lg_1_address                          = $lFieldArr[88];        
               $lEesStudentTabObj->lg_1_phone                            = $lFieldArr[89];      
               $lEesStudentTabObj->lg_2_name                             = $lFieldArr[90];      
               $lEesStudentTabObj->lg_2_rel_type                         = $lFieldArr[91];         
               $lEesStudentTabObj->lg_2_address                          = $lFieldArr[92];         
               $lEesStudentTabObj->lg_2_phone                            = $lFieldArr[93];       
               $lEesStudentTabObj->father_age                            = $lFieldArr[94];       
               $lEesStudentTabObj->f_nationality                         = $lFieldArr[95];          
               $lEesStudentTabObj->father_occ_type                       = $lFieldArr[96];          
               $lEesStudentTabObj->father_employer                       = $lFieldArr[97];           
               $lEesStudentTabObj->father_designation                    = $lFieldArr[98];              
               $lEesStudentTabObj->father_annual_income                  = $lFieldArr[99];               
               $lEesStudentTabObj->f_off_address_1                       = $lFieldArr[100];           
               $lEesStudentTabObj->f_phone_list                          = $lFieldArr[101];        
               $lEesStudentTabObj->mother_age                            = $lFieldArr[102];      
               $lEesStudentTabObj->m_nationality                         = $lFieldArr[103];        
               $lEesStudentTabObj->mother_occ_type                       = $lFieldArr[104];          
               $lEesStudentTabObj->mother_employer                       = $lFieldArr[105];         
               $lEesStudentTabObj->mother_designation                    = $lFieldArr[106];             
               $lEesStudentTabObj->mother_annual_income                  = $lFieldArr[107];                
               $lEesStudentTabObj->m_off_address_1                       = $lFieldArr[108];          
               $lEesStudentTabObj->m_phone_list                          = $lFieldArr[109];        
               $lEesStudentTabObj->org_transport_req_ind                 = $lFieldArr[110];                  
               $lEesStudentTabObj->org_hostel_req_ind                    = $lFieldArr[111];            
               $lEesStudentTabObj->route_id                              = $lFieldArr[112];  
               $lEesStudentTabObj->stoppage_id                           = $lFieldArr[113];     
               $lEesStudentTabObj->stoppage_name                         = $lFieldArr[114];       
               $lEesStudentTabObj->trip_id                               = $lFieldArr[115];
  
               //PUT VALUE IN ARRAY
               $lEesStudentTabObjArr[$lRecNum-1] = $lEesStudentTabObj;
             }
           }
         }

         if( $lEesStudentTabObjArr !== null && count($lEesStudentTabObjArr) > 0 )
          return $lEesStudentTabObjArr;
         else
          return null;
     } 
  }     
?>
