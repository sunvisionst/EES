<?

  //------------------------------------------------
  // THIS CONDITION SHALL EXECUTE AFTER LOGIN
  //------------------------------------------------
  {
    //--------------------------------------------------------------------------

    if ( $lReturnValue < 0 )
       ;
    else
    {
      //--------------------------------------------------------------------------
      /*
       GETTING USER INFO FROM 
       HR EMPLOYEE FILE 
      */
      $lEmployeeFileName = "sst_".$lSSTLogin->lOrganizationId."_hr_employee_ext.dat";

      $lHrEmployeeMethodObj->lEmployeeFileName     = $lEmployeeFileName;
      $lHrEmployeeMethodObj->lFilterCriteriaValue1 = $lSSTLogin->lOrganizationId; ///ORG ID
      $lHrEmployeeMethodObj->lFilterCriteriaValue2 = $lSSTLogin->lEmployeeId; ///Employee ID
      $lHrEmployeeMethodObj->lFilteredPosition1    = 0;
      $lHrEmployeeMethodObj->lFilteredPosition2    = 1;

      $lHrEmployeeTabObjArr    = $lHrEmployeeMethodObj->gtHrEmployeeTabObjArr();
      $lHrEmployeeTabObjGlobal = $lHrEmployeeTabObjArr[0];
  
      //SETTING GLOBAL EMPLOYEE TABOBJ VALUE
      $_SESSION['lHrEmployeeTabObjGlobal'] = serialize($lHrEmployeeTabObjGlobal);
      //--------------------------------------------------------------------------

      $_SESSION['lOrgId']                  = $lSSTLogin->lOrganizationId;

      //--------------------------------------------------------------------------
      /*
       GETTING USER INFO FROM 
       GN_USER_ACCESS  
      */
      $lUserFileName = "sst_".$lSSTLogin->lOrganizationId."_gn_user_ext.dat";

      $lGnUserMethodObj->lUserFileName         = $lUserFileName;
      $lGnUserMethodObj->lFilterCriteriaValue1 = $lSSTLogin->lOrganizationId; ///ORG ID
      $lGnUserMethodObj->lFilterCriteriaValue2 = $lSSTLogin->lEmployeeId; ///Employee ID
      $lGnUserMethodObj->lFilteredPosition1    = 0;
      $lGnUserMethodObj->lFilteredPosition2    = 6;

      $lGnUserTabObjArr = $lGnUserMethodObj->gtGnUserTabObjArr();
      $lGnUserTabObj    = $lGnUserTabObjArr[0];
 
      //SETTING GLOBAL EMPLOYEE TABOBJ VALUE
      $_SESSION['lGnUserTabObj'] = serialize($lGnUserTabObj);
      //--------------------------------------------------------------------------

      $_SESSION['lCheckUserQty'] = $lSSTLogin->lCheckUserQty;//if This Flag is false means there is only one record in file

      //-----------------------------------------------------------------------------------------------------
      $lGnApplnSessionMethodObj->org_id           = $lOrgId;
      $lGnApplnSessionMethodObj->appln_short_name = "MLA";
      $lGnApplnSessionMethodObj->user_name        = $lHrEmployeeTabObjGlobal->employee_f_name." ".$lHrEmployeeTabObjGlobal->employee_l_name;
      $lGnApplnSessionMethodObj->user_id          = $lUserId;
      $lGnApplnSessionMethodObj->user_emp_id      = $lHrEmployeeTabObjGlobal->employee_id;
      $lGnApplnSessionMethodObj->pswd             = $lUserPass;
      $lGnApplnSessionMethodObj->session_status   = "A"; 
      $lGnApplnSessionMethodObj->role_type        = $lGnUserTabObj->role_type; 

      
      $lGnApplnSessionMethodObj->lSessionFileName = "sst_".$lOrgId."_session_ext.dat"; 
      //-----------------------------------------------------------------------------------------------------
      //------------------CHECK SESSION IF ALREADY EXISTS----------------------------------------------------
      //-----------------------------------------------------------------------------------------------------
       $lGnApplnSessionTabObjArr = $lGnApplnSessionMethodObj->insSessionRec();  //METHOD WHICH CHECK AN EXISTING SESSION 
   
       if ( $lGnApplnSessionTabObjArr !== null && count( $lGnApplnSessionTabObjArr ) > 0 )
           $lGnApplnSessionTabObj = $lGnApplnSessionTabObjArr[0]; 

      //-----------------------------------------------------------------------------------------------------
      if( $lGnApplnSessionTabObj !== null )  
        $_SESSIION['lGnApplnSessionTabObj'] = serialize($lGnApplnSessionTabObj); 

      if( $lSessionId !== null && strlen($lSessionId) > 0 )
      {
        $lGnApplnSessionMethodObj->session_id       = $lSessionId;
        $lGnApplnSessionMethodObj->insSessionRec();  //METHOD WHICH WRITE THE ANY NEW SESSION START IN FILE

      }
    }
  }
?>
