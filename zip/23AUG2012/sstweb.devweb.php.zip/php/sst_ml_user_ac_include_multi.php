<?php
  echo "<td align = \"right\">";
  echo $lGnUserTabObj->user_id;
  echo "</td>";

  echo "<td align = \"right\">";
  echo $lGnUserTabObj->user_emp_id;
  echo "</td>";

  echo "<td align = \"right\">";
  echo $lGnUserTabObj->user_name;
  echo "</td>";
?>
