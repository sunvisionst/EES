function check_password(evt)
{
  var lFlag = false;
  var lPassObj1 = document.getElementById('admin_password');
  var lPassObj2 = document.getElementById('re_admin_password');

  if( lPassObj1 != null && lPassObj2 != null && ( lPassObj1.value == lPassObj2.value ) )
  {
    lFlag = true; 
  }
  else
  {
    alert('Password Is Incorrect !!!');
    var lBrowserName = getBrowserName();
    if ( lBrowserName == 'Microsoft Internet Explorer' )
         window.event.returnValue=false;
    else
    if ( lBrowserName == 'Netscape' )
    {
       evt.preventDefault();
       evt.stopPropagation();
    }
  }
  return lFlag;
}
