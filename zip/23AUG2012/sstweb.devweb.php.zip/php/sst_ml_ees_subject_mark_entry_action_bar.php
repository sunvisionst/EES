<?
   echo "<table border=\"0\" name=\"\" id=\"\" width=\"100%\">";
   echo "<tr>"; 


   echo "<input type=\"hidden\" 
                id=\"submit_action\" 
                name=\"submit_action\" value=\"\"/>"; 
 
   $lCurrentPage = "sst_ml_ees_subject_mark_entry_envelop.php?menu_option=eesFaculty&req_type=facMarkEntry";

   echo "<td align=\"center\">"; 
   echo "<input type=\"submit\" 
                id=\"save_submit\" 
                name=\"save_submit\" 
                onclick=\"{
                            document.getElementById('submit_action').value = 'saveSubmit';
                            javascript:form.action='$lCurrentPage';
                          }
                        \" 
                value=\"Save Marks\"/>";
   echo "</td>"; 

   echo "<td align=\"center\">"; 
   echo "<input type=\"submit\" 
                id=\"approve_submit\" 
                name=\"approve_submit\" 
                onclick=\"{ 
                            document.getElementById('submit_action').value = 'approveSubmit';
                            javascript:form.action='$lCurrentPage';
                          }
                        \" 
                value=\"Approve Marks\"/>";
   echo "</td>"; 



   echo "</tr>"; 
   echo "</table>"; 
?>
