<?
  $lReportFileName   = "";
  $lCourseId         = "";
  $lCourseStream     = "";
  $lClassNum         = "";
  $lCourseTerm       = "";
  $lClassSection     = "";
  $lMonth            = "";
  $lSubjectCode      = "";
  $lStudentId        = "";
  $lEmployeeId       = "";

  $lMenuOption       = $_SESSION['lMenuOption']; 
  $lRequestType      = $_SESSION['lRequestType']; 
  $lCurrentMonth     = $_SESSION['lCurrentMonth']; 

  if( $lMenuOption !== null && $lMenuOption == 'eesCourse' )
  {
    $lCourseId         = $_SESSION['lCourseId']; 
    if( $lCourseId !== null && $lCourseId == 'BTECH' )
      $lCourseStream     = $_POST['course_stream'];

    $lClassNum         = $_POST['class_num'];
    $lCourseTerm       = $_POST['course_term'];
  }


  if(  $lRequestType !== null 
    && $lRequestType == 'facAttnEntry' 
    || $lRequestType == 'stuList' 
    || $lRequestType == 'facList' 
    || $lRequestType == 'classAtten' 
    || $lRequestType == 'classTT' 
    )
    $lClassSection     = $_POST['class_section'];


  if(  $lRequestType !== null 
    && $lRequestType == 'classAtten' 
    || $lRequestType == 'facTT'
    || $lRequestType == 'stuAtten'
   )
    $lMonth            = $_POST['month'];

  if(  $lRequestType !== null 
    && $lRequestType == 'facAttenEntry' 
    || $lRequestType == 'facMarkEntry'
    || $lRequestType == 'facSubProgEntry'
   )
    $lSubjectCode      = $_POST['subject_code'];

  if(  $lRequestType !== null 
    && $lRequestType == 'facAttenEntry' 
    || $lRequestType == 'stuProfile' 
    )
    $lStudentId        = $_POST['student_id'];


  if(  $lRequestType !== null 
    && $lRequestType == 'facProfile' 
    || $lRequestType == 'facTT'
    || $lRequestType == 'facAllocatedSubject'
   )
    $lEmployeeId       = $_POST['employee_id'];



 
  if( $lRequestType !== null && $lRequestType == 'subList' )
    $lReportType = "SUBJECT_LIST" ;
  else
  if( $lRequestType !== null && $lRequestType == 'facList' )
    $lReportType = "FACULTY_LIST" ;
  else
  if( $lRequestType !== null && $lRequestType == 'stuList' )
    $lReportType = "STUDENT_LIST" ;
  else
  if( $lRequestType !== null && $lRequestType == 'subProg' )
    $lReportType = "SUBJECT_PROGRESS";
  else
  if( $lRequestType !== null && $lRequestType == 'classTT' )
    $lReportType = "CLASS_TIMETABLE";
  else
  if( $lRequestType !== null && $lRequestType == 'facTT' )
    $lReportType = "FACULTY_TIMETABLE";
  else
  if( $lRequestType !== null && $lRequestType == 'facProfile' )
    $lReportType = "FACULTY_PROFILE";
  else
  if( $lRequestType !== null && $lRequestType == 'paidStud' )
    $lReportType = "PAID_STUDENT_LIST";
  else
  if( $lRequestType !== null && $lRequestType == 'stuProfile' )
    $lReportType = "STUDENT_PROFILE";
  else
  if( $lRequestType !== null && $lRequestType == 'classAtten' )
    $lReportType = "CLASS_ATTENDANCE";
  else
  if( $lRequestType !== null && $lRequestType == 'facAllocatedSubject' )
    $lReportType = "FACULTY_SUBJECT_ALLOCATION";
  else
  if( $lRequestType !== null && $lRequestType == 'stuMarkSheet' )
    $lReportType = "STUDENT_MARKSHEET";

  //--------------------------------------------------------------------------------------
  if ( $lCourseStream !== null && strlen($lCourseStream) > 0 ); else $lCourseStream = "NA";
  //--------------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------------
  //$lReportFileName = "SST"."_"SGI"_"."2008_2009"."_";
  $lReportFileName = "SST"."_".$lOrgId."_"."2008_2009"."_";
  //--------------------------------------------------------------------------------------
  if( $lMenuOption !== null && $lMenuOption == 'eesCourse' )
    $lReportFileName .="$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_";
   

  if(   $lRequestType !== null && $lRequestType == 'subList' )
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lReportType"."."."HTML"; 
  }
  else
  if(  ( $lRequestType !== null && $lRequestType == 'facList' )
    || ( $lRequestType !== null && $lRequestType == 'stuList' )
    || ( $lRequestType !== null && $lRequestType == 'classTT' )
    )
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lClassSection"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lClassSection"."_"."$lReportType"."."."HTML"; 
  }
  else 
  if( $lRequestType !== null && $lRequestType == 'subProg') 
  {
     $lSubjectCode = str_replace("/", "_", $lSubjectCode);
     $lSubjectCode = str_replace("-", "_", $lSubjectCode);

     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lReportType"."."."HTML"; 
  }
  else 
  if( $lRequestType !== null && $lRequestType == 'facTT') 
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lMonth"."_"."$lEmployeeId"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lMonth"."_"."$lEmployeeId"."_"."$lReportType"."."."HTML"; 
  }
  else 
  if( $lRequestType !== null && $lRequestType == 'facProfile') 
  {
    $lReportFileName = "";  
    //$lReportFileName = "SST"."_"."SGI"."_"."$lEmployeeId"."_"."$lReportType"."."."HTML"; 
    $lReportFileName = "SST"."_".$lOrgId."_"."$lEmployeeId"."_"."$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'paidStud' )
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'stuProfile' )
  {
     $lStudentId = str_replace("/", "_", $lStudentId);
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lStudentId"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lStudentId"."_"."$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'classAtten' )
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lClassSection"."_"."$lCurrentMonth"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lClassSection"."_"."$lCurrentMonth"."_"."$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'facList' )
  {
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lCourseId"."_"."$lCourseStream"."_"."$lClassNum"."_"."$lCourseTerm"."_"."$lClassSection"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lClassSection"."_"."$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'facAllocatedSubject' )
  {
    //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lEmployeeId"."_"."$lReportType"."."."HTML"; 
    $lReportFileName .="$lEmployeeId"."_"."$lReportType"."."."HTML"; 
  }
  else
  if( $lRequestType !== null && $lRequestType == 'stuMarkSheet' )
  {
     $lStudentId = str_replace("/", "_", $lStudentId);
     //$lReportFileName = "SST"."_"."SGI"."_"."2008_2009"."_"."$lStudentId"."_"."$lReportType"."."."HTML"; 
     $lReportFileName .="$lStudentId"."_"."$lReportType"."."."HTML"; 
  }

   //echo "AAAA---->>".$lReportFileName;

   echo "<table id=\"common_menu_tab\" name=\"common_menu_tab\" border=\"0\" width=\"100%\">";
   echo"<tr>";

   echo"<td align = \"center\" width = \"100%\">";
   echo"<fieldset>";
   echo"<legend><font color = \"white\" >Dash Board For ". $lCourseId ."</font></legend>";
   echo"<table border = \"0\" width = \"100%\"> ";
   echo"<tr>";
   echo"<td>";

   include("sst_ml_common_query_menu_box.php");

   echo"</td>";
   echo"</tr>";
   echo"</table> ";
   echo"</fieldset>";
   echo"</td>";

   echo"</tr>";

   $lReportFilePath  = $_SESSION['SST_MLA_OUTBOX_DIR'];
   $lReportFilePath .= $lReportFileName;


  //if ( file_exists("outbox/".$lReportFileName) && is_readable ("outbox/".$lReportFileName) )
  if ( file_exists($lReportFilePath) && is_readable ($lReportFilePath) )
  {
    echo"<tr>";
    echo"<td width=\"75%\">";
    echo"<table border = \"0\" width = \"100%\"> ";
    echo"<tr>";
    echo"<td>";
    require_once($lReportFilePath);
    echo"</td>";
    echo"</tr>";
    echo"</table> ";
    echo"</td>";
    echo"</tr>";
  }
  else
  {
    echo"<tr>";
    echo"<td>";
    echo "<table id=\"error_file_tab\" name=\"error_file_tab\" border=\"0\">";
    echo "<tr>";

    echo "<td align=\"center\">";
    echo "<h1><font color=\"red\">Report File Not Prepared By SST !!!</font></h1>";
    echo "</td>";

    echo "<tr>";
    echo "</table>";
    echo"</td>";
    echo"</tr>";
  }


  echo "</table>";
?>
