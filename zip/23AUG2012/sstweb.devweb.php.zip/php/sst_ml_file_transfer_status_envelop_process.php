<?
  { 
   echo "<table border=\"0\" width=\"100%\">"; 
   echo "<tr>"; 

   echo "<td>"; 
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >File Transfer Status </font></legend>";

   echo "<table border=\"0\" width=\"100%\">"; 

   echo "<tr>"; 
   echo "<td colspan=\"3\">"; 
   include("sst_ml_file_transfer_status_link.php");  
   echo "</td>"; 
   echo "</tr>"; 

   echo "<tr>"; 

   echo "<td>"; 
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Sent Files</font></legend>";

   echo "<table border=\"0\" width=\"100%\">"; 
   echo "<tr>"; 

   echo "<td>"; 
   include("sst_ml_file_transfer_status_include_th.php");  
   echo "</td>"; 

   echo "</tr>"; 
   echo "</table>"; 

   echo "</fieldset>";
   echo "</td>"; 

   //EMPTY TD
   echo "<td width = \"1%\">"; 
   echo "</td>"; 
   //EMPTY TD

   echo "<td>"; 
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Received Files </font></legend>";

   echo "<table border=\"0\" width=\"100%\">"; 
   echo "<td>"; 
   include("sst_ml_file_transfer_status_include_th.php");  
   echo "</td>"; 
   echo "</table>"; 

   echo "</fieldset>";
   echo "</td>"; 


   echo "</tr>"; 
   echo "</table>"; 

   echo "</fieldset>";
   echo "</td>"; 

   echo "</tr>"; 
   echo "</table>"; 
  }
?>
