<?

class GnUserTabObj
{
  public $tab_rowid;
  public $org_id;
  public $user_id;
  public $user_name;
  public $role_type;
  public $lnf_template_id;
  public $remark;
  public $user_emp_id;
  public $parent_user_id;
  public $pswd_change_cnt;
  public $pswd_0;
  public $pswd_1;
  public $pswd_2;
  public $pswd_3;
  public $pswd_4;
  public $pswd_5;
  public $pswd_6;
  public $pswd_7;
  public $pswd_8;
  public $pswd_9;
  public $pswd_10;
  public $pswd_11;
  public $pswd_12;
  public $pswd_effective_date;
  public $expiry_period;
  public $hint;
  public $hint_ans;
  public $effective_date;
  public $expiration_date;
  public $user_status;
  public $user_status_date;





  public $org_id_ind;
  public $user_id_ind;
  public $user_name_ind;
  public $role_type_ind;
  public $lnf_template_id_ind;
  public $remark_ind;
  public $user_emp_id_ind;
  public $parent_user_id_ind;
  public $pswd_change_cnt_ind;
  public $pswd_0_ind;
  public $pswd_1_ind;
  public $pswd_2_ind;
  public $pswd_3_ind;
  public $pswd_4_ind;
  public $pswd_5_ind;
  public $pswd_6_ind;
  public $pswd_7_ind;
  public $pswd_8_ind;
  public $pswd_9_ind;
  public $pswd_10_ind;
  public $pswd_11_ind;
  public $pswd_12_ind;
  public $pswd_effective_date_ind;
  public $expiry_period_ind;
  public $hint_ind;
  public $hint_ans_ind;
  public $effective_date_ind;
  public $expiration_date_ind;
  public $user_status_ind;
  public $user_status_date_ind;


  public function __construct(){}


  public function GnUserTabObj
  (
    $org_id,
    $user_id,
    $user_name,
    $role_type,
    $lnf_template_id,
    $remark,
    $user_emp_id,
    $parent_user_id,
    $pswd_change_cnt,
    $pswd_0,
    $pswd_1,
    $pswd_2,
    $pswd_3,
    $pswd_4,
    $pswd_5,
    $pswd_6,
    $pswd_7,
    $pswd_8,
    $pswd_9,
    $pswd_10,
    $pswd_11,
    $pswd_12,
    $pswd_effective_date,
    $expiry_period,
    $hint,
    $hint_ans,
    $effective_date,
    $expiration_date,
    $user_status,
    $user_status_date
  )
  {
     $this->org_id                          = $org_id;
     $this->user_id                         = $user_id;
     $this->user_name                       = $user_name;
     $this->role_type                       = $role_type;
     $this->lnf_template_id                 = $lnf_template_id;
     $this->remark                          = $remark;
     $this->user_emp_id                     = $user_emp_id;
     $this->parent_user_id                  = $parent_user_id;
     $this->pswd_change_cnt                 = $pswd_change_cnt;
     $this->pswd_0                          = $pswd_0;
     $this->pswd_1                          = $pswd_1;
     $this->pswd_2                          = $pswd_2;
     $this->pswd_3                          = $pswd_3;
     $this->pswd_4                          = $pswd_4;
     $this->pswd_5                          = $pswd_5;
     $this->pswd_6                          = $pswd_6;
     $this->pswd_7                          = $pswd_7;
     $this->pswd_8                          = $pswd_8;
     $this->pswd_9                          = $pswd_9;
     $this->pswd_10                         = $pswd_10;
     $this->pswd_11                         = $pswd_11;
     $this->pswd_12                         = $pswd_12;
     $this->pswd_effective_date             = $pswd_effective_date;
     $this->expiry_period                   = $expiry_period;
     $this->hint                            = $hint;
     $this->hint_ans                        = $hint_ans;
     $this->effective_date                  = $effective_date;
     $this->expiration_date                 = $expiration_date;
     $this->user_status                     = $user_status;
     $this->user_status_date                = $user_status_date;
  }

  public function getorg_id()                           { return $this->org_id; }
  public function getuser_id()                          { return $this->user_id; }
  public function getuser_name()                        { return $this->user_name; }
  public function getrole_type()                        { return $this->role_type; }
  public function getlnf_template_id()                  { return $this->lnf_template_id; }
  public function getremark()                           { return $this->remark; }
  public function getuser_emp_id()                      { return $this->user_emp_id; }
  public function getparent_user_id()                   { return $this->parent_user_id; }
  public function getpswd_change_cnt()                  { return $this->pswd_change_cnt; }
  public function getpswd_0()                           { return $this->pswd_0; }
  public function getpswd_1()                           { return $this->pswd_1; }
  public function getpswd_2()                           { return $this->pswd_2; }
  public function getpswd_3()                           { return $this->pswd_3; }
  public function getpswd_4()                           { return $this->pswd_4; }
  public function getpswd_5()                           { return $this->pswd_5; }
  public function getpswd_6()                           { return $this->pswd_6; }
  public function getpswd_7()                           { return $this->pswd_7; }
  public function getpswd_8()                           { return $this->pswd_8; }
  public function getpswd_9()                           { return $this->pswd_9; }
  public function getpswd_10()                          { return $this->pswd_10; }
  public function getpswd_11()                          { return $this->pswd_11; }
  public function getpswd_12()                          { return $this->pswd_12; }
  public function getpswd_effective_date()              { return $this->pswd_effective_date; }
  public function getexpiry_period()                    { return $this->expiry_period; }
  public function gethint()                             { return $this->hint; }
  public function gethint_ans()                         { return $this->hint_ans; }
  public function geteffective_date()                   { return $this->effective_date; }
  public function getexpiration_date()                  { return $this->expiration_date; }
  public function getuser_status()                      { return $this->user_status; }
  public function getuser_status_date()                 { return $this->user_status_date; }



  public function  setorg_id($org_id )                               { $this->org_id               = $org_id; }
  public function  setuser_id($user_id )                             { $this->user_id              = $user_id; }
  public function  setuser_name($user_name )                         { $this->user_name            = $user_name; }
  public function  setrole_type($role_type )                         { $this->role_type            = $role_type; }
  public function  setlnf_template_id($lnf_template_id )             { $this->lnf_template_id      = $lnf_template_id; }
  public function  setremark($remark )                               { $this->remark               = $remark; }
  public function  setuser_emp_id($user_emp_id )                     { $this->user_emp_id          = $user_emp_id; }
  public function  setparent_user_id($parent_user_id )               { $this->parent_user_id       = $parent_user_id; }
  public function  setpswd_change_cnt($pswd_change_cnt )             { $this->pswd_change_cnt      = $pswd_change_cnt; }
  public function  setpswd_0($pswd_0 )                               { $this->pswd_0               = $pswd_0; }
  public function  setpswd_1($pswd_1 )                               { $this->pswd_1               = $pswd_1; }
  public function  setpswd_2($pswd_2 )                               { $this->pswd_2               = $pswd_2; }
  public function  setpswd_3($pswd_3 )                               { $this->pswd_3               = $pswd_3; }
  public function  setpswd_4($pswd_4 )                               { $this->pswd_4               = $pswd_4; }
  public function  setpswd_5($pswd_5 )                               { $this->pswd_5               = $pswd_5; }
  public function  setpswd_6($pswd_6 )                               { $this->pswd_6               = $pswd_6; }
  public function  setpswd_7($pswd_7 )                               { $this->pswd_7               = $pswd_7; }
  public function  setpswd_8($pswd_8 )                               { $this->pswd_8               = $pswd_8; }
  public function  setpswd_9($pswd_9 )                               { $this->pswd_9               = $pswd_9; }
  public function  setpswd_10($pswd_10 )                             { $this->pswd_10              = $pswd_10; }
  public function  setpswd_11($pswd_11 )                             { $this->pswd_11              = $pswd_11; }
  public function  setpswd_12($pswd_12 )                             { $this->pswd_12              = $pswd_12; }
  public function  setpswd_effective_date($pswd_effective_date )     { $this->pswd_effective_date  = $pswd_effective_date; }
  public function  setexpiry_period($expiry_period )                 { $this->expiry_period        = $expiry_period; }
  public function  sethint($hint )                                   { $this->hint                 = $hint; }
  public function  sethint_ans($hint_ans )                           { $this->hint_ans             = $hint_ans; }
  public function  seteffective_date($effective_date )               { $this->effective_date       = $effective_date; }
  public function  setexpiration_date($expiration_date )             { $this->expiration_date      = $expiration_date; }
  public function  setuser_status($user_status )                     { $this->user_status          = $user_status; }
  public function  setuser_status_date($user_status_date )           { $this->user_status_date     = $user_status_date; }
}
?>
