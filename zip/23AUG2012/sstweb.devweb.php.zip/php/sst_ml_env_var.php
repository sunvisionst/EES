<?php 

  //-----------------------------------------------------------------
  //-----------------ENVOIRNMENT VARIABLE ARE------------------------
  //-----------------------------------------------------------------
  putenv("SST_MLA_HOME=/opt3/dev4/sstweb/devweb/php/");
  putenv("SST_MLA_INSTALL=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/inbox/install");
  putenv("SST_MLA_DATA_INSTALL=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/inbox/install/data/");
  putenv("SST_MLA_DATA_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/refdb/datafiledir/");
  putenv("SST_MLA_MENU_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/refdb/menufiledir/");
  putenv("SST_MLA_INBOX_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/inbox/otdata/");
  putenv("SST_MLA_OUTBOX_DIR=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/outbox/");
  putenv("SST_DC_DATA_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/SGI/refdb/datafiledir/");
  putenv("SST_DC_INBOX_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/SGI/inbox/");
  putenv("SST_DC_OUTBOX_DIR=/opt3/dev4/sstweb/devweb/upload/sstmladc/SGI/outbox/");

  putenv("SST_MLA_FILTER_PATH=/opt3/dev4/sstweb/devweb/upload/custmla/SGI/");
  //-----------------------------------------------------------------
?>
