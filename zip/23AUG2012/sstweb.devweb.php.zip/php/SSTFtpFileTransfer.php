<?
  class SSTFtp
  {
    //public $ftp_source_ip; //FROM WHERE WE HAVE TO COPY
    //public $ftp_source_dir; //DIR FROM WHERE WE HAVE TO COPY
    public $ftp_dest_ip; //DESTINATION IP WHERE WE HAVE TO COPY
    public $ftp_dest_dir;//DESTINATION DIR WHERE WE HAVE TO COPY
    
    public $ftp_dirname;//THIS WILL USE FOR CAHNGE DIR OR CREATES NEW ONE

    public $ftp_usrname;
    public $ftp_usrpass;
    public $ftp_Con;//FTP CONNECTION OBJECT

    function SStFtp()
    {
      //$this->ftp_source_ip  = "";
      //$this->ftp_source_dir = "";
      $this->ftp_dest_ip    = "";
      $this->ftp_dest_dir   = "";

      $this->ftp_usrname    = "";
      $this->ftp_usrpass    = "";
      $this->this->ftp_Con        = "";

      $this->ftp_dirname    = "";
    }


    private function sst_connect_ftp( $inFtpIp ) 
    {
      $this->ftp_Con = ftp_connect($inFtpIp);
      return $this->ftp_Con;
    } 


    private function sst_ftp_login( $inFtpUsr, $inFtpPass ) 
    {
      return ftp_login($this->ftp_Con, $inFtpUsr, $inFtpPass ); 
    } 


    private function sst_ftp_pasv_mode() 
    {
      return ftp_pasv($this->ftp_Con, 1); 
    } 
     
    private function sst_ftp_create_dir() 
    {
      return ftp_mkdir( $this->ftp_Con, $this->ftp_dirname ); //RETURNS NEWLY CREATED DIR NAME OTHERWISE FALSE
    } 


    private function sst_ftp_change_dir() 
    {
      return ftp_chdir( $this->ftp_Con, $this->ftp_dirname ); //RETURNS TRUE OTHERWISE FALSE
    } 
    

    private function sst_ftp_getPwd() 
    {
      return ftp_pwd( $this->ftp_Con ); //RETURNS NAME OF CURRENT DIR OTHERWISE FALSE
    } 


    private function sst_ftp_getFileList() 
    {
      return ftp_nlist( $this->ftp_Con, $this->ftp_dirname ); //RETURNS ARRAY OF FILES OF CURRENT DIR OTHERWISE FALSE
    } 

   
    private function sst_ftp_uploadFile($inFileName, $inTransType) 
    {
      $lReturnValue = "";
      $fp           = "";
      try
      { 
        if( $inTransType !== null && $inTransType == "FRM_CLNT" ) 
          $fp = fopen($inFileName, 'r') or die("Failed To Open File !!!");
        else 
        if( $inTransType !== null && $inTransType == "TO_CLNT" ) 
          $fp = fopen($inFileName, 'w') or die("Failed To Open File !!!");

        //try to upload file
        if( $inTransType !== null && $inTransType == "FRM_CLNT" ) 
          $lReturnValue = ftp_fput($this->ftp_Con, $inFileName, $fp, FTP_ASCII); 
        else 
        if( $inTransType !== null && $inTransType == "TO_CLNT" ) 
          $lReturnValue = ftp_fget($this->ftp_Con, $fp, $inFileName, FTP_ASCII, 0);
      }
      catch(Exception $Ex)
      {
        echo $Ex->getMessage();
      }

      // close the connection and the file handler
      fclose($fp);
      return $lReturnValue;
    } 



    private function sst_ftp_close_Con() 
    {
      return ftp_close($this->ftp_Con); //CLOSE FTP CONNECTION
    } 



    ///////////////////////////////////////////////////////////////////////////
    /*
    *REC_SEND FUNCTION IS USED TO TRANS & RECIVES FILE FROM & TO A CLIENT. 
    *TRANS TYPE FLAG TELLS THE TRANSEFER TYPE, MEANS FILE COMING FROM CLIENT
    *OR FILE IS SENDING TO THE CLIENT.
    */
    ///////////////////////////////////////////////////////////////////////////

    public function recv_send_file($inTransType)
    {
      $lTransFileListArr = array();
      $lDestIp  = "";

      /* 
      if( $inTransType !== null && $inTransType == "FRM_CLNT" ) 
        $lDestIp = $this->ftp_dest_ip;
      else 
      if( $inTransType !== null && $inTransType == "TO_CLNT" ) 
        $lDestIp = $this->ftp_dest_ip;
      */       
   
      //-----------------------------------------------------------------
      //create connection
      if( $this->ftp_Con = $this->sst_connect_ftp($lDestIp) )
        echo "Connection Successfull !!";
      else   
      {
        echo "Connection Failed !!";
        break;
      }
      //-----------------------------------------------------------------



      //-----------------------------------------------------------------
      //Login to Server 
      if( $this->sst_ftp_login($this->ftp_usrname, $this->ftp_usrpass) )
        echo "Login Successfull !!";
      else   
      {
        echo "Login Failed !!";
        //CLOSE FTP CONNECTION
        //-----------------------------------------------------------------
        if( $this->sst_ftp_close_Con() ) 
          echo "Connection Closed Successfully";
        else
          echo "Failed To Closed Connection !!!";
        //-----------------------------------------------------------------
        break;
      }
      //-----------------------------------------------------------------



      //SET TO PASSIVE MODE
      //In passive mode, data connections 
      //are initiated by the client, rather than by the server. It may be needed if the client is behind firewall. 
      //-----------------------------------------------------------------
      if( $this->sst_ftp_pasv_mode() )
        echo "Passive Mode Open!!";
      else   
      {
        echo "Couldn't Open Passive Mode !!!";
        //CLOSE FTP CONNECTION
        //-----------------------------------------------------------------
        if( $this->sst_ftp_close_Con() ) 
          echo "Connection Closed Successfully";
        else
          echo "Failed To Closed Connection !!!";
        //-----------------------------------------------------------------
        break;
      }
      //-----------------------------------------------------------------


      //CHANGE DIR IF REQUIRED
      /*
      //-----------------------------------------------------------------
      if( $this->sst_ftp_change_dir() )
        echo "Dir Change Successfull !!!";
      else   
      {
        echo "Dir Change Failed !!!";
        break;
      }
      //-----------------------------------------------------------------
      */

  
      //CHANGE DIR IF REQUIRED
      //-----------------------------------------------------------------
      if( !( $lTransFileListArr = $this->sst_ftp_getFileList() ) )
      {
        echo "No File's Found !!!";

        //CLOSE FTP CONNECTION
        //-----------------------------------------------------------------
        if( $this->sst_ftp_close_Con() ) 
          echo "Connection Closed Successfully";
        else
          echo "Failed To Closed Connection !!!";
        //-----------------------------------------------------------------
        
        break;
      }
      else
      {
        echo "<br>FILE NAMEs---".$lTransFileListArr[0]."---".$lTransFileListArr[1];
      }
      //-----------------------------------------------------------------


       

      //-----------------------------------------------------------------
      if( $lTransFileListArr !== null && count($lTransFileListArr) > 0 )
      {
        for( $lRecNum = 0; $lRecNum < count( $lTransFileListArr ); $lRecNum++ )
        {
          if( $this->sst_ftp_uploadFile( $lTransFileListArr[$lRecNum], $inTransType ) )
            ;
          else   
          {
            ;//PREP ERROR FILE LIST
          }
        }
      }
      //-----------------------------------------------------------------

       //CLOSE FTP CONNECTION
      //-----------------------------------------------------------------
       if( $this->sst_ftp_close_Con() ) 
         echo "Connection Closed Successfully";
       else
         echo "Failed To Closed Connection !!!";
      //-----------------------------------------------------------------
      
    }//END OF FUNCTION REC_SEND_FILE
  }
?>
