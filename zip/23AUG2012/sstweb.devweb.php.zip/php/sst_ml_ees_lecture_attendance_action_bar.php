<?
   echo"<table border = \"0\" width = \"50%\"> ";
   echo"<tr>";
   $lCurrentPage = "sst_ml_ees_lecture_attendance_envelop.php?menu_option=eesFaculty&req_type=facAttnEntry&action=saveSubmit";
   echo"<td>";
   echo "<input  type =\"submit\" 
                 id   =\"save_submit\"  
                 name =\"save_submit\" 
                 onClick =\"{
                              javascript:form.action='$lCurrentPage'; 
                            }
                          \" 
                 value=\"Save Attendance\">";
   echo"</td>";

   echo"<td>";
   $lCurrentPage = "";
   $lCurrentPage ="sst_ml_ees_lecture_attendance_envelop.php?menu_option=eesFaculty&req_type=facAttnEntry&action=approveSubmit";
   echo "<input type=\"submit\" 
                id=\"approve_submit\" 
                name=\"approve_submit\" 
                onClick =\"{
                              javascript:form.action='$lCurrentPage'; 
                            }
                          \" 
                value=\"Approve Attendance\">";
   echo"</td>";
   echo"</tr>";
   echo"</table>"; 
?>
