<?


class GnUserAccessTabObj
{
  public $tab_rowid;
  public $org_id;
  public $appln_short_name;
  public $appln_user_id;
  public $role_type;
  public $user_area_id;
  public $user_emp_id;
  public $effective_date;
  public $expiration_date;





  public $org_id_ind;
  public $appln_short_name_ind;
  public $appln_user_id_ind;
  public $role_type_ind;
  public $user_area_id_ind;
  public $user_emp_id_ind;
  public $effective_date_ind;
  public $expiration_date_ind;


  public function __construct(){}


  public function GnUserAccessTabObj
  (
    $org_id,
    $appln_short_name,
    $appln_user_id,
    $role_type,
    $user_area_id,
    $user_emp_id,
    $effective_date,
    $expiration_date
  )
  {
     $this->org_id                  = $org_id;
     $this->appln_short_name        = $appln_short_name;
     $this->appln_user_id           = $appln_user_id;
     $this->role_type               = $role_type;
     $this->user_area_id            = $user_area_id;
     $this->user_emp_id             = $user_emp_id;
     $this->effective_date          = $effective_date;
     $this->expiration_date         = $expiration_date;
  }

  public function getorg_id()                    { return $this->org_id; }
  public function getappln_short_name()          { return $this->appln_short_name; }
  public function getappln_user_id()             { return $this->appln_user_id; }
  public function getrole_type()                 { return $this->role_type; }
  public function getuser_area_id()              { return $this->user_area_id; }
  public function getuser_emp_id()               { return $this->user_emp_id; }
  public function geteffective_date()            { return $this->effective_date; }
  public function getexpiration_date()           { return $this->expiration_date; }



  public function  setorg_id($org_id )                           { $this->org_id               = $org_id; }
  public function  setappln_short_name($appln_short_name )       { $this->appln_short_name     = $appln_short_name; }
  public function  setappln_user_id($appln_user_id )             { $this->appln_user_id        = $appln_user_id; }
  public function  setrole_type($role_type )                     { $this->role_type            = $role_type; }
  public function  setuser_area_id($user_area_id )               { $this->user_area_id         = $user_area_id; }
  public function  setuser_emp_id($user_emp_id )                 { $this->user_emp_id          = $user_emp_id; }
  public function  seteffective_date($effective_date )           { $this->effective_date       = $effective_date; }
  public function  setexpiration_date($expiration_date )         { $this->expiration_date      = $expiration_date; }
}

?>
