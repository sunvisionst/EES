<?
  echo "<td colspan = \"3\">";
  echo "<table border=\"0\" width =\"100%\">";
  echo "<tr bgcolor = \"darkred\">";

  echo "<td>";
  echo "<font color=\"white\" size=\"2\">";
  echo "Enterprise Solution";
  echo "</font>";
  echo "</td>";

  echo "<td>";
  echo "</td>";

  echo "<td align = \"right\">";
  echo "<font color=\"white\" size=\"2\">";

  $lLoggedEmp = $lHrEmployeeTabObjGlobal->employee_f_name."(".$lHrEmployeeTabObjGlobal->employee_id.")";

  echo "Welcome ".$lLoggedEmp;
  echo "</font>";
  echo "</td>";

  echo "<td width = \"1%\">";
  echo "</td>";
  
  if(!isset($_SESSION['lSessionId']))
   ;
  else
  {
    echo "<td name=\"login_td\" id=\"login_td\" align=\"right\" width=\"5%\">"; 
    echo "<input type = \"hidden\" id = \"action_logout\" name = \"action_logout\" value = \"\">";
    echo "<a href=\"index.php\" onClick = \"document.getElementById('action_logout').value='logout';\">";
    echo "<font color = \"white\">Logout</font></a>";
    echo "</td>";
  }
  

  echo "</tr>";
  echo "</table>";
  echo "</td>";

?>
