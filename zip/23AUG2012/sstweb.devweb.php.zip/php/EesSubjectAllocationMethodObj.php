<?
   require_once("sst_ml_filter_record.php");
   require_once("EesSubjectAllocationTabObj.php");

   class EesSubjectAllocationMethodObj
   {
     //--------------------------------------------------------------------------------------------------
     public  $lSubjectAllocationFileName  = null;
     public  $lTodayDate                 = "";
     //public  $lFilteredFileName        = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilterCriteriaValue1      = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition1         = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue2      = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition2         = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     //--------------------------------------------------------------------------------------------------




      /*
      FUNCTION TO GET SUBJECT ALLOCATION
      TAB OBJ ARR.
      */
       public function gtSubjectAllocationTabObjArr()
       {
         $lSubjectAllocationTabObjArr  = array();
         //FILTER OBJECT    
         $lSSTFilter = new SSTFilter();
         //-----------------------------------------------------------------------------
         //READ FILE 
         //-----------------------------------------------------------------------------

         //GETTING FILE SOURCE
         //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/refdb/datafiledir/".$this->lSubjectAllocationFileName;
         //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/refdb/datafiledir/".$this->lSubjectAllocationFileName; 
         $lFileNamePath  = $_SESSION['SST_MLA_DATA_DIR'];
         $lFileNamePath .= $this->lSubjectAllocationFileName;


         //FILTER PART START
         $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/"; //ASSIGN FILE PATH             
         $lSSTFilter->lFilteredFileName     = $this->lSubjectAllocationFileName; //ASSIGN FILE NAME TO FILTER
         $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1;//ASSIGN CRITERIA VALUE TO FILTER
         $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
         $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2;//ASSIGN CRITERIA VALUE TO FILTER
         $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED

         if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
         {
           //GETTING FILTERED RECORD ARR
           $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          

           if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
           {
             for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
             {
               //PREP TABOBJ OBJECT
               $lEesSubjectAllocationTabObj     = new EesSubjectAllocationTabObj();
               $lFieldArr             = explode( ",", $lFilteredRecordArr[$lRecNum] );
   
               $lEesSubjectAllocationTabObj->org_id              =            $lFieldArr[0];
               $lEesSubjectAllocationTabObj->subject_code        =            $lFieldArr[1];
               $lEesSubjectAllocationTabObj->employee_id         =            $lFieldArr[2];
               $lEesSubjectAllocationTabObj->class_id            =            $lFieldArr[3];
               $lEesSubjectAllocationTabObj->class_num           =            $lFieldArr[4];
               $lEesSubjectAllocationTabObj->class_std           =            $lFieldArr[5];
               $lEesSubjectAllocationTabObj->class_section       =            $lFieldArr[6];
               $lEesSubjectAllocationTabObj->course_id           =            $lFieldArr[7];
               $lEesSubjectAllocationTabObj->course_term         =            $lFieldArr[8];
               $lEesSubjectAllocationTabObj->course_stream       =            $lFieldArr[9];
               $lEesSubjectAllocationTabObj->lp_version          =            $lFieldArr[10];
               $lEesSubjectAllocationTabObj->load_point          =            $lFieldArr[11];
               $lEesSubjectAllocationTabObj->planned_lect_num    =            $lFieldArr[12];
               $lEesSubjectAllocationTabObj->choice_ind          =            $lFieldArr[13];
               $lEesSubjectAllocationTabObj->approve_sts         =            $lFieldArr[14];
               $lEesSubjectAllocationTabObj->short_subject_code  =            $lFieldArr[15];
   
               $lSubjectAllocationTabObjArr[$lRecNum-1] = $lEesSubjectAllocationTabObj;
             }
           }
         }
     
         if( $lSubjectAllocationTabObjArr !== null && count($lSubjectAllocationTabObjArr) > 0 )
             return $lSubjectAllocationTabObjArr;
            else
             return null;
       }
}
?>
