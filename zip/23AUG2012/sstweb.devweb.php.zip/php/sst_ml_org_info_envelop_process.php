<?
  echo "<table id=\"\" name=\"\" border=\"0\" width=\"100%\">"; 
  echo "<tr>";


  echo "<td align=\"center\" colspan=\"0\">";
  echo "APPLY <font color=\"darkred\">IT POWER</font> IN YOUR BUSINESS";
  echo "</td>";

  echo "</tr>";


  echo "<tr>";

  echo "<td align=\"right\" >";
  echo "<table id=\"sst_msg_tab\" name=\"sst_msg_tab\" border=\"0\" width=\"100%\">"; 
  echo "<tr>";

  echo "<td> <font color=\"darkred\" align=\"left\" >";
  echo "<br>MESSAGE FROM SUNVISION  -></font>";
  echo "  <b>FAST INTO FUTURE</b> <br><p>Information Technology has intruded in everybody's dailylife.Earlier businesses were easy to execute without IT because of less data to maintain.Today everybody is facing big competition in market. They are bound to generate more and more business than ever which raises a genuine issue of maintaining huge amount of data and paper work.Applying 100 times more manpower will not resolve issue, because human body has the maximum capacitywhich can not be increased. Businesses running on old tradional pattern i.e. without IT POWER, shall definitely go out of market. ADOPT IT FOR BETTERMENT OR LOSE BUSINESS.</p>";
  echo "</td>";

  echo "</tr>";
  echo "</table>";
  echo "</td>";
  echo "</tr>";
  echo "</table>";
?>
