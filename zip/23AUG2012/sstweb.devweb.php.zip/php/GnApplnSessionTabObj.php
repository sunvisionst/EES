<?


class GnApplnSessionTabObj
{
  public $tab_rowid;
  public $org_id;
  public $session_id;
  public $seq_num;
  public $appln_short_name;
  public $user_name;
  public $user_id;
  public $user_emp_id;
  public $pswd;
  public $login_time;
  public $login_date;
  public $logout_time;
  public $logout_date;
  public $session_status;
  public $role_type;
  public $role_weight;
  public $schema_name;
  public $server_ip_v4;
  public $server_ip_v6;
  public $server_country;
  public $server_city;
  public $server_name;
  public $server_port;
  public $server_scheme;
  public $server_char_encoding;
  public $server_os_name;
  public $server_os_user_name;
  public $process_id;
  public $remote_ip_v4;
  public $remote_ip_v6;
  public $remote_country;
  public $remote_city;
  public $remote_name;
  public $remote_os_name;
  public $remote_os_user_name;
  public $remote_browser;
  public $req_session_id;
  public $default_lab;
  public $login_lab;
  public $lnf_template_id;





  public $org_id_ind;
  public $session_id_ind;
  public $seq_num_ind;
  public $appln_short_name_ind;
  public $user_name_ind;
  public $user_id_ind;
  public $user_emp_id_ind;
  public $pswd_ind;
  public $login_time_ind;
  public $login_date_ind;
  public $logout_time_ind;
  public $logout_date_ind;
  public $session_status_ind;
  public $role_type_ind;
  public $role_weight_ind;
  public $schema_name_ind;
  public $server_ip_v4_ind;
  public $server_ip_v6_ind;
  public $server_country_ind;
  public $server_city_ind;
  public $server_name_ind;
  public $server_port_ind;
  public $server_scheme_ind;
  public $server_char_encoding_ind;
  public $server_os_name_ind;
  public $server_os_user_name_ind;
  public $process_id_ind;
  public $remote_ip_v4_ind;
  public $remote_ip_v6_ind;
  public $remote_country_ind;
  public $remote_city_ind;
  public $remote_name_ind;
  public $remote_os_name_ind;
  public $remote_os_user_name_ind;
  public $remote_browser_ind;
  public $req_session_id_ind;
  public $default_lab_ind;
  public $login_lab_ind;
  public $lnf_template_id_ind;


  public function __construct(){}


  public function GnApplnSessionTabObj
  (
    $org_id,
    $session_id,
    $seq_num,
    $appln_short_name,
    $user_name,
    $user_id,
    $user_emp_id,
    $pswd,
    $login_time,
    $login_date,
    $logout_time,
    $logout_date,
    $session_status,
    $role_type,
    $role_weight,
    $schema_name,
    $server_ip_v4,
    $server_ip_v6,
    $server_country,
    $server_city,
    $server_name,
    $server_port,
    $server_scheme,
    $server_char_encoding,
    $server_os_name,
    $server_os_user_name,
    $process_id,
    $remote_ip_v4,
    $remote_ip_v6,
    $remote_country,
    $remote_city,
    $remote_name,
    $remote_os_name,
    $remote_os_user_name,
    $remote_browser,
    $req_session_id,
    $default_lab,
    $login_lab,
    $lnf_template_id
  )
  {
     $this->org_id                           = $org_id;
     $this->session_id                       = $session_id;
     $this->seq_num                          = $seq_num;
     $this->appln_short_name                 = $appln_short_name;
     $this->user_name                        = $user_name;
     $this->user_id                          = $user_id;
     $this->user_emp_id                      = $user_emp_id;
     $this->pswd                             = $pswd;
     $this->login_time                       = $login_time;
     $this->login_date                       = $login_date;
     $this->logout_time                      = $logout_time;
     $this->logout_date                      = $logout_date;
     $this->session_status                   = $session_status;
     $this->role_type                        = $role_type;
     $this->role_weight                      = $role_weight;
     $this->schema_name                      = $schema_name;
     $this->server_ip_v4                     = $server_ip_v4;
     $this->server_ip_v6                     = $server_ip_v6;
     $this->server_country                   = $server_country;
     $this->server_city                      = $server_city;
     $this->server_name                      = $server_name;
     $this->server_port                      = $server_port;
     $this->server_scheme                    = $server_scheme;
     $this->server_char_encoding             = $server_char_encoding;
     $this->server_os_name                   = $server_os_name;
     $this->server_os_user_name              = $server_os_user_name;
     $this->process_id                       = $process_id;
     $this->remote_ip_v4                     = $remote_ip_v4;
     $this->remote_ip_v6                     = $remote_ip_v6;
     $this->remote_country                   = $remote_country;
     $this->remote_city                      = $remote_city;
     $this->remote_name                      = $remote_name;
     $this->remote_os_name                   = $remote_os_name;
     $this->remote_os_user_name              = $remote_os_user_name;
     $this->remote_browser                   = $remote_browser;
     $this->req_session_id                   = $req_session_id;
     $this->default_lab                      = $default_lab;
     $this->login_lab                        = $login_lab;
     $this->lnf_template_id                  = $lnf_template_id;
  }

  public function getorg_id()                         { return $this->org_id; }
  public function getsession_id()                     { return $this->session_id; }
  public function getseq_num()                        { return $this->seq_num; }
  public function getappln_short_name()               { return $this->appln_short_name; }
  public function getuser_name()                      { return $this->user_name; }
  public function getuser_id()                        { return $this->user_id; }
  public function getuser_emp_id()                    { return $this->user_emp_id; }
  public function getpswd()                           { return $this->pswd; }
  public function getlogin_time()                     { return $this->login_time; }
  public function getlogin_date()                     { return $this->login_date; }
  public function getlogout_time()                    { return $this->logout_time; }
  public function getlogout_date()                    { return $this->logout_date; }
  public function getsession_status()                 { return $this->session_status; }
  public function getrole_type()                      { return $this->role_type; }
  public function getrole_weight()                    { return $this->role_weight; }
  public function getschema_name()                    { return $this->schema_name; }
  public function getserver_ip_v4()                   { return $this->server_ip_v4; }
  public function getserver_ip_v6()                   { return $this->server_ip_v6; }
  public function getserver_country()                 { return $this->server_country; }
  public function getserver_city()                    { return $this->server_city; }
  public function getserver_name()                    { return $this->server_name; }
  public function getserver_port()                    { return $this->server_port; }
  public function getserver_scheme()                  { return $this->server_scheme; }
  public function getserver_char_encoding()           { return $this->server_char_encoding; }
  public function getserver_os_name()                 { return $this->server_os_name; }
  public function getserver_os_user_name()            { return $this->server_os_user_name; }
  public function getprocess_id()                     { return $this->process_id; }
  public function getremote_ip_v4()                   { return $this->remote_ip_v4; }
  public function getremote_ip_v6()                   { return $this->remote_ip_v6; }
  public function getremote_country()                 { return $this->remote_country; }
  public function getremote_city()                    { return $this->remote_city; }
  public function getremote_name()                    { return $this->remote_name; }
  public function getremote_os_name()                 { return $this->remote_os_name; }
  public function getremote_os_user_name()            { return $this->remote_os_user_name; }
  public function getremote_browser()                 { return $this->remote_browser; }
  public function getreq_session_id()                 { return $this->req_session_id; }
  public function getdefault_lab()                    { return $this->default_lab; }
  public function getlogin_lab()                      { return $this->login_lab; }
  public function getlnf_template_id()                { return $this->lnf_template_id; }



  public function setorg_id($org_id )                               { $this->org_id               = $org_id; }
  public function setsession_id($session_id )                    { $this->session_id           = $session_id; }
  public function setseq_num($seq_num )                          { $this->seq_num              = $seq_num; }
  public function setappln_short_name($appln_short_name )           { $this->appln_short_name     = $appln_short_name; }
  public function setuser_name($user_name )                         { $this->user_name            = $user_name; }
  public function setuser_id($user_id )                             { $this->user_id              = $user_id; }
  public function setuser_emp_id($user_emp_id )                     { $this->user_emp_id          = $user_emp_id; }
  public function setpswd($pswd )                                   { $this->pswd                 = $pswd; }
  public function setlogin_time($login_time )                       { $this->login_time           = $login_time; }
  public function setlogin_date($login_date )                       { $this->login_date           = $login_date; }
  public function setlogout_time($logout_time )                     { $this->logout_time          = $logout_time; }
  public function setlogout_date($logout_date )                     { $this->logout_date          = $logout_date; }
  public function setsession_status($session_status )               { $this->session_status       = $session_status; }
  public function setrole_type($role_type )                         { $this->role_type            = $role_type; }
  public function setrole_weight($role_weight )                  { $this->role_weight          = $role_weight; }
  public function setschema_name($schema_name )                     { $this->schema_name          = $schema_name; }
  public function setserver_ip_v4($server_ip_v4 )                   { $this->server_ip_v4         = $server_ip_v4; }
  public function setserver_ip_v6($server_ip_v6 )                   { $this->server_ip_v6         = $server_ip_v6; }
  public function setserver_country($server_country )               { $this->server_country       = $server_country; }
  public function setserver_city($server_city )                     { $this->server_city          = $server_city; }
  public function setserver_name($server_name )                     { $this->server_name          = $server_name; }
  public function setserver_port($server_port )                     { $this->server_port          = $server_port; }
  public function setserver_scheme($server_scheme )                 { $this->server_scheme        = $server_scheme; }
  public function setserver_char_encoding($server_char_encoding )   { $this->server_char_encoding = $server_char_encoding; }
  public function setserver_os_name($server_os_name )               { $this->server_os_name       = $server_os_name; }
  public function setserver_os_user_name($server_os_user_name )     { $this->server_os_user_name  = $server_os_user_name; }
  public function setprocess_id($process_id )                       { $this->process_id           = $process_id; }
  public function setremote_ip_v4($remote_ip_v4 )                   { $this->remote_ip_v4         = $remote_ip_v4; }
  public function setremote_ip_v6($remote_ip_v6 )                   { $this->remote_ip_v6         = $remote_ip_v6; }
  public function setremote_country($remote_country )               { $this->remote_country       = $remote_country; }
  public function setremote_city($remote_city )                     { $this->remote_city          = $remote_city; }
  public function setremote_name($remote_name )                     { $this->remote_name          = $remote_name; }
  public function setremote_os_name($remote_os_name )               { $this->remote_os_name       = $remote_os_name; }
  public function setremote_os_user_name($remote_os_user_name )     { $this->remote_os_user_name  = $remote_os_user_name; }
  public function setremote_browser($remote_browser )               { $this->remote_browser       = $remote_browser; }
  public function setreq_session_id($req_session_id )               { $this->req_session_id       = $req_session_id; }
  public function setdefault_lab($default_lab )                     { $this->default_lab          = $default_lab; }
  public function setlogin_lab($login_lab )                         { $this->login_lab            = $login_lab; }
  public function setlnf_template_id($lnf_template_id )             { $this->lnf_template_id      = $lnf_template_id; }
}
?>
