<?
  require_once("EesTimeTableModelTabObj.php");
  require_once("sst_ml_filter_record.php");


  class EesTimeTableModelMethodObj
  {
     //--------------------------------------------------------------------------------------------------
     public  $lCourseId             = "";
     public  $lTodayDate            = "";
     public  $lRecordSize           = 0;
     public  $lFilteredFileName             = null; //ASSIGN FILE NAME TO FILTER
     public  $lFilterCriteriaValue1         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition1            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue2         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition2            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue3         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition3            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     public  $lFilterCriteriaValue4         = null; //ASSIGN CRITERIA VALUE TO FILTER
     public  $lFilteredPosition4            = null; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
     //--------------------------------------------------------------------------------------------------




    public function gtEesTimeTableModelRecByCriteria()
    {
       $lEesTimeTableModelTabObjArr = array();
       $lSSTFilter                  = new SSTFilter();

       //FILTER PART START
       $lSSTFilter->lFilteredFileRelPath  = "/refdb/datafiledir/";//ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilteredFileName     = $this->lFilteredFileName; //ASSIGN FILE NAME TO FILTER
       $lSSTFilter->lFilterCriteriaValue1 = $this->lFilterCriteriaValue1; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition1    = $this->lFilteredPosition1; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue2 = $this->lFilterCriteriaValue2; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition2    = $this->lFilteredPosition2; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue3 = $this->lFilterCriteriaValue3; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition3    = $this->lFilteredPosition3; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED
       $lSSTFilter->lFilterCriteriaValue4 = $this->lFilterCriteriaValue4; //ASSIGN CRITERIA VALUE TO FILTER
       $lSSTFilter->lFilteredPosition4    = $this->lFilteredPosition4; //POSTION VALUE ON WHICH FILTER VALUE IS CHECKED


       //GETTING FILTERED RECORD ARR
       $lFilteredRecordArr = $lSSTFilter->filter_record(); //CALLING FILTER FUNCTION                          
       if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
       {
         for( $lRecNum = 1; $lRecNum < count($lFilteredRecordArr); $lRecNum++ )
         {
            //PREP TABOBJ OBJECT
            $lEesTimeTableModelTabObj     = new EesTimeTableModelTabObj();
            $lFieldArr  = explode( ",", $lFilteredRecordArr[$lRecNum] );  

            $lEesTimeTableModelTabObj->org_id                =               $lFieldArr[0];
            $lEesTimeTableModelTabObj->week_day              =               $lFieldArr[1];
            $lEesTimeTableModelTabObj->period_num            =               $lFieldArr[2];
            $lEesTimeTableModelTabObj->class_id              =               $lFieldArr[3];
            $lEesTimeTableModelTabObj->timetable_id          =               $lFieldArr[4];
            $lEesTimeTableModelTabObj->timetable_sts         =               $lFieldArr[5];
            $lEesTimeTableModelTabObj->timetable_sts_date    =               $lFieldArr[6];
            $lEesTimeTableModelTabObj->subject_code          =               $lFieldArr[7];
            $lEesTimeTableModelTabObj->class_num             =               $lFieldArr[8];
            $lEesTimeTableModelTabObj->class_std             =               $lFieldArr[9];
            $lEesTimeTableModelTabObj->class_section         =               $lFieldArr[10];
            $lEesTimeTableModelTabObj->course_id             =               $lFieldArr[11];
            $lEesTimeTableModelTabObj->course_term           =               $lFieldArr[12];
            $lEesTimeTableModelTabObj->course_stream         =               $lFieldArr[13];
            $lEesTimeTableModelTabObj->employee_id           =               $lFieldArr[14];
            $lEesTimeTableModelTabObj->add_faculty_1         =               $lFieldArr[15];
            $lEesTimeTableModelTabObj->add_faculty_2         =               $lFieldArr[16];
            $lEesTimeTableModelTabObj->add_faculty_3         =               $lFieldArr[17];
            $lEesTimeTableModelTabObj->building_id           =               $lFieldArr[18];
            $lEesTimeTableModelTabObj->room_num              =               $lFieldArr[19];
            $lEesTimeTableModelTabObj->short_subject_code    =               $lFieldArr[20];
 
             //PUT VALUE IN ARRAY
             $lEesTimeTableModelTabObjArr[$lRecNum-1] = $lEesTimeTableModelTabObj;
         }
       }
     
       if( $lEesTimeTableModelTabObjArr !== null && count($lEesTimeTableModelTabObjArr) > 0 )
         return $lEesTimeTableModelTabObjArr;
       else
         return null;
    }
  }
?>
