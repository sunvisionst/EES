<?
   echo "<script language=\"javascript\" src=\"../js/gn_loginEnvVar.js\"> </script>";
   echo "<script language=\"javascript\" src=\"../js/gn_confMultiNotNullById.js\"> </script>";
?>
<?

{
  $lActionSubmit        = "";
  $lRedirectPage        = "";
  $lGnUserTabObjArr     = array();
  $lHrEmployeeTabObj    = new HrEmployeeTabObj();
  $lHrEmployeeTabObjArr = array();

  $lHrEmployeeMethodObj->lEmployeeFileName = "sst_".$lOrgId."_hr_employee_ext.dat"; 

  if ( $lGnUserTabObj->user_id !== null && $lGnUserTabObj->user_id == 'admin' )
  {
    $lGnUserMethodObj->lUserFileName         = "sst_".$lOrgId."_gn_user_ext.dat";
    $lGnUserAccessMethodObj->lUserFileName   = "sst_".$lOrgId."_gn_user_access_ext.dat";
  }


  if( !isset($_POST['action_submit']) )
    ;
  else
  {
    $lActionSubmit = $_POST['action_submit']; 
  }


 
  if( $lActionSubmit !== null && $lActionSubmit == 'create' ) 
  {
    if( $lGnUserMethodObj->createGnUser() < 0 )
      echo "User Genration Failed !!!";
    if( $lGnUserAccessMethodObj->createGnUserAccess() < 0 )
      echo "User Genration Failed !!!";
    if( $lHrEmployeeMethodObj->createHrEmployee() < 0 )
      echo "Employee Record Generation Failed !!!";
  }
  else
  if( $lActionSubmit !== null && $lActionSubmit == 'update' ) 
  {
    if( $lHrEmployeeMethodObj->updateHrEmployee($lOrgId, $lHrEmployeeTabObjGlobal->employee_id) < 0 )
      echo "Employee Record Updation Failed !!!";



  }
  else
  if( $lActionSubmit !== null && $lActionSubmit == 'delete' ) 
  {
    $lSelUserId = ""; 
    $lSelEmpId  = ""; 

    if( !isset($_GET['sel_user_id']) )
      ;
    else
    {
      $lSelUserId = $_GET['sel_user_id']; 
      if( $lGnUserMethodObj->deleteGnUser($lOrgId, $lSelUserId) < 0 )
        echo "User Deletion Failed !!!";
      if( $lGnUserAccessMethodObj->deleteGnUserAccess($lOrgId, $lSelUserId ) < 0 )
        echo "User Deletion Failed !!!";
    }

    if( !isset($_GET['sel_employee_id']) )
      ;
    else
    {
      $lSelEmpId = $_GET['sel_employee_id']; 
      if( $lHrEmployeeMethodObj->deleteHrEmployee($lOrgId, $lSelEmpId) < 0 )
        echo "Employee Record Deletion Failed !!!";
    }
  }
  
  //----------------------------------------------------------------------------
  $lHrEmployeeMethodObj->lFilterCriteriaValue1 = $lOrgId;
  $lHrEmployeeMethodObj->lFilteredPosition1    = 0; 
  $lHrEmployeeMethodObj->lFilterCriteriaValue2 = $lHrEmployeeTabObjGlobal->employee_id;
  $lHrEmployeeMethodObj->lFilteredPosition2    = 1; 

  $lHrEmployeeTabObjArr = $lHrEmployeeMethodObj->gtHrEmployeeTabObjArr();
  if( $lHrEmployeeTabObjArr !== null && count( $lHrEmployeeTabObjArr ) > 0 )
     $lHrEmployeeTabObj = $lHrEmployeeTabObjArr[0];
  //----------------------------------------------------------------------------
   
  echo "<table border = \"0\" width = \"100%\">";

  echo "<tr>";
  echo "<td>";

  echo "<table border = \"0\" width = \"100%\">";
  echo "<tr>";
  
  if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type == 'admin' )
  {
    echo "<td align = \"left\">";
    echo "<fieldset>"; 
    echo "<legend><font color = \"white\" >User Managment</font></legend>";
    include("sst_ml_user_ac_include_single.php");
    echo "</fieldset>"; 
    echo "</td>";
  
    echo "<td width = \"1%\">";
    echo "</td>";
     //---------------------------------------------------------------------
     /*
     THIS FUNCTION IS USED TO
     GET ALL THE PREV EXISTS USERS.
     */ 
     $lGnUserMethodObj->lFilterCriteriaValue1 = $lOrgId;
     $lGnUserMethodObj->lFilteredPosition1    = 0;

     $lGnUserTabObjArr = $lGnUserMethodObj->gtGnUserTabObjArr();
     //---------------------------------------------------------------------

     echo "<td align = \"left\" id =\"lable_user_list\" name =\"User Name\" abbr =\"User Name Form List &\">";
     echo "<fieldset>"; 
     echo "<legend><font color = \"white\" >User Listing</font></legend>";
     if( $lGnUserTabObjArr !== null && count($lGnUserTabObjArr) > 0 )
     { 
       echo "<SELECT name = \"user_list\"  id = \"user_list\" size = \"10\" width = \"100%\">";
       for( $lRecNum = 0; $lRecNum < count($lGnUserTabObjArr); $lRecNum++ )
       {
         $lGnUserTabObjTmp = new GnUserTabObj();
         $lGnUserTabObjTmp = $lGnUserTabObjArr[$lRecNum];

         echo "<OPTION value = \"$lGnUserTabObjTmp->user_id,$lGnUserTabObjTmp->user_emp_id\">";
         echo "$lGnUserTabObjTmp->user_id  $lGnUserTabObjTmp->user_name  $lGnUserTabObjTmp->user_emp_id</OPTION>";
       }
       echo "</SELECT>";
     }
     echo "</fieldset>"; 
     echo "</td>";
  }
  else
  {
    echo "<td align = \"center\">";
    echo "<fieldset>"; 
    echo "<legend><font color = \"white\" >Employee Information</font></legend>";
    include("sst_ml_user_ac_include_single.php");
    echo "</fieldset>"; 
    echo "</td>";
  } 
     
  echo "</tr>";
  echo "</table>";

  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  echo "<fieldset>"; 
  echo "<legend><font color = \"white\" >Action</font></legend>";
  require_once("sst_ml_user_ac_action_bar.php");
  echo "</fieldset>"; 
  echo "</td>";
  echo "</tr>";

  echo "</table>";
}
?>
