<?
  echo "<table id=\"\" name=\"\" border=\"0\" width=\"100%\">";
  echo "<tr>";

  echo "<td align=\"center\">";
      //include("");                          
  echo "</td>";

  echo "</tr>";
  echo "</table>";
?>
~                                                                                                                               
~           
