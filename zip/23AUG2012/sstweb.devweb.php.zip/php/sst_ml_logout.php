<?php
     session_start();
     session_unset();
     session_destroy();

     //header('Location : index.php');
     echo "<META HTTP-EQUIV=\"refresh\" content=\"2; URL=index.php\"> ";
?>
