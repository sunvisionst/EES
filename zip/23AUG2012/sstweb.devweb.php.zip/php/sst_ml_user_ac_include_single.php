<?
  {
   echo "<table border = \"0\" width = \"80%\">";


   //-----------------------------------------------------------------------------------------
   echo "<input type  = \"hidden\"
                id    = \"org_id\" 
                name  = \"org_id\" 
                value = \"$lOrgId\" 
         />";

   echo "<input type  = \"hidden\"
                id    = \"appln_short_name\" 
                name  = \"appln_short_name\" 
                value = \"MLA\" 
         />";
   //-----------------------------------------------------------------------------------------

   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type == 'admin' )
   {
     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<input type  = \"hidden\"
                  id    = \"parent_id\" 
                  name  = \"parent_id\" 
                  value = \"$lHrEmployeeTabObj->employee_id\" 
           />";
     echo "<td>";
     echo "User Id";
     echo "</td>";

     echo "<td id =\"lable_user_id\" name =\"User Id\" abbr =\"User Id\">";
     echo "<input type = \"textbox\"
                  id   = \"user_id\" 
                  name = \"user_id\" 
           />";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";

     echo "<td>";
     echo "Password";
     echo "</td>";

     echo "<td id =\"lable_password\" name =\"Password\" abbr =\"Password\">";
     echo "<input type = \"password\"
                  id   = \"password\" 
                  name = \"password\" 
           />";
     echo "</td>";

     echo "</tr>";
     //-----------------------------------------------------------------------------------------


     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Re-Type Password";
     echo "</td>";

     echo "<td id =\"lable_re_password\" name =\"Re-Type Password\" abbr =\"Re-Type Password\">";
     echo "<input type = \"password\"
                  id   = \"re_password\" 
                  name = \"re_password\" 
           />";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Role";
     echo "</td>";

     echo "<td id =\"lable_user_role\" name =\"User Role\" abbr =\"User Role\">";
     echo "<input type = \"textbox\"
                  id   = \"user_role\" 
                  name = \"user_role\" 
           />";

     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------
   }

  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "Employee Id";
   echo "</td>";

   echo "<td id =\"lable_employee_id\" name =\"Employee Id\" abbr =\"Employee Id\">";
   echo "<input type = \"textbox\"
                id   = \"employee_id\" 
                name = \"employee_id\""; 
   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type != 'admin' )
   {
       echo " value = \"$lHrEmployeeTabObj->employee_id\""; 
       echo " READONLY";
   } 
   echo "         />";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------

  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "Initial";
   echo "</td>";

   echo "<td id =\"lable_initial\" name =\"Initial\" abbr =\"Initial\">";
   echo "    <SELECT id = 'initial' name = 'initial'>";
   echo "      <Script language = \"JavaScript\">";
               include("../cache/SGI/gn_nameinit.js");
   echo "      </Script>";
   echo "    </SELECT>";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------


  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "First Name";
   echo "</td>";

   echo "<td id =\"lable_first_name\" name =\"First Name\" abbr =\"First Name\">";
   echo "<input type = \"textbox\"
                id   = \"first_name\" 
                name = \"first_name\"";
   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type != 'admin' )
       echo " value = \"$lHrEmployeeTabObj->employee_f_name\""; 
   echo "/>";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------


  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "Middle Name";
   echo "</td>";

   echo "<td id =\"lable_middle_name\" name =\"Middle Name\" abbr =\"Middle Name\">";
   echo "<input type = \"textbox\"
                id   = \"middle_name\" 
                name = \"middle_name\""; 
   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type != 'admin' )
       echo " value = \"$lHrEmployeeTabObj->employee_m_name\""; 
   echo "/>";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------




  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "Last Name";
   echo "</td>";

   echo "<td id =\"lable_last_name\" name =\"Last Name\" abbr =\"Last Name\">";
   echo "<input type = \"textbox\"
                id   = \"last_name\" 
                name = \"last_name\""; 
   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type != 'admin' )
       echo " value = \"$lHrEmployeeTabObj->employee_l_name\""; 
   echo "/>";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------


  //-----------------------------------------------------------------------------------------
   echo "<tr>";
   echo "<td>";
   echo "Department";
   echo "</td>";

   echo "<td id =\"lable_dept_id\" name =\"Department Id\" abbr =\"Department Id\">";
   echo "<input type = \"textbox\"
                id   = \"dept_id\" 
                name = \"dept_id\""; 
   if( $lHrEmployeeTabObj->dept_id !== null )
   echo "value = \"$lHrEmployeeTabObj->dept_id\""; 
   echo "/>";
   echo "</td>";
   echo "</tr>";
  //-----------------------------------------------------------------------------------------

  //-----------------------------------------------------------------------------------------
   if ( $lGnUserTabObj->role_type !== null && $lGnUserTabObj->role_type != 'admin' )
   {
     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Employee Short Name";
     echo "</td>";

     echo "<td id =\"lable_short_name\" name =\"Short Name\" abbr =\"Short Name\">";
     echo "<input type = \"textbox\"
                  id   = \"short_name\" 
                  name = \"short_name\""; 
     if( $lHrEmployeeTabObj->employee_short_name !== null )
     echo "value = \"$lHrEmployeeTabObj->employee_short_name\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------


     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Position Id";
     echo "</td>";

     echo "<td id =\"lable_position_id\" name =\"Position\" abbr =\"Position\">";
     echo "<input type = \"textbox\"
                  id   = \"position_id\" 
                  name = \"position_id\""; 
     if( $lHrEmployeeTabObj->position_id !== null )
     echo "value = \"$lHrEmployeeTabObj->position_id\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------


     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Level Id";
     echo "</td>";

     echo "<td id =\"lable_level_id\" name =\"Level\" abbr =\"Level\">";
     echo "<input type = \"textbox\"
                  id   = \"level_id\" 
                  name = \"level_id\""; 
     if( $lHrEmployeeTabObj->level_id !== null )
     echo "value = \"$lHrEmployeeTabObj->level_id\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Designation";
     echo "</td>";

     echo "<td id =\"lable_designation\" name =\"Designation\" abbr =\"Designation\">";
     echo "<input type = \"textbox\"
                  id   = \"designation\" 
                  name = \"designation\""; 
     if( $lHrEmployeeTabObj->designation !== null )
     echo "value = \"$lHrEmployeeTabObj->designation\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Date Of Join";
     echo "</td>";

     echo "<td id =\"lable_doj\" name =\"Date Of Join\" abbr =\"Date Of Join\">";
     echo "<input type = \"textbox\"
                  id   = \"doj\" 
                  name = \"doj\""; 
     if( $lHrEmployeeTabObj->doj !== null )
     echo "value = \"$lHrEmployeeTabObj->doj\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Contact No";
     echo "</td>";

     echo "<td id =\"lable_phone\" name =\"Contact No\" abbr =\"Contact No\">";
     echo "<input type = \"textbox\"
                  id   = \"phone\" 
                  name = \"phone\""; 
     if( $lHrEmployeeTabObj->phone !== null )
     echo "value = \"$lHrEmployeeTabObj->phone\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Address";
     echo "</td>";

     echo "<td id =\"lable_address\" name =\"Address\" abbr =\"Address\">";
     echo "<input type = \"textbox\"
                  id   = \"address\" 
                  name = \"address\""; 
     if( $lHrEmployeeTabObj->p_address_1 !== null )
     echo "value = \"$lHrEmployeeTabObj->p_address_1\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "City";
     echo "</td>";

     echo "<td id =\"lable_city\" name =\"City\" abbr =\"City\">";
     echo "<input type = \"textbox\"
                  id   = \"city\" 
                  name = \"city\""; 
     if( $lHrEmployeeTabObj->p_city !== null )
     echo "value = \"$lHrEmployeeTabObj->p_city\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "State";
     echo "</td>";

     echo "<td id =\"lable_state\" name =\"State\" abbr =\"State\">";
     echo "<input type = \"textbox\"
                  id   = \"state\" 
                  name = \"state\""; 
     if( $lHrEmployeeTabObj->p_state !== null )
     echo "value = \"$lHrEmployeeTabObj->p_state\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Country";
     echo "</td>";

     echo "<td id =\"lable_country\" name =\"Country\" abbr =\"Country\">";
     echo "<input type = \"textbox\"
                  id   = \"country\" 
                  name = \"country\" ";
     if( $lHrEmployeeTabObj->country !== null )
     echo "value = \"$lHrEmployeeTabObj->country\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Marital Status";
     echo "</td>";

     echo "<td id =\"lable_marital_status\" name =\"Marital Status\" abbr =\"Marital Status\">";
     echo "    <SELECT id= \"marital_status\" 
                       name= \"marital_status\"
                       onChange= \"
                                 {
                                   if( this.value == 'M' )
                                     document.getElementById('spouse_tr').style.display = '';
                                   else  
                                     document.getElementById('spouse_tr').style.display = 'none';
                                 }
                                 \"
                >";
     echo "      <Script language = \"JavaScript\">";
                       include("../cache/SGI/gn_maritalsts.js");
     echo "      </Script>";
     echo "    </SELECT>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Gender";
     echo "</td>";

     echo "<td id =\"lable_gender\" name =\"Gender\" abbr =\"Gender\">";
     echo "    <SELECT id = \"gender\" name = \"gender\">";
     echo "      <Script language = \"JavaScript\">";
                       include("../cache/SGI/gn_gender.js");
     echo "      </Script>";
     echo "    </SELECT>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------


     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Date Of Birth";
     echo "</td>";

     echo "<td id =\"lable_dob\" name =\"Date Of Birth\" abbr =\"Date Of Birth\">";
     echo "<input type = \"textbox\"
                  id   = \"dob\" 
                  name = \"dob\"";
     if( $lHrEmployeeTabObj->dob !== null )
     echo "value = \"$lHrEmployeeTabObj->dob\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Father Name";
     echo "</td>";

     echo "<td id =\"lable_father_name\" name =\"Father Name\" abbr =\"Father Name\">";
     echo "<input type = \"textbox\"
                  id   = \"father_name\" 
                  name = \"father_name\"";
     if( $lHrEmployeeTabObj->father_name !== null )
     echo "value = \"$lHrEmployeeTabObj->father_name\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr>";
     echo "<td>";
     echo "Mother Name";
     echo "</td>";

     echo "<td id =\"lable_mother_name\" name =\"Mother Name\" abbr =\"Mother Name\">";
     echo "<input type = \"textbox\"
                  id   = \"mother_name\" 
                  name = \"mother_name\"";
     if( $lHrEmployeeTabObj->mother_name !== null )
     echo "value = \"$lHrEmployeeTabObj->mother_name\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------

     //-----------------------------------------------------------------------------------------
     echo "<tr id=\"spouse_tr\" name=\"spouse_name\" style=\"display:none\">";
     echo "<td>";
     echo "Spouse Name";
     echo "</td>";

     echo "<td id =\"lable_spouse_name\" name =\"Spouse Name\" abbr =\"Spouse Name\">";
     echo "<input type = \"textbox\"
                  id   = \"spouse_name\" 
                  name = \"spouse_name\"";
     if( $lHrEmployeeTabObj->mother_name !== null )
     echo "value = \"$lHrEmployeeTabObj->mother_name\""; 
     echo "/>";
     echo "</td>";
     echo "</tr>";
     //-----------------------------------------------------------------------------------------


     //-----------------------------------------------------------------------------------------
     echo "<Script language = \"JavaScript\">";
     if( $lHrEmployeeTabObj->name_initials !== null )
       echo "document.getElementById('initial').value ='$lHrEmployeeTabObj->name_initials';";
     if( $lHrEmployeeTabObj->gender !== null )
       echo "document.getElementById('gender').value ='$lHrEmployeeTabObj->gender';";
     if( $lHrEmployeeTabObj->marital_status !== null )
       echo "document.getElementById('marital_status').value ='$lHrEmployeeTabObj->marital_status';";
     echo "</Script>";
     //-----------------------------------------------------------------------------------------
   }

   echo "</table>";
 }
?>
