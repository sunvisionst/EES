<?php
     echo"<html> ";
     echo"  <head> ";
     echo "   <script language=\"javascript\" src=\"../js/gn_prep_dd_option.js\"> </script>";
     echo "   <script language=\"javascript\" src=\"../php/gn_refresh_element_ajax_php.js\"> </script>";
     echo"  </head> ";
?>

<?
     $lCourseId     = "";
     $lQueryValue   = "";

     //VARIABLE DECLARATION & GETTING VALUE FROM QUERY STRING
     $lMenuOption         = $_GET['menu_option'];
     $lRequestType        = $_GET['req_type'];

     if( $lMenuOption  !== null && $lMenuOption == "eesCourse" ) 
     {
       $lCourseId           = $_GET['course_id'];
       $_SESSION['lCourseId']    = $lCourseId;
     }


     $_SESSION['lMenuOption']  = $lMenuOption;
     $_SESSION['lRequestType'] = $lRequestType;

     //Create Object of Class SSTPopDDValue
     $lSSTPopDDValue = new SSTPopDDValue();

     if( $lMenuOption !== null )
     {
       echo"<table border = \"0\" width = \"100%\"> ";

        if($lMenuOption == 'eesCourse' ) 
           $lLegendString = "Course ".$lCourseId;
       // else 
        //if($lMenuOption == 'eesFee' ) 
         //  $lLegendString = "Fee";
        else 
        if($lMenuOption == 'eesFaculty' ) 
           $lLegendString = "Faculty";
        else 
        if($lMenuOption == 'eesStudent' ) 
           $lLegendString = "Student";

        //SET VALUE IN THE SESSION
        $_SESSION['lLegendString'] = $lLegendString;


       //COMMON MENU BOX 
       echo"<tr>";
       echo"<td align = \"center\" width = \"80%\">";
       echo"<fieldset>";
       echo"<legend><font color = \"white\" >Dash Board For $lLegendString</font></legend>";
       echo"<table border = \"0\" width = \"100%\"> ";
       echo"<tr>";
       echo"<td>";

       include("sst_ml_common_query_menu_box.php");

       echo"</td>";
       echo"</tr>";
       echo"</table> ";
       echo"</fieldset>";
       echo"</td>";
       echo"</tr> ";
       //COMMON MENU BOX 


      
      if( $lRequestType != null && !($lRequestType == "COM") )
      {
        //---------------------------------------------------------------------
        if( $lRequestType == 'subList' )
          $lQueryValue = "Subject List";
        else 
        if( $lRequestType == 'stuList' )
          $lQueryValue = "Student List";
        else 
        if( $lRequestType == 'facAllocatedSub' )
          $lQueryValue = "Allocated Subject";
        else 
        if( $lRequestType == 'subProg' )
          $lQueryValue = "Subject Progress";
        else 
        if( $lRequestType == 'classTT' )
          $lQueryValue = "Class Timetable";
        else 
        if( $lRequestType == 'facProfile' )
          $lQueryValue = "Faculty Profile";
        else 
        if( $lRequestType == 'facTT' )
          $lQueryValue = "Faculty TimeTable";
        else 
        if( $lRequestType == 'facMarkEntry' )
          $lQueryValue = "Mark Entry";
        else 
        if( $lRequestType == 'facAttnEntry' )
          $lQueryValue = "Attendance Entry";
        else 
        if( $lRequestType == 'facAllSubject' )
          $lQueryValue = "Allocated Subject";
        else 
        if( $lRequestType == 'facAdr' )
          $lQueryValue = "Faculty Adr";
        else 
        if( $lRequestType == 'stuProfile' )
          $lQueryValue = "Student Profile";
        else 
        if( $lRequestType == 'stuMarkSheet' )
          $lQueryValue = "Mark Sheet";
        else 
        if( $lRequestType == 'stuAtten' )
          $lQueryValue = "Student Attendance";
        else 
        if( $lRequestType == 'classAtten' )
          $lQueryValue = "Class Attendance";
        else 
        if( $lRequestType == 'paidStud' )
          $lQueryValue = "Paid Student";
        else 
        if( $lRequestType == 'feeStruct' )
          $lQueryValue = "Fee Structure";
        else 
        if( $lRequestType == 'facList' )
          $lQueryValue = "Faculty List";
        else 
        if( $lRequestType == 'facSubProgEntry' )
          $lQueryValue = "Subject Progress Entry";
        //---------------------------------------------------------------------


        //INCLUDE SINGLE INCLUDE HERE
        echo"<tr>";
        echo"<td align = \"center\" width = \"60%\">";
        echo"<fieldset>";
        echo"<legend><font color = \"white\" >Query Criteria For $lQueryValue </font></legend>";
        echo"<table border = \"0\" width = \"70%\"> ";
        echo"<tr>";
        //echo"<td>";

        if( ( $lRequestType == 'facMarkEntry' )
          ||( $lRequestType == 'facAttnEntry' )
          ||( $lRequestType == 'facSubProgEntry' )
          )
          include("sst_ml_common_query_include_single2.php");
        else 
          include("sst_ml_common_query_include_single.php");
  
        //echo"</td>";
        echo"</tr>";
        echo"</table> ";
        echo"</fieldset>";
        echo"</td>";
        echo"</tr>";
  
  
        echo"<tr>";
        echo"<td align = \"center\" width = \"50%\">";
        echo"<fieldset>";
        echo"<legend><font color = \"white\" >Submit Action</font></legend>";
        echo"<table border = \"0\" width = \"100%\"> ";
        echo"<tr>";
        echo"<td align = \"center\">";

        include("sst_ml_common_query_criteria_action_bar.php");
  
        echo"</td>";
        echo"</tr>";
        echo"</table> ";
        echo"</td>";
        echo"</tr>";
      }
      echo"</table>";
   } 
   echo"</html> ";
?>
