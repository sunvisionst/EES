<?php
  /*
   *this class is used to upload excel file and create 2 file one with CTL ext & other is dat ext. 
   *lFileNameArray contains the file which supposed to be uploaded from the client side, file name 
   *store in the order in the array zero index contains employee file name, & first index contain class file name & soon.
  */

  require_once("test/example.php");

    class SSTUploadFile  
    {
      public  $lOrgId            = "";
      public  $lFileTypeErrMsg   = "";
      public  $lFileSizeErrMsg   = "";
      private $lFileNameArray    = array();


      public function upload_file()
      {
        $target_path = ""; 
        $target_path = $_SESSION['SST_MLA_UPLOAD_DATA_TRG_PATH'];

        $this->lFileNameArray[0] = $target_path."sst_ml_".$this->lOrgId."_hr_employee.CTL";
        $this->lFileNameArray[1] = $target_path."sst_ml_".$this->lOrgId."_ees_class.CTL";
        $this->lFileNameArray[2] = $target_path."sst_ml_".$this->lOrgId."_ees_student.CTL";
        $this->lFileNameArray[3] = $target_path."sst_ml_".$this->lOrgId."_ees_subject.CTL";

          
        //CHECK THE TYPE AND SIZE OF THE
        //EACH FILE
        for( $lRecNum = 0; $lRecNum < count($_FILES['upload_file']['name']); $lRecNum++ )
        {
           if( strlen($_FILES['upload_file']['name'][$lRecNum]) > 0 ) //CHECk IF FILE NAME IS GIVEN
           {
             if( $_FILES['upload_file']['type'][$lRecNum] == "application/vnd.ms-excel" ) //CHECK FILE TYPE
               ;
             else
             { 
               $lERRMsg = "FILE TYPE IS NOT CORRECT OF FILE ";
               $this->lFileTypeErrMsg = $lERRMsg.$_FILES['upload_file']['name'][$lRecNum]; 
               return -1;
             }

             if( $_FILES['upload_file']['size'][$lRecNum] <= 4200000  ) //CHECK FILE TYPE
               ;
             else
             { 
               $lERRMsg = "FILE SIZE IS EXCEED OF FILE ";
               $this->lFileSizeErrMsg = $lERRMsg.$_FILES['upload_file']['name'][$lRecNum]; 
               return -1;
             }
           }
        }


        $lWriteCSVLine = "";   

        //UPLOADING ALL THE FILE's
        for( $lRecNum = 0; $lRecNum < count($_FILES['upload_file']['name']); $lRecNum++ )
        {
         $lWriteCSVLine = "";   
         if( strlen($_FILES['upload_file']['name'][$lRecNum]) > 0 ) //CHECk IF FILE NAME IS GIVEN
         {
           //copy( $_FILES['upload_file']['tmp_name'][0], $this->lFileNameArray[$lRecNum] );//COPY FILE TO DESTINATION;
           $filename          = $_FILES['upload_file']['tmp_name'][$lRecNum]; 

           //GETTING FILE DATA IN TO ARRAY
           $lExcelFileDataArr = parseExcel($filename); 

           if( $lExcelFileDataArr !== null && count( $lExcelFileDataArr ) > 0 )
           {
             for( $lRowCount = 0; $lRowCount < count($lExcelFileDataArr); $lRowCount++ ) 
             {
               /*
                THIS CONDITION IS ONLY BCOZ
                DATA ROW START FROM 4 ROW IN 
                EXCEL SHEET.
               */
               if( $lRowCount !== null && $lRowCount > 3 )
               for( $lColumnCount = 0; $lColumnCount < count($lExcelFileDataArr); $lColumnCount++ ) 
               {
                 $lCellValue = $lExcelFileDataArr[$lRowCount][$lColumnCount]; 

                 if( strlen( $lCellValue ) > 0 )
                 {
                   if( is_numeric($lCellValue) )
                     $lWriteCSVLine .= $lCellValue.",";  
                   else
                   {
                     /*
                     if Any Period sign found in the strat 
                     middle or end of the word then the process 
                     will terminate
                     */
                     if( preg_match("/[^.]+\.[^.]/", $lCellValue) > 0 )
                        return -1;

                     if( ctype_alpha($lCellValue) )
                     {
                       if( ctype_upper($lCellValue) )
                         $lWriteCSVLine .= $lCellValue;  
                       else
                         return -1; //means value is not in upper case
                     }
                     else
                     { 
                       $lWriteCSVLine .= $lCellValue;  
                     }
                     $lWriteCSVLine .= ",";  
                   }
                 } 
               }
               /*
                THIS CONDITION IS ONLY BCOZ
                DATA ROW START FROM 4 ROW IN 
                EXCEL SHEET.
               */
               if( $lRowCount !== null && $lRowCount > 3 )
                $lWriteCSVLine .= "\n";  
             }
            
             //WRITE A METHOD WHICH WRITES DATA IN TO .DAT FILE
             $this->writeFileData($this->lFileNameArray[$lRecNum], $lWriteCSVLine);
           } 
         }
        }
        return 0;
      }



      private function writeFileData( $lCTLFileNamePath, $lCsvLineData )
      {
        $lDatFileNamePathArr = split('[.]', $lCTLFileNamePath);
        $lDatFileNamePath    = $lDatFileNamePathArr[0].".dat";  

        try
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lDatFileNamePath, "w") or die("FILE CAN NOT BE OPEN !!");
          fwrite($lFileHandler, $lCsvLineData);
        }
        catch (Exception $Ex )
        {
          echo $Ex->getMessage();
          return -1;
        }

        //Close the file
        fclose($lFileHandler);

        try
        {
          //OPEN A FILE FROM THE GIVEN PATH
          $lFileHandler  = fopen($lCTLFileNamePath, "w") or die("FILE CAN NOT BE OPEN !!");
          fwrite($lFileHandler, "");
        }
        catch (Exception $Ex )
        {
          echo $Ex->getMessage();
          return -1;
        }
        //Close the file
        fclose($lFileHandler);
      }


    }
?>
