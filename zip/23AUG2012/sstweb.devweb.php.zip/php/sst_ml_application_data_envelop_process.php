<?
   require_once("SSTUploadFile.php");
   //-----------------------------------------------------------------------------------
   $lSubmitAction = "";
   $lReturnValue  = 0;
   //-----------------------------------------------------------------------------------

   //-----------------------------------------------------------------------------------
   if( !isset($_POST['action_submit']) )
     ;
   else
    $lSubmitAction = $_POST['action_submit'];
   //-----------------------------------------------------------------------------------

   //-----------------------------------------------------------------------------------
   $lSSTUploadFile = new SSTUploadFile(); 
   $lSSTUploadFile->lOrgId = $lOrgId;
   //-----------------------------------------------------------------------------------

   //-----------------------------------------------------------------------------------
   if( $lSubmitAction !== null && $lSubmitAction == "uploaddata" ) 
   {
     $lReturnValue = $lSSTUploadFile->upload_file(); 

     if( $lReturnValue !== null && $lReturnValue < 0 )
     {
        echo "<font color = \"red\"><b>[UPLOADING FAILED DUE TO][] ";

        if( $lSSTUploadFile->lFileTypeErrMsg !== null && strlen($lSSTUploadFile->lFileTypeErrMsg) > 0 )
          echo " [".$lSSTUploadFile->lFileTypeErrMsg."]";
        else
        if( $lSSTUploadFile->lFileSizeErrMsg !== null && strlen($lSSTUploadFile->lFileSizeErrMsg) > 0 )
          echo " [".$lSSTUploadFile->lFileSizeErrMsg."]";
        
        echo "</b> !!!</font>";
     }
     else
        echo "<font color = \"red\"><b>[FILE UPLOADED SUCCESSFULLY !!!]";
      
   }
   //-----------------------------------------------------------------------------------

   //-----------------------------------------------------------------------------------
   echo "<table border = \"0\" width = \"100%\">";

   echo "<tr>";
   echo "<td align = \"left\">";
   echo "<fieldset>";
   echo "<legend><font color = \"white\" >Upload Data File </font></legend>";
   echo "</fieldset>";
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td>";
   echo "<table border = \"0\" width = \"100%\">";
   //LINK FOR SAMPLE FILE
   echo "<tr>";
   echo "<td>";
   require_once("sst_ml_application_data_sample_file_link.php"); 
   echo "</td>";
   echo "</tr>";

   echo "<tr>";
   echo "<td>";
   require_once("sst_ml_application_data_upload_file_include_single.php"); 
   echo "</td>";
   echo "<tr>";

   echo "</table>";
   echo "</td>";
   echo "</tr>";




   echo "</table>";
   //-----------------------------------------------------------------------------------
?>
