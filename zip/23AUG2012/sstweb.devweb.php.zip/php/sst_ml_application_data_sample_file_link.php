<?
  echo "<table border = \"0\" width = \"100%\">";
  echo "<tr>";

  echo "<td align = \"center\">";
  //echo "<a href=\"http://172.30.10.56/document/sstdoc/EES/SST_EES_Application_Configuration_Manual.pdf\">Download Sample Data File</a>";
  echo "<a href=\"../upload/custmla/".$lOrgId."/sample/sampleFile.ods\">Download Sample Data File</a>";
  echo "</td>";

  echo "<td align = \"center\">";
  echo "<a href=\"../upload/custmla/".$lOrgId."/sample/EmployeeData.ods\">Download Employee File Format</a>";
  echo "</td>";

  echo "<td align = \"center\">";
  echo "<a href=\"../upload/custmla/".$lOrgId."/sample/StudentData.ods\">Download Student File Format</a>";
  echo "</td>";

  echo "<td align = \"center\">";
  echo "<a href=\"#\">Download Class File Format</a>";
  echo "</td>";

  echo "<td align = \"center\">";
  echo "<a href=\"#\">Download Subject File Format</a>";
  echo "</td>";

  echo "</tr>";
  echo "</table>";
?>
