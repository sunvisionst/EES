<?php

  class SSTMlaAppParameterInit 
  {
    public $SST_MLA_HOME_PREFIX;
    public $SST_MLA_HOME;
    public $SST_MLA_HOME_CUST_DC;
    public $SST_MLA_HOME_SST_DC;
    public $SST_MLA_INSTALL;
    public $SST_MLA_DATA_INSTALL;
    public $SST_MLA_DATA_DIR;
    public $SST_MLA_MENU_DIR;
    public $SST_MLA_INBOX_DIR;
    public $SST_MLA_OUTBOX_DIR;
    public $SST_DC_DATA_DIR;
    public $SST_DC_INBOX_DIR;
    public $SST_DC_OUTBOX_DIR;
    public $SST_MLA_FILTER_PATH;
    public $SST_MLA_UPLOAD_DATA_TRG_PATH;
 

    function SSTMlaAppParameterInit ()
    {
      $SST_MLA_HOME_PREFIX          = "";
      $SST_MLA_HOME                 = "";
      $SST_MLA_HOME_CUST_DC         = "";
      $SST_MLA_HOME_SST_DC          = "";
      $SST_MLA_INSTALL              = "";
      $SST_MLA_DATA_INSTALL         = "";
      $SST_MLA_DATA_DIR             = "";
      $SST_MLA_MENU_DIR             = "";
      $SST_MLA_INBOX_DIR            = "";
      $SST_MLA_OUTBOX_DIR           = "";
      $SST_DC_DATA_DIR              = "";
      $SST_DC_INBOX_DIR             = "";
      $SST_DC_OUTBOX_DIR            = "";
      $SST_MLA_FILTER_PATH          = "";
      $SST_MLA_UPLOAD_DATA_TRG_PATH = "";
    }


    /*
      THIS METHOD IS USED TO GET THE
      INIT PARAMETER FROM THE FILE
      sst_ml_param_config_init.txt &
      LOAD THE PARAM VALUES INTO M/M. 
    */
    public function MlaAppParametrInit()
    {
       $lFileNamePath = "../php/sst_ml_param_config_init.txt";

       if(file_exists($lFileNamePath) && is_readable ($lFileNamePath))
       {
         try
         {
           //OPEN A FILE FROM THE GIVEN PATH
           $lFileHandler  = fopen($lFileNamePath, "r");

            while (!feof($lFileHandler))
            {
              $lRecordLine = fgets($lFileHandler);
              $lLineArr    = explode('=', $lRecordLine); 

              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_HOME_PREFIX' ) 
                $this->SST_MLA_HOME_PREFIX = str_replace(' ' ,'',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_HOME' ) 
                $this->SST_MLA_HOME        = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_HOME_CUST_DC' ) 
                $this->SST_MLA_HOME_CUST_DC = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_HOME_SST_DC' ) 
                $this->SST_MLA_HOME_SST_DC = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_INSTALL' ) 
                $this->SST_MLA_INSTALL     = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_DATA_INSTALL' ) 
                $this->SST_MLA_DATA_INSTALL = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_DATA_DIR' ) 
                $this->SST_MLA_DATA_DIR    = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_MENU_DIR' ) 
                $this->SST_MLA_MENU_DIR    = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_INBOX_DIR' ) 
                $this->SST_MLA_INBOX_DIR   = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_OUTBOX_DIR' ) 
                $this->SST_MLA_OUTBOX_DIR  = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_DC_DATA_DIR' ) 
                $this->SST_DC_DATA_DIR     = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_DC_INBOX_DIR' ) 
                $this->SST_DC_INBOX_DIR    = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_DC_OUTBOX_DIR' ) 
                $this->SST_DC_OUTBOX_DIR   = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_FILTER_PATH' ) 
                $this->SST_MLA_FILTER_PATH = str_replace(' ','',$lLineArr[1]);
              else
              if( $lLineArr[0] !== null && $lLineArr[0] == 'SST_MLA_UPLOAD_DATA_TRG_PATH' ) 
                $this->SST_MLA_UPLOAD_DATA_TRG_PATH = str_replace(' ','',$lLineArr[1]);
            }
         }
         catch (Exception $Ex )
         {
           echo $Ex->getMessage();
           return -1;
         }
      }
      else
       return -1; 

     return 0;
    }
  }
?>
