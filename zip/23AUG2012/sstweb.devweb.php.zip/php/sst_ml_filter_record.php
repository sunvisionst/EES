<?php

  class SSTFilter
  {
    public $lFilteredFileRelPath   = ""; //Relative File Path
    public $lFilteredFileName      = ""; //File in which we Search
    public $lFilteredPosition1     = 0; //Position value which matches from Criteria 
    public $lFilteredPosition2     = 0; //Position value which matches from Criteria 
    public $lFilteredPosition3     = 0; //Position value which matches from Criteria 
    public $lFilteredPosition4     = 0; //Position value which matches from Criteria 
    public $lFilteredPosition5     = 0; //Position value which matches from Criteria 
    public $lFilterCriteriaValue1  = null; //Criteria value 
    public $lFilterCriteriaValue2  = null; //Criteria value 
    public $lFilterCriteriaValue3  = null; //Criteria value 
    public $lFilterCriteriaValue4  = null; //Criteria value 
    public $lFilterCriteriaValue5  = null; //Criteria value 
    public $lFilteredRecordArr     = array();



    /* 
     PROVISION TO READ LESS
     NUM OF RECORD AND 
     REDUCE SEARCh COMPLEXITY.
    */
    public function filter_record ()
    {
       $lRecordLine = "";
       $lFilteredRecordArr     = array(); 

       //-----------------------------------------------------------------------------
       //READ FILE 
       //-----------------------------------------------------------------------------

       //GETTING FILE SOURCE
       //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME'])."/refdb/datafiledir/".$this->lFilteredFileName;
       //$lFileNamePath = dirname($_SERVER['SCRIPT_FILENAME']).$this->lFilteredFileRelPath.$this->lFilteredFileName;
       //$lFileNamePath   = getenv("SST_MLA_DATA_DIR")."SGI/".$this->lFilteredFileRelPath.$this->lFilteredFileName; 
       $lFileNamePath  = $_SESSION['SST_MLA_FILTER_PATH'];
       $lFileNamePath .= $this->lFilteredFileRelPath.$this->lFilteredFileName;

       if (file_exists($lFileNamePath) && is_readable ($lFileNamePath))
       {
         try
         {
           //OPEN A FILE FROM THE GIVEN PATH
           $lFileHandler  = fopen($lFileNamePath, "r") or die("FILE CAN NOT BE OPEN !!");
           //GETTING THE SIZE OF THE FILE 
           $lFileSize     = filesize($lFileNamePath);
      
           //INITILIZE THE ARRAY 
           $lFilteredRecordArr[0] = $lRecordLine; 
  
           while (!feof($lFileHandler))
           {
              if ( ($lRecordLine = fgets($lFileHandler)) && strlen($lRecordLine) > 1 )   //READ LINE BY LINE 
                $lFieldValueArr = explode( ",", $lRecordLine );
              else
                break;
            
  
              if( $lFieldValueArr !== null && count($lFieldValueArr) > 0 )
              { 
                if(  $this->lFilterCriteriaValue1 !== null 
                  && $this->lFilterCriteriaValue2 !== null 
                  && $this->lFilterCriteriaValue3 !== null 
                  && $this->lFilterCriteriaValue4 !== null 
                  && $this->lFilterCriteriaValue5 !== null 
                  ) 
                {
                  if( $lFieldValueArr[$this->lFilteredPosition1] == $this->lFilterCriteriaValue1 )//MATCH IDX VALUE
                    if( $lFieldValueArr[$this->lFilteredPosition2] == $this->lFilterCriteriaValue2 )//MATCH IDX VALUE
                      if( $lFieldValueArr[$this->lFilteredPosition3] == $this->lFilterCriteriaValue3 )//MATCH IDX VALUE
                        if( $lFieldValueArr[$this->lFilteredPosition4] == $this->lFilterCriteriaValue4 )//MATCH IDX VALUE
                          if( $lFieldValueArr[$this->lFilteredPosition5] == $this->lFilterCriteriaValue5 )//MATCH IDX VALUE
                          {
                            array_push( $lFilteredRecordArr, $lRecordLine );
                          }
                }
                else
                if(  $this->lFilterCriteriaValue1 !== null 
                  && $this->lFilterCriteriaValue2 !== null 
                  && $this->lFilterCriteriaValue3 !== null 
                  && $this->lFilterCriteriaValue4 !== null 
                  ) 
                {
                  if( $lFieldValueArr[$this->lFilteredPosition1] == $this->lFilterCriteriaValue1 )//MATCH IDX VALUE
                    if( $lFieldValueArr[$this->lFilteredPosition2] == $this->lFilterCriteriaValue2 )//MATCH IDX VALUE
                      if( $lFieldValueArr[$this->lFilteredPosition3] == $this->lFilterCriteriaValue3 )//MATCH IDX VALUE
                        if( $lFieldValueArr[$this->lFilteredPosition4] == $this->lFilterCriteriaValue4 )//MATCH IDX VALUE
                        {
                          array_push( $lFilteredRecordArr, $lRecordLine );
                        }
                }
                else
                if( $this->lFilterCriteriaValue1 !== null && $this->lFilterCriteriaValue2 !== null ) 
                {
                  if( $lFieldValueArr[$this->lFilteredPosition1] == $this->lFilterCriteriaValue1 )//MATCH IDX VALUE
                    if( $lFieldValueArr[$this->lFilteredPosition2] == $this->lFilterCriteriaValue2 )//MATCH IDX VALUE
                    {
                      array_push( $lFilteredRecordArr, $lRecordLine );
                    }
                }
                else
                if( $this->lFilterCriteriaValue1 !== null ) 
                {
                  if( $lFieldValueArr[$this->lFilteredPosition1] == $this->lFilterCriteriaValue1 )//MATCH IDX VALUE
                     array_push( $lFilteredRecordArr, $lRecordLine );
                }
              }
           }
         }
         catch (Exception $Ex )
         {
           echo $Ex->getMessage(); 
         } 
         
       }//end of if

       if( $lFilteredRecordArr !== null && count($lFilteredRecordArr) > 1 )
          return $lFilteredRecordArr;
       else
         return -1;
    } 
  }
?>
