<?

class EesStudentTabObj
{
  public $tab_rowid;
  public $org_id;
  public $student_id;
  public $barcode;
  public $user_id;
  public $pswd_0;
  public $student_name;
  public $father_name;
  public $mother_name;
  public $student_ctg;
  public $gender_flag;
  public $dob;
  public $doj;
  public $dot;
  public $p_address_1;
  public $p_address_2;
  public $p_country;
  public $p_state;
  public $p_city;
  public $p_district;
  public $p_zip;
  public $m_address_1;
  public $m_address_2;
  public $m_country;
  public $m_state;
  public $m_city;
  public $m_district;
  public $m_zip;
  public $class_id;
  public $class_num;
  public $class_std;
  public $class_section;
  public $course_id;
  public $course_term;
  public $course_stream;
  public $scholor_num;
  public $roll_num;
  public $external_roll_num;
  public $enrollment_num;
  public $shift_code;
  public $prev_org_id;
  public $prev_class_id;
  public $prev_class_num;
  public $prev_class_std;
  public $prev_class_section;
  public $prev_course_id;
  public $prev_course_term;
  public $prev_course_stream;
  public $prev_shift_code;
  public $promotion_sts;
  public $promotion_date;
  public $phone;
  public $email_id;
  public $student_sts;
  public $student_sts_date;
  public $photo_file_name;
  public $batch_number;
  public $num_of_yr_in_class;
  public $passing_year;
  public $extra_class_ind;
  public $admission_mode;
  public $account_balance;
  public $bal_close_curr;
  public $dr_amt_curr;
  public $cr_amt_curr;
  public $bal_open_curr;
  public $bal_close_prev;
  public $dr_amt_prev;
  public $cr_amt_prev;
  public $bal_open_prev;
  public $ban_status;
  public $last_status_date;
  public $bank_code;
  public $year_qrt_num;
  public $last_year_qrt_num;
  public $next_year_qrt_num;
  public $next_payment_date;
  public $allergy;
  public $allergic_medicine;
  public $physical_disability;
  public $health_problem;
  public $blood_group;
  public $hobbies;
  public $lg_0_name;
  public $lg_0_rel_type;
  public $lg_0_address;
  public $lg_0_phone;
  public $lg_1_name;
  public $lg_1_rel_type;
  public $lg_1_address;
  public $lg_1_phone;
  public $lg_2_name;
  public $lg_2_rel_type;
  public $lg_2_address;
  public $lg_2_phone;
  public $father_age;
  public $f_nationality;
  public $father_occ_type;
  public $father_employer;
  public $father_designation;
  public $father_annual_income;
  public $f_off_address_1;
  public $f_phone_list;
  public $mother_age;
  public $m_nationality;
  public $mother_occ_type;
  public $mother_employer;
  public $mother_designation;
  public $mother_annual_income;
  public $m_off_address_1;
  public $m_phone_list;
  public $org_transport_req_ind;
  public $org_hostel_req_ind;
  public $route_id;
  public $stoppage_id;
  public $stoppage_name;
  public $trip_id;
  public $trip_num;




  /*
  public $org_id_ind;
  public $student_id_ind;
  public $barcode_ind;
  public $user_id_ind;
  public $pswd_0_ind;
  public $student_name_ind;
  public $father_name_ind;
  public $mother_name_ind;
  public $student_ctg_ind;
  public $gender_flag_ind;
  public $dob_ind;
  public $doj_ind;
  public $dot_ind;
  public $p_address_1_ind;
  public $p_address_2_ind;
  public $p_country_ind;
  public $p_state_ind;
  public $p_city_ind;
  public $p_district_ind;
  public $p_zip_ind;
  public $m_address_1_ind;
  public $m_address_2_ind;
  public $m_country_ind;
  public $m_state_ind;
  public $m_city_ind;
  public $m_district_ind;
  public $m_zip_ind;
  public $class_id_ind;
  public $class_num_ind;
  public $class_std_ind;
  public $class_section_ind;
  public $course_id_ind;
  public $course_term_ind;
  public $course_stream_ind;
  public $scholor_num_ind;
  public $roll_num_ind;
  public $external_roll_num_ind;
  public $enrollment_num_ind;
  public $shift_code_ind;
  public $prev_org_id_ind;
  public $prev_class_id_ind;
  public $prev_class_num_ind;
  public $prev_class_std_ind;
  public $prev_class_section_ind;
  public $prev_course_id_ind;
  public $prev_course_term_ind;
  public $prev_course_stream_ind;
  public $prev_shift_code_ind;
  public $promotion_sts_ind;
  public $promotion_date_ind;
  public $phone_ind;
  public $email_id_ind;
  public $student_sts_ind;
  public $student_sts_date_ind;
  public $photo_file_name_ind;
  public $batch_number_ind;
  public $num_of_yr_in_class_ind;
  public $passing_year_ind;
  public $extra_class_ind_ind;
  public $admission_mode_ind;
  public $account_balance_ind;
  public $bal_close_curr_ind;
  public $dr_amt_curr_ind;
  public $cr_amt_curr_ind;
  public $bal_open_curr_ind;
  public $bal_close_prev_ind;
  public $dr_amt_prev_ind;
  public $cr_amt_prev_ind;
  public $bal_open_prev_ind;
  public $ban_status_ind;
  public $last_status_date_ind;
  public $bank_code_ind;
  public $year_qrt_num_ind;
  public $last_year_qrt_num_ind;
  public $next_year_qrt_num_ind;
  public $next_payment_date_ind;
  public $allergy_ind;
  public $allergic_medicine_ind;
  public $physical_disability_ind;
  public $health_problem_ind;
  public $blood_group_ind;
  public $hobbies_ind;
  public $lg_0_name_ind;
  public $lg_0_rel_type_ind;
  public $lg_0_address_ind;
  public $lg_0_phone_ind;
  public $lg_1_name_ind;
  public $lg_1_rel_type_ind;
  public $lg_1_address_ind;
  public $lg_1_phone_ind;
  public $lg_2_name_ind;
  public $lg_2_rel_type_ind;
  public $lg_2_address_ind;
  public $lg_2_phone_ind;
  public $father_age_ind;
  public $f_nationality_ind;
  public $father_occ_type_ind;
  public $father_employer_ind;
  public $father_designation_ind;
  public $father_annual_income_ind;
  public $f_off_address_1_ind;
  public $f_phone_list_ind;
  public $mother_age_ind;
  public $m_nationality_ind;
  public $mother_occ_type_ind;
  public $mother_employer_ind;
  public $mother_designation_ind;
  public $mother_annual_income_ind;
  public $m_off_address_1_ind;
  public $m_phone_list_ind;
  public $org_transport_req_ind_ind;
  public $org_hostel_req_ind_ind;
  public $route_id_ind;
  public $stoppage_id_ind;
  public $stoppage_name_ind;
  public $trip_id_ind;
  public $trip_num_ind;
  */

  function __construct(){}
  
  function EesStudentTabObj 
  (
    $org_id,
    $student_id,
    $barcode,
    $user_id,
    $pswd_0,
    $student_name,
    $father_name,
    $mother_name,
    $student_ctg,
    $gender_flag,
    $dob,
    $doj,
    $dot,
    $p_address_1,
    $p_address_2,
    $p_country,
    $p_state,
    $p_city,
    $p_district,
    $p_zip,
    $m_address_1,
    $m_address_2,
    $m_country,
    $m_state,
    $m_city,
    $m_district,
    $m_zip,
    $class_id,
    $class_num,
    $class_std,
    $class_section,
    $course_id,
    $course_term,
    $course_stream,
    $scholor_num,
    $roll_num,
    $external_roll_num,
    $enrollment_num,
    $shift_code,
    $prev_org_id,
    $prev_class_id,
    $prev_class_num,
    $prev_class_std,
    $prev_class_section,
    $prev_course_id,
    $prev_course_term,
    $prev_course_stream,
    $prev_shift_code,
    $promotion_sts,
    $promotion_date,
    $phone,
    $email_id,
    $student_sts,
    $student_sts_date,
    $photo_file_name,
    $batch_number,
    $num_of_yr_in_class,
    $passing_year,
    $extra_class_ind,
    $admission_mode,
    $account_balance,
    $bal_close_curr,
    $dr_amt_curr,
    $cr_amt_curr,
    $bal_open_curr,
    $bal_close_prev,
    $dr_amt_prev,
    $cr_amt_prev,
    $bal_open_prev,
    $ban_status,
    $last_status_date,
    $bank_code,
    $year_qrt_num,
    $last_year_qrt_num,
    $next_year_qrt_num,
    $next_payment_date,
    $allergy,
    $allergic_medicine,
    $physical_disability,
    $health_problem,
    $blood_group,
    $hobbies,
    $lg_0_name,
    $lg_0_rel_type,
    $lg_0_address,
    $lg_0_phone,
    $lg_1_name,
    $lg_1_rel_type,
    $lg_1_address,
    $lg_1_phone,
    $lg_2_name,
    $lg_2_rel_type,
    $lg_2_address,
    $lg_2_phone,
    $father_age,
    $f_nationality,
    $father_occ_type,
    $father_employer,
    $father_designation,
    $father_annual_income,
    $f_off_address_1,
    $f_phone_list,
    $mother_age,
    $m_nationality,
    $mother_occ_type,
    $mother_employer,
    $mother_designation,
    $mother_annual_income,
    $m_off_address_1,
    $m_phone_list,
    $org_transport_req_ind,
    $org_hostel_req_ind,
    $route_id,
    $stoppage_id,
    $stoppage_name,
    $trip_id,
    $trip_num
  )
  {
     //echo "AAAAAAAAAAA";
     $this->org_id = $org_id;
     $this->student_id = $student_id;
     $this->barcode = $barcode;
     $this->user_id = $user_id;
     $this->pswd_0 = $pswd_0;
     $this->student_name = $student_name;
     $this->father_name = $father_name;
     $this->mother_name = $mother_name;
     $this->student_ctg = $student_ctg;
     $this->gender_flag = $gender_flag;
     $this->dob = $dob;
     $this->doj = $doj;
     $this->dot = $dot;
     $this->p_address_1 = $p_address_1;
     $this->p_address_2 = $p_address_2;
     $this->p_country = $p_country;
     $this->p_state = $p_state;
     $this->p_city = $p_city;
     $this->p_district = $p_district;
     $this->p_zip = $p_zip;
     $this->m_address_1 = $m_address_1;
     $this->m_address_2 = $m_address_2;
     $this->m_country = $m_country;
     $this->m_state = $m_state;
     $this->m_city = $m_city;
     $this->m_district = $m_district;
     $this->m_zip = $m_zip;
     $this->class_id = $class_id;
     $this->class_num = $class_num;
     $this->class_std = $class_std;
     $this->class_section = $class_section;
     $this->course_id = $course_id;
     $this->course_term = $course_term;
     $this->course_stream = $course_stream;
     $this->scholor_num = $scholor_num;
     $this->roll_num = $roll_num;
     $this->external_roll_num = $external_roll_num;
     $this->enrollment_num = $enrollment_num;
     $this->shift_code = $shift_code;
     $this->prev_org_id = $prev_org_id;
     $this->prev_class_id = $prev_class_id;
     $this->prev_class_num = $prev_class_num;
     $this->prev_class_std = $prev_class_std;
     $this->prev_class_section = $prev_class_section;
     $this->prev_course_id = $prev_course_id;
     $this->prev_course_term = $prev_course_term;
     $this->prev_course_stream = $prev_course_stream;
     $this->prev_shift_code = $prev_shift_code;
     $this->promotion_sts = $promotion_sts;
     $this->promotion_date = $promotion_date;
     $this->phone = $phone;
     $this->email_id = $email_id;
     $this->student_sts = $student_sts;
     $this->student_sts_date = $student_sts_date;
     $this->photo_file_name = $photo_file_name;
     $this->batch_number = $batch_number;
     $this->num_of_yr_in_class = $num_of_yr_in_class;
     $this->passing_year = $passing_year;
     $this->extra_class_ind = $extra_class_ind;
     $this->admission_mode = $admission_mode;
     $this->account_balance = $account_balance;
     $this->bal_close_curr = $bal_close_curr;
     $this->dr_amt_curr = $dr_amt_curr;
     $this->cr_amt_curr = $cr_amt_curr;
     $this->bal_open_curr = $bal_open_curr;
     $this->bal_close_prev = $bal_close_prev;
     $this->dr_amt_prev = $dr_amt_prev;
     $this->cr_amt_prev = $cr_amt_prev;
     $this->bal_open_prev = $bal_open_prev;
     $this->ban_status = $ban_status;
     $this->last_status_date = $last_status_date;
     $this->bank_code = $bank_code;
     $this->year_qrt_num = $year_qrt_num;
     $this->last_year_qrt_num = $last_year_qrt_num;
     $this->next_year_qrt_num = $next_year_qrt_num;
     $this->next_payment_date = $next_payment_date;
     $this->allergy = $allergy;
     $this->allergic_medicine = $allergic_medicine;
     $this->physical_disability = $physical_disability;
     $this->health_problem = $health_problem;
     $this->blood_group = $blood_group;
     $this->hobbies = $hobbies;
     $this->lg_0_name = $lg_0_name;
     $this->lg_0_rel_type = $lg_0_rel_type;
     $this->lg_0_address = $lg_0_address;
     $this->lg_0_phone = $lg_0_phone;
     $this->lg_1_name = $lg_1_name;
     $this->lg_1_rel_type = $lg_1_rel_type;
     $this->lg_1_address = $lg_1_address;
     $this->lg_1_phone = $lg_1_phone;
     $this->lg_2_name = $lg_2_name;
     $this->lg_2_rel_type = $lg_2_rel_type;
     $this->lg_2_address = $lg_2_address;
     $this->lg_2_phone = $lg_2_phone;
     $this->father_age = $father_age;
     $this->f_nationality = $f_nationality;
     $this->father_occ_type = $father_occ_type;
     $this->father_employer = $father_employer;
     $this->father_designation = $father_designation;
     $this->father_annual_income = $father_annual_income;
     $this->f_off_address_1 = $f_off_address_1;
     $this->f_phone_list = $f_phone_list;
     $this->mother_age = $mother_age;
     $this->m_nationality = $m_nationality;
     $this->mother_occ_type = $mother_occ_type;
     $this->mother_employer = $mother_employer;
     $this->mother_designation = $mother_designation;
     $this->mother_annual_income = $mother_annual_income;
     $this->m_off_address_1 = $m_off_address_1;
     $this->m_phone_list = $m_phone_list;
     $this->org_transport_req_ind = $org_transport_req_ind;
     $this->org_hostel_req_ind = $org_hostel_req_ind;
     $this->route_id = $route_id;
     $this->stoppage_id = $stoppage_id;
     $this->stoppage_name = $stoppage_name;
     $this->trip_id = $trip_id;
     $this->trip_num = $trip_num;
  }
 /* 
  public function getorg_id()                           { return $org_id; }
  public function getstudent_id()                         { return $student_id; }
  public function getbarcode()                          { return $barcode; }
  public function getuser_id()                          { return $user_id; }
  public function getpswd_0()                           { return $pswd_0; }
  public function getstudent_name()                        { return $student_name; }
  public function getfather_name()                        { return $father_name; }
  public function getmother_name()                        { return $mother_name; }
  public function getstudent_ctg()                        { return $student_ctg; }
  public function getgender_flag()                        { return $gender_flag; }
  public function getdob()                            { return $dob; }
  public function getdoj()                            { return $doj; }
  public function getdot()                            { return $dot; }
  public function getp_address_1()                        { return $p_address_1; }
  public function getp_address_2()                        { return $p_address_2; }
  public function getp_country()                         { return $p_country; }
  public function getp_state()                          { return $p_state; }
  public function getp_city()                           { return $p_city; }
  public function getp_district()                         { return $p_district; }
  public function getp_zip()                           { return $p_zip; }
  public function getm_address_1()                        { return $m_address_1; }
  public function getm_address_2()                        { return $m_address_2; }
  public function getm_country()                         { return $m_country; }
  public function getm_state()                          { return $m_state; }
  public function getm_city()                           { return $m_city; }
  public function getm_district()                         { return $m_district; }
  public function getm_zip()                           { return $m_zip; }
  public function getclass_id()                          { return $class_id; }
  public function getclass_num()                         { return $class_num; }
  public function getclass_std()                         { return $class_std; }
  public function getclass_section()                       { return $class_section; }
  public function getcourse_id()                         { return $course_id; }
  public function getcourse_term()                        { return $course_term; }
  public function getcourse_stream()                       { return $course_stream; }
  public function getscholor_num()                        { return $scholor_num; }
  public function getroll_num()                          { return $roll_num; }
  public function getexternal_roll_num()                     { return $external_roll_num; }
  public function getenrollment_num()                       { return $enrollment_num; }
  public function getshift_code()                         { return $shift_code; }
  public function getprev_org_id()                        { return $prev_org_id; }
  public function getprev_class_id()                       { return $prev_class_id; }
  public function getprev_class_num()                       { return $prev_class_num; }
  public function getprev_class_std()                       { return $prev_class_std; }
  public function getprev_class_section()                     { return $prev_class_section; }
  public function getprev_course_id()                       { return $prev_course_id; }
  public function getprev_course_term()                      { return $prev_course_term; }
  public function getprev_course_stream()                     { return $prev_course_stream; }
  public function getprev_shift_code()                      { return $prev_shift_code; }
  public function getpromotion_sts()                       { return $promotion_sts; }
  public function getpromotion_date()                       { return $promotion_date; }
  public function getphone()                           { return $phone; }
  public function getemail_id()                          { return $email_id; }
  public function getstudent_sts()                        { return $student_sts; }
  public function getstudent_sts_date()                      { return $student_sts_date; }
  public function getphoto_file_name()                      { return $photo_file_name; }
  public function getbatch_number()                        { return $batch_number; }
  public function getnum_of_yr_in_class()                      { return $num_of_yr_in_class; }
  public function getpassing_year()                         { return $passing_year; }
  public function getextra_class_ind()                      { return $extra_class_ind; }
  public function getadmission_mode()                       { return $admission_mode; }
  public function getaccount_balance()                      { return $account_balance; }
  public function getbal_close_curr()                       { return $bal_close_curr; }
  public function getdr_amt_curr()                        { return $dr_amt_curr; }
  public function getcr_amt_curr()                        { return $cr_amt_curr; }
  public function getbal_open_curr()                       { return $bal_open_curr; }
  public function getbal_close_prev()                       { return $bal_close_prev; }
  public function getdr_amt_prev()                        { return $dr_amt_prev; }
  public function getcr_amt_prev()                        { return $cr_amt_prev; }
  public function getbal_open_prev()                       { return $bal_open_prev; }
  public function getban_status()                         { return $ban_status; }
  public function getlast_status_date()                      { return $last_status_date; }
  public function getbank_code()                         { return $bank_code; }
  public function getyear_qrt_num()                        { return $year_qrt_num; }
  public function getlast_year_qrt_num()                     { return $last_year_qrt_num; }
  public function getnext_year_qrt_num()                     { return $next_year_qrt_num; }
  public function getnext_payment_date()                     { return $next_payment_date; }
  public function getallergy()                          { return $allergy; }
  public function getallergic_medicine()                     { return $allergic_medicine; }
  public function getphysical_disability()                    { return $physical_disability; }
  public function gethealth_problem()                       { return $health_problem; }
  public function getblood_group()                        { return $blood_group; }
  public function gethobbies()                          { return $hobbies; }
  public function getlg_0_name()                         { return $lg_0_name; }
  public function getlg_0_rel_type()                       { return $lg_0_rel_type; }
  public function getlg_0_address()                        { return $lg_0_address; }
  public function getlg_0_phone()                         { return $lg_0_phone; }
  public function getlg_1_name()                         { return $lg_1_name; }
  public function getlg_1_rel_type()                       { return $lg_1_rel_type; }
  public function getlg_1_address()                        { return $lg_1_address; }
  public function getlg_1_phone()                         { return $lg_1_phone; }
  public function getlg_2_name()                         { return $lg_2_name; }
  public function getlg_2_rel_type()                       { return $lg_2_rel_type; }
  public function getlg_2_address()                        { return $lg_2_address; }
  public function getlg_2_phone()                         { return $lg_2_phone; }
  public function getfather_age()                          { return $father_age; }
  public function getf_nationality()                       { return $f_nationality; }
  public function getfather_occ_type()                      { return $father_occ_type; }
  public function getfather_employer()                      { return $father_employer; }
  public function getfather_designation()                     { return $father_designation; }
  public function getfather_annual_income()                    { return $father_annual_income; }
  public function getf_off_address_1()                      { return $f_off_address_1; }
  public function getf_phone_list()                        { return $f_phone_list; }
  public function getmother_age()                          { return $mother_age; }
  public function getm_nationality()                       { return $m_nationality; }
  public function getmother_occ_type()                      { return $mother_occ_type; }
  public function getmother_employer()                      { return $mother_employer; }
  public function getmother_designation()                     { return $mother_designation; }
  public function getmother_annual_income()                    { return $mother_annual_income; }
  public function getm_off_address_1()                      { return $m_off_address_1; }
  public function getm_phone_list()                        { return $m_phone_list; }
  public function getorg_transport_req_ind()                   { return $org_transport_req_ind; }
  public function getorg_hostel_req_ind()                     { return $org_hostel_req_ind; }
  public function getroute_id()                          { return $route_id; }
  public function getstoppage_id()                        { return $stoppage_id; }
  public function getstoppage_name()                       { return $stoppage_name; }
  public function gettrip_id()                          { return $trip_id; }
  public function gettrip_num()                          { return $trip_num; }
  


  public function  setorg_id($org_id )                    { $this->org_id = $org_id; }
  public function  setstudent_id($student_id )                { $this->student_id = $student_id; }
  public function  setbarcode($barcode )                   { $this->barcode = $barcode; }
  public function  setuser_id($user_id )                   { $this->user_id = $user_id; }
  public function  setpswd_0($pswd_0 )                    { $this->pswd_0 = $pswd_0; }
  public function  setstudent_name($student_name )              { $this->student_name = $student_name; }
  public function  setfather_name($father_name )               { $this->father_name = $father_name; }
  public function  setmother_name($mother_name )               { $this->mother_name = $mother_name; }
  public function  setstudent_ctg($student_ctg )               { $this->student_ctg = $student_ctg; }
  public function  setgender_flag($gender_flag )               { $this->gender_flag = $gender_flag; }
  public function  setdob($dob )                       { $this->dob = $dob; }
  public function  setdoj($doj )                       { $this->doj = $doj; }
  public function  setdot($dot )                       { $this->dot = $dot; }
  public function  setp_address_1($p_address_1 )               { $this->p_address_1 = $p_address_1; }
  public function  setp_address_2($p_address_2 )               { $this->p_address_2 = $p_address_2; }
  public function  setp_country($p_country )                 { $this->p_country = $p_country; }
  public function  setp_state($p_state )                   { $this->p_state = $p_state; }
  public function  setp_city($p_city )                    { $this->p_city = $p_city; }
  public function  setp_district($p_district )                { $this->p_district = $p_district; }
  public function  setp_zip($p_zip )                     { $this->p_zip = $p_zip; }
  public function  setm_address_1($m_address_1 )               { $this->m_address_1 = $m_address_1; }
  public function  setm_address_2($m_address_2 )               { $this->m_address_2 = $m_address_2; }
  public function  setm_country($m_country )                 { $this->m_country = $m_country; }
  public function  setm_state($m_state )                   { $this->m_state = $m_state; }
  public function  setm_city($m_city )                    { $this->m_city = $m_city; }
  public function  setm_district($m_district )                { $this->m_district = $m_district; }
  public function  setm_zip($m_zip )                     { $this->m_zip = $m_zip; }
  public function  setclass_id($class_id )                  { $this->class_id = $class_id; }
  public function  setclass_num($class_num )                 { $this->class_num = $class_num; }
  public function  setclass_std($class_std )                 { $this->class_std = $class_std; }
  public function  setclass_section($class_section )             { $this->class_section = $class_section; }
  public function  setcourse_id($course_id )                 { $this->course_id = $course_id; }
  public function  setcourse_term($course_term )               { $this->course_term = $course_term; }
  public function  setcourse_stream($course_stream )             { $this->course_stream = $course_stream; }
  public function  setscholor_num($scholor_num )               { $this->scholor_num = $scholor_num; }
  public function  setroll_num($roll_num )                  { $this->roll_num = $roll_num; }
  public function  setexternal_roll_num($external_roll_num )         { $this->external_roll_num = $external_roll_num; }
  public function  setenrollment_num($enrollment_num )            { $this->enrollment_num = $enrollment_num; }
  public function  setshift_code($shift_code )                { $this->shift_code = $shift_code; }
  public function  setprev_org_id($prev_org_id )               { $this->prev_org_id = $prev_org_id; }
  public function  setprev_class_id($prev_class_id )             { $this->prev_class_id = $prev_class_id; }
  public function  setprev_class_num($prev_class_num )            { $this->prev_class_num = $prev_class_num; }
  public function  setprev_class_std($prev_class_std )            { $this->prev_class_std = $prev_class_std; }
  public function  setprev_class_section($prev_class_section )        { $this->prev_class_section = $prev_class_section; }
  public function  setprev_course_id($prev_course_id )            { $this->prev_course_id = $prev_course_id; }
  public function  setprev_course_term($prev_course_term )          { $this->prev_course_term = $prev_course_term; }
  public function  setprev_course_stream($prev_course_stream )        { $this->prev_course_stream = $prev_course_stream; }
  public function  setprev_shift_code($prev_shift_code )           { $this->prev_shift_code = $prev_shift_code; }
  public function  setpromotion_sts($promotion_sts )             { $this->promotion_sts = $promotion_sts; }
  public function  setpromotion_date($promotion_date )            { $this->promotion_date = $promotion_date; }
  public function  setphone($phone )                     { $this->phone = $phone; }
  public function  setemail_id($email_id )                  { $this->email_id = $email_id; }
  public function  setstudent_sts($student_sts )               { $this->student_sts = $student_sts; }
  public function  setstudent_sts_date($student_sts_date )          { $this->student_sts_date = $student_sts_date; }
  public function  setphoto_file_name($photo_file_name )           { $this->photo_file_name = $photo_file_name; }
  public function  setbatch_number($batch_number )              { $this->batch_number = $batch_number; }
  public function  setnum_of_yr_in_class($num_of_yr_in_class )         { $this->num_of_yr_in_class = $num_of_yr_in_class; }
  public function  setpassing_year($passing_year )               { $this->passing_year = $passing_year; }
  public function  setextra_class_ind($extra_class_ind )           { $this->extra_class_ind = $extra_class_ind; }
  public function  setadmission_mode($admission_mode )            { $this->admission_mode = $admission_mode; }
  public function  setaccount_balance($account_balance )           { $this->account_balance = $account_balance; }
  public function  setbal_close_curr($bal_close_curr )            { $this->bal_close_curr = $bal_close_curr; }
  public function  setdr_amt_curr($dr_amt_curr )               { $this->dr_amt_curr = $dr_amt_curr; }
  public function  setcr_amt_curr($cr_amt_curr )               { $this->cr_amt_curr = $cr_amt_curr; }
  public function  setbal_open_curr($bal_open_curr )             { $this->bal_open_curr = $bal_open_curr; }
  public function  setbal_close_prev($bal_close_prev )            { $this->bal_close_prev = $bal_close_prev; }
  public function  setdr_amt_prev($dr_amt_prev )               { $this->dr_amt_prev = $dr_amt_prev; }
  public function  setcr_amt_prev($cr_amt_prev )               { $this->cr_amt_prev = $cr_amt_prev; }
  public function  setbal_open_prev($bal_open_prev )             { $this->bal_open_prev = $bal_open_prev; }
  public function  setban_status($ban_status )                { $this->ban_status = $ban_status; }
  public function  setlast_status_date($last_status_date )          { $this->last_status_date = $last_status_date; }
  public function  setbank_code($bank_code )                 { $this->bank_code = $bank_code; }
  public function  setyear_qrt_num($year_qrt_num )              { $this->year_qrt_num = $year_qrt_num; }
  public function  setlast_year_qrt_num($last_year_qrt_num )         { $this->last_year_qrt_num = $last_year_qrt_num; }
  public function  setnext_year_qrt_num($next_year_qrt_num )         { $this->next_year_qrt_num = $next_year_qrt_num; }
  public function  setnext_payment_date($next_payment_date )         { $this->next_payment_date = $next_payment_date; }
  public function  setallergy($allergy )                   { $this->allergy = $allergy; }
  public function  setallergic_medicine($allergic_medicine )         { $this->allergic_medicine = $allergic_medicine; }
  public function  setphysical_disability($physical_disability )       { $this->physical_disability = $physical_disability; }
  public function  sethealth_problem($health_problem )            { $this->health_problem = $health_problem; }
  public function  setblood_group($blood_group )               { $this->blood_group = $blood_group; }
  public function  sethobbies($hobbies )                   { $this->hobbies = $hobbies; }
  public function  setlg_0_name($lg_0_name )                 { $this->lg_0_name = $lg_0_name; }
  public function  setlg_0_rel_type($lg_0_rel_type )             { $this->lg_0_rel_type = $lg_0_rel_type; }
  public function  setlg_0_address($lg_0_address )              { $this->lg_0_address = $lg_0_address; }
  public function  setlg_0_phone($lg_0_phone )                { $this->lg_0_phone = $lg_0_phone; }
  public function  setlg_1_name($lg_1_name )                 { $this->lg_1_name = $lg_1_name; }
  public function  setlg_1_rel_type($lg_1_rel_type )             { $this->lg_1_rel_type = $lg_1_rel_type; }
  public function  setlg_1_address($lg_1_address )              { $this->lg_1_address = $lg_1_address; }
  public function  setlg_1_phone($lg_1_phone )                { $this->lg_1_phone = $lg_1_phone; }
  public function  setlg_2_name($lg_2_name )                 { $this->lg_2_name = $lg_2_name; }
  public function  setlg_2_rel_type($lg_2_rel_type )             { $this->lg_2_rel_type = $lg_2_rel_type; }
  public function  setlg_2_address($lg_2_address )              { $this->lg_2_address = $lg_2_address; }
  public function  setlg_2_phone($lg_2_phone )                { $this->lg_2_phone = $lg_2_phone; }
  public function  setfather_age($father_age )                 { $this->father_age = $father_age; }
  public function  setf_nationality($f_nationality )             { $this->f_nationality = $f_nationality; }
  public function  setfather_occ_type($father_occ_type )           { $this->father_occ_type = $father_occ_type; }
  public function  setfather_employer($father_employer )           { $this->father_employer = $father_employer; }
  public function  setfather_designation($father_designation )        { $this->father_designation = $father_designation; }
  public function  setfather_annual_income($father_annual_income )      { $this->father_annual_income = $father_annual_income; }
  public function  setf_off_address_1($f_off_address_1 )           { $this->f_off_address_1 = $f_off_address_1; }
  public function  setf_phone_list($f_phone_list )              { $this->f_phone_list = $f_phone_list; }
  public function  setmother_age($mother_age )                 { $this->mother_age = $mother_age; }
  public function  setm_nationality($m_nationality )             { $this->m_nationality = $m_nationality; }
  public function  setmother_occ_type($mother_occ_type )           { $this->mother_occ_type = $mother_occ_type; }
  public function  setmother_employer($mother_employer )           { $this->mother_employer = $mother_employer; }
  public function  setmother_designation($mother_designation )        { $this->mother_designation = $mother_designation; }
  public function  setmother_annual_income($mother_annual_income )      { $this->mother_annual_income = $mother_annual_income; }
  public function  setm_off_address_1($m_off_address_1 )           { $this->m_off_address_1 = $m_off_address_1; }
  public function  setm_phone_list($m_phone_list )              { $this->m_phone_list = $m_phone_list; }
  public function  setorg_transport_req_ind($org_transport_req_ind )     { $this->org_transport_req_ind = $org_transport_req_ind; }
  public function  setorg_hostel_req_ind($org_hostel_req_ind )        { $this->org_hostel_req_ind = $org_hostel_req_ind; }
  public function  setroute_id($route_id )                  { $this->route_id = $route_id; }
  public function  setstoppage_id($stoppage_id )               { $this->stoppage_id = $stoppage_id; }
  public function  setstoppage_name($stoppage_name )             { $this->stoppage_name = $stoppage_name; }
  public function  settrip_id($trip_id )                   { $this->trip_id = $trip_id; }
  public function  settrip_num($trip_num )                  { $this->trip_num = $trip_num; }
  */  

}

?>
