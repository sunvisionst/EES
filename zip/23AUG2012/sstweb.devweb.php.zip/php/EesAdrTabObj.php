<?


class EesAdrTabObj
{
  public $tab_rowid;
  public $org_id;
  public $employee_id;
  public $period_num;
  public $adr_date;
  public $topic_id;
  public $adr_start_time;
  public $adr_end_time;
  public $lecture_num;
  public $subject_code;
  public $topic_percent_covered;
  public $class_id;
  public $class_num;
  public $class_std;
  public $class_section;
  public $course_id;
  public $course_term;
  public $course_stream;





  public $org_id_ind;
  public $employee_id_ind;
  public $period_num_ind;
  public $adr_date_ind;
  public $topic_id_ind;
  public $adr_start_time_ind;
  public $adr_end_time_ind;
  public $lecture_num_ind;
  public $subject_code_ind;
  public $topic_percent_covered_ind;
  public $class_id_ind;
  public $class_num_ind;
  public $class_std_ind;
  public $class_section_ind;
  public $course_id_ind;
  public $course_term_ind;
  public $course_stream_ind;


  public function __construct(){}


  public function EesAdrTabObj
  (
    $org_id,
    $employee_id,
    $period_num,
    $adr_date,
    $topic_id,
    $adr_start_time,
    $adr_end_time,
    $lecture_num,
    $subject_code,
    $topic_percent_covered,
    $class_id,
    $class_num,
    $class_std,
    $class_section,
    $course_id,
    $course_term,
    $course_stream
  )
  {
     $this->org_id                = $org_id;
     $this->employee_id           = $employee_id;
     $this->period_num            = $period_num;
     $this->adr_date              = $adr_date;
     $this->topic_id              = $topic_id;
     $this->adr_start_time        = $adr_start_time;
     $this->adr_end_time          = $adr_end_time;
     $this->lecture_num           = $lecture_num;
     $this->subject_code          = $subject_code;
     $this->topic_percent_covered = $topic_percent_covered;
     $this->class_id              = $class_id;
     $this->class_num             = $class_num;
     $this->class_std             = $class_std;
     $this->class_section         = $class_section;
     $this->course_id             = $course_id;
     $this->course_term           = $course_term;
     $this->course_stream         = $course_stream;
  }

  public function getorg_id()                               { return $this->org_id; }
  public function getemployee_id()                          { return $this->employee_id; }
  public function getperiod_num()                           { return $this->period_num; }
  public function getadr_date()                             { return $this->adr_date; }
  public function gettopic_id()                             { return $this->topic_id; }
  public function getadr_start_time()                       { return $this->adr_start_time; }
  public function getadr_end_time()                         { return $this->adr_end_time; }
  public function getlecture_num()                          { return $this->lecture_num; }
  public function getsubject_code()                         { return $this->subject_code; }
  public function gettopic_percent_covered()                { return $this->topic_percent_covered; }
  public function getclass_id()                             { return $this->class_id; }
  public function getclass_num()                            { return $this->class_num; }
  public function getclass_std()                            { return $this->class_std; }
  public function getclass_section()                        { return $this->class_section; }
  public function getcourse_id()                            { return $this->course_id; }
  public function getcourse_term()                          { return $this->course_term; }
  public function getcourse_stream()                        { return $this->course_stream; }



  public function  setorg_id($org_id )                               { $this->org_id                = $org_id; }
  public function  setemployee_id($employee_id )                     { $this->employee_id           = $employee_id; }
  public function  setperiod_num($period_num )                       { $this->period_num            = $period_num; }
  public function  setadr_date($adr_date )                           { $this->adr_date              = $adr_date; }
  public function  settopic_id($topic_id )                           { $this->topic_id              = $topic_id; }
  public function  setadr_start_time($adr_start_time )               { $this->adr_start_time        = $adr_start_time; }
  public function  setadr_end_time($adr_end_time )                   { $this->adr_end_time          = $adr_end_time; }
  public function  setlecture_num($lecture_num )                     { $this->lecture_num           = $lecture_num; }
  public function  setsubject_code($subject_code )                   { $this->subject_code          = $subject_code; }
  public function  settopic_percent_covered($topic_percent_covered ) { $this->topic_percent_covered = $topic_percent_covered; }
  public function  setclass_id($class_id )                           { $this->class_id              = $class_id; }
  public function  setclass_num($class_num )                         { $this->class_num             = $class_num; }
  public function  setclass_std($class_std )                         { $this->class_std             = $class_std; }
  public function  setclass_section($class_section )                 { $this->class_section         = $class_section; }
  public function  setcourse_id($course_id )                         { $this->course_id             = $course_id; }
  public function  setcourse_term($course_term )                     { $this->course_term           = $course_term; }
  public function  setcourse_stream($course_stream )                 { $this->course_stream         = $course_stream; }
}
?>
