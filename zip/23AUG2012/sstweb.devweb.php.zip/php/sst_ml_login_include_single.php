<?
  echo "<table border=\"0\" width = \"20%\">";

  echo "<tr>";
  echo "<td>";
  echo "User Id";
  echo "<td>";

  echo "<td>";
  echo "<input type=\"textbox\" id=\"user_id\" name=\"user_id\"/>";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  echo "Password";
  echo "<td>";

  echo "<td>";
  echo "<input type=\"password\" id=\"user_password\" name=\"user_password\"/>";
  echo "</td>";
  echo "</tr>";

  echo "<tr>";
  echo "<td>";
  echo "Org Id"; 
  echo "<td>";

  echo "<td>";
  echo "<input type=\"textbox\" id=\"org_id\" name=\"org_id\"/>";
  echo "</td>";
  echo "</tr>";

  echo "</table>";
?>
