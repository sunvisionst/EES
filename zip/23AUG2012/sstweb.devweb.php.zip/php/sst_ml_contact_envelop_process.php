<?

  echo "<table border=\"0\" width=\"100%\">"; 
  echo "<tr>";
  
  echo "<td>";
  echo "<fieldset>";
  echo "<legend>Contact Details</legend>";

  echo "<table border=\"0\" width=\"100%\">"; 
  echo "<tr>";
  echo "<td align=\"center\">";

  echo "<p>SunVision S/W SoftWare Technologies<br>";
  echo "Sec - 2A/15A<br>";
  echo "Vaishali Ghaziabad (UP)<br>";

  echo "Phone No : 0120-2322460<br>";
  echo "Email Address : hr@sunvisionst.com<br>";
  echo "WebSite : www.sunvisionst.com<br></p>";

  echo "</td>";
  echo "</tr>";

  echo "</table>";
  echo "</fieldset>";
  echo "</td>";

  echo "<tr>";
  echo "</table>";
?>
