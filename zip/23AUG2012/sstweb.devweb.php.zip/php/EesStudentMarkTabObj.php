<?


class EesStudentMarkTabObj
{
  public $tab_rowid;
  public $org_id;
  public $student_id;
  public $exam_id;
  public $subject_code;
  public $subject_type;
  public $subject_ctg;
  public $paper_id;
  public $class_id;
  public $class_num;
  public $class_std;
  public $class_section;
  public $course_id;
  public $course_term;
  public $course_stream;
  public $roll_num;
  public $enrollment_num;
  public $room_num;
  public $building_id;
  public $floor_num;
  public $seat_num;
  public $exam_term;
  public $exam_type;
  public $exam_date;
  public $session_id;
  public $exam_start_time;
  public $exam_end_time;
  public $pass_fail_ind;
  public $attendance_status;
  public $student_status;
  public $copy_checked_status;
  public $max_mark;
  public $obtained_mark;





  public $org_id_ind;
  public $student_id_ind;
  public $exam_id_ind;
  public $subject_code_ind;
  public $subject_type_ind;
  public $subject_ctg_ind;
  public $paper_id_ind;
  public $class_id_ind;
  public $class_num_ind;
  public $class_std_ind;
  public $class_section_ind;
  public $course_id_ind;
  public $course_term_ind;
  public $course_stream_ind;
  public $roll_num_ind;
  public $enrollment_num_ind;
  public $room_num_ind;
  public $building_id_ind;
  public $floor_num_ind;
  public $seat_num_ind;
  public $exam_term_ind;
  public $exam_type_ind;
  public $exam_date_ind;
  public $session_id_ind;
  public $exam_start_time_ind;
  public $exam_end_time_ind;
  public $pass_fail_ind_ind;
  public $attendance_status_ind;
  public $student_status_ind;
  public $copy_checked_status_ind;
  public $max_mark_ind;
  public $obtained_mark_ind;


  public function __construct(){}


  public function EesStudentMarkTabObj
  (
    $org_id,
    $student_id,
    $exam_id,
    $subject_code,
    $subject_type,
    $subject_ctg,
    $paper_id,
    $class_id,
    $class_num,
    $class_std,
    $class_section,
    $course_id,
    $course_term,
    $course_stream,
    $roll_num,
    $enrollment_num,
    $room_num,
    $building_id,
    $floor_num,
    $seat_num,
    $exam_term,
    $exam_type,
    $exam_date,
    $session_id,
    $exam_start_time,
    $exam_end_time,
    $pass_fail_ind,
    $attendance_status,
    $student_status,
    $copy_checked_status,
    $max_mark,
    $obtained_mark
  )
  {
     $this->org_id                          = $org_id;
     $this->student_id                      = $student_id;
     $this->exam_id                         = $exam_id;
     $this->subject_code                    = $subject_code;
     $this->subject_type                    = $subject_type;
     $this->subject_ctg                     = $subject_ctg;
     $this->paper_id                        = $paper_id;
     $this->class_id                        = $class_id;
     $this->class_num                       = $class_num;
     $this->class_std                       = $class_std;
     $this->class_section                   = $class_section;
     $this->course_id                       = $course_id;
     $this->course_term                     = $course_term;
     $this->course_stream                   = $course_stream;
     $this->roll_num                        = $roll_num;
     $this->enrollment_num                  = $enrollment_num;
     $this->room_num                        = $room_num;
     $this->building_id                     = $building_id;
     $this->floor_num                       = $floor_num;
     $this->seat_num                        = $seat_num;
     $this->exam_term                       = $exam_term;
     $this->exam_type                       = $exam_type;
     $this->exam_date                       = $exam_date;
     $this->session_id                      = $session_id;
     $this->exam_start_time                 = $exam_start_time;
     $this->exam_end_time                   = $exam_end_time;
     $this->pass_fail_ind                   = $pass_fail_ind;
     $this->attendance_status               = $attendance_status;
     $this->student_status                  = $student_status;
     $this->copy_checked_status             = $copy_checked_status;
     $this->max_mark                        = $max_mark;
     $this->obtained_mark                   = $obtained_mark;
  }

  public function getorg_id()                           { return $this->org_id; }
  public function getstudent_id()                       { return $this->student_id; }
  public function getexam_id()                          { return $this->exam_id; }
  public function getsubject_code()                     { return $this->subject_code; }
  public function getsubject_type()                     { return $this->subject_type; }
  public function getsubject_ctg()                      { return $this->subject_ctg; }
  public function getpaper_id()                         { return $this->paper_id; }
  public function getclass_id()                         { return $this->class_id; }
  public function getclass_num()                        { return $this->class_num; }
  public function getclass_std()                        { return $this->class_std; }
  public function getclass_section()                    { return $this->class_section; }
  public function getcourse_id()                        { return $this->course_id; }
  public function getcourse_term()                      { return $this->course_term; }
  public function getcourse_stream()                    { return $this->course_stream; }
  public function getroll_num()                         { return $this->roll_num; }
  public function getenrollment_num()                   { return $this->enrollment_num; }
  public function getroom_num()                         { return $this->room_num; }
  public function getbuilding_id()                      { return $this->building_id; }
  public function getfloor_num()                        { return $this->floor_num; }
  public function getseat_num()                         { return $this->seat_num; }
  public function getexam_term()                        { return $this->exam_term; }
  public function getexam_type()                        { return $this->exam_type; }
  public function getexam_date()                        { return $this->exam_date; }
  public function getsession_id()                       { return $this->session_id; }
  public function getexam_start_time()                  { return $this->exam_start_time; }
  public function getexam_end_time()                    { return $this->exam_end_time; }
  public function getpass_fail_ind()                    { return $this->pass_fail_ind; }
  public function getattendance_status()                { return $this->attendance_status; }
  public function getstudent_status()                   { return $this->student_status; }
  public function getcopy_checked_status()              { return $this->copy_checked_status; }
  public function getmax_mark()                         { return $this->max_mark; }
  public function getobtained_mark()                    { return $this->obtained_mark; }



  public function setorg_id($org_id )                                  { $this->org_id              = $org_id; }
  public function setstudent_id($student_id )                          { $this->student_id          = $student_id; }
  public function setexam_id($exam_id )                                { $this->exam_id             = $exam_id; }
  public function setsubject_code($subject_code )                      { $this->subject_code        = $subject_code; }
  public function setsubject_type($subject_type )                      { $this->subject_type        = $subject_type; }
  public function setsubject_ctg($subject_ctg )                        { $this->subject_ctg         = $subject_ctg; }
  public function setpaper_id($paper_id )                              { $this->paper_id            = $paper_id; }
  public function setclass_id($class_id )                              { $this->class_id            = $class_id; }
  public function setclass_num($class_num )                            { $this->class_num           = $class_num; }
  public function setclass_std($class_std )                            { $this->class_std           = $class_std; }
  public function setclass_section($class_section )                    { $this->class_section       = $class_section; }
  public function setcourse_id($course_id )                            { $this->course_id           = $course_id; }
  public function setcourse_term($course_term )                        { $this->course_term         = $course_term; }
  public function setcourse_stream($course_stream )                    { $this->course_stream       = $course_stream; }
  public function setroll_num($roll_num )                              { $this->roll_num            = $roll_num; }
  public function setenrollment_num($enrollment_num )                  { $this->enrollment_num      = $enrollment_num; }
  public function setroom_num($room_num )                              { $this->room_num            = $room_num; }
  public function setbuilding_id($building_id )                        { $this->building_id         = $building_id; }
  public function setfloor_num($floor_num )                            { $this->floor_num           = $floor_num; }
  public function setseat_num($seat_num )                              { $this->seat_num            = $seat_num; }
  public function setexam_term($exam_term )                            { $this->exam_term           = $exam_term; }
  public function setexam_type($exam_type )                            { $this->exam_type           = $exam_type; }
  public function setexam_date($exam_date )                            { $this->exam_date           = $exam_date; }
  public function setsession_id($session_id )                          { $this->session_id          = $session_id; }
  public function setexam_start_time($exam_start_time )                { $this->exam_start_time     = $exam_start_time; }
  public function setexam_end_time($exam_end_time )                    { $this->exam_end_time       = $exam_end_time; }
  public function setpass_fail_ind($pass_fail_ind )                    { $this->pass_fail_ind       = $pass_fail_ind; }
  public function setattendance_status($attendance_status )            { $this->attendance_status   = $attendance_status; }
  public function setstudent_status($student_status )                  { $this->student_status      = $student_status; }
  public function setcopy_checked_status($copy_checked_status )        { $this->copy_checked_status = $copy_checked_status; }
  public function setmax_mark($max_mark )                              { $this->max_mark            = $max_mark; }
  public function setobtained_mark($obtained_mark )                    { $this->obtained_mark       = $obtained_mark; }
}
?>
