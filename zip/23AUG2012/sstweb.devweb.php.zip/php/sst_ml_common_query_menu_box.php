<?php

    echo "<table border = '0' width = '100%'>";
   
    //START OF SUBJECT CHOICE
    if( $lMenuOption !== null && $lMenuOption == 'eesCourse')
    {
      echo "<tr>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=subList";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Subject List</a>";
      echo " </td>";
   
      /*
      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facAllocatedSub";
      echo "&course_id=$lCourseId'>Subject Instructor</a>";
      echo " </td>";
      */


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=stuList";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Student List</a>";
      echo " </td>";


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=feeStruct";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'";
      echo "'>Fee Structure</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=paidStud";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'";
      echo "'>Paid Student</a>";
      echo " </td>";

      echo "</tr>";
      echo "<tr>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=subProg";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Subject Progress</a>";
      echo " </td>";


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=classTT";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Class Timetable</a>";
      echo " </td>";


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=classAtten";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Class Attendance</a>";
      echo " </td>";


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facList";
      echo "&course_id=$lCourseId&sst_session_id=$lSessionId'>Faculty List</a>";
      echo " </td>";

      echo "</tr>";
    }
    //END OF SUBJECT CHOICE




    if( $lMenuOption !== null && $lMenuOption == 'eesStudent' )
    {
      echo "<tr>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=stuProfile";
      //echo "&stud_prof=$lStudentProfile'>Student Profile</a>";
      echo "&sst_session_id=$lSessionId'>Student Profile</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=stuMarkSheet";
      //echo "&stud_prof=$lStudentProfile'>Mark Sheet</a>";
      echo "&sst_session_id=$lSessionId'>Mark Sheet</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=stuAtten";
      //echo "&stud_prof=$lStudentProfile'>Attendance</a>";
      echo "&sst_session_id=$lSessionId'>Attendance</a>";
      echo " </td>";

      echo "</tr>";
    } 


    if( $lMenuOption !== null && $lMenuOption == 'eesFaculty' )
    {
      echo "<tr>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facProfile";
      //echo "&faculty=$lFacultyProfile'>Faculty Profile</a>";
      echo "&sst_session_id=$lSessionId'>Faculty Profile</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facTT";
      //echo "&faculty=$lFacultyProfile'>Faculty Timetable</a>";
      echo "&sst_session_id=$lSessionId'>Faculty Timetable</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facMarkEntry";
      //echo "&faculty=$lFacultyProfile'>Marks Entry</a>";
      echo "&sst_session_id=$lSessionId'>Marks Entry</a>";
      echo " </td>";

      echo "</tr>";
      echo "<tr>";


      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facAttnEntry";
      //echo "&faculty=$lFacultyProfile'>Attendance Entry</a>";
      echo "&sst_session_id=$lSessionId'>Attendance Entry</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facAllocatedSubject";
      //echo "&faculty=$lFacultyProfile'>Allocated Subject</a>";
      echo "&sst_session_id=$lSessionId'>Allocated Subject</a>";
      echo " </td>";

      echo " <td align = 'center'>";
      echo "  <a href = '../php/sst_ml_common_query_criteria_envelop.php?menu_option=$lMenuOption&req_type=facSubProgEntry";
      echo "&action=querySubmit'";
      //echo "&faculty=$lFacultyProfile'>Subject Progress Entry</a>";
      echo "&sst_session_id=$lSessionId'>Subject Progress Entry</a>";
      echo " </td>";

      echo "</tr>";
    }

    echo "</table>";
?>
