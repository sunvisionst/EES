<?
  //session_start();
{
  echo "<html>";


  echo "<head>";
  //---------------------------------------------------------------------------
  // COMMON HEAD PART - STARTS
  //---------------------------------------------------------------------------
  require_once("sst_ml_menu_list_box.php");
  require_once("GnUserTabObj.php");
  require_once("HrEmployeeTabObj.php");
  require_once("sst_ml_common_head_include.php");
  //---------------------------------------------------------------------------
  // COMMON HEAD PART - ENDS
  //---------------------------------------------------------------------------
  echo "</head>";

  $lOrgId        = "";
  $lSubmitAction = "";
  $lSessionId    = null;
  $lCurrentYear  = "";
  $lCurrentDate  = "";
  $lCurrentMonth = "";
  $lCheckUserQty = "";

  $lTodayDBDate  = "";
  $lTodayGUIDate = "";

  /*
   SETTING GLOBAL VARIABLES              
   FOR HR EPMLOYEE.
  */

  $lHrEmployeeTabObjGlobal    = new HrEmployeeTabObj();
  $lGnUserTabObj        = new GnUserTabObj();
  $lSSTMLAMenuMethodObj = new SSTMLAMenuMethodObj();


  echo "<body style=\"{ margin: 0px 0px 0px 0px; }\" name=\"ml_product_body\" id=\"ml_product_body\" width=\"100%\">";
  echo "<form method = \"post\" name = 'form' id = 'form'>";
  echo "<table name=\"ml_product_table\" id=\"ml_product_table\" width=\"100%\" border=\"0\">";




  //--------------------------------------------------------------------------
  // INCLUDE FOR UPPER  - STARTS
  //--------------------------------------------------------------------------
  include("sst_ml_upper.php");
  //--------------------------------------------------------------------------
  // INCLUDE FOR UPPER  - ENDS
  //--------------------------------------------------------------------------





  //--------------------------------------------------------------------------
  // INCLUDE FOR DATA - STARTS
  // - TWO TDs
  // - First TD for MENU
  // - Second TD for envelop_process
  //--------------------------------------------------------------------------

  echo "<tr>";

  echo "<td name=\"prod_data_td\" id=\"prod_data_td\" align=\"center\" colspan=\"3\" width=\"100%\">";
  echo "<table name=\"prod_data_tab\" id=\"prod_data_tab\" align=\"center\" width=\"100%\" border = \"0\">";
  echo "<tr>";


  //-------------------------------------------------------------------------
  // MENU FILE - STARTS
  //-------------------------------------------------------------------------
  echo "<td name=\"menu_list_td\" id=\"menu_list_td\" align=\"right\" width=\"20%\" valign=\"top\">";
  if(!isset($_SESSION['lHrEmployeeTabObjGlobal']))
    ;
  else
    $lSSTMLAMenuMethodObj->prepMenu($lGnUserTabObj->role_type, $lCheckUserQty, $lSessionId);
  echo "</td>";
  //-------------------------------------------------------------------------
  // MENU FILE - ENDS
  //-------------------------------------------------------------------------




  //-------------------------------------------------------------------------
  // ENVELOP PROCESS - STARTS
  //-------------------------------------------------------------------------
  echo "<td name=\"envelop_pro_td\" id=\"envelop_pro_td\" align=\"right\" width=\"100%\">"; 
  include ("sst_ml_ees_subject_progress_entry_envelop_process.php");
  echo "<td>";
  //-------------------------------------------------------------------------
  // ENVELOP PROCESS - ENDS
  //-------------------------------------------------------------------------


  echo "</tr>";

  echo "</table>";
  echo "</td>";
  echo "</tr>";

  //--------------------------------------------------------------------------
  // INCLUDE FOR DATA - ENDS 
  //--------------------------------------------------------------------------





  //--------------------------------------------------------------------------
  // INCLUDE FOR LOWER  - STARTS
  //--------------------------------------------------------------------------
  echo "<tr>";
  include ("sst_ml_lower.php");
  echo "</tr>";
  //--------------------------------------------------------------------------
  // INCLUDE FOR LOWER  - ENDS
  //--------------------------------------------------------------------------

  echo " </table>";
  echo "</form>";

  echo "</body>";
  echo "</html>";
}
?>
