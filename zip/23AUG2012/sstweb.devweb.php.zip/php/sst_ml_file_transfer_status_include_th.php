<?
   echo "<th>"; 
   echo "WeekDay"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "Location"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "File Name"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "Size"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "Access Time"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "Modified Time"; 
   echo "</th>"; 

   echo "<th>"; 
   echo "Create Time"; 
   echo "</th>"; 
?>
