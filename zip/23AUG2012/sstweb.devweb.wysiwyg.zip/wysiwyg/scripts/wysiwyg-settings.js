/********************************************************************
 * openWYSIWYG settings file Copyright (c) 2006 openWebWare.com
 * Contact us at devs@openwebware.com
 * This copyright notice MUST stay intact for use.
 *
 * $Id: wysiwyg-settings.js,v 1.4 2007/01/22 23:05:57 xhaggi Exp $
 ********************************************************************/

/*
 * Full featured setup used the openImageLibrary addon
 */
var full = new WYSIWYG.Settings();
//full.ImagesDir = "images/";
//full.PopupsDir = "popups/";
//full.CSSFile = "styles/wysiwyg.css";
full.Width = "85%"; 
full.Height = "250px";
// customize toolbar buttons
full.addToolbarElement("font", 3, 1); 
full.addToolbarElement("fontsize", 3, 2);
full.addToolbarElement("headings", 3, 3);
// openImageLibrary addon implementation
full.ImagePopupFile = "addons/imagelibrary/insert_image.php";
full.ImagePopupWidth = 600;
full.ImagePopupHeight = 245;

/*
 * Small Setup Example
 */
var small = new WYSIWYG.Settings();
small.Width = "350px";
small.Height = "100px";
small.DefaultStyle = "font-family: Arial; font-size: 12px; background-color: #AA99AA";
small.Toolbar[0] = new Array("font", "fontsize", "bold", "italic", "underline"); // small setup for toolbar 1
small.Toolbar[1] = ""; // disable toolbar 2
small.StatusBarEnabled = false;


/*
 * Small Setup Example
 */
var sst_he_setting = new WYSIWYG.Settings();
sst_he_setting.ImagesDir = "../wysiwyg/images/";
sst_he_setting.PopupsDir = "../wysiwyg/popups/";
sst_he_setting.CSSFile = "../wysiwyg/styles/wysiwyg.css";

sst_he_setting.Width = "85%";
sst_he_setting.Height = "250px";
// customize toolbar buttons
sst_he_setting.addToolbarElement("font", 3, 1);
sst_he_setting.addToolbarElement("fontsize", 3, 2);
sst_he_setting.addToolbarElement("headings", 3, 3);

// openImageLibrary addon implementation
sst_he_setting.ImagePopupFile = "../wysiwyg/addons/imagelibrary/insert_image.php";
sst_he_setting.ImagePopupWidth = 600;
sst_he_setting.ImagePopupHeight = 245;
sst_he_setting.addToolbarElement("font", 1, 1);
//WYSIWYG.attach('all', 'sst_he_setting');
alert( sst_he_setting.CSSFile +' 123456');

