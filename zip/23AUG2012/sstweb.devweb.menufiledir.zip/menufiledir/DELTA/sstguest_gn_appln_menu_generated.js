function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


menu[0] = new Array();
menu[0][0]  = new Menu(true, '', inLeftCoord, inTopCoord, inWidth, '#FF9933', '', '', 'itemText');
menu[0][1]  = new Item('Human Resourse', 'NA.html', '', defLength, 0, 1 );
menu[0][2]  = new Item('Emp Productivity', 'NA.html', '', defLength, 0, 2 );
menu[0][3]  = new Item('Admission', 'NA.html', '', defLength, 0, 3 );
menu[0][4]  = new Item('Fee', 'NA.html', '', defLength, 0, 4 );
menu[0][5]  = new Item('Academic', 'NA.html', '', defLength, 0, 5 );
menu[0][6]  = new Item('Timetable', 'NA.html', '', defLength, 0, 6 );
menu[0][7]  = new Item('Exam', 'NA.html', '', defLength, 0, 7 );
menu[0][8]  = new Item('Alumini', 'NA.html', '', defLength, 0, 8 );
menu[0][9]  = new Item('Hostel', 'NA.html', '', defLength, 0, 9 );
menu[0][10]  = new Item('Mess', 'NA.html', '', defLength, 0, 10 );
menu[0][11]  = new Item('Transport', 'NA.html', '', defLength, 0, 11 );
menu[0][12]  = new Item('Fine and Disc', 'NA.html', '', defLength, 0, 12 );
menu[0][13]  = new Item('Lab', 'NA.html', '', defLength, 0, 13 );
menu[0][14]  = new Item('Library', 'NA.html', '', defLength, 0, 14 );
menu[0][15]  = new Item('T & P', 'NA.html', '', defLength, 0, 15 );
menu[0][16]  = new Item('HRMS', 'NA.html', '', defLength, 0, 16 );
menu[0][17]  = new Item('Finance', 'NA.html', '', defLength, 0, 17 );
menu[0][18]  = new Item('MIS Reports', 'NA.html', '', defLength, 0, 18 );
menu[0][19]  = new Item('UPTU Interface', 'http://www.uptu.org', '', defLength, 0, 0 );
menu[0][20]  = new Item('Payroll', 'NA.html', '', defLength, 0, 20 );
menu[0][21]  = new Item('Customer Care and Billing', 'NA.html', '', defLength, 0, 21 );
menu[0][22]  = new Item('AR and Collection', 'NA.html', '', defLength, 0, 22 );
menu[0][23]  = new Item('Training', 'NA.html', '', defLength, 0, 23 );
menu[0][24]  = new Item('Recruitment', 'NA.html', '', defLength, 0, 24 );
menu[0][25]  = new Item('Event', 'NA.html', '', defLength, 0, 25 );
menu[0][26]  = new Item('Scholorship', 'NA.html', '', defLength, 0, 26 );
menu[0][27]  = new Item('Grant', 'NA.html', '', defLength, 0, 27 );
menu[0][28]  = new Item('Budget Mgt', 'NA.html', '', defLength, 0, 28 );
menu[0][29]  = new Item('User Mgt', 'NA.html', '', defLength, 0, 29 );
menu[0][30]  = new Item('Administrator', 'NA.html', '', defLength, 0, 30 );
menu[0][31]  = new Item('Sunvision Admin', 'NA.html', '', defLength, 0, 31 );
menu[0][32]  = new Item('Followup Mgt', 'NA.html', '', defLength, 0, 32 );
menu[0][33]  = new Item('Order Mgt', 'NA.html', '', defLength, 0, 33 );
menu[0][34]  = new Item('Store Mgt', 'NA.html', '', defLength, 0, 34 );

menu[1] = new Array();
menu[1][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[1][1]  = new Item('Infrastructure', 'NA.html', '', defLength, 0, 38 );
menu[1][2]  = new Item('Department', 'NA.html', '', defLength, 0, 39 );
menu[1][3]  = new Item('Employee Profile', 'NA.html', '', defLength, 0, 40 );
menu[1][4]  = new Item('HR Reports', 'NA.html', '', defLength, 0, 0 );

menu[2] = new Array();
menu[2][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[2][1]  = new Item('Task Planning', '../servlet/hr_job_dtl?menuOption=hrJobPlan', '', defLength, 0, 0 );
menu[2][2]  = new Item('Task Allocation', '../servlet/hr_job_dtl?menuOption=hrJobAlloc', '', defLength, 0, 0 );
menu[2][3]  = new Item('Task Monitoring-Admin', '../servlet/hr_job_dtl?menuOption=hrJobMonitorDeptWise', '', defLength, 0, 0 );
menu[2][4]  = new Item('Task Monitoring-Self', '../servlet/hr_job_dtl?menuOption=hrJobMonitorEmpWise', '', defLength, 0, 0 );
menu[2][5]  = new Item('Report and Query', 'NA.html', '', defLength, 0, 764 );

menu[3] = new Array();
menu[3][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[3][1]  = new Item('Admin Process', 'NA.html', '', defLength, 0, 77 );
menu[3][2]  = new Item('Online Process', 'NA.html', '', defLength, 0, 78 );
menu[3][3]  = new Item('Admission Pro', 'NA.html', '', defLength, 0, 79 );
menu[3][4]  = new Item('Prospectus', 'NA.html', '', defLength, 0, 80 );
menu[3][5]  = new Item('Selection Process', 'NA.html', '', defLength, 0, 81 );
menu[3][6]  = new Item('Admit Card', 'NA.html', '', defLength, 0, 82 );
menu[3][7]  = new Item('Direct Selection', 'NA.html', '', defLength, 0, 83 );
menu[3][8]  = new Item('Admission Process', 'NA.html', '', defLength, 0, 84 );
menu[3][9]  = new Item('Student Profile', 'NA.html', '', defLength, 0, 85 );
menu[3][10]  = new Item('Adm Reports', 'NA.html', '', defLength, 0, 86 );

menu[4] = new Array();
menu[4][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[4][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 87 );
menu[4][2]  = new Item('Ledger', 'NA.html', '', defLength, 0, 88 );
menu[4][3]  = new Item('Fee Process', 'NA.html', '', defLength, 0, 89 );
menu[4][4]  = new Item('Fee Reports and Query', 'NA.html', '', defLength, 0, 90 );

menu[5] = new Array();
menu[5][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[5][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 49 );
menu[5][2]  = new Item('Upload Syllabus', '../servlet/ees_lecture_plan?menuOption=uploadSylb', '', defLength, 0, 0 );
menu[5][3]  = new Item('Subject Allocation', 'NA.html', '', defLength, 0, 51 );
menu[5][4]  = new Item('Academic Reports', 'NA.html', '', defLength, 0, 52 );

menu[6] = new Array();
menu[6][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[6][1]  = new Item('Timetable Preparation', 'NA.html', '', defLength, 0, 349 );
menu[6][2]  = new Item('ADR', 'NA.html', '', defLength, 0, 350 );
menu[6][3]  = new Item('TT Report and Query', 'NA.html', '', defLength, 0, 351 );

menu[7] = new Array();
menu[7][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[7][1]  = new Item('Exam Admin', 'NA.html', '', defLength, 0, 67 );
menu[7][2]  = new Item('Exam Mgt', 'NA.html', '', defLength, 0, 68 );
menu[7][3]  = new Item('Exam Result', 'NA.html', '', defLength, 0, 69 );
menu[7][4]  = new Item('Question Model Paper', '../servlet/ees_exam_question?menuOption=eesExamQuestionModelPaper', '', defLength, 0, 0 );
menu[7][5]  = new Item('Exam Reports', 'NA.html', '', defLength, 0, 71 );
menu[7][6]  = new Item('Upgrade Student', '../servlet/ees_student?menuOption=upgradeStudent', '', defLength, 0, 0 );

menu[8] = new Array();
menu[8][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[8][1]  = new Item('Login', '../servlet/ees_alumni?menuOption=eesAlumniRegistration', '', defLength, 0, 0 );
menu[8][2]  = new Item('From Student DB', '../servlet/ees_alumni?menuOption=eesAlumniImportfromStudent', '', defLength, 0, 0 );
menu[8][3]  = new Item('Memories', 'NA.html', '', defLength, 0, 132 );
menu[8][4]  = new Item('Alumni Reports', 'NA.html', '', defLength, 0, 133 );

menu[9] = new Array();
menu[9][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[9][1]  = new Item('Hostel Master', 'NA.html', '', defLength, 0, 91 );
menu[9][2]  = new Item('Update Warden', '../servlet/ees_hostel?menuOption=eesHostelWardenUpdate', '', defLength, 0, 0 );
menu[9][3]  = new Item('Set Hostel', '../servlet/ees_hostel?menuOption=eesHostelLogin', '', defLength, 0, 0 );
menu[9][4]  = new Item('Hostel Reg Form', '../servlet/ees_student?menuOption=hostelReg', '', defLength, 0, 0 );
menu[9][5]  = new Item('Room Allotment', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[9][6]  = new Item('Outsider Allotment', '../servlet/ees_hostel_bed?menuOption=eesHostelBedOutsiderStay', '', defLength, 0, 0 );
menu[9][7]  = new Item('Assign Locker', '../servlet/ees_locker?menuOption=eesLocker', '', defLength, 0, 0 );
menu[9][8]  = new Item('Visitor Profile', '../servlet/ees_hostel_visitor?menuOption=eesHostelVisitor', '', defLength, 0, 0 );
menu[9][9]  = new Item('Hostel Summary', '../servlet/ees_hostel_bed?menuOption=eesHostelSummary', '', defLength, 0, 0 );
menu[9][10]  = new Item('Room Deallocation', '../servlet/ees_hostel_bed?menuOption=suspExpul', '', defLength, 0, 0 );
menu[9][11]  = new Item('Exit Entry Reg', '../servlet/ees_hostel_exit_entry_reg?menuOption=eesHostelEntryTime', '', defLength, 0, 0 );
menu[9][12]  = new Item('Visitor Register', 'NA.html', '', defLength, 0, 102 );
menu[9][13]  = new Item('Operate Locker', '../servlet/ees_locker_use?menuOption=eesLockerUse', '', defLength, 0, 0 );
menu[9][14]  = new Item('Complain Register', 'NA.html', '', defLength, 0, 104 );
menu[9][15]  = new Item('Hostel Attn Reg', '../servlet/ees_hostel_attn_reg?menuOption=eesHostelAttnReg', '', defLength, 0, 0 );
menu[9][16]  = new Item('Baggage In', '../servlet/ees_hostel_bs?menuOption=eesHostelBsIn', '', defLength, 0, 0 );
menu[9][17]  = new Item('Baggage Out', '../servlet/ees_hostel_bs?menuOption=eesHostelBsOut', '', defLength, 0, 0 );
menu[9][18]  = new Item('Room Change(obso)', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[9][19]  = new Item('Room Change', '../servlet/ees_hostel_bed?menuOption=hrc', '', defLength, 0, 0 );
menu[9][20]  = new Item('Room Type Conversion', '../servlet/ees_hostel_room?menuOption=convRoomType', '', defLength, 0, 0 );
menu[9][21]  = new Item('Hostel Item', '../servlet/ees_hostel_item?menuOption=eesHostelItem', '', defLength, 0, 0 );
menu[9][22]  = new Item('Hostel Staff', '../servlet/ees_hostel_warden?menuOption=eesHostelWarden', '', defLength, 0, 0 );
menu[9][23]  = new Item('Warden History', '../servlet/ees_hostel_warden_hist?menuOption=eesHostelWardenHist', '', defLength, 0, 0 );
menu[9][24]  = new Item('Remove Hostel', '../servlet/ees_hostel?menuOption=eesHostelRemove', '', defLength, 0, 0 );
menu[9][25]  = new Item('Hostel Reports', 'NA.html', '', defLength, 0, 115 );

menu[10] = new Array();
menu[10][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[10][1]  = new Item('Mess Admin', 'NA.html', '', defLength, 0, 735 );
menu[10][2]  = new Item('Diet Register', '../servlet/ees_mess_diet_reg?menuOption=eesMessDietReg', '', defLength, 0, 0 );
menu[10][3]  = new Item('Mess Bill', '../servlet/ees_mess_fee?menuOption=eesMessFee', '', defLength, 0, 0 );
menu[10][4]  = new Item('Mess Payment', '../servlet/ees_mess_fee?menuOption=eesMessFee', '', defLength, 0, 0 );

menu[11] = new Array();
menu[11][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[11][1]  = new Item('Contract', '../servlet/ees_contract?menuOption=eesContract', '', defLength, 0, 0 );
menu[11][2]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 0 );
menu[11][3]  = new Item('Vehicle Driver', '../servlet/ees_vehicle_driver?menuOption=eesVehicleDriver', '', defLength, 0, 0 );
menu[11][4]  = new Item('Vehicle Location', '../servlet/ees_vehicle_location?menuOption=eesVehicleLocation', '', defLength, 0, 0 );
menu[11][5]  = new Item('Route', 'NA.html', '', defLength, 0, 175 );
menu[11][6]  = new Item('Student Trip', '../servlet/ees_student_trip?menuOption=eesStudentTrip', '', defLength, 0, 0 );
menu[11][7]  = new Item('Student Route Trip', '../servlet/ees_student_trip?menuOption=eesStudentRouteStoppageTrip', '', defLength, 0, 0 );
menu[11][8]  = new Item('Transport Fee (stopwise)', '../servlet/ees_tp_fee?menuOption=eesTpFee', '', defLength, 0, 0 );
menu[11][9]  = new Item('Issue Trip Work Order', '../servlet/ees_daily_trip?menuOption=eesDailyTrip', '', defLength, 0, 0 );
menu[11][10]  = new Item('Transport Reports', 'NA.html', '', defLength, 0, 180 );

menu[12] = new Array();
menu[12][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[12][1]  = new Item('General Discipline', '../servlet/ees_gen_disc?menuOption=eesGenDisc', '', defLength, 0, 0 );
menu[12][2]  = new Item('Disciplinary Action', '../servlet/ees_gen_disc_act?menuOption=eesGenDiscAct', '', defLength, 0, 0 );

menu[13] = new Array();
menu[13][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[13][1]  = new Item('Login', '../servlet/ees_lab?menuOption=loginLab', '', defLength, 0, 0 );
menu[13][2]  = new Item('Lab Admin', 'NA.html', '', defLength, 0, 135 );
menu[13][3]  = new Item('Lab Automation', 'NA.html', '', defLength, 0, 136 );
menu[13][4]  = new Item('Student Attendance', '../servlet/ees_lab_its?action=ees_go_lab_attendence_submit&menuOption=kkkkkk', '', defLength, 0, 0 );
menu[13][5]  = new Item('Lab Report', 'NA.html', '', defLength, 0, 138 );
menu[13][6]  = new Item('History Report', 'NA.html', '', defLength, 0, 139 );

menu[14] = new Array();
menu[14][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[14][1]  = new Item('Library Admin', 'NA.html', '', defLength, 0, 454 );
menu[14][2]  = new Item('Issue and Return', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssue', '', defLength, 0, 0 );
menu[14][3]  = new Item('Attendance', '../servlet/ees_lib_attn_reg?menuOption=eesLibAttnReg', '', defLength, 0, 0 );
menu[14][4]  = new Item('Query and Report', 'NA.html', '', defLength, 0, 457 );

menu[15] = new Array();
menu[15][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[15][1]  = new Item('TNP Admin', 'NA.html', '', defLength, 0, 119 );
menu[15][2]  = new Item('Company Followup', '../servlet/ees_tnp_cfr?menuOption=tnpCFR', '', defLength, 0, 0 );
menu[15][3]  = new Item('Interview Detail', 'NA.html', '', defLength, 0, 121 );
menu[15][4]  = new Item('List', 'NA.html', '', defLength, 0, 122 );
menu[15][5]  = new Item('Training Detail', '../servlet/ees_training_sch?menuOption=trainingSch', '', defLength, 0, 0 );
menu[15][6]  = new Item('Select Student', '../servlet/ees_tnp_ci_student?menuOption=selectedStudent', '', defLength, 0, 0 );
menu[15][7]  = new Item('TNP Reports', 'NA.html', '', defLength, 0, 125 );
menu[15][8]  = new Item('Trainee (Student -> TNP)', '../servlet/ees_tnp_ci_student?menuOption=prepTraineeList', '', defLength, 0, 0 );
menu[15][9]  = new Item('Assign Project Mentor', '../servlet/ees_tnp_ci_student?menuOption=assignMentor', '', defLength, 0, 0 );
menu[15][10]  = new Item('Edit Project Detail', '../servlet/ees_tnp_ci_student?menuOption=projectDtlSelf', '', defLength, 0, 0 );
menu[15][11]  = new Item('Edit Project Detail (Admin)', '../servlet/ees_tnp_ci_student?menuOption=projectDtlAdmin', '', defLength, 0, 0 );

menu[16] = new Array();
menu[16][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[16][1]  = new Item('Administrator', 'NA.html', '', defLength, 0, 469 );
menu[16][2]  = new Item('Increment Promotion', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 470 );
menu[16][3]  = new Item('Income Deduction', 'NA.html', '', defLength, 0, 471 );
menu[16][4]  = new Item('Expn Reimbursement', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 472 );
menu[16][5]  = new Item('Time Management', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 473 );
menu[16][6]  = new Item('Leave Management', 'NA.html', '', defLength, 0, 474 );
menu[16][7]  = new Item('Loan Management', 'NA.html', '', defLength, 0, 475 );
menu[16][8]  = new Item('Emp Self Care', 'NA.html', '', defLength, 0, 476 );
menu[16][9]  = new Item('Manager Self Care', 'NA.html', '', defLength, 0, 477 );
menu[16][10]  = new Item('Travel Management', 'NA.html', '', defLength, 0, 478 );
menu[16][11]  = new Item('Shift Management', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 479 );
menu[16][12]  = new Item('Transfer Management', 'NA.html', '', defLength, 0, 480 );

menu[17] = new Array();
menu[17][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[17][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 73 );
menu[17][2]  = new Item('Voucher', 'NA.html', '', defLength, 0, 74 );
menu[17][3]  = new Item('Ledger Master', 'NA.html', '', defLength, 0, 75 );
menu[17][4]  = new Item('Finance Report', 'NA.html', '', defLength, 0, 76 );

menu[18] = new Array();
menu[18][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[18][1]  = new Item('General', 'NA.html', '', defLength, 0, 0 );
menu[18][2]  = new Item('HR Reports', 'NA.html', '', defLength, 0, 449 );
menu[18][3]  = new Item('CC and B', 'NA.html', '', defLength, 0, 450 );
menu[18][4]  = new Item('Recruitment', 'NA.html', '', defLength, 0, 0 );
menu[18][5]  = new Item('Training', 'NA.html', '', defLength, 0, 452 );
menu[18][6]  = new Item('Payroll', 'NA.html', '', defLength, 0, 453 );

menu[19] = new Array();
menu[19][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[20] = new Array();
menu[20][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[20][1]  = new Item('Salary Head', '../servlet/hr_salary_head?menuOption=hrSalaryHead', '', defLength, 0, 0 );
menu[20][2]  = new Item('Statewise Wages', '../servlet/hr_wages_statewise?menuOption=hrWagesStatewise', '', defLength, 0, 0 );
menu[20][3]  = new Item('Emp Agreement', '../servlet/hr_emp_agreement?menuOption=hrEmpAgreement', '', defLength, 0, 0 );
menu[20][4]  = new Item('Apr Emp Agreement', '../servlet/hr_emp_agreement?menuOption=hrEmpAgreementPendingApproval', '', defLength, 0, 0 );
menu[20][5]  = new Item('Tax Mgt', 'NA.html', '', defLength, 0, 244 );
menu[20][6]  = new Item('Sal Advance', 'NA.html', '', defLength, 0, 245 );
menu[20][7]  = new Item('Sal Prep', 'NA.html', '', defLength, 0, 246 );
menu[20][8]  = new Item('Custwise Salary Prep', '../servlet/hr_emp_salary_ledger?menuOption=prepSalaryCustwise', '', defLength, 0, 0 );

menu[21] = new Array();
menu[21][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[21][1]  = new Item('Define Customer', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );
menu[21][2]  = new Item('Cust Agr Form', '../servlet/hr_cust_agreement?menuOption=hrCustAgrForm', '', defLength, 0, 0 );
menu[21][3]  = new Item('Customer Agreement', '../servlet/hr_cust_agreement?menuOption=hrCustAgreement', '', defLength, 0, 0 );
menu[21][4]  = new Item('Allocate Resource', '../servlet/hr_cust_agreement?menuOption=outsourceEmployee', '', defLength, 0, 0 );
menu[21][5]  = new Item('Attn - Customerwise', '../servlet/hr_timesheet?menuOption=clientWiseAttn', '', defLength, 0, 0 );
menu[21][6]  = new Item('Open Bill Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[21][7]  = new Item('Bill Prepration', '../servlet/esm_cusomer_billing?menuOption=customerBillPrep', '', defLength, 0, 0 );
menu[21][8]  = new Item('Bill Q&A', '../servlet/esm_cusomer_billing?menuOption=customerBillQA', '', defLength, 0, 0 );
menu[21][9]  = new Item('Bill Print', '../servlet/esm_cusomer_billing?menuOption=customerBillPrint', '', defLength, 0, 0 );
menu[21][10]  = new Item('Bill Cycle Close', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycleClose', '', defLength, 0, 0 );
menu[21][11]  = new Item('Release Resource', '../servlet/hr_cust_agreement?menuOption=releaseResource', '', defLength, 0, 0 );

menu[22] = new Array();
menu[22][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[22][1]  = new Item('Payment Collection', '../servlet/esm_cusomer_payment?menuOption=customerPayment', '', defLength, 0, 0 );

menu[23] = new Array();
menu[23][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[23][1]  = new Item('Pre-Training Tasks', 'NA.html', '', defLength, 0, 534 );
menu[23][2]  = new Item('Post-Training Tasks', 'NA.html', '', defLength, 0, 535 );

menu[24] = new Array();
menu[24][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[24][1]  = new Item('Recruitment Admin', 'NA.html', '', defLength, 0, 248 );
menu[24][2]  = new Item('Pre Advert', 'NA.html', '', defLength, 0, 249 );
menu[24][3]  = new Item('Post Advert', 'NA.html', '', defLength, 0, 250 );

menu[25] = new Array();
menu[25][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[25][1]  = new Item('Event Detail', '../servlet/ees_event?menuOption=eesEvent', '', defLength, 0, 0 );
menu[25][2]  = new Item('Event Contact', '../servlet/ees_event_contact?menuOption=eesEventContact', '', defLength, 0, 0 );
menu[25][3]  = new Item('Event Guest Reg', '../servlet/ees_event?menuOption=eesEventRegGuest', '', defLength, 0, 0 );
menu[25][4]  = new Item('Event Activity', '../servlet/ees_event?menuOption=eesEventActivity', '', defLength, 0, 0 );
menu[25][5]  = new Item('Event Stud Reg', '../servlet/ees_event?menuOption=eesEventRegStud', '', defLength, 0, 0 );
menu[25][6]  = new Item('Event Listing', '../servlet/ees_event?menuOption=eventListing', '', defLength, 0, 0 );
menu[25][7]  = new Item('Award', 'NA.html', '', defLength, 0, 0 );
menu[25][8]  = new Item('Event Reports', 'NA.html', '', defLength, 0, 0 );

menu[26] = new Array();
menu[26][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[26][1]  = new Item('Define SchShip', '../servlet/ees_sch_ship?menuOption=eesSchShip', '', defLength, 0, 0 );
menu[26][2]  = new Item('Stud SchShip', '../servlet/ees_student_sch_ship?menuOption=eesStudentSchShip', '', defLength, 0, 0 );
menu[26][3]  = new Item('Class SchShip', '../servlet/ees_class_sch_ship?menuOption=eesClassSchShip', '', defLength, 0, 0 );
menu[26][4]  = new Item('Search', '../servlet/ees_student_sch_ship?menuOption=schQuery', '', defLength, 0, 0 );
menu[26][5]  = new Item('Scship Reports', 'NA.html', '', defLength, 0, 0 );

menu[27] = new Array();
menu[27][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[27][1]  = new Item('Define Granter', '../servlet/ees_granter?menuOption=eesGranter', '', defLength, 0, 0 );
menu[27][2]  = new Item('Define Grant', '../servlet/ees_grant?menuOption=eesGrant', '', defLength, 0, 0 );
menu[27][3]  = new Item('Grant Inst', '../servlet/ees_grant_inst?menuOption=eesGrantInst', '', defLength, 0, 0 );
menu[27][4]  = new Item('Grant Reports', 'NA.html', '', defLength, 0, 0 );

menu[28] = new Array();
menu[28][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[28][1]  = new Item('Allocate Budget', '../servlet/hr_budget_code?menuOption=hrBudgetMgt', '', defLength, 0, 0 );
menu[28][2]  = new Item('Budget Tracking', '../servlet/hr_budget_code?menuOption=hrBudgetMap', '', defLength, 0, 0 );
menu[28][3]  = new Item('Report and Query', 'NA.html', '', defLength, 0, 734 );

menu[29] = new Array();
menu[29][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[29][1]  = new Item('Role Type', '../servlet/gn_user_role?menuOption=gnUserRole', '', defLength, 0, 0 );
menu[29][2]  = new Item('Appln Security', 'NA.html', '', defLength, 0, 741 );
menu[29][3]  = new Item('Menu Option', '../servlet/gn_appln_menu?menuOption=gnApplnMenu', '', defLength, 0, 0 );
menu[29][4]  = new Item('Permission-Rolewise', '../servlet/gn_appln_menu?menuOption=rolewiseMenuPermission', '', defLength, 0, 0 );
menu[29][5]  = new Item('Permission-Userwise', '../servlet/gn_appln_menu?menuOption=menuPermission', '', defLength, 0, 0 );
menu[29][6]  = new Item('Bulk Gen Menu', '../servlet/gn_appln_menu?menuOption=bulkMenuGen', '', defLength, 0, 0 );

menu[30] = new Array();
menu[30][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[30][1]  = new Item('Sys Config', 'NA.html', '', defLength, 0, 35 );
menu[30][2]  = new Item('Portal Page', 'NA.html', '', defLength, 0, 36 );
menu[30][3]  = new Item('Backup and Restore', 'NA.html', '', defLength, 0, 37 );

menu[31] = new Array();
menu[31][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[31][1]  = new Item('Type Parameter', 'NA.html', '', defLength, 0, 161 );
menu[31][2]  = new Item('Application Menu', 'NA.html', '', defLength, 0, 162 );
menu[31][3]  = new Item('Product Testing', 'NA.html', '', defLength, 0, 163 );
menu[31][4]  = new Item('Geo Location', 'NA.html', '', defLength, 0, 164 );
menu[31][5]  = new Item('Sys Config', 'NA.html', '', defLength, 0, 165 );
menu[31][6]  = new Item('User Productivity Report', 'NA.html', '', defLength, 0, 0 );

menu[32] = new Array();
menu[32][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[32][1]  = new Item('Sales Followup', '../servlet/esm_gen_cfr?menuOption=esmGenCfr', '', defLength, 0, 0 );

menu[33] = new Array();
menu[33][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[33][1]  = new Item('Purchase Order', 'NA.html', '', defLength, 0, 747 );
menu[33][2]  = new Item('Report and Query', 'NA.html', '', defLength, 0, 748 );

menu[34] = new Array();
menu[34][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[34][1]  = new Item('Store Item', '../servlet/esm_item?menuOption=esmStoreItem', '', defLength, 0, 0 );
menu[34][2]  = new Item('Issue Item', '../servlet/esm_si_order?menuOption=esmSiOrder', '', defLength, 0, 0 );
menu[34][3]  = new Item('Report and Query', 'NA.html', '', defLength, 0, 0 );

menu[35] = new Array();
menu[35][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[35][1]  = new Item('Sequence Param', '../servlet/sst_config?menuOption=esmSeqList', '', defLength, 0, 0 );
menu[35][2]  = new Item('Holiday', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[35][3]  = new Item('Change Password', '../servlet/gn_login?menuOption=changePassword', '', defLength, 0, 0 );

menu[36] = new Array();
menu[36][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[36][1]  = new Item('Client Logo', '../servlet/ees_home_college_desc?menuOption=clientLogo', '', defLength, 0, 0 );
menu[36][2]  = new Item('Main Banner', '../servlet/ees_home_college_desc?menuOption=mainBanner', '', defLength, 0, 0 );
menu[36][3]  = new Item('Bottom Login Box', '../servlet/ees_home_college_desc?menuOption=bottomLoginBox', '', defLength, 0, 0 );
menu[36][4]  = new Item('Change Style', '../servlet/gn_lnf_template?menuOption=gnLnfTemplate', '', defLength, 0, 0 );
menu[36][5]  = new Item('Edit College Desc', '../servlet/ees_home_college_desc?menuOption=eesHomeCollegeDesc', '', defLength, 0, 0 );
menu[36][6]  = new Item('Edit Right To Info', '../servlet/ees_home_right_to_info?menuOption=eesHomeRightToInfo', '', defLength, 0, 0 );

menu[37] = new Array();
menu[37][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[37][1]  = new Item('Appln Backup', '../servlet/sst_admin_servlet?menuOption=applnBkp', '', defLength, 0, 0 );
menu[37][2]  = new Item('Database Backup', '../servlet/sst_admin_servlet?menuOption=databaseBkp', '', defLength, 0, 0 );
menu[37][3]  = new Item('Restore Database Backup', '../servlet/sst_admin_servlet?menuOption=dbRestore', '', defLength, 0, 0 );

menu[38] = new Array();
menu[38][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[38][1]  = new Item('Organization', '../servlet/hr_organization?menuOption=hrOrganization', '', defLength, 0, 0 );
menu[38][2]  = new Item('Building and Room', '../servlet/hr_building?menuOption=hrBuilding', '', defLength, 0, 0 );
menu[38][3]  = new Item('Bldg Room (obso)', '../servlet/hr_building_room?menuOption=hrBuildingRoom', '', defLength, 0, 0 );

menu[39] = new Array();
menu[39][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[39][1]  = new Item('Define Department', '../servlet/hr_department?menuOption=hrDepartment', '', defLength, 0, 0 );

menu[40] = new Array();
menu[40][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[40][1]  = new Item('Create Profile', '../servlet/hr_employee?menuOption=createProfile', '', defLength, 0, 0 );
menu[40][2]  = new Item('Update Profile(H)', 'NA.html', '', defLength, 0, 43 );
menu[40][3]  = new Item('View Profile(H)', 'NA.html', '', defLength, 0, 44 );

menu[41] = new Array();
menu[41][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[42] = new Array();
menu[42][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[43] = new Array();
menu[43][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[43][1]  = new Item('Self', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[43][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaUpd', '', defLength, 0, 0 );

menu[44] = new Array();
menu[44][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[44][1]  = new Item('Self', '../servlet/hr_employee?menuOption=viewOwnProfile', '', defLength, 0, 0 );
menu[44][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaQry', '', defLength, 0, 0 );

menu[45] = new Array();
menu[45][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[46] = new Array();
menu[46][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[47] = new Array();
menu[47][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[48] = new Array();
menu[48][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[49] = new Array();
menu[49][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[49][1]  = new Item('Acad Session (ADM)', '../servlet/ees_academic_session?menuOption=eesAcademicSession', '', defLength, 0, 0 );
menu[49][2]  = new Item('Class Section', '../servlet/gn_type_code?action=gn_type_code_check_exist_show&id_type=CLASSSEC', '', defLength, 0, 0 );
menu[49][3]  = new Item('Define Period', '../servlet/ees_period?menuOption=eesPeriod', '', defLength, 0, 0 );
menu[49][4]  = new Item('Define Course', '../servlet/ees_course?menuOption=eesCourse', '', defLength, 0, 0 );
menu[49][5]  = new Item('Define Class', '../servlet/ees_class?menuOption=eesClass', '', defLength, 0, 0 );
menu[49][6]  = new Item('Class Teacher', '../servlet/ees_class?menuOption=eesClassTeacher', '', defLength, 0, 0 );
menu[49][7]  = new Item('Room Class', '../servlet/ees_class?menuOption=eesRoomClass', '', defLength, 0, 0 );
menu[49][8]  = new Item('Define Subject', '../servlet/ees_subject?menuOption=eesSubject', '', defLength, 0, 0 );
menu[49][9]  = new Item('Close Semester', '../servlet/ees_lab_its?menuOption=semClose', '', defLength, 0, 0 );

menu[50] = new Array();
menu[50][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[51] = new Array();
menu[51][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[51][1]  = new Item('Subject Choice-self', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoiceFacultywise', '', defLength, 0, 0 );
menu[51][2]  = new Item('Subject Choice-Admin', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoiceByAdmin', '', defLength, 0, 0 );
menu[51][3]  = new Item('Subject Distribution', '../servlet/ees_subject_allocation?menuOption=eesSubjectDistribution', '', defLength, 0, 0 );
menu[51][4]  = new Item('Sub Alloc (Direct)', '../servlet/ees_subject_allocation?menuOption=eesSubjectDistribution', '', defLength, 0, 0 );
menu[51][5]  = new Item('Choice From Faculty(obso)', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoice', '', defLength, 0, 0 );
menu[51][6]  = new Item('Admin Subject Choice(obso)', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoiceView', '', defLength, 0, 0 );

menu[52] = new Array();
menu[52][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[52][1]  = new Item('Class Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassWiseList', '', defLength, 0, 0 );
menu[52][2]  = new Item('Subject Detail', '../servlet/ees_subject?menuOption=subjectReport', '', defLength, 0, 0 );
menu[52][3]  = new Item('Subject Allocation', '../servlet/ees_academic_report?menuOption=eesAcademicSubjectAllocationReport', '', defLength, 0, 0 );
menu[52][4]  = new Item('Faculty Performance', '../servlet/ees_adr?menuOption=eesAdrFacultyProgressReport', '', defLength, 0, 0 );
menu[52][5]  = new Item('Class Teacher Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassTeacherWiseList', '', defLength, 0, 0 );
menu[52][6]  = new Item('Student Listing', '../servlet/ees_academic_report?menuOption=eesAcademicStudentListReport', '', defLength, 0, 0 );
menu[52][7]  = new Item('Subject Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassWiseSubjectList', '', defLength, 0, 0 );
menu[52][8]  = new Item('Subject Choice List', '../servlet/ees_academic_report?menuOption=eesAcademicSubjectChoiceList', '', defLength, 0, 0 );
menu[52][9]  = new Item('Period List', '../servlet/ees_academic_report?menuOption=eesAcademicPeriodList', '', defLength, 0, 0 );

menu[53] = new Array();
menu[53][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[54] = new Array();
menu[54][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[55] = new Array();
menu[55][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[56] = new Array();
menu[56][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[57] = new Array();
menu[57][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[58] = new Array();
menu[58][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[59] = new Array();
menu[59][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[60] = new Array();
menu[60][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[61] = new Array();
menu[61][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[62] = new Array();
menu[62][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[63] = new Array();
menu[63][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[64] = new Array();
menu[64][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[65] = new Array();
menu[65][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[66] = new Array();
menu[66][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[67] = new Array();
menu[67][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[67][1]  = new Item('Valid Values', 'NA.html', '', defLength, 0, 327 );
menu[67][2]  = new Item('Exam Term', '../servlet/ees_exam_term?menuOption=eesExamTerm', '', defLength, 0, 0 );
menu[67][3]  = new Item('Buidling', '../servlet/hr_building?menuOption=hrBuilding', '', defLength, 0, 0 );
menu[67][4]  = new Item('Subject Mark Rule', '../servlet/ees_subject_mark_rule?menuOption=eesSubjectMarkRule', '', defLength, 0, 0 );
menu[67][5]  = new Item('Marksheet Layout', '../servlet/ees_marksheet_lo?menuOption=eesMarksheetLo', '', defLength, 0, 0 );
menu[67][6]  = new Item('Exam Room Capacity', '../servlet/ees_exam_seat_plan?menuOption=eesExamSeatPlanStd', '', defLength, 0, 0 );

menu[68] = new Array();
menu[68][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[68][1]  = new Item('Define Exam', '../servlet/ees_exam?menuOption=eesExam', '', defLength, 0, 0 );
menu[68][2]  = new Item('Room Capacity', '../servlet/ees_exam_seat_plan?menuOption=eesExamSeatPlan', '', defLength, 0, 0 );
menu[68][3]  = new Item('Define Schedule', '../servlet/ees_exam?menuOption=eesExamScheduleDefine', '', defLength, 0, 0 );
menu[68][4]  = new Item('Seat Allocation', '../servlet/ees_exam_seat_allocation?menuOption=eesExamSeatAllocation', '', defLength, 0, 0 );
menu[68][5]  = new Item('Student Attendence', '../servlet/ees_exam_seat_allocation?menuOption=eesStudentAttendenceRoomWise', '', defLength, 0, 0 );
menu[68][6]  = new Item('Exam Quest Paper', '../servlet/ees_exam_question?menuOption=eesExamQuestion', '', defLength, 0, 0 );
menu[68][7]  = new Item('Incharge(obso)', '../servlet/ees_exam?menuOption=eesExamInchargAndStudentRange', '', defLength, 0, 0 );

menu[69] = new Array();
menu[69][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[69][1]  = new Item('Marks Entry', '../servlet/ees_student_mark?menuOption=eesStudentMark', '', defLength, 0, 0 );
menu[69][2]  = new Item('Student Remark Entry', '../servlet/ees_student_mark?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );
menu[69][3]  = new Item('Report Card', '../servlet/ees_exam_report?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );
menu[69][4]  = new Item('View Report Card(obso)', '../servlet/ees_report_card?menuOption=eesReportCard', '', defLength, 0, 0 );
menu[69][5]  = new Item('Student Remark (Obso)', '../servlet/ees_report_card?menuOption=eesReportCard', '', defLength, 0, 0 );
menu[69][6]  = new Item('Bulk Remark (Obso)', '../servlet/ees_student_marksheet?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );

menu[70] = new Array();
menu[70][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[71] = new Array();
menu[71][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[71][1]  = new Item('Exam Schedule', '../servlet/ees_exam_report?menuOption=eesExamSchReport', '', defLength, 0, 0 );
menu[71][2]  = new Item('Seat Plan', '../servlet/ees_exam_report?menuOption=eesExamSeatPlanReport', '', defLength, 0, 0 );
menu[71][3]  = new Item('Exam Room List', '../servlet/ees_exam_report?menuOption=eesExamRoomListReport', '', defLength, 0, 0 );
menu[71][4]  = new Item('Student Attn Report', '../servlet/ees_exam_report?menuOption=eesStudentAttendanceReport', '', defLength, 0, 0 );
menu[71][5]  = new Item('Student Obtained Mark', '../servlet/ees_exam_report?menuOption=eesStudentObtainedMarkGrpAdmReport', '', defLength, 0, 0 );
menu[71][6]  = new Item('Top Rankers', '../servlet/ees_exam_report?menuOption=eesExamTopRankingReport', '', defLength, 0, 0 );
menu[71][7]  = new Item('Top Rankers in Group', '../servlet/ees_exam_report?menuOption=eesExamTopRankingGrpAdmReport', '', defLength, 0, 0 );

menu[72] = new Array();
menu[72][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[73] = new Array();
menu[73][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[73][1]  = new Item('Account Group', '../servlet/fa_account_group?menuOption=faAccountGroup1', '', defLength, 0, 0 );
menu[73][2]  = new Item('GL Accounts', '../servlet/fa_gl_account?menuOption=faGlAccount1', '', defLength, 0, 0 );
menu[73][3]  = new Item('Voucher Type', '../servlet/fa_voucher?menuOption=faVoucher', '', defLength, 0, 0 );
menu[73][4]  = new Item('Cr - Dr Rule', '../servlet/fa_cr_dr_rule?menuOption=faCrDrRule1', '', defLength, 0, 0 );
menu[73][5]  = new Item('Voucher Limit', '../servlet/fa_vc_limit_rule?menuOption=faVcLimitRule', '', defLength, 0, 0 );

menu[74] = new Array();
menu[74][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[74][1]  = new Item('Voucher Entry', '../servlet/fa_vc_txn?menuOption=faVcTxn', '', defLength, 0, 0 );
menu[74][2]  = new Item('Approve Voucher', '../servlet/fa_vc_txn?menuOption=approveVoucher', '', defLength, 0, 0 );

menu[75] = new Array();
menu[75][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[75][1]  = new Item('Customer Ledger', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );
menu[75][2]  = new Item('Supplier Ledger', '../servlet/esm_supplier?menuOption=defineSupplier', '', defLength, 0, 0 );
menu[75][3]  = new Item('Emp Ledger ', '../servlet/hr_employee?menuOption=createProfile', '', defLength, 0, 0 );
menu[75][4]  = new Item('Oth Vendor Ledger', '../servlet/hr_vendor?menuOption=defineVendor', '', defLength, 0, 0 );

menu[76] = new Array();
menu[76][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[76][1]  = new Item('Account Book', '../servlet/fa_vc_txn_report?menuOption=voucherReport', '', defLength, 0, 0 );
menu[76][2]  = new Item('Ledger Detail', '../servlet/fa_vc_txn_report?menuOption=glReport', '', defLength, 0, 0 );
menu[76][3]  = new Item('Trail Balance', '../servlet/fa_vc_txn_report?menuOption=tbReport', '', defLength, 0, 0 );
menu[76][4]  = new Item('Balancesheet', '../servlet/fa_vc_txn_report?menuOption=bsReport', '', defLength, 0, 0 );
menu[76][5]  = new Item('Voucher Print', '../servlet/hr_payroll_report?menuOption=hrVoucherSlip', '', defLength, 0, 0 );
menu[76][6]  = new Item('Profit and Loss', '../servlet/fa_vc_txn_report?menuOption=plReport', '', defLength, 0, 0 );
menu[76][7]  = new Item('GL Account Query', '../servlet/fa_vc_txn_report?menuOption=glAccountQuery', '', defLength, 0, 0 );

menu[77] = new Array();
menu[77][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[77][1]  = new Item('Ent.Exam Subject', '../servlet/ees_adm_req?menuOption=eesAdmSub', '', defLength, 0, 0 );
menu[77][2]  = new Item('Fee Head', '../servlet/ees_fee_head?menuOption=eesFeeHead', '', defLength, 0, 0 );
menu[77][3]  = new Item('Student Category', '../servlet/ees_student_ctg?menuOption=eesStudentCtg', '', defLength, 0, 0 );

menu[78] = new Array();
menu[78][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[78][1]  = new Item('Download Admission Form', '../servlet/ees_adm_req?menuOption=eesAdmReq', '', defLength, 0, 0 );
menu[78][2]  = new Item('Online Admission', '../servlet/ees_adm_req?menuOption=eesAdmReq', '', defLength, 0, 0 );
menu[78][3]  = new Item('Update Adm From', '../servlet/ees_adm_req?menuOption=eesDetailsOfOnLineForms', '', defLength, 0, 0 );

menu[79] = new Array();
menu[79][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[79][1]  = new Item('Enquiry Form', '../servlet/ees_adm_req?menuOption=eesAdmReqEnq', '', defLength, 0, 0 );
menu[79][2]  = new Item('Enquiry Processing', '../servlet/ees_adm_req?menuOption=eesAdmReqCollegeCouncelling', '', defLength, 0, 0 );
menu[79][3]  = new Item('Councelling List', '../servlet/ees_adm_list?menuOption=eesAdmReqCouncellingList', '', defLength, 0, 0 );
menu[79][4]  = new Item('Admission List', '../servlet/ees_adm_req?menuOption=eesAdmReqAdmList', '', defLength, 0, 0 );
menu[79][5]  = new Item('Admission Form', '../servlet/ees_adm_req?menuOption=eesAdmReqAdmForm', '', defLength, 0, 0 );

menu[80] = new Array();
menu[80][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[80][1]  = new Item('Prospectus Sale', '../servlet/ees_adm_req?menuOption=eesAdmReqProspectusSale', '', defLength, 0, 0 );
menu[80][2]  = new Item('Prospectus Update', '../servlet/ees_adm_req?menuOption=eesAdmReqProspectusUpdate', '', defLength, 0, 0 );
menu[80][3]  = new Item('Form Received', '../servlet/ees_adm_req?menuOption=eesAdmReqFormReceivedFromApplicant', '', defLength, 0, 0 );

menu[81] = new Array();
menu[81][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[81][1]  = new Item('Exam Schedule', '../servlet/ees_adm_req?menuOption=eesAdmReqExamSchedule', '', defLength, 0, 0 );
menu[81][2]  = new Item('Send Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqSendAdmitCard', '', defLength, 0, 0 );
menu[81][3]  = new Item('Exam Marks', '../servlet/ees_adm_req?menuOption=eesAdmMark', '', defLength, 0, 0 );
menu[81][4]  = new Item('Shortlist After Test', '../servlet/ees_adm_req?menuOption=eesAdmReqStudentListAfterTest', '', defLength, 0, 0 );
menu[81][5]  = new Item('Final List of Candidates(NU)', '../servlet/ees_adm_req?menuOption=eesAdmReqSortedCanditateForAdm', '', defLength, 0, 0 );

menu[82] = new Array();
menu[82][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[82][1]  = new Item('Send Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqSendAdmitCard', '', defLength, 0, 0 );
menu[82][2]  = new Item('View Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqViewAdmitCard', '', defLength, 0, 0 );

menu[83] = new Array();
menu[83][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[83][1]  = new Item('Shortlist Application', '../servlet/ees_adm_req?menuOption=eesAdmReqCanShortlisting', '', defLength, 0, 0 );

menu[84] = new Array();
menu[84][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[84][1]  = new Item('New Students List', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );
menu[84][2]  = new Item('Adm Fee Deposit', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );
menu[84][3]  = new Item('Adm Fee Receipt', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );

menu[85] = new Array();
menu[85][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[85][1]  = new Item('New Student', '../servlet/ees_student?menuOption=eesStudentDirectEntryScreen', '', defLength, 0, 0 );
menu[85][2]  = new Item('Section Allotment', '../servlet/ees_student_admission?menuOption=studentSectionAllotment', '', defLength, 0, 0 );
menu[85][3]  = new Item('Section Re-assign', '../servlet/ees_student_admission?menuOption=studentSectionReAllotment', '', defLength, 0, 0 );
menu[85][4]  = new Item('Roll Num Assign', '../servlet/ees_student_admission?menuOption=studentRollNumAllotment', '', defLength, 0, 0 );
menu[85][5]  = new Item('Advance Student Search', '../servlet/ees_student?menuOption=studentSearch', '', defLength, 0, 0 );

menu[86] = new Array();
menu[86][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[86][1]  = new Item('Student List', '../servlet/ees_student?menuOption=studentReport', '', defLength, 0, 0 );
menu[86][2]  = new Item('Fee O/S Report', '../servlet/ees_fee_report?menuOption=eesStudentFeeOutstandingReport', '', defLength, 0, 0 );
menu[86][3]  = new Item('Outstanding Fee Orgwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeOrgWiseReport', '', defLength, 0, 0 );
menu[86][4]  = new Item('Outstanding Fee Classwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeClassWiseReport', '', defLength, 0, 0 );
menu[86][5]  = new Item('Adm Form Query', '../servlet/ees_adm_req?menuOption=eesAdmReqReportsDetail', '', defLength, 0, 0 );
menu[86][6]  = new Item('Admission Receipt', '../servlet/ees_admission_report?menuOption=eesAdmissionReceipt', '', defLength, 0, 0 );

menu[87] = new Array();
menu[87][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[87][1]  = new Item('Fee Head', '../servlet/ees_fee_head?menuOption=eesFeeHead', '', defLength, 0, 0 );
menu[87][2]  = new Item('Class-wise Fee', '../servlet/ees_fee_head_class?menuOption=eesFeeHeadClass', '', defLength, 0, 0 );
menu[87][3]  = new Item('Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[87][4]  = new Item('Late Fee Rule', '../servlet/ees_late_fee_rule?menuOption=lateFeeRule', '', defLength, 0, 0 );
menu[87][5]  = new Item('Fee Concession', '../servlet/ees_fee_concession?menuOption=eesFeeConcession', '', defLength, 0, 0 );
menu[87][6]  = new Item('Transport Fee', '../servlet/ees_tp_fee?menuOption=eesTpFee', '', defLength, 0, 0 );

menu[88] = new Array();
menu[88][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[88][1]  = new Item('Student', '../servlet/ees_student_fee_ledger?menuOption=studentLedger', '', defLength, 0, 0 );
menu[88][2]  = new Item('Fee', '../servlet/ees_student_fee_ledger?menuOption=feeLedger', '', defLength, 0, 0 );

menu[89] = new Array();
menu[89][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[89][1]  = new Item('Planned Fee Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCyclePlanned', '', defLength, 0, 0 );
menu[89][2]  = new Item('Open Bill Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleOpen', '', defLength, 0, 0 );
menu[89][3]  = new Item('Bill Prep', '../servlet/ees_fee_cycle?menuOption=eesFeePrep', '', defLength, 0, 0 );
menu[89][4]  = new Item('Fee Collection - ADM', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=99', '', defLength, 0, 0 );
menu[89][5]  = new Item('Fee Collection - Hostel', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=98', '', defLength, 0, 0 );
menu[89][6]  = new Item('Fee Collection - Transport', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=97', '', defLength, 0, 0 );
menu[89][7]  = new Item('Fee Collection - Exam', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=96', '', defLength, 0, 0 );
menu[89][8]  = new Item('Bill Q&A', '../servlet/ees_fee_cycle?menuOption=eesFeeQA', '', defLength, 0, 0 );
menu[89][9]  = new Item('Bill Print', '../servlet/ees_fee_cycle?menuOption=eesFeePrint', '', defLength, 0, 0 );
menu[89][10]  = new Item('Payment Collection', '../servlet/ees_fee_cycle?menuOption=eesFeeCollection', '', defLength, 0, 0 );
menu[89][11]  = new Item('Bill Cycle Close', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleClose', '', defLength, 0, 0 );
menu[89][12]  = new Item('Coll Center', '../servlet/ees_fee_cycle?menuOption=eesFeeCC', '', defLength, 0, 0 );

menu[90] = new Array();
menu[90][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[90][1]  = new Item('View Fee Structure', '../servlet/ees_view_fee_stucture?menuOption=eesViewFeeStuctureClassNumWise', '', defLength, 0, 0 );
menu[90][2]  = new Item('View Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[90][3]  = new Item('Ledger studentwise', '../servlet/ees_fee_report?menuOption=feeLedgerStudentWise', '', defLength, 0, 0 );
menu[90][4]  = new Item('Ledger Feehead wise', '../servlet/ees_fee_report?menuOption=feeLedgerFeeHeadWise', '', defLength, 0, 0 );
menu[90][5]  = new Item('Collection', '../servlet/ees_fee_report?menuOption=collectionOrgwise', '', defLength, 0, 0 );
menu[90][6]  = new Item('Collection classwise', '../servlet/ees_fee_report?menuOption=collectionClasswise', '', defLength, 0, 0 );
menu[90][7]  = new Item('OS Report', '../servlet/ees_fee_report?menuOption=osOrgwise', '', defLength, 0, 0 );
menu[90][8]  = new Item('OS Classwise', '../servlet/ees_fee_report?menuOption=osClasswise', '', defLength, 0, 0 );
menu[90][9]  = new Item('OS Studentwise', '../servlet/ees_fee_report?menuOption=osStudentwise', '', defLength, 0, 0 );
menu[90][10]  = new Item('Collection-Counterwise(Future)', '../servlet/ees_fee_report?menuOption=collectionCounterwise', '', defLength, 0, 0 );
menu[90][11]  = new Item('Collection-Userwise(Future)', '../servlet/ees_fee_report?menuOption=collectionUserwise', '', defLength, 0, 0 );
menu[90][12]  = new Item('Student Fee Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerStudentWise', '', defLength, 0, 0 );
menu[90][13]  = new Item('Fee Head Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerFeeHeadWise', '', defLength, 0, 0 );

menu[91] = new Array();
menu[91][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[91][1]  = new Item('Room Type', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=ROOMTYPE', '', defLength, 0, 0 );
menu[91][2]  = new Item('Hostel Fee (roomtype wise)', '../servlet/ees_hostel_fee?menuOption=eesHostelFee', '', defLength, 0, 0 );
menu[91][3]  = new Item('Define Hostel', '../servlet/ees_hostel?menuOption=eesHostel', '', defLength, 0, 0 );
menu[91][4]  = new Item('Hostel Floor  ', '../servlet/ees_hostel_flw_qty?menuOption=eesHostelFlwQty', '', defLength, 0, 0 );
menu[91][5]  = new Item('Hostel Wing', '../servlet/ees_hostel_wing?menuOption=eesHostelWing', '', defLength, 0, 0 );
menu[91][6]  = new Item('Room', '../servlet/ees_hostel_room?menuOption=eesRoom', '', defLength, 0, 0 );
menu[91][7]  = new Item('Bed Listing', '../servlet/ees_hostel_bed?menuOption=eesRoomBedListing', '', defLength, 0, 0 );
menu[91][8]  = new Item('Room Inventory', '../servlet/ees_hostel_room_inv?menuOption=eesHostelRoomInvItem', '', defLength, 0, 0 );
menu[91][9]  = new Item('Room Items Listing', '../servlet/ees_hostel_room_item?menuOption=eesHostelRoomItem', '', defLength, 0, 0 );

menu[92] = new Array();
menu[92][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[93] = new Array();
menu[93][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[94] = new Array();
menu[94][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[95] = new Array();
menu[95][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[96] = new Array();
menu[96][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[97] = new Array();
menu[97][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[98] = new Array();
menu[98][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[99] = new Array();
menu[99][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[100] = new Array();
menu[100][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[101] = new Array();
menu[101][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[102] = new Array();
menu[102][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[102][1]  = new Item('In', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegIn', '', defLength, 0, 0 );
menu[102][2]  = new Item('Out', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegOut', '', defLength, 0, 0 );

menu[103] = new Array();
menu[103][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[104] = new Array();
menu[104][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[104][1]  = new Item('Raise', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRaise', '', defLength, 0, 0 );
menu[104][2]  = new Item('Monitor', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainMonitor', '', defLength, 0, 0 );
menu[104][3]  = new Item('Resolve', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRegResolve', '', defLength, 0, 0 );

menu[105] = new Array();
menu[105][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[106] = new Array();
menu[106][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[107] = new Array();
menu[107][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[108] = new Array();
menu[108][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[109] = new Array();
menu[109][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[110] = new Array();
menu[110][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[111] = new Array();
menu[111][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[112] = new Array();
menu[112][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[113] = new Array();
menu[113][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[114] = new Array();
menu[114][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[115] = new Array();
menu[115][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[115][1]  = new Item('Hostel Room Allotment', '../servlet/ees_hostel?menuOption=eesHostelAllotmentReport', '', defLength, 0, 0 );
menu[115][2]  = new Item('Hostel Exit Entry List', '../servlet/ees_hostel?menuOption=eesHostelExitEntryReport', '', defLength, 0, 0 );
menu[115][3]  = new Item('Hostel Room Inv Reports', '../servlet/ees_hostel_report?menuOption=eesHostelItemRoomInventory', '', defLength, 0, 0 );
menu[115][4]  = new Item('Hostel Reg Form Printed', '../servlet/ees_hostel_report?menuOption=eesHostelRegistrationForm', '', defLength, 0, 0 );
menu[115][5]  = new Item('Declaration Letter', '../servlet/ees_hostel_report?menuOption=eesHostelDeclarationLetter', '', defLength, 0, 0 );
menu[115][6]  = new Item('Locker List', '../servlet/ees_hostel_report?menuOption=eesHostelLocker', '', defLength, 0, 0 );
menu[115][7]  = new Item('Hostel Use Reg', '../servlet/ees_hostel_report?menuOption=eesHostelLockerVisit', '', defLength, 0, 0 );
menu[115][8]  = new Item('Room Allotment Reports', '../servlet/ees_hostel_report?menuOption=eesHostelRoomAllotment', '', defLength, 0, 0 );
menu[115][9]  = new Item('Deaalication Reports', '../servlet/ees_hostel_report?menuOption=eesHostelRoomDealloate', '', defLength, 0, 0 );
menu[115][10]  = new Item('Oytsider Register', '../servlet/ees_hostel_report?menuOption=eesHostelBedOutsiderStay', '', defLength, 0, 0 );
menu[115][11]  = new Item('Visiter Register', '../servlet/ees_hostel_report?menuOption=eesHostelVisitorVisitReport', '', defLength, 0, 0 );
menu[115][12]  = new Item('Baggage Register', '../servlet/ees_hostel_report?menuOption=eesHostelStudentBaggage', '', defLength, 0, 0 );
menu[115][13]  = new Item('Item Inventory Register', '../servlet/ees_hostel_report?menuOption=eesHostelInventory', '', defLength, 0, 0 );
menu[115][14]  = new Item('Hostel Staff List', '../servlet/ees_hostel_report?menuOption=eesHostelStaffProfile', '', defLength, 0, 0 );
menu[115][15]  = new Item('Hostel Visitor List', '../servlet/ees_hostel_report?menuOption=eesHostelVisitorProfile', '', defLength, 0, 0 );
menu[115][16]  = new Item('Room Type Conversion Report', '../servlet/ees_hostel_report?menuOption=eesHostelRoomConvReport', '', defLength, 0, 0 );
menu[115][17]  = new Item('Hostel Complain Reg', '../servlet/ees_hostel_report?menuOption=eesHostelComplianRegReport', '', defLength, 0, 0 );
menu[115][18]  = new Item('Room Change Report', '../servlet/ees_hostel_report?menuOption=eesHostelRoomTransferReport', '', defLength, 0, 0 );
menu[115][19]  = new Item('Hostel Attendance Report', '../servlet/ees_hostel_report?menuOption=eesHostelAttRegister', '', defLength, 0, 0 );
menu[115][20]  = new Item('Hostel Room Summary Reports', '../servlet/ees_hostel_report?menuOption=eesHostelSummary', '', defLength, 0, 0 );

menu[116] = new Array();
menu[116][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[116][1]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 116 );
menu[116][2]  = new Item('Contract', '../servlet/ees_contract?menuOption=eesContract', '', defLength, 0, 0 );
menu[116][3]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 0 );

menu[117] = new Array();
menu[117][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[118] = new Array();
menu[118][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[119] = new Array();
menu[119][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[119][1]  = new Item('Student Profile', '../servlet/ees_student?menuOption=eesStudentDirectEntryScreen', '', defLength, 0, 0 );
menu[119][2]  = new Item('Company Profile', '../servlet/ees_tnp_company?menuOption=eesTnpCompany', '', defLength, 0, 0 );
menu[119][3]  = new Item('Guest Institute', '../servlet/ees_institute?menuOption=eesInstitute', '', defLength, 0, 0 );

menu[120] = new Array();
menu[120][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[121] = new Array();
menu[121][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[121][1]  = new Item('Criteria', '../servlet/ees_tnp_cic?menuOption=tnpCIC', '', defLength, 0, 0 );
menu[121][2]  = new Item('Venue', '../servlet/ees_tnp_civ?menuOption=tnpCIV', '', defLength, 0, 0 );

menu[122] = new Array();
menu[122][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[122][1]  = new Item('Student List', '../servlet/ees_tnp_ci_student?menuOption=eesStudentList', '', defLength, 0, 0 );
menu[122][2]  = new Item('Company List', '../servlet/ees_tnp_company?menuOption=eesCompanyList', '', defLength, 0, 0 );
menu[122][3]  = new Item('Other Institute', '../servlet/ees_institute?menuOption=eesInstitute', '', defLength, 0, 0 );
menu[122][4]  = new Item('Upload Student List', '../servlet/ees_tnp_ci_student?menuOption=uploadStudent', '', defLength, 0, 0 );
menu[122][5]  = new Item('Registration(od)', '../servlet/ees_tnp_ci_student?menuOption=applyForCI', '', defLength, 0, 0 );

menu[123] = new Array();
menu[123][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[124] = new Array();
menu[124][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[125] = new Array();
menu[125][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[125][1]  = new Item('Placement History', '../servlet/ees_tnp_ci_student?menuOption=eesTnpCiStudentReport', '', defLength, 0, 0 );

menu[126] = new Array();
menu[126][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[127] = new Array();
menu[127][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[128] = new Array();
menu[128][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[129] = new Array();
menu[129][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[130] = new Array();
menu[130][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[131] = new Array();
menu[131][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[132] = new Array();
menu[132][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[132][1]  = new Item('Photo', 'NA.html', '', defLength, 0, 156 );

menu[133] = new Array();
menu[133][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[133][1]  = new Item('Alumni Profile', '../servlet/ees_alumni_prof?menuOption=eesAlumniProfReport', '', defLength, 0, 0 );

menu[134] = new Array();
menu[134][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[135] = new Array();
menu[135][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[135][1]  = new Item('Lab Session Type', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=SESSIONTYP', '', defLength, 0, 0 );
menu[135][2]  = new Item('Lab', '../servlet/ees_lab?menuOption=eesLab', '', defLength, 0, 0 );
menu[135][3]  = new Item('Lab Eqp', '../servlet/ees_lab_eqp?menuOption=eesLabEqp', '', defLength, 0, 0 );

menu[136] = new Array();
menu[136][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[136][1]  = new Item('Lab Schedule', 'NA.html', '', defLength, 0, 211 );
menu[136][2]  = new Item('Eqp Status', '../servlet/ees_lab_its?menuOption=eesLabEqpView1', '', defLength, 0, 0 );

menu[137] = new Array();
menu[137][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[138] = new Array();
menu[138][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[138][1]  = new Item('Consolidate Lab Report', '../servlet/ees_lab_report?menuOption=labConsolidatedReport', '', defLength, 0, 0 );
menu[138][2]  = new Item('Lab Wise Report', '../servlet/ees_lab_report?menuOption=labWiseReport', '', defLength, 0, 0 );
menu[138][3]  = new Item('Student Wise Report', '../servlet/ees_lab_report?menuOption=studentWiseReport', '', defLength, 0, 0 );
menu[138][4]  = new Item('Faculty Wise Report', '../servlet/ees_lab_report?menuOption=facultyWiseReport', '', defLength, 0, 0 );
menu[138][5]  = new Item('Staff Wise Report', '../servlet/ees_lab_report?menuOption=staffWiseReport', '', defLength, 0, 0 );
menu[138][6]  = new Item('Lab Wise ETS Report', '../servlet/ees_lab_report?menuOption=labWiseEtsReport', '', defLength, 0, 0 );
menu[138][7]  = new Item('Labwise Eqp List Report', '../servlet/ees_lab_report?menuOption=eqpList', '', defLength, 0, 0 );
menu[138][8]  = new Item('Subject Wise Report', '../servlet/ees_lab_report?menuOption=subjectWiseReport', '', defLength, 0, 0 );

menu[139] = new Array();
menu[139][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[139][1]  = new Item('Consolidate Lab Report', '../servlet/ees_lab_report?menuOption=labConsolidatedReportHist', '', defLength, 0, 0 );
menu[139][2]  = new Item('Lab Wise Report', '../servlet/ees_lab_report?menuOption=labWiseReportHist', '', defLength, 0, 0 );
menu[139][3]  = new Item('Student Wise Report', '../servlet/ees_lab_report?menuOption=studentWiseReportHist', '', defLength, 0, 0 );
menu[139][4]  = new Item('Faculty Wise Report', '../servlet/ees_lab_report?menuOption=facltyWiseReportHist', '', defLength, 0, 0 );
menu[139][5]  = new Item('Staff Wise Report', '../servlet/ees_lab_report?menuOption=staffWiseReportHist', '', defLength, 0, 0 );

menu[140] = new Array();
menu[140][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[141] = new Array();
menu[141][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[142] = new Array();
menu[142][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[143] = new Array();
menu[143][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[144] = new Array();
menu[144][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[145] = new Array();
menu[145][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[146] = new Array();
menu[146][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[147] = new Array();
menu[147][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[148] = new Array();
menu[148][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[149] = new Array();
menu[149][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[150] = new Array();
menu[150][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[151] = new Array();
menu[151][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[152] = new Array();
menu[152][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[153] = new Array();
menu[153][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[154] = new Array();
menu[154][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[155] = new Array();
menu[155][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[156] = new Array();
menu[156][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[156][1]  = new Item('Infrastructure', 'NA.html', '', defLength, 0, 0 );
menu[156][2]  = new Item('College Staff', 'NA.html', '', defLength, 0, 0 );
menu[156][3]  = new Item('Alumni Batch', 'NA.html', '', defLength, 0, 0 );
menu[156][4]  = new Item('Convocation', 'NA.html', '', defLength, 0, 0 );

menu[157] = new Array();
menu[157][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[158] = new Array();
menu[158][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[159] = new Array();
menu[159][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[160] = new Array();
menu[160][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[161] = new Array();
menu[161][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[161][1]  = new Item('ID Type', '../servlet/gn_type_value?menuOption=defineIdType', '', defLength, 0, 0 );
menu[161][2]  = new Item('Bulk Cache Generation', '../servlet/gn_type_value?menuOption=bulkCacheGen', '', defLength, 0, 0 );
menu[161][3]  = new Item('Bulk Cache Generation', '../servlet/gn_type_value?menuOption=bulkCacheGen', '', defLength, 0, 0 );

menu[162] = new Array();
menu[162][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[162][1]  = new Item('Project Mgt', '../servlet/gn_appln_menu?menuOption=projectManagement', '', defLength, 0, 0 );

menu[163] = new Array();
menu[163][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[163][1]  = new Item('Raise Defect', '../servlet/qa_defect?menuOption=qaDefect', '', defLength, 0, 0 );
menu[163][2]  = new Item('Defect Tracking', '../servlet/qa_defect?menuOption=qaDefect', '', defLength, 0, 0 );
menu[163][3]  = new Item('Test Case', '../servlet/qa_testcase?menuOption=qaTestcase', '', defLength, 0, 0 );
menu[163][4]  = new Item('Test Procedure', '../servlet/qa_testcase_step?menuOption=qaTestcaseStep', '', defLength, 0, 0 );

menu[164] = new Array();
menu[164][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[164][1]  = new Item('Continent', '../servlet/gn_continent?menuOption=gnContinent', '', defLength, 0, 0 );
menu[164][2]  = new Item('Country', '../servlet/gn_country?menuOption=gnCountry', '', defLength, 0, 0 );
menu[164][3]  = new Item('State', '../servlet/gn_state?menuOption=gnState', '', defLength, 0, 0 );
menu[164][4]  = new Item('City', '../servlet/gn_city?menuOption=gnCity', '', defLength, 0, 0 );
menu[164][5]  = new Item('Districtt', '../servlet/gn_city?menuOption=gnCity', '', defLength, 0, 0 );

menu[165] = new Array();
menu[165][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[165][1]  = new Item('JDBC Config', '../servlet/sst_config?menuOption=driverConfig', '', defLength, 0, 0 );
menu[165][2]  = new Item('Param Config', '../servlet/sst_config?menuOption=esmParamConfig', '', defLength, 0, 0 );
menu[165][3]  = new Item('Param Config Init', '../servlet/sst_config?menuOption=esmParamConfigInit', '', defLength, 0, 0 );

menu[166] = new Array();
menu[166][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[167] = new Array();
menu[167][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[168] = new Array();
menu[168][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[169] = new Array();
menu[169][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[170] = new Array();
menu[170][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[171] = new Array();
menu[171][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[172] = new Array();
menu[172][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[173] = new Array();
menu[173][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[174] = new Array();
menu[174][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[175] = new Array();
menu[175][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[175][1]  = new Item('Define Route ', '../servlet/ees_route?menuOption=eesRoute', '', defLength, 0, 0 );
menu[175][2]  = new Item('Route Stoppage', '../servlet/ees_route_stoppage?menuOption=eesRouteStoppage', '', defLength, 0, 0 );
menu[175][3]  = new Item('Route and Stoppage', '../servlet/ees_route?menuOption=eesDefineRouteStoppage', '', defLength, 0, 0 );
menu[175][4]  = new Item('Route For Vehicle', '../servlet/ees_vehicle_route?menuOption=eesVehicleRoute', '', defLength, 0, 0 );

menu[176] = new Array();
menu[176][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[177] = new Array();
menu[177][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[178] = new Array();
menu[178][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[179] = new Array();
menu[179][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[180] = new Array();
menu[180][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[180][1]  = new Item('Work Order List', '../servlet/ees_transport_report?menuOption=eesWorkListReport', '', defLength, 0, 0 );
menu[180][2]  = new Item('Vehicle Usage Report', '../servlet/ees_transport_report?menuOption=eesVehicleUsageReport', '', defLength, 0, 0 );
menu[180][3]  = new Item('Classwise Route Stoppage Report', '../servlet/ees_transport_report?menuOption=eesClassWiseRouteStopReport', '', defLength, 0, 0 );
menu[180][4]  = new Item('Transporter List', '../servlet/ees_transport_report?menuOption=eesTransporterRegister', '', defLength, 0, 0 );
menu[180][5]  = new Item('Driver List', '../servlet/ees_transport_report?menuOption=eesVehicleDriverList', '', defLength, 0, 0 );

menu[181] = new Array();
menu[181][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[182] = new Array();
menu[182][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[183] = new Array();
menu[183][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[184] = new Array();
menu[184][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[185] = new Array();
menu[185][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[186] = new Array();
menu[186][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[187] = new Array();
menu[187][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[188] = new Array();
menu[188][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[189] = new Array();
menu[189][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[190] = new Array();
menu[190][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[191] = new Array();
menu[191][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[192] = new Array();
menu[192][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[193] = new Array();
menu[193][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[194] = new Array();
menu[194][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[195] = new Array();
menu[195][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[196] = new Array();
menu[196][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[197] = new Array();
menu[197][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[198] = new Array();
menu[198][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[199] = new Array();
menu[199][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[200] = new Array();
menu[200][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[201] = new Array();
menu[201][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[202] = new Array();
menu[202][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[203] = new Array();
menu[203][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[204] = new Array();
menu[204][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[205] = new Array();
menu[205][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[206] = new Array();
menu[206][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[207] = new Array();
menu[207][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[208] = new Array();
menu[208][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[209] = new Array();
menu[209][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[210] = new Array();
menu[210][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[211] = new Array();
menu[211][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[211][1]  = new Item('For Class', '../servlet/ees_lab_its?menuOption=eesLabSchDay', '', defLength, 0, 0 );
menu[211][2]  = new Item('For Exam', '../servlet/ees_lab_its?menuOption=eesLabSchDayExam', '', defLength, 0, 0 );
menu[211][3]  = new Item('Copy Schedule', '../servlet/ees_lab_its?menuOption=eesLabSchWeek', '', defLength, 0, 0 );

menu[212] = new Array();
menu[212][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[213] = new Array();
menu[213][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[214] = new Array();
menu[214][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[215] = new Array();
menu[215][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[216] = new Array();
menu[216][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[217] = new Array();
menu[217][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[218] = new Array();
menu[218][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[219] = new Array();
menu[219][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[220] = new Array();
menu[220][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[221] = new Array();
menu[221][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[222] = new Array();
menu[222][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[223] = new Array();
menu[223][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[224] = new Array();
menu[224][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[225] = new Array();
menu[225][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[226] = new Array();
menu[226][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[227] = new Array();
menu[227][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[228] = new Array();
menu[228][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[229] = new Array();
menu[229][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[230] = new Array();
menu[230][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[231] = new Array();
menu[231][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[232] = new Array();
menu[232][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[233] = new Array();
menu[233][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[234] = new Array();
menu[234][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[235] = new Array();
menu[235][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[236] = new Array();
menu[236][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[237] = new Array();
menu[237][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[238] = new Array();
menu[238][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[239] = new Array();
menu[239][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[240] = new Array();
menu[240][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[241] = new Array();
menu[241][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[242] = new Array();
menu[242][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[243] = new Array();
menu[243][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[244] = new Array();
menu[244][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[244][1]  = new Item('Accrued Policy', '../servlet/hr_emp_rr_accrued_amt?menuOption=hrEmpRrAccruedAmt', '', defLength, 0, 0 );
menu[244][2]  = new Item('Saving Declaration', '../servlet/hr_tax_rebate_reason_dtl?menuOption=hrTaxRebateReasonDtl', '', defLength, 0, 0 );
menu[244][3]  = new Item('Tax Sheet', '../servlet/hr_tax_ledger?menuOption=hrTaxLedger', '', defLength, 0, 0 );
menu[244][4]  = new Item('Emp Tax Sheet', '../servlet/hr_tax_ledger?menuOption=empTaxLedger', '', defLength, 0, 0 );
menu[244][5]  = new Item('Tax Saving Declaration - ADM', '../servlet/hr_tax_rebate_reason_dtl?menuOption=hrTaxRebateReasonDtlAdm', '', defLength, 0, 0 );
menu[244][6]  = new Item('Future Use1', 'NA.html', '', defLength, 0, 0 );
menu[244][7]  = new Item('Future Use2', 'NA.html', '', defLength, 0, 0 );

menu[245] = new Array();
menu[245][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[245][1]  = new Item('Request', 'NA.html', '', defLength, 0, 0 );
menu[245][2]  = new Item('Approve', 'NA.html', '', defLength, 0, 0 );

menu[246] = new Array();
menu[246][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[246][1]  = new Item('Monthly Salary', '../servlet/hr_emp_salary_ledger?menuOption=hrEmpBulkSalaryPrep', '', defLength, 0, 0 );
menu[246][2]  = new Item('Sal Cheque', '../servlet/hr_emp_clubbed_salary?menuOption=hrEmpSalaryCheque', '', defLength, 0, 0 );
menu[246][3]  = new Item('Sal Cheque (Custwise)', '../servlet/hr_emp_clubbed_salary?menuOption=hrEmpSalaryChequeCustwise', '', defLength, 0, 0 );
menu[246][4]  = new Item('Salary Slip', '../servlet/hr_emp_salary_ledger?menuOption=viewSalarySlip', '', defLength, 0, 0 );
menu[246][5]  = new Item('Salary Ledger(Old)', '../servlet/hr_emp_salary_ledger?menuOption=salaryLedger', '', defLength, 0, 0 );

menu[247] = new Array();
menu[247][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[248] = new Array();
menu[248][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[248][1]  = new Item('Job Position', '../servlet/hr_position?menuOption=hrPosition', '', defLength, 0, 0 );
menu[248][2]  = new Item('Define Eval Criteria', '../servlet/hr_eval_criteria?menuOption=hrEvalCriteria', '', defLength, 0, 0 );
menu[248][3]  = new Item('Recruit. Agency', '../servlet/hr_vendor?menuOption=hrVendor&vendor_type=R', '', defLength, 0, 0 );
menu[248][4]  = new Item('Position Qualification(Obso)', '../servlet/hr_position?menuOption=hrPositionQuali', '', defLength, 0, 0 );

menu[249] = new Array();
menu[249][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[249][1]  = new Item('Raise Recruitment(Dept)', '../servlet/hr_recruitment_req?menuOption=raiseRecRequestDeptMgr', '', defLength, 0, 0 );
menu[249][2]  = new Item('Raise Recruitment(Hr)', '../servlet/hr_recruitment_req?menuOption=raiseRecRequestHRMgr', '', defLength, 0, 0 );
menu[249][3]  = new Item('Moniter Rec Request', '../servlet/hr_recruitment_req?menuOption=moniterRecRequest', '', defLength, 0, 0 );
menu[249][4]  = new Item('Approve Rec Request', '../servlet/hr_recruitment_req?menuOption=approveRecRequest', '', defLength, 0, 0 );
menu[249][5]  = new Item('Process Recruitment', '../servlet/hr_recruitment_req?menuOption=processRecRequest', '', defLength, 0, 0 );

menu[250] = new Array();
menu[250][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[250][1]  = new Item('Resume Builder', '../servlet/hr_applicant?menuOption=hrApplicantCareer', '', defLength, 0, 0 );
menu[250][2]  = new Item('Careers', '../servlet/hr_applicant?menuOption=hrApplicantCareer', '', defLength, 0, 0 );
menu[250][3]  = new Item('Pick Resume', '../servlet/hr_applicant?menuOption=hrApplicantFilterResume', '', defLength, 0, 0 );
menu[250][4]  = new Item('Applicant Rating', '../servlet/hr_eval_criteria?menuOption=hrApplicantListOne', '', defLength, 0, 0 );
menu[250][5]  = new Item('Applicant Result', '../servlet/hr_eval_criteria?menuOption=hrApplicantListTwo', '', defLength, 0, 0 );
menu[250][6]  = new Item('Final Selection', '../servlet/hr_eval_criteria?menuOption=hrApplicantListThree', '', defLength, 0, 0 );
menu[250][7]  = new Item('Selected Candidates', '../servlet/hr_applicant?menuOption=hrCandidateListOne', '', defLength, 0, 0 );
menu[250][8]  = new Item('Final List Candidates', '../servlet/hr_applicant?menuOption=hrCandidateListTwo', '', defLength, 0, 0 );
menu[250][9]  = new Item('Send For Training', '../servlet/hr_training?menuOption=hrTrainingApplicant', '', defLength, 0, 0 );

menu[251] = new Array();
menu[251][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[252] = new Array();
menu[252][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[253] = new Array();
menu[253][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[254] = new Array();
menu[254][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[255] = new Array();
menu[255][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[256] = new Array();
menu[256][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[257] = new Array();
menu[257][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[258] = new Array();
menu[258][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[259] = new Array();
menu[259][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[260] = new Array();
menu[260][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[261] = new Array();
menu[261][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[262] = new Array();
menu[262][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[263] = new Array();
menu[263][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[264] = new Array();
menu[264][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[265] = new Array();
menu[265][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[266] = new Array();
menu[266][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[267] = new Array();
menu[267][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[268] = new Array();
menu[268][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[269] = new Array();
menu[269][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[270] = new Array();
menu[270][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[271] = new Array();
menu[271][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[272] = new Array();
menu[272][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[273] = new Array();
menu[273][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[274] = new Array();
menu[274][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[275] = new Array();
menu[275][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[276] = new Array();
menu[276][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[277] = new Array();
menu[277][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[278] = new Array();
menu[278][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[279] = new Array();
menu[279][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[280] = new Array();
menu[280][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[281] = new Array();
menu[281][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[282] = new Array();
menu[282][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[283] = new Array();
menu[283][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[284] = new Array();
menu[284][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[285] = new Array();
menu[285][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[286] = new Array();
menu[286][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[287] = new Array();
menu[287][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[288] = new Array();
menu[288][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[289] = new Array();
menu[289][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[290] = new Array();
menu[290][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[291] = new Array();
menu[291][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[292] = new Array();
menu[292][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[293] = new Array();
menu[293][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[294] = new Array();
menu[294][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[295] = new Array();
menu[295][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[296] = new Array();
menu[296][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[297] = new Array();
menu[297][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[298] = new Array();
menu[298][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[299] = new Array();
menu[299][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[300] = new Array();
menu[300][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[301] = new Array();
menu[301][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[302] = new Array();
menu[302][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[303] = new Array();
menu[303][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[304] = new Array();
menu[304][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[305] = new Array();
menu[305][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[306] = new Array();
menu[306][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[307] = new Array();
menu[307][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[308] = new Array();
menu[308][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[309] = new Array();
menu[309][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[310] = new Array();
menu[310][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[311] = new Array();
menu[311][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[312] = new Array();
menu[312][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[313] = new Array();
menu[313][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[314] = new Array();
menu[314][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[315] = new Array();
menu[315][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[316] = new Array();
menu[316][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[317] = new Array();
menu[317][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[318] = new Array();
menu[318][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[319] = new Array();
menu[319][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[320] = new Array();
menu[320][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[321] = new Array();
menu[321][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[322] = new Array();
menu[322][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[323] = new Array();
menu[323][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[324] = new Array();
menu[324][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[325] = new Array();
menu[325][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[326] = new Array();
menu[326][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[327] = new Array();
menu[327][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[327][1]  = new Item('Exam Session', '../servlet/ees_period?menuOption=eesExamSession', '', defLength, 0, 0 );

menu[328] = new Array();
menu[328][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[329] = new Array();
menu[329][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[330] = new Array();
menu[330][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[331] = new Array();
menu[331][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[332] = new Array();
menu[332][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[333] = new Array();
menu[333][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[334] = new Array();
menu[334][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[335] = new Array();
menu[335][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[336] = new Array();
menu[336][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[337] = new Array();
menu[337][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[338] = new Array();
menu[338][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[339] = new Array();
menu[339][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[340] = new Array();
menu[340][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[341] = new Array();
menu[341][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[342] = new Array();
menu[342][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[343] = new Array();
menu[343][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[344] = new Array();
menu[344][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[345] = new Array();
menu[345][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[346] = new Array();
menu[346][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[347] = new Array();
menu[347][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[348] = new Array();
menu[348][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[349] = new Array();
menu[349][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[349][1]  = new Item('Timetable Rule', '../servlet/ees_timetable_rule?menuOption=eesTimetableRule', '', defLength, 0, 0 );
menu[349][2]  = new Item('Initiate Timetable', '../servlet/ees_timetable?menuOption=initiateTimetable', '', defLength, 0, 0 );
menu[349][3]  = new Item('Timetable Classwise', '../servlet/ees_timetable?menuOption=eesTimetableHdr', '', defLength, 0, 0 );
menu[349][4]  = new Item('Timetable Teacherwise', '../servlet/ees_timetable?menuOption=eesTimetableTeacherwise', '', defLength, 0, 0 );
menu[349][5]  = new Item('Approve Timetable', '../servlet/ees_timetable?menuOption=approveTT', '', defLength, 0, 0 );
menu[349][6]  = new Item('CopyTimetable', '../servlet/ees_timetable?menuOption=eesTimetableCpy', '', defLength, 0, 0 );
menu[349][7]  = new Item('View Timetable', 'NA.html', '', defLength, 0, 358 );

menu[350] = new Array();
menu[350][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[350][1]  = new Item('Lect Delv Plan', '../servlet/ees_timetable?menuOption=eesLectureDeliveryPlan', '', defLength, 0, 0 );
menu[350][2]  = new Item('Attendence Entry', '../servlet/ees_adr?menuOption=eesAdr', '', defLength, 0, 0 );
menu[350][3]  = new Item('Copy Attendance', '../servlet/ees_adr?menuOption=copyAttnPeriodWise', '', defLength, 0, 0 );
menu[350][4]  = new Item('ADR Progress', '../servlet/ees_adr?menuOption=eesAdrProgress', '', defLength, 0, 0 );
menu[350][5]  = new Item('Add or Alt Faculty', '../servlet/ees_timetable?menuOption=eesTimetable', '', defLength, 0, 0 );
menu[350][6]  = new Item('Alt Faculty Req (OD)', 'NA.html', '', defLength, 0, 366 );
menu[350][7]  = new Item('ADR Reports', 'NA.html', '', defLength, 0, 367 );

menu[351] = new Array();
menu[351][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[351][1]  = new Item('TT Query-Classwise', '../servlet/ees_timetable_report?menuOption=monthlyTimetableReportClassWise', '', defLength, 0, 0 );
menu[351][2]  = new Item('TT Query-Facultywise', '../servlet/ees_timetable_report?menuOption=monthlyTimetableReportFacultyWise', '', defLength, 0, 0 );
menu[351][3]  = new Item('TT Report-Classwise', '../servlet/ees_timetable_report?menuOption=eesTimetableReportClassWise', '', defLength, 0, 0 );
menu[351][4]  = new Item('TT Report-Facultywise', '../servlet/ees_timetable_report?menuOption=eesTimetableFacultyWiseReport', '', defLength, 0, 0 );
menu[351][5]  = new Item('TT Report-Datewise', '../servlet/ees_timetable_report?menuOption=eesTimetableDateWiseFacultyReport', '', defLength, 0, 0 );
menu[351][6]  = new Item('Student Attn Report-Monthly', '../servlet/ees_timetable_report?menuOption=eesStuAttMonthReport', '', defLength, 0, 0 );

menu[352] = new Array();
menu[352][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[353] = new Array();
menu[353][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[354] = new Array();
menu[354][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[355] = new Array();
menu[355][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[356] = new Array();
menu[356][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[357] = new Array();
menu[357][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[358] = new Array();
menu[358][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[358][1]  = new Item('For Faculty', '../servlet/ees_timetable?menuOption=viewTimetableFaculty', '', defLength, 0, 0 );
menu[358][2]  = new Item('Admin', '../servlet/ees_timetable?menuOption=viewTimetableAdm', '', defLength, 0, 0 );

menu[359] = new Array();
menu[359][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[360] = new Array();
menu[360][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[361] = new Array();
menu[361][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[362] = new Array();
menu[362][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[363] = new Array();
menu[363][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[364] = new Array();
menu[364][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[365] = new Array();
menu[365][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[366] = new Array();
menu[366][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[366][1]  = new Item('Raise Request', '../servlet/ees_tt_af_req?menuOption=raiseRequest', '', defLength, 0, 0 );
menu[366][2]  = new Item('View Raise Req', '../servlet/ees_tt_af_req?menuOption=viewRaiseRequest', '', defLength, 0, 0 );
menu[366][3]  = new Item('Moniter Alt Fac Req', '../servlet/ees_tt_af_req?menuOption=monitorRequest', '', defLength, 0, 0 );

menu[367] = new Array();
menu[367][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[367][1]  = new Item('Monthly Attendance ', '../servlet/ees_adr?menuOption=attnReportMonthly', '', defLength, 0, 0 );
menu[367][2]  = new Item('Period Wise Attendance', '../servlet/ees_adr?menuOption=attnReportPeriodWise', '', defLength, 0, 0 );

menu[368] = new Array();
menu[368][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[369] = new Array();
menu[369][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[370] = new Array();
menu[370][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[371] = new Array();
menu[371][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[372] = new Array();
menu[372][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[373] = new Array();
menu[373][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[374] = new Array();
menu[374][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[375] = new Array();
menu[375][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[376] = new Array();
menu[376][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[377] = new Array();
menu[377][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[378] = new Array();
menu[378][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[379] = new Array();
menu[379][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[380] = new Array();
menu[380][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[381] = new Array();
menu[381][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[382] = new Array();
menu[382][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[383] = new Array();
menu[383][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[384] = new Array();
menu[384][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[385] = new Array();
menu[385][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[386] = new Array();
menu[386][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[387] = new Array();
menu[387][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[388] = new Array();
menu[388][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[389] = new Array();
menu[389][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[390] = new Array();
menu[390][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[391] = new Array();
menu[391][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[392] = new Array();
menu[392][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[393] = new Array();
menu[393][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[394] = new Array();
menu[394][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[395] = new Array();
menu[395][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[396] = new Array();
menu[396][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[397] = new Array();
menu[397][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[398] = new Array();
menu[398][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[399] = new Array();
menu[399][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[400] = new Array();
menu[400][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[401] = new Array();
menu[401][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[402] = new Array();
menu[402][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[403] = new Array();
menu[403][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[404] = new Array();
menu[404][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[405] = new Array();
menu[405][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[406] = new Array();
menu[406][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[407] = new Array();
menu[407][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[408] = new Array();
menu[408][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[409] = new Array();
menu[409][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[410] = new Array();
menu[410][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[411] = new Array();
menu[411][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[412] = new Array();
menu[412][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[413] = new Array();
menu[413][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[414] = new Array();
menu[414][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[415] = new Array();
menu[415][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[416] = new Array();
menu[416][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[417] = new Array();
menu[417][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[418] = new Array();
menu[418][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[419] = new Array();
menu[419][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[420] = new Array();
menu[420][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[421] = new Array();
menu[421][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[422] = new Array();
menu[422][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[423] = new Array();
menu[423][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[424] = new Array();
menu[424][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[425] = new Array();
menu[425][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[426] = new Array();
menu[426][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[427] = new Array();
menu[427][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[428] = new Array();
menu[428][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[429] = new Array();
menu[429][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[430] = new Array();
menu[430][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[431] = new Array();
menu[431][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[432] = new Array();
menu[432][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[433] = new Array();
menu[433][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[434] = new Array();
menu[434][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[435] = new Array();
menu[435][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[436] = new Array();
menu[436][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[437] = new Array();
menu[437][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[438] = new Array();
menu[438][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[439] = new Array();
menu[439][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[440] = new Array();
menu[440][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[441] = new Array();
menu[441][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[442] = new Array();
menu[442][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[443] = new Array();
menu[443][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[444] = new Array();
menu[444][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[445] = new Array();
menu[445][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[446] = new Array();
menu[446][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[447] = new Array();
menu[447][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[448] = new Array();
menu[448][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[449] = new Array();
menu[449][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[449][1]  = new Item('Emp Exit Report', '../servlet/hr_employee_report?menuOption=hrEmpExitReport', '', defLength, 0, 0 );
menu[449][2]  = new Item('Employee Personal Profile', '../servlet/hr_employee_report?menuOption=hrEmployeeProfileReport', '', defLength, 0, 0 );
menu[449][3]  = new Item('Employee Detail Listing', '../servlet/hr_employee_report?menuOption=hrEmployeeDetailReport', '', defLength, 0, 0 );
menu[449][4]  = new Item('Building Wise Room List', '../servlet/hr_building_room?menuOption=buildingWiseRoomReport', '', defLength, 0, 0 );
menu[449][5]  = new Item('Holiday Calendar', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[449][6]  = new Item('Epmloyee Count', '../servlet/hr_department_report?menuOption=hrEmployeeStatisticsReport', '', defLength, 0, 0 );
menu[449][7]  = new Item('Emp Count in Group', '../servlet/hr_department_report?menuOption=hrEmployeeStatisticsGrpAdmReport', '', defLength, 0, 0 );
menu[449][8]  = new Item('Emp Statistic (grpadm)', '../servlet/hr_department_report?menuOption=hrEmployeeGrpAdmReport', '', defLength, 0, 0 );
menu[449][9]  = new Item('Emp List - Dept', '../servlet/hr_employee_report?menuOption=hrEmployeeDepartmentReport', '', defLength, 0, 0 );
menu[449][10]  = new Item('Emp List - Position', '../servlet/hr_employee_report?menuOption=hrEmployeePositionwise', '', defLength, 0, 0 );
menu[449][11]  = new Item('Emp List - Join Date', '../servlet/hr_employee_report?menuOption=hrEmployeeJoiningDatewise', '', defLength, 0, 0 );
menu[449][12]  = new Item('Emp List - Appraisal', '../servlet/hr_employee_report?menuOption=hrEmployeeAppraisalwise', '', defLength, 0, 0 );
menu[449][13]  = new Item('Emp List - Project', '../servlet/hr_employee_report?menuOption=hrEmployeeProjectwise', '', defLength, 0, 0 );
menu[449][14]  = new Item('Emp List - Salary Range', '../servlet/hr_employee_report?menuOption=hrEmployeeSalaryRangewise', '', defLength, 0, 0 );

menu[450] = new Array();
menu[450][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[450][1]  = new Item('Print Cust Agreement', '../servlet/hr_ccb_report?menuOption=hrCustAgrForm', '', defLength, 0, 0 );

menu[451] = new Array();
menu[451][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[452] = new Array();
menu[452][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[452][1]  = new Item('Attendance Sheet Report', '../servlet/hr_card_time?menuOption=hrAttendanceSheetReport', '', defLength, 0, 0 );
menu[452][2]  = new Item('Attendance Sum Report', '../servlet/hr_card_time?menuOption=hrEmpAttendanceSumReport', '', defLength, 0, 0 );
menu[452][3]  = new Item('Training Payment', '../servlet/hr_training_report?menuOption=hrTrainingPayment', '', defLength, 0, 0 );
menu[452][4]  = new Item('Offer Accepted Candidate', '../servlet/hr_training_report?menuOption=hrCandidateListTwo', '', defLength, 0, 0 );
menu[452][5]  = new Item('Training Schedule', '../servlet/hr_training_report?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[452][6]  = new Item('Trainee List Report', '../servlet/hr_training_report?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[452][7]  = new Item('Monthly Attn Sumry', '../servlet/hr_card_time?menuOption=hrEmpAttendanceSum', '', defLength, 0, 0 );

menu[453] = new Array();
menu[453][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[453][1]  = new Item('Salary Ledger (M)', '../servlet/hr_payroll_report?menuOption=hrEmpMonthlySalary', '', defLength, 0, 0 );
menu[453][2]  = new Item('Customer Invoice Bill', '../servlet/hr_payroll_report?menuOption=customerInvoiceBill', '', defLength, 0, 0 );
menu[453][3]  = new Item('ESI Form 5 Reg', '../servlet/hr_payroll_report?menuOption=esiForm5Reg', '', defLength, 0, 0 );
menu[453][4]  = new Item('ESI Form 5(State Wise)', '../servlet/hr_payroll_report?menuOption=esiForm5StateWise', '', defLength, 0, 0 );
menu[453][5]  = new Item('PF Form 5 M (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm5Monthly', '', defLength, 0, 0 );
menu[453][6]  = new Item('PF Form 5 Y (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm5Yearly', '', defLength, 0, 0 );
menu[453][7]  = new Item('PF Form 10 Reg', '../servlet/hr_payroll_report?menuOption=pfForm10Reg', '', defLength, 0, 0 );
menu[453][8]  = new Item('PF Form 10 CustomerWise', '../servlet/hr_payroll_report?menuOption=pfForm10CustomerWise', '', defLength, 0, 0 );
menu[453][9]  = new Item('EPF Form NSS Reg', '../servlet/hr_payroll_report?menuOption=epfFormNssReg', '', defLength, 0, 0 );
menu[453][10]  = new Item('EPF Form NSS Customer Wise', '../servlet/hr_payroll_report?menuOption=epfFormNssCustomerWise', '', defLength, 0, 0 );
menu[453][11]  = new Item('ESI Form 3 Reg', '../servlet/hr_payroll_report?menuOption=esiForm3Reg', '', defLength, 0, 0 );
menu[453][12]  = new Item('ESI Form 3 CustomerWise', '../servlet/hr_payroll_report?menuOption=esiForm3CustomerWise', '', defLength, 0, 0 );
menu[453][13]  = new Item('ESI Challan Monthwise', '../servlet/hr_payroll_report?menuOption=esiChallanMonthwise', '', defLength, 0, 0 );
menu[453][14]  = new Item('Bulk Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrTaxSheetReport', '', defLength, 0, 0 );
menu[453][15]  = new Item('Employee Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrEmpTaxSheetReport', '', defLength, 0, 0 );
menu[453][16]  = new Item('Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=yearlySalaryMisReport', '', defLength, 0, 0 );
menu[453][17]  = new Item('Employee Wise Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpWiseYearlySalaryMisReport', '', defLength, 0, 0 );
menu[453][18]  = new Item('Employee Customer Wise Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpCustWiseYearlySalaryMisReport', '', defLength, 0, 0 );
menu[453][19]  = new Item('Employee Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpSalaryMisReport', '', defLength, 0, 0 );
menu[453][20]  = new Item('Customer Employee Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrCustEmpSalaryMisReport', '', defLength, 0, 0 );
menu[453][21]  = new Item('Customer Employee Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrCustEmpTaxSheetReport', '', defLength, 0, 0 );
menu[453][22]  = new Item('Customer Employee Bulk Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrCustEmpBulkTaxSheetReport', '', defLength, 0, 0 );
menu[453][23]  = new Item('Employee Agreement Salary Report', '../servlet/hr_payroll_report?menuOption=hrEmployeeAgreementSalary', '', defLength, 0, 0 );
menu[453][24]  = new Item('Customer Employee Agreement Salary Report', '../servlet/hr_payroll_report?menuOption=hrCustEmployeeAgreementSalary', '', defLength, 0, 0 );
menu[453][25]  = new Item('Salary Ledger (M) (Custwise)', '../servlet/hr_payroll_report?menuOption=hrEmpMonthlySalaryCustwise', '', defLength, 0, 0 );
menu[453][26]  = new Item('Emp List-Sal Modewise', '../servlet/hr_payroll_report?menuOption=hrempSalaryMode', '', defLength, 0, 0 );
menu[453][27]  = new Item('Salary Slip (Reg)', '../servlet/hr_payroll_report?menuOption=hrEmpSalary', '', defLength, 0, 0 );
menu[453][28]  = new Item('Salary Slip (Custwise)', '../servlet/hr_payroll_report?menuOption=hrEmpSalaryCustwise', '', defLength, 0, 0 );
menu[453][29]  = new Item('ESI Form 1', '../servlet/hr_payroll_report?menuOption=esiForm1', '', defLength, 0, 0 );
menu[453][30]  = new Item('ESI Form 1 (Custwise)', '../servlet/hr_payroll_report?menuOption=esiForm1Custwise', '', defLength, 0, 0 );
menu[453][31]  = new Item('ESI Challan', '../servlet/hr_payroll_report?menuOption=esiChallan', '', defLength, 0, 0 );
menu[453][32]  = new Item('ESI Challan (Custwise)', '../servlet/hr_payroll_report?menuOption=esiChallanCustwise', '', defLength, 0, 0 );
menu[453][33]  = new Item('ESI Statement (Monthly)', '../servlet/hr_payroll_report?menuOption=esiForm999Monthly', '', defLength, 0, 0 );
menu[453][34]  = new Item('ESI Statement (Yearly)', '../servlet/hr_payroll_report?menuOption=esiForm999Yearly', '', defLength, 0, 0 );
menu[453][35]  = new Item('PF Ledger', '../servlet/hr_payroll_report?menuOption=pfLedger', '', defLength, 0, 0 );
menu[453][36]  = new Item('PF Form 2', '../servlet/hr_payroll_report?menuOption=pfForm2', '', defLength, 0, 0 );
menu[453][37]  = new Item('PF Form 3A(Rev)', '../servlet/hr_payroll_report?menuOption=pfForm3A', '', defLength, 0, 0 );
menu[453][38]  = new Item('PF Form 3A(Rev)-Custwise', '../servlet/hr_payroll_report?menuOption=pfForm3AClientwise', '', defLength, 0, 0 );
menu[453][39]  = new Item('PF Form 5 (Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm5ClientwiseMonthly', '', defLength, 0, 0 );
menu[453][40]  = new Item('PF Form 5 (Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm5ClientwiseYearly', '', defLength, 0, 0 );
menu[453][41]  = new Item('PF Form 6A M (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm6AMonthly', '', defLength, 0, 0 );
menu[453][42]  = new Item('PF Form 6A (Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm6AClientwiseMonthly', '', defLength, 0, 0 );
menu[453][43]  = new Item('PF Form 6A Y (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm6AYearly', '', defLength, 0, 0 );
menu[453][44]  = new Item('PF Form 6A (Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm6AClientwiseYearly', '', defLength, 0, 0 );
menu[453][45]  = new Item('PF Form 9 rev', '../servlet/hr_payroll_report?menuOption=pfForm9Rev', '', defLength, 0, 0 );
menu[453][46]  = new Item('PF Form 9 rev (Custwise)', '../servlet/hr_payroll_report?menuOption=pfForm9RevCustwise', '', defLength, 0, 0 );
menu[453][47]  = new Item('PF Form 10A(Rev)', '../servlet/hr_payroll_report?menuOption=pfForm10A', '', defLength, 0, 0 );
menu[453][48]  = new Item('PF Form 10A (Custwise Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm10AClientwiseMonthly', '', defLength, 0, 0 );
menu[453][49]  = new Item('PF Form 10A (Custwise Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm10AClientwiseYearly', '', defLength, 0, 0 );
menu[453][50]  = new Item('PF Form 19', '../servlet/hr_payroll_report?menuOption=pfForm19', '', defLength, 0, 0 );
menu[453][51]  = new Item('PF Form 19 (Custwise)', '../servlet/hr_payroll_report?menuOption=pfForm19Custwise', '', defLength, 0, 0 );
menu[453][52]  = new Item('PF Challan', '../servlet/hr_payroll_report?menuOption=pfChallan', '', defLength, 0, 0 );
menu[453][53]  = new Item('PF Challan (Custwise)', '../servlet/hr_payroll_report?menuOption=pfChallanCustwise', '', defLength, 0, 0 );

menu[454] = new Array();
menu[454][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[454][1]  = new Item('Define Library', '../servlet/ees_library?menuOption=eesLibrary', '', defLength, 0, 0 );
menu[454][2]  = new Item('Book Inventory', '../servlet/ees_lib_book?menuOption=eesLibBook', '', defLength, 0, 0 );
menu[454][3]  = new Item('Issue and Penalty Rule', '../servlet/ees_lib_issue_rule?menuOption=eesLibIssueRule', '', defLength, 0, 0 );
menu[454][4]  = new Item('Book Status', '../servlet/ees_lib_book?menuOption=changeBookStatus', '', defLength, 0, 0 );

menu[455] = new Array();
menu[455][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[456] = new Array();
menu[456][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[457] = new Array();
menu[457][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[457][1]  = new Item('Issue History(Book)', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[457][2]  = new Item('Reading Pattern', '../servlet/ees_lib_book_issue?menuOption=eesBookTypeWiseReport', '', defLength, 0, 0 );
menu[457][3]  = new Item('Book Inventory Report', '../servlet/ees_library_report?menuOption=eesLibraryBookInventory', '', defLength, 0, 0 );
menu[457][4]  = new Item('Book Issue History', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[457][5]  = new Item('Student Issue History', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[457][6]  = new Item('Penalty Report', 'NA.html', '', defLength, 0, 0 );
menu[457][7]  = new Item('Reading Pattern', '../servlet/ees_lib_book_issue?menuOption=eesBookTypeWiseReport', '', defLength, 0, 0 );

menu[458] = new Array();
menu[458][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[459] = new Array();
menu[459][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[460] = new Array();
menu[460][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[461] = new Array();
menu[461][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[462] = new Array();
menu[462][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[463] = new Array();
menu[463][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[464] = new Array();
menu[464][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[465] = new Array();
menu[465][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[466] = new Array();
menu[466][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[467] = new Array();
menu[467][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[468] = new Array();
menu[468][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[469] = new Array();
menu[469][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[469][1]  = new Item('Department', '../servlet/hr_department?menuOption=hrDepartment', '', defLength, 0, 0 );
menu[469][2]  = new Item('Cost Center(obso)', '../servlet/hr_cost_center?menuOption=hrCostCenter', '', defLength, 0, 0 );
menu[469][3]  = new Item('Logical Groups(obso)', '../servlet/hr_logical_grp?menuOption=hrLogicalGrp', '', defLength, 0, 0 );
menu[469][4]  = new Item('Budget Mgt(obso)', '../servlet/hr_budget_code?menuOption=hrBudgetMgt', '', defLength, 0, 0 );
menu[469][5]  = new Item('Employee Position', '../servlet/hr_position?menuOption=hrPosition', '', defLength, 0, 0 );
menu[469][6]  = new Item('Employee Level', '../servlet/hr_position_level?menuOption=hrPositionLevel', '', defLength, 0, 0 );
menu[469][7]  = new Item('Working Shift', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[469][8]  = new Item('Salary Cycle', 'NA.html', '', defLength, 0, 488 );
menu[469][9]  = new Item('Tax Rule', '../servlet/hr_tax_rule?menuOption=hrTaxRule', '', defLength, 0, 0 );
menu[469][10]  = new Item('Holiday', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[469][11]  = new Item('Financial Year', '../servlet/hr_finance_year_def?menuOption=hrFinanceYearDef', '', defLength, 0, 0 );
menu[469][12]  = new Item('Tax Rebate Reason', '../servlet/hr_tax_rebate_reason?menuOption=hrTaxRebateReason', '', defLength, 0, 0 );
menu[469][13]  = new Item('Absent Code', '../servlet/hr_absent_type?menuOption=hrAbsentType', '', defLength, 0, 0 );
menu[469][14]  = new Item('Salary Head', '../servlet/hr_salary_head?menuOption=hrSalaryHead', '', defLength, 0, 0 );
menu[469][15]  = new Item('Banker', '../servlet/hr_banker?menuOption=hrBanker', '', defLength, 0, 0 );
menu[469][16]  = new Item('Vendor', '../servlet/hr_vendor?menuOption=hrVendor', '', defLength, 0, 0 );
menu[469][17]  = new Item('Customer', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );

menu[470] = new Array();
menu[470][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[470][1]  = new Item('Evaluation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 502 );
menu[470][2]  = new Item('Appreciation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 503 );

menu[471] = new Array();
menu[471][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[471][1]  = new Item('Income', 'NA.html', '', defLength, 0, 504 );
menu[471][2]  = new Item('Deduction', 'NA.html', '', defLength, 0, 505 );

menu[472] = new Array();
menu[472][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[472][1]  = new Item('General Expense', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 506 );
menu[472][2]  = new Item('Local Conveyance', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 507 );

menu[473] = new Array();
menu[473][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[473][1]  = new Item('Upload Card Time', '../servlet/hr_card_time?menuOption=hrCardTime', '', defLength, 0, 0 );
menu[473][2]  = new Item('Daily Attn Sheet', '../servlet/hr_card_time?menuOption=hrAttendancesheet', '', defLength, 0, 0 );
menu[473][3]  = new Item('Weekly Timesheet', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 0 );
menu[473][4]  = new Item('Emp Working Hours', '../servlet/hr_card_time?menuOption=empDailyHour', '', defLength, 0, 0 );
menu[473][5]  = new Item('View Mnthly Attn', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 0 );

menu[474] = new Array();
menu[474][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[474][1]  = new Item('Absent Type (Admin)', '../servlet/hr_absent_type?menuOption=hrAbsentType', '', defLength, 0, 0 );
menu[474][2]  = new Item('Leave Request', '../servlet/hr_vacation_request?menuOption=hrVacationRequest', '', defLength, 0, 0 );
menu[474][3]  = new Item('Leave Approval (Dept)', 'NA.html', '', defLength, 0, 0 );
menu[474][4]  = new Item('Leave Approval (HR)', 'NA.html', '', defLength, 0, 0 );
menu[474][5]  = new Item('Leave Balance', 'NA.html', '', defLength, 0, 0 );
menu[474][6]  = new Item('Leave Encashment', 'NA.html', '', defLength, 0, 0 );

menu[475] = new Array();
menu[475][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[475][1]  = new Item('Loan Type', 'NA.html', '', defLength, 0, 0 );
menu[475][2]  = new Item('Loan Request', 'NA.html', '', defLength, 0, 0 );
menu[475][3]  = new Item('Loan Approval', 'NA.html', '', defLength, 0, 0 );
menu[475][4]  = new Item('Loan Installments', 'NA.html', '', defLength, 0, 0 );
menu[475][5]  = new Item('Pending Loan Installments', 'NA.html', '', defLength, 0, 0 );
menu[475][6]  = new Item('Repayment Alert', 'NA.html', '', defLength, 0, 0 );

menu[476] = new Array();
menu[476][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[476][1]  = new Item('View Own Profile', '../servlet/hr_employee?menuOption=viewOwnProfile', '', defLength, 0, 0 );
menu[476][2]  = new Item('View Others Profile', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaQry', '', defLength, 0, 0 );
menu[476][3]  = new Item('Update Own Profile', 'NA.html', '', defLength, 0, 500 );
menu[476][4]  = new Item('Vacation Balance', 'NA.html', '', defLength, 0, 0 );

menu[477] = new Array();
menu[477][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[477][1]  = new Item('Leave Approval', 'NA.html', '', defLength, 0, 0 );
menu[477][2]  = new Item('Apr Encashed Leave', 'NA.html', '', defLength, 0, 0 );
menu[477][3]  = new Item('Apr Shift Change', 'NA.html', '', defLength, 0, 0 );
menu[477][4]  = new Item('Apr Shift Swap', 'NA.html', '', defLength, 0, 0 );
menu[477][5]  = new Item('Approve Timesheet', 'NA.html', '', defLength, 0, 0 );
menu[477][6]  = new Item('Apr Transfer', 'NA.html', '', defLength, 0, 0 );
menu[477][7]  = new Item('Apr Conveyance Report', 'NA.html', '', defLength, 0, 0 );
menu[477][8]  = new Item('Apr Expense Report', 'NA.html', '', defLength, 0, 0 );
menu[477][9]  = new Item('Apr Travel Request', 'NA.html', '', defLength, 0, 0 );

menu[478] = new Array();
menu[478][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[478][1]  = new Item('Ticket', 'NA.html', '', defLength, 0, 536 );
menu[478][2]  = new Item('Expense Report', 'NA.html', '', defLength, 0, 537 );

menu[479] = new Array();
menu[479][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[479][1]  = new Item('Shift Allocation', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[479][2]  = new Item('Shift Change Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[479][3]  = new Item('Shift Swap Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[479][4]  = new Item('Apr Shift Change Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );

menu[480] = new Array();
menu[480][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[480][1]  = new Item('Req By Emp', 'NA.html', '', defLength, 0, 0 );
menu[480][2]  = new Item('Approval By Manager', 'NA.html', '', defLength, 0, 0 );
menu[480][3]  = new Item('Update Transfer Detail', 'NA.html', '', defLength, 0, 0 );

menu[481] = new Array();
menu[481][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[482] = new Array();
menu[482][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[483] = new Array();
menu[483][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[484] = new Array();
menu[484][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[485] = new Array();
menu[485][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[486] = new Array();
menu[486][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[487] = new Array();
menu[487][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[488] = new Array();
menu[488][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[488][1]  = new Item('New Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[488][2]  = new Item('Open Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[488][3]  = new Item('Close Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );

menu[489] = new Array();
menu[489][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[490] = new Array();
menu[490][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[491] = new Array();
menu[491][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[492] = new Array();
menu[492][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[493] = new Array();
menu[493][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[494] = new Array();
menu[494][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[495] = new Array();
menu[495][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[496] = new Array();
menu[496][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[497] = new Array();
menu[497][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[498] = new Array();
menu[498][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[499] = new Array();
menu[499][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[500] = new Array();
menu[500][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[500][1]  = new Item('Academic Detail', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[500][2]  = new Item('Family Members', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[500][3]  = new Item('Family Academic', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[500][4]  = new Item('Contact Detail', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[500][5]  = new Item('Skill and Domain', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );

menu[501] = new Array();
menu[501][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[502] = new Array();
menu[502][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[502][1]  = new Item('Notification By HR', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][2]  = new Item('Notification By Manager', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][3]  = new Item('Emp Self Evaluation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][4]  = new Item('Emp Feedback', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][5]  = new Item('Emp Rating', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][6]  = new Item('Appraisal Acceptance', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[502][7]  = new Item('Objection on Appraisal', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );

menu[503] = new Array();
menu[503][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[503][1]  = new Item('Appreciation Letter', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[503][2]  = new Item('Apr Incr/Prom', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[503][3]  = new Item('Apr Incr/Prom(HR)', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[503][4]  = new Item('Modify Sal Structure', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[503][5]  = new Item('Arrear Calc', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );

menu[504] = new Array();
menu[504][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[504][1]  = new Item('Overtime', 'NA.html', '', defLength, 0, 0 );
menu[504][2]  = new Item('Bonus', 'NA.html', '', defLength, 0, 0 );
menu[504][3]  = new Item('Gratuity', 'NA.html', '', defLength, 0, 0 );
menu[504][4]  = new Item('Arrear', 'NA.html', '', defLength, 0, 0 );
menu[504][5]  = new Item('Advance', 'NA.html', '', defLength, 0, 0 );
menu[504][6]  = new Item('Imprest', 'NA.html', '', defLength, 0, 0 );
menu[504][7]  = new Item('Incentive', 'NA.html', '', defLength, 0, 0 );
menu[504][8]  = new Item('LTA', 'NA.html', '', defLength, 0, 0 );

menu[505] = new Array();
menu[505][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[505][1]  = new Item('Income Tax', 'NA.html', '', defLength, 0, 0 );
menu[505][2]  = new Item('PF', 'NA.html', '', defLength, 0, 0 );
menu[505][3]  = new Item('ESI', 'NA.html', '', defLength, 0, 0 );

menu[506] = new Array();
menu[506][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[506][1]  = new Item('Expn Report By Emp', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[506][2]  = new Item('Phone Bills', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[506][3]  = new Item('Apr Expense Report', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[506][4]  = new Item('Expense Summary', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );

menu[507] = new Array();
menu[507][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[507][1]  = new Item('Conveyance Form', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[507][2]  = new Item('Apr Conveyance', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );

menu[508] = new Array();
menu[508][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[509] = new Array();
menu[509][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[510] = new Array();
menu[510][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[511] = new Array();
menu[511][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[512] = new Array();
menu[512][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[513] = new Array();
menu[513][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[514] = new Array();
menu[514][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[515] = new Array();
menu[515][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[516] = new Array();
menu[516][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[517] = new Array();
menu[517][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[518] = new Array();
menu[518][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[519] = new Array();
menu[519][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[520] = new Array();
menu[520][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[521] = new Array();
menu[521][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[522] = new Array();
menu[522][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[523] = new Array();
menu[523][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[524] = new Array();
menu[524][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[525] = new Array();
menu[525][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[526] = new Array();
menu[526][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[527] = new Array();
menu[527][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[528] = new Array();
menu[528][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[529] = new Array();
menu[529][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[530] = new Array();
menu[530][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[531] = new Array();
menu[531][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[532] = new Array();
menu[532][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[533] = new Array();
menu[533][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[534] = new Array();
menu[534][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[534][1]  = new Item('Training Course', '../servlet/hr_training_course?menuOption=hrTrainingCourse', '', defLength, 0, 0 );
menu[534][2]  = new Item('Training Charge', '../servlet/hr_training_charge?menuOption=hrTrainingCharge', '', defLength, 0, 0 );
menu[534][3]  = new Item('Define Training', '../servlet/hr_training?menuOption=hrTraining', '', defLength, 0, 0 );
menu[534][4]  = new Item('Trainee List', '../servlet/hr_training?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[534][5]  = new Item('Apr Training Req', '../servlet/hr_training?menuOption=hrTrainingApprove', '', defLength, 0, 0 );
menu[534][6]  = new Item('Training Schedule', '../servlet/hr_training_sch?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[534][7]  = new Item('Training Schedule Report', '../servlet/hr_training_sch?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[534][8]  = new Item('Training Payment', '../servlet/hr_training_charge?menuOption=hrTrainingPayment', '', defLength, 0, 0 );
menu[534][9]  = new Item('Training Req (Emp)', '../servlet/hr_training?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[534][10]  = new Item('Group Training(obso)', '../servlet/hr_training_grp_req?menuOption=hrTrainingGrpReq', '', defLength, 0, 0 );
menu[534][11]  = new Item('Apr Group Training(obso)', '../servlet/hr_training?menuOption=hrTrainingApprove', '', defLength, 0, 0 );

menu[535] = new Array();
menu[535][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[535][1]  = new Item('Confirm As Emp', '../servlet/hr_training?menuOption=hrTrainingConfirmation', '', defLength, 0, 0 );
menu[535][2]  = new Item('Trainer Feedback', '../servlet/hr_training?menuOption=hrTrainingFeedback', '', defLength, 0, 0 );
menu[535][3]  = new Item('Trainee Feedback', '../servlet/hr_training?menuOption=hrTrainingFeedback', '', defLength, 0, 0 );

menu[536] = new Array();
menu[536][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[536][1]  = new Item('Travel Request', '../servlet/hr_travel_req?menuOption=raiseTravelReq', '', defLength, 0, 0 );
menu[536][2]  = new Item('Apr Travel Req(D) ', 'NA.html', '', defLength, 0, 0 );
menu[536][3]  = new Item('Apr Travel Req(H)', 'NA.html', '', defLength, 0, 0 );
menu[536][4]  = new Item('Apr Travel Req(TD)', '../servlet/hr_travel_req?menuOption=inbxDeptMgr&lReqType=travelReq&EmpType=TA', '', defLength, 0, 0 );
menu[536][5]  = new Item('Ticket Delivery', 'NA.html', '', defLength, 0, 0 );

menu[537] = new Array();
menu[537][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[537][1]  = new Item('Travel Expence', '../servlet/hr_travel_expense_report?menuOption=hrTravelExpense', '', defLength, 0, 0 );
menu[537][2]  = new Item('Apr Exp Rep(E)', 'NA.html', '', defLength, 0, 0 );
menu[537][3]  = new Item('Apr Exp Rep(D)', 'NA.html', '', defLength, 0, 0 );
menu[537][4]  = new Item('New Exp Rep(Fin)', 'NA.html', '', defLength, 0, 0 );
menu[537][5]  = new Item('Monthly Trvl Exp Rep', 'NA.html', '', defLength, 0, 0 );

menu[538] = new Array();
menu[538][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[539] = new Array();
menu[539][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[540] = new Array();
menu[540][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[541] = new Array();
menu[541][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[542] = new Array();
menu[542][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[543] = new Array();
menu[543][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[544] = new Array();
menu[544][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[545] = new Array();
menu[545][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[546] = new Array();
menu[546][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[547] = new Array();
menu[547][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[548] = new Array();
menu[548][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[549] = new Array();
menu[549][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[550] = new Array();
menu[550][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[551] = new Array();
menu[551][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[552] = new Array();
menu[552][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[553] = new Array();
menu[553][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[554] = new Array();
menu[554][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[555] = new Array();
menu[555][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[556] = new Array();
menu[556][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[557] = new Array();
menu[557][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[558] = new Array();
menu[558][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[559] = new Array();
menu[559][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[560] = new Array();
menu[560][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[561] = new Array();
menu[561][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[562] = new Array();
menu[562][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[563] = new Array();
menu[563][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[564] = new Array();
menu[564][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[565] = new Array();
menu[565][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[566] = new Array();
menu[566][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[567] = new Array();
menu[567][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[568] = new Array();
menu[568][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[569] = new Array();
menu[569][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[570] = new Array();
menu[570][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[571] = new Array();
menu[571][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[572] = new Array();
menu[572][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[573] = new Array();
menu[573][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[574] = new Array();
menu[574][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[575] = new Array();
menu[575][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[576] = new Array();
menu[576][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[577] = new Array();
menu[577][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[578] = new Array();
menu[578][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[579] = new Array();
menu[579][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[580] = new Array();
menu[580][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[581] = new Array();
menu[581][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[582] = new Array();
menu[582][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[583] = new Array();
menu[583][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[584] = new Array();
menu[584][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[585] = new Array();
menu[585][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[586] = new Array();
menu[586][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[587] = new Array();
menu[587][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[588] = new Array();
menu[588][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[589] = new Array();
menu[589][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[590] = new Array();
menu[590][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[591] = new Array();
menu[591][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[592] = new Array();
menu[592][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[593] = new Array();
menu[593][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[594] = new Array();
menu[594][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[595] = new Array();
menu[595][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[596] = new Array();
menu[596][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[597] = new Array();
menu[597][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[598] = new Array();
menu[598][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[599] = new Array();
menu[599][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[600] = new Array();
menu[600][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[601] = new Array();
menu[601][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[602] = new Array();
menu[602][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[603] = new Array();
menu[603][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[604] = new Array();
menu[604][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[605] = new Array();
menu[605][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[606] = new Array();
menu[606][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[607] = new Array();
menu[607][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[608] = new Array();
menu[608][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[609] = new Array();
menu[609][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[610] = new Array();
menu[610][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[611] = new Array();
menu[611][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[612] = new Array();
menu[612][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[613] = new Array();
menu[613][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[614] = new Array();
menu[614][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[615] = new Array();
menu[615][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[616] = new Array();
menu[616][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[617] = new Array();
menu[617][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[618] = new Array();
menu[618][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[619] = new Array();
menu[619][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[620] = new Array();
menu[620][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[621] = new Array();
menu[621][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[622] = new Array();
menu[622][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[623] = new Array();
menu[623][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[624] = new Array();
menu[624][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[625] = new Array();
menu[625][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[626] = new Array();
menu[626][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[627] = new Array();
menu[627][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[628] = new Array();
menu[628][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[629] = new Array();
menu[629][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[630] = new Array();
menu[630][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[631] = new Array();
menu[631][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[632] = new Array();
menu[632][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[633] = new Array();
menu[633][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[634] = new Array();
menu[634][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[635] = new Array();
menu[635][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[636] = new Array();
menu[636][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[637] = new Array();
menu[637][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[638] = new Array();
menu[638][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[639] = new Array();
menu[639][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[640] = new Array();
menu[640][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[641] = new Array();
menu[641][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[642] = new Array();
menu[642][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[643] = new Array();
menu[643][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[644] = new Array();
menu[644][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[645] = new Array();
menu[645][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[646] = new Array();
menu[646][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[647] = new Array();
menu[647][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[648] = new Array();
menu[648][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[649] = new Array();
menu[649][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[650] = new Array();
menu[650][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[651] = new Array();
menu[651][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[652] = new Array();
menu[652][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[653] = new Array();
menu[653][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[654] = new Array();
menu[654][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[655] = new Array();
menu[655][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[656] = new Array();
menu[656][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[657] = new Array();
menu[657][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[658] = new Array();
menu[658][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[659] = new Array();
menu[659][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[660] = new Array();
menu[660][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[661] = new Array();
menu[661][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[662] = new Array();
menu[662][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[663] = new Array();
menu[663][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[664] = new Array();
menu[664][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[665] = new Array();
menu[665][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[666] = new Array();
menu[666][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[667] = new Array();
menu[667][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[668] = new Array();
menu[668][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[669] = new Array();
menu[669][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[670] = new Array();
menu[670][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[671] = new Array();
menu[671][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[672] = new Array();
menu[672][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[673] = new Array();
menu[673][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[674] = new Array();
menu[674][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[675] = new Array();
menu[675][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[676] = new Array();
menu[676][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[677] = new Array();
menu[677][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[678] = new Array();
menu[678][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[679] = new Array();
menu[679][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[680] = new Array();
menu[680][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[681] = new Array();
menu[681][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[682] = new Array();
menu[682][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[683] = new Array();
menu[683][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[684] = new Array();
menu[684][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[685] = new Array();
menu[685][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[686] = new Array();
menu[686][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[687] = new Array();
menu[687][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[688] = new Array();
menu[688][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[689] = new Array();
menu[689][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[690] = new Array();
menu[690][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[691] = new Array();
menu[691][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[692] = new Array();
menu[692][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[693] = new Array();
menu[693][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[694] = new Array();
menu[694][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[695] = new Array();
menu[695][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[696] = new Array();
menu[696][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[697] = new Array();
menu[697][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[698] = new Array();
menu[698][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[699] = new Array();
menu[699][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[700] = new Array();
menu[700][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[701] = new Array();
menu[701][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[702] = new Array();
menu[702][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[703] = new Array();
menu[703][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[704] = new Array();
menu[704][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[705] = new Array();
menu[705][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[706] = new Array();
menu[706][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[707] = new Array();
menu[707][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[708] = new Array();
menu[708][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[709] = new Array();
menu[709][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[710] = new Array();
menu[710][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[711] = new Array();
menu[711][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[712] = new Array();
menu[712][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[713] = new Array();
menu[713][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[714] = new Array();
menu[714][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[715] = new Array();
menu[715][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[716] = new Array();
menu[716][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[717] = new Array();
menu[717][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[718] = new Array();
menu[718][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[719] = new Array();
menu[719][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[720] = new Array();
menu[720][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[721] = new Array();
menu[721][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[722] = new Array();
menu[722][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[723] = new Array();
menu[723][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[724] = new Array();
menu[724][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[725] = new Array();
menu[725][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[726] = new Array();
menu[726][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[727] = new Array();
menu[727][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[728] = new Array();
menu[728][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[729] = new Array();
menu[729][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[730] = new Array();
menu[730][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[731] = new Array();
menu[731][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[732] = new Array();
menu[732][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[733] = new Array();
menu[733][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[734] = new Array();
menu[734][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[734][1]  = new Item('Budget Code List', '../servlet/fa_vc_txn_report?menuOption=budgetcode', '', defLength, 0, 0 );

menu[735] = new Array();
menu[735][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[735][1]  = new Item('Mess', '../servlet/ees_mess?menuOption=eesMess', '', defLength, 0, 0 );

menu[736] = new Array();
menu[736][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[737] = new Array();
menu[737][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[738] = new Array();
menu[738][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[739] = new Array();
menu[739][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[740] = new Array();
menu[740][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[741] = new Array();
menu[741][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[741][1]  = new Item('Create User', '../servlet/gn_user?menuOption=gnUser', '', defLength, 0, 0 );
menu[741][2]  = new Item('Menu Option Privilage', '../servlet/gn_appln_menu?menuOption=menuPermission', '', defLength, 0, 0 );

menu[742] = new Array();
menu[742][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[743] = new Array();
menu[743][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[744] = new Array();
menu[744][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[745] = new Array();
menu[745][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[746] = new Array();
menu[746][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[747] = new Array();
menu[747][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[747][1]  = new Item('Supplier', '../servlet/esm_supplier?menuOption=esmSupplier', '', defLength, 0, 0 );
menu[747][2]  = new Item('Supplier PO', '../servlet/esm_supplier_po?menuOption=esmSupplierPo', '', defLength, 0, 0 );
menu[747][3]  = new Item('Supplier Payment', '../servlet/esm_supplier_po?menuOption=esmSupplierPo', '', defLength, 0, 0 );

menu[748] = new Array();
menu[748][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[748][1]  = new Item('PO Report', '../servlet/esm_supplier_po_report?menuOption=hrPuschaseOrderReport', '', defLength, 0, 0 );
menu[748][2]  = new Item('Received PO Report', '../servlet/esm_supplier_po_report?menuOption=hrRecievePuschaseOrderReport', '', defLength, 0, 0 );
menu[748][3]  = new Item('Balance Order', '../servlet/esm_supplier_po_report?menuOption=esmBalanceOrderReport', '', defLength, 0, 0 );
menu[748][4]  = new Item('Received Item List', '../servlet/esm_supplier_po_report?menuOption=esmItemReceivingListReport', '', defLength, 0, 0 );

menu[749] = new Array();
menu[749][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[750] = new Array();
menu[750][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[751] = new Array();
menu[751][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[752] = new Array();
menu[752][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[753] = new Array();
menu[753][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[754] = new Array();
menu[754][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[755] = new Array();
menu[755][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[756] = new Array();
menu[756][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[757] = new Array();
menu[757][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[758] = new Array();
menu[758][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[759] = new Array();
menu[759][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[760] = new Array();
menu[760][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[761] = new Array();
menu[761][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[762] = new Array();
menu[762][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[763] = new Array();
menu[763][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[764] = new Array();
menu[764][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[764][1]  = new Item('Job Detail DateWise Report', '../servlet/hr_job_allocation_report?menuOption=hrJobDetailDateWiseReport', '', defLength, 0, 0 );
menu[764][2]  = new Item('Task Alloc History Report', '../servlet/hr_job_allocation_report?menuOption=hrJobAllocTaskHistory', '', defLength, 0, 0 );
menu[764][3]  = new Item('Empwise Task Alloc Report', '../servlet/hr_job_allocation_report?menuOption=hrJobAllocEmpwise', '', defLength, 0, 0 );

  return menu;
}
