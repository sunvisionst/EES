function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


menu[0] = new Array();
menu[0][0]  = new Menu(true, '', inLeftCoord, inTopCoord, inWidth, '#FF9933', '', '', 'itemText');
menu[0][1]  = new Item('Fee', 'NA.html', '', defLength, 0, 3 );

menu[1] = new Array();
menu[1][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[2] = new Array();
menu[2][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[3] = new Array();
menu[3][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[3][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 80 );
menu[3][2]  = new Item('Ledger', 'NA.html', '', defLength, 0, 81 );
menu[3][3]  = new Item('Fee Process', 'NA.html', '', defLength, 0, 82 );
menu[3][4]  = new Item('Fee Reports and Query', 'NA.html', '', defLength, 0, 83 );
menu[3][5]  = new Item('Fee Deposit(obso)', '../servlet/ees_student_fee?menuOption=eesStudentFee', '', defLength, 0, 84 );

menu[4] = new Array();
menu[4][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[5] = new Array();
menu[5][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[6] = new Array();
menu[6][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[7] = new Array();
menu[7][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[8] = new Array();
menu[8][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[9] = new Array();
menu[9][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[10] = new Array();
menu[10][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[11] = new Array();
menu[11][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[12] = new Array();
menu[12][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[13] = new Array();
menu[13][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[14] = new Array();
menu[14][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[15] = new Array();
menu[15][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[16] = new Array();
menu[16][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[17] = new Array();
menu[17][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[18] = new Array();
menu[18][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[19] = new Array();
menu[19][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[20] = new Array();
menu[20][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[21] = new Array();
menu[21][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[22] = new Array();
menu[22][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[23] = new Array();
menu[23][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[24] = new Array();
menu[24][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[25] = new Array();
menu[25][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[26] = new Array();
menu[26][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[27] = new Array();
menu[27][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[28] = new Array();
menu[28][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[29] = new Array();
menu[29][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[30] = new Array();
menu[30][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[31] = new Array();
menu[31][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[32] = new Array();
menu[32][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[33] = new Array();
menu[33][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[34] = new Array();
menu[34][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[35] = new Array();
menu[35][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[36] = new Array();
menu[36][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[37] = new Array();
menu[37][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[38] = new Array();
menu[38][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[39] = new Array();
menu[39][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[40] = new Array();
menu[40][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[41] = new Array();
menu[41][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[42] = new Array();
menu[42][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[43] = new Array();
menu[43][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[44] = new Array();
menu[44][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[45] = new Array();
menu[45][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[46] = new Array();
menu[46][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[47] = new Array();
menu[47][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[48] = new Array();
menu[48][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[49] = new Array();
menu[49][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[50] = new Array();
menu[50][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[51] = new Array();
menu[51][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[52] = new Array();
menu[52][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[53] = new Array();
menu[53][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[54] = new Array();
menu[54][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[55] = new Array();
menu[55][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[56] = new Array();
menu[56][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[57] = new Array();
menu[57][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[58] = new Array();
menu[58][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[59] = new Array();
menu[59][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[60] = new Array();
menu[60][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[61] = new Array();
menu[61][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[62] = new Array();
menu[62][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[63] = new Array();
menu[63][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[64] = new Array();
menu[64][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[65] = new Array();
menu[65][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[66] = new Array();
menu[66][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[67] = new Array();
menu[67][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[68] = new Array();
menu[68][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[69] = new Array();
menu[69][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[70] = new Array();
menu[70][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[71] = new Array();
menu[71][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[72] = new Array();
menu[72][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[73] = new Array();
menu[73][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[74] = new Array();
menu[74][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[75] = new Array();
menu[75][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[76] = new Array();
menu[76][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[77] = new Array();
menu[77][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[78] = new Array();
menu[78][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[79] = new Array();
menu[79][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[79][1]  = new Item('Fee O/S Report', '../servlet/ees_fee_report?menuOption=eesStudentFeeOutstandingReport', '', defLength, 0, 0 );
menu[79][2]  = new Item('Outstanding Fee Orgwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeOrgWiseReport', '', defLength, 0, 0 );
menu[79][3]  = new Item('Outstanding Fee Classwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeClassWiseReport', '', defLength, 0, 0 );

menu[80] = new Array();
menu[80][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[80][1]  = new Item('Fee Head', '../servlet/ees_fee_head?menuOption=eesFeeHead', '', defLength, 0, 0 );
menu[80][2]  = new Item('Class-wise Fee', '../servlet/ees_fee_head_class?menuOption=eesFeeHeadClass', '', defLength, 0, 0 );
menu[80][3]  = new Item('Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[80][4]  = new Item('Late Fee Rule', '../servlet/ees_late_fee_rule?menuOption=lateFeeRule', '', defLength, 0, 0 );
menu[80][5]  = new Item('Fee Concession', '../servlet/ees_fee_concession?menuOption=eesFeeConcession', '', defLength, 0, 0 );
menu[80][6]  = new Item('Transport Fee', '../servlet/ees_tp_fee?menuOption=eesTpFee', '', defLength, 0, 0 );

menu[81] = new Array();
menu[81][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[81][1]  = new Item('Student', '../servlet/ees_student_fee_ledger?menuOption=studentLedger', '', defLength, 0, 0 );
menu[81][2]  = new Item('Fee', '../servlet/ees_student_fee_ledger?menuOption=feeLedger', '', defLength, 0, 0 );

menu[82] = new Array();
menu[82][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[82][1]  = new Item('Planned Fee Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCyclePlanned', '', defLength, 0, 0 );
menu[82][2]  = new Item('Open Bill Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleOpen', '', defLength, 0, 0 );
menu[82][3]  = new Item('Bill Prep', '../servlet/ees_fee_cycle?menuOption=eesFeePrep', '', defLength, 0, 0 );
menu[82][4]  = new Item('Fee Collection - ADM', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=99', '', defLength, 0, 0 );
menu[82][5]  = new Item('Fee Collection - Hostel', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=98', '', defLength, 0, 0 );
menu[82][6]  = new Item('Fee Collection - Transport', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=97', '', defLength, 0, 0 );
menu[82][7]  = new Item('Fee Collection - Exam', '../servlet/ees_fee_cycle?menuOption=FDPC&cycle_id=96', '', defLength, 0, 0 );
menu[82][8]  = new Item('Bill Q&A', '../servlet/ees_fee_cycle?menuOption=eesFeeQA', '', defLength, 0, 0 );
menu[82][9]  = new Item('Bill Print', '../servlet/ees_fee_cycle?menuOption=eesFeePrint', '', defLength, 0, 0 );
menu[82][10]  = new Item('Payment Collection', '../servlet/ees_fee_cycle?menuOption=eesFeeCollection', '', defLength, 0, 0 );
menu[82][11]  = new Item('Bill Cycle Close', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleClose', '', defLength, 0, 0 );
menu[82][12]  = new Item('Coll Center', '../servlet/ees_fee_cycle?menuOption=eesFeeCC', '', defLength, 0, 0 );

menu[83] = new Array();
menu[83][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[83][1]  = new Item('View Fee Structure', '../servlet/ees_view_fee_stucture?menuOption=eesViewFeeStuctureClassNumWise', '', defLength, 0, 0 );
menu[83][2]  = new Item('View Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[83][3]  = new Item('Ledger studentwise', '../servlet/ees_fee_report?menuOption=feeLedgerStudentWise', '', defLength, 0, 0 );
menu[83][4]  = new Item('Ledger Feehead wise', '../servlet/ees_fee_report?menuOption=feeLedgerFeeHeadWise', '', defLength, 0, 0 );
menu[83][5]  = new Item('Collection', '../servlet/ees_fee_report?menuOption=collectionOrgwise', '', defLength, 0, 0 );
menu[83][6]  = new Item('Collection classwise', '../servlet/ees_fee_report?menuOption=collectionClasswise', '', defLength, 0, 0 );
menu[83][7]  = new Item('OS Report', '../servlet/ees_fee_report?menuOption=osOrgwise', '', defLength, 0, 0 );
menu[83][8]  = new Item('OS Classwise', '../servlet/ees_fee_report?menuOption=osClasswise', '', defLength, 0, 0 );
menu[83][9]  = new Item('OS Studentwise', '../servlet/ees_fee_report?menuOption=osStudentwise', '', defLength, 0, 0 );
menu[83][10]  = new Item('Student Fee Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerStudentWise', '', defLength, 0, 0 );
menu[83][11]  = new Item('Fee Head Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerFeeHeadWise', '', defLength, 0, 0 );

menu[84] = new Array();
menu[84][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[84][1]  = new Item('Yearly', '../servlet/ees_student_fee?menuOption=Yearly', '', defLength, 0, 0 );
menu[84][2]  = new Item('Quarterly', '../servlet/ees_student_fee?menuOption=Quarterly', '', defLength, 0, 0 );
menu[84][3]  = new Item('Misc', '../servlet/ees_student_fee?menuOption=Yearly', '', defLength, 0, 0 );

  return menu;
}
