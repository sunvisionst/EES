function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


menu[0] = new Array();
menu[0][0]  = new Menu(true, '', inLeftCoord, inTopCoord, inWidth, '#FF9933', '', '', 'itemText');
menu[0][1]  = new Item('Event', 'NA.html', '', defLength, 0, 24 );

menu[1] = new Array();
menu[1][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[2] = new Array();
menu[2][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[3] = new Array();
menu[3][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[4] = new Array();
menu[4][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[5] = new Array();
menu[5][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[6] = new Array();
menu[6][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[6][1]  = new Item('Exam Admin', 'NA.html', '', defLength, 0, 0 );

menu[7] = new Array();
menu[7][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[8] = new Array();
menu[8][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[9] = new Array();
menu[9][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[10] = new Array();
menu[10][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[11] = new Array();
menu[11][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[12] = new Array();
menu[12][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[13] = new Array();
menu[13][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[14] = new Array();
menu[14][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[15] = new Array();
menu[15][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[16] = new Array();
menu[16][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[17] = new Array();
menu[17][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[18] = new Array();
menu[18][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[19] = new Array();
menu[19][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[20] = new Array();
menu[20][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[21] = new Array();
menu[21][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[22] = new Array();
menu[22][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[23] = new Array();
menu[23][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[24] = new Array();
menu[24][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[24][1]  = new Item('Event Detail', '../servlet/ees_event?menuOption=eesEvent', '', defLength, 0, 0 );
menu[24][2]  = new Item('Event Contact', '../servlet/ees_event_contact?menuOption=eesEventContact', '', defLength, 0, 0 );
menu[24][3]  = new Item('Event Guest Reg', '../servlet/ees_event?menuOption=eesEventRegGuest', '', defLength, 0, 0 );
menu[24][4]  = new Item('Event Activity', '../servlet/ees_event?menuOption=eesEventActivity', '', defLength, 0, 0 );
menu[24][5]  = new Item('Event Stud Reg', '../servlet/ees_event?menuOption=eesEventRegStud', '', defLength, 0, 0 );
menu[24][6]  = new Item('Event Listing', '../servlet/ees_event?menuOption=eventListing', '', defLength, 0, 0 );
menu[24][7]  = new Item('Award', 'NA.html', '', defLength, 0, 0 );
menu[24][8]  = new Item('Event Reports', 'NA.html', '', defLength, 0, 0 );

  return menu;
}
