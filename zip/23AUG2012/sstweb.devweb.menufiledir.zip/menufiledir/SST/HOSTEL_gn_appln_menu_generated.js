function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


menu[0] = new Array();
menu[0][0]  = new Menu(true, '', inLeftCoord, inTopCoord, inWidth, '#FF9933', '', '', 'itemText');
menu[0][1]  = new Item('Hostel', 'NA.html', '', defLength, 0, 8 );

menu[1] = new Array();
menu[1][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[2] = new Array();
menu[2][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[3] = new Array();
menu[3][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[4] = new Array();
menu[4][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[5] = new Array();
menu[5][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[6] = new Array();
menu[6][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[7] = new Array();
menu[7][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[8] = new Array();
menu[8][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[8][1]  = new Item('Hostel Master', 'NA.html', '', defLength, 0, 85 );
menu[8][2]  = new Item('Update Warden', '../servlet/ees_hostel?menuOption=eesHostelWardenUpdate', '', defLength, 0, 0 );
menu[8][3]  = new Item('Set Hostel', '../servlet/ees_hostel?menuOption=eesHostelLogin', '', defLength, 0, 0 );
menu[8][4]  = new Item('Hostel Reg Form', '../servlet/ees_student?menuOption=hostelReg', '', defLength, 0, 0 );
menu[8][5]  = new Item('Room Allotment', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[8][6]  = new Item('Outsider Allotment', '../servlet/ees_hostel_bed?menuOption=eesHostelBedOutsiderStay', '', defLength, 0, 0 );
menu[8][7]  = new Item('Assign Locker', '../servlet/ees_locker?menuOption=eesLocker', '', defLength, 0, 0 );
menu[8][8]  = new Item('Visitor Profile', '../servlet/ees_hostel_visitor?menuOption=eesHostelVisitor', '', defLength, 0, 0 );
menu[8][9]  = new Item('Hostel Summary', '../servlet/ees_hostel_bed?menuOption=eesHostelSummary', '', defLength, 0, 0 );
menu[8][10]  = new Item('Room Deallocation', '../servlet/ees_hostel_bed?menuOption=suspExpul', '', defLength, 0, 0 );
menu[8][11]  = new Item('Exit Entry Reg', '../servlet/ees_hostel_exit_entry_reg?menuOption=eesHostelEntryTime', '', defLength, 0, 0 );
menu[8][12]  = new Item('Visitor Register', 'NA.html', '', defLength, 0, 96 );
menu[8][13]  = new Item('Operate Locker', '../servlet/ees_locker_use?menuOption=eesLockerUse', '', defLength, 0, 0 );
menu[8][14]  = new Item('Complain Register', 'NA.html', '', defLength, 0, 98 );
menu[8][15]  = new Item('Hostel Attn Reg', '../servlet/ees_hostel_attn_reg?menuOption=eesHostelAttnReg', '', defLength, 0, 0 );
menu[8][16]  = new Item('Baggage In', '../servlet/ees_hostel_bed?menuOption=eesHostelBsIn', '', defLength, 0, 0 );
menu[8][17]  = new Item('Baggage Out', '../servlet/ees_hostel_bs?menuOption=eesHostelBsOut', '', defLength, 0, 0 );
menu[8][18]  = new Item('Room Change', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[8][19]  = new Item('Room Change', '../servlet/ees_hostel_bed?menuOption=hrc', '', defLength, 0, 0 );
menu[8][20]  = new Item('Room Type Conversion', '../servlet/ees_hostel_room?menuOption=convRoomType', '', defLength, 0, 0 );
menu[8][21]  = new Item('Hostel Item', '../servlet/ees_hostel_item?menuOption=eesHostelItem', '', defLength, 0, 0 );
menu[8][22]  = new Item('Hostel Staff', '../servlet/ees_hostel_warden?menuOption=eesHostelWarden', '', defLength, 0, 0 );
menu[8][23]  = new Item('Warden History', '../servlet/ees_hostel_warden_hist?menuOption=eesHostelWardenHist', '', defLength, 0, 0 );
menu[8][24]  = new Item('Remove Hostel', '../servlet/ees_hostel?menuOption=eesHostelRemove', '', defLength, 0, 0 );
menu[8][25]  = new Item('Hostel Reports', 'NA.html', '', defLength, 0, 109 );

menu[9] = new Array();
menu[9][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[10] = new Array();
menu[10][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[11] = new Array();
menu[11][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[12] = new Array();
menu[12][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[13] = new Array();
menu[13][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[14] = new Array();
menu[14][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[15] = new Array();
menu[15][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[16] = new Array();
menu[16][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[17] = new Array();
menu[17][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[18] = new Array();
menu[18][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[19] = new Array();
menu[19][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[20] = new Array();
menu[20][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[21] = new Array();
menu[21][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[22] = new Array();
menu[22][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[23] = new Array();
menu[23][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[24] = new Array();
menu[24][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[25] = new Array();
menu[25][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[26] = new Array();
menu[26][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[27] = new Array();
menu[27][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[28] = new Array();
menu[28][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[29] = new Array();
menu[29][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[30] = new Array();
menu[30][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[31] = new Array();
menu[31][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[32] = new Array();
menu[32][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[33] = new Array();
menu[33][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[34] = new Array();
menu[34][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[35] = new Array();
menu[35][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[36] = new Array();
menu[36][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[37] = new Array();
menu[37][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[38] = new Array();
menu[38][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[39] = new Array();
menu[39][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[40] = new Array();
menu[40][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[41] = new Array();
menu[41][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[42] = new Array();
menu[42][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[43] = new Array();
menu[43][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[44] = new Array();
menu[44][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[45] = new Array();
menu[45][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[46] = new Array();
menu[46][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[47] = new Array();
menu[47][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[48] = new Array();
menu[48][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[49] = new Array();
menu[49][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[50] = new Array();
menu[50][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[51] = new Array();
menu[51][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[52] = new Array();
menu[52][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[53] = new Array();
menu[53][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[54] = new Array();
menu[54][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[55] = new Array();
menu[55][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[56] = new Array();
menu[56][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[57] = new Array();
menu[57][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[58] = new Array();
menu[58][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[59] = new Array();
menu[59][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[60] = new Array();
menu[60][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[61] = new Array();
menu[61][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[62] = new Array();
menu[62][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[63] = new Array();
menu[63][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[64] = new Array();
menu[64][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[65] = new Array();
menu[65][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[66] = new Array();
menu[66][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[67] = new Array();
menu[67][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[68] = new Array();
menu[68][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[69] = new Array();
menu[69][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[70] = new Array();
menu[70][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[71] = new Array();
menu[71][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[72] = new Array();
menu[72][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[73] = new Array();
menu[73][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[74] = new Array();
menu[74][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[75] = new Array();
menu[75][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[76] = new Array();
menu[76][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[77] = new Array();
menu[77][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[78] = new Array();
menu[78][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[79] = new Array();
menu[79][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[80] = new Array();
menu[80][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[81] = new Array();
menu[81][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[82] = new Array();
menu[82][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[83] = new Array();
menu[83][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[84] = new Array();
menu[84][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[85] = new Array();
menu[85][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[85][1]  = new Item('Define Hostel', '../servlet/ees_hostel?menuOption=eesHostel', '', defLength, 0, 0 );
menu[85][2]  = new Item('Hostel Fee (roomtype wise)', '../servlet/ees_hostel_fee?menuOption=eesHostelFee', '', defLength, 0, 0 );
menu[85][3]  = new Item('Hostel Floor  ', '../servlet/ees_hostel_flw_qty?menuOption=eesHostelFlwQty', '', defLength, 0, 0 );
menu[85][4]  = new Item('Hostel Wing', '../servlet/ees_hostel_wing?menuOption=eesHostelWing', '', defLength, 0, 0 );
menu[85][5]  = new Item('Room', '../servlet/ees_hostel_room?menuOption=eesRoom', '', defLength, 0, 0 );
menu[85][6]  = new Item('Bed Listing', '../servlet/ees_hostel_bed?menuOption=eesRoomBedListing', '', defLength, 0, 0 );
menu[85][7]  = new Item('Room Inventory', '../servlet/ees_hostel_room_inv?menuOption=eesHostelRoomInvItem', '', defLength, 0, 0 );
menu[85][8]  = new Item('Room Items Listing', '../servlet/ees_hostel_room_item?menuOption=eesHostelRoomItem', '', defLength, 0, 0 );
menu[85][9]  = new Item('Reports', '../servlet/ees_hostel?menuOption=eesHostel', '', defLength, 0, 0 );

menu[86] = new Array();
menu[86][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[87] = new Array();
menu[87][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[88] = new Array();
menu[88][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[89] = new Array();
menu[89][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[90] = new Array();
menu[90][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[91] = new Array();
menu[91][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[92] = new Array();
menu[92][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[93] = new Array();
menu[93][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[94] = new Array();
menu[94][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[95] = new Array();
menu[95][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[96] = new Array();
menu[96][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[96][1]  = new Item('In', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegIn', '', defLength, 0, 0 );
menu[96][2]  = new Item('Out', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegOut', '', defLength, 0, 0 );

menu[97] = new Array();
menu[97][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[98] = new Array();
menu[98][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[98][1]  = new Item('Raise', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRaise', '', defLength, 0, 0 );
menu[98][2]  = new Item('Monitor', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainMonitor', '', defLength, 0, 0 );
menu[98][3]  = new Item('Resolve', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRegResolve', '', defLength, 0, 0 );

menu[99] = new Array();
menu[99][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[100] = new Array();
menu[100][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[101] = new Array();
menu[101][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[102] = new Array();
menu[102][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[103] = new Array();
menu[103][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[104] = new Array();
menu[104][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[105] = new Array();
menu[105][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[106] = new Array();
menu[106][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[107] = new Array();
menu[107][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[108] = new Array();
menu[108][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[109] = new Array();
menu[109][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[109][1]  = new Item('Hostel Room Allotment', '../servlet/ees_hostel?menuOption=eesHostelAllotmentReport', '', defLength, 0, 0 );
menu[109][2]  = new Item('Hostel Exit Entry List', '../servlet/ees_hostel?menuOption=eesHostelExitEntryReport', '', defLength, 0, 0 );
menu[109][3]  = new Item('Hostel Room Inv Reports', '../servlet/ees_hostel_report?menuOption=eesHostelItemRoomInventory', '', defLength, 0, 0 );
menu[109][4]  = new Item('Hostel Reg Form Printed', '../servlet/ees_hostel_report?menuOption=eesHostelRegistrationForm', '', defLength, 0, 0 );
menu[109][5]  = new Item('Declaration Letter', '../servlet/ees_hostel_report?menuOption=eesHostelDeclarationLetter', '', defLength, 0, 0 );
menu[109][6]  = new Item('Locker List', '../servlet/ees_hostel_report?menuOption=eesHostelLocker', '', defLength, 0, 0 );
menu[109][7]  = new Item('Hostel Use Reg', '../servlet/ees_hostel_report?menuOption=eesHostelLockerVisit', '', defLength, 0, 0 );
menu[109][8]  = new Item('Room Allotment Reports', '../servlet/ees_hostel_report?menuOption=eesHostelRoomAllotment', '', defLength, 0, 0 );
menu[109][9]  = new Item('Deaalication Reports', '../servlet/ees_hostel_report?menuOption=eesHostelRoomDealloate', '', defLength, 0, 0 );
menu[109][10]  = new Item('Oytsider Register', '../servlet/ees_hostel_report?menuOption=eesHostelBedOutsiderStay', '', defLength, 0, 0 );
menu[109][11]  = new Item('Visiter Register', '../servlet/ees_hostel_report?menuOption=eesHostelVisitorVisitReport', '', defLength, 0, 0 );
menu[109][12]  = new Item('Baggage Register', '../servlet/ees_hostel_report?menuOption=eesHostelStudentBaggage', '', defLength, 0, 0 );
menu[109][13]  = new Item('Item Inventory Register', '../servlet/ees_hostel_report?menuOption=eesHostelInventory', '', defLength, 0, 0 );

  return menu;
}
