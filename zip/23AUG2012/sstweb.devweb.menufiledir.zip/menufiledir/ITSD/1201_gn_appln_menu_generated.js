function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


menu[0] = new Array();
menu[0][0]  = new Menu(true, '', inLeftCoord, inTopCoord, inWidth, '#FF9933', '', '', 'itemText');
menu[0][1]  = new Item('Human Resourse', 'NA.html', '', defLength, 0, 1 );
menu[0][2]  = new Item('Admission', 'NA.html', '', defLength, 0, 2 );
menu[0][3]  = new Item('Fee', 'NA.html', '', defLength, 0, 3 );
menu[0][4]  = new Item('Academic', 'NA.html', '', defLength, 0, 4 );
menu[0][5]  = new Item('Timetable', 'NA.html', '', defLength, 0, 5 );
menu[0][6]  = new Item('Exam', 'NA.html', '', defLength, 0, 6 );
menu[0][7]  = new Item('Hostel', 'NA.html', '', defLength, 0, 7 );
menu[0][8]  = new Item('Transport', 'NA.html', '', defLength, 0, 8 );
menu[0][9]  = new Item('Lab', 'NA.html', '', defLength, 0, 9 );
menu[0][10]  = new Item('Library', 'NA.html', '', defLength, 0, 10 );
menu[0][11]  = new Item('T & P', 'NA.html', '', defLength, 0, 11 );
menu[0][12]  = new Item('HRMS', 'NA.html', '', defLength, 0, 12 );
menu[0][13]  = new Item('Finance', 'NA.html', '', defLength, 0, 13 );
menu[0][14]  = new Item('MIS Reports', 'NA.html', '', defLength, 0, 14 );
menu[0][15]  = new Item('UPTU Interface', 'http://www.uptu.org', '', defLength, 0, 0 );
menu[0][16]  = new Item('Alumini', 'NA.html', '', defLength, 0, 16 );
menu[0][17]  = new Item('Event', 'NA.html', '', defLength, 0, 17 );
menu[0][18]  = new Item('Scholorship', 'NA.html', '', defLength, 0, 18 );
menu[0][19]  = new Item('Grant', 'NA.html', '', defLength, 0, 19 );
menu[0][20]  = new Item('Administrator', 'NA.html', '', defLength, 0, 20 );
menu[0][21]  = new Item('Sunvision Admin', 'NA.html', '', defLength, 0, 21 );

menu[1] = new Array();
menu[1][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[1][1]  = new Item('Infrastructure', 'NA.html', '', defLength, 0, 26 );
menu[1][2]  = new Item('Department', 'NA.html', '', defLength, 0, 27 );
menu[1][3]  = new Item('Employee Profile', 'NA.html', '', defLength, 0, 28 );
menu[1][4]  = new Item('HR Reports', 'NA.html', '', defLength, 0, 0 );

menu[2] = new Array();
menu[2][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[2][1]  = new Item('Admin Process', 'NA.html', '', defLength, 0, 62 );
menu[2][2]  = new Item('Online Process', 'NA.html', '', defLength, 0, 63 );
menu[2][3]  = new Item('Admission Pro', 'NA.html', '', defLength, 0, 64 );
menu[2][4]  = new Item('Prospectus', 'NA.html', '', defLength, 0, 65 );
menu[2][5]  = new Item('Selection Process', 'NA.html', '', defLength, 0, 66 );
menu[2][6]  = new Item('Admit Card', 'NA.html', '', defLength, 0, 67 );
menu[2][7]  = new Item('Direct Selection', 'NA.html', '', defLength, 0, 68 );
menu[2][8]  = new Item('Admission Process', 'NA.html', '', defLength, 0, 69 );
menu[2][9]  = new Item('Student Profile', 'NA.html', '', defLength, 0, 70 );
menu[2][10]  = new Item('Adm Reports', 'NA.html', '', defLength, 0, 71 );

menu[3] = new Array();
menu[3][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[3][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 72 );
menu[3][2]  = new Item('Fee Deposit', '../servlet/ees_student_fee?menuOption=eesStudentFee', '', defLength, 0, 73 );
menu[3][3]  = new Item('Ledger', 'NA.html', '', defLength, 0, 74 );
menu[3][4]  = new Item('Fee Process', 'NA.html', '', defLength, 0, 75 );
menu[3][5]  = new Item('Fee Reports and Query', 'NA.html', '', defLength, 0, 76 );

menu[4] = new Array();
menu[4][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[4][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 37 );
menu[4][2]  = new Item('Upload Syllabus', '../servlet/ees_lecture_plan?menuOption=uploadSylb', '', defLength, 0, 0 );
menu[4][3]  = new Item('Subject Allocation', 'NA.html', '', defLength, 0, 39 );
menu[4][4]  = new Item('Academic Reports', 'NA.html', '', defLength, 0, 40 );

menu[5] = new Array();
menu[5][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[5][1]  = new Item('Timetable Preparation', 'NA.html', '', defLength, 0, 321 );
menu[5][2]  = new Item('ADR', 'NA.html', '', defLength, 0, 322 );
menu[5][3]  = new Item('Timetable Reports', 'NA.html', '', defLength, 0, 323 );

menu[6] = new Array();
menu[6][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[6][1]  = new Item('Exam Admin', 'NA.html', '', defLength, 0, 53 );
menu[6][2]  = new Item('Exam Mgt', 'NA.html', '', defLength, 0, 54 );
menu[6][3]  = new Item('Exam Result', 'NA.html', '', defLength, 0, 55 );
menu[6][4]  = new Item('Question Model Paper', '../servlet/ees_exam_question?menuOption=eesExamQuestionModelPaper', '', defLength, 0, 0 );
menu[6][5]  = new Item('Exam Reports', 'NA.html', '', defLength, 0, 57 );

menu[7] = new Array();
menu[7][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[7][1]  = new Item('Hostel Master', 'NA.html', '', defLength, 0, 77 );
menu[7][2]  = new Item('Update Warden', '../servlet/ees_hostel?menuOption=eesHostelWardenUpdate', '', defLength, 0, 0 );
menu[7][3]  = new Item('Room Allotment', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[7][4]  = new Item('Room Change', '../servlet/ees_hostel_bed?menuOption=eesRoomBed', '', defLength, 0, 0 );
menu[7][5]  = new Item('Pay Mess Fee ', '../servlet/ees_mess_fee?menuOption=eesMessFee', '', defLength, 0, 0 );
menu[7][6]  = new Item('Exit Entry Reg', '../servlet/ees_hostel_exit_entry_reg?menuOption=eesHostelEntryTime', '', defLength, 0, 0 );
menu[7][7]  = new Item('Visitor Register', 'NA.html', '', defLength, 0, 83 );
menu[7][8]  = new Item('Complain Register', 'NA.html', '', defLength, 0, 84 );
menu[7][9]  = new Item('Warden History', '../servlet/ees_hostel_warden_hist?menuOption=eesHostelWardenHist', '', defLength, 0, 0 );
menu[7][10]  = new Item('Hostel Reports', 'NA.html', '', defLength, 0, 86 );

menu[8] = new Array();
menu[8][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[8][1]  = new Item('Contract', '../servlet/ees_contract?menuOption=eesContract', '', defLength, 0, 0 );
menu[8][2]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 0 );
menu[8][3]  = new Item('Vehicle Driver', '../servlet/ees_vehicle_driver?menuOption=eesVehicleDriver', '', defLength, 0, 0 );
menu[8][4]  = new Item('Vehicle Location', '../servlet/ees_vehicle_location?menuOption=eesVehicleLocation', '', defLength, 0, 0 );
menu[8][5]  = new Item('Student Trip', '../servlet/ees_student_trip?menuOption=eesStudentTrip', '', defLength, 0, 0 );
menu[8][6]  = new Item('Route', 'NA.html', '', defLength, 0, 148 );
menu[8][7]  = new Item('Issue Trip Work Order', '../servlet/ees_daily_trip?menuOption=eesDailyTrip', '', defLength, 0, 0 );
menu[8][8]  = new Item('Transport Reports', 'NA.html', '', defLength, 0, 0 );

menu[9] = new Array();
menu[9][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[9][1]  = new Item('Login', '../servlet/ees_lab?menuOption=loginLab', '', defLength, 0, 0 );
menu[9][2]  = new Item('Lab Admin', 'NA.html', '', defLength, 0, 102 );
menu[9][3]  = new Item('Lab Automation', 'NA.html', '', defLength, 0, 103 );
menu[9][4]  = new Item('Student Attendance', '../servlet/ees_lab_its?action=ees_go_lab_attendence_submit&menuOption=kkkkkk', '', defLength, 0, 0 );
menu[9][5]  = new Item('Lab Report', 'NA.html', '', defLength, 0, 105 );
menu[9][6]  = new Item('History Report', 'NA.html', '', defLength, 0, 106 );

menu[10] = new Array();
menu[10][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[10][1]  = new Item('Library Admin', 'NA.html', '', defLength, 0, 390 );
menu[10][2]  = new Item('Issue and Return', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssue', '', defLength, 0, 0 );
menu[10][3]  = new Item('Attendance', '../servlet/ees_lib_attn_reg?menuOption=eesLibAttnReg', '', defLength, 0, 0 );
menu[10][4]  = new Item('Query and Report', 'NA.html', '', defLength, 0, 393 );

menu[11] = new Array();
menu[11][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[11][1]  = new Item('TNP Admin', 'NA.html', '', defLength, 0, 90 );
menu[11][2]  = new Item('Company Followup', '../servlet/ees_tnp_cfr?menuOption=tnpCFR', '', defLength, 0, 0 );
menu[11][3]  = new Item('Interview Detail', 'NA.html', '', defLength, 0, 92 );
menu[11][4]  = new Item('List', 'NA.html', '', defLength, 0, 93 );
menu[11][5]  = new Item('Training Detail', '../servlet/ees_training_sch?menuOption=trainingSch', '', defLength, 0, 0 );
menu[11][6]  = new Item('Select Student', '../servlet/ees_tnp_ci_student?menuOption=selectedStudent', '', defLength, 0, 0 );
menu[11][7]  = new Item('TNP Reports', 'NA.html', '', defLength, 0, 96 );

menu[12] = new Array();
menu[12][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[12][1]  = new Item('Administrator', 'NA.html', '', defLength, 0, 404 );
menu[12][2]  = new Item('Emp Mgt', 'NA.html', '', defLength, 0, 405 );
menu[12][3]  = new Item('Payroll', 'NA.html', '', defLength, 0, 406 );
menu[12][4]  = new Item('Increment Promotion', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 407 );
menu[12][5]  = new Item('Income Deduction', 'NA.html', '', defLength, 0, 408 );
menu[12][6]  = new Item('Expn Reimbursement', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 409 );
menu[12][7]  = new Item('Time Management', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 410 );
menu[12][8]  = new Item('Leave Management', 'NA.html', '', defLength, 0, 411 );
menu[12][9]  = new Item('Loan Management', 'NA.html', '', defLength, 0, 412 );
menu[12][10]  = new Item('Emp Self Care', 'NA.html', '', defLength, 0, 413 );
menu[12][11]  = new Item('Manager Self Care', 'NA.html', '', defLength, 0, 414 );
menu[12][12]  = new Item('Recruitment', 'NA.html', '', defLength, 0, 415 );
menu[12][13]  = new Item('Training', 'NA.html', '', defLength, 0, 416 );
menu[12][14]  = new Item('Travel Management', 'NA.html', '', defLength, 0, 417 );
menu[12][15]  = new Item('Customer Care and Billing', 'NA.html', '', defLength, 0, 418 );
menu[12][16]  = new Item('Shift Management', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 419 );
menu[12][17]  = new Item('AR and Collection', 'NA.html', '', defLength, 0, 420 );
menu[12][18]  = new Item('Transfer Management', 'NA.html', '', defLength, 0, 421 );

menu[13] = new Array();
menu[13][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[13][1]  = new Item('Admin', 'NA.html', '', defLength, 0, 58 );
menu[13][2]  = new Item('Voucher', 'NA.html', '', defLength, 0, 59 );
menu[13][3]  = new Item('Ledger Master', 'NA.html', '', defLength, 0, 60 );
menu[13][4]  = new Item('Finance Report', 'NA.html', '', defLength, 0, 61 );

menu[14] = new Array();
menu[14][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[14][1]  = new Item('General', 'NA.html', '', defLength, 0, 0 );
menu[14][2]  = new Item('HR Reports', 'NA.html', '', defLength, 0, 385 );
menu[14][3]  = new Item('CC and B', 'NA.html', '', defLength, 0, 386 );
menu[14][4]  = new Item('Recruitment', 'NA.html', '', defLength, 0, 0 );
menu[14][5]  = new Item('Training', 'NA.html', '', defLength, 0, 388 );
menu[14][6]  = new Item('Payroll', 'NA.html', '', defLength, 0, 389 );

menu[15] = new Array();
menu[15][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[16] = new Array();
menu[16][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[16][1]  = new Item('Login', '../servlet/ees_alumni?menuOption=eesAlumniRegistration', '', defLength, 0, 0 );
menu[16][2]  = new Item('From Student DB', '../servlet/ees_alumni?menuOption=eesAlumniImportfromStudent', '', defLength, 0, 0 );
menu[16][3]  = new Item('Memories', 'NA.html', '', defLength, 0, 99 );
menu[16][4]  = new Item('Alumni Reports', 'NA.html', '', defLength, 0, 100 );

menu[17] = new Array();
menu[17][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[17][1]  = new Item('Event Detail', '../servlet/ees_event?menuOption=eesEvent', '', defLength, 0, 0 );
menu[17][2]  = new Item('Event Contact', '../servlet/ees_event_contact?menuOption=eesEventContact', '', defLength, 0, 0 );
menu[17][3]  = new Item('Event Guest Reg', '../servlet/ees_event?menuOption=eesEventRegGuest', '', defLength, 0, 0 );
menu[17][4]  = new Item('Event Activity', '../servlet/ees_event?menuOption=eesEventActivity', '', defLength, 0, 0 );
menu[17][5]  = new Item('Event Stud Reg', '../servlet/ees_event?menuOption=eesEventRegStud', '', defLength, 0, 0 );
menu[17][6]  = new Item('Event Listing', '../servlet/ees_event?menuOption=eventListing', '', defLength, 0, 0 );
menu[17][7]  = new Item('Award', 'NA.html', '', defLength, 0, 0 );
menu[17][8]  = new Item('Event Reports', 'NA.html', '', defLength, 0, 0 );

menu[18] = new Array();
menu[18][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[18][1]  = new Item('Define SchShip', '../servlet/ees_sch_ship?menuOption=eesSchShip', '', defLength, 0, 0 );
menu[18][2]  = new Item('Stud SchShip', '../servlet/ees_student_sch_ship?menuOption=eesStudentSchShip', '', defLength, 0, 0 );
menu[18][3]  = new Item('Class SchShip', '../servlet/ees_class_sch_ship?menuOption=eesClassSchShip', '', defLength, 0, 0 );
menu[18][4]  = new Item('Search', '../servlet/ees_student_sch_ship?menuOption=schQuery', '', defLength, 0, 0 );
menu[18][5]  = new Item('Scship Reports', 'NA.html', '', defLength, 0, 0 );

menu[19] = new Array();
menu[19][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[19][1]  = new Item('Define Granter', '../servlet/ees_granter?menuOption=eesGranter', '', defLength, 0, 0 );
menu[19][2]  = new Item('Define Grant', '../servlet/ees_grant?menuOption=eesGrant', '', defLength, 0, 0 );
menu[19][3]  = new Item('Grant Inst', '../servlet/ees_grant_inst?menuOption=eesGrantInst', '', defLength, 0, 0 );
menu[19][4]  = new Item('Grant Reports', 'NA.html', '', defLength, 0, 0 );

menu[20] = new Array();
menu[20][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[20][1]  = new Item('Appln Security', 'NA.html', '', defLength, 0, 22 );
menu[20][2]  = new Item('Sys Config', 'NA.html', '', defLength, 0, 23 );
menu[20][3]  = new Item('Portal Page', 'NA.html', '', defLength, 0, 24 );
menu[20][4]  = new Item('Backup and Restore', 'NA.html', '', defLength, 0, 25 );

menu[21] = new Array();
menu[21][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[21][1]  = new Item('Type Parameter', 'NA.html', '', defLength, 0, 128 );
menu[21][2]  = new Item('Application Menu', 'NA.html', '', defLength, 0, 129 );
menu[21][3]  = new Item('Product Testing', 'NA.html', '', defLength, 0, 130 );
menu[21][4]  = new Item('Geo Location', 'NA.html', '', defLength, 0, 131 );
menu[21][5]  = new Item('Sys Config', 'NA.html', '', defLength, 0, 132 );
menu[21][6]  = new Item('User Productivity Report', 'NA.html', '', defLength, 0, 0 );

menu[22] = new Array();
menu[22][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[22][1]  = new Item('Create User', '../servlet/gn_user?menuOption=gnUser', '', defLength, 0, 0 );
menu[22][2]  = new Item('Menu Option Privilage', '../servlet/gn_appln_menu?menuOption=menuPermission', '', defLength, 0, 0 );

menu[23] = new Array();
menu[23][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[23][1]  = new Item('Sequence Param', '../servlet/sst_config?menuOption=esmSeqList', '', defLength, 0, 0 );
menu[23][2]  = new Item('Holiday', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[23][3]  = new Item('Change Password', '../servlet/gn_login?menuOption=changePassword', '', defLength, 0, 0 );

menu[24] = new Array();
menu[24][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[24][1]  = new Item('Client Logo', '../servlet/ees_home_college_desc?menuOption=clientLogo', '', defLength, 0, 0 );
menu[24][2]  = new Item('Main Banner', '../servlet/ees_home_college_desc?menuOption=mainBanner', '', defLength, 0, 0 );
menu[24][3]  = new Item('Bottom Login Box', '../servlet/ees_home_college_desc?menuOption=bottomLoginBox', '', defLength, 0, 0 );
menu[24][4]  = new Item('Change Style', '../servlet/gn_lnf_template?menuOption=gnLnfTemplate', '', defLength, 0, 0 );
menu[24][5]  = new Item('Edit College Desc', '../servlet/ees_home_college_desc?menuOption=eesHomeCollegeDesc', '', defLength, 0, 0 );
menu[24][6]  = new Item('Edit Right To Info', '../servlet/ees_home_right_to_info?menuOption=eesHomeRightToInfo', '', defLength, 0, 0 );

menu[25] = new Array();
menu[25][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[25][1]  = new Item('Appln Backup', '../servlet/sst_admin_servlet?menuOption=applnBkp', '', defLength, 0, 0 );
menu[25][2]  = new Item('Database Backup', '../servlet/sst_admin_servlet?menuOption=databaseBkp', '', defLength, 0, 0 );
menu[25][3]  = new Item('Restore Database Backup', '../servlet/sst_admin_servlet?menuOption=dbRestore', '', defLength, 0, 0 );

menu[26] = new Array();
menu[26][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[26][1]  = new Item('Organization', '../servlet/hr_organization?menuOption=hrOrganization', '', defLength, 0, 0 );
menu[26][2]  = new Item('Building and Room', '../servlet/hr_building?menuOption=hrBuilding', '', defLength, 0, 0 );
menu[26][3]  = new Item('Bldg Room (obso)', '../servlet/hr_building_room?menuOption=hrBuildingRoom', '', defLength, 0, 0 );

menu[27] = new Array();
menu[27][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[27][1]  = new Item('Define Department', '../servlet/hr_department?menuOption=hrDepartment', '', defLength, 0, 0 );

menu[28] = new Array();
menu[28][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[28][1]  = new Item('Create Profile', '../servlet/hr_employee?menuOption=createProfile', '', defLength, 0, 0 );
menu[28][2]  = new Item('Update Profile(H)', 'NA.html', '', defLength, 0, 31 );
menu[28][3]  = new Item('View Profile(H)', 'NA.html', '', defLength, 0, 32 );

menu[29] = new Array();
menu[29][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[30] = new Array();
menu[30][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[31] = new Array();
menu[31][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[31][1]  = new Item('Self', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[31][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaUpd', '', defLength, 0, 0 );

menu[32] = new Array();
menu[32][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[32][1]  = new Item('Self', '../servlet/hr_employee?menuOption=viewOwnProfile', '', defLength, 0, 0 );
menu[32][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaQry', '', defLength, 0, 0 );

menu[33] = new Array();
menu[33][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[34] = new Array();
menu[34][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[35] = new Array();
menu[35][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[36] = new Array();
menu[36][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[37] = new Array();
menu[37][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[37][1]  = new Item('Acad Session (ADM)', '../servlet/ees_academic_session?menuOption=eesAcademicSession', '', defLength, 0, 0 );
menu[37][2]  = new Item('Define Period', '../servlet/ees_period?menuOption=eesPeriod', '', defLength, 0, 0 );
menu[37][3]  = new Item('Define Course', '../servlet/ees_course?menuOption=eesCourse', '', defLength, 0, 0 );
menu[37][4]  = new Item('Define Class', '../servlet/ees_class?menuOption=eesClass', '', defLength, 0, 0 );
menu[37][5]  = new Item('Class Teacher', '../servlet/ees_class?menuOption=eesClassTeacher', '', defLength, 0, 0 );
menu[37][6]  = new Item('Room Class', '../servlet/ees_class?menuOption=eesRoomClass', '', defLength, 0, 0 );
menu[37][7]  = new Item('Define Subject', '../servlet/ees_subject?menuOption=eesSubject', '', defLength, 0, 0 );

menu[38] = new Array();
menu[38][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[39] = new Array();
menu[39][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[39][1]  = new Item('Choice From Faculty', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoice', '', defLength, 0, 0 );
menu[39][2]  = new Item('Admin Subject Choice', '../servlet/ees_subject_allocation?menuOption=eesSubjectChoiceView', '', defLength, 0, 0 );
menu[39][3]  = new Item('Subject Distribution', '../servlet/ees_subject_allocation?menuOption=eesSubjectDistribution', '', defLength, 0, 0 );
menu[39][4]  = new Item('Sub Alloc (Direct)', '../servlet/ees_subject_allocation?menuOption=eesSubjectDistribution', '', defLength, 0, 0 );

menu[40] = new Array();
menu[40][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[40][1]  = new Item('Class Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassWiseList', '', defLength, 0, 0 );
menu[40][2]  = new Item('Subject Detail', '../servlet/ees_subject?menuOption=subjectReport', '', defLength, 0, 0 );
menu[40][3]  = new Item('Subject Allocation', '../servlet/ees_academic_report?menuOption=eesAcademicSubjectAllocationReport', '', defLength, 0, 0 );
menu[40][4]  = new Item('Faculty Performance', '../servlet/ees_adr?menuOption=eesAdrFacultyProgressReport', '', defLength, 0, 0 );
menu[40][5]  = new Item('Class Teacher Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassTeacherWiseList', '', defLength, 0, 0 );
menu[40][6]  = new Item('Student Listing', '../servlet/ees_academic_report?menuOption=eesAcademicStudentListReport', '', defLength, 0, 0 );
menu[40][7]  = new Item('Subject Listing', '../servlet/ees_academic_report?menuOption=eesAcademicClassWiseSubjectList', '', defLength, 0, 0 );

menu[41] = new Array();
menu[41][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[42] = new Array();
menu[42][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[43] = new Array();
menu[43][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[44] = new Array();
menu[44][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[45] = new Array();
menu[45][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[46] = new Array();
menu[46][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[47] = new Array();
menu[47][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[48] = new Array();
menu[48][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[49] = new Array();
menu[49][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[50] = new Array();
menu[50][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[51] = new Array();
menu[51][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[52] = new Array();
menu[52][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[53] = new Array();
menu[53][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[53][1]  = new Item('Academic Session', '../servlet/ees_academic_session?menuOption=eesAcademicSession', '', defLength, 0, 0 );
menu[53][2]  = new Item('Valid Values', 'NA.html', '', defLength, 0, 299 );
menu[53][3]  = new Item('Exam Term', '../servlet/ees_exam_term?menuOption=eesExamTerm', '', defLength, 0, 0 );
menu[53][4]  = new Item('Buidling', '../servlet/hr_building?menuOption=hrBuilding', '', defLength, 0, 0 );
menu[53][5]  = new Item('Subject Mark Rule', '../servlet/ees_subject_mark_rule?menuOption=eesSubjectMarkRule', '', defLength, 0, 0 );
menu[53][6]  = new Item('Marksheet Layout', '../servlet/ees_marksheet_lo?menuOption=eesMarksheetLo', '', defLength, 0, 0 );
menu[53][7]  = new Item('Exam Room Capacity', '../servlet/ees_exam_seat_plan?menuOption=eesExamSeatPlanStd', '', defLength, 0, 0 );

menu[54] = new Array();
menu[54][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[54][1]  = new Item('Define Exam', '../servlet/ees_exam?menuOption=eesExam', '', defLength, 0, 0 );
menu[54][2]  = new Item('Room Capacity', '../servlet/ees_exam_seat_plan?menuOption=eesExamSeatPlan', '', defLength, 0, 0 );
menu[54][3]  = new Item('Define Schedule', '../servlet/ees_exam?menuOption=eesExamScheduleDefine', '', defLength, 0, 0 );
menu[54][4]  = new Item('Seat Allocation', '../servlet/ees_exam_seat_allocation?menuOption=eesExamSeatAllocation', '', defLength, 0, 0 );
menu[54][5]  = new Item('Student Attendence', '../servlet/ees_exam_seat_allocation?menuOption=eesStudentAttendenceRoomWise', '', defLength, 0, 0 );
menu[54][6]  = new Item('Exam Quest Paper', '../servlet/ees_exam_question?menuOption=eesExamQuestion', '', defLength, 0, 0 );
menu[54][7]  = new Item('Incharge(obso)', '../servlet/ees_exam?menuOption=eesExamInchargAndStudentRange', '', defLength, 0, 0 );

menu[55] = new Array();
menu[55][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[55][1]  = new Item('Marks Entry', '../servlet/ees_student_mark?menuOption=eesStudentMark', '', defLength, 0, 0 );
menu[55][2]  = new Item('Student Remark Entry', '../servlet/ees_student_mark?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );
menu[55][3]  = new Item('Report Card', '../servlet/ees_exam_report?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );
menu[55][4]  = new Item('View Report Card(obso)', '../servlet/ees_report_card?menuOption=eesReportCard', '', defLength, 0, 0 );
menu[55][5]  = new Item('Student Remark (Obso)', '../servlet/ees_report_card?menuOption=eesReportCard', '', defLength, 0, 0 );
menu[55][6]  = new Item('Bulk Remark (Obso)', '../servlet/ees_student_marksheet?menuOption=eesStudentMarksheet', '', defLength, 0, 0 );

menu[56] = new Array();
menu[56][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[57] = new Array();
menu[57][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[57][1]  = new Item('Exam Schedule', '../servlet/ees_exam_report?menuOption=eesExamSchReport', '', defLength, 0, 0 );
menu[57][2]  = new Item('Seat Plan', '../servlet/ees_exam_report?menuOption=eesExamSeatPlanReport', '', defLength, 0, 0 );
menu[57][3]  = new Item('Exam Room List', '../servlet/ees_exam_report?menuOption=eesExamRoomListReport', '', defLength, 0, 0 );
menu[57][4]  = new Item('Student Attn Report', '../servlet/ees_exam_report?menuOption=eesStudentAttendanceReport', '', defLength, 0, 0 );
menu[57][5]  = new Item('Student Obtained Mark', '../servlet/ees_exam_report?menuOption=eesStudentObtainedMarkGrpAdmReport', '', defLength, 0, 0 );
menu[57][6]  = new Item('Top Rankers', '../servlet/ees_exam_report?menuOption=eesExamTopRankingReport', '', defLength, 0, 0 );
menu[57][7]  = new Item('Top Rankers in Group', '../servlet/ees_exam_report?menuOption=eesExamTopRankingGrpAdmReport', '', defLength, 0, 0 );

menu[58] = new Array();
menu[58][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[58][1]  = new Item('Account Group', '../servlet/fa_account_group?menuOption=faAccountGroup1', '', defLength, 0, 0 );
menu[58][2]  = new Item('GL Accounts', '../servlet/fa_gl_account?menuOption=faGlAccount1', '', defLength, 0, 0 );
menu[58][3]  = new Item('Voucher Type', '../servlet/fa_voucher?menuOption=faVoucher', '', defLength, 0, 0 );
menu[58][4]  = new Item('Cr - Dr Rule', '../servlet/fa_cr_dr_rule?menuOption=faCrDrRule1', '', defLength, 0, 0 );
menu[58][5]  = new Item('Voucher Limit', '../servlet/fa_vc_limit_rule?menuOption=faVcLimitRule', '', defLength, 0, 0 );

menu[59] = new Array();
menu[59][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[59][1]  = new Item('Voucher Entry', '../servlet/fa_vc_txn?menuOption=faVcTxn', '', defLength, 0, 0 );
menu[59][2]  = new Item('Pending Voucher Entry', '../servlet/fa_vc_txn?menuOption=pendingVoucher', '', defLength, 0, 0 );

menu[60] = new Array();
menu[60][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[60][1]  = new Item('Customer Ledger', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );
menu[60][2]  = new Item('Supplier Ledger', '../servlet/esm_supplier?menuOption=defineSupplier', '', defLength, 0, 0 );
menu[60][3]  = new Item('Emp Ledger ', '../servlet/hr_employee?menuOption=createProfile', '', defLength, 0, 0 );
menu[60][4]  = new Item('Oth Vendor Ledger', '../servlet/hr_vendor?menuOption=defineVendor', '', defLength, 0, 0 );

menu[61] = new Array();
menu[61][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[61][1]  = new Item('Book Printing', 'NA.html', '', defLength, 0, 218 );
menu[61][2]  = new Item('Balancesheet', '../servlet/fa_report?menuOption=balanceSheet', '', defLength, 0, 0 );
menu[61][3]  = new Item('Trail Balance', '../servlet/fa_vc_txn_report?menuOption=tbReport', '', defLength, 0, 0 );
menu[61][4]  = new Item('Account Book', '../servlet/fa_vc_txn_report?menuOption=voucherReport', '', defLength, 0, 0 );
menu[61][5]  = new Item('Ledger Detail', '../servlet/fa_vc_txn_report?menuOption=glReport', '', defLength, 0, 0 );
menu[61][6]  = new Item('Profit and Loss', '../servlet/fa_vc_txn_report?menuOption=plReport', '', defLength, 0, 0 );
menu[61][7]  = new Item('Balancesheet', '../servlet/fa_vc_txn_report?menuOption=bsReport', '', defLength, 0, 0 );

menu[62] = new Array();
menu[62][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[62][1]  = new Item('Ent.Exam Subject', '../servlet/ees_adm_req?menuOption=eesAdmSub', '', defLength, 0, 0 );
menu[62][2]  = new Item('Fee Head', '../servlet/ees_fee_head?menuOption=eesFeeHead', '', defLength, 0, 0 );
menu[62][3]  = new Item('Student Category', '../servlet/ees_student_ctg?menuOption=eesStudentCtg', '', defLength, 0, 0 );

menu[63] = new Array();
menu[63][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[63][1]  = new Item('Download Admission Form', '../servlet/ees_adm_req?menuOption=eesAdmReq', '', defLength, 0, 0 );
menu[63][2]  = new Item('Online Admission', '../servlet/ees_adm_req?menuOption=eesAdmReq', '', defLength, 0, 0 );
menu[63][3]  = new Item('Update Adm From', '../servlet/ees_adm_req?menuOption=eesDetailsOfOnLineForms', '', defLength, 0, 0 );

menu[64] = new Array();
menu[64][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[64][1]  = new Item('Enquiry Form', '../servlet/ees_adm_req?menuOption=eesAdmReqEnq', '', defLength, 0, 0 );
menu[64][2]  = new Item('Enquiry Processing', '../servlet/ees_adm_req?menuOption=eesAdmReqCollegeCouncelling', '', defLength, 0, 0 );
menu[64][3]  = new Item('Councelling List', '../servlet/ees_adm_list?menuOption=eesAdmReqCouncellingList', '', defLength, 0, 0 );
menu[64][4]  = new Item('Admission List', '../servlet/ees_adm_req?menuOption=eesAdmReqAdmList', '', defLength, 0, 0 );
menu[64][5]  = new Item('Admission Form', '../servlet/ees_adm_req?menuOption=eesAdmReqAdmForm', '', defLength, 0, 0 );

menu[65] = new Array();
menu[65][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[65][1]  = new Item('Prospectus Sale', '../servlet/ees_adm_req?menuOption=eesAdmReqProspectusSale', '', defLength, 0, 0 );
menu[65][2]  = new Item('Prospectus Update', '../servlet/ees_adm_req?menuOption=eesAdmReqProspectusUpdate', '', defLength, 0, 0 );
menu[65][3]  = new Item('Form Received', '../servlet/ees_adm_req?menuOption=eesAdmReqFormReceivedFromApplicant', '', defLength, 0, 0 );

menu[66] = new Array();
menu[66][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[66][1]  = new Item('Exam Schedule', '../servlet/ees_adm_req?menuOption=eesAdmReqExamSchedule', '', defLength, 0, 0 );
menu[66][2]  = new Item('Send Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqSendAdmitCard', '', defLength, 0, 0 );
menu[66][3]  = new Item('Exam Marks', '../servlet/ees_adm_req?menuOption=eesAdmMark', '', defLength, 0, 0 );
menu[66][4]  = new Item('Shortlist After Test', '../servlet/ees_adm_req?menuOption=eesAdmReqStudentListAfterTest', '', defLength, 0, 0 );
menu[66][5]  = new Item('Final List of Candidates(NU)', '../servlet/ees_adm_req?menuOption=eesAdmReqSortedCanditateForAdm', '', defLength, 0, 0 );

menu[67] = new Array();
menu[67][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[67][1]  = new Item('Send Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqSendAdmitCard', '', defLength, 0, 0 );
menu[67][2]  = new Item('View Admit Card', '../servlet/ees_adm_req?menuOption=eesAdmReqViewAdmitCard', '', defLength, 0, 0 );

menu[68] = new Array();
menu[68][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[68][1]  = new Item('Shortlist Application', '../servlet/ees_adm_req?menuOption=eesAdmReqCanShortlisting', '', defLength, 0, 0 );

menu[69] = new Array();
menu[69][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[69][1]  = new Item('New Students List', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );
menu[69][2]  = new Item('Adm Fee Deposit', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );
menu[69][3]  = new Item('Adm Fee Receipt', '../servlet/ees_student_admission?menuOption=studentAdmission', '', defLength, 0, 0 );

menu[70] = new Array();
menu[70][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[70][1]  = new Item('New Student', '../servlet/ees_student?menuOption=eesStudentDirectEntryScreen', '', defLength, 0, 0 );
menu[70][2]  = new Item('Section Allotment', '../servlet/ees_student_admission?menuOption=studentSectionAllotment', '', defLength, 0, 0 );
menu[70][3]  = new Item('Section Re-assign', '../servlet/ees_student_admission?menuOption=studentSectionReAllotment', '', defLength, 0, 0 );
menu[70][4]  = new Item('Roll Num Assign', '../servlet/ees_student_admission?menuOption=studentRollNumAllotment', '', defLength, 0, 0 );
menu[70][5]  = new Item('Advance Student Search', '../servlet/ees_student?menuOption=studentSearch', '', defLength, 0, 0 );

menu[71] = new Array();
menu[71][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[71][1]  = new Item('Student List', '../servlet/ees_student?menuOption=studentReport', '', defLength, 0, 0 );
menu[71][2]  = new Item('Fee O/S Report', '../servlet/ees_fee_report?menuOption=eesStudentFeeOutstandingReport', '', defLength, 0, 0 );
menu[71][3]  = new Item('Outstanding Fee Orgwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeOrgWiseReport', '', defLength, 0, 0 );
menu[71][4]  = new Item('Outstanding Fee Classwise', '../servlet/ees_fee_report?menuOption=eesStudentFeeClassWiseReport', '', defLength, 0, 0 );
menu[71][5]  = new Item('Adm Form Query', '../servlet/ees_adm_req?menuOption=eesAdmReqReportsDetail', '', defLength, 0, 0 );
menu[71][6]  = new Item('Admission Receipt', '../servlet/ees_admission_report?menuOption=eesAdmissionReceipt', '', defLength, 0, 0 );

menu[72] = new Array();
menu[72][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[72][1]  = new Item('Fee Head', '../servlet/ees_fee_head?menuOption=eesFeeHead', '', defLength, 0, 0 );
menu[72][2]  = new Item('Class-wise Fee', '../servlet/ees_fee_head_class?menuOption=eesFeeHeadClass', '', defLength, 0, 0 );
menu[72][3]  = new Item('Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[72][4]  = new Item('Late Fee Rule', '../servlet/ees_late_fee_rule?menuOption=lateFeeRule', '', defLength, 0, 0 );
menu[72][5]  = new Item('Fee Concession', '../servlet/ees_fee_concession?menuOption=eesFeeConcession', '', defLength, 0, 0 );
menu[72][6]  = new Item('Transport Fee', '../servlet/ees_tp_fee?menuOption=eesTpFee', '', defLength, 0, 0 );

menu[73] = new Array();
menu[73][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[73][1]  = new Item('Yearly', '../servlet/ees_student_fee?menuOption=Yearly', '', defLength, 0, 0 );
menu[73][2]  = new Item('Quarterly', '../servlet/ees_student_fee?menuOption=Quarterly', '', defLength, 0, 0 );
menu[73][3]  = new Item('Misc', '../servlet/ees_student_fee?menuOption=Yearly', '', defLength, 0, 0 );

menu[74] = new Array();
menu[74][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[74][1]  = new Item('Student', '../servlet/ees_student_fee_ledger?menuOption=studentLedger', '', defLength, 0, 0 );
menu[74][2]  = new Item('Fee', '../servlet/ees_student_fee_ledger?menuOption=feeLedger', '', defLength, 0, 0 );

menu[75] = new Array();
menu[75][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[75][1]  = new Item('Planned Fee Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCyclePlanned', '', defLength, 0, 0 );
menu[75][2]  = new Item('Open Bill Cycle', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleOpen', '', defLength, 0, 0 );
menu[75][3]  = new Item('Bill Prep', '../servlet/ees_fee_cycle?menuOption=eesFeePrep', '', defLength, 0, 0 );
menu[75][4]  = new Item('Bill Q&A', '../servlet/ees_fee_cycle?menuOption=eesFeeQA', '', defLength, 0, 0 );
menu[75][5]  = new Item('Bill Print', '../servlet/ees_fee_cycle?menuOption=eesFeePrint', '', defLength, 0, 0 );
menu[75][6]  = new Item('Payment Collection', '../servlet/ees_fee_cycle?menuOption=eesFeeCollection', '', defLength, 0, 0 );
menu[75][7]  = new Item('Bill Cycle Close', '../servlet/ees_fee_cycle?menuOption=eesFeeCycleClose', '', defLength, 0, 0 );
menu[75][8]  = new Item('Coll Center', '../servlet/ees_fee_cycle?menuOption=eesFeeCC', '', defLength, 0, 0 );

menu[76] = new Array();
menu[76][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[76][1]  = new Item('View Fee Structure', '../servlet/ees_view_fee_stucture?menuOption=eesViewFeeStuctureClassNumWise', '', defLength, 0, 0 );
menu[76][2]  = new Item('View Fee Schedule', '../servlet/ees_fee_due_date?menuOption=eesFeeDueDate', '', defLength, 0, 0 );
menu[76][3]  = new Item('Student Fee Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerStudentWise', '', defLength, 0, 0 );
menu[76][4]  = new Item('Fee Head Ledger', '../servlet/ees_fee_report?menuOption=feeLedgerFeeHeadWise', '', defLength, 0, 0 );

menu[77] = new Array();
menu[77][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[77][1]  = new Item('Define Hostel', '../servlet/ees_hostel?menuOption=eesHostel', '', defLength, 0, 0 );
menu[77][2]  = new Item('Hostel Floor  ', '../servlet/ees_hostel_flw_qty?menuOption=eesHostelFlwQty', '', defLength, 0, 0 );
menu[77][3]  = new Item('Hostel Wing', '../servlet/ees_hostel_wing?menuOption=eesHostelWing', '', defLength, 0, 0 );
menu[77][4]  = new Item('Room', '../servlet/ees_hostel_room?menuOption=eesRoom', '', defLength, 0, 0 );
menu[77][5]  = new Item('Bed Listing', '../servlet/ees_hostel_bed?menuOption=eesRoomBedListing', '', defLength, 0, 0 );
menu[77][6]  = new Item('Room Inventory', '../servlet/ees_hostel_room_inv?menuOption=eesHostelRoomInvItem', '', defLength, 0, 0 );
menu[77][7]  = new Item('Room Items Listing', '../servlet/ees_hostel_room_item?menuOption=eesHostelRoomItem', '', defLength, 0, 0 );
menu[77][8]  = new Item('Mess', '../servlet/ees_mess?menuOption=eesMess', '', defLength, 0, 0 );
menu[77][9]  = new Item('Reports', '../servlet/ees_hostel?menuOption=eesHostel', '', defLength, 0, 0 );

menu[78] = new Array();
menu[78][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[79] = new Array();
menu[79][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[80] = new Array();
menu[80][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[81] = new Array();
menu[81][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[82] = new Array();
menu[82][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[83] = new Array();
menu[83][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[83][1]  = new Item('In', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegIn', '', defLength, 0, 0 );
menu[83][2]  = new Item('Out', '../servlet/ees_hostel_visit_reg?menuOption=eesHostelVisitRegOut', '', defLength, 0, 0 );

menu[84] = new Array();
menu[84][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[84][1]  = new Item('Raise', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRaise', '', defLength, 0, 0 );
menu[84][2]  = new Item('Monitor', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainMonitor', '', defLength, 0, 0 );
menu[84][3]  = new Item('Resolve', '../servlet/ees_hostel_complain_reg?menuOption=eesHostelComplainRegResolve', '', defLength, 0, 0 );

menu[85] = new Array();
menu[85][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[86] = new Array();
menu[86][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[86][1]  = new Item('Hostel Room Allotment', '../servlet/ees_hostel?menuOption=eesHostelAllotmentReport', '', defLength, 0, 0 );
menu[86][2]  = new Item('Hostel Exit Entry List', '../servlet/ees_hostel?menuOption=eesHostelExitEntryReport', '', defLength, 0, 0 );

menu[87] = new Array();
menu[87][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[87][1]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 87 );
menu[87][2]  = new Item('Contract', '../servlet/ees_contract?menuOption=eesContract', '', defLength, 0, 0 );
menu[87][3]  = new Item('Vehicle', '../servlet/ees_vehicle?menuOption=eesVehicle', '', defLength, 0, 0 );

menu[88] = new Array();
menu[88][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[89] = new Array();
menu[89][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[90] = new Array();
menu[90][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[90][1]  = new Item('Student Profile', '../servlet/ees_student?menuOption=eesStudentDirectEntryScreen', '', defLength, 0, 0 );
menu[90][2]  = new Item('Company Profile', '../servlet/ees_tnp_company?menuOption=eesTnpCompany', '', defLength, 0, 0 );
menu[90][3]  = new Item('Guest Institute', '../servlet/ees_institute?menuOption=eesInstitute', '', defLength, 0, 0 );

menu[91] = new Array();
menu[91][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[92] = new Array();
menu[92][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[92][1]  = new Item('Criteria', '../servlet/ees_tnp_cic?menuOption=tnpCIC', '', defLength, 0, 0 );
menu[92][2]  = new Item('Venue', '../servlet/ees_tnp_civ?menuOption=tnpCIV', '', defLength, 0, 0 );

menu[93] = new Array();
menu[93][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[93][1]  = new Item('Student List', '../servlet/ees_tnp_ci_student?menuOption=eesStudentList', '', defLength, 0, 0 );
menu[93][2]  = new Item('Company List', '../servlet/ees_tnp_company?menuOption=eesCompanyList', '', defLength, 0, 0 );
menu[93][3]  = new Item('Other Institute', '../servlet/ees_institute?menuOption=eesInstitute', '', defLength, 0, 0 );
menu[93][4]  = new Item('Upload Student List', '../servlet/ees_tnp_ci_student?menuOption=uploadStudent', '', defLength, 0, 0 );
menu[93][5]  = new Item('Registration(od)', '../servlet/ees_tnp_ci_student?menuOption=applyForCI', '', defLength, 0, 0 );

menu[94] = new Array();
menu[94][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[95] = new Array();
menu[95][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[96] = new Array();
menu[96][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[96][1]  = new Item('Placement History', '../servlet/ees_tnp_ci_student?menuOption=eesTnpCiStudentReport', '', defLength, 0, 0 );

menu[97] = new Array();
menu[97][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[98] = new Array();
menu[98][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[99] = new Array();
menu[99][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[99][1]  = new Item('Photo', 'NA.html', '', defLength, 0, 123 );

menu[100] = new Array();
menu[100][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[100][1]  = new Item('Alumni Profile', '../servlet/ees_alumni_prof?menuOption=eesAlumniProfReport', '', defLength, 0, 0 );

menu[101] = new Array();
menu[101][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[102] = new Array();
menu[102][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[102][1]  = new Item('Lab', '../servlet/ees_lab?menuOption=eesLab', '', defLength, 0, 0 );
menu[102][2]  = new Item('Lab Eqp', '../servlet/ees_lab_eqp?menuOption=eesLabEqp', '', defLength, 0, 0 );
menu[102][3]  = new Item('Lab Session Type', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=SESSIONTYP', '', defLength, 0, 0 );
menu[102][4]  = new Item('Close Semester', '../servlet/ees_lab_its?menuOption=semClose', '', defLength, 0, 0 );
menu[102][5]  = new Item('Upgrade Student', '../servlet/ees_student?menuOption=upgradeStudent', '', defLength, 0, 0 );
menu[102][6]  = new Item('Academic Session', '../servlet/ees_academic_session?menuOption=eesAcademicSession', '', defLength, 0, 0 );
menu[102][7]  = new Item('Lab User', '../servlet/ees_lab_user?menuOption=gnUser1', '', defLength, 0, 0 );
menu[102][8]  = new Item('Lab Class', '../servlet/ees_class?menuOption=eesClass', '', defLength, 0, 0 );
menu[102][9]  = new Item('Class Section', '../servlet/gn_type_code?action=gn_type_code_check_exist_show&id_type=CLASSSEC', '', defLength, 0, 0 );
menu[102][10]  = new Item('Class Subject', '../servlet/ees_subject?menuOption=eesSubject', '', defLength, 0, 0 );
menu[102][11]  = new Item('Faculty', '../servlet/ees_lab_eqp?menuOption=eesLabEqp', '', defLength, 0, 0 );
menu[102][12]  = new Item('Lab Assistant', 'gn_type_value?menuOption=defineIdTypeValue&id_type_param=ASSISTANTID', '', defLength, 0, 0 );
menu[102][13]  = new Item('Lab Student', '../servlet/ees_student?menuOption=eesStudentDirectEntryScreen', '', defLength, 0, 0 );

menu[103] = new Array();
menu[103][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[103][1]  = new Item('Lab Schedule', 'NA.html', '', defLength, 0, 189 );
menu[103][2]  = new Item('Eqp Status', '../servlet/ees_lab_its?menuOption=eesLabEqpView1', '', defLength, 0, 0 );

menu[104] = new Array();
menu[104][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[105] = new Array();
menu[105][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[105][1]  = new Item('Consolidate Lab Report', '../servlet/ees_lab_report?menuOption=labConsolidatedReport', '', defLength, 0, 0 );
menu[105][2]  = new Item('Lab Wise Report', '../servlet/ees_lab_report?menuOption=labWiseReport', '', defLength, 0, 0 );
menu[105][3]  = new Item('Student Wise Report', '../servlet/ees_lab_report?menuOption=studentWiseReport', '', defLength, 0, 0 );
menu[105][4]  = new Item('Faculty Wise Report', '../servlet/ees_lab_report?menuOption=facultyWiseReport', '', defLength, 0, 0 );
menu[105][5]  = new Item('Staff Wise Report', '../servlet/ees_lab_report?menuOption=staffWiseReport', '', defLength, 0, 0 );
menu[105][6]  = new Item('Lab Wise ETS Report', '../servlet/ees_lab_report?menuOption=labWiseEtsReport', '', defLength, 0, 0 );
menu[105][7]  = new Item('Labwise Eqp List Report', '../servlet/ees_lab_report?menuOption=eqpList', '', defLength, 0, 0 );
menu[105][8]  = new Item('Subject Wise Report', '../servlet/ees_lab_report?menuOption=subjectWiseReport', '', defLength, 0, 0 );

menu[106] = new Array();
menu[106][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[106][1]  = new Item('Consolidate Lab Report', '../servlet/ees_lab_report?menuOption=labConsolidatedReportHist', '', defLength, 0, 0 );
menu[106][2]  = new Item('Lab Wise Report', '../servlet/ees_lab_report?menuOption=labWiseReportHist', '', defLength, 0, 0 );
menu[106][3]  = new Item('Student Wise Report', '../servlet/ees_lab_report?menuOption=studentWiseReportHist', '', defLength, 0, 0 );
menu[106][4]  = new Item('Faculty Wise Report', '../servlet/ees_lab_report?menuOption=facltyWiseReportHist', '', defLength, 0, 0 );
menu[106][5]  = new Item('Staff Wise Report', '../servlet/ees_lab_report?menuOption=staffWiseReportHist', '', defLength, 0, 0 );

menu[107] = new Array();
menu[107][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[108] = new Array();
menu[108][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[109] = new Array();
menu[109][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[110] = new Array();
menu[110][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[111] = new Array();
menu[111][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[112] = new Array();
menu[112][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[113] = new Array();
menu[113][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[114] = new Array();
menu[114][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[115] = new Array();
menu[115][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[116] = new Array();
menu[116][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[117] = new Array();
menu[117][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[118] = new Array();
menu[118][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[119] = new Array();
menu[119][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[120] = new Array();
menu[120][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[121] = new Array();
menu[121][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[122] = new Array();
menu[122][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[123] = new Array();
menu[123][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[123][1]  = new Item('Infrastructure', 'NA.html', '', defLength, 0, 0 );
menu[123][2]  = new Item('College Staff', 'NA.html', '', defLength, 0, 0 );
menu[123][3]  = new Item('Alumni Batch', 'NA.html', '', defLength, 0, 0 );
menu[123][4]  = new Item('Convocation', 'NA.html', '', defLength, 0, 0 );

menu[124] = new Array();
menu[124][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[125] = new Array();
menu[125][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[126] = new Array();
menu[126][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[127] = new Array();
menu[127][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[128] = new Array();
menu[128][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[128][1]  = new Item('ID Type', '../servlet/gn_type_value?menuOption=defineIdType', '', defLength, 0, 0 );
menu[128][2]  = new Item('Bulk Cache Generation', '../servlet/gn_type_value?menuOption=bulkCacheGen', '', defLength, 0, 0 );
menu[128][3]  = new Item('Bulk Cache Generation', '../servlet/gn_type_value?menuOption=bulkCacheGen', '', defLength, 0, 0 );

menu[129] = new Array();
menu[129][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[129][1]  = new Item('Project Mgt', '../servlet/gn_appln_menu?menuOption=projectManagement', '', defLength, 0, 0 );
menu[129][2]  = new Item('User Role', '../servlet/gn_user_role?menuOption=gnUserRole', '', defLength, 0, 0 );
menu[129][3]  = new Item('Manage Menu Options', '../servlet/gn_appln_menu?menuOption=gnApplnMenu', '', defLength, 0, 0 );
menu[129][4]  = new Item('Rolewise Permission', '../servlet/gn_appln_menu?menuOption=rolewiseMenuPermission', '', defLength, 0, 0 );
menu[129][5]  = new Item('Menu Privilage', '../servlet/gn_appln_menu?menuOption=menuPermission', '', defLength, 0, 0 );
menu[129][6]  = new Item('Bulk Gen Menu', '../servlet/gn_appln_menu?menuOption=bulkMenuGen', '', defLength, 0, 0 );

menu[130] = new Array();
menu[130][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[130][1]  = new Item('Raise Defect', '../servlet/qa_defect?menuOption=qaDefect', '', defLength, 0, 0 );
menu[130][2]  = new Item('Defect Tracking', '../servlet/qa_defect?menuOption=qaDefect', '', defLength, 0, 0 );
menu[130][3]  = new Item('Test Case', '../servlet/qa_testcase?menuOption=qaTestcase', '', defLength, 0, 0 );
menu[130][4]  = new Item('Test Procedure', '../servlet/qa_testcase_step?menuOption=qaTestcaseStep', '', defLength, 0, 0 );

menu[131] = new Array();
menu[131][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[131][1]  = new Item('Continent', '../servlet/gn_continent?menuOption=gnContinent', '', defLength, 0, 0 );
menu[131][2]  = new Item('Country', '../servlet/gn_country?menuOption=gnCountry', '', defLength, 0, 0 );
menu[131][3]  = new Item('State', '../servlet/gn_state?menuOption=gnState', '', defLength, 0, 0 );
menu[131][4]  = new Item('City', '../servlet/gn_city?menuOption=gnCity', '', defLength, 0, 0 );
menu[131][5]  = new Item('Districtt', '../servlet/gn_city?menuOption=gnCity', '', defLength, 0, 0 );

menu[132] = new Array();
menu[132][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[132][1]  = new Item('JDBC Config', '../servlet/sst_config?menuOption=driverConfig', '', defLength, 0, 0 );
menu[132][2]  = new Item('Param Config', '../servlet/sst_config?menuOption=esmParamConfig', '', defLength, 0, 0 );
menu[132][3]  = new Item('Param Config Init', '../servlet/sst_config?menuOption=esmParamConfigInit', '', defLength, 0, 0 );

menu[133] = new Array();
menu[133][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[134] = new Array();
menu[134][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[135] = new Array();
menu[135][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[136] = new Array();
menu[136][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[137] = new Array();
menu[137][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[138] = new Array();
menu[138][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[139] = new Array();
menu[139][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[140] = new Array();
menu[140][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[141] = new Array();
menu[141][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[142] = new Array();
menu[142][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[143] = new Array();
menu[143][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[144] = new Array();
menu[144][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[145] = new Array();
menu[145][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[146] = new Array();
menu[146][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[147] = new Array();
menu[147][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[148] = new Array();
menu[148][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[148][1]  = new Item('Define Route ', '../servlet/ees_route?menuOption=eesRoute', '', defLength, 0, 0 );
menu[148][2]  = new Item('Route Stoppage', '../servlet/ees_route_stoppage?menuOption=eesRouteStoppage', '', defLength, 0, 0 );
menu[148][3]  = new Item('Route For Vehicle', '../servlet/ees_vehicle_route?menuOption=eesVehicleRoute', '', defLength, 0, 0 );

menu[149] = new Array();
menu[149][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[150] = new Array();
menu[150][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[151] = new Array();
menu[151][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[152] = new Array();
menu[152][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[153] = new Array();
menu[153][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[154] = new Array();
menu[154][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[155] = new Array();
menu[155][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[156] = new Array();
menu[156][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[157] = new Array();
menu[157][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[158] = new Array();
menu[158][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[159] = new Array();
menu[159][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[160] = new Array();
menu[160][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[161] = new Array();
menu[161][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[162] = new Array();
menu[162][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[163] = new Array();
menu[163][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[164] = new Array();
menu[164][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[165] = new Array();
menu[165][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[166] = new Array();
menu[166][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[167] = new Array();
menu[167][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[168] = new Array();
menu[168][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[169] = new Array();
menu[169][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[170] = new Array();
menu[170][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[171] = new Array();
menu[171][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[172] = new Array();
menu[172][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[173] = new Array();
menu[173][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[174] = new Array();
menu[174][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[175] = new Array();
menu[175][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[176] = new Array();
menu[176][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[177] = new Array();
menu[177][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[178] = new Array();
menu[178][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[179] = new Array();
menu[179][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[180] = new Array();
menu[180][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[181] = new Array();
menu[181][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[182] = new Array();
menu[182][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[183] = new Array();
menu[183][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[184] = new Array();
menu[184][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[185] = new Array();
menu[185][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[186] = new Array();
menu[186][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[187] = new Array();
menu[187][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[188] = new Array();
menu[188][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[189] = new Array();
menu[189][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[189][1]  = new Item('For Class', '../servlet/ees_lab_its?menuOption=eesLabSchDay', '', defLength, 0, 0 );
menu[189][2]  = new Item('For Exam', '../servlet/ees_lab_its?menuOption=eesLabSchDayExam', '', defLength, 0, 0 );
menu[189][3]  = new Item('Copy Schedule', '../servlet/ees_lab_its?menuOption=eesLabSchWeek', '', defLength, 0, 0 );

menu[190] = new Array();
menu[190][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[191] = new Array();
menu[191][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[192] = new Array();
menu[192][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[193] = new Array();
menu[193][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[194] = new Array();
menu[194][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[195] = new Array();
menu[195][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[196] = new Array();
menu[196][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[197] = new Array();
menu[197][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[198] = new Array();
menu[198][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[199] = new Array();
menu[199][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[200] = new Array();
menu[200][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[201] = new Array();
menu[201][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[202] = new Array();
menu[202][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[203] = new Array();
menu[203][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[204] = new Array();
menu[204][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[205] = new Array();
menu[205][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[206] = new Array();
menu[206][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[207] = new Array();
menu[207][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[208] = new Array();
menu[208][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[209] = new Array();
menu[209][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[210] = new Array();
menu[210][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[211] = new Array();
menu[211][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[212] = new Array();
menu[212][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[213] = new Array();
menu[213][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[214] = new Array();
menu[214][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[215] = new Array();
menu[215][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[216] = new Array();
menu[216][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[217] = new Array();
menu[217][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[218] = new Array();
menu[218][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[218][1]  = new Item('Bank', '../servlet/fa_report?menuOption=ledgerDayBook', '', defLength, 0, 0 );
menu[218][2]  = new Item('Cash', '../servlet/fa_report?menuOption=ledgerDayBook', '', defLength, 0, 0 );
menu[218][3]  = new Item('Sale', '../servlet/fa_report?menuOption=ledgerDayBook', '', defLength, 0, 0 );
menu[218][4]  = new Item('Purchase', '../servlet/fa_report?menuOption=ledgerDayBook', '', defLength, 0, 0 );

menu[219] = new Array();
menu[219][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[220] = new Array();
menu[220][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[221] = new Array();
menu[221][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[222] = new Array();
menu[222][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[223] = new Array();
menu[223][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[224] = new Array();
menu[224][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[225] = new Array();
menu[225][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[226] = new Array();
menu[226][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[227] = new Array();
menu[227][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[228] = new Array();
menu[228][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[229] = new Array();
menu[229][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[230] = new Array();
menu[230][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[231] = new Array();
menu[231][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[232] = new Array();
menu[232][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[233] = new Array();
menu[233][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[234] = new Array();
menu[234][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[235] = new Array();
menu[235][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[236] = new Array();
menu[236][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[237] = new Array();
menu[237][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[238] = new Array();
menu[238][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[239] = new Array();
menu[239][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[240] = new Array();
menu[240][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[241] = new Array();
menu[241][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[242] = new Array();
menu[242][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[243] = new Array();
menu[243][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[244] = new Array();
menu[244][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[245] = new Array();
menu[245][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[246] = new Array();
menu[246][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[247] = new Array();
menu[247][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[248] = new Array();
menu[248][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[249] = new Array();
menu[249][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[250] = new Array();
menu[250][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[251] = new Array();
menu[251][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[252] = new Array();
menu[252][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[253] = new Array();
menu[253][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[254] = new Array();
menu[254][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[255] = new Array();
menu[255][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[256] = new Array();
menu[256][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[257] = new Array();
menu[257][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[258] = new Array();
menu[258][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[259] = new Array();
menu[259][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[260] = new Array();
menu[260][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[261] = new Array();
menu[261][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[262] = new Array();
menu[262][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[263] = new Array();
menu[263][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[264] = new Array();
menu[264][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[265] = new Array();
menu[265][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[266] = new Array();
menu[266][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[267] = new Array();
menu[267][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[268] = new Array();
menu[268][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[269] = new Array();
menu[269][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[270] = new Array();
menu[270][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[271] = new Array();
menu[271][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[272] = new Array();
menu[272][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[273] = new Array();
menu[273][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[274] = new Array();
menu[274][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[275] = new Array();
menu[275][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[276] = new Array();
menu[276][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[277] = new Array();
menu[277][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[278] = new Array();
menu[278][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[279] = new Array();
menu[279][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[280] = new Array();
menu[280][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[281] = new Array();
menu[281][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[282] = new Array();
menu[282][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[283] = new Array();
menu[283][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[284] = new Array();
menu[284][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[285] = new Array();
menu[285][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[286] = new Array();
menu[286][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[287] = new Array();
menu[287][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[288] = new Array();
menu[288][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[289] = new Array();
menu[289][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[290] = new Array();
menu[290][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[291] = new Array();
menu[291][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[292] = new Array();
menu[292][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[293] = new Array();
menu[293][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[294] = new Array();
menu[294][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[295] = new Array();
menu[295][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[296] = new Array();
menu[296][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[297] = new Array();
menu[297][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[298] = new Array();
menu[298][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[299] = new Array();
menu[299][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[299][1]  = new Item('Define Exam Type(obso)', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=TERMTYPE', '', defLength, 0, 0 );
menu[299][2]  = new Item('Define Term Type(obso)', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=TERM', '', defLength, 0, 0 );
menu[299][3]  = new Item('Define Room Type(obso)', '../servlet/gn_type_value?menuOption=defineIdTypeValue&id_type_param=ROOMTYPE', '', defLength, 0, 0 );
menu[299][4]  = new Item('Define Exam Session', '../servlet/ees_period?menuOption=eesExamSession', '', defLength, 0, 0 );

menu[300] = new Array();
menu[300][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[301] = new Array();
menu[301][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[302] = new Array();
menu[302][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[303] = new Array();
menu[303][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[304] = new Array();
menu[304][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[305] = new Array();
menu[305][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[306] = new Array();
menu[306][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[307] = new Array();
menu[307][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[308] = new Array();
menu[308][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[309] = new Array();
menu[309][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[310] = new Array();
menu[310][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[311] = new Array();
menu[311][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[312] = new Array();
menu[312][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[313] = new Array();
menu[313][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[314] = new Array();
menu[314][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[315] = new Array();
menu[315][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[316] = new Array();
menu[316][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[317] = new Array();
menu[317][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[318] = new Array();
menu[318][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[319] = new Array();
menu[319][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[320] = new Array();
menu[320][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[321] = new Array();
menu[321][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[321][1]  = new Item('Timetable Rule', '../servlet/ees_timetable_rule?menuOption=eesTimetableRule', '', defLength, 0, 0 );
menu[321][2]  = new Item('Initiate Timetable', '../servlet/ees_timetable?menuOption=initiateTimetable', '', defLength, 0, 0 );
menu[321][3]  = new Item('Timetable Classwise', '../servlet/ees_timetable?menuOption=eesTimetableHdr', '', defLength, 0, 0 );
menu[321][4]  = new Item('Timetable Teacherwise', '../servlet/ees_timetable?menuOption=eesTimetableTeacherwise', '', defLength, 0, 0 );
menu[321][5]  = new Item('Approve Timetable', '../servlet/ees_timetable?menuOption=approveTT', '', defLength, 0, 0 );
menu[321][6]  = new Item('CopyTimetable', '../servlet/ees_timetable?menuOption=eesTimetableCpy', '', defLength, 0, 0 );
menu[321][7]  = new Item('View Timetable', 'NA.html', '', defLength, 0, 330 );

menu[322] = new Array();
menu[322][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[322][1]  = new Item('Lect Delv Plan', '../servlet/ees_timetable?menuOption=eesLectureDeliveryPlan', '', defLength, 0, 0 );
menu[322][2]  = new Item('Attendence Entry', '../servlet/ees_adr?menuOption=eesAdr', '', defLength, 0, 0 );
menu[322][3]  = new Item('Copy Attendance', '../servlet/ees_adr?menuOption=copyAttnPeriodWise', '', defLength, 0, 0 );
menu[322][4]  = new Item('ADR Progress', '../servlet/ees_adr?menuOption=eesAdrProgress', '', defLength, 0, 0 );
menu[322][5]  = new Item('Add or Alt Faculty', '../servlet/ees_timetable?menuOption=eesTimetable', '', defLength, 0, 0 );
menu[322][6]  = new Item('Alt Faculty Req (OD)', 'NA.html', '', defLength, 0, 338 );
menu[322][7]  = new Item('ADR Reports', 'NA.html', '', defLength, 0, 339 );

menu[323] = new Array();
menu[323][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[323][1]  = new Item('ClassWise Report', '../servlet/ees_timetable_report?menuOption=monthlyTimetableReportClassWise', '', defLength, 0, 0 );
menu[323][2]  = new Item('FacultyWise Report', '../servlet/ees_timetable_report?menuOption=monthlyTimetableReportFacultyWise', '', defLength, 0, 0 );
menu[323][3]  = new Item('Timetable ClassWise', '../servlet/ees_timetable_report?menuOption=eesTimetableReportClassWise', '', defLength, 0, 0 );

menu[324] = new Array();
menu[324][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[325] = new Array();
menu[325][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[326] = new Array();
menu[326][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[327] = new Array();
menu[327][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[328] = new Array();
menu[328][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[329] = new Array();
menu[329][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[330] = new Array();
menu[330][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[330][1]  = new Item('For Faculty', '../servlet/ees_timetable?menuOption=viewTimetableFaculty', '', defLength, 0, 0 );
menu[330][2]  = new Item('Admin', '../servlet/ees_timetable?menuOption=viewTimetableAdm', '', defLength, 0, 0 );

menu[331] = new Array();
menu[331][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[332] = new Array();
menu[332][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[333] = new Array();
menu[333][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[334] = new Array();
menu[334][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[335] = new Array();
menu[335][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[336] = new Array();
menu[336][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[337] = new Array();
menu[337][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[338] = new Array();
menu[338][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[338][1]  = new Item('Raise Request', '../servlet/ees_tt_af_req?menuOption=raiseRequest', '', defLength, 0, 0 );
menu[338][2]  = new Item('View Raise Req', '../servlet/ees_tt_af_req?menuOption=viewRaiseRequest', '', defLength, 0, 0 );
menu[338][3]  = new Item('Moniter Alt Fac Req', '../servlet/ees_tt_af_req?menuOption=monitorRequest', '', defLength, 0, 0 );

menu[339] = new Array();
menu[339][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[339][1]  = new Item('Monthly Attendance ', '../servlet/ees_adr?menuOption=attnReportMonthly', '', defLength, 0, 0 );
menu[339][2]  = new Item('Period Wise Attendance', '../servlet/ees_adr?menuOption=attnReportPeriodWise', '', defLength, 0, 0 );

menu[340] = new Array();
menu[340][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[341] = new Array();
menu[341][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[342] = new Array();
menu[342][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[343] = new Array();
menu[343][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[344] = new Array();
menu[344][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[345] = new Array();
menu[345][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[346] = new Array();
menu[346][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[347] = new Array();
menu[347][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[348] = new Array();
menu[348][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[349] = new Array();
menu[349][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[350] = new Array();
menu[350][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[351] = new Array();
menu[351][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[352] = new Array();
menu[352][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[353] = new Array();
menu[353][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[354] = new Array();
menu[354][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[355] = new Array();
menu[355][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[356] = new Array();
menu[356][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[357] = new Array();
menu[357][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[358] = new Array();
menu[358][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[359] = new Array();
menu[359][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[360] = new Array();
menu[360][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[361] = new Array();
menu[361][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[362] = new Array();
menu[362][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[363] = new Array();
menu[363][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[364] = new Array();
menu[364][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[365] = new Array();
menu[365][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[366] = new Array();
menu[366][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[367] = new Array();
menu[367][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[368] = new Array();
menu[368][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[369] = new Array();
menu[369][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[370] = new Array();
menu[370][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[371] = new Array();
menu[371][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[372] = new Array();
menu[372][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[373] = new Array();
menu[373][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[374] = new Array();
menu[374][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[375] = new Array();
menu[375][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[376] = new Array();
menu[376][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[377] = new Array();
menu[377][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[378] = new Array();
menu[378][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[379] = new Array();
menu[379][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[380] = new Array();
menu[380][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[381] = new Array();
menu[381][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[382] = new Array();
menu[382][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[383] = new Array();
menu[383][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[384] = new Array();
menu[384][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[385] = new Array();
menu[385][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[385][1]  = new Item('Employee Personal Profile', '../servlet/hr_employee_report?menuOption=hrEmployeeProfileReport', '', defLength, 0, 0 );
menu[385][2]  = new Item('Employee Detail Listing', '../servlet/hr_employee_report?menuOption=hrEmployeeDetailReport', '', defLength, 0, 0 );
menu[385][3]  = new Item('Building Wise Room List', '../servlet/hr_building_room?menuOption=buildingWiseRoomReport', '', defLength, 0, 0 );
menu[385][4]  = new Item('Holiday Calendar', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[385][5]  = new Item('Epmloyee Count', '../servlet/hr_department_report?menuOption=hrEmployeeStatisticsReport', '', defLength, 0, 0 );
menu[385][6]  = new Item('Emp Count in Group', '../servlet/hr_department_report?menuOption=hrEmployeeStatisticsGrpAdmReport', '', defLength, 0, 0 );
menu[385][7]  = new Item('Emp Statistic (grpadm)', '../servlet/hr_department_report?menuOption=hrEmployeeGrpAdmReport', '', defLength, 0, 0 );
menu[385][8]  = new Item('Emp List - Dept', '../servlet/hr_employee_report?menuOption=hrEmployeeDepartmentReport', '', defLength, 0, 0 );
menu[385][9]  = new Item('Emp List - Position', '../servlet/hr_employee_report?menuOption=hrEmployeePositionwise', '', defLength, 0, 0 );
menu[385][10]  = new Item('Emp List - Join Date', '../servlet/hr_employee_report?menuOption=hrEmployeeJoiningDatewise', '', defLength, 0, 0 );
menu[385][11]  = new Item('Emp List - Appraisal', '../servlet/hr_employee_report?menuOption=hrEmployeeAppraisalwise', '', defLength, 0, 0 );
menu[385][12]  = new Item('Emp List - Project', '../servlet/hr_employee_report?menuOption=hrEmployeeProjectwise', '', defLength, 0, 0 );
menu[385][13]  = new Item('Emp List - Salary Range', '../servlet/hr_employee_report?menuOption=hrEmployeeSalaryRangewise', '', defLength, 0, 0 );

menu[386] = new Array();
menu[386][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[386][1]  = new Item('Print Cust Agreement', '../servlet/hr_ccb_report?menuOption=hrCustAgrForm', '', defLength, 0, 0 );

menu[387] = new Array();
menu[387][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[388] = new Array();
menu[388][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[388][1]  = new Item('Attendance Sheet Report', '../servlet/hr_card_time?menuOption=hrAttendanceSheetReport', '', defLength, 0, 0 );
menu[388][2]  = new Item('Attendance Sum Report', '../servlet/hr_card_time?menuOption=hrEmpAttendanceSumReport', '', defLength, 0, 0 );
menu[388][3]  = new Item('Training Payment', '../servlet/hr_training_report?menuOption=hrTrainingPayment', '', defLength, 0, 0 );
menu[388][4]  = new Item('Offer Accepted Candidate', '../servlet/hr_training_report?menuOption=hrCandidateListTwo', '', defLength, 0, 0 );
menu[388][5]  = new Item('Training Schedule', '../servlet/hr_training_report?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[388][6]  = new Item('Trainee List Report', '../servlet/hr_training_report?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[388][7]  = new Item('Monthly Attn Sumry', '../servlet/hr_card_time?menuOption=hrEmpAttendanceSum', '', defLength, 0, 0 );

menu[389] = new Array();
menu[389][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[389][1]  = new Item('Salary Ledger (M)', '../servlet/hr_payroll_report?menuOption=hrEmpMonthlySalary', '', defLength, 0, 0 );
menu[389][2]  = new Item('Customer Invoice Bill', '../servlet/hr_payroll_report?menuOption=customerInvoiceBill', '', defLength, 0, 0 );
menu[389][3]  = new Item('ESI Form 5 Reg', '../servlet/hr_payroll_report?menuOption=esiForm5Reg', '', defLength, 0, 0 );
menu[389][4]  = new Item('ESI Form 5(State Wise)', '../servlet/hr_payroll_report?menuOption=esiForm5StateWise', '', defLength, 0, 0 );
menu[389][5]  = new Item('PF Form 5 M (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm5Monthly', '', defLength, 0, 0 );
menu[389][6]  = new Item('PF Form 5 Y (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm5Yearly', '', defLength, 0, 0 );
menu[389][7]  = new Item('PF Form 10 Reg', '../servlet/hr_payroll_report?menuOption=pfForm10Reg', '', defLength, 0, 0 );
menu[389][8]  = new Item('PF Form 10 CustomerWise', '../servlet/hr_payroll_report?menuOption=pfForm10CustomerWise', '', defLength, 0, 0 );
menu[389][9]  = new Item('EPF Form NSS Reg', '../servlet/hr_payroll_report?menuOption=epfFormNssReg', '', defLength, 0, 0 );
menu[389][10]  = new Item('EPF Form NSS Customer Wise', '../servlet/hr_payroll_report?menuOption=epfFormNssCustomerWise', '', defLength, 0, 0 );
menu[389][11]  = new Item('ESI Form 3 Reg', '../servlet/hr_payroll_report?menuOption=esiForm3Reg', '', defLength, 0, 0 );
menu[389][12]  = new Item('ESI Form 3 CustomerWise', '../servlet/hr_payroll_report?menuOption=esiForm3CustomerWise', '', defLength, 0, 0 );
menu[389][13]  = new Item('ESI Challan Monthwise', '../servlet/hr_payroll_report?menuOption=esiChallanMonthwise', '', defLength, 0, 0 );
menu[389][14]  = new Item('Bulk Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrTaxSheetReport', '', defLength, 0, 0 );
menu[389][15]  = new Item('Employee Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrEmpTaxSheetReport', '', defLength, 0, 0 );
menu[389][16]  = new Item('Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=yearlySalaryMisReport', '', defLength, 0, 0 );
menu[389][17]  = new Item('Employee Wise Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpWiseYearlySalaryMisReport', '', defLength, 0, 0 );
menu[389][18]  = new Item('Employee Customer Wise Yearly Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpCustWiseYearlySalaryMisReport', '', defLength, 0, 0 );
menu[389][19]  = new Item('Employee Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrEmpSalaryMisReport', '', defLength, 0, 0 );
menu[389][20]  = new Item('Customer Employee Salary Mis Report', '../servlet/hr_payroll_report?menuOption=hrCustEmpSalaryMisReport', '', defLength, 0, 0 );
menu[389][21]  = new Item('Customer Employee Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrCustEmpTaxSheetReport', '', defLength, 0, 0 );
menu[389][22]  = new Item('Customer Employee Bulk Tax Sheet Report', '../servlet/hr_tax_report?menuOption=hrCustEmpBulkTaxSheetReport', '', defLength, 0, 0 );
menu[389][23]  = new Item('Employee Agreement Salary Report', '../servlet/hr_payroll_report?menuOption=hrEmployeeAgreementSalary', '', defLength, 0, 0 );
menu[389][24]  = new Item('Customer Employee Agreement Salary Report', '../servlet/hr_payroll_report?menuOption=hrCustEmployeeAgreementSalary', '', defLength, 0, 0 );
menu[389][25]  = new Item('Salary Ledger (M) (Custwise)', '../servlet/hr_payroll_report?menuOption=hrEmpMonthlySalaryCustwise', '', defLength, 0, 0 );
menu[389][26]  = new Item('Salary Slip (Reg)', '../servlet/hr_payroll_report?menuOption=hrEmpSalary', '', defLength, 0, 0 );
menu[389][27]  = new Item('Salary Slip (Custwise)', '../servlet/hr_payroll_report?menuOption=hrEmpSalaryCustwise', '', defLength, 0, 0 );
menu[389][28]  = new Item('ESI Form 1', '../servlet/hr_payroll_report?menuOption=esiForm1', '', defLength, 0, 0 );
menu[389][29]  = new Item('ESI Form 1 (Custwise)', '../servlet/hr_payroll_report?menuOption=esiForm1Custwise', '', defLength, 0, 0 );
menu[389][30]  = new Item('ESI Challan', '../servlet/hr_payroll_report?menuOption=esiChallan', '', defLength, 0, 0 );
menu[389][31]  = new Item('ESI Challan (Custwise)', '../servlet/hr_payroll_report?menuOption=esiChallanCustwise', '', defLength, 0, 0 );
menu[389][32]  = new Item('ESI Statement (Monthly)', '../servlet/hr_payroll_report?menuOption=esiForm999Monthly', '', defLength, 0, 0 );
menu[389][33]  = new Item('ESI Statement (Yearly)', '../servlet/hr_payroll_report?menuOption=esiForm999Yearly', '', defLength, 0, 0 );
menu[389][34]  = new Item('PF Ledger', '../servlet/hr_payroll_report?menuOption=pfLedger', '', defLength, 0, 0 );
menu[389][35]  = new Item('PF Form 2', '../servlet/hr_payroll_report?menuOption=pfForm2', '', defLength, 0, 0 );
menu[389][36]  = new Item('PF Form 3A(Rev)', '../servlet/hr_payroll_report?menuOption=pfForm3A', '', defLength, 0, 0 );
menu[389][37]  = new Item('PF Form 3A(Rev)-Custwise', '../servlet/hr_payroll_report?menuOption=pfForm3AClientwise', '', defLength, 0, 0 );
menu[389][38]  = new Item('PF Form 5 (Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm5ClientwiseMonthly', '', defLength, 0, 0 );
menu[389][39]  = new Item('PF Form 5 (Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm5ClientwiseYearly', '', defLength, 0, 0 );
menu[389][40]  = new Item('PF Form 6A M (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm6AMonthly', '', defLength, 0, 0 );
menu[389][41]  = new Item('PF Form 6A (Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm6AClientwiseMonthly', '', defLength, 0, 0 );
menu[389][42]  = new Item('PF Form 6A Y (Reg)', '../servlet/hr_payroll_report?menuOption=pfForm6AYearly', '', defLength, 0, 0 );
menu[389][43]  = new Item('PF Form 6A (Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm6AClientwiseYearly', '', defLength, 0, 0 );
menu[389][44]  = new Item('PF Form 9 rev', '../servlet/hr_payroll_report?menuOption=pfForm9Rev', '', defLength, 0, 0 );
menu[389][45]  = new Item('PF Form 9 rev (Custwise)', '../servlet/hr_payroll_report?menuOption=pfForm9RevCustwise', '', defLength, 0, 0 );
menu[389][46]  = new Item('PF Form 10A(Rev)', '../servlet/hr_payroll_report?menuOption=pfForm10A', '', defLength, 0, 0 );
menu[389][47]  = new Item('PF Form 10A (Custwise Monthly)', '../servlet/hr_payroll_report?menuOption=pfForm10AClientwiseMonthly', '', defLength, 0, 0 );
menu[389][48]  = new Item('PF Form 10A (Custwise Yearly)', '../servlet/hr_payroll_report?menuOption=pfForm10AClientwiseYearly', '', defLength, 0, 0 );
menu[389][49]  = new Item('PF Form 19', '../servlet/hr_payroll_report?menuOption=pfForm19', '', defLength, 0, 0 );
menu[389][50]  = new Item('PF Form 19 (Custwise)', '../servlet/hr_payroll_report?menuOption=pfForm19Custwise', '', defLength, 0, 0 );
menu[389][51]  = new Item('PF Challan', '../servlet/hr_payroll_report?menuOption=pfChallan', '', defLength, 0, 0 );
menu[389][52]  = new Item('PF Challan (Custwise)', '../servlet/hr_payroll_report?menuOption=pfChallanCustwise', '', defLength, 0, 0 );

menu[390] = new Array();
menu[390][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[390][1]  = new Item('Define Library', '../servlet/ees_library?menuOption=eesLibrary', '', defLength, 0, 0 );
menu[390][2]  = new Item('Book Inventory', '../servlet/ees_lib_book?menuOption=eesLibBook', '', defLength, 0, 0 );
menu[390][3]  = new Item('Issue and Penalty Rule', '../servlet/ees_lib_issue_rule?menuOption=eesLibIssueRule', '', defLength, 0, 0 );
menu[390][4]  = new Item('Book Status', '../servlet/ees_lib_book?menuOption=changeBookStatus', '', defLength, 0, 0 );

menu[391] = new Array();
menu[391][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[392] = new Array();
menu[392][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[393] = new Array();
menu[393][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[393][1]  = new Item('Issue History(Book)', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[393][2]  = new Item('Reading Pattern', '../servlet/ees_lib_book_issue?menuOption=eesBookTypeWiseReport', '', defLength, 0, 0 );
menu[393][3]  = new Item('Book Issue History', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[393][4]  = new Item('Student Issue History', '../servlet/ees_lib_book_issue?menuOption=eesLibBookIssueReport', '', defLength, 0, 0 );
menu[393][5]  = new Item('Penalty Report', 'NA.html', '', defLength, 0, 0 );
menu[393][6]  = new Item('Reading Pattern', '../servlet/ees_lib_book_issue?menuOption=eesBookTypeWiseReport', '', defLength, 0, 0 );

menu[394] = new Array();
menu[394][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[395] = new Array();
menu[395][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[396] = new Array();
menu[396][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[397] = new Array();
menu[397][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[398] = new Array();
menu[398][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[399] = new Array();
menu[399][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[400] = new Array();
menu[400][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[401] = new Array();
menu[401][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[402] = new Array();
menu[402][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[403] = new Array();
menu[403][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[404] = new Array();
menu[404][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[404][1]  = new Item('Department', '../servlet/hr_department?menuOption=hrDepartment', '', defLength, 0, 0 );
menu[404][2]  = new Item('Cost Center', '../servlet/hr_cost_center?menuOption=hrCostCenter', '', defLength, 0, 0 );
menu[404][3]  = new Item('Logical Groups', '../servlet/hr_logical_grp?menuOption=hrLogicalGrp', '', defLength, 0, 0 );
menu[404][4]  = new Item('Budget Code', '../servlet/hr_budget_code?menuOption=hrBudgetCode', '', defLength, 0, 0 );
menu[404][5]  = new Item('Employee Position', '../servlet/hr_position?menuOption=hrPosition', '', defLength, 0, 0 );
menu[404][6]  = new Item('Employee Level', '../servlet/hr_position_level?menuOption=hrPositionLevel', '', defLength, 0, 0 );
menu[404][7]  = new Item('Working Shift', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[404][8]  = new Item('Salary Cycle', 'NA.html', '', defLength, 0, 429 );
menu[404][9]  = new Item('Tax Rule', '../servlet/hr_tax_rule?menuOption=hrTaxRule', '', defLength, 0, 0 );
menu[404][10]  = new Item('Holiday', '../servlet/hr_holiday?menuOption=hrHoliday', '', defLength, 0, 0 );
menu[404][11]  = new Item('Financial Year', '../servlet/hr_finance_year_def?menuOption=hrFinanceYearDef', '', defLength, 0, 0 );
menu[404][12]  = new Item('Tax Rebate Reason', '../servlet/hr_tax_rebate_reason?menuOption=hrTaxRebateReason', '', defLength, 0, 0 );
menu[404][13]  = new Item('Absent Code', '../servlet/hr_absent_type?menuOption=hrAbsentType', '', defLength, 0, 0 );
menu[404][14]  = new Item('Salary Head', '../servlet/hr_salary_head?menuOption=hrSalaryHead', '', defLength, 0, 0 );
menu[404][15]  = new Item('Banker', '../servlet/hr_banker?menuOption=hrBanker', '', defLength, 0, 0 );
menu[404][16]  = new Item('Vendor', '../servlet/hr_vendor?menuOption=hrVendor', '', defLength, 0, 0 );
menu[404][17]  = new Item('Customer', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );

menu[405] = new Array();
menu[405][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[405][1]  = new Item('Create Profile', '../servlet/hr_employee?menuOption=createProfile', '', defLength, 0, 0 );
menu[405][2]  = new Item('Update Profile(H)', 'NA.html', '', defLength, 0, 440 );
menu[405][3]  = new Item('View Profile(H)', 'NA.html', '', defLength, 0, 441 );

menu[406] = new Array();
menu[406][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[406][1]  = new Item('Salary Head', '../servlet/hr_salary_head?menuOption=hrSalaryHead', '', defLength, 0, 0 );
menu[406][2]  = new Item('Statewise Wages', '../servlet/hr_wages_statewise?menuOption=hrWagesStatewise', '', defLength, 0, 0 );
menu[406][3]  = new Item('Emp Agreement', '../servlet/hr_emp_agreement?menuOption=hrEmpAgreement', '', defLength, 0, 0 );
menu[406][4]  = new Item('Apr Emp Agreement', '../servlet/hr_emp_agreement?menuOption=hrEmpAgreementPendingApproval', '', defLength, 0, 0 );
menu[406][5]  = new Item('Tax Mgt', 'NA.html', '', defLength, 0, 482 );
menu[406][6]  = new Item('Sal Advance', 'NA.html', '', defLength, 0, 483 );
menu[406][7]  = new Item('Sal Prep', 'NA.html', '', defLength, 0, 484 );
menu[406][8]  = new Item('Custwise Salary Prep', '../servlet/hr_emp_salary_ledger?menuOption=prepSalaryCustwise', '', defLength, 0, 0 );

menu[407] = new Array();
menu[407][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[407][1]  = new Item('Evaluation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 446 );
menu[407][2]  = new Item('Appreciation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 447 );

menu[408] = new Array();
menu[408][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[408][1]  = new Item('Income', 'NA.html', '', defLength, 0, 448 );
menu[408][2]  = new Item('Deduction', 'NA.html', '', defLength, 0, 449 );

menu[409] = new Array();
menu[409][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[409][1]  = new Item('General Expense', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 450 );
menu[409][2]  = new Item('Local Conveyance', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 451 );

menu[410] = new Array();
menu[410][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[410][1]  = new Item('Upload Card Time', '../servlet/hr_card_time?menuOption=hrCardTime', '', defLength, 0, 0 );
menu[410][2]  = new Item('Daily Attn Sheet', '../servlet/hr_card_time?menuOption=hrAttendancesheet', '', defLength, 0, 0 );
menu[410][3]  = new Item('Weekly Timesheet', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 0 );
menu[410][4]  = new Item('Emp Working Hours', '../servlet/hr_card_time?menuOption=empDailyHour', '', defLength, 0, 0 );
menu[410][5]  = new Item('View Mnthly Attn', '../servlet/hr_emp_timesheet?menuOption=hrEmpTimesheet', '', defLength, 0, 0 );

menu[411] = new Array();
menu[411][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[411][1]  = new Item('Absent Type (Admin)', '../servlet/hr_absent_type?menuOption=hrAbsentType', '', defLength, 0, 0 );
menu[411][2]  = new Item('Leave Request', '../servlet/hr_vacation_request?menuOption=hrVacationRequest', '', defLength, 0, 0 );
menu[411][3]  = new Item('Leave Approval (Dept)', 'NA.html', '', defLength, 0, 0 );
menu[411][4]  = new Item('Leave Approval (HR)', 'NA.html', '', defLength, 0, 0 );
menu[411][5]  = new Item('Leave Balance', 'NA.html', '', defLength, 0, 0 );
menu[411][6]  = new Item('Leave Encashment', 'NA.html', '', defLength, 0, 0 );

menu[412] = new Array();
menu[412][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[412][1]  = new Item('Loan Type', 'NA.html', '', defLength, 0, 0 );
menu[412][2]  = new Item('Loan Request', 'NA.html', '', defLength, 0, 0 );
menu[412][3]  = new Item('Loan Approval', 'NA.html', '', defLength, 0, 0 );
menu[412][4]  = new Item('Loan Installments', 'NA.html', '', defLength, 0, 0 );
menu[412][5]  = new Item('Pending Loan Installments', 'NA.html', '', defLength, 0, 0 );
menu[412][6]  = new Item('Repayment Alert', 'NA.html', '', defLength, 0, 0 );

menu[413] = new Array();
menu[413][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[413][1]  = new Item('View Own Profile', '../servlet/hr_employee?menuOption=viewOwnProfile', '', defLength, 0, 0 );
menu[413][2]  = new Item('View Others Profile', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaQry', '', defLength, 0, 0 );
menu[413][3]  = new Item('Update Own Profile', 'NA.html', '', defLength, 0, 444 );
menu[413][4]  = new Item('Vacation Balance', 'NA.html', '', defLength, 0, 0 );

menu[414] = new Array();
menu[414][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[414][1]  = new Item('Leave Approval', 'NA.html', '', defLength, 0, 0 );
menu[414][2]  = new Item('Apr Encashed Leave', 'NA.html', '', defLength, 0, 0 );
menu[414][3]  = new Item('Apr Shift Change', 'NA.html', '', defLength, 0, 0 );
menu[414][4]  = new Item('Apr Shift Swap', 'NA.html', '', defLength, 0, 0 );
menu[414][5]  = new Item('Approve Timesheet', 'NA.html', '', defLength, 0, 0 );
menu[414][6]  = new Item('Apr Transfer', 'NA.html', '', defLength, 0, 0 );
menu[414][7]  = new Item('Apr Conveyance Report', 'NA.html', '', defLength, 0, 0 );
menu[414][8]  = new Item('Apr Expense Report', 'NA.html', '', defLength, 0, 0 );
menu[414][9]  = new Item('Apr Travel Request', 'NA.html', '', defLength, 0, 0 );

menu[415] = new Array();
menu[415][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[415][1]  = new Item('Recruitment Admin', 'NA.html', '', defLength, 0, 486 );
menu[415][2]  = new Item('Pre Advert', 'NA.html', '', defLength, 0, 487 );
menu[415][3]  = new Item('Post Advert', 'NA.html', '', defLength, 0, 488 );

menu[416] = new Array();
menu[416][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[416][1]  = new Item('Pre-Training Tasks', 'NA.html', '', defLength, 0, 489 );
menu[416][2]  = new Item('Post-Training Tasks', 'NA.html', '', defLength, 0, 490 );

menu[417] = new Array();
menu[417][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[417][1]  = new Item('Ticket', 'NA.html', '', defLength, 0, 491 );
menu[417][2]  = new Item('Expense Report', 'NA.html', '', defLength, 0, 492 );

menu[418] = new Array();
menu[418][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[418][1]  = new Item('Define Customer', '../servlet/esm_customer?menuOption=defineCustomer', '', defLength, 0, 0 );
menu[418][2]  = new Item('Cust Agr Form', '../servlet/hr_cust_agreement?menuOption=hrCustAgrForm', '', defLength, 0, 0 );
menu[418][3]  = new Item('Customer Agreement', '../servlet/hr_cust_agreement?menuOption=hrCustAgreement', '', defLength, 0, 0 );
menu[418][4]  = new Item('Allocate Resource', '../servlet/hr_cust_agreement?menuOption=outsourceEmployee', '', defLength, 0, 0 );
menu[418][5]  = new Item('Attn - Customerwise', '../servlet/hr_timesheet?menuOption=clientWiseAttn', '', defLength, 0, 0 );
menu[418][6]  = new Item('Open Bill Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[418][7]  = new Item('Bill Prepration', '../servlet/esm_cusomer_billing?menuOption=customerBillPrep', '', defLength, 0, 0 );
menu[418][8]  = new Item('Bill Q&A', '../servlet/esm_cusomer_billing?menuOption=customerBillQA', '', defLength, 0, 0 );
menu[418][9]  = new Item('Bill Print', '../servlet/esm_cusomer_billing?menuOption=customerBillPrint', '', defLength, 0, 0 );
menu[418][10]  = new Item('Bill Cycle Close', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycleClose', '', defLength, 0, 0 );
menu[418][11]  = new Item('Release Resource', '../servlet/hr_cust_agreement?menuOption=releaseResource', '', defLength, 0, 0 );

menu[419] = new Array();
menu[419][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[419][1]  = new Item('Shift Allocation', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[419][2]  = new Item('Shift Change Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[419][3]  = new Item('Shift Swap Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );
menu[419][4]  = new Item('Apr Shift Change Req', '../servlet/hr_shift?menuOption=hrShiftCode', '', defLength, 0, 0 );

menu[420] = new Array();
menu[420][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[420][1]  = new Item('Payment Collection', '../servlet/esm_cusomer_payment?menuOption=customerPayment', '', defLength, 0, 0 );

menu[421] = new Array();
menu[421][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[421][1]  = new Item('Req By Emp', 'NA.html', '', defLength, 0, 0 );
menu[421][2]  = new Item('Approval By Manager', 'NA.html', '', defLength, 0, 0 );
menu[421][3]  = new Item('Update Transfer Detail', 'NA.html', '', defLength, 0, 0 );

menu[422] = new Array();
menu[422][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[423] = new Array();
menu[423][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[424] = new Array();
menu[424][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[425] = new Array();
menu[425][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[426] = new Array();
menu[426][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[427] = new Array();
menu[427][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[428] = new Array();
menu[428][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[429] = new Array();
menu[429][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[429][1]  = new Item('New Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[429][2]  = new Item('Open Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );
menu[429][3]  = new Item('Close Salary Cycle', '../servlet/hr_salary_cycle?menuOption=hrSalaryCycle', '', defLength, 0, 0 );

menu[430] = new Array();
menu[430][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[431] = new Array();
menu[431][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[432] = new Array();
menu[432][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[433] = new Array();
menu[433][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[434] = new Array();
menu[434][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[435] = new Array();
menu[435][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[436] = new Array();
menu[436][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[437] = new Array();
menu[437][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[438] = new Array();
menu[438][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[439] = new Array();
menu[439][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[440] = new Array();
menu[440][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[440][1]  = new Item('Self', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[440][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaUpd', '', defLength, 0, 0 );

menu[441] = new Array();
menu[441][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[441][1]  = new Item('Self', '../servlet/hr_employee?menuOption=viewOwnProfile', '', defLength, 0, 0 );
menu[441][2]  = new Item('Admin', '../servlet/hr_employee?menuOption=hrEmployeeQueryCriteriaQry', '', defLength, 0, 0 );

menu[442] = new Array();
menu[442][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[443] = new Array();
menu[443][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[444] = new Array();
menu[444][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[444][1]  = new Item('Academic Detail', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[444][2]  = new Item('Family Members', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[444][3]  = new Item('Family Academic', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[444][4]  = new Item('Contact Detail', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );
menu[444][5]  = new Item('Skill and Domain', '../servlet/hr_employee?menuOption=updateProfile', '', defLength, 0, 0 );

menu[445] = new Array();
menu[445][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[446] = new Array();
menu[446][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[446][1]  = new Item('Notification By HR', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][2]  = new Item('Notification By Manager', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][3]  = new Item('Emp Self Evaluation', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][4]  = new Item('Emp Feedback', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][5]  = new Item('Emp Rating', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][6]  = new Item('Appraisal Acceptance', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[446][7]  = new Item('Objection on Appraisal', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );

menu[447] = new Array();
menu[447][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[447][1]  = new Item('Appreciation Letter', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[447][2]  = new Item('Apr Incr/Prom', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[447][3]  = new Item('Apr Incr/Prom(HR)', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[447][4]  = new Item('Modify Sal Structure', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );
menu[447][5]  = new Item('Arrear Calc', '../servlet/hr_emp_inc_prom?menuOption=hrIncProm', '', defLength, 0, 0 );

menu[448] = new Array();
menu[448][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[448][1]  = new Item('Overtime', 'NA.html', '', defLength, 0, 0 );
menu[448][2]  = new Item('Bonus', 'NA.html', '', defLength, 0, 0 );
menu[448][3]  = new Item('Gratuity', 'NA.html', '', defLength, 0, 0 );
menu[448][4]  = new Item('Arrear', 'NA.html', '', defLength, 0, 0 );
menu[448][5]  = new Item('Advance', 'NA.html', '', defLength, 0, 0 );
menu[448][6]  = new Item('Imprest', 'NA.html', '', defLength, 0, 0 );
menu[448][7]  = new Item('Incentive', 'NA.html', '', defLength, 0, 0 );
menu[448][8]  = new Item('LTA', 'NA.html', '', defLength, 0, 0 );

menu[449] = new Array();
menu[449][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[449][1]  = new Item('Income Tax', 'NA.html', '', defLength, 0, 0 );
menu[449][2]  = new Item('PF', 'NA.html', '', defLength, 0, 0 );
menu[449][3]  = new Item('ESI', 'NA.html', '', defLength, 0, 0 );

menu[450] = new Array();
menu[450][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[450][1]  = new Item('Expn Report By Emp', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[450][2]  = new Item('Phone Bills', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[450][3]  = new Item('Apr Expense Report', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[450][4]  = new Item('Expense Summary', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );

menu[451] = new Array();
menu[451][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[451][1]  = new Item('Conveyance Form', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );
menu[451][2]  = new Item('Apr Conveyance', '../servlet/hr_emp_general_expense?menuOption=hrEmpGeneralExpense', '', defLength, 0, 0 );

menu[452] = new Array();
menu[452][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[453] = new Array();
menu[453][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[454] = new Array();
menu[454][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[455] = new Array();
menu[455][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[456] = new Array();
menu[456][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[457] = new Array();
menu[457][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[458] = new Array();
menu[458][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[459] = new Array();
menu[459][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[460] = new Array();
menu[460][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[461] = new Array();
menu[461][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[462] = new Array();
menu[462][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[463] = new Array();
menu[463][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[464] = new Array();
menu[464][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[465] = new Array();
menu[465][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[466] = new Array();
menu[466][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[467] = new Array();
menu[467][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[468] = new Array();
menu[468][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[469] = new Array();
menu[469][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[470] = new Array();
menu[470][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[471] = new Array();
menu[471][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[472] = new Array();
menu[472][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[473] = new Array();
menu[473][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[474] = new Array();
menu[474][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[475] = new Array();
menu[475][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[476] = new Array();
menu[476][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[477] = new Array();
menu[477][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[478] = new Array();
menu[478][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[479] = new Array();
menu[479][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[480] = new Array();
menu[480][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[481] = new Array();
menu[481][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[482] = new Array();
menu[482][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[482][1]  = new Item('Accrued Policy', '../servlet/hr_emp_rr_accrued_amt?menuOption=hrEmpRrAccruedAmt', '', defLength, 0, 0 );
menu[482][2]  = new Item('Saving Declaration', '../servlet/hr_tax_rebate_reason_dtl?menuOption=hrTaxRebateReasonDtl', '', defLength, 0, 0 );
menu[482][3]  = new Item('Tax Sheet', '../servlet/hr_tax_ledger?menuOption=hrTaxLedger', '', defLength, 0, 0 );
menu[482][4]  = new Item('Emp Tax Sheet', '../servlet/hr_tax_ledger?menuOption=empTaxLedger', '', defLength, 0, 0 );
menu[482][5]  = new Item('Tax Saving Declaration - ADM', '../servlet/hr_tax_rebate_reason_dtl?menuOption=hrTaxRebateReasonDtlAdm', '', defLength, 0, 0 );
menu[482][6]  = new Item('Future Use1', 'NA.html', '', defLength, 0, 0 );
menu[482][7]  = new Item('Future Use2', 'NA.html', '', defLength, 0, 0 );

menu[483] = new Array();
menu[483][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[483][1]  = new Item('Request', 'NA.html', '', defLength, 0, 0 );
menu[483][2]  = new Item('Approve', 'NA.html', '', defLength, 0, 0 );

menu[484] = new Array();
menu[484][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[484][1]  = new Item('Monthly Salary', '../servlet/hr_emp_salary_ledger?menuOption=hrEmpBulkSalaryPrep', '', defLength, 0, 0 );
menu[484][2]  = new Item('Sal Cheque', '../servlet/hr_emp_clubbed_salary?menuOption=hrEmpSalaryCheque', '', defLength, 0, 0 );
menu[484][3]  = new Item('Sal Cheque (Custwise)', '../servlet/hr_emp_clubbed_salary?menuOption=hrEmpSalaryChequeCustwise', '', defLength, 0, 0 );
menu[484][4]  = new Item('Salary Slip', '../servlet/hr_emp_salary_ledger?menuOption=viewSalarySlip', '', defLength, 0, 0 );
menu[484][5]  = new Item('Salary Ledger(Old)', '../servlet/hr_emp_salary_ledger?menuOption=salaryLedger', '', defLength, 0, 0 );

menu[485] = new Array();
menu[485][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');

menu[486] = new Array();
menu[486][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[486][1]  = new Item('Job Position', '../servlet/hr_position?menuOption=hrPosition', '', defLength, 0, 0 );
menu[486][2]  = new Item('Define Eval Criteria', '../servlet/hr_eval_criteria?menuOption=hrEvalCriteria', '', defLength, 0, 0 );
menu[486][3]  = new Item('Recruit. Agency', '../servlet/hr_vendor?menuOption=hrVendor&vendor_type=R', '', defLength, 0, 0 );
menu[486][4]  = new Item('Position Qualification(Obso)', '../servlet/hr_position?menuOption=hrPositionQuali', '', defLength, 0, 0 );

menu[487] = new Array();
menu[487][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[487][1]  = new Item('Raise Recruitment(Dept)', '../servlet/hr_recruitment_req?menuOption=raiseRecRequestDeptMgr', '', defLength, 0, 0 );
menu[487][2]  = new Item('Raise Recruitment(Hr)', '../servlet/hr_recruitment_req?menuOption=raiseRecRequestHRMgr', '', defLength, 0, 0 );
menu[487][3]  = new Item('Moniter Rec Request', '../servlet/hr_recruitment_req?menuOption=moniterRecRequest', '', defLength, 0, 0 );
menu[487][4]  = new Item('Approve Rec Request', '../servlet/hr_recruitment_req?menuOption=approveRecRequest', '', defLength, 0, 0 );
menu[487][5]  = new Item('Process Recruitment', '../servlet/hr_recruitment_req?menuOption=processRecRequest', '', defLength, 0, 0 );

menu[488] = new Array();
menu[488][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[488][1]  = new Item('Resume Builder', '../servlet/hr_applicant?menuOption=hrApplicantCareer', '', defLength, 0, 0 );
menu[488][2]  = new Item('Careers', '../servlet/hr_applicant?menuOption=hrApplicantCareer', '', defLength, 0, 0 );
menu[488][3]  = new Item('Pick Resume', '../servlet/hr_applicant?menuOption=hrApplicantFilterResume', '', defLength, 0, 0 );
menu[488][4]  = new Item('Applicant Rating', '../servlet/hr_eval_criteria?menuOption=hrApplicantListOne', '', defLength, 0, 0 );
menu[488][5]  = new Item('Applicant Result', '../servlet/hr_eval_criteria?menuOption=hrApplicantListTwo', '', defLength, 0, 0 );
menu[488][6]  = new Item('Final Selection', '../servlet/hr_eval_criteria?menuOption=hrApplicantListThree', '', defLength, 0, 0 );
menu[488][7]  = new Item('Selected Candidates', '../servlet/hr_applicant?menuOption=hrCandidateListOne', '', defLength, 0, 0 );
menu[488][8]  = new Item('Final List Candidates', '../servlet/hr_applicant?menuOption=hrCandidateListTwo', '', defLength, 0, 0 );
menu[488][9]  = new Item('Send For Training', '../servlet/hr_training?menuOption=hrTrainingApplicant', '', defLength, 0, 0 );

menu[489] = new Array();
menu[489][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[489][1]  = new Item('Training Course', '../servlet/hr_training_course?menuOption=hrTrainingCourse', '', defLength, 0, 0 );
menu[489][2]  = new Item('Training Charge', '../servlet/hr_training_charge?menuOption=hrTrainingCharge', '', defLength, 0, 0 );
menu[489][3]  = new Item('Define Training', '../servlet/hr_training?menuOption=hrTraining', '', defLength, 0, 0 );
menu[489][4]  = new Item('Trainee List', '../servlet/hr_training?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[489][5]  = new Item('Apr Training Req', '../servlet/hr_training?menuOption=hrTrainingApprove', '', defLength, 0, 0 );
menu[489][6]  = new Item('Training Schedule', '../servlet/hr_training_sch?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[489][7]  = new Item('Training Schedule Report', '../servlet/hr_training_sch?menuOption=hrTrainingSch', '', defLength, 0, 0 );
menu[489][8]  = new Item('Training Payment', '../servlet/hr_training_charge?menuOption=hrTrainingPayment', '', defLength, 0, 0 );
menu[489][9]  = new Item('Training Req (Emp)', '../servlet/hr_training?menuOption=hrTraineeList', '', defLength, 0, 0 );
menu[489][10]  = new Item('Group Training(obso)', '../servlet/hr_training_grp_req?menuOption=hrTrainingGrpReq', '', defLength, 0, 0 );
menu[489][11]  = new Item('Apr Group Training(obso)', '../servlet/hr_training?menuOption=hrTrainingApprove', '', defLength, 0, 0 );

menu[490] = new Array();
menu[490][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[490][1]  = new Item('Confirm As Emp', '../servlet/hr_training?menuOption=hrTrainingConfirmation', '', defLength, 0, 0 );
menu[490][2]  = new Item('Trainer Feedback', '../servlet/hr_training?menuOption=hrTrainingFeedback', '', defLength, 0, 0 );
menu[490][3]  = new Item('Trainee Feedback', '../servlet/hr_training?menuOption=hrTrainingFeedback', '', defLength, 0, 0 );

menu[491] = new Array();
menu[491][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[491][1]  = new Item('Travel Request', '../servlet/hr_travel_req?menuOption=raiseTravelReq', '', defLength, 0, 0 );
menu[491][2]  = new Item('Apr Travel Req(D) ', 'NA.html', '', defLength, 0, 0 );
menu[491][3]  = new Item('Apr Travel Req(H)', 'NA.html', '', defLength, 0, 0 );
menu[491][4]  = new Item('Apr Travel Req(TD)', '../servlet/hr_travel_req?menuOption=inbxDeptMgr&lReqType=travelReq&EmpType=TA', '', defLength, 0, 0 );
menu[491][5]  = new Item('Ticket Delivery', 'NA.html', '', defLength, 0, 0 );

menu[492] = new Array();
menu[492][0]  = new Menu(true, '>', lSubMenuX, lSubMenuY, inSubMenuWidth, defOver, defBack, 'itemBorder', 'itemText');
menu[492][1]  = new Item('Travel Expence', '../servlet/hr_travel_expense_report?menuOption=hrTravelExpense', '', defLength, 0, 0 );
menu[492][2]  = new Item('Apr Exp Rep(E)', 'NA.html', '', defLength, 0, 0 );
menu[492][3]  = new Item('Apr Exp Rep(D)', 'NA.html', '', defLength, 0, 0 );
menu[492][4]  = new Item('New Exp Rep(Fin)', 'NA.html', '', defLength, 0, 0 );
menu[492][5]  = new Item('Monthly Trvl Exp Rep', 'NA.html', '', defLength, 0, 0 );

  return menu;
}
