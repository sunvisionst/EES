cp ../SST/SSTSU_gn_appln_menu_generated.js 1401_gn_appln_menu_generated.js



cd ../../css

cp SSTSU_gn_data.css 1401_gn_data.css

cd -
