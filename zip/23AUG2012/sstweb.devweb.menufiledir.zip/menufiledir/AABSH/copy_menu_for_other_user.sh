cp ../SST/SSTSU_gn_appln_menu_generated.js 2101_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2102_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2103_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2104_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2105_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2106_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2107_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2108_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2109_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2110_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2111_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2112_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2113_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2114_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2115_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2116_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2117_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2118_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2119_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2120_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2121_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2122_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2123_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2124_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2125_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2126_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2127_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2128_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2129_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 2130_gn_appln_menu_generated.js



cd ../../css

cp SSTSU_gn_data.css 2101_gn_data.css
cp SSTSU_gn_data.css 2102_gn_data.css
cp SSTSU_gn_data.css 2103_gn_data.css
cp SSTSU_gn_data.css 2104_gn_data.css
cp SSTSU_gn_data.css 2105_gn_data.css
cp SSTSU_gn_data.css 2106_gn_data.css
cp SSTSU_gn_data.css 2107_gn_data.css
cp SSTSU_gn_data.css 2108_gn_data.css
cp SSTSU_gn_data.css 2109_gn_data.css
cp SSTSU_gn_data.css 2110_gn_data.css
cp SSTSU_gn_data.css 2111_gn_data.css
cp SSTSU_gn_data.css 2112_gn_data.css
cp SSTSU_gn_data.css 2113_gn_data.css
cp SSTSU_gn_data.css 2114_gn_data.css
cp SSTSU_gn_data.css 2115_gn_data.css
cp SSTSU_gn_data.css 2116_gn_data.css
cp SSTSU_gn_data.css 2117_gn_data.css
cp SSTSU_gn_data.css 2118_gn_data.css
cp SSTSU_gn_data.css 2119_gn_data.css
cp SSTSU_gn_data.css 2120_gn_data.css
cp SSTSU_gn_data.css 2121_gn_data.css
cp SSTSU_gn_data.css 2122_gn_data.css
cp SSTSU_gn_data.css 2123_gn_data.css
cp SSTSU_gn_data.css 2124_gn_data.css
cp SSTSU_gn_data.css 2125_gn_data.css
cp SSTSU_gn_data.css 2126_gn_data.css
cp SSTSU_gn_data.css 2127_gn_data.css
cp SSTSU_gn_data.css 2128_gn_data.css
cp SSTSU_gn_data.css 2129_gn_data.css
cp SSTSU_gn_data.css 2130_gn_data.css

cd -
