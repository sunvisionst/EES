function returnMenu( inLeftCoord, inTopCoord, inWidth, inSubMenuWidth, inSubMenuY )
{ 

  var menu      = new Array(); 
  var lSubMenuX = inWidth; 
  var lSubMenuY = inSubMenuY; 


  return menu;
}
