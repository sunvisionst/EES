cp ../SST/SSTSU_gn_appln_menu_generated.js 1601_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1602_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1603_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1604_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1605_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1606_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1607_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1608_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1609_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1610_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1611_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1612_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1613_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1614_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1615_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1616_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1617_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1618_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1619_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1620_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1621_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1622_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1623_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1624_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1625_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1626_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1627_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1628_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1629_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1630_gn_appln_menu_generated.js



cd ../../css

cp SSTSU_gn_data.css 1601_gn_data.css
cp SSTSU_gn_data.css 1602_gn_data.css
cp SSTSU_gn_data.css 1603_gn_data.css
cp SSTSU_gn_data.css 1604_gn_data.css
cp SSTSU_gn_data.css 1605_gn_data.css
cp SSTSU_gn_data.css 1606_gn_data.css
cp SSTSU_gn_data.css 1607_gn_data.css
cp SSTSU_gn_data.css 1608_gn_data.css
cp SSTSU_gn_data.css 1609_gn_data.css
cp SSTSU_gn_data.css 1610_gn_data.css
cp SSTSU_gn_data.css 1611_gn_data.css
cp SSTSU_gn_data.css 1612_gn_data.css
cp SSTSU_gn_data.css 1613_gn_data.css
cp SSTSU_gn_data.css 1614_gn_data.css
cp SSTSU_gn_data.css 1615_gn_data.css
cp SSTSU_gn_data.css 1616_gn_data.css
cp SSTSU_gn_data.css 1617_gn_data.css
cp SSTSU_gn_data.css 1618_gn_data.css
cp SSTSU_gn_data.css 1619_gn_data.css
cp SSTSU_gn_data.css 1620_gn_data.css
cp SSTSU_gn_data.css 1621_gn_data.css
cp SSTSU_gn_data.css 1622_gn_data.css
cp SSTSU_gn_data.css 1623_gn_data.css
cp SSTSU_gn_data.css 1624_gn_data.css
cp SSTSU_gn_data.css 1625_gn_data.css
cp SSTSU_gn_data.css 1626_gn_data.css
cp SSTSU_gn_data.css 1627_gn_data.css
cp SSTSU_gn_data.css 1628_gn_data.css
cp SSTSU_gn_data.css 1629_gn_data.css
cp SSTSU_gn_data.css 1630_gn_data.css

cd -
