cp ../SST/SSTSU_gn_appln_menu_generated.js 1101_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1102_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1103_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1104_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1105_gn_appln_menu_generated.js


cd ../../css

cp SSTSU_gn_data.css 1101_gn_data.css
cp SSTSU_gn_data.css 1102_gn_data.css
cp SSTSU_gn_data.css 1103_gn_data.css
cp SSTSU_gn_data.css 1105_gn_data.css

cd -
