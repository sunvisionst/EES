cp ../SST/SSTSU_gn_appln_menu_generated.js 1201_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1202_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1203_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1204_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1205_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1206_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1207_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1208_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1209_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1210_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1211_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1212_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1213_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1214_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1215_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1216_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1217_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1218_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1219_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1220_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1221_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1222_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1223_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1224_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1225_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1226_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1227_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1228_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1229_gn_appln_menu_generated.js
cp ../SST/SSTSU_gn_appln_menu_generated.js 1230_gn_appln_menu_generated.js



cd ../../css

cp SSTSU_gn_data.css 1201_gn_data.css
cp SSTSU_gn_data.css 1202_gn_data.css
cp SSTSU_gn_data.css 1203_gn_data.css
cp SSTSU_gn_data.css 1204_gn_data.css
cp SSTSU_gn_data.css 1205_gn_data.css
cp SSTSU_gn_data.css 1206_gn_data.css
cp SSTSU_gn_data.css 1207_gn_data.css
cp SSTSU_gn_data.css 1208_gn_data.css
cp SSTSU_gn_data.css 1209_gn_data.css
cp SSTSU_gn_data.css 1210_gn_data.css
cp SSTSU_gn_data.css 1211_gn_data.css
cp SSTSU_gn_data.css 1212_gn_data.css
cp SSTSU_gn_data.css 1213_gn_data.css
cp SSTSU_gn_data.css 1214_gn_data.css
cp SSTSU_gn_data.css 1215_gn_data.css
cp SSTSU_gn_data.css 1216_gn_data.css
cp SSTSU_gn_data.css 1217_gn_data.css
cp SSTSU_gn_data.css 1218_gn_data.css
cp SSTSU_gn_data.css 1219_gn_data.css
cp SSTSU_gn_data.css 1220_gn_data.css
cp SSTSU_gn_data.css 1221_gn_data.css
cp SSTSU_gn_data.css 1222_gn_data.css
cp SSTSU_gn_data.css 1223_gn_data.css
cp SSTSU_gn_data.css 1224_gn_data.css
cp SSTSU_gn_data.css 1225_gn_data.css
cp SSTSU_gn_data.css 1226_gn_data.css
cp SSTSU_gn_data.css 1227_gn_data.css
cp SSTSU_gn_data.css 1228_gn_data.css
cp SSTSU_gn_data.css 1229_gn_data.css
cp SSTSU_gn_data.css 1230_gn_data.css

cd -
